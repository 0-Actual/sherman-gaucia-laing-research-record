// Live verification of the fixed local workspace; does not start model inference.
import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
import http from 'node:http';
const root=import.meta.dirname,base='http://127.0.0.1:17818',checks=[];
const assert=(value,message)=>{if(!value)throw Error(message);};
async function call(route,{method='GET',headers={},body}={}){
  const r=await fetch(base+route,{method,headers:{'Content-Type':'application/json',...headers},...(body===undefined?{}:{body:JSON.stringify(body)}),redirect:'error',signal:AbortSignal.timeout(5000)});
  return {status:r.status,body:await r.json()};
}
async function check(name,fn){try{const detail=await fn();checks.push({name,passed:true,detail});}catch(e){checks.push({name,passed:false,error:e.message});}}
await check('Unauthenticated API access is refused',async()=>{assert((await call('/api/status')).status===403,'API admitted without session');return '403';});
await check('Foreign Origin is refused',async()=>{assert((await call('/health',{headers:{Origin:'https://example.invalid'}})).status===403,'Foreign origin admitted');return '403';});
await check('Foreign Host is refused',async()=>{
  // Fetch may replace Host; use a raw HTTP request so this checks the actual wire header.
  const status=await new Promise((resolve,reject)=>{
    const req=http.request({hostname:'127.0.0.1',port:17818,path:'/health',headers:{Host:'example.invalid'}},res=>{res.resume();res.on('end',()=>resolve(res.statusCode));});
    req.setTimeout(5000,()=>req.destroy(Error('Host probe timed out')));req.on('error',reject);req.end();
  });
  assert(status===403,'Foreign host admitted: '+status);return '403 with explicit Host header';
});
const auth=await call('/session');assert(auth.status===200&&auth.body.session,'Session unavailable');
const headers={'x-q8-session':auth.body.session};
await check('Live reference corpus loads without errors',async()=>{const r=await call('/api/status',{headers});assert(r.status===200&&r.body.knowledge.records>700&&!r.body.knowledge.errors.length,'Knowledge load failed');return r.body.knowledge;});
await check('Consolidated catalog resolves its required entries',async()=>{const r=await call('/api/catalog',{headers});assert(r.status===200,'Catalog unavailable');const required=r.body.entries.filter(e=>e.required);assert(required.length>=4&&required.every(e=>e.available),'Required catalog target missing');return {entries:r.body.entries.length,required:required.length,missingOptional:r.body.entries.filter(e=>!e.available).map(e=>e.title)};});
await check('Run endpoint refuses arbitrary parameters',async()=>{const r=await call('/api/run',{method:'POST',headers,body:{command:'not-a-capability'}});assert(r.status===400,'Unexpected parameter admitted');return '400';});
const fixtures=JSON.parse(fs.readFileSync(path.join(root,'knowledge/heldout_queries.json'),'utf8')).fixtures;
for(const f of fixtures)await check('Retrieval: '+f.id,async()=>{const r=await call('/api/search?q='+encodeURIComponent(f.query),{headers});const i=r.body.matches.findIndex(m=>m.title.startsWith(f.expected_source_prefix));assert(r.status===200&&i>=0&&i<8,'Expected source missing from first eight results');const m=r.body.matches[i];assert(m.sourcePath&&fs.existsSync(m.sourcePath),'Full local source unavailable');return {rank:i+1,source:m.sourcePath,generatedAnswerEvaluated:false};});
let run;
await check('Fixed test suite completes and preserves both copies',async()=>{
  const started=await call('/api/run',{method:'POST',headers,body:{}});assert(started.status===202,'Suite not admitted: '+JSON.stringify(started.body));
  for(let i=0;i<160;i++){await new Promise(resolve=>setTimeout(resolve,200));const r=await call('/api/run?id='+encodeURIComponent(started.body.id),{headers});run=r.body;if(run.status!=='running')break;}
  assert(run.status==='complete'&&run.result.summary.failed===0,'Suite failed or did not complete');
  assert(run.storage.length>=2&&run.allCopiesVerified,'Both saved copies were not verified');
  const bytes=run.storage.map(s=>fs.readFileSync(s.path));assert(bytes.every(b=>b.equals(bytes[0])),'Saved evidence bytes differ');
  return {id:run.id,summary:run.result.summary,storage:run.storage,measurements:run.result.measurements};
});
const result={at:new Date().toISOString(),checks,summary:{passed:checks.filter(c=>c.passed).length,failed:checks.filter(c=>!c.passed).length,total:checks.length},testRun:run?.id||null,release:'PRIVATE/HOLD/UNSIGNED',signature:null};
const cfg=JSON.parse(fs.readFileSync(path.join(root,'workspace.json'),'utf8'));
const name='workspace-verification-'+Date.now()+'-'+randomUUID().slice(0,8)+'.json',bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');
for(const d of [...new Set([root,...cfg.mirrorRoots].map(p=>path.resolve(p)))]){const file=path.join(d,'evidence',name);fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,bytes,{flag:'wx'});assert(fs.readFileSync(file).equals(bytes),'Verification receipt readback failed');}
console.log(JSON.stringify(result));if(result.summary.failed)process.exitCode=1;
