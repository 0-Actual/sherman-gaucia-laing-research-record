// Quantum.Earth.Laing. Prepared for Sherman G. Laing; assistant-written integration.
// Fixed local study and testing operations. No language output is executable.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {randomBytes,randomUUID} from 'node:crypto';
import {Worker} from 'node:worker_threads';
import {Library} from './engine/library-core.mjs';

const root=import.meta.dirname;
const config=JSON.parse(fs.readFileSync(path.join(root,'workspace.json'),'utf8'));
const port=config.port;
if(port!==17818)throw Error('This workspace uses the fixed local port 17818.');
const host=`127.0.0.1:${port}`,origin=`http://${host}`,session=randomBytes(24).toString('hex');
const library=new Library(root,['knowledge/corpus.jsonl']);
const runs=new Map();let active=null,lastRun=null;
const mirrors=[...new Set([root,...config.mirrorRoots].map(p=>path.resolve(p)))];
const catalog=JSON.parse(fs.readFileSync(path.join(root,'catalog.json'),'utf8')).entries;

function writeEvidence(name,value){
  const bytes=Buffer.from(JSON.stringify(value,null,2)+'\n'),destinations=[];
  for(const base of mirrors){
    const file=path.join(base,'evidence',name);
    try{
      fs.mkdirSync(path.dirname(file),{recursive:true});
      const fd=fs.openSync(file,'wx');try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
      if(!fs.readFileSync(file).equals(bytes))throw Error('Exact byte readback failed');
      destinations.push({path:file,bytes:bytes.length,verified:true});
    }catch(e){destinations.push({path:file,verified:false,error:e.message});}
  }
  return destinations;
}
function json(res,status,value){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Content-Security-Policy':"default-src 'none'; frame-ancestors 'none'"});res.end(JSON.stringify(value));}
async function body(req){let text='',bytes=0;for await(const b of req){bytes+=b.length;if(bytes>4096)throw Error('Request too large');text+=b.toString('utf8');}return JSON.parse(text||'{}');}
function localSource(row){
  const expected=path.resolve(root,'knowledge','documents');
  const sourcePath=path.join(expected,path.basename(row.origin));
  return {...row,sourcePath:fs.existsSync(sourcePath)?sourcePath:null};
}
function startSuite(){
  const id=Date.now()+'-'+randomUUID().slice(0,8),run={id,status:'running',startedAt:new Date().toISOString()};
  active=run;runs.set(id,run);
  let worker,timer,settled=false;
  const finish=(result,error)=>{
    if(settled)return;settled=true;clearTimeout(timer);worker?.terminate();
    Object.assign(run,{status:error?'failed':'complete',finishedAt:new Date().toISOString(),...(error?{error}:{result})});
    const evidence={...run,owner:'Sherman G. Laing',authorship:'Assistant-written tests of established mathematics and the existing QEL engine',release:'PRIVATE/HOLD/UNSIGNED',signature:null};
    run.storage=writeEvidence('test-'+id+'.json',evidence);
    run.allCopiesVerified=run.storage.every(s=>s.verified);
    lastRun=run;active=null;
    if(runs.size>40){for(const key of runs.keys()){if(key!==id){runs.delete(key);break;}}}
  };
  try{
    worker=new Worker(new URL('./suite-worker.mjs',import.meta.url));
    timer=setTimeout(()=>finish(null,'Suite exceeded its 30-second execution budget.'),30000);
    worker.once('message',m=>m.ok?finish(m.result,null):finish(null,m.error));
    worker.once('error',e=>finish(null,e.message));
    worker.once('exit',code=>{if(!settled)finish(null,'Test worker exited before a result: '+code);});
  }catch(e){finish(null,e.message);}
  return run;
}
const evidenceDir=path.join(root,'evidence');
if(fs.existsSync(evidenceDir)){
  for(const n of fs.readdirSync(evidenceDir).filter(n=>/^test-[0-9]+-[a-f0-9]+\.json$/.test(n)).sort().reverse()){
    try{
      const bytes=fs.readFileSync(path.join(evidenceDir,n)),r=JSON.parse(bytes.toString('utf8'));
      if(r.id&&['complete','failed'].includes(r.status)){
        r.storage=mirrors.map(base=>{const file=path.join(base,'evidence',n);try{return {path:file,bytes:bytes.length,verified:fs.readFileSync(file).equals(bytes),verifiedOnReload:true};}catch(e){return {path:file,verified:false,error:e.message,verifiedOnReload:true};}});
        r.allCopiesVerified=r.storage.every(s=>s.verified);lastRun=r;runs.set(r.id,r);break;
      }
    }catch{}
  }
}
const server=http.createServer(async(req,res)=>{
  try{
    if(req.headers.host!==host)return json(res,403,{error:'Local host only'});
    if(req.headers.origin&&req.headers.origin!==origin)return json(res,403,{error:'Local origin only'});
    if(req.headers['sec-fetch-site']==='cross-site')return json(res,403,{error:'Cross-site request refused'});
    const url=new URL(req.url,origin),p=url.pathname;
    if(req.method==='GET'&&p==='/health')return json(res,200,{app:'Q8_TESTING_SPACE',ready:true});
    if(req.method==='GET'&&p==='/session')return json(res,200,{session});
    if(!p.startsWith('/api/')||req.headers['x-q8-session']!==session)return json(res,403,{error:'Local session required'});
    if(req.method==='GET'&&p==='/api/status')return json(res,200,{app:'Q8_TESTING_SPACE',version:config.version,pid:process.pid,workspace:root,active:active?.id||null,freeMiB:Math.floor(os.freemem()/1048576),knowledge:library.summary(),lastRun,release:'PRIVATE/HOLD/UNSIGNED',languageWeightsUpdated:false});
    if(req.method==='GET'&&p==='/api/catalog')return json(res,200,{entries:catalog.map(e=>{const target=e.relative?path.resolve(root,e.path):(e.variants?.[root.toLowerCase().startsWith('d:')?'usb':'laptop']||e.path);return {...e,path:target,available:fs.existsSync(target)};})});
    if(req.method==='GET'&&p==='/api/search'){
      const q=url.searchParams.get('q')||'';if(q.length>1000)throw Error('Search text too long');
      return json(res,200,{matches:library.search(q,12).map(localSource)});
    }
    if(req.method==='GET'&&p==='/api/run'){
      const r=runs.get(url.searchParams.get('id'));return json(res,r?200:404,r||{error:'Run not found'});
    }
    if(req.method==='POST'&&p==='/api/run'){
      const b=await body(req);if(Object.keys(b).length)throw Error('This endpoint only runs the fixed reviewed suite.');
      if(active)return json(res,409,{error:'A test run is already active.'});
      if(os.freemem()<96*1024**2)return json(res,503,{error:'Less than 96 MiB free memory. No suite was started.'});
      return json(res,202,{id:startSuite().id});
    }
    if(req.method==='POST'&&p==='/api/reindex'){
      const b=await body(req);if(Object.keys(b).length)throw Error('No arbitrary corpus path is accepted.');
      if(active)return json(res,409,{error:'Wait for the current test run.'});
      return json(res,200,{knowledge:library.reload()});
    }
    return json(res,404,{error:'No such local capability'});
  }catch(e){json(res,400,{error:e.message});}
});
server.requestTimeout=10000;server.headersTimeout=8000;server.maxConnections=12;
server.on('error',e=>{console.error(e.message);process.exitCode=1;});
server.listen(port,'127.0.0.1',()=>console.log(JSON.stringify({ready:true,pid:process.pid,origin,knowledge:library.summary()})));
for(const s of ['SIGINT','SIGTERM'])process.on(s,()=>{if(active)return;server.close(()=>process.exit(0));});
