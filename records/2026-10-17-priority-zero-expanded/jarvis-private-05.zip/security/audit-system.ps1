$ErrorActionPreference='Stop'
$ProgressPreference='SilentlyContinue'
$Audit=[ordered]@{utc=[DateTime]::UtcNow.ToString('o');identity=[Security.Principal.WindowsIdentity]::GetCurrent().Name;read_only=$true;probes=[ordered]@{}}
function Probe($Name,[scriptblock]$Body) {
 try {$value=& $Body; $Audit.probes[$Name]=[ordered]@{status='READ';value=$value}}
 catch {$Audit.probes[$Name]=[ordered]@{status='UNVERIFIED';error=$_.Exception.Message}}
}
Probe 'os' {Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' | Select-Object ProductName,EditionID,DisplayVersion,CurrentBuildNumber,UBR}
Probe 'drives' {[IO.DriveInfo]::GetDrives() | Where-Object {$_.Name -in @('./REDACTED_LOCAL_ROOT/','./REDACTED_LOCAL_ROOT/')} | Select-Object Name,DriveType,DriveFormat,IsReady,TotalSize,AvailableFreeSpace}
Probe 'services' {Get-Service -Name WinDefend,mpssvc,wscsvc,TermService,RemoteRegistry,sshd,WinRM,LanmanServer -ErrorAction SilentlyContinue | Select-Object Name,Status,StartType}
Probe 'defender_status' {Get-MpComputerStatus | Select-Object AMServiceEnabled,AntivirusEnabled,RealTimeProtectionEnabled,BehaviorMonitorEnabled,IoavProtectionEnabled,NISEnabled,IsTamperProtected,AntivirusSignatureLastUpdated,AntivirusSignatureVersion,QuickScanAge,FullScanAge,RebootRequired}
Probe 'defender_settings' {$p=Get-MpPreference; [pscustomobject]@{MAPSReporting=$p.MAPSReporting;SubmitSamplesConsent=$p.SubmitSamplesConsent;DisableRealtimeMonitoring=$p.DisableRealtimeMonitoring;EnableControlledFolderAccess=$p.EnableControlledFolderAccess;ExclusionPathCount=@($p.ExclusionPath).Count;ExclusionProcessCount=@($p.ExclusionProcess).Count;ControlledFolderCount=@($p.ControlledFolderAccessProtectedFolders).Count;AllowedAppCount=@($p.ControlledFolderAccessAllowedApplications).Count}}
Probe 'firewall' {Get-NetFirewallProfile -PolicyStore ActiveStore | Select-Object Name,Enabled,DefaultInboundAction,DefaultOutboundAction,AllowInboundRules,AllowLocalFirewallRules,NotifyOnListen,LogBlocked,LogAllowed,LogMaxSizeKilobytes}
Probe 'network_profiles' {Get-NetConnectionProfile | Select-Object InterfaceAlias,NetworkCategory,IPv4Connectivity,IPv6Connectivity}
Probe 'bitlocker' {Get-BitLockerVolume -MountPoint 'C:','D:' | Select-Object MountPoint,VolumeType,ProtectionStatus,VolumeStatus,EncryptionPercentage,EncryptionMethod,LockStatus,AutoUnlockEnabled}
Probe 'remote_desktop_policy' {Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' | Select-Object fDenyTSConnections}
Probe 'network_shares' {Get-SmbShare | Select-Object Name,Path,Special,EncryptData,FolderEnumerationMode}
Probe 'local_users' {Get-LocalUser | Select-Object Name,Enabled,PasswordRequired,PasswordExpires,LastLogon}
Probe 'administrator_members' {Get-LocalGroupMember -SID 'S-1-5-32-544' | Select-Object Name,ObjectClass,PrincipalSource}
Probe 'usb_autorun_policy' {
 $names=@('HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer','HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\Explorer')
 foreach($n in $names){if(Test-Path $n){Get-ItemProperty $n | Select-Object PSPath,NoDriveTypeAutoRun,NoAutorun}}
}
Probe 'file_access' {
 foreach($p in @('./REDACTED_LOCAL_ROOT/Documents\Codex\Q8_Testing_Space','./REDACTED_LOCAL_ROOT/QEL_Q7','./REDACTED_LOCAL_ROOT/QEL_Q7\Q8_Testing_Space')) {
  $a=Get-Acl -LiteralPath $p
  [pscustomobject]@{path=$p;owner=$a.Owner;inheritance_disabled=$a.AreAccessRulesProtected;rules=@($a.Access | Select-Object IdentityReference,FileSystemRights,AccessControlType,IsInherited)}
 }
}
Probe 'cloud_sync_processes' {Get-Process -Name OneDrive,Dropbox,GoogleDriveFS,Box,BoxDrive -ErrorAction SilentlyContinue | Select-Object ProcessName,Id}
Probe 'node_security_flags' {(& './REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe' --help | Select-String -Pattern 'permission|allow-net|allow-fs|allow-child|allow-worker').Line}
$Audit | ConvertTo-Json -Depth 9
