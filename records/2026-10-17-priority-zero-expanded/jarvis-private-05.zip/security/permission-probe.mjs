import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {Worker} from 'node:worker_threads';
const [allowed,denied]=process.argv.slice(2),checks=[];
function check(name,fn,denial=false){try{const value=fn();checks.push({name,passed:!denial&&value===true,denied:false});}catch(e){checks.push({name,passed:denial&&e.code==='ERR_ACCESS_DENIED',denied:true,code:e.code});}}
check('permitted_read',()=>fs.readFileSync(allowed+'/read.txt','utf8')==='PUBLIC SECURITY CANARY');
check('permitted_write',()=>{fs.writeFileSync(allowed+'/write.txt','PUBLIC SECURITY CANARY',{flag:'wx'});return true;});
check('outside_read_denied',()=>fs.readFileSync(denied+'/read.txt'),true);
check('outside_create_denied',()=>fs.writeFileSync(denied+'/unexpected.txt','CANARY',{flag:'wx'}),true);
check('child_process_denied',()=>{const r=spawnSync(process.execPath,['-e','process.exit(0)']);if(r.error)throw r.error;return r.status===0;},true);
check('worker_thread_denied',()=>new Worker('0',{eval:true}),true);
console.log(JSON.stringify({checks,passed:checks.every(x=>x.passed),scope:'Trusted-code permission checks only; no hostile-code isolation or OS-wide network-denial claim.'}));
process.exitCode=checks.every(x=>x.passed)?0:1;
