// Fixed eight-orbital Wannier reconstruction. Same term order as baseline.mjs.
import {validateH} from './baseline.mjs';
export function validatePacked(data){
 if(data.length!==1041*131)throw Error('Packed Wannier length mismatch');
 for(let b=0;b<1041;b++){const at=b*131;for(let j=0;j<131;j++)if(!Number.isFinite(data[at+j])||(j<3&&!Number.isInteger(data[at+j])))throw Error('Invalid packed Wannier value');}
 return true;
}
export function constructPacked(data,k){
 if(data.length!==1041*131||!Array.isArray(k)||k.length!==3||!k.every(Number.isFinite))throw Error('Invalid packed reconstruction input');
 const values=new Float64Array(128);
 for(let b=0;b<1041;b++){const at=b*131,angle=2*Math.PI*(data[at]*k[0]+data[at+1]*k[1]+data[at+2]*k[2]),c=Math.cos(angle),s=Math.sin(angle);
  for(let j=0;j<128;j+=2){const re=data[at+3+j],im=data[at+4+j];values[j]+=c*re-s*im;values[j+1]+=c*im+s*re;}
 }
 const h=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>[values[2*(8*i+j)],values[2*(8*i+j)+1]]));let rawDefect=0;
 for(let i=0;i<8;i++)for(let j=0;j<8;j++)rawDefect=Math.max(rawDefect,Math.hypot(h[i][j][0]-h[j][i][0],h[i][j][1]+h[j][i][1]));
 const projected=h.map((r,i)=>r.map((z,j)=>[(z[0]+h[j][i][0])/2,(z[1]-h[j][i][1])/2]));validateH(projected);return{h:projected,rawDefect};
}
