// Exact parameter derivatives from the unchanged Q8 ansatz, followed by a damped Newton step.
// No physical-Hamiltonian eigensolver, reference eigenvalues, or reference states are imported.
import {ansatz,actualState,validateH} from './baseline.mjs';
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0),norm=a=>Math.sqrt(dot(a,a));
const scale=(a,s)=>a.map(z=>[z[0]*s,z[1]*s]);
const sub=(a,b)=>a.map((z,i)=>[z[0]-b[i][0],z[1]-b[i][1]]);
function realInner(a,b){let sum=0,correction=0;for(let i=0;i<a.length;i++){const term=a[i][0]*b[i][0]+a[i][1]*b[i][1],y=term-correction,t=sum+y;correction=(t-sum)-y;sum=t;}return sum;}
const mv=(H,p)=>H.map(row=>{let re=0,im=0;for(let j=0;j<p.length;j++){re+=row[j][0]*p[j][0]-row[j][1]*p[j][1];im+=row[j][0]*p[j][1]+row[j][1]*p[j][0];}return [re,im];});
const vectorNorm=p=>Math.sqrt(realInner(p,p));
export function symmetricEigen(matrix){
 const n=matrix.length,A=matrix.map(r=>r.slice()),V=Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>+(i===j)));
 const tolerance=2e-16*Math.max(1,...A.flat().map(Math.abs));let rotations=0;
 for(;rotations<100*n*n;rotations++){
  let p=0,q=1,largest=0;for(let i=0;i<n;i++)for(let j=i+1;j<n;j++)if(Math.abs(A[i][j])>largest){largest=Math.abs(A[i][j]);p=i;q=j;}
  if(largest<=tolerance)break;
  const tau=(A[q][q]-A[p][p])/(2*A[p][q]),t=(tau>=0?1:-1)/(Math.abs(tau)+Math.sqrt(1+tau*tau)),c=1/Math.sqrt(1+t*t),s=t*c,apq=A[p][q];
  A[p][p]-=t*apq;A[q][q]+=t*apq;A[p][q]=A[q][p]=0;
  for(let k=0;k<n;k++){if(k!==p&&k!==q){const kp=A[k][p],kq=A[k][q];A[k][p]=A[p][k]=c*kp-s*kq;A[k][q]=A[q][k]=s*kp+c*kq;}const vp=V[k][p],vq=V[k][q];V[k][p]=c*vp-s*vq;V[k][q]=s*vp+c*vq;}
 }
 const order=Array.from({length:n},(_,i)=>i).sort((a,b)=>A[a][a]-A[b][b]),values=order.map(i=>A[i][i]),vectors=order.map(i=>V.map(row=>row[i]));
 let residual=0;for(let k=0;k<n;k++)for(let i=0;i<n;i++)residual=Math.max(residual,Math.abs(dot(matrix[i],vectors[k])-values[k]*vectors[k][i]));
 return {values,vectors,residual,rotations};
}
function context(H){
 validateH(H);const offset=H.reduce((s,row,i)=>s+row[i][0],0)/8,centered=H.map((r,i)=>r.map((z,j)=>[z[0]-(i===j?offset:0),z[1]]));let calls=0;
 const state=theta=>{calls++;return actualState(ansatz(theta)).state;};
 return {offset,centered,state,calls:()=>calls};
}
function derivatives(ctx,theta,withHessian=true){
 const p=ctx.state(theta),n2=realInner(p,p),hp=mv(ctx.centered,p),E=realInner(p,hp)/n2,residual=sub(hp,scale(p,E));
 const K=ctx.centered.map((r,i)=>r.map((z,j)=>[z[0]-(i===j?E:0),z[1]])),D=theta.map((_,i)=>{const t=theta.slice();t[i]+=Math.PI;return scale(ctx.state(t),.5);});
 const gradient=D.map(d=>2*realInner(d,residual)/n2);let hessian=null;
 if(withHessian){const KD=D.map(d=>mv(K,d));hessian=theta.map(()=>theta.map(()=>0));
  for(let i=0;i<theta.length;i++)for(let j=i;j<theta.length;j++){let dd;if(i===j)dd=scale(p,-.25);else{const t=theta.slice();t[i]+=Math.PI;t[j]+=Math.PI;dd=scale(ctx.state(t),.25);}hessian[i][j]=hessian[j][i]=2*(realInner(D[i],KD[j])+realInner(dd,residual))/n2;}
 }
 return {p,norm:n2,centered_energy:E,energy_ev:E+ctx.offset,residual_vector:residual,residual_ev:vectorNorm(residual)/Math.sqrt(n2),gradient,gradient_norm:norm(gradient),hessian,K,derivative_states:D};
}
export function derivativeDiagnostics(H,theta){
 const ctx=context(H),d=derivatives(ctx,theta),step=1e-5;let gradientError=0,hessianError=0,stateError=0;
 for(let i=0;i<theta.length;i++){const a=theta.slice(),b=theta.slice();a[i]+=step;b[i]-=step;const da=derivatives(ctx,a,false),db=derivatives(ctx,b,false);gradientError=Math.max(gradientError,Math.abs((da.energy_ev-db.energy_ev)/(2*step)-d.gradient[i]));for(let j=0;j<theta.length;j++)hessianError=Math.max(hessianError,Math.abs((da.gradient[j]-db.gradient[j])/(2*step)-d.hessian[j][i]));for(let k=0;k<8;k++)stateError=Math.max(stateError,Math.hypot((da.p[k][0]-db.p[k][0])/(2*step)-d.derivative_states[i][k][0],(da.p[k][1]-db.p[k][1])/(2*step)-d.derivative_states[i][k][1]));}
 const eig=symmetricEigen(d.hessian);
 return {gradient_error:gradientError,hessian_error:hessianError,state_derivative_error:stateError,hessian_eigen_residual:eig.residual,gradient_norm:d.gradient_norm,hessian_min:eig.values[0],hessian_max:eig.values.at(-1),calls:ctx.calls()};
}
export function refineNewton(H,initial,cfg){
 if(initial.length!==18||!initial.every(Number.isFinite))throw Error('18 finite parameters required');
 const ctx=context(H);let theta=initial.slice(),reason='iteration_budget';const history=[];
 for(let iteration=0;iteration<cfg.max_iterations;iteration++){
  const d=derivatives(ctx,theta),eig=symmetricEigen(d.hessian),floor=Math.max(cfg.absolute_curvature_floor,cfg.relative_curvature_floor*Math.max(...eig.values.map(Math.abs))),minimum=eig.values[0];
  if(eig.residual>1e-9)throw Error('Parameter Hessian solve inaccurate');
  if(d.gradient_norm<=cfg.gradient_tolerance&&minimum>=-cfg.negative_curvature_tolerance){reason='gradient_and_curvature_tolerance';break;}
  let direction=Array(18).fill(0),mode='damped_newton',damping=Math.max(0,-minimum+floor);
  if(d.gradient_norm<=cfg.gradient_tolerance&&minimum<-cfg.negative_curvature_tolerance){direction=eig.vectors[0].slice();mode='negative_curvature_escape';}
  else for(let k=0;k<18;k++){const lambda=eig.values[k]+damping;if(lambda<floor)continue;const coefficient=-dot(eig.vectors[k],d.gradient)/lambda;for(let j=0;j<18;j++)direction[j]+=coefficient*eig.vectors[k][j];}
  if(!direction.every(Number.isFinite)||norm(direction)===0){direction=d.gradient.map(v=>-v);mode='gradient_fallback';}
  const length=norm(direction);if(length>cfg.maximum_step_norm)direction=direction.map(v=>v*cfg.maximum_step_norm/length);
  const signs=mode==='negative_curvature_escape'?[1,-1]:[1];let best=null;
  for(const sign of signs){const p=direction.map(v=>v*sign),slope=dot(d.gradient,p);for(let backtrack=0;backtrack<cfg.line_search_steps;backtrack++){
   const alpha=2**(-backtrack),next=theta.map((v,i)=>v+alpha*p[i]),np=ctx.state(next),delta=sub(np,d.p),change=(2*realInner(delta,d.residual_vector)+realInner(delta,mv(d.K,delta)))/realInner(np,np);
   const sufficient=mode==='negative_curvature_escape'?change<-cfg.energy_roundoff_allowance:change<=cfg.armijo*alpha*slope+cfg.energy_roundoff_allowance;
   if(sufficient&&(!best||change<best.change)){best={next,change,alpha,backtrack,mode};break;}
  }}
  if(!best){reason='line_search_exhausted';break;}
  history.push({iteration:iteration+1,energy_ev:d.energy_ev,gradient_norm:d.gradient_norm,residual_ev:d.residual_ev,minimum_parameter_curvature:minimum,maximum_parameter_curvature:eig.values.at(-1),floor,damping,step_scale:best.alpha,predicted_energy_change_ev:best.change,mode:best.mode});
  theta=best.next;
 }
 const final=derivatives(ctx,theta,false);
 return {parameters:theta,amplitudes:final.p,energy_ev:final.energy_ev,norm:final.norm,residual_ev:final.residual_ev,gradient_norm:final.gradient_norm,iterations:history.length,reason,state_evaluations:ctx.calls(),history,method:'Exact Q8 parameter derivatives and damped Newton; no Hamiltonian reference eigensolution'};
}

