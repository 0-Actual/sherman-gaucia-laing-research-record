import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {fileURLToPath} from 'node:url';import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),mirror=root.toLowerCase().startsWith('d:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_03':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_03';
export const read=rel=>JSON.parse(fs.readFileSync(path.join(root,rel),'utf8'));
export function createRun(label){
 if(!/^[a-z0-9_-]{1,60}$/.test(label))throw Error('Invalid run label');const dirs=[root,mirror].map(r=>path.join(r,'runs',label));for(const d of dirs)fs.mkdirSync(d);
 const started=performance.now(),cpu=process.cpuUsage(),at=new Date().toISOString();let peak=process.memoryUsage().rss;
 const save=(file,data)=>{const b=Buffer.from(JSON.stringify(data,null,2)+'\n');for(const d of dirs){fs.writeFileSync(path.join(d,file),b,{flag:'wx'});if(!b.equals(fs.readFileSync(path.join(d,file))))throw Error('Run mirror mismatch');}};
 const log=(stage,fields={})=>{peak=Math.max(peak,process.memoryUsage().rss);const e={at_utc:new Date().toISOString(),stage,...fields};for(const d of dirs)fs.appendFileSync(path.join(d,'events.ndjson'),JSON.stringify(e)+'\n');console.log(JSON.stringify(e));};
 const sources=['jobs/private-check-core.mjs','jobs/private-check.mjs','numerics/newton.mjs','numerics/candidate.mjs','numerics/baseline.mjs','numerics/runtime-v6.mjs','numerics/acceptance.mjs','numerics/conditioned.mjs','numerics/bracketed.mjs','numerics/hybrid.mjs','numerics/vendor/quantum.mjs','numerics/vendor/vendor/qel60_sop.mjs',path.relative(root,process.argv[1])],ids=sources.map(f=>({file:f,identity:hashBytes(fs.readFileSync(path.join(root,f)),'qel-numerical-source')}));
 save('sources.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',files:ids});
 const finish=()=>{for(const r of ids)if(hashBytes(fs.readFileSync(path.join(root,r.file)),'qel-numerical-source')!==r.identity)throw Error('Numerical source changed during job');save('execution.json',{started_utc:at,finished_utc:new Date().toISOString(),elapsed_ms:performance.now()-started,cpu_microseconds:process.cpuUsage(cpu),sampled_maximum_rss_bytes:Math.max(peak,process.memoryUsage().rss),source_unchanged:true,mirrored:true});};
 return {save,log,finish,fail:e=>{save('failure.json',{error:String(e),stack:e.stack});console.error(e);process.exitCode=1;}};
}
export async function modules(){
 const base=path.join(root,'numerics'),allow=new Set(['acceptance.mjs','conditioned.mjs','bracketed.mjs','hybrid.mjs','newton.mjs','candidate.mjs','baseline.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']),cache=new Map(),context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}});
 async function load(rel){if(!allow.has(rel))throw Error('Import outside numerical allowlist');if(cache.has(rel))return cache.get(rel);const m=new vm.SourceTextModule(fs.readFileSync(path.join(base,rel),'utf8'),{context,identifier:rel});cache.set(rel,m);await m.link((s,p)=>{if(!s.startsWith('./'))throw Error('Nonlocal numerical import');return load(path.posix.normalize(path.posix.join(path.posix.dirname(p.identifier),s)));});return m;}
 const n=await load('newton.mjs');await n.evaluate({timeout:5000});const c=await load('candidate.mjs');await c.evaluate({timeout:5000});
 const h=await load('hybrid.mjs');await h.evaluate({timeout:5000});
 const g=await load('bracketed.mjs');await g.evaluate({timeout:5000});
 const cg=await load('conditioned.mjs');await cg.evaluate({timeout:5000});
 const a=await load('acceptance.mjs');await a.evaluate({timeout:5000});
 const bindings=vm.runInContext('({process:typeof process,require:typeof require,fetch:typeof fetch,WebSocket:typeof WebSocket})',context);if(Object.values(bindings).some(x=>x!=='undefined'))throw Error('Unexpected host binding');
 return {a:a.namespace,cg:cg.namespace,g:g.namespace,h:h.namespace,n:n.namespace,c:c.namespace,b:cache.get('baseline.mjs').namespace,containment:{bindings,imports:[...allow],code_generation_disabled:true,os_network_isolation:false}};
}
export function overlap(col,p){let re=0,im=0;for(let j=0;j<p.length;j++){re+=col[j][0]*p[j][0]+col[j][1]*p[j][1];im+=col[j][0]*p[j][1]-col[j][1]*p[j][0];}return re*re+im*im;}

