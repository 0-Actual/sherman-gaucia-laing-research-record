// Scientific acceptance is a conjunction of independently measured properties.
export const defaults=Object.freeze({energy_goal_ev:1e-6,fidelity_goal:0.9999,energy_roundoff_ev:1e-8,norm_error:2e-10,amplitude_error:2e-10,dense_energy_error_ev:1e-9,fidelity_roundoff:1e-10});
export function assessState(m,overrides={}) {
  const cfg={...defaults,...overrides},required=['energy_error_ev','fidelity','norm_error','amplitude_error','dense_energy_error_ev'];
  if(!Object.values(cfg).every(v=>Number.isFinite(v)&&v>=0)||cfg.fidelity_goal>1)throw Error('Invalid scientific acceptance thresholds');
  if(!m||typeof m!=='object')return {accepted:false,status:'INSUFFICIENT_EVIDENCE',reasons:['MEASUREMENT_REQUIRED']};
  const missing=required.filter(key=>m[key]===undefined||m[key]===null);
  if(missing.length)return {accepted:false,status:'INSUFFICIENT_EVIDENCE',reasons:missing.map(x=>'MISSING_'+x.toUpperCase())};
  const invalid=required.filter(key=>!Number.isFinite(m[key]));
  const reasons=invalid.map(x=>'NONFINITE_'+x.toUpperCase());
  if(m.reference_verified!==true)reasons.push('REFERENCE_NOT_VERIFIED');
  if(m.energy_error_ev < -cfg.energy_roundoff_ev)reasons.push('ENERGY_BELOW_REFERENCE_TOLERANCE');
  if(m.energy_error_ev > cfg.energy_goal_ev)reasons.push('ENERGY_TARGET_MISSED');
  if(m.fidelity < cfg.fidelity_goal)reasons.push('GROUND_SUBSPACE_FIDELITY_MISSED');
  if(m.fidelity < -cfg.fidelity_roundoff||m.fidelity>1+cfg.fidelity_roundoff)reasons.push('FIDELITY_OUT_OF_RANGE');
  for(const key of ['norm_error','amplitude_error','dense_energy_error_ev'])if(m[key]<0||m[key]>cfg[key])reasons.push(key.toUpperCase()+'_OUT_OF_TOLERANCE');
  return {accepted:reasons.length===0,status:reasons.length?'FAIL':'PASS',reasons,energy_pass:Number.isFinite(m.energy_error_ev)&&m.energy_error_ev>=-cfg.energy_roundoff_ev&&m.energy_error_ev<=cfg.energy_goal_ev,fidelity_pass:Number.isFinite(m.fidelity)&&m.fidelity>=cfg.fidelity_goal&&m.fidelity<=1+cfg.fidelity_roundoff};
}
export function energyFidelityLowerBound({energy_error_upper_ev,gap_lower_ev}) {
  if(!Number.isFinite(energy_error_upper_ev)||energy_error_upper_ev<0||!Number.isFinite(gap_lower_ev)||gap_lower_ev<=0)return {available:false,reason:'Valid upper energy error and positive lower spectral gap required'};
  return {available:true,lower_bound:Math.max(0,1-energy_error_upper_ev/gap_lower_ev),assumption:'Caller must supply justified one-sided error and gap bounds; raw floating-point estimates are not interval certificates.'};
}
