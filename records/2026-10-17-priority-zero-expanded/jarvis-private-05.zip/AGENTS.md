# Private work continuity — Sherman G. Laing / GAUCIA

This folder implements the owner's current instruction to continue substantive work for the authorized work period and explain it directly in chat. Earlier checkpoints are evidence, not permission to end the session.

- Follow the latest owner direction before this local policy.
- Before changing numerical algorithms, verify the workflow-control regression and concurrency results.
- Keep work local to the laptop and USB. Do not publish to GitHub.
- Keep first and second pass evidence unchanged.
- Inspect LIVE_STATUS.json and the ledger before any final handoff. A completed job or saved report is not completion of the authorized session.
- Continue meaningful queued research after checkpoints. An empty queue is a planning requirement, not success. Do not pad elapsed time with idle polling or repeated tests that answer no unresolved question.
- Distinguish controller uptime, actual numerical job time, and elapsed wall time. Never claim that an idle process is doing scientific work.
- Do not call the whole task complete while required objectives, execution checks, or the substantial in-chat explanation remain outstanding.
- Explain tests, measured results, achievements, learning, code changes, unresolved limits, and costs directly in chat. File links supplement that explanation.
- The report validator checks structure and evidence references. It cannot judge all prose semantics or verify actual chat delivery; the assistant remains responsible for the explanation.
- A controller block, disconnection, stale lock, or failed test must remain explicit and checkpointed. Preserve attempts and resume safely.
- No owner signatures are fabricated. SGL Prime fingerprints remain unsigned consistency evidence.
- The local controller cannot rewrite the assistant's model, change platform behavior, or guarantee all future conversations. Do not make that claim.

