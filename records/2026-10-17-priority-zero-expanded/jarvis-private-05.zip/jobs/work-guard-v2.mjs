// Project work-completion gate. No numerical algorithms or previous evidence are changed.
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
export function validateContract(c){
 assert(c?.schema==='qel-work-session-v1','Unsupported contract');
 assert(Number.isSafeInteger(c.minimum_window_ms)&&c.minimum_window_ms>0,'Positive finite work window required');
 assert(Array.isArray(c.goals)&&c.goals.length>0,'Goals required');
 assert(new Set(c.goals.map(g=>g.id)).size===c.goals.length,'Duplicate goals');
 assert(c.goals.every(g=>/^[a-z0-9_]+$/.test(g.id)&&typeof g.required==='boolean'),'Malformed goal');
 assert(Array.isArray(c.required_report_sections)&&c.required_report_sections.length>=7,'Detailed report sections required');
 assert(c.checkpoint_is_completion===false&&c.automatic_chat_delivery_available===false,'Checkpoint or delivery misrepresentation');
 return c;
}
export function initialState(c,startedMs){
 validateContract(c);assert(Number.isFinite(startedMs),'Start time required');
 return {started_ms:startedMs,last_observed_ms:startedMs,clock_rollback:false,jobs:{},goals:Object.fromEntries(c.goals.map(g=>[g.id,{passed:false,evidence:[]} ])),checkpoints:[],evidence_audit:false,report:null,interrupted:false,owner_pause:false,productive_job_ms:0,observed_session_ms:0,events:0};
}
export function applyEvent(c,prior,event){return applyEventInPlace(c,structuredClone(prior),event);}
export function applyEventInPlace(c,s,event){
 assert(Number.isFinite(event.at_ms),'Event time required');
 if(event.at_ms<s.last_observed_ms)s.clock_rollback=true;s.last_observed_ms=Math.max(s.last_observed_ms,event.at_ms);
 const d=event.data||{};const active=()=>Object.values(s.jobs).filter(j=>j.status==='RUNNING');
 switch(event.type){
 case 'SESSION_PROGRESS':
  assert(Number.isFinite(d.elapsed_ms)&&d.elapsed_ms>=0&&d.elapsed_ms<=65000,'Bounded monotonic progress required');s.observed_session_ms+=d.elapsed_ms;break;
 case 'JOB_REGISTERED':
  assert(/^[a-z0-9_-]{1,60}$/.test(d.id)&&!s.jobs[d.id],'Unique job id required');
  assert(typeof d.purpose==='string'&&d.purpose.length>=20,'Meaningful job purpose required');
  s.jobs[d.id]={...d,status:'PENDING'};s.evidence_audit=false;s.report=null;break;
 case 'JOB_STARTED':
  assert(s.jobs[d.id]?.status==='PENDING'&&active().length===0,'Only one pending job may start');
  assert(!s.owner_pause&&!s.interrupted,'Resume required');
  s.jobs[d.id].status='RUNNING';s.jobs[d.id].started_ms=event.at_ms;break;
 case 'JOB_FINISHED':
  assert(s.jobs[d.id]?.status==='RUNNING','Job is not active');
  assert(d.exit_code===0&&d.bytes_verified===true&&Number.isFinite(d.elapsed_ms)&&d.elapsed_ms>=0,'Successful verified job result required');
  assert(Array.isArray(d.artifacts)&&d.artifacts.length>0,'Result evidence required');
  Object.assign(s.jobs[d.id],d,{status:'FINISHED'});s.productive_job_ms+=d.elapsed_ms;s.evidence_audit=false;s.report=null;break;
 case 'JOB_FAILED':
  assert(s.jobs[d.id]?.status==='RUNNING','Job is not active');Object.assign(s.jobs[d.id],d,{status:'FAILED'});s.interrupted=true;break;
 case 'GOAL_MEASURED':
  assert(s.goals[d.id]&&typeof d.passed==='boolean','Known goal and explicit boolean required');
  assert(Array.isArray(d.evidence)&&d.evidence.length>0&&d.evidence.every(x=>typeof x==='string'&&x.length>0),'Goal evidence required');
  s.goals[d.id]={passed:d.passed,evidence:d.evidence,metrics:d.metrics||{}};s.evidence_audit=false;s.report=null;break;
 case 'CHECKPOINT':
  assert(typeof d.evidence==='string'&&d.evidence.length>0,'Checkpoint evidence required');s.checkpoints.push(d.evidence);break;
 case 'AUDIT':
  assert(typeof d.passed==='boolean','Audit boolean required');s.evidence_audit=d.passed;break;
 case 'REPORT_PREPARED':
  validateReport(c,d.report);s.report=d.report;break;
 case 'INTERRUPTED': s.interrupted=true;break;
 case 'RESUMED':
  assert(active().length===0,'An active job must be reconciled first');s.interrupted=false;s.owner_pause=false;break;
 case 'OWNER_PAUSE':s.owner_pause=true;break;
 case 'CLOCK_RECONCILED':
  assert(d.reviewed===true&&typeof d.evidence==='string'&&d.evidence.length>0,'Clock reconciliation evidence required');s.clock_rollback=false;break;
 default:throw Error('Unrecognized event: '+event.type);
 }
 s.events++;return s;
}
export function validateReport(c,r){
 assert(r&&r.channel==='chat'&&r.kind==='substantive_explanation','In-chat explanation required');
 for(const key of c.required_report_sections){const x=r.sections?.[key];assert(x&&typeof x.explanation==='string'&&x.explanation.trim().split(/\s+/).length>=25,'Insufficient explanation: '+key);assert(Array.isArray(x.evidence)&&x.evidence.length>0,'Evidence required: '+key);}
 assert(r.sections.measured_results.metrics&&Object.keys(r.sections.measured_results.metrics).length>=3,'Measured metrics required');
 assert(r.delivery_status==='PREPARED_NOT_DELIVERED','File creation is not chat delivery');
 return true;
}
export function completionGate(c,s,now){
 const reasons=[];if(!Number.isFinite(now)||now<s.last_observed_ms||s.clock_rollback)reasons.push('CLOCK_REQUIRES_REVIEW');
 const elapsed=Math.max(0,now-s.started_ms);
 if(elapsed<c.minimum_window_ms||s.observed_session_ms<c.minimum_window_ms)reasons.push('AUTHORIZED_WORK_WINDOW_REMAINS');
 if(Object.values(s.jobs).some(j=>j.status==='RUNNING'))reasons.push('JOB_RUNNING');
 if(Object.values(s.jobs).some(j=>j.status==='PENDING'))reasons.push('WORK_QUEUED');
 if(s.interrupted)reasons.push('INTERRUPTION_REQUIRES_RESUME');
 const unmet=c.goals.filter(g=>g.required&&!s.goals[g.id]?.passed).map(g=>g.id);if(unmet.length)reasons.push('REQUIRED_GOALS_UNRESOLVED');
 if(!s.evidence_audit)reasons.push('EVIDENCE_AUDIT_REQUIRED');
 if(!s.report)reasons.push('SUBSTANTIVE_CHAT_EXPLANATION_REQUIRED');
 if(s.owner_pause)reasons.push('OWNER_PAUSED');
 const ready=reasons.length===0;
 return {state:s.owner_pause?'OWNER_PAUSED':s.interrupted?'BLOCKED_REQUIRES_ATTENTION':ready?'READY_FOR_CHAT_REPORT':Object.values(s.jobs).some(j=>j.status==='RUNNING')?'WORKING':'CONTINUE_OR_PLAN_NEXT_WORK',can_declare_task_complete:false,can_prepare_final_handoff:ready,chat_delivery_verified:false,elapsed_window_ms:elapsed,observed_controller_ms:s.observed_session_ms,remaining_window_ms:Math.max(0,c.minimum_window_ms-Math.min(elapsed,s.observed_session_ms)),recorded_numerical_job_ms:s.productive_job_ms,unresolved_goals:unmet,reasons,warning:'Local code controls local workflow transitions. It cannot guarantee future assistant behavior or verify a chat message was delivered.'};
}

