export function referenceFidelity(p,ref){
 if(ref.kind==='known_basis')return ref.columns.slice(0,ref.dimension).reduce((sum,col)=>{let re=0,im=0;for(let i=0;i<8;i++){re+=col[i][0]*p[i][0]+col[i][1]*p[i][1];im+=col[i][0]*p[i][1]-col[i][1]*p[i][0];}return sum+re*re+im*im;},0);
 const v=p.map(z=>z[0]).concat(p.map(z=>z[1]));return ref.real_vectors.slice(0,2*ref.dimension).reduce((sum,col)=>sum+col.reduce((s,x,i)=>s+x*v[i],0)**2,0);
}
export function score(m,H,prediction,reference){
 const p=prediction.amplitudes,E=m.b.independentEnergy(H,p),fidelity=referenceFidelity(p,reference),norm=p.reduce((sum,z)=>sum+z[0]*z[0]+z[1]*z[1],0);
 const error=E-reference.energy_ev,reportedDifference=Math.abs(E-(prediction.energy_ev??prediction.final_energy_ev));
 if(prediction.parameters){const diag=m.c.stateDiagnostics(H,prediction.parameters),amplitudeError=Math.max(...p.map((z,i)=>Math.hypot(z[0]-diag.amplitudes[i][0],z[1]-diag.amplitudes[i][1])));
  const measurement={energy_error_ev:error,fidelity,norm_error:Math.abs(norm-1),amplitude_error:Math.max(amplitudeError,diag.max_amplitude_error),dense_energy_error_ev:Math.max(diag.dense_energy_error_ev,Math.abs(E-diag.energy_ev)),reference_verified:reference.residual<=1e-9&&reportedDifference<=1e-9},assessment=m.a.assessState(measurement);
  return {...assessment,measurement,energy_ev:E,circuit_verified:true};
 }
 const measurement={energy_error_ev:error,fidelity,norm_error:Math.abs(norm-1),reported_energy_error_ev:reportedDifference,residual_ev:prediction.residual_ev};
 const accepted=Object.values(measurement).every(Number.isFinite)&&error>=-1e-9&&error<=1e-6&&fidelity>=.9999&&fidelity<=1+1e-9&&Math.abs(norm-1)<=1e-9&&reportedDifference<=1e-9&&prediction.residual_ev<=1e-9&&reference.residual<=1e-9;
 return {accepted,status:accepted?'PASS':'FAIL',measurement,energy_ev:E,circuit_verified:false,scope:'Direct classical state answer; no circuit parameters requested or produced.'};
}
export function directSolve(m,H){
 const offset=H.reduce((s,r,i)=>s+r[i][0]/8,0),center=H.map((r,i)=>r.map((z,j)=>[z[0]-(i===j?offset:0),z[1]])),scale=Math.max(...center.map(r=>r.reduce((s,z)=>s+Math.hypot(...z),0)))||1;
 const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=center[i%8][j%8];return (i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]))/scale;})),e=m.n.symmetricEigen(A),p=Array.from({length:8},(_,i)=>[e.vectors[0][i],e.vectors[0][i+8]]);
 return {amplitudes:p,energy_ev:m.b.energy(H,p),residual_ev:e.residual*scale,method:'Existing direct symmetric Jacobi solver on real embedding of centered complex Hermitian matrix',external_reference_used:false};
}
