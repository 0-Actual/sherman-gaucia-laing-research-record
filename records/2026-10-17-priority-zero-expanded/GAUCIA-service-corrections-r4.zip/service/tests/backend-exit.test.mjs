import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {Backend} from '../backend.mjs';
import {Backend as Before} from '../../baseline/backend-before-exit-confirmation.mjs';

function fixture(Cls=Backend,log=()=>{}){
  const b=new Cls('unused',{backendPort:17778},log);
  const child=new EventEmitter();child.pid=42;child.exitCode=null;child.signalCode=null;
  child.killCalls=0;child.kill=()=>{child.killCalls++;return true;};
  b.child=child;b.ready=true;return{b,child};
}
test('baseline reproduces false stopped state while the child has not exited',()=>{
  const {b,child}=fixture(Before);b.stop();
  assert.equal(child.exitCode,null);assert.equal(child.signalCode,null);
  assert.equal(b.status().state,'stopped');assert.equal(b.child,null);
});
test('baseline also discards a child that refuses the stop signal',()=>{
  const {b,child}=fixture(Before);child.kill=()=>false;b.stop();assert.equal(b.child,null);
});
test('successful signal stays pending until exit and prevents another start',async()=>{
  const events=[];const {b,child}=fixture(Backend,k=>events.push(k));
  const pending=b.stop();assert.equal(b.child,child);assert.equal(b.status().state,'stopping');assert.equal(events.length,0);
  await assert.rejects(b.start(),/shutdown is still pending/);
  child.emit('exit',0,null);await pending;
  assert.equal(b.child,null);assert.equal(b.status().state,'stopped');assert.deepEqual(events,['language.stop']);
});
test('a refused signal rejects and retains process ownership',async()=>{
  const {b,child}=fixture();child.kill=()=>false;
  await assert.rejects(b.stop(),/rejected the stop signal/);assert.equal(b.child,child);
});
test('a thrown stop error rejects and retains the child',async()=>{
  const {b,child}=fixture();child.kill=()=>{throw Error('stop denied');};
  await assert.rejects(b.stop(),/stop denied/);assert.equal(b.child,child);
});
test('timeout retains ownership and a later attempt can confirm exit',async()=>{
  const {b,child}=fixture();await assert.rejects(b.stop({timeoutMs:5}),/exit was not confirmed/);
  assert.equal(b.child,child);await assert.rejects(b.start(),/not been confirmed stopped/);
  const retry=b.stop();child.emit('exit',0,null);await retry;assert.equal(b.child,null);
});
test('overlapping callers share one stop operation and clean listeners',async()=>{
  const {b,child}=fixture();const one=b.stop(),two=b.stop();assert.equal(one,two);assert.equal(child.killCalls,1);
  child.emit('exit',0,null);await Promise.all([one,two]);assert.equal(child.listenerCount('exit'),0);assert.equal(child.listenerCount('error'),0);
});
test('async process error rejects without losing the child',async()=>{
  const {b,child}=fixture();const pending=b.stop();child.emit('error',Error('process failure'));
  await assert.rejects(pending,/process failure/);assert.equal(b.child,child);
});
test('already exited child needs no additional termination request',async()=>{
  const {b,child}=fixture();child.exitCode=0;await b.stop();assert.equal(child.killCalls,0);assert.equal(b.child,null);
});
test('logging failure remains a warning after confirmed exit',async()=>{
  const {b,child}=fixture(Backend,()=>{throw Error('disk unavailable');});const pending=b.stop();child.emit('exit',0,null);await pending;
  assert.equal(b.child,null);assert.match(b.status().stopWarning,/disk unavailable/);
});
test('synchronous exit during kill is observed',async()=>{
  const {b,child}=fixture();child.kill=()=>{child.emit('exit',0,null);return true;};await b.stop();assert.equal(b.child,null);
});
