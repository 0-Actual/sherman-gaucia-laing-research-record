import test from 'node:test';
import assert from 'node:assert/strict';
import {EventEmitter} from 'node:events';
import {Backend} from '../backend.mjs';
function childWith(kill){const c=new EventEmitter();c.pid=42;c.exitCode=null;c.signalCode=null;c.kill=kill;return c;}
test('a stop-log failure remains visible after confirmed exit',async()=>{
 const b=new Backend('unused',{backendPort:17778},()=>{throw Error('disk unavailable');});
 const c=childWith(()=>true);b.child=c;b.ready=true;const stopping=b.stop();c.emit('exit',0,null);await stopping;
 assert.equal(b.child,null);assert.equal(b.ready,false);assert.match(b.status().stopWarning,/disk unavailable/);
});
test('a failed process stop is not disguised as successful cleanup',async()=>{
 const b=new Backend('unused',{backendPort:17778},()=>{});const c=childWith(()=>{throw Error('process stop denied');});
 b.child=c;b.ready=true;await assert.rejects(b.stop(),/process stop denied/);assert.equal(b.child,c);assert.equal(b.ready,true);
});
