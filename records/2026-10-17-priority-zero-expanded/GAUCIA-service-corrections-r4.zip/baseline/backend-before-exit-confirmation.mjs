import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {randomBytes} from 'node:crypto';
import {redactTemplate} from './core.mjs';
function qelRequireSecurityRelease() {
  try { fs.lstatSync('./REDACTED_LOCAL_ROOT/QEL_Q7/SECURITY_ONLY_HOLD.json'); } catch (e) { if (e.code === 'ENOENT') return; throw Error('QEL_SECURITY_ONLY_HOLD: hold inspection failed.'); }
  throw Error('QEL_SECURITY_ONLY_HOLD: language work is paused.');
}
const delay=ms=>new Promise(r=>setTimeout(r,ms));
export class Backend {
  constructor(root,config,log){this.root=root;this.config=config;this.log=log;this.child=null;this.ready=false;this.starting=null;this.key=randomBytes(32).toString('hex');this.lastError=null;this.port=config.backendPort;this.lastUse=0;}
  url(route){if(!route.startsWith('/')||route.includes('://'))throw Error('Local route required');return `http://127.0.0.1:${this.port}${route}`;}
  async request(route,body,signal){return fetch(this.url(route),{method:body===undefined?'GET':'POST',redirect:'error',headers:{'Content-Type':'application/json',Authorization:'Bearer '+this.key},body:body===undefined?undefined:JSON.stringify(body),signal:signal||AbortSignal.timeout(5000)});}
  status(){return {state:this.ready?'ready':this.starting?'loading':this.lastError?'error':'stopped',pid:this.child?.pid||null,model:this.config.modelLabel,modelFile:this.config.model,context:this.config.context,threads:this.config.threads,lastError:this.lastError,stopWarning:this.lastStopWarning||null,network:'loopback only; offline model mode'};}
  async start(){
    if(this.ready&&this.child)return;
    if(this.starting)return this.starting;
    this.starting=this._start();try{return await this.starting;}catch(e){this.lastError=e.message;throw e;}finally{this.starting=null;}
  }
  async _start(){
    qelRequireSecurityRelease();
    this.lastError=null;
    const exe=path.resolve(this.root,this.config.llama),model=path.resolve(this.root,this.config.model);
    if(!fs.existsSync(exe)||!fs.existsSync(model))throw Error('USB language runtime/model not found');
    if(os.freemem()<128*1024**2)throw Error('Local free RAM below 128 MiB; model was not started. Library and quantum tools remain available.');
    const output=fs.openSync(path.join(this.root,'logs',`language-${Date.now()}.log`),'a');
    const args=['-m',model,'--host','127.0.0.1','--port',String(this.port),'--api-key',this.key,'--no-ui','--offline','--device','none','--reasoning','off','--no-warmup','-np','1','-c',String(this.config.context),'-b','32','-ub','32','-t',String(this.config.threads),'--threads-http','2','--prio','-1','--poll','0','--fit','off'];
    this.log('language.start',{model:this.config.modelLabel,host:'127.0.0.1',port:this.port,freeRam:os.freemem()});
    this.child=spawn(exe,args,{cwd:this.root,windowsHide:true,stdio:['ignore',output,output],env:{...process.env,HF_HUB_OFFLINE:'1',TRANSFORMERS_OFFLINE:'1',HF_HUB_DISABLE_TELEMETRY:'1'}});
    fs.closeSync(output);let spawnError=null;
    const ownedChild=this.child;
    this.child.on('error',e=>{spawnError=e;this.lastError=e.message;this.ready=false;});
    this.child.on('exit',(code)=>{if(this.child===ownedChild){this.ready=false;this.child=null;if(code&&code!==0)this.lastError='Language process exited '+code;}});
    const start=Date.now();
    while(Date.now()-start<240000){
      if(spawnError)throw spawnError;
      if(!this.child)throw Error(this.lastError||'Language process stopped while loading; inspect USB logs');
      try{const r=await this.request('/health');if(r.ok){this.ready=true;this.lastUse=Date.now();this.log('language.ready',{pid:this.child.pid,loadMs:Date.now()-start});return;}}catch{}
      await delay(1200);
    }
    this.stop();throw Error('Local language loading timed out; input remains saved.');
  }
  stop(){if(this.child){this.child.kill();this.child=null;}this.ready=false;this.lastStopWarning=null;try{this.log('language.stop',{});}catch(e){this.lastStopWarning='Language stop log could not be recorded: '+e.message;}}
  // The caller saves input before invoking this method. Only optional older
  // messages and separately supplied archive material may be omitted to fit.
  async generate(messages,onToken=()=>{},signal,options={}){
    qelRequireSecurityRelease();
    let stage='validation',promptTokens=null,generationRequested=false;
    let safeMessages=[],corePolicy='',archive='',archiveIncluded=false;
    let content='',notice='',metrics=null,finishReason=null,terminalMarker=false;
    const omitted={historyMessages:0,historyUserMessages:0,historyAssistantMessages:0,archivePassages:0,archiveCharacters:0};
    const redactedCharacters={corePolicy:0,latestUserMessage:0,history:0,archive:0};
    let archiveContext='',archivePassages=0,onContext=()=>{},onOutcome=()=>{};
    const budget=this.config.context-280;
    const fail=(code,message,status='error')=>Object.assign(Error(message),{code,status});
    const checkAbort=()=>{
      if(signal?.aborted)throw fail('LOCAL_CANCELLED','Response stopped. Your message and any partial answer remain saved.','stopped');
    };
    const contextInfo=()=>({
      promptTokens,contextLimit:this.config.context,promptBudget:budget,generationRequested,
      shortened:omitted.historyMessages>0||omitted.archiveCharacters>0,
      omitted:{...omitted},notice,latestUserMessageTruncated:false,corePolicyTruncated:false,
      latestUserInputCharacters:Array.isArray(messages)?messages.at(-1)?.content?.length??null:null,
      latestUserPreparedCharacters:safeMessages.at(-1)?.content?.length??null,
      corePolicyInputCharacters:Array.isArray(messages)?messages[0]?.content?.length??null:null,
      corePolicyPreparedCharacters:corePolicy.length,
      archiveInputCharacters:typeof archiveContext==='string'?archiveContext.length:null,archivePreparedCharacters:archive.length,
      redaction:'Existing template-control token removal only; character counts use JavaScript UTF-16 code units.',
      redactedCharacters:{...redactedCharacters},
    });
    const outcomeInfo=(status,code=null)=>({status,code,stage,finishReason,terminalMarker,generationRequested,partial:status!=='complete'&&content.length>0,modelContentCharacters:content.length});
    const notify=(callback,value)=>{
      try{callback(value);}catch(cause){const error=fail('LOCAL_CALLBACK_FAILED','The local response could not be recorded by its caller.');error.cause=cause;throw error;}
    };
    try{
      if(!Array.isArray(messages)||messages.length<2||messages[0]?.role!=='system'||messages.at(-1)?.role!=='user'||messages.some((m,i)=>typeof m?.content!=='string'||(i>0&&!['user','assistant'].includes(m.role))))throw fail('LOCAL_INVALID_INPUT','Expected core system policy, optional user/assistant history, and a final user message.');
      if(!options||typeof options!=='object'||Array.isArray(options)||typeof onToken!=='function')throw fail('LOCAL_INVALID_INPUT','Invalid local response options.');
      ({archiveContext='',archivePassages=0,onContext=()=>{},onOutcome=()=>{}}=options);
      if(typeof archiveContext!=='string'||!Number.isInteger(archivePassages)||archivePassages<0||(!archiveContext&&archivePassages!==0)||typeof onContext!=='function'||typeof onOutcome!=='function')throw fail('LOCAL_INVALID_INPUT','Invalid local archive context metadata or callback.');
      if(!Number.isSafeInteger(budget)||budget<1)throw fail('LOCAL_INVALID_INPUT','Invalid local context budget.');
      checkAbort();
      safeMessages=messages.map(m=>({role:m.role,content:redactTemplate(m.content)}));
      corePolicy=safeMessages[0].content;archive=redactTemplate(archiveContext);archiveIncluded=archive.length>0;
      redactedCharacters.corePolicy=messages[0].content.length-corePolicy.length;
      redactedCharacters.latestUserMessage=messages.at(-1).content.length-safeMessages.at(-1).content.length;
      redactedCharacters.history=messages.slice(1,-1).reduce((n,m,i)=>n+m.content.length-safeMessages[i+1].content.length,0);
      redactedCharacters.archive=archiveContext.length-archive.length;
      stage='start';await this.start();checkAbort();this.lastUse=Date.now();
      // Every failed fitting iteration removes complete optional input or fails.
      // There is no retry count that could admit an oversized prompt accidentally.
      while(true){
        checkAbort();safeMessages[0].content=corePolicy+(archiveIncluded?archive:'');
        stage='template';
        const tr=await this.request('/apply-template',{messages:safeMessages.map(m=>({...m})),chat_template_kwargs:{enable_thinking:false}},signal);
        checkAbort();if(!tr.ok)throw fail('LOCAL_TEMPLATE_FAILED','Local template operation failed; your input remains saved.');
        const template=await tr.json();checkAbort();
        if(typeof template?.prompt!=='string')throw fail('LOCAL_TEMPLATE_FAILED','Local template returned no prompt; your input remains saved.');
        stage='tokenize';
        const tz=await this.request('/tokenize',{content:template.prompt,add_special:true},signal);
        checkAbort();if(!tz.ok)throw fail('LOCAL_TOKENIZE_FAILED','Local token count failed; no completion was requested.');
        const tokenized=await tz.json();checkAbort();
        if(!Array.isArray(tokenized?.tokens)||!tokenized.tokens.every(Number.isInteger))throw fail('LOCAL_TOKENIZE_FAILED','Local tokenizer returned an invalid token list; no completion was requested.');
        promptTokens=tokenized.tokens.length;
        if(promptTokens<=budget)break;
        if(safeMessages.length>2){
          const count=safeMessages.length>3&&safeMessages[1].role==='user'&&safeMessages[2].role==='assistant'?2:1;
          for(const m of safeMessages.splice(1,count)){
            omitted.historyMessages++;
            if(m.role==='user')omitted.historyUserMessages++;else omitted.historyAssistantMessages++;
          }
          continue;
        }
        if(archiveIncluded){archiveIncluded=false;omitted.archivePassages=archivePassages;omitted.archiveCharacters=archive.length;continue;}
        throw fail('LOCAL_CONTEXT_TOO_LARGE','The latest message and core policy exceed the local context budget. No response was generated and neither was shortened to fit. Your input remains saved; split it into smaller requests.');
      }
      const exclusions=[];
      if(omitted.historyMessages)exclusions.push(`${omitted.historyMessages} older message${omitted.historyMessages===1?'':'s'}`);
      if(omitted.archiveCharacters)exclusions.push(archivePassages?`${archivePassages} archive excerpt${archivePassages===1?'':'s'}`:'the archive excerpts');
      notice=exclusions.length?`Context notice: This response omits ${exclusions.join(' and ')} to fit the local model. Your latest message and core policy were not shortened to fit.\n\n`:'';
      notify(onContext,contextInfo());if(notice)notify(onToken,notice);
      checkAbort();stage='completion';generationRequested=true;
      const body={messages:safeMessages,max_tokens:240,stream:true,temperature:.7,top_p:.8,top_k:20,min_p:0,presence_penalty:1.5,chat_template_kwargs:{enable_thinking:false}};
      const r=await this.request('/v1/chat/completions',body,signal);
      checkAbort();
      if(!r.ok)throw fail('LOCAL_GENERATION_FAILED','Local generation failed: '+r.status+' '+(await r.text()).slice(0,400));
      if(!r.body||typeof r.body[Symbol.asyncIterator]!=='function')throw fail('LOCAL_STREAM_INCOMPLETE','Local response had no readable stream. Your input remains saved.','interrupted');
      stage='stream';
      let pending='',eventData=[];
      const decoder=new TextDecoder('utf-8',{fatal:true});
      const protocol=message=>fail('LOCAL_STREAM_PROTOCOL',message+' Any partial answer remains saved.');
      const dispatch=()=>{
        if(!eventData.length)return;
        const data=eventData.join('\n');eventData=[];
        if(terminalMarker)throw protocol('The local stream sent data after its terminal marker.');
        if(data.trim()==='[DONE]'){terminalMarker=true;return;}
        let part;try{part=JSON.parse(data);}catch{throw protocol('The local stream contained malformed JSON.');}
        if(!part||typeof part!=='object'||Array.isArray(part))throw protocol('The local stream contained an invalid event.');
        if(part.error){
          const detail=typeof part.error==='string'?part.error:part.error.message||JSON.stringify(part.error);
          throw fail('LOCAL_PROVIDER_ERROR','Local model error: '+String(detail).slice(0,400));
        }
        if(part.timings)metrics=part.timings;
        if(!Array.isArray(part.choices))throw protocol('The local stream omitted its choices array.');
        if(part.choices.length===0){
          if(!part.usage&&!part.timings)throw protocol('The local stream contained an empty unrecognized event.');
          return;
        }
        if(part.choices.length!==1)throw protocol('The local stream returned an unexpected number of choices.');
        const choice=part.choices[0];
        if(!choice||typeof choice!=='object'||Array.isArray(choice)||(choice.index!==undefined&&choice.index!==0))throw protocol('The local stream returned an invalid choice.');
        if(finishReason!==null)throw protocol('The local stream sent another choice after its finish reason.');
        const delta=choice.delta;
        if(!delta||typeof delta!=='object'||Array.isArray(delta))throw protocol('The local stream returned an invalid text delta.');
        if(delta.content!==undefined&&delta.content!==null&&typeof delta.content!=='string')throw protocol('The local stream returned non-text content.');
        if(typeof delta.content==='string'&&delta.content){content+=delta.content;notify(onToken,notice+content);}
        if(delta.tool_calls?.length||delta.function_call)throw fail('LOCAL_UNSUPPORTED_FINISH','The local model requested a tool operation that this text response cannot execute. The response is not marked complete.');
        if(choice.finish_reason!==undefined&&choice.finish_reason!==null){
          if(typeof choice.finish_reason!=='string'||!choice.finish_reason)throw protocol('The local stream returned an invalid finish reason.');
          finishReason=choice.finish_reason;
        }
      };
      const line=value=>{
        if(value===''){dispatch();return;}
        if(value.startsWith(':'))return; // Standard SSE keep-alive comment.
        const colon=value.indexOf(':');
        const field=colon===-1?value:value.slice(0,colon);
        let data=colon===-1?'':value.slice(colon+1);if(data.startsWith(' '))data=data.slice(1);
        if(field==='data')eventData.push(data);
        // SSE event/id/retry fields do not replace the JSON completion payload.
      };
      const drain=final=>{
        while(true){
          const match=/[\r\n]/.exec(pending);if(!match)break;
          const pos=match.index;if(pending[pos]==='\r'&&pos===pending.length-1&&!final)break;
          const width=pending[pos]==='\r'&&pending[pos+1]==='\n'?2:1;
          line(pending.slice(0,pos));pending=pending.slice(pos+width);
        }
        if(final){if(pending){line(pending);pending='';}dispatch();}
      };
      for await(const chunk of r.body){
        checkAbort();
        try{pending+=decoder.decode(chunk,{stream:true});}catch{throw protocol('The local stream contained invalid UTF-8.');}
        drain(false);
      }
      checkAbort();
      try{pending+=decoder.decode();}catch{throw protocol('The local stream ended inside invalid UTF-8.');}
      drain(true);checkAbort();
      // llama.cpp's compatible chat endpoint emits both a final finish reason
      // and [DONE]. Socket EOF alone is not proof of a completed answer.
      if(finishReason==='length')throw fail('LOCAL_OUTPUT_LIMIT','The local model reached a generation or context limit. This is a partial answer; your input and generated text remain saved.','limited');
      if(finishReason!==null&&finishReason!=='stop')throw fail('LOCAL_UNSUPPORTED_FINISH',`The local model ended with unsupported finish reason ${finishReason}. The response is not marked complete.`);
      if(!terminalMarker||finishReason!=='stop')throw fail('LOCAL_STREAM_INCOMPLETE','The local stream ended without both a normal finish reason and its terminal marker. Any partial answer remains saved.','interrupted');
      if(!content.trim())throw fail('LOCAL_EMPTY_RESPONSE','Local model returned no answer; your input remains saved.');
      stage='finished';this.lastUse=Date.now();
      const context=contextInfo(),outcome=outcomeInfo('complete');
      notify(onContext,context);notify(onOutcome,outcome);
      return {content:notice+content,metrics,context,outcome};
    }catch(cause){
      let error;
      if(signal?.aborted)error=fail('LOCAL_CANCELLED','Response stopped. Your message and any partial answer remain saved.','stopped');
      else if(cause?.code?.startsWith?.('LOCAL_'))error=cause;
      else{
        const codes={template:'LOCAL_TEMPLATE_FAILED',tokenize:'LOCAL_TOKENIZE_FAILED',stream:'LOCAL_STREAM_INTERRUPTED',start:'LOCAL_START_FAILED',completion:'LOCAL_GENERATION_FAILED'};
        error=fail(codes[stage]||'LOCAL_GENERATION_FAILED',`Local ${stage} operation failed: ${cause?.message||String(cause)}. Your input and any partial answer remain saved.`,stage==='stream'?'interrupted':'error');
      }
      if(error!==cause)error.cause=cause;
      this.lastUse=Date.now();error.content=notice+content;error.partialContent=error.content;error.metrics=metrics;error.context=contextInfo();error.outcome=outcomeInfo(error.status||'error',error.code);
      // Metadata callback failures must not erase the original failure or partial text.
      for(const [callback,value] of [[onContext,error.context],[onOutcome,error.outcome]]){
        try{if(typeof callback==='function')callback(value);}catch(reportingError){error.reportingError=reportingError.message||String(reportingError);}
      }
      throw error;
    }
  }
}
