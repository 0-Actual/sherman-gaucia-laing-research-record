# GAUCIA service correction r4 — October 17, 2026

This research correction follows the retained r3 package. Backend stop now waits
for an exit event or already-observed exit state. A failed signal, process error or
timeout retains process ownership and returns failure. Overlapping stop requests
share one operation. Model-stop and quit endpoints await this result.

Use service/backend.mjs and service/communication.mjs as the reviewed replacement
pair for r3. The remaining included service/baseline files support isolated tests.
Do not replace an installed application automatically; its current bytes and absent
audit dependencies still require integration review. No live USB/model deployment
or new complete GAUCIA installer is supplied by this archive.

From the extracted archive directory, using a current Node.js runtime:

    node --experimental-vm-modules --test --test-concurrency=1 service/tests/*.test.mjs service/recovery.test.mjs

Validation: 55 isolated tests passed. The baseline tests deliberately reproduce
the old false stopped state; they are passing counterexample tests, not operational
success claims. No model, real service listener or real child process is launched.
Existing holds and admission checks remain in the source.
The enclosing release's unchanged license and component notices apply.
