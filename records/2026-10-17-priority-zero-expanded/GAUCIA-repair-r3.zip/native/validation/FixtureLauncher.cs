using System;
using System.IO;
using System.Threading;
public static class FixtureLauncher {
 public static int Main(string[] args) {
  string mode=File.ReadAllText("fixture-mode.txt").Trim();
  File.AppendAllText("fixture-started.txt",System.Diagnostics.Process.GetCurrentProcess().Id+Environment.NewLine);
  if(mode=="hold"){Console.Error.WriteLine("QEL_SECURITY_ONLY_HOLD: fixture-only hold response.");return 73;}
  if(mode=="delayedhold"){Thread.Sleep(350);Console.Error.WriteLine("QEL_SECURITY_ONLY_HOLD: fixture-only hold response.");return 73;}
  if(mode=="shortwait"){Thread.Sleep(1500);return 0;}
  if(mode=="flood"){Console.Out.WriteLine("FIXTURE_OUTPUT_MARKER");Console.Error.WriteLine("FIXTURE_ERROR_MARKER");for(int i=0;i<2000;i++){Console.Out.WriteLine(new string('O',256));Console.Error.WriteLine(new string('E',256));}return 42;}
  if(mode=="zero")return 0;
  if(mode=="ready"){Thread.Sleep(600);return 0;}
  if(mode=="timeout"){Thread.Sleep(47000);return 0;}
  return 99;
 }
}
