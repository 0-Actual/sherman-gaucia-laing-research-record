using System;
using System.IO;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Linq;
using System.Security.Cryptography;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
public static class StartupRegressionTests {
 static readonly string Base=AppDomain.CurrentDomain.BaseDirectory;
 static readonly string RunRoot=Path.Combine(Base,"r",Guid.NewGuid().ToString("N").Substring(0,8));
 static readonly BindingFlags Private=BindingFlags.Instance|BindingFlags.NonPublic;
 static readonly JavaScriptSerializer Json=new JavaScriptSerializer();
 static int passed;static bool audited;
 sealed class FakeHandler:HttpMessageHandler {
  public Func<HttpRequestMessage,CancellationToken,Task<HttpResponseMessage>> Respond;
  public int Count,Messages,Unexpected;
  protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,CancellationToken ct){
   Count++;if(request.RequestUri.AbsolutePath!="/health")Console.WriteLine("FIXTURE request "+request.RequestUri.AbsolutePath);if(request.RequestUri.AbsolutePath=="/api/message")Messages++;
   if(request.RequestUri.Host!="127.0.0.1"||request.RequestUri.AbsolutePath.Contains("model")){Unexpected++;throw new Exception("Forbidden fixture request");}
   return Respond(request,ct);
  }
 }
 static void Check(bool okay,string reason){if(!okay)throw new Exception(reason);}
 static void Pass(string name){passed++;Console.WriteLine("PASS "+name);}
 static HttpResponseMessage Response(object body,int status=200){return new HttpResponseMessage((HttpStatusCode)status){Content=new StringContent(Json.Serialize(body))};}
 static Dictionary<string,object> Health(string root){return new Dictionary<string,object>{{"app","GAUCIA_QEL_LOCAL_PANEL"},{"ready",true},{"workspace",root}};}
 static Dictionary<string,object> Status(string root,bool ready){var status=Health(root);status["ready"]=ready;status["active"]=null;status["backend"]=new Dictionary<string,object>{{"state","offline"}};status["library"]=new Dictionary<string,object>{{"records",0}};status["freeMiB"]=100;return status;}
 static Task<HttpResponseMessage> Absent(){throw new HttpRequestException("Fixture connection refused",new SocketException(10061));}
 static string Fixture(string name,string mode,bool runtime){string root=Path.Combine(RunRoot,name,"app");Directory.CreateDirectory(Path.Combine(root,"tools"));File.WriteAllText(Path.Combine(root,"tools","start-panel.mjs"),"// local inert fixture");File.WriteAllText(Path.Combine(root,"fixture-mode.txt"),mode);if(runtime){string runtimeDir=Path.GetFullPath(Path.Combine(root,@"..\Independent_Model_20260919\runtime"));Directory.CreateDirectory(runtimeDir);File.Copy(Path.Combine(Base,"FixtureLauncher.exe"),Path.Combine(runtimeDir,"node.exe"));}return root;}
 static FieldInfo Field(string key){return typeof(GauciaWindow).GetField(key,Private);}
 static Task Call(GauciaWindow window,string method,params object[] args){return (Task)typeof(GauciaWindow).GetMethod(method,Private).Invoke(window,args);}
 static void Await(Task task){var elapsed=Stopwatch.StartNew();while(!task.IsCompleted){Application.DoEvents();Thread.Sleep(10);if(elapsed.ElapsedMilliseconds>12000)throw new Exception("Isolated fixture wait exceeded 12 seconds");}task.GetAwaiter().GetResult();}
 static string Details(GauciaWindow window){return (string)typeof(GauciaWindow).GetMethod("StartupDetailsText",Private).Invoke(window,null);}
 static GauciaWindow Window(string root,FakeHandler handler){var window=new GauciaWindow(false);Check(!window.Visible,"Form unexpectedly visible");((HttpClient)Field("http").GetValue(window)).Dispose();Field("http").SetValue(window,new HttpClient(handler));Field("root").SetValue(window,root);if(audited){var outbox=Activator.CreateInstance(typeof(GauciaWindow).Assembly.GetType("NativeOutbox"),Path.Combine(root,"data","native-outbox"));Field("outbox").SetValue(window,outbox);}return window;}
 static Exception Failure(Task task){try{Await(task);}catch(Exception error){return error;}throw new Exception("Expected failure");}
 static bool SendEnabled(GauciaWindow window){return ((Button)Field("send").GetValue(window)).Enabled;}
 static void Reap(string root){string marker=Path.Combine(root,"fixture-started.txt");if(!File.Exists(marker))return;foreach(string line in File.ReadAllLines(marker)){try{using(var process=Process.GetProcessById(int.Parse(line))){Check(process.WaitForExit(4000),"Finite fixture child did not exit");}}catch(ArgumentException){}}}
 static Dictionary<string,object> Request(){return new Dictionary<string,object>{{"id","fixture-conversation"},{"text","Exact draft\r\nשלום  "},{"kind","chat"},{"requestId",Guid.NewGuid().ToString("D")},{"createdAt",DateTime.UtcNow.ToString("o")}};}
 static object Outbox(GauciaWindow window){return Field("outbox").GetValue(window);}
 static object OutboxCall(object box,string method,params object[] args){return box.GetType().GetMethod(method).Invoke(box,args);}
 static Dictionary<string,string> Snapshot(string root){var hashes=new Dictionary<string,string>();using(var sha=SHA256.Create()){foreach(string file in Directory.GetFiles(root,"*",SearchOption.AllDirectories))hashes[file]=Convert.ToBase64String(sha.ComputeHash(File.ReadAllBytes(file)));}return hashes;}
 [STAThread] public static int Main(){WindowsFormsSynchronizationContext.AutoInstall=false;SynchronizationContext.SetSynchronizationContext(new WindowsFormsSynchronizationContext());audited=Field("outbox")!=null;
  try{
   int budget=(int)typeof(GauciaWindow).GetField("ServiceStartupBudgetMilliseconds",BindingFlags.Static|BindingFlags.NonPublic).GetRawConstantValue();Check(budget>=90000,"UI deadline is shorter than supported helper budget");
   for(int scenario=0;scenario<8;scenario++){
    string root=Fixture("identity-"+scenario,"zero",true);var body=Health(root);if(scenario==0)body["workspace"]=root.ToUpperInvariant()+"\\";if(scenario==1)body["ready"]=false;if(scenario==2)body.Remove("ready");if(scenario==3)body["ready"]="true";if(scenario==4)body["workspace"]=Path.Combine(root,"other");if(scenario==5)body.Remove("workspace");if(scenario==6)body["app"]="OTHER";
    var handler=new FakeHandler{Respond=(req,ct)=>Task.FromResult(Response(body,scenario==7?503:200))};using(var window=Window(root,handler)){if(scenario==0)Await(Call(window,"EnsureCommunicationService"));else Failure(Call(window,"EnsureCommunicationService"));Check(!File.Exists(Path.Combine(root,"fixture-started.txt")),"Unready/foreign/unknown service caused speculative launch");Check(handler.Unexpected==0,"Unexpected endpoint");}
   }Pass("ready is explicit boolean; normalized workspace matches; seven incompatible/unready cases do not launch");
   for(int scenario=0;scenario<2;scenario++){
    string root=Fixture("restricted-"+scenario,"zero",true);var handler=new FakeHandler{Respond=async(req,ct)=>{if(scenario==0)throw new HttpRequestException("Fixture access forbidden",new SocketException(10013));await Task.Delay(Timeout.Infinite,ct);return Response(Health(root));}};
    using(var window=Window(root,handler)){var elapsed=Stopwatch.StartNew();Failure(Call(window,"EnsureCommunicationService"));Check(elapsed.ElapsedMilliseconds<2000,"Unknown health did not finish probe promptly");Check(!File.Exists(Path.Combine(root,"fixture-started.txt")),"Unknown health launched a helper");}
   }Pass("access-forbidden and initial timeout are not treated as absent service");
   string holdRoot=Fixture("single-flight","delayedhold",true);var holdHandler=new FakeHandler{Respond=(req,ct)=>Absent()};
   using(var window=Window(holdRoot,holdHandler)){
    Dictionary<string,object> draft=null;if(audited){draft=Request();OutboxCall(Outbox(window),"Save",draft);}
    Task first=Call(window,"Initialize"),second=Call(window,"Initialize");Check(Object.ReferenceEquals(first,second),"Concurrent initialization was not shared");Check(!SendEnabled(window),"RestorePending re-enabled Send while initializing");Await(first);Check(!SendEnabled(window),"Failed initialization enabled Send");Check(Details(window).Contains("Exit code: 73"),"Hold exit explanation lost");Check(File.ReadAllLines(Path.Combine(holdRoot,"fixture-started.txt")).Length==1,"Concurrent initialization launched duplicate helpers");if(audited){var restored=(Dictionary<string,object>)OutboxCall(Outbox(window),"Load");Check(Json.Serialize(restored)==Json.Serialize(draft),"Pending request changed on failed startup");}
   }Reap(holdRoot);Pass("concurrent initialization shares one hold-protected helper and leaves Send disabled; pending draft preserved");
   string timeoutRoot=Fixture("unknown-outcome","shortwait",true);bool recovered=false;int healthCalls=0;var timeoutHandler=new FakeHandler{Respond=async(req,ct)=>{healthCalls++;if(recovered)return Response(Health(timeoutRoot));if(healthCalls==1||healthCalls>2)return await Absent();await Task.Delay(Timeout.Infinite,ct);return Response(Health(timeoutRoot));}};
   using(var window=Window(timeoutRoot,timeoutHandler)){
    var elapsed=Stopwatch.StartNew();Exception timeout=Failure(Call(window,"EnsureCommunicationServiceCore",300));Check(elapsed.ElapsedMilliseconds>=280&&elapsed.ElapsedMilliseconds<1500,"Injected short deadline violated");Check(timeout.Message.Contains("within 0.3 seconds"),"Deadline diagnostic absent");Exception retry=Failure(Call(window,"EnsureCommunicationService"));Check(retry.Message.Contains("earlier startup outcome"),"Unknown outcome did not block duplicate retry");for(int i=0;i<20&&!File.Exists(Path.Combine(timeoutRoot,"fixture-started.txt"));i++)Thread.Sleep(100);Check(File.ReadAllLines(Path.Combine(timeoutRoot,"fixture-started.txt")).Length==1,"Unknown outcome retried another helper");recovered=true;Await(Call(window,"EnsureCommunicationService"));Check(!(bool)Field("startupOutcomeUnknown").GetValue(window),"Verified recovery did not clear unknown outcome");
   }Reap(timeoutRoot);Pass("bounded wait; unknown outcome prevents duplicate retry and clears only after matching ready health");
   string statusRoot=Fixture("status-failure","zero",false);var statusHandler=new FakeHandler{Respond=(req,ct)=>{
    string route=req.RequestUri.AbsolutePath;if(route=="/health")return Task.FromResult(Response(Health(statusRoot)));if(route=="/session")return Task.FromResult(Response(new{session="fixture-only"}));if(route=="/api/conversations")return Task.FromResult(Response(new[]{new{id="c",title="fixture"}}));if(route=="/api/conversation")return Task.FromResult(Response(new{id="c",messages=new object[0],updatedAt="fixture"}));if(route=="/api/status")return Task.FromResult(Response(new{error="fixture status unavailable"},503));throw new Exception("Unexpected fixture request "+route);}};
   using(var window=Window(statusRoot,statusHandler)){Await(Call(window,"Initialize"));Check((string)Field("session").GetValue(window)==""&&!SendEnabled(window),"Status failure was presented as connected");Check(Details(window).Contains("workspace status could not be read"),"Status failure not retained in Details");Check(statusHandler.Unexpected==0,"Forbidden request attempted");}Pass("healthy endpoint plus failed workspace status never becomes connected or send-ready");
   string unreadyRoot=Fixture("status-unready","zero",false);var unreadyHandler=new FakeHandler{Respond=(req,ct)=>Task.FromResult(Response(Status(unreadyRoot,false)))};
   using(var window=Window(unreadyRoot,unreadyHandler)){Field("session").SetValue(window,"fixture-only");Field("lastStatus").SetValue(window,Status(unreadyRoot,true));((Button)Field("send").GetValue(window)).Enabled=true;Await(Call(window,"Poll"));Check(!SendEnabled(window)&&!((Button)Field("model").GetValue(window)).Enabled,"Unready status left active controls enabled");if(audited)typeof(GauciaWindow).GetMethod("PendingUi",Private).Invoke(window,null);Check(!SendEnabled(window),"PendingUi overrode service-not-ready state");}Pass("explicit status ready:false disables Send/model and cannot be overridden by pending UI");
   string recoveryRoot=Fixture("recovery","zero",false);string conversationRoot=Path.Combine(recoveryRoot,"data","conversations");
   foreach(string id in new[]{"valid","damaged","fallback"})Directory.CreateDirectory(Path.Combine(conversationRoot,id));
   Func<string,string,string> conversation=(id,content)=>Json.Serialize(new{id=id,title=id,messages=new[]{new{role="assistant",content=content}},updatedAt="fixture"});
   File.WriteAllText(Path.Combine(conversationRoot,"valid","003.json"),conversation("valid","Saved valid content"));File.WriteAllText(Path.Combine(conversationRoot,"damaged","003.json"),"{bad");File.WriteAllText(Path.Combine(conversationRoot,"fallback","003.json"),"{bad newest");File.WriteAllText(Path.Combine(conversationRoot,"fallback","002.json"),conversation("fallback","Earlier preserved content"));File.WriteAllText(Path.Combine(Path.GetDirectoryName(recoveryRoot),"SECURITY_ONLY_HOLD.json"),"{\"hold\":true}");
   var recoveryHandler=new FakeHandler{Respond=(req,ct)=>{throw new Exception("Recovery must never request HTTP");}};
   using(var window=Window(recoveryRoot,recoveryHandler)){
    if(audited)OutboxCall(Outbox(window),"Save",Request());var before=Snapshot(Path.GetDirectoryName(recoveryRoot));typeof(GauciaWindow).GetMethod("EnterRecovery",Private).Invoke(window,null);
    var list=(ListBox)Field("history").GetValue(window);Check(list.Items.Count==3,"Recovery lost a damaged or valid conversation row");Check(list.Items.Cast<object>().Any(item=>item.ToString().Contains("unreadable"))&&list.Items.Cast<object>().Any(item=>item.ToString().Contains("older valid revision")),"Recovery corruption/fallback labels missing");
    var rows=list.Items.Cast<SavedHistoryRecovery.Item>().ToArray();var validRow=rows.Single(item=>item.Title=="valid");var unreadableRow=rows.Single(item=>item.Record==null);var fallbackRow=rows.Single(item=>item.Title.Contains("older valid revision"));var footer=(Label)Field("saved").GetValue(window);
    list.SelectedItem=validRow;Check(validRow.File!=""&&footer.Text.Contains(validRow.File),"Valid selection footer did not identify its saved revision");
    list.SelectedItem=unreadableRow;Check(!footer.Text.Contains(validRow.File)&&footer.Text.Contains("no readable saved revision"),"Unreadable selection footer retained the previous valid file path");
    list.SelectedItem=fallbackRow;Check(fallbackRow.File!=""&&footer.Text.Contains(fallbackRow.File)&&!footer.Text.Contains(validRow.File),"Fallback selection footer did not identify its own saved revision");
    list.SelectedItem=unreadableRow;Check(!footer.Text.Contains(fallbackRow.File)&&footer.Text.Contains("no readable saved revision"),"Unreadable selection footer retained the fallback file path");
    list.SelectedItem=validRow;Check(footer.Text.Contains(validRow.File)&&!footer.Text.Contains("no readable saved revision"),"Valid selection did not restore its revision footer after an unreadable selection");
    for(int i=0;i<list.Items.Count;i++)list.SelectedIndex=i;Check(!SendEnabled(window)&&!((Button)Field("model").GetValue(window)).Enabled&&!((Button)Field("newConversation").GetValue(window)).Enabled&&!((Button)Field("exportButton").GetValue(window)).Enabled,"Recovery normal controls were enabled");
    Await(Call(window,"Send"));Await(Call(window,"Poll"));Await(Call(window,"NewChat"));Await(Call(window,"Export"));Await(Call(window,"Initialize"));typeof(GauciaWindow).GetMethod("Log",Private).Invoke(window,new object[]{"fixture","must not save"});if(audited)typeof(GauciaWindow).GetMethod("PendingUi",Private).Invoke(window,null);
    Check(!SendEnabled(window)&&recoveryHandler.Count==0,"Recovery performed service work or enabled sending");var after=Snapshot(Path.GetDirectoryName(recoveryRoot));Check(before.Count==after.Count&&before.All(pair=>after.ContainsKey(pair.Key)&&after[pair.Key]==pair.Value),"Recovery changed a saved file, pending outbox or hold");Check(Details(window).Contains("Read-only recovery")&&((Label)Field("health").GetValue(window)).Text.Contains("service not connected"),"Recovery was presented as live service readiness");
   }Pass("explicit recovery lists valid/damaged/fallback history with selection-correct revision footers and all actions disabled; file hashes, outbox and hold unchanged; zero HTTP");
   if(audited){
    string root=Fixture("outbox","zero",false);using(var window=Window(root,new FakeHandler{Respond=(req,ct)=>Absent()})){
     object box=Outbox(window);var request=Request();OutboxCall(box,"Save",request);Check(Json.Serialize(OutboxCall(box,"Load"))==Json.Serialize(request),"Outbox text roundtrip changed");bool rejected=false;try{OutboxCall(box,"Acknowledge",request,new Dictionary<string,object>{{"receipt",new Dictionary<string,object>{{"committed",false}}}});}catch(TargetInvocationException){rejected=true;}Check(rejected&&OutboxCall(box,"Load")!=null,"Uncommitted acknowledgment discarded pending input");OutboxCall(box,"Acknowledge",request,new Dictionary<string,object>{{"receipt",new Dictionary<string,object>{{"committed",true}}}});Check(OutboxCall(box,"Load")==null,"Committed acknowledgment did not clear pending");Check(File.Exists(Path.Combine(root,"data","native-outbox","receipts",request["requestId"]+".json")),"Receipt absent");var next=Request();OutboxCall(box,"Save",next);OutboxCall(box,"Reject",next,new Dictionary<string,object>{{"notAdmitted",true}});Check(OutboxCall(box,"Load")==null&&File.Exists(Path.Combine(root,"data","native-outbox","rejected",next["requestId"]+".json")),"Rejection record absent");
    }Pass("Audited exact draft roundtrip, committed receipt gate and rejection preservation retained");
   }
   Console.WriteLine("RESULT PASS "+passed+" regression groups; variant="+(audited?"Audited":"Stable")+"; configured_budget_ms="+budget+"; all requests fake; forms never shown; no USB/model/service access.");return 0;
  }catch(Exception error){Console.Error.WriteLine("RESULT FAIL "+error);return 1;}
 }
}
