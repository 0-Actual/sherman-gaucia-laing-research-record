# GAUCIA native repair, revision 3

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting implementation and verification: Codex.

Revision 3 gates New conversation and Save copy on verified workspace readiness. The empty-workspace startup flow still creates its initial conversation after valid status. Window closure/disposal cancels pending requests and prevents subsequent startup launches, diagnostic writes and verification receipts. A helper or service already running is not killed by closing the window. Requests admitted before cancellation are not rolled back by this UI change. Audited's 3,666-byte NativeOutbox class is byte-for-byte preserved.

The initial window fits the selected monitor's working area. Toolbar captions fit the observed laptop window, and long history titles can scroll horizontally. An unreadable history selection clears the previous record's path from the footer; valid and fallback selections show their own paths. Saved-history recovery remains read-only, with explicit corrupt/fallback labels; no parser changes were made. Minimum-size and other-monitor layouts were not visually verified.

Integrated native regression groups: Local 7/7, Audited 8/8. New lifecycle/action groups: 8/8 for each. These use isolated records and fake HTTP. The closed-startup baseline reproduced a late helper launch and diagnostic writes. Full candidate windows were separately opened against C: fixtures for visual inspection; startup did not establish a live connection, and no runtime/helper was supplied. See validation/native-visible-r3.json at the package root for exact observations. No USB deployment, live conversation, model activation or security certification is claimed.

The build-and-test.ps1 script rebuilds both variants and both test harnesses within this chat's local C: work folder. No GUI application is launched by that test script. The visible fixture checks were a separate attended operation.
