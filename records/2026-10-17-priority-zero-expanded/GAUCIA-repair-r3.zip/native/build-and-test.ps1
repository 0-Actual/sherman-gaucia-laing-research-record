<#!
Rebuild the frozen local candidates and run their isolated regression harnesses.
This script does not launch either GAUCIA GUI executable, contact a live service,
load a model, edit a hold, or write to the USB. It rewrites local build/test outputs
only when explicitly run. The existing hash receipt is not silently refreshed.

Original source mapping (read-only snapshot; not rewritten or recompiled directly):
  ..\gaucia-current\GAUCIA_Sovereign_20260919\ui\GauciaWindow-stable.cs
    -> GauciaWindow-startup-repair.cs -> GAUCIA-Local-startup-repair.exe
  ..\gaucia-current\GAUCIA_Sovereign_20260919\ui\GauciaWindow-audited.cs
    -> audited\GauciaWindow-audited-startup-repair.cs
    -> audited\GAUCIA-Audited-startup-repair.exe
NativeOutbox is preserved exactly in the Audited candidate. Original executable
source equivalence is not established by these mappings. Compiler PE timestamps
can change rebuilt binary hashes; compare source and test outcomes separately.

The port-startup.ps1 generator is intentionally not run here: frozen candidate
sources are the compilation inputs. Production service budget is 90 seconds;
the isolated deadline regression injects 300 ms and uses fake HTTP/local fixtures.
#>
[CmdletBinding()]
param([string]$RepairRoot = $PSScriptRoot)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$repairPath = [IO.Path]::GetFullPath($RepairRoot).TrimEnd('\')
$allowedWork = './REDACTED_LOCAL_ROOT/Documents\Codex\2026-10-15\check-the-library-space-and-let\work\'
if (-not $repairPath.StartsWith($allowedWork,[StringComparison]::OrdinalIgnoreCase)) {
    throw 'Use this chat''s local C: work folder. USB and other output locations are not supported by this reproduction script.'
}
$compiler = './REDACTED_LOCAL_ROOT/Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
if (-not (Test-Path -LiteralPath $compiler -PathType Leaf)) { throw 'The verified .NET Framework compiler is unavailable.' }
$references = @(
    '/reference:System.Windows.Forms.dll',
    '/reference:System.Drawing.dll',
    '/reference:System.Net.Http.dll',
    '/reference:System.Web.Extensions.dll',
    '/reference:System.Core.dll'
)

function Compile-Local {
    param([string]$Target,[string]$Output,[string]$Source,[string[]]$ExtraReferences = @())
    $sourceFile = Join-Path $repairPath $Source
    $outputFile = Join-Path $repairPath $Output
    if (-not (Test-Path -LiteralPath $sourceFile -PathType Leaf)) { throw "Missing frozen source: $Source" }
    & $compiler '/nologo' "/target:$Target" "/out:$outputFile" @references @ExtraReferences $sourceFile
    if ($LASTEXITCODE -ne 0) { throw "Compilation failed for $Output (exit $LASTEXITCODE)." }
}

function Invoke-IsolatedTests {
    param([string]$RelativeExecutable,[string]$RelativeResults)
    $testFile = Join-Path $repairPath $RelativeExecutable
    $resultFile = Join-Path $repairPath $RelativeResults
    $start = [Diagnostics.ProcessStartInfo]::new()
    $start.FileName = $testFile
    $start.WorkingDirectory = Split-Path $testFile -Parent
    $start.UseShellExecute = $false
    $start.CreateNoWindow = $true
    $start.WindowStyle = [Diagnostics.ProcessWindowStyle]::Hidden
    $start.RedirectStandardOutput = $true
    $start.RedirectStandardError = $true
    $process = [Diagnostics.Process]::new()
    $process.StartInfo = $start
    try {
        if (-not $process.Start()) { throw "Could not start local test harness: $RelativeExecutable" }
        # Drain both pipes concurrently before waiting; never block on sequential
        # ReadToEnd calls while a child could fill its other output pipe.
        $stdout = $process.StandardOutput.ReadToEndAsync()
        $stderr = $process.StandardError.ReadToEndAsync()
        if (-not $process.WaitForExit(60000)) {
            # This is only the harness process created immediately above.
            $process.Kill()
            throw "Local test harness exceeded the 60-second bound: $RelativeExecutable"
        }
        $drains = [Threading.Tasks.Task[]]@($stdout,$stderr)
        if (-not [Threading.Tasks.Task]::WaitAll($drains,5000)) { throw 'Test output did not finish within the bounded drain.' }
        $report = $stdout.Result + $stderr.Result
        [IO.File]::WriteAllText($resultFile,$report,[Text.UTF8Encoding]::new($false))
        if ([IO.File]::ReadAllText($resultFile) -cne $report) { throw 'Test result readback did not match.' }
        Write-Output $report.TrimEnd()
        if ($process.ExitCode -ne 0) { throw "Regression tests failed (exit $($process.ExitCode)): $RelativeExecutable" }
        if ($report -notmatch 'RESULT PASS') { throw 'Regression harness did not report a passing completion.' }
    }
    finally { $process.Dispose() }
}

Push-Location -LiteralPath $repairPath
try {
    Compile-Local 'library' 'validation\GauciaStartupCandidate.dll' 'GauciaWindow-startup-repair.cs'
    Compile-Local 'library' 'audited\GauciaAuditedCandidate.dll' 'audited\GauciaWindow-audited-startup-repair.cs'
    Compile-Local 'winexe' 'GAUCIA-Local-startup-repair.exe' 'GauciaWindow-startup-repair.cs'
    Compile-Local 'winexe' 'audited\GAUCIA-Audited-startup-repair.exe' 'audited\GauciaWindow-audited-startup-repair.cs'

    # Same installed compiler and target used for the harmless fake node.exe.
    & $compiler '/nologo' '/target:exe' '/out:validation\FixtureLauncher.exe' 'validation\FixtureLauncher.cs'
    if ($LASTEXITCODE -ne 0) { throw 'Fixture compilation failed.' }
    Copy-Item -LiteralPath 'validation\FixtureLauncher.exe' -Destination 'audited\FixtureLauncher.exe' -Force

    Compile-Local 'exe' 'validation\StartupRegressionTests.exe' 'validation\StartupRegressionTests.cs' @('/reference:validation\GauciaStartupCandidate.dll')
    Compile-Local 'exe' 'audited\StartupRegressionTests.exe' 'validation\StartupRegressionTests.cs' @('/reference:audited\GauciaAuditedCandidate.dll')
    Invoke-IsolatedTests 'validation\StartupRegressionTests.exe' 'validation\regression-results.txt'
    Invoke-IsolatedTests 'audited\StartupRegressionTests.exe' 'audited\regression-results.txt'
    Compile-Local 'exe' 'validation\LifecycleRegressionTests.exe' 'validation\LifecycleRegressionTests.cs' @('/reference:validation\GauciaStartupCandidate.dll')
    Compile-Local 'exe' 'audited\LifecycleRegressionTests.exe' 'validation\LifecycleRegressionTests.cs' @('/reference:audited\GauciaAuditedCandidate.dll')
    Invoke-IsolatedTests 'validation\LifecycleRegressionTests.exe' 'validation\lifecycle-results.txt'
    Invoke-IsolatedTests 'audited\LifecycleRegressionTests.exe' 'audited\lifecycle-results.txt'
    Write-Output 'Local candidates compiled and isolated tests passed. Neither GAUCIA GUI was launched. No USB deployment occurred.'
}
finally { Pop-Location }
