// Quantum.Earth.Laing — Sherman G. Laing. GAUCIA AI-assisted native interface.
// This window uses only the existing loopback communication API. No shell input.
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
public sealed class GauciaWindow : Form {
 readonly string root=AppDomain.CurrentDomain.BaseDirectory;
 readonly HttpClient http=new HttpClient(new HttpClientHandler { UseProxy=false,AllowAutoRedirect=false });
 readonly JavaScriptSerializer json=new JavaScriptSerializer { MaxJsonLength=8388608 };
 readonly Color bg=Color.FromArgb(17,25,28), panel=Color.FromArgb(28,42,46), ink=Color.FromArgb(237,243,241), gold=Color.FromArgb(209,179,118);
 readonly RichTextBox transcript=new RichTextBox(); readonly TextBox input=new TextBox(); readonly ListBox history=new ListBox();
 readonly Label notice=new Label(),health=new Label(),saved=new Label(); readonly ComboBox mode=new ComboBox(); readonly NumericUpDown qubits=new NumericUpDown();
 readonly Button send=new Button(),stop=new Button(),model=new Button(); readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer();
 readonly Font small=new Font("Segoe UI",9),smallBold=new Font("Segoe UI",9,FontStyle.Bold),large=new Font("Segoe UI",19);
 string session="", currentId="",rendered="",startupDiagnostic="Opening your local workspace…"; bool polling=false,historyLoading=false,busy=false,verify=false,connectionLost=false;
 Task initializationTask,communicationStartupTask; bool initializing=false,startupOutcomeUnknown=false;
 readonly CancellationTokenSource lifetime=new CancellationTokenSource(); bool closing=false;
 bool recoveryMode=false;readonly Button recovery=new Button();Button newConversation,exportButton;
 // The existing helper allows 1.5 s plus 40*(0.5+1.5) s = 81.5 s.
 const int ServiceStartupBudgetMilliseconds=90000;
 Dictionary<string,object> pending; NativeOutbox outbox; bool sending=false,storageBlocked=false;
 Dictionary<string,object> lastStatus; readonly Font regular=new Font("Segoe UI",11),bold=new Font("Segoe UI",11,FontStyle.Bold);
 static Dictionary<string,object> D(object value){return (Dictionary<string,object>)value;}
 static string S(Dictionary<string,object> d,string key){return d.ContainsKey(key)&&d[key]!=null?Convert.ToString(d[key]):"";}
 static object[] A(object value){return ((IEnumerable)value).Cast<object>().ToArray();}
 sealed class ChatRow {public string Id,Title;public override string ToString(){return Title;}}
 public GauciaWindow(bool verification){outbox=new NativeOutbox(Path.Combine(root,"data","native-outbox"));verify=verification;Text="GAUCIA | Quantum.Earth.Laing";Rectangle workingArea=Screen.FromPoint(Cursor.Position).WorkingArea;MinimumSize=new Size(Math.Min(850,workingArea.Width),Math.Min(610,workingArea.Height));Size=new Size(Math.Min(1180,workingArea.Width),Math.Min(800,workingArea.Height));StartPosition=FormStartPosition.Manual;Location=new Point(workingArea.Left+(workingArea.Width-Width)/2,workingArea.Top+(workingArea.Height-Height)/2);BackColor=bg;ForeColor=ink;Font=regular;Build();http.Timeout=TimeSpan.FromSeconds(15);Shown+=async delegate {await Initialize();if(verify&&!WindowClosed())await VerifyWindow();};timer.Interval=1000;timer.Tick+=async delegate {await Poll();};FormClosed+=delegate {BeginClose();http.Dispose();};}
 bool WindowClosed(){return closing||IsDisposed||Disposing;}
 void ThrowIfClosing(){if(WindowClosed())throw new OperationCanceledException("The GAUCIA window is closing.");}
 void BeginClose(){if(closing)return;closing=true;timer.Stop();lifetime.Cancel();http.CancelPendingRequests();}
 protected override void OnFormClosing(FormClosingEventArgs e){base.OnFormClosing(e);if(!e.Cancel)BeginClose();}
 protected override void Dispose(bool disposing){if(disposing){BeginClose();http.Dispose();timer.Dispose();lifetime.Dispose();}base.Dispose(disposing);}
 bool WorkspaceActionsReady(){return !WindowClosed()&&!recoveryMode&&!initializing&&session!=""&&StatusReady()&&!connectionLost;}
 void UpdateWorkspaceActions(){if(WindowClosed())return;bool enabled=WorkspaceActionsReady()&&!busy&&pending==null&&!sending&&!storageBlocked;newConversation.Enabled=enabled;exportButton.Enabled=enabled&&currentId!="";}
 async Task<string> GetLocalText(string url){ThrowIfClosing();using(var response=await http.GetAsync(url,lifetime.Token)){ThrowIfClosing();response.EnsureSuccessStatusCode();string text=await response.Content.ReadAsStringAsync();ThrowIfClosing();return text;}}
 Button B(string text,int width=150){var b=new Button {Text=text,Width=width,Height=34,FlatStyle=FlatStyle.Flat,BackColor=panel,ForeColor=ink,Margin=new Padding(4)};b.FlatAppearance.BorderColor=Color.FromArgb(65,85,88);return b;}
 void Style(Button b,string text,int width){b.Text=text;b.Width=width;b.Height=34;b.FlatStyle=FlatStyle.Flat;b.BackColor=panel;b.ForeColor=ink;b.Margin=new Padding(4);b.FlatAppearance.BorderColor=Color.FromArgb(65,85,88);}
 void Build(){
  var shell=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(0)};shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,235));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(shell);
  var side=new Panel {Dock=DockStyle.Fill,Padding=new Padding(16),BackColor=Color.FromArgb(13,21,24)};shell.Controls.Add(side,0,0);
  var brand=new Panel {Dock=DockStyle.Top,Height=90};brand.Controls.Add(new Label {Text="Quantum.Earth.Laing",Dock=DockStyle.Bottom,Height=35,Font=new Font("Segoe UI",10),ForeColor=gold});brand.Controls.Add(new Label {Text="QEL",Dock=DockStyle.Top,Height=45,Font=new Font("Segoe UI",23,FontStyle.Bold),ForeColor=gold});
  var owner=new Label {Text="Sherman G. Laing\nLocal execution · USB records",Dock=DockStyle.Bottom,Height=58,Font=new Font("Segoe UI",9),ForeColor=Color.LightGray};
  newConversation=B("+ New conversation",190);newConversation.Enabled=false;var newButton=newConversation;newButton.Dock=DockStyle.Top;newButton.Click+=async delegate {await NewChat();};
  Style(recovery,"Read saved history",190);recovery.Dock=DockStyle.Top;recovery.Visible=false;recovery.Click+=delegate {EnterRecovery();};
  history.Dock=DockStyle.Fill;history.BackColor=side.BackColor;history.ForeColor=ink;history.BorderStyle=BorderStyle.None;history.Font=new Font("Segoe UI",9);history.ItemHeight=27;history.IntegralHeight=false;history.HorizontalScrollbar=true;
  history.SelectedIndexChanged+=async delegate {if(historyLoading||history.SelectedItem==null)return;if(recoveryMode){ShowRecovered((SavedHistoryRecovery.Item)history.SelectedItem);return;}if(pending!=null){Notice("Resolve the saved pending request before switching conversations.",true);return;}try{currentId=((ChatRow)history.SelectedItem).Id;rendered="";Render(D(await Api("conversation?id="+currentId)));}catch(Exception e){Notice(e.Message,true);}};
  side.Controls.Add(history);side.Controls.Add(owner);side.Controls.Add(recovery);side.Controls.Add(newButton);side.Controls.Add(brand);
  var main=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=6,Padding=new Padding(20,8,20,8)};foreach(float h in new float[]{86,36,0,45,120,27})main.RowStyles.Add(new RowStyle(h==0?SizeType.Percent:SizeType.Absolute,h==0?100:h));shell.Controls.Add(main,1,0);
  var heading=new Panel {Dock=DockStyle.Fill};heading.Controls.Add(new Label {Text="GAUCIA Actual",Font=new Font("Segoe UI",27,FontStyle.Regular),Dock=DockStyle.Top,Height=51,ForeColor=ink});health.Dock=DockStyle.Bottom;health.Height=29;health.ForeColor=gold;health.Font=new Font("Segoe UI",10);heading.Controls.Add(health);main.Controls.Add(heading,0,0);
  notice.Dock=DockStyle.Fill;notice.Font=new Font("Segoe UI",9);notice.Text="Opening your local workspace…";main.Controls.Add(notice,0,1);
  transcript.Dock=DockStyle.Fill;transcript.BackColor=bg;transcript.ForeColor=ink;transcript.BorderStyle=BorderStyle.None;transcript.ReadOnly=true;transcript.DetectUrls=false;transcript.Font=regular;main.Controls.Add(transcript,0,2);
  var tools=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};mode.DropDownStyle=ComboBoxStyle.DropDownList;mode.Items.AddRange(new object[]{"Talk with GAUCIA","Search USB research","Quantum GHZ state","Train classifier"});mode.SelectedIndex=0;mode.Width=175;mode.DropDownWidth=230;mode.BackColor=panel;mode.ForeColor=ink;mode.Margin=new Padding(4,7,4,4);tools.Controls.Add(mode);
  qubits.Minimum=2;qubits.Maximum=60;qubits.Value=3;qubits.Width=48;qubits.BackColor=panel;qubits.ForeColor=ink;qubits.Margin=new Padding(4,7,4,4);tools.Controls.Add(qubits);qubits.AccessibleName="GHZ qubits";qubits.Visible=false;mode.SelectedIndexChanged+=delegate {qubits.Visible=mode.SelectedIndex==2;};
  Style(model,"Load language",120);model.Enabled=false;model.Click+=async delegate {try{bool ready=lastStatus!=null&&S(D(lastStatus["backend"]),"state")=="ready";await Api(ready?"model/stop":"model/start",new Dictionary<string,object>());await Poll();}catch(Exception e){Notice(e.Message,true);}};tools.Controls.Add(model);
  exportButton=B("Save copy",100);exportButton.Enabled=false;var export=exportButton;export.Click+=async delegate {await Export();};tools.Controls.Add(export);var details=B("Details",70);details.Click+=delegate {ShowDetails();};tools.Controls.Add(details);main.Controls.Add(tools,0,3);
  var composer=new Panel {Dock=DockStyle.Fill,Padding=new Padding(10),BackColor=panel};input.Multiline=true;input.AcceptsReturn=true;input.MaxLength=8000;input.Dock=DockStyle.Fill;input.BackColor=panel;input.ForeColor=ink;input.BorderStyle=BorderStyle.None;input.Font=regular;input.KeyDown+=async delegate(object sender,KeyEventArgs e){if(e.KeyCode==Keys.Enter&&!e.Shift){e.SuppressKeyPress=true;await Send();}};
  var bar=new FlowLayoutPanel {Dock=DockStyle.Bottom,Height=40,FlowDirection=FlowDirection.RightToLeft};Style(send,"Send",95);send.BackColor=gold;send.ForeColor=bg;send.Click+=async delegate {await Send();};Style(stop,"Stop",75);stop.Visible=false;stop.Click+=async delegate {try{await Api("stop",new Dictionary<string,object>());Notice("Stopping the response; saved work is retained.");}catch(Exception e){Notice(e.Message,true);}};bar.Controls.Add(send);bar.Controls.Add(stop);composer.Controls.Add(input);composer.Controls.Add(bar);main.Controls.Add(composer,0,4);
  saved.Dock=DockStyle.Fill;saved.Font=new Font("Segoe UI",8);saved.Text="USB preservation enabled · Enter sends · Shift+Enter adds a line";main.Controls.Add(saved,0,5);
 }
 void Notice(string text,bool error=false){if(WindowClosed())return;notice.Text=text;notice.ForeColor=error?Color.Salmon:Color.LightGray;}
 async Task<object> Api(string route,object data=null,bool retried=false){ThrowIfClosing();if(recoveryMode)throw new InvalidOperationException("Read-only history recovery does not contact the service.");
  if(route.Contains("://")||route.StartsWith("/"))throw new Exception("Local route required");
  var request=new HttpRequestMessage(data==null?HttpMethod.Get:HttpMethod.Post,"http://127.0.0.1:17807/api/"+route);request.Headers.Add("X-QEL-Session",session);
  if(data!=null)request.Content=new StringContent(json.Serialize(data),Encoding.UTF8,"application/json");
  using(var response=await http.SendAsync(request,lifetime.Token)){ThrowIfClosing();string bodyText=await response.Content.ReadAsStringAsync();ThrowIfClosing();var value=json.DeserializeObject(bodyText);if(response.StatusCode==System.Net.HttpStatusCode.Forbidden&&!retried){session=S(D(json.DeserializeObject(await GetLocalText("http://127.0.0.1:17807/session"))),"session");var again=await Api(route,data,true);Log("native-session-renewed","Local session reacquired successfully at "+DateTime.UtcNow.ToString("o"));return again;}if(!response.IsSuccessStatusCode){var failure=new Exception(S(D(value),"error"));var body=D(value);if(body.ContainsKey("notAdmitted")&&body["notAdmitted"] is bool&&(bool)body["notAdmitted"]){failure.Data["notAdmitted"]=true;failure.Data["response"]=body;}throw failure;}return value;}
 }
 sealed class CommunicationHealth {public bool Ready,Absent,Blocked;public string Detail;}
 async Task<CommunicationHealth> ProbeHealth(int timeoutMilliseconds){
  try{using(var timeout=CancellationTokenSource.CreateLinkedTokenSource(lifetime.Token)){timeout.CancelAfter(timeoutMilliseconds);
   using(var response=await http.GetAsync("http://127.0.0.1:17807/health",timeout.Token)){
    ThrowIfClosing();var r=D(json.DeserializeObject(await response.Content.ReadAsStringAsync()));ThrowIfClosing();
    if(S(r,"app")!="GAUCIA_QEL_LOCAL_PANEL")return new CommunicationHealth {Blocked=true,Detail="Another or incompatible service is responding on the GAUCIA port. No additional service was launched."};
    string workspace=S(r,"workspace");
    if(String.IsNullOrWhiteSpace(workspace)||!String.Equals(Path.GetFullPath(workspace).TrimEnd('\\','/'),Path.GetFullPath(root).TrimEnd('\\','/'),StringComparison.OrdinalIgnoreCase))return new CommunicationHealth {Blocked=true,Detail="The responding GAUCIA service has a missing or different workspace. It was not reused or relaunched."};
    if(!response.IsSuccessStatusCode||!r.ContainsKey("ready")||!(r["ready"] is bool)||!(bool)r["ready"])return new CommunicationHealth {Blocked=true,Detail="The existing GAUCIA service reports that its workspace is not ready. No additional service was launched."};
    return new CommunicationHealth {Ready=true,Detail="Local communication service is ready."};
   }}
  }catch(HttpRequestException e){for(Exception cause=e;cause!=null;cause=cause.InnerException){var socket=cause as SocketException;if(socket!=null&&socket.SocketErrorCode==SocketError.ConnectionRefused)return new CommunicationHealth {Absent=true,Detail="No local communication service is listening."};}return new CommunicationHealth {Detail="The local connection could not be verified: "+e.Message};}
  catch(TaskCanceledException){return new CommunicationHealth {Detail="The local health check timed out. Service absence is not established."};}
  catch(Exception e){return new CommunicationHealth {Blocked=true,Detail="The local service response could not be verified: "+e.Message};}
 }
 Task EnsureCommunicationService(){ThrowIfClosing();if(communicationStartupTask!=null&&!communicationStartupTask.IsCompleted)return communicationStartupTask;communicationStartupTask=EnsureCommunicationServiceCore(ServiceStartupBudgetMilliseconds);return communicationStartupTask;}
 async Task EnsureCommunicationServiceCore(int budgetMilliseconds){
  ThrowIfClosing();var elapsed=Stopwatch.StartNew();
  var initial=await ProbeHealth(Math.Min(1000,budgetMilliseconds));ThrowIfClosing();
  if(initial.Ready){startupOutcomeUnknown=false;startupDiagnostic=initial.Detail;return;}
  if(startupOutcomeUnknown)throw new Exception("An earlier startup outcome remains unverified. Its service may still be starting; no additional helper was launched. Existing USB work is preserved. "+initial.Detail);
  if(!initial.Absent)throw new Exception(initial.Detail);
  string node=Path.GetFullPath(Path.Combine(root,@"..\Independent_Model_20260919\runtime\node.exe"));
  string entry=Path.Combine(root,@"tools\start-panel.mjs");
  if(!File.Exists(node))throw new FileNotFoundException("The existing USB runtime is not accessible at its expected path. No replacement was started.",node);
  if(!File.Exists(entry))throw new FileNotFoundException("The existing GAUCIA startup entry is not accessible at its expected path. No replacement was started.",entry);
  var output=new StringBuilder();var outputLock=new object();
  Action<string> capture=delegate(string line){if(line==null)return;lock(outputLock){string text=line+Environment.NewLine;int remaining=8192-output.Length;if(remaining>0)output.Append(text,0,Math.Min(remaining,text.Length));}};
  Func<string> diagnostics=delegate {lock(outputLock){return output.ToString().Trim();}};
  Func<int,Exception> exited=delegate(int exitCode){startupOutcomeUnknown=exitCode!=73;string reason=exitCode==73?"The QEL startup check reported a security hold or could not inspect its marker. No hold was changed.":exitCode==0?"The startup entry exited, but the local communication service is not ready.":"The existing GAUCIA startup entry failed.";return new Exception(reason+" Exit code: "+exitCode+".\n"+diagnostics());};
  var start=new ProcessStartInfo(node,"\""+entry+"\""){
   WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true,
   RedirectStandardOutput=true,RedirectStandardError=true
  };
  using(var launcher=new Process {StartInfo=start}){
   launcher.OutputDataReceived+=delegate(object sender,DataReceivedEventArgs e){capture(e.Data);};
   launcher.ErrorDataReceived+=delegate(object sender,DataReceivedEventArgs e){capture(e.Data);};
   ThrowIfClosing();if(!launcher.Start())throw new Exception("Windows did not start the existing GAUCIA startup entry.");
   launcher.BeginOutputReadLine();launcher.BeginErrorReadLine();
   while(elapsed.ElapsedMilliseconds<budgetMilliseconds){ThrowIfClosing();
    if(launcher.HasExited&&launcher.ExitCode!=0){
     // Output callbacks normally finish with process exit; allow one short,
     // bounded drain instead of waiting indefinitely for redirected streams.
     await Task.Delay(100);
     throw exited(launcher.ExitCode);
    }
    int remaining=(int)Math.Max(1,budgetMilliseconds-elapsed.ElapsedMilliseconds);
    var healthState=await ProbeHealth(Math.Min(1000,remaining));ThrowIfClosing();
    if(healthState.Ready){startupOutcomeUnknown=false;startupDiagnostic=healthState.Detail;return;}
    if(healthState.Blocked){startupOutcomeUnknown=true;throw new Exception(healthState.Detail);}
    if(launcher.HasExited){await Task.Delay(100);throw exited(launcher.ExitCode);}
    startupDiagnostic="Waiting for the local communication service ("+(elapsed.ElapsedMilliseconds/1000)+" seconds).";
    Notice(startupDiagnostic);
    int delay=(int)Math.Min(200,Math.Max(0,budgetMilliseconds-elapsed.ElapsedMilliseconds));
    if(delay>0)await Task.Delay(delay);
   }
   // Disposing the handle does not terminate the launcher or its service.
   // Do not restart or kill them without knowing their actual current state.
   startupOutcomeUnknown=true;
   throw new Exception("The local communication service did not become ready within "+(budgetMilliseconds/1000.0).ToString("0.###",System.Globalization.CultureInfo.InvariantCulture)+" seconds. The startup helper may still be running; no duplicate was started. USB work is preserved.\n"+diagnostics());
  }
 }
 Task Initialize(){if(WindowClosed()||recoveryMode)return Task.FromResult(0);if(initializationTask!=null&&!initializationTask.IsCompleted)return initializationTask;initializationTask=InitializeCore();return initializationTask;}
 async Task InitializeCore(){initializing=true;try{
  timer.Stop();session="";lastStatus=null;send.Enabled=false;model.Enabled=false;UpdateWorkspaceActions();RestorePending();
  await EnsureCommunicationService();ThrowIfClosing();
  Notice("Connecting to the local workspace session…" );
  session=S(D(json.DeserializeObject(await GetLocalText("http://127.0.0.1:17807/session"))),"session");
  await CheckInitialStatus();ThrowIfClosing();
  await History();if(pending!=null){if(currentId!="")Render(D(await Api("conversation?id="+currentId)));}else if(history.Items.Count>0){currentId=((ChatRow)history.Items[0]).Id;Render(D(await Api("conversation?id="+currentId)));}else await CreateConversation();
  await Poll();ThrowIfClosing();if(lastStatus==null||connectionLost)throw new Exception("The communication service responded, but the workspace status could not be read. See the connection details.");timer.Start();if(pending==null)Notice("GAUCIA is connected directly to your local USB workspace.");else Notice("A saved request awaits acknowledgment. Retry sends the same request ID.",true);PendingUi();input.Focus();
 }catch(Exception e){if(WindowClosed())return;session="";timer.Stop();model.Enabled=false;startupDiagnostic=e.ToString();Notice(e.Message,true);Log("native-start",startupDiagnostic);recovery.Visible=true;}finally{initializing=false;if(!WindowClosed()){PendingUi();UpdateWorkspaceActions();}}}
 async Task History(){historyLoading=true;try{var rows=A(await Api("conversations"));ThrowIfClosing();history.Items.Clear();foreach(var o in rows){var d=D(o);var row=new ChatRow {Id=S(d,"id"),Title=S(d,"title")};history.Items.Add(row);if(row.Id==currentId)history.SelectedItem=row;}}finally{historyLoading=false;}}
 async Task NewChat(){if(!WorkspaceActionsReady()||busy)return;await CreateConversation();}
 async Task CreateConversation(){if(WindowClosed()||recoveryMode||session==""||!StatusReady()||connectionLost||busy)return;if(pending!=null){Notice("Resolve the saved pending request before starting a new conversation.",true);return;}try{var c=D(await Api("new",new Dictionary<string,object>()));currentId=S(c,"id");rendered="";Render(c);await History();if(!WindowClosed())input.Focus();}catch(Exception e){Notice(e.Message,true);}finally{UpdateWorkspaceActions();}}
 bool StatusReady(){try{return lastStatus!=null&&S(lastStatus,"app")=="GAUCIA_QEL_LOCAL_PANEL"&&lastStatus.ContainsKey("ready")&&lastStatus["ready"] is bool&&(bool)lastStatus["ready"]&&S(lastStatus,"workspace")!=""&&String.Equals(Path.GetFullPath(S(lastStatus,"workspace")).TrimEnd('\\','/'),Path.GetFullPath(root).TrimEnd('\\','/'),StringComparison.OrdinalIgnoreCase);}catch{return false;}}
 async Task CheckInitialStatus(){try{lastStatus=D(await Api("status"));ThrowIfClosing();if(!StatusReady())throw new Exception("The existing workspace reports not ready.");busy=lastStatus["active"]!=null;connectionLost=false;}catch(Exception e){connectionLost=true;throw new Exception("The communication service responded, but the workspace status could not be read. See the connection details.",e);}}
 async Task Poll(){if(WindowClosed()||recoveryMode||polling||session=="")return;polling=true;try{
  bool wasBusy=busy;lastStatus=D(await Api("status"));ThrowIfClosing();if(connectionLost){Notice("Reconnected to the local workspace. USB conversation history is preserved.");connectionLost=false;}busy=lastStatus["active"]!=null;var b=D(lastStatus["backend"]);var lib=D(lastStatus["library"]);
  health.Text="Local language: "+S(b,"state")+"  |  "+S(lib,"records")+" USB passages  |  "+S(lastStatus,"freeMiB")+" MiB available";
  if(!StatusReady())throw new Exception("The existing workspace reports not ready. Sending and model loading are disabled.");
  model.Text=S(b,"state")=="ready"?"Rest language":"Load language";model.Enabled=!busy&&pending==null&&S(b,"state")!="loading";send.Enabled=!recoveryMode&&!initializing&&session!=""&&StatusReady()&&!connectionLost&&!sending&&!storageBlocked&&(!busy||pending!=null);stop.Visible=busy;
  Dictionary<string,object> c=currentId!=""?D(await Api("conversation?id="+currentId)):null;if(c!=null)Render(c);if(wasBusy&&!busy){await History();string state="unknown";if(c!=null){var mm=A(c["messages"]);if(mm.Length>0)state=S(D(mm.Last()),"status");}Notice(state=="complete"?"Response completed and saved on USB.":"Response stopped with state: "+state+". Review the saved result.",state!="complete");}AuditStatus();
 }catch(Exception e){if(WindowClosed())return;connectionLost=true;send.Enabled=false;model.Enabled=false;startupDiagnostic=e.ToString();Notice("Local connection: "+e.Message,true);}finally{polling=false;UpdateWorkspaceActions();}}
 void Append(string text,Color color,Font font){transcript.SelectionStart=transcript.TextLength;transcript.SelectionColor=color;transcript.SelectionFont=font;transcript.AppendText(text);}
 void Render(Dictionary<string,object> c){if(WindowClosed())return;
  currentId=S(c,"id");string key=json.Serialize(c["messages"]);if(key==rendered)return;rendered=key;bool end=transcript.SelectionStart>=transcript.TextLength-80;transcript.Clear();
  var messages=A(c["messages"]);if(messages.Length==0){Append("What shall we work on, Sherman?\n\n",gold,large);Append("Write naturally below. Your conversation, research passages, and computed results are saved in your USB workspace.\n\nYou can ask for a Bell state or use the research and quantum modes.",ink,regular);}
  foreach(var o in messages){var m=D(o);bool user=S(m,"role")=="user";Append((user?"SHERMAN G. LAING":"GAUCIA ACTUAL")+"\n",user?Color.LightGray:gold,bold);string content=S(m,"content");if(content==""&&S(m,"status")=="running")content="Working locally…";Append(content+"\n",ink,regular);if(m.ContainsKey("error"))Append(S(m,"error")+"\n",Color.Salmon,regular);if(m.ContainsKey("engine"))Append(S(m,"engine")+"\n",Color.Gray,small);
   if(m.ContainsKey("sources")){foreach(var source in A(m["sources"])){var s=D(source);Append("\n["+S(s,"id")+"] "+S(s,"title")+"\n",gold,smallBold);Append(S(s,"excerpt")+"\n",Color.LightGray,small);}}
   Append("\n",ink,regular);
  }
  saved.Text="Saved to USB · "+S(c,"updatedAt")+" · Enter sends, Shift+Enter adds a line";if(end){transcript.SelectionStart=transcript.TextLength;transcript.ScrollToCaret();}
 }
 void RestorePending(){
  try{pending=outbox.Load();if(pending!=null){currentId=S(pending,"id");input.Text=S(pending,"text");string kind=S(pending,"kind");mode.SelectedIndex=kind=="search"?1:kind=="ghz"?2:kind=="train"?3:0;if(pending.ContainsKey("n"))qubits.Value=Math.Max(qubits.Minimum,Math.Min(qubits.Maximum,Convert.ToDecimal(pending["n"])));Notice("Saved pending request restored. Use Retry to check acknowledgment.",true);}PendingUi();}
  catch(Exception e){storageBlocked=true;throw new Exception("Pending request storage cannot be verified. Sending is blocked: "+e.Message);}
 }
 void PendingUi(){if(WindowClosed())return;UpdateWorkspaceActions();if(recoveryMode){send.Enabled=false;input.ReadOnly=true;mode.Enabled=false;qubits.Enabled=false;return;}input.ReadOnly=pending!=null;mode.Enabled=pending==null;qubits.Enabled=pending==null;send.Text=pending==null?"Send":"Retry";send.Enabled=!recoveryMode&&!initializing&&session!=""&&StatusReady()&&!connectionLost&&!sending&&!storageBlocked&&(!busy||pending!=null);}
 void AuditStatus(){if(WindowClosed())return;
  string local=pending==null?"No local request awaiting acknowledgment":"Pending request "+S(pending,"requestId");
  if(pending!=null){DateTime t;if(DateTime.TryParse(S(pending,"createdAt"),null,System.Globalization.DateTimeStyles.RoundtripKind,out t)&&(DateTime.UtcNow-t.ToUniversalTime()).TotalSeconds>60)local="OVERDUE acknowledgment · "+local;}
  if(lastStatus!=null&&lastStatus.ContainsKey("audit")){var a=D(lastStatus["audit"]);local+=" · Pending "+S(a,"pending")+" · Overdue "+S(a,"overdue")+" · Unresolved "+S(a,"unresolved");if(S(a,"storageFailure")!="")local+=" · STORAGE FAILURE: "+S(a,"storageFailure");}
  saved.Text=local;PendingUi();
 }
 async Task Send(){if(WindowClosed()||recoveryMode)return;
  if(sending||storageBlocked||(busy&&pending==null))return;if(initializing||session==""||!StatusReady()||connectionLost){await Initialize();}if(WindowClosed()||sending||storageBlocked||(busy&&pending==null)||session==""||!StatusReady()||connectionLost)return;
  string kind=new string[]{"chat","search","ghz","train"}[mode.SelectedIndex];string text=input.Text;
  if(pending==null&&String.IsNullOrWhiteSpace(text)){Notice("Enter a message before sending.");return;}
  sending=true;send.Enabled=false;bool acknowledged=false;
  try{
   if(pending==null){pending=new Dictionary<string,object>{{"id",currentId},{"text",text},{"kind",kind},{"requestId",Guid.NewGuid().ToString("D")},{"createdAt",DateTime.UtcNow.ToString("o")}};if(kind=="ghz")pending["n"]=(int)qubits.Value;try{outbox.Save(pending);}catch{pending=null;throw;}}
   PendingUi();
   if(S(pending,"id")==""){var c=D(await Api("new",new Dictionary<string,object>()));var staged=new Dictionary<string,object>(pending);staged["id"]=S(c,"id");if(S(staged,"id")=="")throw new Exception("Conversation identifier missing");outbox.Save(staged);pending=staged;}
   currentId=S(pending,"id");busy=true;
   var response=D(await Api("message",pending));ThrowIfClosing();
   if(!response.ContainsKey("receipt")||response["receipt"]==null||Convert.ToString(response["receipt"])=="")throw new Exception("The service returned no durable receipt. The request remains saved for retry.");
   outbox.Acknowledge(pending,response);acknowledged=true;pending=null;input.Clear();
   string state=S(response,"state");Notice(state==""?"Input receipt saved on USB. Check the response state below.":"Input receipt saved. Request state: "+state+".",state=="FAILED"||state=="INTERRUPTED");
   await Poll();await History();
  }catch(Exception e){busy=false;if(pending!=null&&e.Data.Contains("notAdmitted")){try{outbox.Reject(pending,(Dictionary<string,object>)e.Data["response"]);pending=null;Notice("Request was not accepted. Your exact draft is retained and editable: "+e.Message,true);return;}catch(Exception storageError){Notice("Rejection record could not be committed. Pending request retained: "+storageError.Message,true);return;}}Notice((acknowledged?"Receipt saved; display refresh failed: ":pending==null?"Input was not sent: ":"Request remains saved for explicit retry: ")+e.Message,true);}
  finally{sending=false;AuditStatus();}
 }
 async Task<string> Export(){try{if(!WorkspaceActionsReady()||busy||currentId=="")return "";var r=D(await Api("export",new Dictionary<string,object>{{"id",currentId}}));Notice("Readable copy saved and read back: "+S(r,"file"));return S(r,"file");}catch(Exception e){Notice(e.Message,true);return "";}}
 void EnterRecovery(){
  if(WindowClosed()||initializing)return;recoveryMode=true;timer.Stop();session="";lastStatus=null;send.Enabled=false;model.Enabled=false;model.Enabled=false;stop.Visible=false;newConversation.Enabled=false;exportButton.Enabled=false;recovery.Enabled=false;input.ReadOnly=true;mode.Enabled=false;qubits.Enabled=false;
  health.Text="READ-ONLY HISTORY RECOVERY · service not connected";startupDiagnostic="Read-only recovery: existing saved revisions only. No service/model activity or record changes. Pending requests are preserved without retry. Reopen GAUCIA to attempt normal startup.";
  historyLoading=true;try{history.Items.Clear();foreach(var item in SavedHistoryRecovery.Read(root))history.Items.Add(item);}finally{historyLoading=false;}
  Notice("Read-only recovery. Service readiness is not established; sending and normal actions are disabled.",true);saved.Text="Existing saved files only · no recovery writes";
  if(history.Items.Count>0)history.SelectedIndex=0;else{transcript.Clear();Append("No saved conversations were found.\n",gold,regular);}
 }
 void ShowRecovered(SavedHistoryRecovery.Item item){saved.Text=item.Record==null?"Read-only: no readable saved revision":"Read-only: "+item.File;transcript.Clear();Append("READ-ONLY RECOVERY\n\n",gold,bold);Append(item.Detail+"\n\n",item.Record==null?Color.Salmon:Color.LightGray,small);if(item.Record==null)return;Append(item.Title+"\n\n",gold,large);foreach(var value in A(item.Record["messages"])){var message=D(value);Append(S(message,"role").ToUpperInvariant()+"\n",gold,bold);Append(S(message,"content")+"\n\n",ink,regular);}}
 string StartupDetailsText(){return "Workspace: "+root+"\n\n"+startupDiagnostic;}
 void ShowDetails(){if(recoveryMode||session==""||!StatusReady()){MessageBox.Show(this,StartupDetailsText(),"GAUCIA startup status",MessageBoxButtons.OK,MessageBoxIcon.Information);return;}var b=D(lastStatus["backend"]);var l=D(lastStatus["library"]);MessageBox.Show(this,"Owner: Sherman G. Laing\nWorkspace: "+root+"\nLanguage: "+S(b,"model")+"\nResearch: "+S(l,"records")+" passages, "+S(l,"sourceFiles")+" source files\nQuantum engine: existing QEL SOP simulation\nStorage: USB conversation revisions and computed results\nConnections: laptop loopback only\n\nQEL interface and integration: GAUCIA, AI-assisted. Open-source language runtime: llama.cpp. Corpus use is local retrieval, not weight training. This application does not execute commands supplied by the language model.","GAUCIA environment",MessageBoxButtons.OK,MessageBoxIcon.Information);}
 void Log(string prefix,string text){if(WindowClosed()||recoveryMode)return;try{Directory.CreateDirectory(Path.Combine(root,"evidence"));File.WriteAllText(Path.Combine(root,"evidence",prefix+"-"+DateTime.UtcNow.Ticks+".txt"),text,Encoding.UTF8);}catch{}}
 async Task<Dictionary<string,object>> WaitAnswer(){for(int i=0;i<300;i++){var c=D(await Api("conversation?id="+currentId));var messages=A(c["messages"]);if(messages.Length>0){var m=D(messages.Last());Render(c);if(S(m,"status")!="running"){await Poll();if(S(m,"status")!="complete")throw new Exception(S(m,"error"));return m;}}await Task.Delay(1000);}throw new Exception("Local response verification timed out");}
 async Task VerifyWindow(){if(WindowClosed())return;
  timer.Stop();var tests=new List<string>();var report=new Dictionary<string,object>{{"at",DateTime.UtcNow.ToString("o")},{"state","RUNNING"},{"tests",tests},{"owner","Sherman G. Laing"},{"windowHandle",Handle.ToInt64()}};
  try{
   if(session=="")throw new Exception("No local session");tests.Add("Native graphical window created and connected");
   await NewChat();mode.SelectedIndex=0;input.Text="Run a Bell state";await Send();var bell=await WaitAnswer();var result=D(bell["result"]);var outcomes=A(result["outcomes"]);double p0=Convert.ToDouble(D(outcomes[0])["probability"]);if(Math.Abs(p0-0.5)>1e-10)throw new Exception("Bell probability mismatch");tests.Add("Typed native-window message invokes actual QEL Bell computation");report["bell"]=result;
   await NewChat();input.Text="What is 2+3? Reply with a single numeral.";var clock=Stopwatch.StartNew();await Send();var answer=await WaitAnswer();string arithmetic=S(answer,"content").Replace(" ","").Trim().TrimEnd('.');if(arithmetic!="5"&&arithmetic!="2+3=5")throw new Exception("Unexpected arithmetic answer: "+S(answer,"content"));tests.Add("Typed native-window message receives actual local-model answer 5");report["languageMs"]=clock.ElapsedMilliseconds;report["languageAnswer"]=answer;
   string export=await Export();if(export==""||!File.ReadAllText(export).Contains("5"))throw new Exception("Export validation failed");report["export"]=export;tests.Add("Native export control writes readable conversation to USB");
   string id=currentId;var restored=D(await Api("conversation?id="+id));Render(restored);if(!transcript.Text.Contains("GAUCIA ACTUAL")||!transcript.Text.Contains("5"))throw new Exception("Native transcript rendering failed");tests.Add("Saved conversation renders back into native transcript");
   Activate();BringToFront();await Task.Delay(400);ThrowIfClosing();using(var image=new Bitmap(Width,Height)){using(var g=Graphics.FromImage(image)){g.CopyFromScreen(Location,Point.Empty,Size);}string shot=Path.Combine(root,"evidence","native-window-"+DateTime.UtcNow.Ticks+".png");image.Save(shot,System.Drawing.Imaging.ImageFormat.Png);report["screenshot"]=shot;}
   report["status"]=lastStatus;report["state"]="PASS";report["conversation"]=id;tests.Add("Screen image saved for the actual native window rectangle");
  }catch(Exception e){report["state"]="FAIL";report["error"]=e.ToString();Notice(e.Message,true);}
  if(WindowClosed())return;string file=Path.Combine(root,"evidence","native-ui-"+DateTime.UtcNow.Ticks+".json");string text=json.Serialize(report);File.WriteAllText(file,text,new UTF8Encoding(false));if(!File.ReadAllBytes(file).SequenceEqual(new UTF8Encoding(false).GetBytes(text)))throw new Exception("Native receipt readback mismatch");
  if(S(report,"state")=="PASS"){await NewChat();Notice("GAUCIA is ready. Local conversation, USB research and QEL quantum computation are connected.");}if(WindowClosed())return;timer.Start();Activate();input.Focus();
 }
}
public sealed class NativeOutbox {
 readonly string directory; readonly JavaScriptSerializer json=new JavaScriptSerializer {MaxJsonLength=8388608};
 public NativeOutbox(string path){directory=path;}
 public string PendingPath {get{return Path.Combine(directory,"pending.json");}}
 static void VerifyBytes(string path,byte[] expected){if(!File.ReadAllBytes(path).SequenceEqual(expected))throw new IOException("Durable request readback mismatch");}
 public static void WriteVerified(string path,string content){
  Directory.CreateDirectory(Path.GetDirectoryName(path));byte[] data=new UTF8Encoding(false,true).GetBytes(content);string temp=path+".writing-"+Guid.NewGuid().ToString("N");
  try{using(var stream=new FileStream(temp,FileMode.CreateNew,FileAccess.Write,FileShare.None,4096,FileOptions.WriteThrough)){stream.Write(data,0,data.Length);stream.Flush(true);}VerifyBytes(temp,data);if(File.Exists(path))File.Replace(temp,path,null);else File.Move(temp,path);VerifyBytes(path,data);}
  finally{if(File.Exists(temp))File.Delete(temp);}
 }
 public void Save(Dictionary<string,object> request){Validate(request);WriteVerified(PendingPath,json.Serialize(request));}
 static void Validate(Dictionary<string,object> request){
  if(request==null||!request.ContainsKey("requestId")||!request.ContainsKey("text")||!request.ContainsKey("kind")||!request.ContainsKey("id"))throw new IOException("Invalid pending request");
  Guid id;if(!Guid.TryParse(Convert.ToString(request["requestId"]),out id))throw new IOException("Invalid request identifier");
  if(!(request["text"] is string)||String.IsNullOrWhiteSpace((string)request["text"]))throw new IOException("Pending text missing");
 }
 public Dictionary<string,object> Load(){if(!File.Exists(PendingPath))return null;var request=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(PendingPath,new UTF8Encoding(false,true)));Validate(request);return request;}
 public void Reject(Dictionary<string,object> request,Dictionary<string,object> response){
  Validate(request);if(!response.ContainsKey("notAdmitted")||!(response["notAdmitted"] is bool)||!(bool)response["notAdmitted"])throw new IOException("Admission is uncertain");
  string record=Path.Combine(directory,"rejected",Convert.ToString(request["requestId"])+".json");WriteVerified(record,json.Serialize(new Dictionary<string,object>{{"request",request},{"rejection",response}}));if(File.Exists(PendingPath))File.Delete(PendingPath);if(File.Exists(PendingPath))throw new IOException("Rejection saved but pending cleanup failed");
 }
 public void Acknowledge(Dictionary<string,object> request,Dictionary<string,object> response){
  Validate(request);if(!response.ContainsKey("receipt")||!(response["receipt"] is Dictionary<string,object>))throw new IOException("Receipt missing");var receipt=(Dictionary<string,object>)response["receipt"];if(!receipt.ContainsKey("committed")||!(receipt["committed"] is bool)||!(bool)receipt["committed"])throw new IOException("Receipt was not committed");
  string ack=Path.Combine(directory,"receipts",Convert.ToString(request["requestId"])+".json");
  var record=new Dictionary<string,object>{{"request",request},{"response",response}};
  if(!File.Exists(ack))WriteVerified(ack,json.Serialize(record));else{var previous=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(ack));var prior=(Dictionary<string,object>)previous["request"];if(json.Serialize(prior)!=json.Serialize(request))throw new IOException("Acknowledgment request mismatch");}
  if(File.Exists(PendingPath))File.Delete(PendingPath);if(File.Exists(PendingPath))throw new IOException("Acknowledgment saved, pending cleanup requires retry");
 }
}
public static class SavedHistoryRecovery {
 public sealed class Item {public string Title,File,Detail;public Dictionary<string,object> Record;public override string ToString(){return Title;}}
 static readonly JavaScriptSerializer json=new JavaScriptSerializer {MaxJsonLength=8388608};
 static string Text(Dictionary<string,object> record,string key){return record.ContainsKey(key)&&record[key]!=null?Convert.ToString(record[key]):"";}
 static void Regular(string path){if((System.IO.File.GetAttributes(path)&FileAttributes.ReparsePoint)!=0)throw new IOException("Linked/reparse entries are not followed in recovery.");}
 public static List<Item> Read(string root){var result=new List<Item>();string directory=Path.Combine(root,"data","conversations");try{
  if(!Directory.Exists(directory)){try{System.IO.File.GetAttributes(directory);}catch(DirectoryNotFoundException){return result;}catch(FileNotFoundException){return result;}}Regular(root);Regular(Path.Combine(root,"data"));Regular(directory);foreach(string folder in Directory.GetDirectories(directory).OrderBy(p=>p,StringComparer.Ordinal)){
   string id=Path.GetFileName(folder);var errors=new List<string>();Dictionary<string,object> record=null;string selected="";
   try{Regular(folder);foreach(string file in Directory.GetFiles(folder,"*.json").OrderByDescending(p=>Path.GetFileName(p),StringComparer.Ordinal)){
    try{Regular(file);var item=json.DeserializeObject(System.IO.File.ReadAllText(file,new UTF8Encoding(false,true))) as Dictionary<string,object>;if(item==null||Text(item,"id")!=id||!item.ContainsKey("messages")||!(item["messages"] is object[]))throw new IOException("Conversation shape or identifier is invalid.");foreach(var message in (object[])item["messages"]){var m=message as Dictionary<string,object>;if(m==null||!m.ContainsKey("content")||!(m["content"] is string))throw new IOException("Message content is invalid.");}record=item;selected=file;break;}catch(Exception error){errors.Add(Path.GetFileName(file)+": "+error.Message);}
   }}catch(Exception error){errors.Add(error.Message);}
   string title=record==null?id+" [unreadable]":Text(record,"title");if(String.IsNullOrWhiteSpace(title))title=id;if(record!=null&&errors.Count>0)title+=" [older valid revision]";
   string detail=record==null?"No readable saved revision.":"Saved revision: "+Path.GetFileName(selected);if(errors.Count>0)detail+="\nRecovery diagnostics: "+String.Join(" | ",errors);
   result.Add(new Item {Title=title,Record=record,File=selected,Detail=detail});
  }
 }catch(Exception error){result.Add(new Item {Title="Saved history unavailable",Detail=error.Message,File=""});}return result;}
}
public static class Program {
 public static string FatalStartupText(Exception error){return "GAUCIA could not open its window. Existing USB work is preserved.\n\n"+error.Message+"\n\nWorkspace: "+AppDomain.CurrentDomain.BaseDirectory;}
 [STAThread] public static void Main(string[] args){try{Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new GauciaWindow(args.Contains("--verify-ui")));}catch(Exception e){try{string evidence=Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"evidence");Directory.CreateDirectory(evidence);File.WriteAllText(Path.Combine(evidence,"native-fatal-"+DateTime.UtcNow.Ticks+".txt"),e.ToString());}catch{}MessageBox.Show(FatalStartupText(e),"GAUCIA startup error",MessageBoxButtons.OK,MessageBoxIcon.Error);}}
}
