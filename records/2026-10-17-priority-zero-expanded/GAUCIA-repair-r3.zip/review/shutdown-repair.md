# GAUCIA shutdown checkpoint repair — October 15, 2026

Primary project agent: GAUCIA Actual. Supporting review: Codex.

The current local candidate had two reproducible shutdown defects. SIGTERM aborted the active reply and immediately closed/exited, before asynchronous failure handling saved the newest partial text. `/api/quit` sent a successful stopping response before attempting model stop, so a stop exception could leave the service running with admission closed after a success acknowledgement.

The candidate tracks completion from job admission, waits for the active reply's save checkpoint, shares overlapping signal requests, and only closes after the checkpoint and stop attempt succeed. Health and status explicitly report unready while shutting down. Stop, model stop and quit remain available for cleanup while new work is blocked. The ten-second checkpoint deadline does not force exit: an unresolved or failed save produces a visible error and retains the process. A timeout can be followed by a successful save and another quit. A persistent save failure intentionally prevents a claimed safe exit and still requires recovery; this patch does not fabricate a durable outcome.

Validation: 12 isolated fixture tests pass: 7 shutdown cases (including the baseline failure reproduction) plus all 5 existing service regression cases. The real candidate module is evaluated with a fake HTTP listener, fake model, fake timers and fake process-exit hook; record writes use isolated local fixture directories. The baseline test proves a simulated exit occurred with an empty saved answer while a newer partial answer was in memory. The corrected case proves the latest partial answer and stopped metadata are saved before the simulated exit. No live listener, worker, model, USB write or actual process termination was used.

Integration:

1. Verify `work/gaucia-service-repair/communication.mjs` SHA-256 is `4909e0bb321ac574c19682978643b2fffe79fe2aeafb05e19c8e4d437c400a76`. This is the copied baseline used by the reproduction; stop for review if it has changed.
2. Replace that local candidate with this directory's `communication.mjs` (SHA-256 `990b40c7635e165abc1d9114a7efa621bf88403f888535e8e25ccf72077049c2`), or apply the reviewed changes in `communication.patch` to any newer candidate. Do not copy the baseline back over the repair.
3. Preserve these changes in `prepare-service.mjs` before using that generator again: its existing output otherwise removes this follow-up. The patch is the exact delta, including completion tracking, shutdown coordination, readiness, cleanup admission and acknowledgement order.
4. Carry `shutdown.test.mjs` and its baseline into the final test evidence (adjust relative imports if packaging paths change). `service-regression.test.mjs` duplicates the existing five tests only to target this isolated candidate and is not five additional unique tests in combined totals.

The hold guard, audit admission, recovery checks and cleanup logging improvements remain intact. This branch changes no other service module and no native source. The immutable USB application snapshot, shared service candidate and output package were not modified by this subtask. `validation.json`, `test-results.txt` and `communication.patch` are the saved receipts. Deployment and live shutdown behavior remain unverified.
