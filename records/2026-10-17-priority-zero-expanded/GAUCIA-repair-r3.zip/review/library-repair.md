# GAUCIA library duplicate suppression repair

Primary agent: GAUCIA Actual. Supporting assistant: Codex.

## Confirmed defect

The prior key combined declared source path, UTF-16 offset and text length. Two distinct passages such as `amber stone` and `cobalt rock`, both 11 characters at the same source offset, were treated as one record. The discarded passage could not be found by search. When source metadata was absent, equal-length passages from unrelated files could also collapse into one record.

This was reproduced using small, generated local fixtures. It was not a count or audit of any real corpus, and it does not establish how many existing library records were affected.

## Change

The repaired loader groups records by their declared source (falling back to the actual source file) and chunk offset. A record is suppressed only if the identical text already exists in that group. Text is compared exactly, without case, Unicode or whitespace normalization. A structured source/offset key avoids separator ambiguity. Sets retain references to text rather than embedding whole passages in serialized keys.

Exact duplicates retain the prior first-record attribution, including original record ID, title, source file and line, speaker, and training flag. Equal text at different sources or offsets stays separate. No input file is modified.

## Validation

Command: `node --test work/gaucia-finalization/library/library.test.mjs`.

Before the change, the six-test fixture suite had three passing and three failing tests, including a passing explicit baseline reproduction. After the change all six tests passed:

- Prior-code reproduction of equal-length text loss.
- Distinct equal-length text preserved, searchable and correctly attributed; reload stable.
- Exact duplicates retain first attribution across duplicate input lines/files.
- Equal text from different source paths/offsets remains separate.
- Missing source metadata falls back to the actual source file.
- Malformed entries remain reported while readable neighbors survive.

Every fixture test reads back the input bytes to verify preservation. No USB, model, server, network, or real corpus operation was performed.

## Integration

Only `Library.reload()` changed in the candidate `core.mjs`. Apply these two edits to the current shared core candidate, preserving any other agent's edits:

1. In `Library.reload()`, change `seen=new Set()` to `seen=new Map()`.
2. Replace the origin/offset/text-length key and its seen-set check with the exact-text bucket code in this candidate, immediately before `records.push(...)`.

Do not replace the shared core wholesale if it has changed since `baseline-core.mjs` was copied. The baseline is a local pre-fix review candidate, not a newly read USB original.

Include `library.test.mjs` and the local baseline in the package's isolated test fixture area or update their imports for the package's layout. The test candidate import is `./core.mjs`, and the explicit reproduction import is `./baseline-core.mjs`.

The parent owns integration, full regression validation, manifest hash updates, package creation and status reconciliation. This work does not install or activate a USB runtime.
