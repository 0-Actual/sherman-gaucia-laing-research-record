# Native recovery and lifecycle follow-up

Scope: Local and Audited native candidates from `work/gaucia-repair`, reviewed after the R2 checkpoint. This folder contains separate candidate sources and bounded local fixture tests. It does not modify the snapshot, R2 package, USB, service modules, or the current progress record. Layout changes are owned by the coordinating task.

## Reproduced defects

1. **Actions remained available before connection was verified.** New conversation and Save readable copy initially appeared enabled. Invoking New conversation while initialization was still active issued an HTTP write even though Send/model were gated. The existing creation method was also used by initialization, so merely adding a readiness guard would have broken an empty workspace's first conversation.
2. **Closing did not cancel startup work.** A delayed connection-refused result delivered after the window's close event launched the inert fixture helper and wrote startup diagnostics. Both original variants produced helper-start marker files. Disposing the window during startup also produced new diagnostics.
3. **Verification could write after closing.** The existing `--verify-ui` path could enter verification after initialization returned from a closed window. The bounded regression invokes the verification entry after a close event; the original path writes a failure receipt.

These are local fixture observations, not claims that the same sequence occurred on the user's USB.

## Candidate behavior

New conversation and export start disabled and require a verified session/status, completed initialization, and an idle workspace. The separate internal initial-conversation step runs only after a successful status-only check, preserving empty-workspace initialization. History is then loaded before a selected conversation is read, allowing a stale selection to be replaced by a readable neighbor. Audited pending drafts continue to block creation of another conversation and retain their existing conversation association.

The window now owns a cancellation source. Closing or disposing cancels pending HTTP checks and prevents later startup launches, session reacquisition, polling, diagnostic writes, and verification receipts. A post-poll close check also prevents initialization from restarting its timer after closing. Closing does **not** kill a helper or communication service that has already started. An accepted request can continue under the service's existing lifecycle; Audited pending outbox state is preserved for its existing receipt/retry rules.

`NativeOutbox` is byte-for-byte identical to its R2 source section (3,666 bytes; SHA-256 `2f4a3c5e9b53ebcda93d6b9504605c0431273ae443ea8fa9e50fdf710785a778`). No outbox algorithms or files were changed. `prepare.mjs` also asserts equivalence after line-ending normalization, records source hashes, and creates only these separate candidate files.

## Other review results and limits

Saved content is rendered through `RichTextBox.AppendText`, with URL detection disabled. No HTML/RTF interpretation path was found. The coordinating task separately observed literal script-like text remain inert in its full native fixture. Recovery validates message content and isolates malformed saved revisions through the existing fallback behavior; no additional confirmed corruption defect justified rewriting it here.

Recovery reads revisions synchronously and its serializer limit is 8,388,608 characters. Very large or numerous records could affect responsiveness; no measured user-data failure, memory-exhaustion reproduction, or fix is claimed. Recovery remains a text view and is not evidence of complete corpus/mirror availability.

The tests use fake HTTP, never-shown Windows Forms, local finite fixture helpers, and folders beneath this review directory. No live endpoint, model, or USB access occurs. Production window closing and layout are for the coordinating task's integrated visual verification. Existing 7 Local/8 Audited regression groups are to be run once by the coordinating task on integrated final sources rather than duplicated here.

## Evidence

- `baseline/Local/results.txt`, `baseline/Audited/results.txt`: current regression behavior of the R2 originals.
- `candidate/Local/results.txt`, `candidate/Audited/results.txt`: behavior of these candidates.
- `LifecycleRegressionTests.cs`: eight bounded groups, with a 500 ms post-close settle before checking whether the helper marker appeared. The final two groups additionally exercise stale-selection reconnect and closing during the final status poll.
- `candidate-hashes.json`: baseline and candidate hashes; this review's tests compile but do not edit candidate sources.
- `check.ps1`: builds and runs either baseline or candidate fixtures, capturing results without displaying application windows.

The baseline run covers the first six groups: it passed initial-conversation creation and failed the other five in each variant. Final candidate results passed the expanded eight-group set in each variant, with zero failures. Read the final results files for individual outcomes; this document is not an installation or live-readiness receipt.
