import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {Records} from './core.mjs';
import {Records as OriginalRecords} from '../baseline/core.mjs';

const fixtureRoot=path.join(import.meta.dirname,'fixtures');
fs.mkdirSync(fixtureRoot,{recursive:true});
const fingerprint=bytes=>createHash('sha256').update(bytes).digest('hex');
function fixture(label,Constructor=Records){
  const root=fs.mkdtempSync(path.join(fixtureRoot,label+'-'));
  return {root,records:new Constructor(root,fingerprint)};
}
function job(root,id,revision,status='running',extra={}){
  const dir=path.join(root,'data','jobs',id);fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,revision+'.json');
  const data={id,revision,status,updatedAt:'2026-01-01T00:00:00.000Z',input:'preserve exact input',task:{kind:'chat'},...extra};
  fs.writeFileSync(file,JSON.stringify(data)+'\n',{flag:'wx'});return file;
}
function broken(root,id,revision='1000000000001-bb'){
  const dir=path.join(root,'data','jobs',id);fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,revision+'.json');fs.writeFileSync(file,'{"id":',{flag:'wx'});return file;
}
function snapshot(files){return new Map(files.map(f=>[f,fs.readFileSync(f)]));}
function unchanged(saved){for(const [file,bytes] of saved)assert.deepEqual(fs.readFileSync(file),bytes,file+' was changed');}
function withFailure(method,match,code,fn){
  const original=fs[method];
  fs[method]=function(...args){if(match(...args))throw Object.assign(Error('Injected fixture '+method+' failure'),{code});return original.apply(this,args);};
  try{return fn();}finally{fs[method]=original;}
}

test('baseline reproduces a corrupt job aborting unrelated job recovery',()=>{
  const {root,records}=fixture('baseline',OriginalRecords);
  const preserved=snapshot([broken(root,'bad'),job(root,'good','1000000000000-aa')]);
  assert.throws(()=>records.recoverJobs(),/No readable revision/);
  assert.equal(records.get('jobs','good').status,'running');unchanged(preserved);
});

test('mixed corruption is reported while valid jobs are interrupted without replay',()=>{
  const {root,records}=fixture('mixed');
  const originals=[job(root,'fallback','1000000000000-aa','queued'),broken(root,'fallback'),broken(root,'unreadable'),job(root,'good','1000000000000-aa'),job(root,'complete','1000000000000-aa','complete')];
  const preserved=snapshot(originals),saved=[];const realSave=records.save.bind(records);
  records.save=(type,record)=>{saved.push({type,status:record.status});return realSave(type,record);};
  const changed=records.recoverJobs();
  assert(Array.isArray(changed));assert.deepEqual(changed.map(j=>j.id).sort(),['fallback','good']);
  assert.equal(changed.issues,records.recoveryIssues);assert.equal(changed.issues.length,2);
  assert.equal(changed.issues.find(i=>i.job==='fallback').code,'OLDER_REVISION_USED');
  assert.equal(changed.issues.find(i=>i.job==='fallback').invalidRevisions[0].code,'INVALID_JSON');
  assert.equal(changed.issues.find(i=>i.job==='unreadable').code,'NO_READABLE_REVISION');
  assert(changed.every(j=>j.status==='interrupted'&&j.input==='preserve exact input'));
  assert(saved.every(j=>j.type==='jobs'&&j.status==='interrupted'));
  assert.equal(records.get('jobs','complete').status,'complete');unchanged(preserved);
  const again=records.recoverJobs();assert.equal(again.length,0);assert.equal(again.issues.length,1);
});

test('job-directory enumeration failure is a structured issue, not success',()=>{
  const {root,records}=fixture('root-read');const dir=path.join(root,'data','jobs');
  const changed=withFailure('readdirSync',file=>file===dir,'EACCES',()=>records.recoverJobs());
  assert.equal(changed.length,0);assert.deepEqual(changed.issues.map(i=>[i.job,i.stage,i.code]),[[null,'enumerate','EACCES']]);
});

test('per-job filesystem read errors do not block unrelated recovery',()=>{
  const {root,records}=fixture('record-read');
  job(root,'denied','1000000000000-aa');job(root,'good','1000000000000-aa');
  const denied=path.join(root,'data','jobs','denied');
  const changed=withFailure('readdirSync',file=>file===denied,'EACCES',()=>records.recoverJobs());
  assert.deepEqual(changed.map(j=>j.id),['good']);
  assert.equal(changed.issues[0].job,'denied');assert.equal(changed.issues[0].code,'EACCES');
  assert.equal(records.get('jobs','denied').status,'running');
});

test('unreadable revision records its filesystem code and keeps input files',()=>{
  const {root,records}=fixture('revision-read');const denied=job(root,'denied','1000000000000-aa');job(root,'good','1000000000000-aa');
  const preserved=snapshot([denied]);
  const changed=withFailure('readFileSync',file=>file===denied,'EIO',()=>records.recoverJobs());
  assert.deepEqual(changed.map(j=>j.id),['good']);
  assert.equal(changed.issues[0].invalidRevisions[0].code,'EIO');unchanged(preserved);
});

test('save failure is visible and failed job is excluded from recovered count',()=>{
  const {root,records}=fixture('save');
  const denied=job(root,'denied','1000000000000-aa');job(root,'good','1000000000000-aa');
  const preserved=snapshot([denied]),dir=path.dirname(denied);
  const changed=withFailure('mkdirSync',file=>file===dir,'EACCES',()=>records.recoverJobs());
  assert.deepEqual(changed.map(j=>j.id),['good']);
  assert.deepEqual(changed.issues.map(i=>[i.job,i.stage,i.code]),[['denied','save','EACCES']]);unchanged(preserved);
});

test('post-write ledger failure retains evidence without claiming a completed recovery',()=>{
  const {root,records}=fixture('ledger');const original=job(root,'one','1000000000000-aa');const preserved=snapshot([original]);
  records.event=()=>{throw Object.assign(Error('Injected ledger storage failure'),{code:'ENOSPC'});};
  const changed=records.recoverJobs();assert.equal(changed.length,0);
  assert.equal(changed.issues[0].stage,'save');assert.equal(changed.issues[0].code,'ENOSPC');
  assert.equal(fs.readdirSync(path.dirname(original)).length,2);unchanged(preserved);
});

test('empty and invalid job directories are reported while completed jobs stay untouched',()=>{
  const {root,records}=fixture('shape');fs.mkdirSync(path.join(root,'data','jobs','empty'));
  fs.mkdirSync(path.join(root,'data','jobs','invalid.name'));
  const file=job(root,'complete','1000000000000-aa','complete');const preserved=snapshot([file]);
  const changed=records.recoverJobs();assert.equal(changed.length,0);
  assert.equal(changed.issues.find(i=>i.job==='empty').code,'NO_SAVED_REVISION');
  assert.equal(changed.issues.find(i=>i.job==='invalid.name').stage,'read');unchanged(preserved);
});

function conversation(root,id,revision,updatedAt='2026-01-01T00:00:00.000Z'){
  const dir=path.join(root,'data','conversations',id);fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,revision+'.json');
  fs.writeFileSync(file,JSON.stringify({id,revision,updatedAt,title:id,messages:[{role:'user',content:'original '+revision}]})+'\n',{flag:'wx'});
  return file;
}
function conversationBroken(root,id,revision){
  const dir=path.join(root,'data','conversations',id);fs.mkdirSync(dir,{recursive:true});
  const file=path.join(dir,revision+'.json');fs.writeFileSync(file,'{"id":',{flag:'wx'});return file;
}

test('explicit conversation listing retains valid neighbors and reports fallback without writes',()=>{
  const {root,records}=fixture('conversations');
  const originals=[
    conversation(root,'fallback','1000000000000-aa','2026-01-01T00:00:00.000Z'),
    conversationBroken(root,'fallback','1000000000001-bb'),
    conversationBroken(root,'unreadable','1000000000001-bb'),
    conversation(root,'neighbor','1000000000000-aa','2026-01-02T00:00:00.000Z'),
    conversation(root,'latest','1000000000000-aa','2026-01-01T00:00:00.000Z'),
    conversation(root,'latest','1000000000001-bb','2026-01-03T00:00:00.000Z')
  ];
  const preserved=snapshot(originals),listingBefore=fs.readdirSync(path.join(root,'data','conversations'),{recursive:true}).sort();
  records.save=()=>{throw Error('Listing must not save');};records.event=()=>{throw Error('Listing must not append ledger events');};
  const listed=withFailure('writeFileSync',()=>true,'NO_WRITES_ALLOWED',()=>records.listWithIssues('conversations'));
  assert.deepEqual(listed.records.map(r=>r.id),['latest','neighbor','fallback']);
  assert.equal(listed.records[0].revision,'1000000000001-bb');
  assert.equal(listed.records[2].revision,'1000000000000-aa');
  assert.equal(listed.issues.length,2);
  assert.equal(listed.issues.find(i=>i.record==='fallback').code,'OLDER_REVISION_USED');
  assert.equal(listed.issues.find(i=>i.record==='unreadable').code,'NO_READABLE_REVISION');
  assert(listed.issues.every(i=>i.type==='conversations'));
  assert.deepEqual(fs.readdirSync(path.join(root,'data','conversations'),{recursive:true}).sort(),listingBefore);unchanged(preserved);
  assert.throws(()=>records.list('conversations'),/No readable revision/,'legacy list contract remains unchanged');
});

test('explicit conversation listing reports filesystem access failures and preserves neighbors',()=>{
  const {root,records}=fixture('conversation-read');
  const denied=conversation(root,'denied','1000000000000-aa'),good=conversation(root,'good','1000000000000-aa');
  const preserved=snapshot([denied,good]);
  const listed=withFailure('readFileSync',file=>file===denied,'EACCES',()=>records.listWithIssues('conversations'));
  assert.deepEqual(listed.records.map(r=>r.id),['good']);
  assert.equal(listed.issues[0].record,'denied');assert.equal(listed.issues[0].invalidRevisions[0].code,'EACCES');unchanged(preserved);
});

test('explicit listing reports malformed ordering metadata instead of hiding readable data',()=>{
  const {root,records}=fixture('conversation-metadata');
  const missing=conversation(root,'missing','1000000000000-aa',null),good=conversation(root,'good','1000000000000-aa');
  const preserved=snapshot([missing,good]),listed=records.listWithIssues('conversations');
  assert.deepEqual(listed.records.map(r=>r.id),['good','missing']);assert.equal(listed.issues[0].code,'INVALID_UPDATE_TIME');unchanged(preserved);
  assert.throws(()=>records.listWithIssues('../ledger'),/Unsupported record type/);
});
