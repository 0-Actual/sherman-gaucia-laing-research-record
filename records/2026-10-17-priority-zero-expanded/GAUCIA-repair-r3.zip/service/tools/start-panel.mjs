// GAUCIA Actual: checked startup and read-only environment diagnosis.
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
import {randomUUID} from 'node:crypto';
import {pathToFileURL} from 'node:url';

const defaultRoot = path.resolve(import.meta.dirname, '..');
const legacyHold = './REDACTED_LOCAL_ROOT/QEL_Q7/SECURITY_ONLY_HOLD.json';
export class PanelError extends Error {
  constructor(code, message, exitCode = 1) { super(message); this.code = code; this.exitCode = exitCode; }
}
function sameWorkspace(a, b) {
  return typeof a === 'string' && path.resolve(a).toLowerCase() === path.resolve(b).toLowerCase();
}
function inspectFile(file, io) {
  try { const s = io.statSync(file); return {path:file, ok:s.isFile() && s.size > 0, bytes:s.size}; }
  catch (e) { return {path:file, ok:false, error:e.code || e.message}; }
}
export function inspectEnvironment(root = defaultRoot, io = fs) {
  root = path.resolve(root);
  const holds = [...new Set([path.resolve(root, '..', 'SECURITY_ONLY_HOLD.json'), legacyHold])].map(file => {
    try { io.lstatSync(file); return {path:file, state:'present'}; }
    catch (e) { return {path:file, state:e.code === 'ENOENT' ? 'absent' : 'unreadable', error:e.code === 'ENOENT' ? undefined : e.code || e.message}; }
  });
  let config, configError;
  try {
    config = JSON.parse(io.readFileSync(path.join(root, 'config.json'), 'utf8'));
    if (!config || typeof config !== 'object' || Array.isArray(config)) throw Error('Expected a configuration object');
    if (!Number.isSafeInteger(config.communicationPort ?? 17807) || (config.communicationPort ?? 17807) < 1 || (config.communicationPort ?? 17807) > 65535) throw Error('Invalid communication port');
    if (!Array.isArray(config.corpus) || config.corpus.some(f => typeof f !== 'string')) throw Error('Invalid research file list');
    for (const key of ['node','llama','model']) if (typeof config[key] !== 'string' || !config[key]) throw Error('Missing configured ' + key + ' path');
  } catch (e) { configError = e.message; }
  const required = ['communication.mjs','core.mjs','backend.mjs','engine/sgl-prime.mjs','engine/vendor/qel60_sop.mjs','governance/system-prompt.txt','../Communication_Audit_20260921_B01/turn-audit.mjs','../Communication_Audit_20260921_B01/watchdog.mjs'];
  const communicationFiles = required.map(f => inspectFile(path.resolve(root, f), io));
  const runtimeFiles = configError ? [] : ['node','llama','model'].map(kind => ({kind,...inspectFile(path.resolve(root, config[kind]), io)}));
  const researchFiles = configError ? [] : config.corpus.map(f => inspectFile(path.resolve(root, f), io));
  const blockedByHold = holds.some(h => h.state !== 'absent');
  return {
    schema:'GAUCIA_ENVIRONMENT_CHECK_V1', primaryAgent:'GAUCIA Actual', workspace:root,
    readOnly:true, serviceStarted:false, modelStarted:false, securityReleaseVerified:false,
    holds, blockedByHold, configError:configError || null,
    communicationPort:configError ? null : config.communicationPort ?? 17807,
    communicationFiles, runtimeFiles, researchFiles,
    communicationInputsPresent:!configError && communicationFiles.every(f => f.ok) && runtimeFiles.find(f => f.kind === 'node')?.ok === true,
    modelInputsPresent:!configError && runtimeFiles.filter(f => f.kind !== 'node').every(f => f.ok),
    researchInputsPresent:!configError && researchFiles.every(f => f.ok),
    verificationBoundary:'File presence and nonzero size only; no executable trust, corpus validity, model readiness, or whole-system security claim.'
  };
}
function requireNoHold(report) {
  const hold = report.holds.find(h => h.state !== 'absent');
  if (hold) throw new PanelError(hold.state === 'present' ? 'QEL_SECURITY_ONLY_HOLD' : 'QEL_HOLD_UNREADABLE',
    hold.state === 'present' ? 'GAUCIA startup is paused by the existing security hold: ' + hold.path : 'Cannot inspect the security hold (' + hold.error + '): ' + hold.path, 73);
}
export async function probePanel(root, url, fetchImpl = fetch, timeoutMs = 1500) {
  let response;
  try { response = await fetchImpl(url + '/health', {redirect:'error', signal:AbortSignal.timeout(Math.max(1, timeoutMs))}); }
  catch (e) {
    if (e?.cause?.code === 'ECONNREFUSED' || e?.code === 'ECONNREFUSED') return {absent:true};
    throw new PanelError('GAUCIA_HEALTH_UNAVAILABLE', 'The local service could not be checked: ' + (e.cause?.code || e.code || e.message) + '. No duplicate service was started.');
  }
  if (!response.ok) throw new PanelError('GAUCIA_PORT_OCCUPIED', 'The local port returned HTTP ' + response.status + '; no duplicate service was started.');
  let health;
  try { health = await response.json(); } catch { throw new PanelError('GAUCIA_HEALTH_INVALID', 'The local port returned an invalid health response.'); }
  if (health?.app !== 'GAUCIA_QEL_LOCAL_PANEL' || !sameWorkspace(health.workspace, root)) throw new PanelError('GAUCIA_WORKSPACE_MISMATCH', 'The running service does not identify this GAUCIA workspace. No other workspace was used.');
  if (health.ready !== true) throw new PanelError('GAUCIA_SERVICE_NOT_READY', 'GAUCIA reports that its audit or recovery state needs attention. Conversation startup was not marked ready.');
  return {ready:true, health};
}
export async function runPanel({root=defaultRoot, args=process.argv.slice(2), io=fs, fetchImpl=fetch, spawnImpl=spawn, now=Date.now, delay=ms=>new Promise(r=>setTimeout(r,ms)), output=console.log} = {}) {
  root = path.resolve(root);
  const report = inspectEnvironment(root, io);
  if (args.includes('--check')) { output(JSON.stringify(report, null, 2)); return {report, readOnly:true}; }
  requireNoHold(report);
  if (report.configError) throw new PanelError('GAUCIA_CONFIGURATION', report.configError);
  const url = 'http://127.0.0.1:' + report.communicationPort;
  let state = await probePanel(root, url, fetchImpl);
  if (!state.ready) {
    const missing = [...report.communicationFiles, ...report.runtimeFiles.filter(f=>f.kind === 'node')].filter(f=>!f.ok);
    if (missing.length) throw new PanelError('GAUCIA_DEPENDENCY_MISSING', 'Required GAUCIA files are missing or unreadable: ' + missing.map(f=>f.path + (f.error ? ' ('+f.error+')' : '')).join('; '));
    // Recheck immediately before writes/launch in case the owner placed a hold during diagnosis.
    requireNoHold(inspectEnvironment(root, io));
    io.mkdirSync(path.join(root, 'logs'), {recursive:true});
    const logPath = path.join(root, 'logs', 'communication-' + now() + '.log');
    const lockPath = path.join(root, 'logs', 'communication-start.lock.json');
    let lockFd, child, childError, exited = false, exitCode, lockToken;
    try {
      try { lockFd=io.openSync(lockPath,'wx'); }
      catch(e) { if(e.code!=='EEXIST')throw e; }
      if(lockFd!==undefined){
        lockToken=JSON.stringify({owner:randomUUID(),launcherPid:process.pid,workspace:root,at:new Date().toISOString()});
        io.writeFileSync(lockFd,lockToken);io.fsyncSync(lockFd);
        // The service may have appeared between the first check and lock acquisition.
        state=await probePanel(root,url,fetchImpl);
        if(!state.ready){
          const log=io.openSync(logPath,'a');
          try{
            child=spawnImpl(process.execPath,[path.join(root,'communication.mjs')],{cwd:root,detached:true,windowsHide:true,stdio:['ignore',log,log]});
            child.on('error',e=>{childError=e;});child.on('exit',code=>{exited=true;exitCode=code;});child.unref();
          }finally{io.closeSync(log);}
        }
      }
      const deadline=now()+80000;
      while(!state.ready && now()<deadline){
        if(childError)throw new PanelError('GAUCIA_SPAWN_FAILED','Could not start the communication service: '+childError.message);
        if(exited)throw new PanelError('GAUCIA_SERVICE_EXITED','The communication service exited ('+exitCode+'). Log: '+logPath);
        await delay(Math.min(500,Math.max(1,deadline-now())));
        if(now()>=deadline)break;
        state=await probePanel(root,url,fetchImpl,Math.min(1500,deadline-now()));
      }
      if(!state.ready)throw new PanelError('GAUCIA_START_TIMEOUT','The communication service did not become ready within 80 seconds. No second service was started. Inspect '+logPath+' and startup record '+lockPath+'.');
    }finally{
      if(lockFd!==undefined){
        io.closeSync(lockFd);
        // Keep an uncertain child/startup record for explicit inspection. Never
        // delete another launcher's record or retry an unknown running child.
        if(!child || childError || exited || state.ready){
          try{if(io.readFileSync(lockPath,'utf8')===lockToken)io.unlinkSync(lockPath);}catch(e){output('GAUCIA_START_RECORD_RETAINED '+lockPath+' ('+(e.code||e.message)+')');}
        }
      }
    }
  }
  output('GAUCIA_LOCAL_PANEL_READY ' + url);
  if (args.includes('--open')) {
    const choices = [path.join(process.env['ProgramFiles(x86)'] || './REDACTED_LOCAL_ROOT/Program Files (x86)','Microsoft','Edge','Application','msedge.exe'),path.join(process.env.ProgramFiles || './REDACTED_LOCAL_ROOT/Program Files','Microsoft','Edge','Application','msedge.exe')];
    const edge = choices.find(f=>io.existsSync(f));
    if (!edge) throw new PanelError('GAUCIA_RENDERER_MISSING', 'The existing Edge rendering engine was not found.');
    const window = spawnImpl(edge, ['--app='+url,'--no-first-run','--no-default-browser-check','--disable-background-networking'], {detached:true, windowsHide:false, stdio:'ignore'});
    window.on('error', e=>console.error('GAUCIA_RENDERER_START_FAILED: ' + e.message));
    window.unref();
    output('QEL_WINDOW_LAUNCH_REQUESTED');
  }
  return {ready:true, workspace:root, url};
}
if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  runPanel().catch(e=>{console.error((e.code || 'GAUCIA_START_FAILED') + ': ' + e.message); process.exitCode=e.exitCode || 1;});
}
