import test from 'node:test';
import assert from 'node:assert/strict';
import {Backend} from '../backend.mjs';
test('a stop-log failure does not prevent local cleanup and remains visible',()=>{
  let stopped=0;const b=new Backend('unused',{backendPort:17778},()=>{throw Error('disk unavailable');});
  b.child={pid:42,kill(){stopped++;return true;}};b.ready=true;
  assert.doesNotThrow(()=>b.stop());assert.equal(stopped,1);assert.equal(b.child,null);assert.equal(b.ready,false);
  assert.match(b.status().stopWarning,/disk unavailable/);
});
test('a failed process stop is not disguised as successful cleanup',()=>{
  const b=new Backend('unused',{backendPort:17778},()=>{});const child={pid:42,kill(){throw Error('process stop denied');}};
  b.child=child;b.ready=true;assert.throws(()=>b.stop(),/process stop denied/);assert.equal(b.child,child);assert.equal(b.ready,true);
});
