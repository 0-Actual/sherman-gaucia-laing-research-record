import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {EventEmitter} from 'node:events';
import * as core from '../core.mjs';

const base=path.resolve(import.meta.dirname,'../fixtures');fs.mkdirSync(base,{recursive:true});
function record(root,type,id,body,bad=false){const dir=path.join(root,'data',type,id);fs.mkdirSync(dir,{recursive:true});fs.writeFileSync(path.join(dir,'100-aaaa.json'),bad?'{malformed':JSON.stringify({id,revision:'100-aaaa',updatedAt:'2026-10-15T00:00:00Z',...body}));}
async function boot({damage=false, failLedger=false, failInterruptedSave=false}={}){
  const root=fs.mkdtempSync(path.join(base,'service-'));
  fs.mkdirSync(path.join(root,'governance'));fs.writeFileSync(path.join(root,'governance','system-prompt.txt'),'GAUCIA fixture policy');
  fs.writeFileSync(path.join(root,'config.json'),JSON.stringify({communicationPort:17807,corpus:[]}));
  record(root,'conversations','valid',{title:'Preserved conversation',messages:[{role:'user',content:'saved exact text'}]});
  if(damage){record(root,'jobs','broken',{},true);record(root,'conversations','damaged',{},true);}
  if(failInterruptedSave){record(root,'jobs','interrupted',{status:'running',conversation:'valid',message:'answer'});record(root,'conversations','valid',{title:'Preserved conversation',messages:[{id:'answer',role:'assistant',status:'running',content:'partial'}]});}
  let handler;let modelStarts=0;let modelStops=0;let childStarts=0;let failNextLedger=failLedger;const printed=[];
  const fakeProcess={pid:12345,env:{QEL_MONITOR_AUTOSTART:'0'},on(){},exit(){throw Error('unexpected exit');}};
  const fakeHttp={createServer(fn){handler=fn;return {on(){},listen(port,host,callback){assert.equal(host,'127.0.0.1');callback();},close(){}};}};
  class Audit {recover(){return [];}status(){return{requests:[],oldest:null};}close(){}event(){}receive(){throw Error('Unexpected job admission');}}
  class Backend {status(){return{state:'stopped'};}start(){modelStarts++;return Promise.resolve();}stop(){modelStops++;}generate(){throw Error('Unexpected generation');}}
  class TestRecords extends core.Records {
    event(kind,details){if(failNextLedger)throw Error('fixture ledger unavailable');return super.event(kind,details);}
    save(type,value){const saved=super.save(type,value);if(failInterruptedSave&&type==='conversations'&&value.id==='valid'){failInterruptedSave=false;throw Error('fixture ledger failed after revision write');}return saved;}
  }
  const testFs={...fs,lstatSync(file){if(String(file).endsWith('SECURITY_ONLY_HOLD.json'))throw Object.assign(Error('absent fixture hold'),{code:'ENOENT'});return fs.lstatSync(file);}};
  const context=vm.createContext({console:{log:x=>printed.push(x),error(){}},process:fakeProcess,URL,TextDecoder,Buffer,AbortController,setTimeout,clearTimeout,setImmediate});
  const imports={
    'node:http':{default:fakeHttp},'node:child_process':{spawn(){childStarts++;throw Error('Unexpected process launch');}},
    'node:url':{fileURLToPath:()=>assert.fail('monitor launch')},'node:fs':{default:testFs},'node:path':{default:path},
    'node:os':{default:{freemem:()=>512*1024**2}},'node:crypto':{randomBytes:crypto.randomBytes,randomUUID:crypto.randomUUID},
    'node:worker_threads':{Worker:class{constructor(){throw Error('Unexpected worker');}}},'./core.mjs':{...core,Records:TestRecords},
    './backend.mjs':{Backend},'./engine/sgl-prime.mjs':{hashBytes:b=>crypto.createHash('sha256').update(b).digest('hex')},
    '../Communication_Audit_20260921_B01/turn-audit.mjs':{TurnAudit:Audit}
  };
  const source=fs.readFileSync(path.resolve(import.meta.dirname,'../communication.mjs'),'utf8');
  const mod=new vm.SourceTextModule(source,{context,initializeImportMeta(meta){meta.dirname=root;meta.url=new URL('file:///'+path.join(root,'communication.mjs').replaceAll('\\','/')).href;}});
  await mod.link(name=>{const values=imports[name];assert.ok(values,'Unexpected import '+name);return new vm.SyntheticModule(Object.keys(values),function(){for(const[k,v]of Object.entries(values))this.setExport(k,v);},{context});});
  await mod.evaluate();
  async function request(route,method='GET',session){
    const res=new EventEmitter();res.headersSent=false;res.writeHead=(status,headers)=>{res.status=status;res.headers=headers;res.headersSent=true;};res.end=body=>{res.body=body?JSON.parse(body):null;};
    const req={url:route,method,headers:{host:'127.0.0.1:17807',...(session?{'x-qel-session':session}:{})},async *[Symbol.asyncIterator](){yield Buffer.from('{}');}};
    await handler(req,res);return res;
  }
  const session=(await request('/session')).body.session;
  return{root,request:(route,method)=>request(route,method,session),printed,modelStarts:()=>modelStarts,modelStops:()=>modelStops,childStarts:()=>childStarts,failLedger:()=>{failNextLedger=true;}};
}
test('corrupt saved records leave valid history readable and make health/status explicitly unready',async()=>{
  const app=await boot({damage:true});
  const health=await app.request('/health');assert.equal(health.body.ready,false);assert.equal(health.body.workspace,app.root);assert.equal(health.body.primaryAgent,'GAUCIA Actual');
  const status=await app.request('/api/status');assert.equal(status.body.ready,false);assert.ok(status.body.recoveryIssues.length>=2);
  const list=await app.request('/api/conversations');assert.equal(list.status,200);assert.deepEqual(list.body.map(c=>c.id),['valid']);
  const detail=await app.request('/api/conversation?id=valid');assert.equal(detail.body.messages[0].content,'saved exact text');
  for(const file of ['data/jobs/broken/100-aaaa.json','data/conversations/damaged/100-aaaa.json'])assert.equal(fs.readFileSync(path.join(app.root,file),'utf8'),'{malformed');
  assert.equal(JSON.parse(app.printed[0]).ready,false);
});
test('recovery trouble blocks all new work while still allowing cleanup',async()=>{
  const app=await boot({damage:true});const before=fs.readdirSync(path.join(app.root,'data','conversations'));
  for(const route of ['/api/new','/api/model/start','/api/message','/api/reindex','/api/export']){
    const r=await app.request(route,'POST');assert.equal(r.status,503,route);assert.equal(r.body.notAdmitted,true);
  }
  assert.deepEqual(fs.readdirSync(path.join(app.root,'data','conversations')),before);
  assert.equal((await app.request('/api/stop','POST')).status,200);assert.equal((await app.request('/api/model/stop','POST')).status,200);
  assert.equal(app.modelStarts(),0);assert.equal(app.childStarts(),0);
});
test('healthy fixture retains normal new-conversation behavior and identifies its workspace',async()=>{
  const app=await boot();const health=await app.request('/health');assert.equal(health.body.ready,true);assert.equal(health.body.workspace,app.root);
  const created=await app.request('/api/new','POST');assert.equal(created.status,201);assert.equal(created.body.messages.length,0);
  assert.equal((await app.request('/api/status')).body.primaryAgent,'GAUCIA Actual');assert.equal(app.modelStarts(),0);assert.equal(app.childStarts(),0);
});
test('failure after an interrupted conversation revision write remains an explicit readiness failure',async()=>{
  const app=await boot({failInterruptedSave:true});
  assert.equal((await app.request('/health')).body.ready,false);
  const status=(await app.request('/api/status')).body;
  assert.ok(status.recoveryIssues.some(x=>x.stage==='interrupted-conversation'));
  assert.equal((await app.request('/api/conversation?id=valid')).body.messages[0].content,'partial');
});
test('Stop and model stop remain possible when authorization logging fails',async()=>{
  const app=await boot({damage:true});app.failLedger();
  const stop=await app.request('/api/stop','POST');assert.equal(stop.status,200);assert.match(stop.body.auditWarning,/could not be recorded/);
  const model=await app.request('/api/model/stop','POST');assert.equal(model.status,200);assert.equal(app.modelStops(),1);
  assert.match(model.body.auditWarning,/could not be recorded/);assert.equal(app.modelStarts(),0);
  assert.equal((await app.request('/api/new','POST')).status,503);
});
