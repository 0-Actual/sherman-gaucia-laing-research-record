import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {Library} from '../core.mjs';
import {Library as BaselineLibrary} from '../../baseline/core-before-library.mjs';

const fixtureRoot=path.join(import.meta.dirname,'fixtures');
fs.mkdirSync(fixtureRoot,{recursive:true});
function fixture(label,files,Constructor=Library){
  const root=fs.mkdtempSync(path.join(fixtureRoot,label+'-'));
  const before=new Map();
  for(const [name,rows] of Object.entries(files)){
    const file=path.join(root,name),bytes=Buffer.from(rows.map(row=>typeof row==='string'?row:JSON.stringify(row)).join('\n')+'\n');
    fs.writeFileSync(file,bytes,{flag:'wx'});before.set(file,bytes);
  }
  return {root,library:new Constructor(root,Object.keys(files)),before};
}
function preserved(before){
  for(const [file,bytes] of before)assert.deepEqual(fs.readFileSync(file),bytes,'Library read changed '+file);
}
const alpha={record_id:'alpha',origin_path:'./REDACTED_LOCAL_ROOT/fixture\\notes.txt',chunk_start_utf16:0,text:'amber stone',relative_path:'notes.txt',speaker:'owner',training_approved:false};
const beta={...alpha,record_id:'beta',text:'cobalt rock'};

test('baseline reproduces loss of distinct equal-length text at the same source offset',()=>{
  assert.equal(alpha.text.length,beta.text.length);
  const {library,before}=fixture('baseline',{'notes.jsonl':[alpha,beta]},BaselineLibrary);
  assert.equal(library.rows.length,1);
  assert.equal(library.search('cobalt').length,0);
  preserved(before);
});

test('distinct equal-length text survives and is independently searchable with its attribution',()=>{
  const {root,library,before}=fixture('distinct',{'notes.jsonl':[alpha,beta]});
  assert.deepEqual(library.rows.map(row=>row.text),[alpha.text,beta.text]);
  assert.deepEqual(library.rows.map(row=>[row.originalId,row.origin,row.sourceFile,row.sourceLine,row.speaker,row.trainingApproved]),[
    ['alpha',alpha.origin_path,path.join(root,'notes.jsonl'),1,'owner',false],
    ['beta',beta.origin_path,path.join(root,'notes.jsonl'),2,'owner',false]
  ]);
  assert.equal(library.search('amber')[0].id,'source-0');
  assert.equal(library.search('cobalt')[0].id,'source-1');
  assert.deepEqual(library.summary().errors,[]);
  const first=library.rows.map(row=>({...row}));
  library.reload();assert.deepEqual(library.rows,first);preserved(before);
});

test('exact duplicates at the same declared source offset retain the first source attribution',()=>{
  const duplicate={...alpha,record_id:'later-id',relative_path:'alternate.txt',speaker:'assistant',training_approved:true};
  const {root,library,before}=fixture('duplicate',{'first.jsonl':[alpha,alpha],'second.jsonl':[duplicate]});
  assert.equal(library.rows.length,1);
  assert.equal(library.rows[0].originalId,'alpha');
  assert.equal(library.rows[0].title,'notes.txt');
  assert.equal(library.rows[0].speaker,'owner');
  assert.equal(library.rows[0].trainingApproved,false);
  assert.equal(library.rows[0].sourceFile,path.join(root,'first.jsonl'));
  assert.equal(library.rows[0].sourceLine,1);preserved(before);
});

test('same text at different source paths or offsets remains separate',()=>{
  const {library,before}=fixture('attribution',{'notes.jsonl':[alpha,{...alpha,chunk_start_utf16:20},{...alpha,origin_path:'./REDACTED_LOCAL_ROOT/fixture\\other.txt'}]});
  assert.equal(library.rows.length,3);
  assert.equal(library.summary().sourceFiles,2);preserved(before);
});

test('missing origin uses the actual source file and never merges unrelated files',()=>{
  const row={text:'archive evidence'};
  const {root,library,before}=fixture('missing-origin',{'first.jsonl':[row,row],'second.jsonl':[row]});
  assert.equal(library.rows.length,2);
  assert.deepEqual(library.rows.map(r=>r.origin),[path.join(root,'first.jsonl'),path.join(root,'second.jsonl')]);
  assert.deepEqual(library.rows.map(r=>r.sourceLine),[1,1]);preserved(before);
});

test('malformed entries are reported without suppressing valid neighboring records',()=>{
  const {library,before}=fixture('malformed',{'notes.jsonl':['{"text":',alpha,{origin_path:'bad'},beta]});
  assert.deepEqual(library.rows.map(r=>r.originalId),['alpha','beta']);
  assert.deepEqual(library.errors.map(e=>e.line),[1,3]);preserved(before);
});
