import test from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import {EventEmitter} from 'node:events';
import {inspectEnvironment, probePanel, runPanel} from '../tools/start-panel.mjs';

const root=path.resolve(import.meta.dirname,'fixtures','GAUCIA');
const missing=()=>Object.assign(Error('missing'),{code:'ENOENT'});
const refused=()=>Promise.reject(Object.assign(Error('fetch failed'),{cause:{code:'ECONNREFUSED'}}));
const response=(changes={})=>({ok:true,status:200,json:async()=>({app:'GAUCIA_QEL_LOCAL_PANEL',ready:true,workspace:root,...changes})});
function fixture({hold=false, unreadable=false, missingFile='', configuredPort=17807}={}) {
  const writes=[], calls=[], output=[], files=new Map(),handles=new Map(); let time=0,nextFd=10;
  const io={
    lstatSync(file){if(unreadable)throw Object.assign(Error('denied'),{code:'EACCES'});if(hold && file.endsWith('SECURITY_ONLY_HOLD.json'))return{};throw missing();},
    statSync(file){if(missingFile && file.endsWith(missingFile))throw missing();return{isFile:()=>true,size:10};},
    readFileSync(file){return file.endsWith('config.json')?JSON.stringify({communicationPort:configuredPort,corpus:['research.jsonl'],node:'runtime/node.exe',llama:'runtime/llama.exe',model:'model.gguf'}):files.get(file);},
    mkdirSync(file){writes.push(['mkdir',file]);},openSync(file,flag){if(flag==='wx'&&files.has(file))throw Object.assign(Error('exists'),{code:'EEXIST'});const fd=nextFd++;handles.set(fd,file);files.set(file,'');writes.push(['open',file]);return fd;},
    writeFileSync(fd,text){files.set(handles.get(fd),text);writes.push(['write',fd]);},fsyncSync(){},unlinkSync(file){files.delete(file);writes.push(['unlink',file]);},closeSync(fd){writes.push(['close',fd]);},existsSync(){return true;}
  };
  const child=new EventEmitter();child.unref=()=>{};
  const options={root,io,args:[],now:()=>time,delay:async ms=>{time+=ms;},output:s=>output.push(s),spawnImpl:(...args)=>{calls.push(args);return child;}};
  return{options,io,writes,calls,output,child,files,time:()=>time};
}
test('read-only diagnosis works during a hold without network, process launch, or writes', async()=>{
  const f=fixture({hold:true});
  const r=await runPanel({...f.options,args:['--check'],fetchImpl:()=>assert.fail('network')});
  assert.equal(r.report.primaryAgent,'GAUCIA Actual');assert.equal(r.report.blockedByHold,true);
  assert.equal(r.report.serviceStarted,false);assert.equal(r.report.securityReleaseVerified,false);
  assert.equal(f.calls.length,0);assert.equal(f.writes.length,0);assert.equal(JSON.parse(f.output[0]).readOnly,true);
});
test('ordinary startup preserves both active and unreadable holds without side effects', async()=>{
  for(const settings of [{hold:true},{unreadable:true}]){
    const f=fixture(settings);
    await assert.rejects(runPanel({...f.options,fetchImpl:()=>assert.fail('network')}),e=>e.exitCode===73);
    assert.equal(f.calls.length,0);assert.equal(f.writes.length,0);
  }
});
test('ready service must identify this workspace; false readiness and foreign/unknown identity are rejected', async()=>{
  for(const change of [{ready:false},{workspace:path.resolve(root,'other')},{workspace:undefined},{app:'other'}]){
    const f=fixture();
    await assert.rejects(runPanel({...f.options,fetchImpl:async()=>response(change)}),e=>/NOT_READY|MISMATCH/.test(e.code));
    assert.equal(f.calls.length,0);assert.equal(f.writes.length,0);assert.equal(f.output.length,0);
  }
  const f=fixture();const r=await runPanel({...f.options,fetchImpl:async()=>response()});
  assert.equal(r.ready,true);assert.equal(f.calls.length,0);assert.equal(f.writes.length,0);
});
test('only connection refusal permits a start; denial, timeout, HTTP failures and invalid bodies do not', async()=>{
  for(const fetchImpl of [async()=>{throw Object.assign(Error('timeout'),{name:'TimeoutError'});},async()=>{throw Object.assign(Error('denied'),{cause:{code:'EACCES'}});},async()=>({ok:false,status:403}),async()=>({ok:true,json:async()=>{throw Error('bad JSON');}})]){
    const f=fixture();await assert.rejects(runPanel({...f.options,fetchImpl}));assert.equal(f.calls.length,0);assert.equal(f.writes.length,0);
  }
});
test('absent required audit dependency is named before a launch or log write',async()=>{
  const f=fixture({missingFile:'turn-audit.mjs'});
  await assert.rejects(runPanel({...f.options,fetchImpl:refused}),e=>e.code==='GAUCIA_DEPENDENCY_MISSING'&&e.message.includes('turn-audit.mjs'));
  assert.equal(f.calls.length,0);assert.equal(f.writes.length,0);
});
test('one helper launch reaches this workspace and uses its configured port',async()=>{
  const f=fixture({configuredPort:17809});let checks=0;
  const r=await runPanel({...f.options,fetchImpl:async url=>{assert.equal(url,'http://127.0.0.1:17809/health');return ++checks<4?refused():response();}});
  assert.equal(r.ready,true);assert.equal(f.calls.length,1);assert.equal(f.calls[0][2].windowsHide,true);
  assert.equal(f.writes.filter(x=>x[0]==='close').length,2);
  assert.equal(f.files.has(path.join(root,'logs','communication-start.lock.json')),false);
});
test('spawn and early-exit failures are observed without declaring ready',async()=>{
  for(const event of ['error','exit']){
    const f=fixture();const delay=f.options.delay;
    f.options.delay=async ms=>{await delay(ms);f.child.emit(event,event==='error'?Error('spawn denied'):42);};
    await assert.rejects(runPanel({...f.options,fetchImpl:refused}),e=>/SPAWN_FAILED|SERVICE_EXITED/.test(e.code));
    assert.equal(f.calls.length,1);assert.equal(f.output.length,0);
  }
});
test('readiness wait has an 80-second total budget with no duplicate spawn',async()=>{
  const f=fixture();await assert.rejects(runPanel({...f.options,fetchImpl:refused}),e=>e.code==='GAUCIA_START_TIMEOUT');
  assert.equal(f.time(),80000);assert.equal(f.calls.length,1);assert.equal(f.output.length,0);
  assert.equal(f.files.has(path.join(root,'logs','communication-start.lock.json')),true);
});
test('simultaneous launchers share startup coordination and spawn once',async()=>{
  const f=fixture();let checks=0;
  const fetchImpl=async()=>++checks<5?refused():response();
  const results=await Promise.all([runPanel({...f.options,fetchImpl}),runPanel({...f.options,fetchImpl})]);
  assert.ok(results.every(r=>r.ready));assert.equal(f.calls.length,1);
});
test('an existing uncertain startup record is retained and does not permit another child',async()=>{
  const f=fixture(),lock=path.join(root,'logs','communication-start.lock.json');f.files.set(lock,'existing evidence');
  await assert.rejects(runPanel({...f.options,fetchImpl:refused}),e=>e.code==='GAUCIA_START_TIMEOUT');
  assert.equal(f.calls.length,0);assert.equal(f.files.get(lock),'existing evidence');
});
test('configuration and file presence are distinct from security completion and model readiness',()=>{
  const f=fixture({missingFile:'model.gguf'});const r=inspectEnvironment(root,f.io);
  assert.equal(r.communicationInputsPresent,true);assert.equal(r.modelInputsPresent,false);assert.equal(r.modelStarted,false);
  assert.equal(r.securityReleaseVerified,false);assert.equal(f.writes.length,0);
  const invalid=fixture({configuredPort:70000});assert.match(inspectEnvironment(root,invalid.io).configError,/port/);
});
