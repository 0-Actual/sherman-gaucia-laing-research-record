import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import crypto from 'node:crypto';
import {EventEmitter} from 'node:events';
import * as core from '../core.mjs';

const base=path.join(import.meta.dirname,'fixtures');fs.mkdirSync(base,{recursive:true});
const flush=()=>new Promise(resolve=>setImmediate(resolve));
async function boot({baseline=false}={}){
  const root=fs.mkdtempSync(path.join(base,baseline?'baseline-':'fixed-'));
  fs.mkdirSync(path.join(root,'governance'));fs.writeFileSync(path.join(root,'governance','system-prompt.txt'),'Fixture policy');
  fs.writeFileSync(path.join(root,'config.json'),JSON.stringify({communicationPort:17807,corpus:[],modelLabel:'Fixture'}));
  const observations={exits:[],events:[],errors:[],modelStops:0,childStarts:0};
  const listeners=new Map(),timers=new Map();let timerId=0;
  let handler,rejectGeneration,failSaves=false,failStop=false;
  class Records extends core.Records {
    save(type,value){if(failSaves&&type==='conversations')throw Error('fixture storage unavailable');const saved=super.save(type,value);observations.events.push({kind:'save',type,value:saved});return saved;}
  }
  class Audit {
    constructor(){this.requests=[];}recover(){return [];}status(){return{requests:this.requests,oldest:null};}close(){}
    receive(id,request){const r={id,request,state:'RECEIVED',receipt:'fixture'};this.requests.push(r);return r;}
    event(id,kind,details){observations.events.push({kind:'audit',id,event:kind,details});const r=this.requests.find(r=>r.id===id);if(r)r.state=kind;}
  }
  class Backend {
    status(){return{state:'fixture'};}start(){throw Error('Unexpected model start');}
    stop(){observations.modelStops++;if(failStop)throw Error('fixture kill denied');}
    generate(messages,onToken,signal){
      observations.events.push({kind:'generate',signal});onToken('newest partial reply');
      return new Promise((resolve,reject)=>{rejectGeneration=()=>reject(Object.assign(Error('stopped fixture'),{content:'newest partial reply'}));});
    }
  }
  const fakeProcess={pid:12345,env:{QEL_MONITOR_AUTOSTART:'0'},on(event,fn){listeners.set(event,fn);},exit(code){observations.exits.push({code,events:observations.events.slice()});}};
  const fakeHttp={createServer(fn){handler=fn;return{on(){},listen(port,host,callback){callback();},close(callback){observations.events.push({kind:'server-close'});callback();},closeIdleConnections(){}};}};
  const fakeFs={...fs,lstatSync(file){if(String(file).endsWith('SECURITY_ONLY_HOLD.json'))throw Object.assign(Error('fixture hold absent'),{code:'ENOENT'});return fs.lstatSync(file);}};
  const context=vm.createContext({console:{log(){},error(...args){observations.errors.push(args.join(' '));}},process:fakeProcess,URL,TextDecoder,Buffer,AbortController,setImmediate,
    setTimeout(fn,ms){const id=++timerId;timers.set(id,{fn,ms});return id;},clearTimeout(id){timers.delete(id);}});
  const imports={
    'node:http':{default:fakeHttp},'node:child_process':{spawn(){observations.childStarts++;throw Error('No real process permitted');}},
    'node:url':{fileURLToPath:()=>assert.fail('No monitor launch permitted')},'node:fs':{default:fakeFs},'node:path':{default:path},
    'node:os':{default:{freemem:()=>512*1024**2}},'node:crypto':{randomBytes:crypto.randomBytes,randomUUID:crypto.randomUUID},
    'node:worker_threads':{Worker:class{constructor(){throw Error('No worker permitted');}}},'./core.mjs':{...core,Records},
    './backend.mjs':{Backend},'./engine/sgl-prime.mjs':{hashBytes:b=>crypto.createHash('sha256').update(b).digest('hex')},
    '../Communication_Audit_20260921_B01/turn-audit.mjs':{TurnAudit:Audit}
  };
  const source=fs.readFileSync(path.join(import.meta.dirname,baseline?'../../baseline/communication-before-shutdown.mjs':'../communication.mjs'),'utf8');
  const module=new vm.SourceTextModule(source,{context,initializeImportMeta(meta){meta.dirname=root;meta.url=new URL('file:///'+path.join(root,'communication.mjs').replaceAll('\\','/')).href;}});
  await module.link(name=>{const values=imports[name];assert.ok(values,'Unexpected import '+name);return new vm.SyntheticModule(Object.keys(values),function(){for(const[k,v]of Object.entries(values))this.setExport(k,v);},{context});});
  await module.evaluate();
  let session;
  async function request(route,method='GET',body={}){
    const res=new EventEmitter();res.headersSent=false;res.writeHead=(status)=>{res.status=status;res.headersSent=true;};res.end=value=>{res.body=value?JSON.parse(value):null;};
    const req={url:route,method,headers:{host:'127.0.0.1:17807',...(session?{'x-qel-session':session}:{})},async *[Symbol.asyncIterator](){yield Buffer.from(JSON.stringify(body));}};
    await handler(req,res);return res;
  }
  session=(await request('/session')).body.session;
  return {root,observations,request,signal:()=>listeners.get('SIGTERM')(),failSaves:()=>{failSaves=true;},failStop:value=>{failStop=value;},release:()=>rejectGeneration(),
    fireTimer(ms){for(const[id,timer]of timers)if(timer.ms===ms){timers.delete(id);timer.fn();return true;}return false;},
    async beginMessage(){const created=await request('/api/new','POST');const admitted=await request('/api/message','POST',{id:created.body.id,text:'fixture message',requestId:'fixture-request'});assert.equal(admitted.status,202);return created.body.id;},
    readConversation(id){return new core.Records(root,b=>crypto.createHash('sha256').update(b).digest('hex')).get('conversations',id);}
  };
}

test('baseline reproduction: signal exits before the latest partial reply is checkpointed',async()=>{
  const app=await boot({baseline:true});const id=await app.beginMessage();await flush();
  app.signal();assert.equal(app.observations.exits.length,1);
  assert.equal(app.readConversation(id).messages.at(-1).content,'');
  app.release();await flush();
});
test('signal waits for aborted work to save latest partial and terminal metadata before exit',async()=>{
  const app=await boot();const id=await app.beginMessage();await flush();
  const closing=app.signal();assert.equal(app.observations.exits.length,0);
  assert.equal((await app.request('/health')).body.ready,false);
  assert.equal((await app.request('/api/status')).body.ready,false);
  assert.equal((await app.request('/api/new','POST')).status,409);
  app.release();await closing;
  assert.equal(app.observations.exits.length,1);
  const saved=app.readConversation(id);assert.equal(saved.messages.at(-1).content,'newest partial reply');assert.equal(saved.messages.at(-1).status,'stopped');
  const exit=app.observations.exits[0];assert.ok(exit.events.some(e=>e.kind==='audit'&&e.event==='FAILED'));assert.equal(app.observations.childStarts,0);
});
test('signal before the queued work starts still waits for its saved stopped outcome',async()=>{
  const app=await boot();const id=await app.beginMessage();
  const closing=app.signal();assert.equal(app.observations.exits.length,0);await closing;
  assert.equal(app.observations.exits.length,1);assert.equal(app.readConversation(id).messages.at(-1).status,'stopped');
  assert.ok(!app.observations.events.some(e=>e.kind==='generate'));
});
test('checkpoint timeout keeps service open and new work blocked; later completed save permits quit',async()=>{
  const app=await boot();const id=await app.beginMessage();await flush();
  const closing=app.signal();assert.equal(app.fireTimer(10000),true);await closing;
  assert.equal(app.observations.exits.length,0);assert.equal((await app.request('/api/new','POST')).status,409);
  assert.equal((await app.request('/health')).body.ready,false);
  assert.ok(app.observations.errors.some(x=>x.includes('save checkpoint')));
  app.release();await flush();assert.equal(app.readConversation(id).messages.at(-1).content,'newest partial reply');
  const retry=await app.request('/api/quit','POST');assert.equal(retry.status,200);assert.equal(retry.body.stopping,true);
  assert.equal(app.fireTimer(150),true);assert.equal(app.observations.exits.length,1);
});
test('a failed checkpoint never reports successful shutdown or exits',async()=>{
  const app=await boot();await app.beginMessage();await flush();app.failSaves();
  const closing=app.signal();app.release();await closing;
  assert.equal(app.observations.exits.length,0);
  const retry=await app.request('/api/quit','POST');assert.equal(retry.status,503);assert.equal(retry.body.stopping,false);assert.match(retry.body.error,/could not be fully saved/);
});
test('model stop failure is returned before a quit acknowledgement and cleanup can be retried',async()=>{
  const app=await boot();app.failStop(true);
  const first=await app.request('/api/quit','POST');assert.equal(first.status,503);assert.equal(first.body.stopping,false);assert.match(first.body.error,/model could not be stopped/);
  assert.equal(app.observations.exits.length,0);assert.equal((await app.request('/api/new','POST')).status,409);
  app.failStop(false);const retry=await app.request('/api/quit','POST');assert.equal(retry.status,200);assert.equal(retry.body.stopping,true);app.fireTimer(150);assert.equal(app.observations.exits.length,1);
});
test('overlapping signals share one stop/checkpoint and close the service once',async()=>{
  const app=await boot();await app.beginMessage();await flush();const one=app.signal(),two=app.signal();
  assert.equal(app.observations.modelStops,1);app.release();await Promise.all([one,two]);assert.equal(app.observations.exits.length,1);
});
