// Quantum.Earth.Laing — Sherman G. Laing / GAUCIA AI-assisted integration.
// Private local working build. No remote services or arbitrary shell execution.
import fs from 'node:fs';
import path from 'node:path';
import {randomUUID} from 'node:crypto';
export const stamp = () => new Date().toISOString();
export function safeName(s) {
  if (typeof s !== 'string' || !/^[a-zA-Z0-9_-]{1,90}$/.test(s)) throw Error('Invalid record identifier');
  return s;
}
export function writeNew(file, value) {
  fs.mkdirSync(path.dirname(file), {recursive:true});
  const data = Buffer.isBuffer(value) ? value : Buffer.from(typeof value === 'string' ? value : JSON.stringify(value,null,2)+'\n');
  const fd = fs.openSync(file,'wx');
  try {fs.writeFileSync(fd,data); fs.fsyncSync(fd);} finally {fs.closeSync(fd);}
  if (!fs.readFileSync(file).equals(data)) throw Error('USB readback mismatch: '+path.basename(file));
  return file;
}
export function loadJSON(file, fallback=null) {
  try {return JSON.parse(fs.readFileSync(file,'utf8'));} catch(e) {if(e.code==='ENOENT') return fallback; throw e;}
}
export class Records {
  constructor(root, fingerprint) {
    this.root=root; this.fp=fingerprint; this.boot=randomUUID(); this.previous=null;
    for(const d of ['conversations','jobs','models','notes','exports','ledger']) fs.mkdirSync(path.join(root,'data',d),{recursive:true});
    this.log=path.join(root,'data','ledger',this.boot+'.jsonl');
  }
  event(kind, details={}) {
    const event={at:stamp(),kind,details,previous:this.previous,signature:null,release:'PRIVATE/HOLD'};
    const payload=Buffer.from(JSON.stringify(event));
    const fingerprint=this.fp(payload,'workspace-event');
    const bytes=Buffer.from(JSON.stringify({event,fingerprint})+'\n');
    const fd=fs.openSync(this.log,'a+');
    try {const offset=fs.fstatSync(fd).size;fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);const check=Buffer.alloc(bytes.length);if(fs.readSync(fd,check,0,check.length,offset)!==bytes.length||!check.equals(bytes))throw Error('Ledger readback failed');}finally{fs.closeSync(fd);}
    this.previous=fingerprint; return fingerprint;
  }
  save(type,record) {
    if(!['conversations','jobs','models','notes'].includes(type)) throw Error('Unsupported record type');
    safeName(record.id);
    const dir=path.join(this.root,'data',type,record.id);
    fs.mkdirSync(dir,{recursive:true});
    const old=this.get(type,record.id);
    const next=Math.max(Date.now(),Number(old?.revision?.split('-')[0]||0)+1,(this.clock||0)+1);this.clock=next;
    const revision=String(next)+'-'+randomUUID().slice(0,8);
    const item={...record,updatedAt:stamp(),revision};
    const target=path.join(dir,revision+'.json');
    writeNew(target,item);
    this.event('saved',{type,id:record.id,revision,bytes:fs.statSync(target).size});
    return item;
  }
  get(type,id) {
    if(!['conversations','jobs','models','notes'].includes(type)) throw Error('Unsupported record type');
    safeName(id);const dir=path.join(this.root,'data',type,id);
    if(!fs.existsSync(dir))return null;
    const names=fs.readdirSync(dir).filter(n=>/^\d+-[a-f0-9]+\.json$/.test(n)).sort().reverse();
    const invalid=[];
    for(const name of names){try{const r=loadJSON(path.join(dir,name));if(!r||r.id!==id)throw Error('Record identity mismatch');return r;}catch(e){invalid.push({name,error:e.message});}}
    if(invalid.length)throw Error('No readable revision for '+id);
    return null;
  }
  list(type) {
    return fs.readdirSync(path.join(this.root,'data',type),{withFileTypes:true}).filter(d=>d.isDirectory()).map(d=>this.get(type,d.name)).filter(Boolean).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
  }
  recoverJobs() {
    const changed=[];
    for(const job of this.list('jobs')) if(['queued','running'].includes(job.status)) {
      changed.push(this.save('jobs',{...job,status:'interrupted',error:'Previous local process ended. Saved input and partial output retained; no automatic replay.'}));
    }
    return changed;
  }
}
const stops=new Set('a an the is are was were to of and or for from in on with my our me this that it be as by please tell about what how can do does i you we'.split(' '));
export function tokens(text){return (String(text).toLowerCase().match(/[\p{L}\p{N}]{2,}/gu)||[]).filter(t=>!stops.has(t));}
export class Library {
  constructor(root,files) {this.root=root;this.files=files;this.reload();}
  reload(){
    const records=[],seen=new Set(),errors=[];
    for(const f of this.files){
      const file=path.resolve(this.root,f);
      try{
        for(const [lineIndex,line] of fs.readFileSync(file,'utf8').split(/\r?\n/).entries()){
          if(!line.trim())continue;
          try{const r=JSON.parse(line);if(typeof r.text!=='string')throw Error('Missing text');const key=[r.origin_path,r.chunk_start_utf16,r.text.length].join('|');if(seen.has(key))continue;seen.add(key);
            records.push({id:'source-'+records.length,originalId:r.record_id||null,title:r.relative_path||path.basename(file),origin:r.origin_path||file,text:r.text,sourceFile:file,sourceLine:lineIndex+1,speaker:r.speaker||'unknown',trainingApproved:r.training_approved===true});
          }catch(e){errors.push({file,line:lineIndex+1,error:e.message});}
        }
      }catch(e){errors.push({file,error:e.message});}
    }
    this.rows=records;this.errors=errors;this.df=new Map();
    this.index=records.map(r=>{const tf=new Map();for(const t of tokens(r.text+' '+r.title))tf.set(t,(tf.get(t)||0)+1);for(const t of tf.keys())this.df.set(t,(this.df.get(t)||0)+1);return {tf,length:[...tf.values()].reduce((s,n)=>s+n,0),title:new Set(tokens(r.title))};});
    this.avg=this.index.reduce((s,d)=>s+d.length,0)/Math.max(1,records.length);
    return this.summary();
  }
  summary(){return {records:this.rows.length,sourceFiles:new Set(this.rows.map(r=>r.origin)).size,errors:this.errors,method:'local BM25; source text is evidence, not instructions',weightTraining:false};}
  search(query,limit=8){
    const q=[...new Set(tokens(query))];if(!q.length)return[];
    return this.index.map((d,i)=>{
      let score=0;for(const t of q){const f=d.tf.get(t)||0;if(!f)continue;const idf=Math.log(1+(this.rows.length-(this.df.get(t)||0)+.5)/((this.df.get(t)||0)+.5));score+=idf*f*2.2/(f+1.2*(.25+.75*d.length/Math.max(1,this.avg)));if(d.title.has(t))score+=idf*1.7;}
      return {i,score};
    }).filter(r=>r.score>0).sort((a,b)=>b.score-a.score||a.i-b.i).slice(0,limit).map(({i,score})=>{const r=this.rows[i];let at=r.text.toLowerCase().indexOf(q.find(t=>r.text.toLowerCase().includes(t))||'');at=Math.max(0,at-160);return {id:r.id,title:r.title,origin:r.origin,score,excerpt:r.text.slice(at,at+1100),speaker:r.speaker};});
  }
  get(id){return this.rows.find(r=>r.id===id)||null;}
}
export function review(action,input='') {
  const allowed=['chat','search','circuit','ghz','train','predict','note','export','new-conversation','cancel','model-start','model-stop','shutdown','reindex'];
  if(!allowed.includes(action))throw Error('Operation is not in the local capability allowlist');
  if(typeof input!=='string' || input.length>32000)throw Error('Invalid local operation input');
  return {at:stamp(),action,decision:'ALLOW_LOCAL',references:['Proverbs 12:22','1 Corinthians 14:40'],checks:{capabilityAllowed:true,inputLengthWithinLimit:true},interpretation:'Mechanical capability and input-size checks. HTTP session checks are separate. This record is not owner identity, a cryptographic signature, a moral judgment, or a claim of divine authority.'};
}
export function redactTemplate(text){return String(text).replace(/<\|(?:im_start|im_end|endoftext)\|>/g,'').replace(/<\/?think>/g,'');}
export function naturalTool(text) {
  if(typeof text!=='string')return null;
  // Whole, explicit commands only. Quoted text, negation, and discussion stay chat.
  const s=text.trim();
  const prefix='(?:please\\s+)?(?:run|compute|calculate|show)\\s+(?:(?:a|the)\\s+)?';
  if(new RegExp('^'+prefix+'bell (?:state|pair)[.!]?$','i').test(s))return {kind:'ghz',n:2};
  const ghz=s.match(new RegExp('^'+prefix+'(?:(\\d+)\\s*[- ]?qubits?\\s+)?ghz(?:\\s+state)?(?:\\s+(?:with\\s+)?(\\d+)(?:\\s+qubits?)?)?[.!]?$','i'));
  if(ghz){if(ghz[1]&&ghz[2])return null;const n=Number(ghz[1]||ghz[2]||3);if(!Number.isSafeInteger(n)||n<2||n>60)throw Error('GHZ qubits must be 2..60');return {kind:'ghz',n};}
  if(new RegExp('^'+prefix+'(?:hadamard )?interference(?: test)?[.!]?$','i').test(s))return {kind:'circuit',spec:{n:1,gates:[{kind:'H',q:0},{kind:'H',q:0}],probes:['0','1']}};
  return null;
}
