// GAUCIA Actual repair deployment. No application launch or permission changes.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {spawnSync} from 'node:child_process';
import {pathToFileURL} from 'node:url';

export const USB_ROOT='./REDACTED_LOCAL_ROOT/QEL_Q7\\GAUCIA_Sovereign_20260919';
export const MAPPINGS=[
 ['core.mjs','service/core.mjs'],['communication.mjs','service/communication.mjs'],
 ['backend.mjs','service/backend.mjs'],['tools/start-panel.mjs','service/tools/start-panel.mjs'],
 ['ui/GauciaWindow-stable.cs','native/GauciaWindow-startup-repair.cs'],
 ['GAUCIA-Local.exe','native/GAUCIA-Local-startup-repair.exe'],
 ['ui/GauciaWindow-audited.cs','native/audited/GauciaWindow-audited-startup-repair.cs'],
 ['GAUCIA-Audited.exe','native/audited/GAUCIA-Audited-startup-repair.exe']
];
const transactionName='.gaucia-repair';
const sha=bytes=>crypto.createHash('sha256').update(bytes).digest('hex');
const fileHash=file=>sha(fs.readFileSync(file));
const normalized=p=>path.resolve(p).toLowerCase();
function fail(message){throw Error(message);}
function inside(root,relative){
 if(typeof relative!=='string'||path.isAbsolute(relative)||relative.split(/[\\/]/).some(x=>!x||x==='.'||x==='..'))fail('Invalid relative path');
 const file=path.resolve(root,relative);if(!normalized(file).startsWith(normalized(root)+path.sep))fail('Path leaves allowed root');return file;
}
function regular(file,{directory=false}={}){
 const st=fs.lstatSync(file);
 if(st.isSymbolicLink()||normalized(fs.realpathSync(file))!==normalized(file))fail('Linked or redirected path refused: '+file);
 if(directory?!st.isDirectory():!st.isFile())fail('Unexpected file type: '+file);
 return st;
}
function parents(root,file){
 regular(root,{directory:true});let current=path.dirname(file);
 while(normalized(current)!==normalized(root)){regular(current,{directory:true});const next=path.dirname(current);if(next===current)fail('Parent left root');current=next;}
}
function json(file){regular(file);return JSON.parse(fs.readFileSync(file,'utf8'));}
function writeNew(file,bytes){
 const data=Buffer.from(bytes);const fd=fs.openSync(file,'wx');
 try{fs.writeFileSync(fd,data);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
 if(fileHash(file)!==sha(data))fail('Write readback mismatch: '+file);
}
function publish(file,bytes){
 const temporary=file+'.tmp-'+crypto.randomUUID();writeNew(temporary,bytes);
 if(fs.existsSync(file))fail('Published transaction record already exists');
 fs.renameSync(temporary,file);if(fileHash(file)!==sha(Buffer.from(bytes)))fail('Published record readback mismatch');
}
function loadBundle(bundleRoot){
 regular(bundleRoot,{directory:true});const manifest=json(inside(bundleRoot,'manifest.json')),plan=json(inside(bundleRoot,'deployment-plan.json'));
 if(manifest.schema!=='GAUCIA_REPAIR_BUNDLE_V1'||plan.targetRoot!==USB_ROOT||plan.primaryEntry!=='GAUCIA-Local.exe')fail('Unexpected deployment package');
 for(const set of [manifest.targets,plan.targets]){
  if(!Array.isArray(set)||set.length!==MAPPINGS.length)fail('Expected exactly eight targets');
  for(const [i,[targetRelative,bundleFile]] of MAPPINGS.entries()){
   const t=set[i];if(t.targetRelative!==targetRelative||t.bundleFile!==bundleFile)fail('Unexpected target mapping');
   if(!/^[a-f0-9]{64}$/.test(t.baselineSha256)||!/^[a-f0-9]{64}$/.test(t.candidateSha256)||!Number.isSafeInteger(t.candidateBytes)||t.candidateBytes<1)fail('Invalid integrity record');
  }
 }
 if(JSON.stringify(manifest.targets)!==JSON.stringify(plan.targets))fail('Plan and manifest disagree');
 for(const t of manifest.targets){const file=inside(bundleRoot,t.bundleFile);parents(bundleRoot,file);regular(file);const bytes=fs.readFileSync(file);if(bytes.length!==t.candidateBytes||sha(bytes)!==t.candidateSha256)fail('Candidate integrity failed: '+t.targetRelative);}
 return {targets:manifest.targets,packageId:sha(JSON.stringify(manifest.targets))};
}
// Read-only Windows process query. Failure or unreadable relevant command lines
// are blockers. No process is killed and command lines are never saved to reports.
export function probeProcesses(root){
 if(process.platform!=='win32')return {known:false,reason:'Windows process inspection is required',processes:[]};
 const command="$ErrorActionPreference='Stop'; try { $items=@(Get-CimInstance Win32_Process -Filter \"Name='node.exe' OR Name='llama-server.exe' OR Name='GAUCIA.exe' OR Name='GAUCIA-Local.exe' OR Name='GAUCIA-Audited.exe'\" | Select-Object ProcessId,Name,ExecutablePath,CommandLine); ConvertTo-Json -InputObject $items -Compress } catch { Write-Error 'Process inspection unavailable'; exit 1 }";
 const shell=path.join(process.env.SystemRoot||'./REDACTED_LOCAL_ROOT/Windows','System32','WindowsPowerShell','v1.0','powershell.exe');
 const result=spawnSync(shell,['-NoProfile','-NonInteractive','-Command',command],{encoding:'utf8',windowsHide:true,timeout:10000,maxBuffer:1024*1024});
 if(result.status!==0)return {known:false,reason:'Windows process inspection unavailable',processes:[]};
 let rows;try{rows=JSON.parse(result.stdout||'[]');}catch{return {known:false,reason:'Process inspection returned invalid data',processes:[]};}
 if(!Array.isArray(rows))return {known:false,reason:'Process inspection returned invalid shape',processes:[]};
 const runtimeRoot=normalized(path.resolve(root,'../Independent_Model_20260919'));
 const relevant=[];let unknown=false;
 for(const row of rows){
  if(row.ProcessId===process.pid)continue;
  if(!row.ExecutablePath||!row.CommandLine){unknown=true;continue;}
  const executable=normalized(row.ExecutablePath),commandLine=String(row.CommandLine).toLowerCase().replaceAll('/','\\');
  if(executable.startsWith(normalized(root)+path.sep)||executable.startsWith(runtimeRoot+path.sep)||commandLine.includes(normalized(root)))relevant.push({pid:row.ProcessId,name:row.Name});
 }
 return {known:!unknown,reason:unknown?'A relevant process has unreadable identity':null,processes:relevant};
}
function assertStopped(root,probe){const p=probe(root);if(!p?.known)fail(p?.reason||'Process state unknown');if(p.processes.length)fail('GAUCIA processes must finish before replacement: '+p.processes.map(x=>x.name+' ('+x.pid+')').join(', '));}
function preserved(root){
 const result={};const excluded=new Set(MAPPINGS.map(x=>x[0].toLowerCase()));
 function walk(dir,relative=''){
  for(const e of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){
   const rel=(relative?relative+'/':'')+e.name;if(!relative&&e.name===transactionName)continue;if(excluded.has(rel.toLowerCase()))continue;
   const file=inside(root,rel);if(e.isDirectory()){regular(file,{directory:true});result[rel+'/']='directory';walk(file,rel);}else{regular(file);result[rel]=fileHash(file);}
  }
 }
 walk(root);const hold=path.resolve(root,'../SECURITY_ONLY_HOLD.json');
 try{regular(hold);result['../SECURITY_ONLY_HOLD.json']=fileHash(hold);}catch(e){if(e.code!=='ENOENT')throw e;result['../SECURITY_ONLY_HOLD.json']='absent';}
 return result;
}
function samePreserved(root,expected){if(JSON.stringify(preserved(root))!==JSON.stringify(expected))fail('A preserved file changed; inspect transaction before continuing');}
function transactionDirectories(root){
 const base=path.join(root,transactionName);try{regular(base,{directory:true});}catch(e){if(e.code==='ENOENT')return [];throw e;}
 return fs.readdirSync(base).filter(name=>!['operation.lock','recovery.lock'].includes(name)).map(name=>{if(!/^repair-[0-9a-f-]{36}$/.test(name))fail('Unknown repair transaction entry');const dir=inside(base,name);regular(dir,{directory:true});return dir;});
}
function exclusive(root,packageId,transaction,operation,{recover=false,ownerAlive=pid=>{try{process.kill(pid,0);return true;}catch(e){if(e.code==='ESRCH')return false;throw e;}}}={}){
 regular(root,{directory:true});
 const base=path.join(root,transactionName);fs.mkdirSync(base,{recursive:true});regular(base,{directory:true});
 const file=path.join(base,'operation.lock');
 let recoveryFd;const gate=path.join(base,'recovery.lock');
 if(recover){try{recoveryFd=fs.openSync(gate,'wx');}catch(e){if(e.code==='EEXIST')fail('Recovery ownership needs inspection: recovery.lock is never automatically reclaimed');throw e;}fs.writeFileSync(recoveryFd,JSON.stringify({pid:process.pid,transaction}));fs.fsyncSync(recoveryFd);}
 try{
 if(recover&&fs.existsSync(file)){
  regular(file);const prior=fs.readFileSync(file,'utf8'),owner=JSON.parse(prior);
  if(owner.packageId!==packageId||owner.transaction!==transaction||!Number.isSafeInteger(owner.pid)||owner.pid<1)fail('Existing operation lock does not match this rollback');
  if(ownerAlive(owner.pid))fail('A deployment operation is still running');
  if(fs.readFileSync(file,'utf8')!==prior)fail('Operation lock changed during inspection');
  fs.unlinkSync(file);
 }
 let fd;try{fd=fs.openSync(file,'wx');}catch(e){if(e.code==='EEXIST')fail('Another or interrupted deployment owns operation.lock; inspect its matching transaction');throw e;}
 const token=JSON.stringify({pid:process.pid,packageId,transaction,token:crypto.randomUUID()});
 try{fs.writeFileSync(fd,token);fs.fsyncSync(fd);return operation();}
 finally{fs.closeSync(fd);if(fs.readFileSync(file,'utf8')===token)fs.unlinkSync(file);}
 }finally{if(recoveryFd!==undefined){fs.closeSync(recoveryFd);fs.unlinkSync(gate);}}
}
function journalEntries(dir){const folder=path.join(dir,'journal');try{regular(folder,{directory:true});}catch(e){if(e.code==='ENOENT')return [{state:'MISSING_JOURNAL'}];throw e;}const names=fs.readdirSync(folder).filter(n=>/^\d{6,}\.json$/.test(n)).sort((a,b)=>Number(a.slice(0,-5))-Number(b.slice(0,-5)));if(!names.length)return [{state:'MISSING_JOURNAL'}];return names.map(n=>{try{return json(path.join(folder,n));}catch(e){if(e instanceof SyntaxError)return {state:'UNREADABLE_JOURNAL',file:n};throw e;}});}
function record(dir,state,details={}){
 const folder=path.join(dir,'journal');fs.mkdirSync(folder,{recursive:true});regular(folder,{directory:true});const names=fs.readdirSync(folder).filter(n=>/^\d{6,}\.json$/.test(n));const n=Math.max(0,...names.map(x=>Number(x.slice(0,-5))))+1;if(!Number.isSafeInteger(n))fail('Invalid transaction sequence');
 publish(path.join(folder,String(n).padStart(6,'0')+'.json'),JSON.stringify({atUtc:new Date().toISOString(),state,...details},null,2)+'\n');
}
function incomplete(root){return transactionDirectories(root).filter(dir=>!['COMPLETED','ROLLED_BACK','PREPARATION_FAILED','RECOVERED_BASELINE'].includes(journalEntries(dir).at(-1).state));}
export function preflight({targetRoot,bundleRoot,processProbe=probeProcesses}){
 const bundle=loadBundle(bundleRoot);regular(targetRoot,{directory:true});const config=json(path.join(targetRoot,'config.json'));
 if(config.communicationPort!==undefined&&config.communicationPort!==17807)fail('Native GAUCIA requires port 17807');
 const pending=incomplete(targetRoot);if(pending.length)fail('Incomplete transaction requires rollback: '+pending.map(x=>path.basename(x)).join(', '));
 const states=bundle.targets.map(t=>{const file=inside(targetRoot,t.targetRelative);parents(targetRoot,file);regular(file);const h=fileHash(file);if(h!==t.baselineSha256&&h!==t.candidateSha256)fail('Unknown/newer live bytes: '+t.targetRelative);return h===t.baselineSha256?'baseline':'candidate';});
 if(new Set(states).size!==1)fail('Mixed live versions require their matching transaction');
 assertStopped(targetRoot,processProbe);
 return {...bundle,state:states[0]==='candidate'?'ALREADY_APPLIED':'READY_TO_APPLY',preserved:preserved(targetRoot),readOnly:true};
}
function stageBytes(dir,name,bytes,expected){const file=path.join(dir,name);writeNew(file,bytes);if(fileHash(file)!==expected)fail('Staging hash mismatch');return file;}
function rollbackChecked({targetRoot,bundleRoot,transaction,processProbe=probeProcesses,beforeRestore=()=>{}}){
 if(!/^repair-[0-9a-f-]{36}$/.test(transaction))fail('Invalid transaction identifier');
 const bundle=loadBundle(bundleRoot);const base=path.join(targetRoot,transactionName);const dir=inside(base,transaction);regular(base,{directory:true});
 assertStopped(targetRoot,processProbe);
 const liveHashes=bundle.targets.map(t=>{const live=inside(targetRoot,t.targetRelative);parents(targetRoot,live);regular(live);return fileHash(live);});
 if(liveHashes.every((h,i)=>h===bundle.targets[i].baselineSha256)){
  // A crash can precede metadata or backup creation. Exact live baselines are
  // sufficient to establish that no target restoration is presently needed.
  fs.mkdirSync(dir,{recursive:true});regular(dir,{directory:true});record(dir,'RECOVERED_BASELINE',{originalsVerified:8,restoredFiles:0,partialEvidenceRetained:true});
  return {state:'ROLLED_BACK',transaction,originalsVerified:8,restoredFiles:0,preservationComparison:'Unavailable or not required for target-only baseline recovery',launched:false};
 }
 regular(dir,{directory:true});
 const metadata=json(path.join(dir,'transaction.json'));
 if(metadata.packageId!==bundle.packageId||normalized(metadata.targetRoot)!==normalized(targetRoot)||JSON.stringify(metadata.targets)!==JSON.stringify(bundle.targets))fail('Transaction does not match this package and target');
 assertStopped(targetRoot,processProbe);
 // Check the COMPLETE restoration set before restoring a single destination.
 for(const [i,t]of bundle.targets.entries()){
  const live=inside(targetRoot,t.targetRelative);parents(targetRoot,live);regular(live);
  const backup=path.join(dir,'original-'+i);regular(backup);
  if(fileHash(backup)!==t.baselineSha256)fail('Original backup mismatch: '+t.targetRelative);
  if(![t.baselineSha256,t.candidateSha256].includes(fileHash(live)))fail('Rollback refused unknown/newer bytes: '+t.targetRelative);
 }
 record(dir,'ROLLBACK_STARTED');
 for(const [i,t]of bundle.targets.entries()){
  beforeRestore(i);const live=inside(targetRoot,t.targetRelative);parents(targetRoot,live);regular(live);const current=fileHash(live);if(current===t.baselineSha256)continue;
  if(current!==t.candidateSha256)fail('Rollback refused a new change during restoration: '+t.targetRelative);
  const temporary=stageBytes(dir,'rollback-'+i+'-'+crypto.randomUUID(),fs.readFileSync(path.join(dir,'original-'+i)),t.baselineSha256);
  record(dir,'BEFORE_RESTORE',{target:t.targetRelative});fs.renameSync(temporary,live);
  if(fileHash(live)!==t.baselineSha256)fail('Restoration readback failed');record(dir,'RESTORED',{target:t.targetRelative});
 }
 for(const t of bundle.targets)if(fileHash(inside(targetRoot,t.targetRelative))!==t.baselineSha256)fail('Final original-set verification failed');
 samePreserved(targetRoot,metadata.preserved);record(dir,'ROLLED_BACK');
 return {state:'ROLLED_BACK',transaction,originalsVerified:8,preservedEntries:Object.keys(metadata.preserved).length,launched:false};
}
export function rollback(options){try{
 const bundle=loadBundle(options.bundleRoot);
 return exclusive(options.targetRoot,bundle.packageId,options.transaction,()=>rollbackChecked(options),{recover:true,...options.lockOptions});
}catch(error){throw Error('Rollback incomplete: '+error.message,{cause:error});}}
export function apply(options){
 const {targetRoot,bundleRoot,processProbe=probeProcesses,beforeReplace=()=>{}}=options;
 const check=preflight({targetRoot,bundleRoot,processProbe});if(check.state==='ALREADY_APPLIED')return {state:check.state,installedFiles:8,rollbackAvailability:'Requires an intact matching transaction',launched:false};
 const transaction='repair-'+crypto.randomUUID();
 return exclusive(targetRoot,check.packageId,transaction,()=>{
 // Revalidate after obtaining exclusive ownership; a competing installer may
 // have completed between our first read-only check and lock acquisition.
 const current=preflight({targetRoot,bundleRoot,processProbe});if(current.state!=='READY_TO_APPLY')fail('Target changed before exclusive installation');
 const dir=path.join(targetRoot,transactionName,transaction);fs.mkdirSync(dir);fs.mkdirSync(path.join(dir,'journal'));
 let replacementStarted=false;
 try{
  record(dir,'PREPARING');
  publish(path.join(dir,'transaction.json'),JSON.stringify({targetRoot:path.resolve(targetRoot),packageId:check.packageId,targets:check.targets,preserved:check.preserved},null,2)+'\n');
  for(const [i,t]of check.targets.entries()){
   stageBytes(dir,'original-'+i,fs.readFileSync(inside(targetRoot,t.targetRelative)),t.baselineSha256);
   stageBytes(dir,'candidate-'+i,fs.readFileSync(inside(bundleRoot,t.bundleFile)),t.candidateSha256);
  }
  assertStopped(targetRoot,processProbe);samePreserved(targetRoot,check.preserved);
  for(const t of check.targets)if(fileHash(inside(targetRoot,t.targetRelative))!==t.baselineSha256)fail('Live target changed after backup');
  record(dir,'PREPARED');replacementStarted=true;
  for(const [i,t]of check.targets.entries()){
   beforeReplace(i);const live=inside(targetRoot,t.targetRelative);parents(targetRoot,live);regular(live);
   if(fileHash(live)!==t.baselineSha256)fail('Live target changed during replacement');
   record(dir,'BEFORE_REPLACE',{target:t.targetRelative});fs.renameSync(path.join(dir,'candidate-'+i),live);
   if(fileHash(live)!==t.candidateSha256)fail('Installed readback failed');record(dir,'REPLACED',{target:t.targetRelative});
  }
  for(const t of check.targets)if(fileHash(inside(targetRoot,t.targetRelative))!==t.candidateSha256)fail('Final candidate-set verification failed');
  samePreserved(targetRoot,check.preserved);record(dir,'COMPLETED');
  return {state:'INSTALLED_BYTES_VERIFIED',installedFiles:8,transaction,preservedEntries:Object.keys(check.preserved).length,launched:false,liveConversationVerified:false};
 }catch(error){
  if(!replacementStarted){try{record(dir,'PREPARATION_FAILED',{error:error.message});}catch{}throw error;}
  try{rollbackChecked({targetRoot,bundleRoot,transaction,processProbe});}catch(rollbackError){try{record(dir,'NEEDS_REVIEW',{error:error.message,rollbackError:rollbackError.message});}catch{}throw Error('Installation interrupted; preserved transaction '+transaction+'. '+rollbackError.message,{cause:error});}
  throw Error('Installation failed and originals were restored: '+error.message,{cause:error});
 }
 });
}
if(process.argv[1]&&pathToFileURL(path.resolve(process.argv[1])).href===import.meta.url){
 const args=process.argv.slice(2);const bundleRoot=path.resolve(import.meta.dirname,'..');
 const options={targetRoot:USB_ROOT,bundleRoot};
 try{
  let result;
  if(args.length===0||args.join(' ')==='--check'){const p=preflight(options);result={state:p.state,readOnly:true,targets:p.targets.length,preservedEntries:Object.keys(p.preserved).length};}
  else if(args.join(' ')==='--apply')result=apply(options);
  else if(args.length===2&&args[0]==='--rollback'&&/^repair-[0-9a-f-]{36}$/.test(args[1]))result=rollback({...options,transaction:args[1]});
  else fail('Use --check, --apply, or --rollback repair-<transaction-id>. Target is fixed to the existing USB GAUCIA folder.');
  console.log(JSON.stringify(result,null,2));
 }catch(error){console.error(JSON.stringify({state:'STOPPED',error:error.message,launched:false}));process.exitCode=1;}
}
