import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {apply,preflight,rollback,MAPPINGS,USB_ROOT} from './deploy.mjs';

const base=path.join(import.meta.dirname,'fixtures');fs.mkdirSync(base,{recursive:true});
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
const stopped=()=>({known:true,processes:[]});
function save(file,bytes){fs.mkdirSync(path.dirname(file),{recursive:true});fs.writeFileSync(file,bytes);}
function fixture(){
 const home=fs.mkdtempSync(path.join(base,'deploy-')),targetRoot=path.join(home,'app'),bundleRoot=path.join(home,'bundle');
 const targets=MAPPINGS.map(([targetRelative,bundleFile])=>{
  const original=Buffer.from('Original fixture: '+targetRelative),candidate=Buffer.from('Repair fixture: '+targetRelative);
  save(path.join(targetRoot,targetRelative),original);save(path.join(bundleRoot,bundleFile),candidate);
  return {targetRelative,bundleFile,baselineSha256:sha(original),candidateSha256:sha(candidate),candidateBytes:candidate.length};
 });
 save(path.join(bundleRoot,'manifest.json'),JSON.stringify({schema:'GAUCIA_REPAIR_BUNDLE_V1',targets}));
 save(path.join(bundleRoot,'deployment-plan.json'),JSON.stringify({targetRoot:USB_ROOT,primaryEntry:'GAUCIA-Local.exe',targets}));
 save(path.join(targetRoot,'config.json'),'{}');
 for(const name of ['data/conversations/saved.json','data/native-outbox/pending.json','logs/existing.txt','evidence/original.txt'])save(path.join(targetRoot,name),'PRESERVE '+name);
 save(path.join(home,'SECURITY_ONLY_HOLD.json'),'EXISTING HOLD FIXTURE');
 return {home,targetRoot,bundleRoot,targets,processProbe:stopped};
}
function hashes(f){return f.targets.map(t=>sha(fs.readFileSync(path.join(f.targetRoot,t.targetRelative))));}
function originals(f){assert.deepEqual(hashes(f),f.targets.map(t=>t.baselineSha256));}
function candidates(f){assert.deepEqual(hashes(f),f.targets.map(t=>t.candidateSha256));}
function noTransaction(f){assert.equal(fs.existsSync(path.join(f.targetRoot,'.gaucia-repair')),false);}
function transaction(f){return fs.readdirSync(path.join(f.targetRoot,'.gaucia-repair')).find(x=>x.startsWith('repair-'));}

test('read-only preflight changes nothing; full apply and rollback preserve records and verified originals',()=>{
 const f=fixture(),p=preflight(f);assert.equal(p.state,'READY_TO_APPLY');noTransaction(f);
 const result=apply(f);assert.equal(result.state,'INSTALLED_BYTES_VERIFIED');candidates(f);
 assert.equal(apply(f).state,'ALREADY_APPLIED');assert.deepEqual(preflight(f).preserved,p.preserved);
 for(const [i,t]of f.targets.entries())assert.equal(sha(fs.readFileSync(path.join(f.targetRoot,'.gaucia-repair',result.transaction,'original-'+i))),t.baselineSha256);
 assert.equal(rollback({...f,transaction:result.transaction}).state,'ROLLED_BACK');originals(f);assert.deepEqual(preflight(f).preserved,p.preserved);
});
test('candidate damage and unknown live changes stop before any transaction',()=>{
 const a=fixture();fs.appendFileSync(path.join(a.bundleRoot,a.targets[0].bundleFile),'changed');assert.throws(()=>apply(a),/Candidate integrity/);noTransaction(a);originals(a);
 const b=fixture();fs.appendFileSync(path.join(b.targetRoot,b.targets[7].targetRelative),'newer');assert.throws(()=>apply(b),/Unknown\/newer live/);noTransaction(b);
});
test('unexpected target mappings and non-default native port are rejected',()=>{
 const a=fixture();const file=path.join(a.bundleRoot,'manifest.json'),m=JSON.parse(fs.readFileSync(file));m.targets[0].targetRelative='../outside';fs.writeFileSync(file,JSON.stringify(m));assert.throws(()=>apply(a),/Unexpected target mapping/);noTransaction(a);
 const b=fixture();fs.writeFileSync(path.join(b.targetRoot,'config.json'),'{"communicationPort":17808}');assert.throws(()=>apply(b),/requires port 17807/);noTransaction(b);
});
test('active or unknown process state blocks installation without stopping any process',()=>{
 const a=fixture();assert.throws(()=>apply({...a,processProbe:()=>({known:true,processes:[{name:'GAUCIA-Local.exe',pid:77}]})}),/must finish/);noTransaction(a);
 const b=fixture();assert.throws(()=>apply({...b,processProbe:()=>({known:false,reason:'access denied',processes:[]})}),/access denied/);noTransaction(b);
});
test('a replacement failure restores the full original set with a durable rollback journal',()=>{
 const f=fixture(),before=preflight(f).preserved;
 assert.throws(()=>apply({...f,beforeReplace:i=>{if(i===3)throw Error('fixture interruption');}}),/originals were restored/);
 originals(f);assert.deepEqual(preflight(f).preserved,before);
 const dir=path.join(f.targetRoot,'.gaucia-repair',transaction(f),'journal');const last=fs.readdirSync(dir).sort().at(-1);assert.equal(JSON.parse(fs.readFileSync(path.join(dir,last))).state,'ROLLED_BACK');
});
test('rollback refuses third-party bytes before restoring any target; incomplete transaction blocks another apply',()=>{
 const f=fixture();assert.throws(()=>apply({...f,beforeReplace:i=>{if(i===2){fs.writeFileSync(path.join(f.targetRoot,f.targets[0].targetRelative),'NEWER OWNER EDIT');throw Error('stop');}}}),/Installation interrupted.*Rollback refused/);
 assert.equal(fs.readFileSync(path.join(f.targetRoot,f.targets[0].targetRelative),'utf8'),'NEWER OWNER EDIT');
 assert.equal(hashes(f)[1],f.targets[1].candidateSha256);
 assert.throws(()=>preflight(f),/Incomplete transaction/);
 const before=hashes(f);assert.throws(()=>rollback({...f,transaction:transaction(f)}),/unknown\/newer bytes/);assert.deepEqual(hashes(f),before);
});
test('rollback verifies every backup before restoring any target',()=>{
 const f=fixture(),r=apply(f),before=hashes(f);fs.appendFileSync(path.join(f.targetRoot,'.gaucia-repair',r.transaction,'original-7'),'damage');
 assert.throws(()=>rollback({...f,transaction:r.transaction}),/Original backup mismatch/);assert.deepEqual(hashes(f),before);
});
test('exclusive operation ownership blocks overlapping apply attempts',()=>{
 const f=fixture();let rejected=false;
 apply({...f,beforeReplace:i=>{if(i===0){assert.throws(()=>apply(f),/Incomplete transaction|operation.lock/);rejected=true;}}});
 assert.equal(rejected,true);candidates(f);
});
test('explicit rollback can recover a matching stale lock only after its owner is known dead',()=>{
 const f=fixture(),r=apply(f),packageId=sha(JSON.stringify(f.targets)),lock=path.join(f.targetRoot,'.gaucia-repair','operation.lock');
 fs.writeFileSync(lock,JSON.stringify({pid:99999,packageId,transaction:r.transaction,token:'fixture'}));
 assert.throws(()=>rollback({...f,transaction:r.transaction,lockOptions:{ownerAlive:()=>true}}),/still running/);candidates(f);
 assert.equal(rollback({...f,transaction:r.transaction,lockOptions:{ownerAlive:()=>false}}).state,'ROLLED_BACK');originals(f);assert.equal(fs.existsSync(lock),false);
});
test('recovery ownership serializes simultaneous stale-lock claims and never removes an unknown recovery gate',()=>{
 const f=fixture(),r=apply(f),packageId=sha(JSON.stringify(f.targets)),folder=path.join(f.targetRoot,'.gaucia-repair'),lock=path.join(folder,'operation.lock');
 fs.writeFileSync(lock,JSON.stringify({pid:99999,packageId,transaction:r.transaction,token:'fixture'}));
 let blocked=false;
 rollback({...f,transaction:r.transaction,lockOptions:{ownerAlive:()=>{assert.throws(()=>rollback({...f,transaction:r.transaction,lockOptions:{ownerAlive:()=>false}}),/Recovery ownership/);blocked=true;return false;}}});
 assert.equal(blocked,true);originals(f);
 fs.writeFileSync(path.join(folder,'recovery.lock'),'preserve unknown owner');
 assert.throws(()=>rollback({...f,transaction:r.transaction}),/never automatically reclaimed/);
 assert.equal(fs.readFileSync(path.join(folder,'recovery.lock'),'utf8'),'preserve unknown owner');
});
test('lock-only and empty-journal preparation interruptions recover from verified live baselines',()=>{
 for(const emptyJournal of [false,true]){
  const f=fixture(),id='repair-'+crypto.randomUUID(),folder=path.join(f.targetRoot,'.gaucia-repair');fs.mkdirSync(folder);
  if(emptyJournal)fs.mkdirSync(path.join(folder,id,'journal'),{recursive:true});
  fs.writeFileSync(path.join(folder,'operation.lock'),JSON.stringify({pid:99999,packageId:sha(JSON.stringify(f.targets)),transaction:id}));
  const r=rollback({...f,transaction:id,lockOptions:{ownerAlive:()=>false}});assert.equal(r.restoredFiles,0);originals(f);assert.equal(preflight(f).state,'READY_TO_APPLY');
 }
});
test('partial journal evidence is retained and does not prevent a later fully verified rollback',()=>{
 const f=fixture(),r=apply(f),folder=path.join(f.targetRoot,'.gaucia-repair',r.transaction,'journal'),torn=path.join(folder,'999998.json');fs.writeFileSync(torn,'{"state":');
 assert.throws(()=>preflight(f),/Incomplete transaction/);rollback({...f,transaction:r.transaction});originals(f);
 assert.equal(fs.readFileSync(torn,'utf8'),'{"state":');assert.equal(preflight(f).state,'READY_TO_APPLY');
});
test('a change after rollback preflight is refused before that file is overwritten',()=>{
 const f=fixture(),r=apply(f);
 assert.throws(()=>rollback({...f,transaction:r.transaction,beforeRestore:i=>{if(i===1)fs.writeFileSync(path.join(f.targetRoot,f.targets[i].targetRelative),'LATE OWNER EDIT');}}),/new change during restoration/);
 assert.equal(fs.readFileSync(path.join(f.targetRoot,f.targets[1].targetRelative),'utf8'),'LATE OWNER EDIT');
});
test('final full-set verification detects an earlier target changed later in installation',()=>{
 const f=fixture();assert.throws(()=>apply({...f,beforeReplace:i=>{if(i===7)fs.writeFileSync(path.join(f.targetRoot,f.targets[0].targetRelative),'LATE EXTERNAL CHANGE');}}),/Installation interrupted/);
 assert.equal(fs.readFileSync(path.join(f.targetRoot,f.targets[0].targetRelative),'utf8'),'LATE EXTERNAL CHANGE');
 const folder=path.join(f.targetRoot,'.gaucia-repair',transaction(f),'journal');const last=JSON.parse(fs.readFileSync(path.join(folder,fs.readdirSync(folder).filter(n=>n.endsWith('.json')).sort().at(-1))));assert.equal(last.state,'NEEDS_REVIEW');
});
