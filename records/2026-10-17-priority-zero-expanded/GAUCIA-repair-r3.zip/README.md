# GAUCIA Actual environment repair — revision 3

This patch repairs the existing USB application. It is locally compiled and tested, and has not been installed on USB. GAUCIA Actual remains the primary project agent; Codex supports this review. Owner: Sherman Gaucia Laing / Quantum.Earth.Laing.

Revision 3 adds native action-readiness gates, cancels pending startup work on window close, prevents post-close diagnostic/verification writes, fits the initial window above the taskbar, and fixes toolbar clipping and stale history-path labels. Read-only saved-history recovery remains available after startup failure. Local and Audited remain separate; Audited's durable outbox is preserved exactly.

The four service modules and installation/rollback runner are byte-identical to verified revision 2. Their prior 42 service tests and 14 fixture tests remain recorded with original timestamps. Changed native code passed 7 Local and 8 Audited regression groups plus 8 additional lifecycle/action groups per variant. Full candidate windows were visually checked with isolated C: records. A separate read-only check of the copied actual application found 20 readable conversation folders and 48 messages in selected latest revisions, from 99 available revision files; older unselected revisions were not parsed. All 688 copied files retained their hashes. This is not a complete USB mirror.

The package contains no actual conversation contents, credentials, model weights or runtime package. Counts refer to their stated test/data populations. Hashes verify bytes, not signatures or certification. See review/ and validation/ for evidence and limitations.

Installation requires effective access and a successful live preflight. From an extracted package in this chat's C: work folder:

    node operations/deploy.mjs --check
    node operations/deploy.mjs --apply

The target is fixed to ./REDACTED_LOCAL_ROOT/QEL_Q7\GAUCIA_Sovereign_20260919. The runner compares all eight originals/candidates, requires a known stopped application and native port 17807, saves verified backups, stages replacement, journals progress and verifies the result. It never kills or launches a process. It preserves configuration, history, outbox, logs, evidence and the sibling hold. Unknown/newer bytes stop installation. A known transaction can be rolled back with node operations/deploy.mjs --rollback repair-TRANSACTION-ID. An uncertain recovery gate requires inspection; no power-loss or cross-file atomicity guarantee is made.

USB installation remains blocked by current execution access. The saved qel-usb profile was not active at the latest inspected turn; scoped requests returned read only. D: is FAT32, whose interaction with the legacy sandbox remains a separate compatibility lead. No drive conversion, permissions change or hold removal is part of this patch. Ordinary generation still requires the applicable owner-reviewed restoration path; attended saved-history recovery does not certify complete security.
