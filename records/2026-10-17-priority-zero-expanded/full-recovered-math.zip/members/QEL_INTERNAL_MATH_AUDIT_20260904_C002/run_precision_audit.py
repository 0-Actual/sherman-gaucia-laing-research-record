#!/usr/bin/env python3
"""QEL C002 repeatable precision tests. Originator: Sherman G. Laing.
Local computation and evidence writes only; no network actions.
"""
from pathlib import Path
import importlib.util, io, json, math, sys, unittest, warnings
import numpy as np
ROOT=Path(__file__).resolve().parent
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
def precision_tests(q):
 class PrecisionTests(unittest.TestCase):
  def test_01_huge_real(self):
   np.testing.assert_allclose(q.normalize_state([1e300,1e300]),[1/math.sqrt(2)]*2,rtol=1e-15,atol=0)
  def test_02_tiny_real(self):
   np.testing.assert_allclose(q.normalize_state([1e-300,1e-300]),[1/math.sqrt(2)]*2,rtol=1e-15,atol=0)
  def test_03_max_complex_components(self):
   m=np.finfo(float).max
   np.testing.assert_allclose(q.normalize_state([complex(m,m),complex(-m,m)]),[.5+.5j,-.5+.5j],rtol=1e-15,atol=0)
  def test_04_minimum_subnormal(self):
   x=np.nextafter(0.,1.)
   np.testing.assert_allclose(q.normalize_state([x,x]),[1/math.sqrt(2)]*2,rtol=1e-15,atol=0)
  def test_05_subnormal_complex_components(self):
   x=np.nextafter(0.,1.)
   np.testing.assert_allclose(q.normalize_state([complex(x,x),complex(-x,x)]),[.5+.5j,-.5+.5j],rtol=1e-15,atol=0)
  def test_06_mixed_scales(self):
   np.testing.assert_array_equal(q.normalize_state([1e308,1e-308]),[1,0])
  def test_07_scale_invariance(self):
   v=np.array([3+4j,-5+12j]);expected=v/math.sqrt(194)
   for scale in (1e-300,1e-200,1.,1e200,1e300):
    with self.subTest(scale=scale):np.testing.assert_allclose(q.normalize_state(v*scale),expected,rtol=2e-15,atol=0)
  def test_08_zero_rejected(self):
   for v in ([0,0],[0j,-0j]):
    with self.subTest(v=v),self.assertRaises(q.LQCPValidationError):q.normalize_state(v)
  def test_09_nonfinite_rejected(self):
   for x in (float('inf'),float('nan'),complex(0,float('inf'))):
    with self.subTest(x=x),self.assertRaises(q.LQCPValidationError):q.normalize_state([1,x])
  def test_10_dimensions_rejected(self):
   for v in ([1,2,3],[[1,0],[0,1]],[]):
    with self.subTest(v=v),self.assertRaises(q.LQCPValidationError):q.normalize_state(v)
   with self.assertRaises(q.LQCPValidationError):q.normalize_state([1,0],2)
  def test_11_input_not_mutated(self):
   a=np.array([1e300,1e300],dtype=complex);b=a.copy();q.normalize_state(a);np.testing.assert_array_equal(a,b)
  def test_12_orthogonal_distance(self):self.assertEqual(q.phase_invariant_distance([1,0],[0,1]),1.)
  def test_13_small_angle(self):
   x=1e-12;np.testing.assert_allclose(q.phase_invariant_distance([1,0],[1,x]),x/math.hypot(1,x),rtol=2e-15,atol=0)
  def test_14_tiny_basis_perturbation(self):
   x=1e-300;np.testing.assert_allclose(q.phase_invariant_distance([1,0],[1,x]),x,rtol=2e-15,atol=0)
  def test_15_self_distance(self):
   a=np.array([1+2j,3-4j]);self.assertLessEqual(q.phase_invariant_distance(a,a),5e-16)
  def test_16_global_phase(self):
   a=np.array([1+2j,3-4j])
   for theta in (0,.25,math.pi/2,math.pi):
    with self.subTest(theta=theta):self.assertLessEqual(q.phase_invariant_distance(a,np.exp(1j*theta)*a),7e-16)
  def test_17_symmetry(self):
   r=np.random.default_rng(841)
   for n in (2,4,8):
    for j in range(10):
     a=r.normal(size=n)+1j*r.normal(size=n);b=r.normal(size=n)+1j*r.normal(size=n)
     self.assertAlmostEqual(q.phase_invariant_distance(a,b),q.phase_invariant_distance(b,a),places=14)
  def test_18_independent_density_distance(self):
   r=np.random.default_rng(842)
   for n in (2,4,8):
    for j in range(10):
     a=r.normal(size=n)+1j*r.normal(size=n);a/=np.linalg.norm(a)
     b=r.normal(size=n)+1j*r.normal(size=n);b/=np.linalg.norm(b)
     expected=.5*np.sum(np.abs(np.linalg.eigvalsh(np.outer(a,a.conj())-np.outer(b,b.conj()))))
     self.assertAlmostEqual(q.phase_invariant_distance(a,b),float(expected),places=14)
  def test_19_raw_distance_overflow_rejected(self):
   with self.assertRaises(q.LQCPValidationError):q.historical_lcr_distance([1e300,0],[-1e300,0])
  def test_20_raw_distance_ordinary(self):self.assertAlmostEqual(q.historical_lcr_distance([1,0],[-1,0]),4.)
  def test_21_density_invariants_after_huge_normalization(self):
   rho=q.density_matrix([1e300,1e300*1j]);np.testing.assert_allclose(rho,[[.5,-.5j],[.5j,.5]],atol=3e-16,rtol=0)
  def test_22_distance_bad_state_rejected(self):
   with self.assertRaises(q.LQCPValidationError):q.phase_invariant_distance([0,0],[1,0])
   with self.assertRaises(q.LQCPValidationError):q.phase_invariant_distance([1,0],[1,0,0,0])
 return unittest.defaultTestLoader.loadTestsFromTestCase(PrecisionTests)
def suite_result(suite):
 stream=io.StringIO()
 with warnings.catch_warnings(record=True) as observed:
  warnings.simplefilter('always');r=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
 methods=sorted({str(t).split()[0] for t,_ in r.failures+r.errors})
 return {'tests':r.testsRun,'success':r.wasSuccessful(),'failed_methods':methods,'warnings':[str(w.message) for w in observed]},stream.getvalue()
def main():
 result={'cycle':'QEL-MATH-20260904-C002'};logs=[]
 prev=load('c001_audit_runner',ROOT/'original/c001_audit_runner.py')
 for label,path in [('parent',ROOT/'original/qel_lqcp_reference_v2_1.py'),('candidate',ROOT/'source/qel_lqcp_reference_v2_2.py')]:
  q=load('qel_lqcp_reference_v2',path)
  t=load('legacy_'+label,ROOT/'original/test_qel_lqcp_reference_v2.py')
  result[label]={}
  for name,suite in [('inherited_108',unittest.defaultTestLoader.loadTestsFromModule(t)),('c001_boundary_12',prev.boundary_tests(q)),('c002_precision_22',precision_tests(q))]:
   receipt,log=suite_result(suite);result[label][name]=receipt;logs.append(label+' '+name+'\n'+log)
 result['status']='PASS' if all(x['success'] for x in result['candidate'].values()) else 'FAIL'
 result['python']=sys.version.split()[0];result['numpy']=np.__version__
 (ROOT/'evidence/precision_results.json').write_text(json.dumps(result,indent=2)+'\n')
 (ROOT/'evidence/precision_test_output.txt').write_text('\n'.join(logs))
 print(json.dumps(result,indent=2));return result['status']!='PASS'
if __name__=='__main__':raise SystemExit(main())
