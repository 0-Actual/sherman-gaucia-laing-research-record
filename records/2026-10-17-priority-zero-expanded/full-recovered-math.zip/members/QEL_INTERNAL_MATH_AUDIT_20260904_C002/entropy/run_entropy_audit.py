"""Replay standalone candidate tests and the transcribed gate's numerical defect."""

from datetime import datetime, timezone
import io
import json
from pathlib import Path
import platform
import sys
import unittest

import numpy as np

from fixed_point_reference import depolarizing_target_fixed_point
from test_fixed_point_reference import FixedPointReferenceTests, MIN_SUBNORMAL, PURE_TAU


def reproduced_old_denominator_gate(p: float, eta: float) -> dict:
    """Numerical reproduction of the excerpt, not original-module execution."""
    contraction = (1.0 - eta) * (1.0 - p)
    denominator = 1.0 - contraction
    return {
        "computed_denominator": denominator,
        "rejects_as_nonunique": bool(denominator <= 1e-10),
    }


def main() -> int:
    directory = Path(__file__).resolve().parent
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(FixedPointReferenceTests)
    # Expected subnormal underflow is permitted; unexpected overflow, division
    # by zero, or invalid arithmetic in these focused tests fails immediately.
    with np.errstate(over="raise", divide="raise", invalid="raise", under="ignore"):
        outcome = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    log = stream.getvalue()
    (directory / "entropy_test_output.txt").write_text(log, encoding="utf-8")

    demonstrations = []
    cases = (
        ("positive denominator rejected by tolerance", 1e-12, 0.0),
        ("depolarizing-only cancellation", 1e-20, 0.0),
        ("target-only cancellation", 0.0, 1e-20),
        ("equal smallest subnormals", MIN_SUBNORMAL, MIN_SUBNORMAL),
        ("unequal smallest subnormals", MIN_SUBNORMAL, 2 * MIN_SUBNORMAL),
    )
    for label, p, eta in cases:
        fixed = depolarizing_target_fixed_point(p, eta, PURE_TAU)
        demonstrations.append({
            "label": label,
            "p": float(p),
            "eta": float(eta),
            "old_gate_reproduction": reproduced_old_denominator_gate(p, eta),
            "corrected_fixed_point_real": fixed.real.tolist(),
            "corrected_fixed_point_imag": fixed.imag.tolist(),
        })
    result = {
        "cycle": "QEL-MATH-20260904-C002",
        "scope": "standalone depolarizing-plus-target fixed-point reference",
        "owner": "Sherman G. Laing",
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "status": "HOLD / UNSIGNED",
        "python": platform.python_version(),
        "numpy": np.__version__,
        "tests_run": outcome.testsRun,
        "failures": len(outcome.failures),
        "errors": len(outcome.errors),
        "skipped": len(outcome.skipped),
        "passed": outcome.wasSuccessful(),
        "oracle": "760-digit Decimal affine fixed-point equation, 10 parameter pairs",
        "independent_channel_invariance_subcases": 72,
        "seeded_random_density_subcases": 100,
        "random_seed": 602002,
        "source_basis": "Library-read excerpt transcription; raw byte identity unverified",
        "original_complete_module_executed": False,
        "deployment_performed": False,
        "demonstrations": demonstrations,
        "limits": [
            "Fixed-point uniqueness does not establish fast or float64-resolvable convergence.",
            "Density validity uses an explicit 1e-12 absolute tolerance.",
            "Individual weights smaller than float64 representability may round to zero.",
        ],
    }
    (directory / "entropy_results.json").write_text(
        json.dumps(result, indent=2, allow_nan=False) + "\n", encoding="utf-8"
    )
    print(log, end="")
    print(json.dumps({"passed": result["passed"], "tests_run": result["tests_run"],
                      "results": str(directory / "entropy_results.json")}))
    return 0 if outcome.wasSuccessful() else 1


if __name__ == "__main__":
    sys.exit(main())
