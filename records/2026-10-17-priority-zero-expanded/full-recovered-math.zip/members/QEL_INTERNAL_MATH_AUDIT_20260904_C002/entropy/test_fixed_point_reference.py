"""Analytic and independent fixed-point checks; no historical source imports."""

from decimal import Decimal, localcontext
import unittest

import numpy as np

from fixed_point_reference import (
    FixedPointValidationError,
    depolarizing_target_fixed_point,
)

I2 = np.eye(2, dtype=np.complex128) / 2
TAU = np.array([[0.7, 0.1 + 0.2j], [0.1 - 0.2j, 0.3]], dtype=np.complex128)
PURE_TAU = np.array([[1, 0], [0, 0]], dtype=np.complex128)
MIN_SUBNORMAL = np.nextafter(0.0, 1.0)


def decimal_fixed_point(p, eta, tau):
    """Independent high-precision solution using the original affine equation.

    760 digits resolve the cancellation in 1-(1-eta)*(1-p), even for the
    smallest positive float64 probabilities. Decimal inputs are exact
    representations of the actual binary floats, not decimal approximations.
    """
    with localcontext() as context:
        context.prec = 760
        one = Decimal(1)
        pd = Decimal.from_float(float(p))
        ed = Decimal.from_float(float(eta))
        contraction = (one - ed) * (one - pd)
        denominator = one - contraction
        result = np.zeros((2, 2), dtype=np.complex128)
        for i in range(2):
            for j in range(2):
                dep = (one - ed) * pd / 2 if i == j else Decimal(0)
                real = (dep + ed * Decimal.from_float(float(tau[i, j].real))) / denominator
                imag = ed * Decimal.from_float(float(tau[i, j].imag)) / denominator
                result[i, j] = complex(float(real), float(imag))
        return result


class FixedPointReferenceTests(unittest.TestCase):
    def test_identity_is_nonunique(self):
        with self.assertRaisesRegex(FixedPointValidationError, "nonunique"):
            depolarizing_target_fixed_point(0.0, 0.0, TAU)

    def test_tiny_depolarizing_only_has_maximally_mixed_fixed_point(self):
        for p in (1e-20, 1e-100, 1e-300, MIN_SUBNORMAL):
            with self.subTest(p=p):
                np.testing.assert_array_equal(depolarizing_target_fixed_point(p, 0.0, TAU), I2)

    def test_tiny_target_only_has_target_fixed_point(self):
        for eta in (1e-20, 1e-100, 1e-300, MIN_SUBNORMAL):
            with self.subTest(eta=eta):
                np.testing.assert_array_equal(depolarizing_target_fixed_point(0.0, eta, TAU), TAU)

    def test_equal_minimum_subnormals_preserve_both_weights(self):
        actual = depolarizing_target_fixed_point(MIN_SUBNORMAL, MIN_SUBNORMAL, PURE_TAU)
        np.testing.assert_array_equal(actual, np.diag([0.75, 0.25]))

    def test_unequal_subnormals_preserve_weight_ratio(self):
        actual = depolarizing_target_fixed_point(MIN_SUBNORMAL, 2 * MIN_SUBNORMAL, PURE_TAU)
        np.testing.assert_allclose(actual, np.diag([5 / 6, 1 / 6]), rtol=2e-16, atol=0)

    def test_known_moderate_parameters(self):
        actual = depolarizing_target_fixed_point(0.25, 0.5, TAU)
        np.testing.assert_allclose(actual, 0.2 * I2 + 0.8 * TAU, rtol=2e-16, atol=0)

    def test_full_depolarizing_boundary(self):
        for eta in (0.0, 0.25, 0.75, 1.0):
            with self.subTest(eta=eta):
                expected = (1 - eta) * I2 + eta * TAU
                np.testing.assert_allclose(depolarizing_target_fixed_point(1.0, eta, TAU), expected,
                                           rtol=2e-16, atol=0)

    def test_full_target_boundary(self):
        for p in (0.0, MIN_SUBNORMAL, 0.25, 1.0):
            with self.subTest(p=p):
                np.testing.assert_array_equal(depolarizing_target_fixed_point(p, 1.0, TAU), TAU)

    def test_extreme_probabilities_match_independent_decimal_equation(self):
        cases = (
            (1e-20, 1e-20), (1e-200, 2e-200),
            (MIN_SUBNORMAL, MIN_SUBNORMAL), (MIN_SUBNORMAL, 2 * MIN_SUBNORMAL),
            (1e-300, 1e-20), (1e-20, 1e-300),
            (MIN_SUBNORMAL, np.nextafter(1.0, 0.0)),
            (np.nextafter(1.0, 0.0), MIN_SUBNORMAL),
            (0.125, 0.875), (0.6, 0.4),
        )
        for p, eta in cases:
            with self.subTest(p=p, eta=eta):
                np.testing.assert_allclose(depolarizing_target_fixed_point(p, eta, TAU),
                                           decimal_fixed_point(p, eta, TAU), rtol=4e-16, atol=0)

    def test_independent_channel_application_preserves_fixed_point(self):
        for p in (0.0, 0.01, 0.25, 0.8, 1.0):
            for eta in (0.0, 0.01, 0.5, 0.9, 1.0):
                if p == eta == 0:
                    continue
                for tau in (I2, TAU, PURE_TAU):
                    with self.subTest(p=p, eta=eta, tau=tau.tolist()):
                        fixed = depolarizing_target_fixed_point(p, eta, tau)
                        depolarized = (1 - p) * fixed + p * I2
                        after_channel = (1 - eta) * depolarized + eta * tau
                        np.testing.assert_allclose(after_channel, fixed, rtol=5e-15, atol=3e-16)

    def test_probability_validation(self):
        for invalid in (-1e-10, 1.0001, np.nan, np.inf, -np.inf, True, "0.5", [0.5], 0.5j, 10**400):
            for which in ("p", "eta"):
                with self.subTest(invalid=repr(invalid), which=which):
                    args = {"p": 0.25, "eta": 0.5, "tau": TAU, which: invalid}
                    with self.assertRaises(FixedPointValidationError):
                        depolarizing_target_fixed_point(**args)

    def test_target_validation(self):
        invalid_targets = (
            np.eye(3) / 3, [1.0, 0.0], [[1.0, 0.2], [0.0, 0.0]],
            [[0.5, 0.0], [0.0, 0.4]], [[1.1, 0.0], [0.0, -0.1]],
            [[np.nan, 0.0], [0.0, 0.5]], [[0.5, np.inf], [np.inf, 0.5]],
            [[np.finfo(float).max, 0.0], [0.0, np.finfo(float).max]],
        )
        for invalid in invalid_targets:
            with self.subTest(tau=repr(invalid)):
                with self.assertRaises(FixedPointValidationError):
                    depolarizing_target_fixed_point(0.25, 0.5, invalid)

    def test_random_density_outputs_and_input_preservation(self):
        rng = np.random.default_rng(602002)
        for _ in range(100):
            amplitudes = rng.normal(size=(2, 2)) + 1j * rng.normal(size=(2, 2))
            tau = amplitudes @ amplitudes.conj().T
            tau /= np.trace(tau)
            before = tau.copy()
            fixed = depolarizing_target_fixed_point(float(rng.random()), float(rng.random()), tau)
            self.assertTrue(np.all(np.isfinite(fixed)))
            np.testing.assert_allclose(fixed, fixed.conj().T, atol=1e-15, rtol=0)
            self.assertAlmostEqual(float(np.trace(fixed).real), 1.0, places=14)
            self.assertGreaterEqual(float(np.linalg.eigvalsh(fixed)[0]), -1e-15)
            np.testing.assert_array_equal(tau, before)


if __name__ == "__main__":
    unittest.main(verbosity=2)
