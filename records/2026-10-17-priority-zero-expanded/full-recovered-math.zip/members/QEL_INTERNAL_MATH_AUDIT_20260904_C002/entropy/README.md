# QEL fixed-point contract correction — C002

Owner and project originator: **Sherman G. Laing**, Quantum.Earth.Laing.
Status: **standalone reference candidate; HOLD / UNSIGNED**. No deployment,
original-file replacement, hardware result, or fast convergence is claimed.

`fixed_point_reference.py` corrects the fixed-point calculation for the declared
qubit channel. It is deliberately a standalone successor reference; the complete
historical module has not been reconstructed or asserted byte-identical.

## Source and literal excerpt

The following is a **transcription of the Library-read text excerpt**, provided
by the root audit agent. Original raw-file byte identity has not been verified.

- Source name: `qel_quantum_entropy_stabilization_control_v1.py`, lines 411–420.
- Library identity: `libfile_76ab6fd06138819194e8e8c81eed1992`.
- Source-file identity: `file_00000000554481f5b5f453ffaa94fdac`.
- `ATOL = 1e-10` was recovered from source lines 1–45.
- Associated contract: `libfile_86798c2d87688191a5518466049ee97e`, source-file
  identity `file_00000000ffbc81f58acc5f151f7ff571`. The recovered contract says
  “The unique fixed point is:” without excluding the identity-channel case.

```python
def combined_fixed_point(target: ArrayLike, disturbance_probability: float, control_strength: float) -> ComplexArray:
    tau = validate_density_matrix(target, dimension=2)
    p = _probability(disturbance_probability, name="disturbance_probability")
    eta = _probability(control_strength, name="control_strength")
    contraction = (1.0 - eta) * (1.0 - p)
    denominator = 1.0 - contraction
    if denominator <= ATOL:
        raise EntropyControlError("combined channel lacks a unique fixed point")
    numerator = (1.0 - eta) * p * I2 / 2.0 + eta * tau
    return validate_density_matrix(numerator / denominator, dimension=2)
```

## Corrected mathematics

For a qubit density matrix, define the channels in their declared order:

\[
D_p(\rho)=(1-p)\rho+pI/2,\qquad
C_\eta(\rho)=(1-\eta)\rho+\eta\tau,
\]

where \(0\le p,\eta\le1\) and \(\tau\) is a valid two-dimensional density
matrix. Their composition is

\[
T(\rho)=a\rho+bI/2+c\tau,
\quad a=(1-\eta)(1-p),\quad b=(1-\eta)p,\quad c=\eta.
\]

If \(p=\eta=0\), \(T\) is the identity and every density matrix is a fixed
point. Otherwise \(b+c=p+\eta-p\eta>0\), and there is exactly one fixed point:

\[
\rho_* = \frac{b}{b+c}\frac I2+\frac{c}{b+c}\tau.
\]

Thus the recovered tolerance gate conflates a small positive denominator with
mathematical nonuniqueness. It also computes that denominator by subtracting
nearly equal quantities, which rounds to zero for examples such as
\(p=10^{-20},\eta=0\). In this example the fixed point is exactly \(I/2\).

The reference takes \(s=\max(p,\eta)>0\) and computes

\[
u=(p/s)(1-\eta),\quad v=\eta/s,\quad
\rho_* = \frac u{u+v}\frac I2+\frac v{u+v}\tau.
\]

Scaling happens before multiplication. The exact scaled denominator lies in
\([1,2]\), since \(\max(p,\eta)\le p+\eta-p\eta\le2\max(p,\eta)\).
This avoids cancellation and preserves meaningful relative weights even when
both probabilities are the smallest positive float64 subnormal. An individual
weight below float64 representability may still round to zero; arbitrary
precision is not claimed.

## Verification and interpretation

There are **13 focused test methods**, with subcases. They cover analytic
boundaries, exact nonuniqueness, unequal and equal subnormal probabilities,
finite probability and density validation, and input preservation. The suite
also compares against a **760-digit Decimal calculation of the original affine
equation** for 10 parameter pairs, checks **72** moderate-parameter channel
invariances, and checks **100** seeded random density outputs. These subcases
are not reported as additional unittest methods.

The Decimal oracle uses exact conversion of each tested binary float. It
evaluates `1 - (1-eta)*(1-p)` at high precision, independently of the scaled
implementation. This is necessary because a one-step channel invariance check
alone can pass trivially when an extremely weak channel rounds to the identity.

Uniqueness is an exact mathematical property. When \(a<1\), iterated channel
differences contract by \(a^n\); a value extremely close to one means very
slow convergence. For \(p=10^{-20},\eta=0\), the characteristic decay scale
is approximately \(10^{20}\) iterations. The corrected existence calculation
does not make those iterations faster or make their individual effects
resolvable in float64.

Run `python run_entropy_audit.py` from this directory. It regenerates
`entropy_test_output.txt` and `entropy_results.json`, recording both the tests
and a clearly labeled numerical reproduction of the old denominator gate.
The recovered full original module is not executed by this runner.
