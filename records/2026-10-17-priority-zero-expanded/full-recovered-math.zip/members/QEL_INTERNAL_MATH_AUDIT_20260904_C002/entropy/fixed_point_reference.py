"""QEL-MATH-20260904-C002: a standalone corrected fixed-point reference.

Project: Quantum.Earth.Laing. Originator: Sherman G. Laing.
Review role: GAUCIA / independent numerical review.
Status: research candidate; HOLD / UNSIGNED; no deployment implied.

Contract recovered from qel_quantum_entropy_stabilization_control_v1.py,
Library file libfile_76ab6fd06138819194e8e8c81eed1992, lines 411-420:

    D_p(rho) = (1-p)*rho + p*I/2
    C_eta(rho) = (1-eta)*rho + eta*tau
    T(rho) = C_eta(D_p(rho))

This file is a new, bounded mathematical reference. It does not reconstruct
or claim to replace the complete historical source module.

The unique fixed point exists iff p and eta are not both zero. Its two
convex weights are proportional to p*(1-eta) and eta. Scaling p and eta
BEFORE multiplication avoids subtracting nearly equal numbers and preserves
relative weights when both positive probabilities are subnormal.

Existence is distinct from convergence speed or floating-point resolvability.
For tiny positive probabilities, one channel step can round to the identity;
that does not make the exact mathematical fixed point nonunique.
"""

from __future__ import annotations

import numbers

import numpy as np
from numpy.typing import ArrayLike, NDArray

DENSITY_ATOL = 1e-12


class FixedPointValidationError(ValueError):
    """The declared channel contract is invalid or lacks a unique fixed point."""


def _probability(value: float, *, name: str) -> float:
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Real):
        raise FixedPointValidationError(f"{name} must be a real probability")
    try:
        result = float(value)
    except (TypeError, ValueError, OverflowError) as exc:
        raise FixedPointValidationError(f"{name} must be a finite probability") from exc
    if not np.isfinite(result) or not 0.0 <= result <= 1.0:
        raise FixedPointValidationError(f"{name} must be finite and within [0, 1]")
    return result


def _target_density(tau: ArrayLike) -> NDArray[np.complex128]:
    try:
        target = np.asarray(tau, dtype=np.complex128)
    except (TypeError, ValueError, OverflowError) as exc:
        raise FixedPointValidationError("tau must be a 2x2 density matrix") from exc
    if target.shape != (2, 2):
        raise FixedPointValidationError("tau must be a 2x2 density matrix")
    if not np.all(np.isfinite(target.real)) or not np.all(np.isfinite(target.imag)):
        raise FixedPointValidationError("tau must contain finite components")
    # Every component of a positive semidefinite, trace-one density matrix
    # has magnitude at most one. Check real/imaginary components separately
    # before sums/subtractions can overflow on invalid finite input.
    if (np.any(np.abs(target.real) > 1.0 + DENSITY_ATOL)
            or np.any(np.abs(target.imag) > 1.0 + DENSITY_ATOL)):
        raise FixedPointValidationError("tau components exceed density-matrix bounds")
    if not np.allclose(target, target.conj().T, atol=DENSITY_ATOL, rtol=0.0):
        raise FixedPointValidationError("tau must be Hermitian")
    if not np.isclose(np.trace(target), 1.0, atol=DENSITY_ATOL, rtol=0.0):
        raise FixedPointValidationError("tau must have trace one")
    # Validation tolerance is explicit; the caller's matrix is not projected,
    # renormalized, or otherwise silently changed.
    hermitian_part = target / 2.0 + target.conj().T / 2.0
    if np.min(np.linalg.eigvalsh(hermitian_part)) < -DENSITY_ATOL:
        raise FixedPointValidationError("tau must be positive semidefinite")
    return target.copy()


def depolarizing_target_fixed_point(
    p: float, eta: float, tau: ArrayLike
) -> NDArray[np.complex128]:
    """Return the unique fixed point of C_eta after D_p on a qubit.

    Probabilities are interpreted as their finite float64 values. Only the
    exact identity-channel case p == eta == 0 is rejected as nonunique.
    Density validity is checked to absolute tolerance DENSITY_ATOL.
    """
    p = _probability(p, name="p")
    eta = _probability(eta, name="eta")
    target = _target_density(tau)
    scale = max(p, eta)
    if scale == 0.0:
        raise FixedPointValidationError(
            "nonunique fixed point: p = eta = 0 makes the channel the identity"
        )

    depolarizing_scaled = (p / scale) * (1.0 - eta)
    target_scaled = eta / scale
    # In exact arithmetic this sum lies in [1, 2], so the division cannot
    # overflow or have a vanishing denominator for any valid probabilities.
    total_scaled = depolarizing_scaled + target_scaled
    depolarizing_weight = depolarizing_scaled / total_scaled
    target_weight = target_scaled / total_scaled
    result = (
        depolarizing_weight * (np.eye(2, dtype=np.complex128) / 2.0)
        + target_weight * target
    )
    if not np.all(np.isfinite(result)):
        raise FixedPointValidationError("fixed-point calculation produced nonfinite output")
    return result
