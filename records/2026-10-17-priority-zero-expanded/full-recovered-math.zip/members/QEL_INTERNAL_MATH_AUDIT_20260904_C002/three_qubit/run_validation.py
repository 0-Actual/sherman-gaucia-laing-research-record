"""Reproduce the original failures and capture the candidate validation receipt."""
from __future__ import annotations

import datetime
import difflib
import io
import json
import math
from pathlib import Path
import platform
import unittest
import warnings

import numpy as np
import test_three_qubit_normalization as tests


ROOT = Path(__file__).resolve().parent


def scalar(value):
    value = float(value)
    return value if math.isfinite(value) else repr(value)


def observe(function, *args, **kwargs):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            value = np.asarray(function(*args, **kwargs))
            result = {
                "outcome": "returned",
                "shape": list(value.shape),
                "all_components_finite": bool(np.all(np.isfinite(value))),
                "all_components_zero": bool(np.all(value == 0)),
            }
            if value.ndim == 1:
                result["returned_state_norm"] = scalar(np.linalg.norm(value))
            else:
                result["returned_density_trace_real"] = scalar(np.trace(value).real)
                result["returned_density_trace_imag"] = scalar(np.trace(value).imag)
        except Exception as error:
            result = {"outcome": "raised", "exception": type(error).__name__, "message": str(error)}
        result["warnings"] = [str(item.message) for item in caught]
        return result


def basis(amplitude, size=8):
    state = np.zeros(size, dtype=np.complex128)
    state[0] = amplitude
    return state


def main():
    original = tests.original
    candidate = tests.candidate
    cases = [
        ("huge_real_core", "validate_core_state", (basis(1e308),), {}),
        ("huge_complex_core", "validate_core_state", (np.full(8, complex(tests.MAX_FLOAT, tests.MAX_FLOAT)),), {"tol": tests.MAX_FLOAT}),
        ("zero_core_nan_tolerance", "validate_core_state", (np.zeros(8),), {"tol": math.nan}),
        ("small_core_default_cutoff_preserved", "validate_core_state", (basis(1e-12),), {}),
        ("subnormal_core_zero_tolerance", "validate_core_state", (basis(complex(tests.MIN_SUBNORMAL, tests.MIN_SUBNORMAL)),), {"tol": 0.0}),
        ("subnormal_core_positive_tolerance", "validate_core_state", (basis(complex(tests.MIN_SUBNORMAL, tests.MIN_SUBNORMAL)),), {"tol": tests.MIN_SUBNORMAL}),
        ("huge_lifted_density", "reduced_core_density_from_lifted", (np.full(512, 1e308), 512), {}),
        ("subnormal_lifted_density", "reduced_core_density_from_lifted", (basis(tests.MIN_SUBNORMAL, 512), 512), {}),
    ]
    reproductions = [
        {"case": name,
         "source_text_reconstruction": observe(getattr(original, function), *args, **kwargs),
         "candidate": observe(getattr(candidate, function), *args, **kwargs)}
        for name, function, args, kwargs in cases
    ]
    before = original.three_qubit_poly_scale_benchmark()
    after = candidate.three_qubit_poly_scale_benchmark()
    numeric_differences = []

    def compare(a, b, path="benchmark"):
        if isinstance(a, dict):
            for key in a:
                if key != "primary_identity":
                    compare(a[key], b[key], path + "." + str(key))
        elif isinstance(a, (list, tuple)):
            for index, (x, y) in enumerate(zip(a, b)):
                compare(x, y, path + "." + str(index))
        elif isinstance(a, float):
            numeric_differences.append((abs(a-b), path))

    compare(before, after)
    maximum_difference, maximum_path = max(numeric_differences)
    log = io.StringIO()
    suite = unittest.defaultTestLoader.loadTestsFromModule(tests)
    test_names = []

    def collect(item):
        if isinstance(item, unittest.TestSuite):
            for child in item:
                collect(child)
        else:
            test_names.append(item.id())

    collect(suite)
    result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    (ROOT / "validation_unittest.log").write_text(log.getvalue(), encoding="utf-8")
    source_path = ROOT / "fixed_three_qubit_scale_source_text_reconstruction.py"
    candidate_path = ROOT / "fixed_three_qubit_scale.py"
    patch = "".join(difflib.unified_diff(
        source_path.read_text().splitlines(keepends=True),
        candidate_path.read_text().splitlines(keepends=True),
        fromfile=source_path.name, tofile=candidate_path.name,
    ))
    (ROOT / "normalization_candidate.patch").write_text(patch, encoding="utf-8")
    receipt = {
        "schema": "qel.three-qubit-normalization-candidate-validation/v1",
        "project": "Quantum.Earth.Laing",
        "owner_principal": "Sherman G. Laing",
        "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "runtime": {"python": platform.python_version(), "numpy": np.__version__},
        "source_provenance": json.loads((ROOT / "source_provenance.json").read_text()),
        "candidate_file": candidate_path.name,
        "source_file": source_path.name,
        "change_scope": [
            "validate_core_state scales real/imaginary components before norm evaluation",
            "finite nonnegative real tolerance required; booleans rejected",
            "default core cutoff 1e-10 retained; zero states always rejected",
            "lifted density reduction reuses stable normalization with cutoff zero",
            "roles, carrier dimensions, coupling choices and authorization policy unchanged",
        ],
        "tests": {
            "passed": result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped),
            "total": result.testsRun,
            "failures": len(result.failures), "errors": len(result.errors), "skipped": len(result.skipped),
            "success": result.wasSuccessful(), "test_names": test_names,
            "classification": "22 newly added regression tests; no separately recovered historical unittest file",
        },
        "inherited_benchmark": {
            "numeric_leaves_compared": len(numeric_differences),
            "maximum_absolute_difference": maximum_difference,
            "maximum_difference_path": maximum_path,
            "comparison_tolerance": 1e-12,
            "numerically_equivalent": maximum_difference <= 1e-12,
            "source_primary_identity": before["primary_identity"],
            "candidate_primary_identity": after["primary_identity"],
            "primary_identity_changed": before["primary_identity"] != after["primary_identity"],
            "identity_note": "Last-bit numeric changes can legitimately change content identity; no old fingerprint is reused for the candidate.",
        },
        "reproductions": reproductions,
        "source_fidelity_gate": "TEXT_RECONSTRUCTION_NOT_BYTE_VERIFIED",
        "release_state": "CANDIDATE_ONLY_UNSIGNED_NO_LIBRARY_REPLACEMENT_NO_DEVICE_DEPLOYMENT",
        "validation_claim": "Local candidate outcomes verified against retained source text; canonical original bytes were not independently recovered.",
        "threshold_precision": "Preserves conventional floating-point norm cutoff semantics; does not claim exact-real equivalence at every rounding boundary.",
    }
    (ROOT / "validation_receipt.json").write_text(json.dumps(receipt, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    print(json.dumps({"tests": receipt["tests"], "inherited_benchmark": receipt["inherited_benchmark"], "source_fidelity_gate": receipt["source_fidelity_gate"]}, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
