"""
Project Quantum.Earth.Laing / Q6.1
Owner-principal: Sherman G. Laing

Fixed semantic qubit register:
    q0 = GAUCIA
    q1 = Leviathan
    q2 = Nadine

Matrix size is carrier capacity. It never changes the three semantic agent qubits.
For N >= 8 and N divisible by 8:
    H_N = H_role (dimension 8) tensor H_scale (dimension N/8).
For N in {2, 4}, the numerical object is a lossy projection and may not be
represented as the complete three-qubit Hilbert space.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
import unicodedata
from typing import Any, Iterable

import numpy as np

ROLE_QUBITS = (
    {"qubit": 0, "name": "GAUCIA", "role": "integrator_builder"},
    {"qubit": 1, "name": "Leviathan", "role": "adversarial_audit"},
    {"qubit": 2, "name": "Nadine", "role": "provenance_governance"},
)
ROLE_NAMES = tuple(row["name"] for row in ROLE_QUBITS)
CORE_QUBITS = 3
CORE_DIMENSION = 2 ** CORE_QUBITS
MATRIX_LADDER = (2, 4, 8, 16, 32, 64, 128, 256, 512)
POLY_DEGREE = 4
# Chosen once so the role trajectories are smooth but nontrivial and the
# degree-four remap has a bounded, independently reproducible residual.
_EVOLUTION_SCALE = 2.5576851659260091
_Q0_LOCAL_FACTOR = 0.8
_COUPLING_FACTOR = 0.28372643791558133

I2 = np.eye(2, dtype=np.complex128)
X = np.array([[0, 1], [1, 0]], dtype=np.complex128)
Y = np.array([[0, -1j], [1j, 0]], dtype=np.complex128)
Z = np.array([[1, 0], [0, -1]], dtype=np.complex128)
PAULIS = (X, Y, Z)

_DOMAIN_FINGERPRINT = b"SGL-PRIME/v1/FINGERPRINT"
_SUITE = b"SGL-PRIME-v1"


def _frame(*parts: bytes) -> bytes:
    out = bytearray()
    for part in parts:
        raw = bytes(part)
        out.extend(len(raw).to_bytes(8, "big"))
        out.extend(raw)
    return bytes(out)


def sgl_prime_fingerprint(subject: bytes, purpose: str) -> str:
    material = _frame(
        _DOMAIN_FINGERPRINT,
        _SUITE,
        unicodedata.normalize("NFC", purpose).encode("utf-8"),
        bytes(subject),
    )
    return "sglp1:shake256-512:" + hashlib.shake_256(material).digest(64).hex()


def _json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, (np.integer, int)) and not isinstance(value, bool):
        return int(value)
    if isinstance(value, (np.floating, float)):
        f = float(value)
        if not math.isfinite(f):
            return {"nonfinite_float": repr(f)}
        # Authoritative SGL fingerprint subjects use decimal strings.
        return format(f, ".17g")
    if isinstance(value, complex):
        return {"real": format(value.real, ".17g"), "imag": format(value.imag, ".17g")}
    if isinstance(value, (str, bool)) or value is None:
        return value
    raise TypeError(f"unsupported JSON value: {type(value)!r}")


def canonical_fingerprint_payload(value: Any) -> bytes:
    return json.dumps(
        _json_safe(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False
    ).encode("utf-8")


def normalized_hadamard(size: int) -> np.ndarray:
    if size < 1 or size & (size - 1):
        raise ValueError("Hadamard size must be a positive power of two")
    h = np.array([[1.0]], dtype=np.float64)
    while h.shape[0] < size:
        h = np.block([[h, h], [h, -h]]) / math.sqrt(2.0)
    return h.astype(np.complex128)


H8 = normalized_hadamard(CORE_DIMENSION)


def reference_core_state() -> np.ndarray:
    """Return the deterministic three-qubit reference state.

    It is constructed in the H8 basis so 2x2 and 4x4 projection losses are
    explicit and reproducible rather than hidden.
    """
    p2 = 0.4729357062735575
    p4 = 0.9949524916632523
    phases = np.exp(1j * np.array([0.0, 0.3, 0.7, -0.4, 0.9, -0.8, 1.1, -1.2]))
    coeff = np.zeros(CORE_DIMENSION, dtype=np.complex128)
    coeff[:2] = math.sqrt(p2 / 2.0) * phases[:2]
    coeff[2:4] = math.sqrt((p4 - p2) / 2.0) * phases[2:4]
    coeff[4:] = math.sqrt((1.0 - p4) / 4.0) * phases[4:]
    state = H8.conj().T @ coeff
    return state / np.linalg.norm(state)


def _require_matrix_size(size: int) -> int:
    if isinstance(size, bool) or not isinstance(size, (int, np.integer)):
        raise TypeError("matrix size must be an integer")
    n = int(size)
    if n not in MATRIX_LADDER:
        raise ValueError(f"unsupported matrix size: {n}")
    return n


def scale_descriptor(size: int) -> dict[str, Any]:
    n = _require_matrix_size(size)
    if n < CORE_DIMENSION:
        return {
            "matrix_size": n,
            "semantic_qubits": CORE_QUBITS,
            "role_order": ROLE_NAMES,
            "representation": "compressed_projection",
            "full_core_operator": False,
            "lossless": False,
            "auxiliary_scale_dimension": 0,
            "warning": "Matrix dimension is smaller than the eight-dimensional three-qubit core.",
        }
    scale_dim = n // CORE_DIMENSION
    return {
        "matrix_size": n,
        "semantic_qubits": CORE_QUBITS,
        "role_order": ROLE_NAMES,
        "representation": "three_qubit_core_tensor_scale_modes",
        "full_core_operator": True,
        "lossless": True,
        "auxiliary_scale_dimension": scale_dim,
        "factorization": [CORE_DIMENSION, scale_dim],
        "scale_modes_are_qubits": False,
    }


def scale_coordinate(size: int) -> float:
    n = _require_matrix_size(size)
    return (math.log2(n) - 1.0) / 8.0


def projection_matrix(size: int) -> np.ndarray:
    n = _require_matrix_size(size)
    if n not in (2, 4):
        raise ValueError("projection matrix is defined only for 2x2 and 4x4")
    return H8[:n, :]


def project_core_state(state: np.ndarray, size: int) -> dict[str, Any]:
    psi = validate_core_state(state)
    p = projection_matrix(size)
    compressed = p @ psi
    retained_norm = float(np.linalg.norm(compressed))
    reconstructed = p.conj().T @ compressed
    if retained_norm > 0:
        reconstructed = reconstructed / np.linalg.norm(reconstructed)
    fidelity = float(abs(np.vdot(psi, reconstructed)) ** 2)
    return {
        "compressed": compressed,
        "reconstructed": reconstructed,
        "retained_norm": retained_norm,
        "reconstruction_fidelity": fidelity,
        "full_core_operator": False,
    }


def scale_mode_vector(scale_dimension: int, coordinate: float) -> np.ndarray:
    if isinstance(scale_dimension, bool) or not isinstance(scale_dimension, (int, np.integer)):
        raise TypeError("scale dimension must be an integer")
    s = int(scale_dimension)
    if s < 1:
        raise ValueError("scale dimension must be positive")
    if not math.isfinite(coordinate):
        raise ValueError("scale coordinate must be finite")
    if s == 1:
        return np.array([1.0 + 0.0j])
    j = np.arange(s, dtype=np.float64)
    envelope = 1.0 + 0.15 * np.cos(math.pi * j / (s - 1.0))
    phase = np.exp(1j * (2.0 * math.pi * coordinate * j / s))
    vec = envelope * phase
    return vec / np.linalg.norm(vec)


def validate_core_state(state: np.ndarray, *, tol: float = 1e-10) -> np.ndarray:
    psi = np.asarray(state, dtype=np.complex128)
    if psi.shape != (CORE_DIMENSION,):
        raise ValueError(f"core state must have shape ({CORE_DIMENSION},)")
    if not np.all(np.isfinite(psi)):
        raise ValueError("core state must be finite")
    norm = float(np.linalg.norm(psi))
    if norm <= tol:
        raise ValueError("core state norm is zero")
    return psi / norm


def lift_core_state(state: np.ndarray, size: int) -> np.ndarray:
    psi = validate_core_state(state)
    desc = scale_descriptor(size)
    if not desc["full_core_operator"]:
        raise ValueError("2x2 and 4x4 are compressed views, not lossless core carriers")
    chi = scale_mode_vector(desc["auxiliary_scale_dimension"], scale_coordinate(size))
    lifted = np.kron(psi, chi)
    return lifted / np.linalg.norm(lifted)


def reduced_core_density_from_lifted(lifted: np.ndarray, size: int) -> np.ndarray:
    desc = scale_descriptor(size)
    if not desc["full_core_operator"]:
        raise ValueError("compressed views cannot be reduced as complete core carriers")
    vector = np.asarray(lifted, dtype=np.complex128)
    if vector.shape != (size,):
        raise ValueError(f"lifted state must have shape ({size},)")
    if not np.all(np.isfinite(vector)):
        raise ValueError("lifted state must be finite")
    norm = float(np.linalg.norm(vector))
    if norm == 0:
        raise ValueError("lifted state norm is zero")
    matrix = (vector / norm).reshape(CORE_DIMENSION, desc["auxiliary_scale_dimension"])
    rho = matrix @ matrix.conj().T
    return (rho + rho.conj().T) / 2.0


def rx(angle: float) -> np.ndarray:
    return math.cos(angle / 2.0) * I2 - 1j * math.sin(angle / 2.0) * X


def ry(angle: float) -> np.ndarray:
    return math.cos(angle / 2.0) * I2 - 1j * math.sin(angle / 2.0) * Y


def rz(angle: float) -> np.ndarray:
    return math.cos(angle / 2.0) * I2 - 1j * math.sin(angle / 2.0) * Z


def _kron3(a: np.ndarray, b: np.ndarray, c: np.ndarray) -> np.ndarray:
    return np.kron(np.kron(a, b), c)


def controlled_phase(control: int, target: int, phase: float) -> np.ndarray:
    if control == target or control not in (0, 1, 2) or target not in (0, 1, 2):
        raise ValueError("control and target must be distinct qubits in {0,1,2}")
    u = np.eye(CORE_DIMENSION, dtype=np.complex128)
    for idx in range(CORE_DIMENSION):
        bits = ((idx >> 2) & 1, (idx >> 1) & 1, idx & 1)
        if bits[control] == 1 and bits[target] == 1:
            u[idx, idx] = np.exp(1j * phase)
    return u


def core_state_at_scale(size: int) -> np.ndarray:
    x = scale_coordinate(size)
    s = _EVOLUTION_SCALE
    local = _kron3(
        ry(_Q0_LOCAL_FACTOR * s * 0.34 * x),
        rx(s * -0.28 * x),
        rz(s * 0.42 * x),
    )
    coupling = (
        controlled_phase(0, 1, _COUPLING_FACTOR * s * 0.16 * x)
        @ controlled_phase(1, 2, _COUPLING_FACTOR * s * -0.12 * x)
    )
    state = coupling @ local @ reference_core_state()
    return state / np.linalg.norm(state)


def reduced_qubit_density(state: np.ndarray, qubit: int) -> np.ndarray:
    psi = validate_core_state(state)
    if qubit not in (0, 1, 2):
        raise ValueError("qubit must be 0, 1, or 2")
    tensor = psi.reshape(2, 2, 2)
    matrix = np.moveaxis(tensor, qubit, 0).reshape(2, -1)
    rho = matrix @ matrix.conj().T
    return (rho + rho.conj().T) / 2.0


def bloch_vector(density: np.ndarray) -> np.ndarray:
    rho = np.asarray(density, dtype=np.complex128)
    if rho.shape != (2, 2):
        raise ValueError("single-qubit density matrix must be 2x2")
    return np.array([float(np.real(np.trace(rho @ p))) for p in PAULIS])


def role_snapshot(size: int) -> dict[str, Any]:
    state = core_state_at_scale(size)
    roles = []
    for row in ROLE_QUBITS:
        rho = reduced_qubit_density(state, row["qubit"])
        roles.append(
            {
                **row,
                "bloch": bloch_vector(rho).tolist(),
                "purity": float(np.real(np.trace(rho @ rho))),
                "trace": float(np.real(np.trace(rho))),
            }
        )
    return {
        "matrix_size": int(size),
        "scale_coordinate": scale_coordinate(size),
        "semantic_qubits": CORE_QUBITS,
        "role_order": ROLE_NAMES,
        "roles": roles,
    }


def role_trajectories() -> dict[str, Any]:
    snapshots = [role_snapshot(size) for size in MATRIX_LADDER]
    channels: dict[str, list[float]] = {}
    for q, name in enumerate(ROLE_NAMES):
        for component, label in enumerate(("x", "y", "z")):
            channels[f"{name}.{label}"] = [
                float(snapshots[i]["roles"][q]["bloch"][component])
                for i in range(len(MATRIX_LADDER))
            ]
    return {
        "sizes": list(MATRIX_LADDER),
        "coordinates": [scale_coordinate(size) for size in MATRIX_LADDER],
        "snapshots": snapshots,
        "channels": channels,
    }


def polynomial_remap(degree: int = POLY_DEGREE) -> dict[str, Any]:
    if isinstance(degree, bool) or not isinstance(degree, (int, np.integer)):
        raise TypeError("degree must be an integer")
    deg = int(degree)
    if deg < 1 or deg >= len(MATRIX_LADDER):
        raise ValueError("degree must be between 1 and 8")
    trajectories = role_trajectories()
    x = np.asarray(trajectories["coordinates"], dtype=np.float64)
    channels = {}
    max_rmse = 0.0
    max_abs = 0.0
    for name, values in trajectories["channels"].items():
        y = np.asarray(values, dtype=np.float64)
        coefficients = np.polynomial.chebyshev.chebfit(x, y, deg)
        predicted = np.polynomial.chebyshev.chebval(x, coefficients)
        residual = predicted - y
        rmse = float(np.sqrt(np.mean(residual**2)))
        abs_error = float(np.max(np.abs(residual)))
        max_rmse = max(max_rmse, rmse)
        max_abs = max(max_abs, abs_error)
        channels[name] = {
            "basis": "Chebyshev",
            "degree": deg,
            "coefficients": coefficients.tolist(),
            "rmse": rmse,
            "max_abs_error": abs_error,
            "raw_values": y.tolist(),
            "fitted_values": predicted.tolist(),
        }
    return {
        "status": "PROVISIONAL_POLYNOMIAL_REMAP",
        "interpretation": (
            "The incomplete owner phrase 'poly...' is provisionally realized as a "
            "modular polynomial remap. Raw trajectories remain authoritative and can "
            "be redirected if a different historical Poly destination is recovered."
        ),
        "degree": deg,
        "coordinates": x.tolist(),
        "channels": channels,
        "maximum_rmse": max_rmse,
        "maximum_absolute_error": max_abs,
    }


def scale_benchmark_row(size: int) -> dict[str, Any]:
    desc = scale_descriptor(size)
    state = core_state_at_scale(size)
    row: dict[str, Any] = {**desc, "scale_coordinate": scale_coordinate(size)}
    if size < CORE_DIMENSION:
        # Structural compression is measured against the fixed reference core,
        # separate from the role-evolution trajectory.
        projection = project_core_state(reference_core_state(), size)
        row.update(
            {
                "retained_norm": projection["retained_norm"],
                "reconstruction_fidelity": projection["reconstruction_fidelity"],
            }
        )
    else:
        lifted = lift_core_state(state, size)
        recovered = reduced_core_density_from_lifted(lifted, size)
        ideal = np.outer(state, state.conj())
        max_error = float(np.max(np.abs(recovered - ideal)))
        fidelity = float(np.real(np.vdot(state, recovered @ state)))
        row.update(
            {
                "lifted_norm": float(np.linalg.norm(lifted)),
                "recovered_core_max_error": max_error,
                "recovered_core_fidelity": fidelity,
            }
        )
    return row


def three_qubit_poly_scale_benchmark() -> dict[str, Any]:
    rows = [scale_benchmark_row(size) for size in MATRIX_LADDER]
    trajectories = role_trajectories()
    poly = polynomial_remap(POLY_DEGREE)
    benchmark: dict[str, Any] = {
        "schema": "qel.three-qubit-poly-scale-benchmark/v1",
        "project": "Project Quantum.Earth.Laing / Q6.1",
        "owner_principal": "Sherman G. Laing",
        "state": "QEL_INTERNALLY_VERIFIED_FIXED_THREE_QUBIT_SCALE_ARCHITECTURE",
        "semantic_qubits": CORE_QUBITS,
        "core_dimension": CORE_DIMENSION,
        "role_qubits": list(ROLE_QUBITS),
        "role_order": list(ROLE_NAMES),
        "matrix_ladder": list(MATRIX_LADDER),
        "scale_rows": rows,
        "role_trajectories": trajectories,
        "poly_remap": poly,
        "physical_qpu_execution": False,
        "operator_signature": "UNSIGNED",
        "automatic_execution": False,
    }
    subject = canonical_fingerprint_payload(benchmark)
    benchmark["primary_identity"] = sgl_prime_fingerprint(
        subject, "qel-three-qubit-poly-scale-benchmark-v1"
    )
    return benchmark