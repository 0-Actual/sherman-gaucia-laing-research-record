"""Outcome regressions for the reconstructed QEL three-qubit source candidate."""
from __future__ import annotations

import importlib.util
import math
from pathlib import Path
import sys
import unittest

import numpy as np


ROOT = Path(__file__).resolve().parent


def load_source(name: str, filename: str):
    spec = importlib.util.spec_from_file_location(name, ROOT / filename)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


candidate = load_source("three_qubit_candidate", "fixed_three_qubit_scale.py")
original = load_source(
    "three_qubit_source_reconstruction", "fixed_three_qubit_scale_source_text_reconstruction.py"
)
MIN_SUBNORMAL = float(np.nextafter(0.0, 1.0))
MAX_FLOAT = float(np.finfo(np.float64).max)


class CoreNormalizationTests(unittest.TestCase):
    def assert_unit_state(self, state):
        self.assertEqual(state.shape, (8,))
        self.assertTrue(np.all(np.isfinite(state)))
        self.assertAlmostEqual(float(np.vdot(state, state).real), 1.0, places=14)

    def test_huge_real_state_retains_direction(self):
        state = np.zeros(8, dtype=np.complex128)
        state[0] = 1e308
        result = candidate.validate_core_state(state)
        self.assert_unit_state(result)
        expected = np.zeros(8, dtype=np.complex128)
        expected[0] = 1.0
        np.testing.assert_array_equal(result, expected)

    def test_huge_complex_state_with_maximum_tolerance(self):
        state = np.full(8, complex(MAX_FLOAT, MAX_FLOAT))
        result = candidate.validate_core_state(state, tol=MAX_FLOAT)
        self.assert_unit_state(result)
        np.testing.assert_allclose(result, np.full(8, 0.25 + 0.25j), rtol=1e-14)

    def test_subnormal_components_are_normalized_when_tolerance_is_zero(self):
        state = np.zeros(8, dtype=np.complex128)
        state[0] = complex(MIN_SUBNORMAL, MIN_SUBNORMAL)
        result = candidate.validate_core_state(state, tol=0.0)
        self.assert_unit_state(result)
        self.assertAlmostEqual(result[0].real, 1.0 / math.sqrt(2.0), places=14)
        self.assertAlmostEqual(result[0].imag, 1.0 / math.sqrt(2.0), places=14)

    def test_positive_subnormal_tolerance_is_preserved_without_false_rejection(self):
        state = np.zeros(8, dtype=np.complex128)
        state[0] = complex(MIN_SUBNORMAL, MIN_SUBNORMAL)
        self.assert_unit_state(candidate.validate_core_state(state, tol=MIN_SUBNORMAL))

    def test_small_positive_default_tolerance_still_rejects_small_states(self):
        state = np.zeros(8, dtype=np.complex128)
        state[0] = 1e-12
        with self.assertRaises(ValueError):
            candidate.validate_core_state(state)

    def test_tolerance_equality_and_adjacent_floats(self):
        threshold = 2.0 ** -30
        for amplitude, accepted in (
            (np.nextafter(threshold, 0.0), False),
            (threshold, False),
            (np.nextafter(threshold, math.inf), True),
        ):
            with self.subTest(amplitude=amplitude, accepted=accepted):
                state = np.zeros(8, dtype=np.complex128)
                state[0] = amplitude
                if accepted:
                    self.assert_unit_state(candidate.validate_core_state(state, tol=threshold))
                else:
                    with self.assertRaises(ValueError):
                        candidate.validate_core_state(state, tol=threshold)

    def test_extreme_threshold_ratio_rejects_cleanly(self):
        state = np.zeros(8, dtype=np.complex128)
        state[0] = MIN_SUBNORMAL
        with self.assertRaises(ValueError):
            candidate.validate_core_state(state, tol=MAX_FLOAT)

    def test_phase_and_positive_scale_are_preserved(self):
        state = candidate.reference_core_state()
        phase = complex(-0.6, 0.8)
        expected = state * phase
        for scale in (1.0, 1e150, 1e308):
            with self.subTest(scale=scale):
                result = candidate.validate_core_state(expected * scale)
                self.assert_unit_state(result)
                np.testing.assert_allclose(result, expected, rtol=1e-14, atol=1e-15)

    def test_signed_real_and_imaginary_components_are_preserved(self):
        state = np.array([-3+4j, 2-1j, -2-2j, 1j, 1, -1, -1j, 0], dtype=np.complex128)
        expected = state / np.linalg.norm(state)
        np.testing.assert_allclose(
            candidate.validate_core_state(state * 1e200), expected, rtol=1e-14, atol=1e-15
        )

    def test_input_is_not_mutated(self):
        state = np.arange(8, dtype=np.float64).astype(np.complex128) * (1.0 + 2.0j)
        snapshot = state.copy()
        candidate.validate_core_state(state)
        np.testing.assert_array_equal(state, snapshot)

    def test_zero_is_always_rejected(self):
        for tol in (0.0, 1e-10):
            with self.subTest(tol=tol), self.assertRaises(ValueError):
                candidate.validate_core_state(np.zeros(8, dtype=np.complex128), tol=tol)

    def test_invalid_tolerances_are_rejected(self):
        state = np.ones(8, dtype=np.complex128)
        invalid = (math.nan, math.inf, -math.inf, -1.0, True, False, np.bool_(True),
                   1+0j, "0.0", [0.0], np.array(0.0), 10**1000)
        for tol in invalid:
            with self.subTest(tol=repr(tol)), self.assertRaises(ValueError):
                candidate.validate_core_state(state, tol=tol)

    def test_invalid_core_shapes_are_rejected(self):
        for shape in ((0,), (4,), (16,), (8, 1), (2, 2, 2)):
            with self.subTest(shape=shape), self.assertRaises(ValueError):
                candidate.validate_core_state(np.ones(shape, dtype=np.complex128))

    def test_nonfinite_core_components_are_rejected(self):
        for value in (math.nan, math.inf, -math.inf, complex(0.0, math.inf)):
            with self.subTest(value=value), self.assertRaises(ValueError):
                state = np.ones(8, dtype=np.complex128)
                state[2] = value
                candidate.validate_core_state(state)


class LiftedDensityTests(unittest.TestCase):
    def assert_density(self, rho):
        self.assertEqual(rho.shape, (8, 8))
        self.assertTrue(np.all(np.isfinite(rho)))
        np.testing.assert_allclose(rho, rho.conj().T, atol=1e-14)
        self.assertAlmostEqual(float(np.trace(rho).real), 1.0, places=13)
        self.assertGreaterEqual(float(np.linalg.eigvalsh(rho).min()), -1e-13)

    def test_huge_real_lifted_state_has_unit_trace(self):
        rho = candidate.reduced_core_density_from_lifted(np.full(512, 1e308), 512)
        self.assert_density(rho)
        np.testing.assert_allclose(rho, np.full((8, 8), 1.0 / 8.0), atol=1e-14)

    def test_huge_complex_lifted_state_has_unit_trace(self):
        vector = np.full(512, complex(MAX_FLOAT, MAX_FLOAT))
        rho = candidate.reduced_core_density_from_lifted(vector, 512)
        self.assert_density(rho)
        np.testing.assert_allclose(rho, np.full((8, 8), 1.0 / 8.0), atol=1e-14)

    def test_subnormal_lifted_state_remains_accepted(self):
        vector = np.zeros(512, dtype=np.complex128)
        vector[0] = MIN_SUBNORMAL
        rho = candidate.reduced_core_density_from_lifted(vector, 512)
        self.assert_density(rho)
        expected = np.zeros((8, 8), dtype=np.complex128)
        expected[0, 0] = 1.0
        np.testing.assert_array_equal(rho, expected)

    def test_lifted_scale_and_global_phase_leave_density_unchanged(self):
        vector = candidate.lift_core_state(candidate.reference_core_state(), 512)
        expected = candidate.reduced_core_density_from_lifted(vector, 512)
        for scale in (1.0, 1e200, 1e308):
            with self.subTest(scale=scale):
                rho = candidate.reduced_core_density_from_lifted(vector * (-0.6 + 0.8j) * scale, 512)
                self.assert_density(rho)
                np.testing.assert_allclose(rho, expected, atol=1e-14, rtol=1e-14)

    def test_invalid_lifted_states_are_rejected(self):
        invalid = (np.zeros(512), np.ones(8), np.ones((512, 1)), np.full(512, math.inf),
                   np.full(512, math.nan))
        for index, vector in enumerate(invalid):
            with self.subTest(index=index), self.assertRaises(ValueError):
                candidate.reduced_core_density_from_lifted(vector, 512)

    def test_round_trip_all_complete_carrier_sizes(self):
        state = candidate.reference_core_state()
        expected = np.outer(state, state.conj())
        for size in (8, 16, 32, 64, 128, 256, 512):
            with self.subTest(size=size):
                vector = candidate.lift_core_state(state, size)
                rho = candidate.reduced_core_density_from_lifted(vector, size)
                self.assert_density(rho)
                np.testing.assert_allclose(rho, expected, rtol=1e-13, atol=1e-14)


class InheritedBehaviorTests(unittest.TestCase):
    def test_complete_inherited_benchmark_remains_numerically_equivalent(self):
        before = original.three_qubit_poly_scale_benchmark()
        after = candidate.three_qubit_poly_scale_benchmark()

        def compare(a, b, path="benchmark"):
            if isinstance(a, dict):
                self.assertEqual(set(a), set(b), path)
                for key in a:
                    if key == "primary_identity":
                        continue  # Numeric roundoff can legitimately change content fingerprints.
                    compare(a[key], b[key], path + "." + str(key))
            elif isinstance(a, (list, tuple)):
                self.assertEqual(len(a), len(b), path)
                for index, (x, y) in enumerate(zip(a, b)):
                    compare(x, y, path + "." + str(index))
            elif isinstance(a, float):
                self.assertTrue(math.isfinite(a) and math.isfinite(b), path)
                self.assertLessEqual(abs(a-b), 1e-12, path)
            else:
                self.assertEqual(a, b, path)

        compare(before, after)

    def test_lossy_projection_fidelities_remain_explicit(self):
        state = candidate.reference_core_state()
        for size, expected in ((2, 0.4729357062735575), (4, 0.9949524916632523)):
            with self.subTest(size=size):
                result = candidate.project_core_state(state, size)
                self.assertFalse(result["full_core_operator"])
                self.assertAlmostEqual(result["reconstruction_fidelity"], expected, places=13)


if __name__ == "__main__":
    unittest.main(verbosity=2)
