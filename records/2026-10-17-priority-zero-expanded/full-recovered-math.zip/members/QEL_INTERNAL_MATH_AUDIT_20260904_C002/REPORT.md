# QEL internal mathematical audit — Cycle C002

**Project and originator:** Quantum.Earth.Laing, Sherman G. Laing  
**Agent:** GAUCIA / Codex with parallel mathematical and implementation reviews  
**Continuation authorized:** September 4, 2026, 8:41 p.m. Eastern  
**Cycle:** QEL-MATH-20260904-C002  
**State:** TESTED RESEARCH CANDIDATES / WINDOWS CIRCUIT REVIEW PASS / RELEASE HOLD / UNSIGNED

This report continues the 5,209-word C001 audit, preserved at `original/C001_REPORT.md`. It records new work and supersedes the earlier general diagnosis where newly retrieved governing sources supply more precise definitions. The evidence-first principle remains “Prove all things; hold fast that which is good.” (1 Thessalonians 5:21, KJV.) Mathematical checks are not presented as divine endorsement.

## Completed work

The C001 circuit repair has now passed all 16 focused tests on Sherman's physical Windows laptop. Its 13 frozen circuits retain exact mathematical result bytes and all 383 existing engine checks. That closes the missing device-version test for this isolated candidate. The accepted production profile was not replaced, and no signed release was issued.

The internal numerical work also advanced. The LQCP reference successor handles finite nonzero vectors at extreme scale and computes projective state distance without subtracting nearly equal numbers. It passes 108 inherited tests, all 12 C001 boundary tests, and 22 C002 precision tests: 142 methods in total. A separate three-qubit candidate corrects the same normalization failure in both core-state validation and reduction from lifted states. It passes 22 focused regressions and preserves 504 numerical values in the inherited benchmark within 1e-12. Finally, a standalone entropy fixed-point reference corrects the uniqueness condition and small-parameter evaluation; its 13 focused test methods pass.

These are separate test suites with separate claims. The 383 engine checks and 504 benchmark values are not added to the number of test methods as independent tests. The Python candidates were tested in the internal Python environment. Only the circuit API candidate received the described physical-laptop execution. The test scripts do not make network calls; this does not certify operating-system-wide network isolation.

## Stable explicit normalization

For a nonzero complex vector psi, normalization should return psi divided by its Euclidean norm. A direct sum of squared components can overflow or underflow before the division. For example, the C001 reference rejects `[1e300, 1e300]` because the computed norm becomes infinite, and rejects `[1e-300, 1e-300]` because the computed squared magnitudes underflow to zero. Both inputs have an ordinary normalized result: `[1/sqrt(2), 1/sqrt(2)]`.

The corrected reference first validates the vector shape and finite components and rejects the all-zero vector. It chooses the largest absolute real or imaginary component as a positive scale. Each real and imaginary component is divided by that scale separately. This produces a bounded vector whose norm can be evaluated reliably; the bounded vector is then divided by its own norm. There is no need to reconstruct the potentially overflowing original norm.

Separate real and imaginary division matters at subnormal scale. Some complex-array division paths form an intermediate reciprocal that can overflow even though the desired component ratios are finite. The candidate avoids that intermediate operation. Its tests include 1e300, 1e-300, the largest finite binary64 components, the smallest positive subnormal value, complex signs and phases, mixed scales, invalid dimensions, zero states, nonfinite inputs, and preservation of caller data.

This is an explicit normalization operation in a reference that already provided normalization. It does not add automatic normalization to the WF020 density-matrix engine, where automatic renormalization remains prohibited. Validation and deliberate normalization retain their separate roles. Nor does the correction preserve information that is below the representable precision of the normalized ratios: an extremely small component beside an extremely large component can still round to zero.

The three-qubit module exposed a more serious variant. Its original text checked only whether the direct norm was less than or equal to a tolerance. Infinity does not satisfy that condition, so the function divided by infinity and returned an all-zero vector as though validation had succeeded. The lifted-state reduction similarly produced a density matrix with trace zero. The reconstructed examples now return unit-norm states or unit-trace densities within numerical tolerance.

The three-qubit correction preserves its existing cutoff instead of treating every module identically. `validate_core_state` retains its default 1e-10 norm threshold. Lifted-state reduction retains a zero threshold, accepting any finite nonzero state it can normalize. The cutoff comparison is made in scaled arithmetic, and invalid tolerances—including NaN, infinity, negative values and booleans—are rejected. In particular, a NaN tolerance can no longer allow a zero vector to reach division by zero.

The preserved core benchmark contains 504 numerical leaves. Their maximum observed absolute change is approximately 2.53681827024348e-14, below the 1e-12 comparison tolerance. Because last-bit changes alter exact bytes, the old and new benchmark SGL identities differ; both are retained rather than assigning the old identity to the new output. Roles, dimensions and coupling choices were not changed by this normalization patch.

## Projective distance without near-one subtraction

The earlier phase-invariant distance evaluated `sqrt(max(0, 1-fidelity))`. This is a valid mathematical expression, but it is numerically weak when fidelity is extremely close to one. Small differences can disappear when fidelity rounds to one. Conversely, small rounding errors in the normalization can make the distance from a state to itself appear nonzero.

The executed example uses the state `[1+2j, 3-4j]`. The C001 function reported a self-distance of approximately 2.1073424255447017e-08. The C002 candidate returns zero for that example. For `[1,0]` and `[1,1e-12]`, the earlier function returned zero while the candidate returns 1e-12. For the structured basis perturbation of 1e-300, the candidate retains 1e-300 while the old expression again returns zero.

The correction computes the component of one normalized state perpendicular to the other. With normalized states a and b, form `r=b-a*(<a,b>/<a,a>)`, then take the robust norm of r divided by the robust norm of b. In exact arithmetic this equals the original sine distance between state rays. It avoids subtracting a number nearly equal to one from one. The residual norm uses stable hypot reductions so that representable small residuals do not disappear merely because their squares underflow.

The tests compare this result with an independently computed pure-state density-matrix trace distance, check symmetry, orthogonal states, global phases, self-distance, and explicit tiny basis perturbations. Random-state cases use absolute accuracy appropriate to ordinary floating-point operations. Tiny basis perturbations use zero absolute tolerance so that a returned zero cannot pass simply because a default comparison tolerance is much larger than the signal.

The result does not establish universal sensitivity to arbitrary changes as small as 1e-300. General nearly collinear vectors can still have an absolute representation and projection error near machine precision. The tiny examples are structured basis perturbations, where the relevant component remains directly representable. The report therefore distinguishes those exact examples from a claim of arbitrary tiny-angle recovery.

Expanding the accepted scale range of vector validation exposed a downstream concern: the historical raw squared-distance function could overflow after receiving a finite valid vector. The correction retains its historical formula but explicitly rejects a nonfinite result. This prevents a robustness improvement in one function from opening an unchecked infinity output in another. It does not relabel historical raw vector difference as quantum coherence or as a phase-invariant metric.

## Entropy definitions recovered and corrected precisely

The first cycle identified ambiguities in the supplied shorthand `E > 0.25`. Further retrieval shows that QEL already has a mathematical entropy contract. It defines von Neumann entropy in bits, separates measurement, subsystem and thermodynamic quantities, and specifies a qubit entropy target in [0,1]. Those definitions should be retained. The unresolved question for the shorthand is whether and how it is bound to that specific module; absence of a binding is different from absence of a definition.

The retrieved contract models a qubit depolarizing disturbance followed by target replacement:

\[
\mathcal D_p(\rho)=(1-p)\rho+pI/2,
\qquad
\mathcal C_\eta(\rho)=(1-\eta)\rho+\eta\tau.
\]

For p and eta in [0,1], the composed map has a unique fixed point exactly when they are not both zero. If p=eta=0, the map is the identity and every density matrix is fixed. The contract's unqualified phrase “the unique fixed point” therefore needs this explicit exception.

The original function calculates the denominator as `1-(1-eta)*(1-p)` and rejects values at or below 1e-10 with the message that the channel lacks a unique fixed point. That conflates a numerical threshold with mathematical uniqueness. For p=1e-20 and eta=0, the exact fixed point is I/2, even though the original computation rejects it. For p=0 and eta=1e-20, the exact fixed point is tau. The parameters imply slow contraction; they do not imply nonuniqueness.

The standalone corrected reference uses convex weights proportional to `p*(1-eta)` and `eta`. It first scales p and eta by their maximum positive value, then computes and normalizes those bounded weights. This avoids both subtraction of nearly equal numbers in the denominator and premature underflow of the unscaled numerator. Only the exact p=eta=0 case is rejected as nonunique.

As a concrete extreme example, let both probabilities equal the smallest positive binary64 subnormal, and let the target be the pure zero state. The reference returns diagonal entries 0.75 and 0.25. The tests compare difficult weights against a high-precision Decimal evaluation of the original fixed-point equation, check moderate channel invariance, validate generated density matrices, and reject invalid domains.

The reference is deliberately named as a standalone mathematical successor. It is not a claim to have replaced the complete historical entropy-control module. Its density validation tolerance is explicitly declared. A unique fixed point is also not a promise of fast or numerically observable convergence: with sufficiently small parameters, an individual floating-point channel step can round to the identity even though the exact mathematical map is strictly contracting.

## Existing coupling policy retained

The retrieved `quantum_core_bridge.py` starts with identity coupling and explicitly marks the historical coupling, observer, coherence and entropy laws inactive pending audit and binding. The MC003F v2 reconciliation report retains that default. Its nonidentity Hamiltonian candidate is available only through explicit bounded internal-simulation selection with identity fallback.

Consequently, the weighted-averaging example from C001 remains an analysis of the supplied additive score equation, not a replacement for this established bridge. Replacing identity coupling with averaging would change the model and policy. This cycle did not do so. The retrieved three-qubit scale source also already states that auxiliary scale modes are not additional semantic qubits and labels smaller projections as lossy. These earlier corrections were preserved rather than counted again as new discoveries.

## Physical laptop validation and retained procedural failures

The review used the existing authorized connection to DESKTOP-EI6MFFI and created a new review folder under the QEL desktop project. It verified the existing Node executable at `./REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe`, version 24.20.0, against its recorded pin. The candidate, original source, frozen configuration and focused tests were staged as new review files with exact-byte identity checks. Existing production source and configuration were checked again after the work and remained unchanged.

The test ran in one Node process with a 64 MiB V8 old-space limit, no test-worker isolation, and the normal Restricted PowerShell policy. That old-space setting is not a total-process memory cap. Before execution, a fresh five-sample gate retained the existing thresholds: at least 384 MiB available physical memory, commit below 85%, and at least 8 GiB free on C:. The observed minimum available memory was 447,893,504 bytes; maximum commit was 84.0056%; C: free space was 15,698,255,872 bytes.

All 16 tests passed with exit zero, 3,178 bytes of retained TAP output, and a zero-byte error stream. The TAP-reported test duration was 166.2747 milliseconds. That is a test-run duration, not an application performance benchmark. Peak working-set measurement was unavailable and remains null, not zero. The 13 frozen circuits retained exact result bytes and their 383 engine checks.

Two operator-level failures are retained. The first gate wrapper tried to aggregate hashtable fields with a PowerShell mechanism that did not expose those fields as properties; it failed before Node execution. Explicit scalar extraction corrected that wrapper, and the resource thresholds were not relaxed. A later inline closure command encountered native argument-quoting failure after the tests had passed. A staged closure script corrected that recording path. Neither error was hidden or counted as a successful first attempt, and the already passing tests were not repeatedly rerun to manufacture a cleaner history.

The laptop folder is:

`./REDACTED_LOCAL_ROOT/Desktop\Quantum_Earth_Laing_QEL\MATH_API_SIDE_BY_SIDE_REVIEW_20260905T004419Z_C001`

The returned evidence is preserved in `laptop_review/`. Fourteen closure members were independently rechecked against both their SGL Prime and secondary SHA-256 witnesses. This is exact returned-byte verification. New-file creation is not a write-once vault guarantee, and the fingerprints do not supply an owner signature or trusted timestamp.

## Source custody, limitations and next state

The LQCP parent is the exact locally preserved C001 candidate whose manifest passed verification at the start of this cycle. The circuit review uses exact source and configuration bytes matching the laptop's existing pins. These are stronger custody states than the three-qubit source retrieval: its raw-byte download failed, while authenticated source-text reading succeeded. The recovered text contains 16,248 UTF-8 bytes against metadata reporting 16,249 bytes. The difference is explicitly recorded; no missing byte was guessed and labeled verified.

The three-qubit original is therefore named `fixed_three_qubit_scale_source_text_reconstruction.py`. Its correction and test results apply to that recovered source text, with `TEXT_RECONSTRUCTION_NOT_BYTE_VERIFIED` retained as a source gate. No canonical Library item was overwritten. The entropy reference is newly implemented from the retrieved mathematical contract and literal function excerpt; it does not claim to be the complete original file. Provenance receipts preserve these distinctions.

Each mathematical module contains its replay runner or focused test file and recorded outcomes. C001's report and source parent remain in `original/`. The SGL Prime manifest identifies exact package members, with SHA-256 as a secondary witness. Verification establishes matching bytes under the retrieved fingerprint implementation and known-answer test, not correctness by itself. The signed-release state remains HOLD / UNSIGNED.

The concrete next state is now better than at C001: the circuit candidate has physical-laptop evidence; the reference's extreme-scale normalization and distance failures are corrected; both three-qubit normalization paths have tested text-derived candidates; and the entropy fixed-point condition has a tested bounded successor. Integration into accepted profiles, exact original-byte recovery for the three-qubit source, and signed promotion remain explicit gates. Existing coupling policy and the declared distinction between simulated mathematics and physical hardware claims remain intact.
