import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import * as original from './wf020_core_original.mjs';
import * as candidate from './wf020_core_candidate.mjs';

const config = JSON.parse(readFileSync(new URL('./WF020_CIRCUIT_CONFIG_20260904_C001.json', import.meta.url), 'utf8'));
const freshCircuit = () => ({ id: 'C99_FOREIGN', initial_state: 'ZERO', instructions: [{ op: 'MEASURE_Z' }] });

test('original reproduces unknown-operation false PASS; candidate rejects it', () => {
  const circuit = freshCircuit();
  circuit.instructions.unshift({ op: 'UNKNOWN' });
  const prior = original.executeCircuit(circuit, config);
  assert.equal(prior.aggregate.verdict, 'PASS');
  assert.equal(prior.instruction_trace[0].checks.length, 0);
  assert.throws(() => candidate.executeCircuit(circuit, config), { code: 'WF020-OPCODE' });
});

const invalidArguments = [
  ['unknown initial state', c => { c.initial_state = 'MAGIC'; }, 'WF020-INITIAL-STATE'],
  ['unrecognized circuit field', c => { c.extra = true; }, 'WF020-SCHEMA-KEYS'],
  ['unrecognized instruction field', c => { c.instructions.unshift({ op: 'H', extra: true }); }, 'WF020-SCHEMA-KEYS'],
  ['zero idle duration', c => { c.instructions.unshift({ op: 'IDLE', cycles: 0 }); }, 'WF020-INTEGER'],
  ['fractional idle duration', c => { c.instructions.unshift({ op: 'IDLE', cycles: 1.5 }); }, 'WF020-INTEGER'],
  ['missing measurement', c => { c.instructions = [{ op: 'H' }]; }, 'WF020-MEASUREMENT'],
  ['nonterminal measurement', c => { c.instructions.push({ op: 'X' }); }, 'WF020-MEASUREMENT-ORDER'],
  ['duplicate measurement', c => { c.instructions.push({ op: 'MEASURE_Z' }); }, 'WF020-MEASUREMENT-ORDER'],
  ['instruction budget overflow', c => { c.instructions = [...Array.from({ length: 64 }, () => ({ op: 'I' })), { op: 'MEASURE_Z' }]; }, 'WF020-INSTRUCTIONS'],
  ['cycle budget overflow', c => { c.instructions = [...Array.from({ length: 4 }, () => ({ op: 'IDLE', cycles: 64 })), { op: 'I' }, { op: 'MEASURE_Z' }]; }, 'WF020-CYCLE-BUDGET'],
  ['duplicate snapshot labels', c => { c.instructions.unshift({ op: 'SNAPSHOT', label: 'SAME' }, { op: 'SNAPSHOT', label: 'SAME' }); }, 'WF020-SNAPSHOT'],
];
for (const [name, mutate, code] of invalidArguments) {
  test(`separate circuit argument rejects ${name}`, () => {
    const circuit = freshCircuit();
    mutate(circuit);
    assert.throws(() => candidate.executeCircuit(circuit, config), { code });
  });
}

test('well-formed separate circuit is accepted without requiring profile membership', () => {
  const circuit = freshCircuit();
  circuit.instructions.unshift({ op: 'H' });
  assert.equal(config.circuits.some(item => item.id === circuit.id), false);
  assert.deepEqual(candidate.executeCircuit(circuit, config), original.executeCircuit(circuit, config));
});

test('caller configuration is still validated independently', () => {
  const invalidConfig = structuredClone(config);
  invalidConfig.circuits[0].instructions = [{ op: 'UNKNOWN' }, { op: 'MEASURE_Z' }];
  assert.throws(() => candidate.executeCircuit(freshCircuit(), invalidConfig), { code: 'WF020-OPCODE' });
});

test('all 13 frozen circuits preserve exact mathematical output bytes and 383 checks', () => {
  assert.equal(config.circuits.length, 13);
  const expected = original.buildResultBody(config);
  const actual = candidate.buildResultBody(config);
  assert.equal(actual.aggregate.verdict, 'PASS');
  assert.equal(actual.aggregate.check_count, 383);
  assert.equal(actual.aggregate.passed_count, 383);
  assert.ok(original.canonicalJson(expected).equals(candidate.canonicalJson(actual)));
});

test('API validation leaves supplied circuit and configuration unchanged', () => {
  const circuit = freshCircuit();
  const before = JSON.stringify({ config, circuit });
  candidate.executeCircuit(circuit, config);
  assert.equal(JSON.stringify({ config, circuit }), before);
});
