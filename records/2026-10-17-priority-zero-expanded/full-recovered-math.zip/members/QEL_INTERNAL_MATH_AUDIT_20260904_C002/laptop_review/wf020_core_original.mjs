/* QEL WF020: dependency-free classical single-qubit circuit interface. */

import { createHash } from 'node:crypto';
import {
  closeSync, existsSync, fsyncSync, linkSync, lstatSync, mkdirSync,
  openSync, readFileSync, realpathSync, unlinkSync, writeSync,
} from 'node:fs';
import { dirname, isAbsolute, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
export const CONFIG_SCHEMA = 'qel.wf020.circuit-batch-config/v1';
export const WORKFLOW_ID = 'QEL-WF020-CLASSICAL-QPU-CIRCUIT-INTERFACE';
export const EXECUTION_CLASS = 'CLASSICAL_SINGLE_QUBIT_DENSITY_MATRIX_CIRCUIT_EMULATION';
export const PURPOSE = 'PEACEFUL_CIRCUIT_RESEARCH_FOR_SCIENCE_EDUCATION_HEALING_AND_RESOURCE_STEWARDSHIP';
export const TARGET_BACKEND = 'NONE';
export const RESULT_PURPOSE = 'qel.wf020.circuit-batch-result-body.v1';
export const TOLERANCE = 1e-12;
export const SGL_DOMAIN = 'SGL-PRIME/v2/FINGERPRINT';
export const SGL_PROFILE = 'QEL-SGLP2-FRAME5-SHAKE256-512-v2';
export const SGL_ALGORITHM = 'SHAKE256-512';
export const SGL_PREFIX = 'sglp2:shake256-512:';
export const SGL_KAT_SUBJECT = Buffer.from('QEL-WF018-SGL-KAT-v1', 'utf8');
export const SGL_KAT_PURPOSE = 'qel.quantum-state-coherence/known-answer/v1';
export const SGL_KAT_EXPECTED = 'sglp2:shake256-512:18fca57bd5ef2bfa8ee851731094d2101d9c98efc1749384af70ec498737afd1f3c8b47cd3dad0a439010ed0fddff9363ecd39f7f26e2ffe0bbe480635d8760a';
export const IDENTITY_BOUNDARY = 'UNKEYED_EXACT_BYTE_IDENTITY_NOT_VALIDATION_SIGNATURE_AUTHORSHIP_AUTHORIZATION_TRUTH_OR_TRUSTED_TIME';
export const GATE_OPS = Object.freeze(['I', 'X', 'Y', 'Z', 'H', 'S', 'SDG', 'T', 'TDG']);
export const ALL_OPS = Object.freeze([...GATE_OPS, 'IDLE', 'SNAPSHOT', 'BARRIER', 'MEASURE_Z']);

const EXPECTED_PARENT = Object.freeze({
  cycle_id: 'WF019-20260904-C001',
  relative_path: '..\\WF019_QPU_Calibration_20260904_C001',
  manifest_body_sgl_prime: 'sglp2:shake256-512:49eba642bac030c22f0292e1a75ea061cb5d81ae9a50af2310b2510e2d664bf887f3f8d3d29bcbf60b127adfb4c1190ee54986d75acce90cbfd03930cef1523e',
  capsule_sha256_secondary: '1e046e028f55c72f6cefe416a4efc8f93f070808510fe14d96c5f6de7940b1c6',
  qprint_sha256_secondary: '5524c832fc54e2aef156556922cae301e04041dae1c9a79f5beb6557fe407869',
  state: 'HOLD_UNSIGNED',
});

export class WF020Error extends Error {
  constructor(code, message) {
    super(`${code}: ${message}`);
    this.name = 'WF020Error';
    this.code = code;
    this.detail = message;
  }
}

function normalizedText(value, label) {
  if (typeof value !== 'string') throw new WF020Error('WF020-TEXT', `${label} must be text`);
  for (let i = 0; i < value.length; i += 1) {
    const unit = value.charCodeAt(i);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) throw new WF020Error('WF020-SURROGATE', `${label} has a lone high surrogate`);
      i += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) throw new WF020Error('WF020-SURROGATE', `${label} has a lone low surrogate`);
  }
  return value.normalize('NFC');
}

function length64(value) {
  const output = Buffer.alloc(8);
  output.writeBigUInt64BE(BigInt(value));
  return output;
}

function frame(value) {
  const raw = Buffer.from(normalizedText(value, 'SGL frame'), 'utf8');
  return Buffer.concat([length64(raw.length), raw]);
}

export function sglp2(raw, purpose) {
  if (!Buffer.isBuffer(raw)) throw new WF020Error('WF020-SGL-BYTES', 'subject must be a Buffer');
  purpose = normalizedText(purpose, 'SGL purpose');
  if (!purpose) throw new WF020Error('WF020-SGL-PURPOSE', 'purpose must be nonempty');
  const digest = createHash('shake256', { outputLength: 64 });
  for (const value of [SGL_DOMAIN, SGL_PROFILE, SGL_ALGORITHM, purpose]) digest.update(frame(value));
  digest.update(length64(raw.length));
  digest.update(raw);
  return SGL_PREFIX + digest.digest('hex');
}

export const sha256 = (raw) => {
  if (!Buffer.isBuffer(raw)) throw new WF020Error('WF020-SHA-BYTES', 'subject must be a Buffer');
  return createHash('sha256').update(raw).digest('hex');
};

function canonicalValue(value) {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return JSON.stringify(normalizedText(value, 'JSON string'));
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value) || Object.is(value, -0)) throw new WF020Error('WF020-JSON-NUMBER', 'canonical numbers must be safe non-negative-zero integers');
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalValue).join(',')}]`;
  if (typeof value === 'object') {
    const normalized = new Map();
    for (const [rawKey, item] of Object.entries(value)) {
      const key = normalizedText(rawKey, 'JSON key');
      if (normalized.has(key)) throw new WF020Error('WF020-JSON-DUPLICATE', `duplicate normalized key ${key}`);
      normalized.set(key, item);
    }
    const keys = [...normalized.keys()].sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalValue(normalized.get(key))}`).join(',')}}`;
  }
  throw new WF020Error('WF020-JSON-TYPE', `unsupported JSON type ${typeof value}`);
}

export const canonicalJson = (value) => Buffer.from(canonicalValue(value), 'utf8');

function sortedObject(value) {
  if (value === null || typeof value !== 'object') {
    canonicalValue(value);
    return typeof value === 'string' ? normalizedText(value, 'JSON string') : value;
  }
  if (Array.isArray(value)) return value.map(sortedObject);
  const output = {};
  const entries = Object.entries(value).map(([key, item]) => [normalizedText(key, 'JSON key'), item]);
  entries.sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  for (const [key, item] of entries) output[key] = sortedObject(item);
  return output;
}

export const renderedJson = (value) => Buffer.from(`${JSON.stringify(sortedObject(value), null, 2)}\n`, 'utf8');

export function strictJsonParse(raw, label = 'JSON input', limits = {}) {
  if (!Buffer.isBuffer(raw)) throw new WF020Error('WF020-JSON-BYTES', `${label} must be bytes`);
  const maxDepth = limits.maxDepth ?? 16;
  const maxNodes = limits.maxNodes ?? 8192;
  const source = new TextDecoder('utf-8', { fatal: true, ignoreBOM: true }).decode(raw);
  if (source.charCodeAt(0) === 0xfeff) throw new WF020Error('WF020-JSON-BOM', `${label} must not contain a BOM`);
  let position = 0;
  let nodes = 0;
  const bump = (depth) => {
    nodes += 1;
    if (nodes > maxNodes) throw new WF020Error('WF020-JSON-NODES', `${label} exceeds ${maxNodes} parsed nodes`);
    if (depth > maxDepth) throw new WF020Error('WF020-JSON-DEPTH', `${label} exceeds depth ${maxDepth}`);
  };
  const whitespace = () => { while (/[ \t\r\n]/u.test(source[position] ?? '')) position += 1; };
  const fail = (detail) => { throw new WF020Error('WF020-JSON-MALFORMED', `${label} at ${position}: ${detail}`); };
  const parseString = () => {
    if (source[position] !== '"') fail('expected string');
    const start = position;
    position += 1;
    while (position < source.length) {
      const unit = source[position];
      if (unit === '"') {
        position += 1;
        let value;
        try { value = JSON.parse(source.slice(start, position)); } catch { fail('invalid string escape'); }
        return normalizedText(value, 'JSON string');
      }
      if (unit === '\\') { position += 2; continue; }
      if (unit.charCodeAt(0) < 0x20) fail('unescaped control character');
      position += 1;
    }
    fail('unterminated string');
  };
  const parseValue = (depth = 0) => {
    bump(depth);
    whitespace();
    const unit = source[position];
    if (unit === '"') return parseString();
    if (unit === '{') {
      position += 1; whitespace();
      const output = Object.create(null); const keys = new Set();
      if (source[position] === '}') { position += 1; return output; }
      while (true) {
        whitespace(); const key = parseString();
        if (['__proto__', 'prototype', 'constructor'].includes(key)) fail(`prohibited key ${key}`);
        if (keys.has(key)) fail(`duplicate normalized key ${key}`);
        keys.add(key); whitespace();
        if (source[position] !== ':') fail('expected colon');
        position += 1; output[key] = parseValue(depth + 1); whitespace();
        if (source[position] === '}') { position += 1; return output; }
        if (source[position] !== ',') fail('expected comma');
        position += 1;
      }
    }
    if (unit === '[') {
      position += 1; whitespace();
      const output = [];
      if (source[position] === ']') { position += 1; return output; }
      while (true) {
        output.push(parseValue(depth + 1)); whitespace();
        if (source[position] === ']') { position += 1; return output; }
        if (source[position] !== ',') fail('expected comma');
        position += 1;
      }
    }
    for (const [token, value] of [['true', true], ['false', false], ['null', null]]) {
      if (source.startsWith(token, position)) { position += token.length; return value; }
    }
    const match = /^-?(?:0|[1-9][0-9]*)/.exec(source.slice(position));
    if (!match) fail('expected integer, literal, array, or object');
    position += match[0].length;
    if (/[.eE]/u.test(source[position] ?? '')) fail('floating-point controls are prohibited; use decimal strings');
    if (match[0] === '-0') fail('negative zero is prohibited');
    const value = Number(match[0]);
    if (!Number.isSafeInteger(value)) fail('integer exceeds exact safe range');
    return value;
  };
  const value = parseValue(); whitespace();
  if (position !== source.length) fail('trailing content');
  return value;
}

function exactKeys(value, allowed, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new WF020Error('WF020-SCHEMA', `${label} must be an object`);
  const actual = Object.keys(value).sort();
  const expected = [...allowed].sort();
  if (actual.length !== expected.length || actual.some((key, index) => key !== expected[index])) throw new WF020Error('WF020-SCHEMA-KEYS', `${label} keys must be exactly ${expected.join(',')}`);
}

function requireInteger(value, label, minimum, maximum) {
  if (!Number.isSafeInteger(value) || Object.is(value, -0) || value < minimum || value > maximum) throw new WF020Error('WF020-INTEGER', `${label} must be an integer in [${minimum}, ${maximum}]`);
  return value;
}

function sameObject(value, expected) {
  return canonicalJson(value).equals(canonicalJson(expected));
}

export function validateConfig(config, rawBytes = null) {
  exactKeys(config, ['schema','cycle_id','workflow_id','declared_at_utc','execution_class','target_backend','purpose','parent_checkpoint','external_example_input','channel','semantics','resource_policy','numeric_policy','circuits','claim_boundary'], 'config');
  if (config.schema !== CONFIG_SCHEMA || config.workflow_id !== WORKFLOW_ID || config.execution_class !== EXECUTION_CLASS || config.target_backend !== TARGET_BACKEND || config.purpose !== PURPOSE) throw new WF020Error('WF020-CONFIG-IDENTITY', 'schema, workflow, execution class, backend, or peaceful purpose mismatch');
  if (!/^WF020-[0-9]{8}-C[0-9]{3}$/u.test(config.cycle_id)) throw new WF020Error('WF020-CYCLE-ID', 'cycle_id is noncanonical');
  if (!/^2026-09-04T[0-9]{2}:[0-9]{2}:[0-9]{2}Z$/u.test(config.declared_at_utc)) throw new WF020Error('WF020-DECLARED-TIME', 'declared time must be a fixed UTC label');
  exactKeys(config.parent_checkpoint, Object.keys(EXPECTED_PARENT), 'parent_checkpoint');
  if (!sameObject(config.parent_checkpoint, EXPECTED_PARENT)) throw new WF020Error('WF020-PARENT', 'sealed WF019 parent witness mismatch');
  exactKeys(config.external_example_input, ['source_cycle','classification','t1_ns','t2_ns','cycle_ns'], 'external_example_input');
  exactKeys(config.channel, ['t1_ns','t2_ns','cycle_ns'], 'channel');
  exactKeys(config.semantics, ['instruction_order','noise_placement','measurement','global_phase','automatic_renormalization'], 'semantics');
  exactKeys(config.resource_policy, ['max_config_bytes','max_circuits','max_instructions_per_circuit','max_idle_cycles_per_instruction','max_total_cycles_per_circuit','max_output_bytes','max_matrix_dimension','node_old_space_mib'], 'resource_policy');
  exactKeys(config.numeric_policy, ['absolute_tolerance_decimal'], 'numeric_policy');
  exactKeys(config.claim_boundary, ['physical_qpu','physical_coherence','quantum_advantage','random_shots','laptop_security','owner_signature','public_release','release'], 'claim_boundary');
  const policy = config.resource_policy;
  requireInteger(policy.max_config_bytes, 'max_config_bytes', 1024, 65536);
  requireInteger(policy.max_circuits, 'max_circuits', 1, 16);
  requireInteger(policy.max_instructions_per_circuit, 'max_instructions_per_circuit', 1, 64);
  requireInteger(policy.max_idle_cycles_per_instruction, 'max_idle_cycles_per_instruction', 1, 64);
  requireInteger(policy.max_total_cycles_per_circuit, 'max_total_cycles_per_circuit', 1, 256);
  requireInteger(policy.max_output_bytes, 'max_output_bytes', 4096, 2097152);
  if (policy.max_matrix_dimension !== 2 || policy.node_old_space_mib !== 64) throw new WF020Error('WF020-RESOURCE-POLICY', 'matrix and Node heap limits must remain frozen at 2 and 64 MiB');
  if (rawBytes !== null && rawBytes > policy.max_config_bytes) throw new WF020Error('WF020-CONFIG-SIZE', 'configuration exceeds declared byte ceiling');
  const channel = config.channel;
  for (const key of ['t1_ns','t2_ns','cycle_ns']) requireInteger(channel[key], key, 1, 1000000000);
  if (channel.t2_ns > 2 * channel.t1_ns) throw new WF020Error('WF020-NONPHYSICAL-TIMES', 'T2 exceeds the declared Markovian bound 2*T1');
  if (config.external_example_input.source_cycle !== EXPECTED_PARENT.cycle_id || config.external_example_input.classification !== 'DECLARED_EXAMPLE_NOT_PHYSICAL_MEASUREMENT' || ['t1_ns','t2_ns','cycle_ns'].some((key) => config.external_example_input[key] !== channel[key])) throw new WF020Error('WF020-INPUT-PROVENANCE', 'channel must match the declared external example');
  if (!sameObject(config.semantics, {instruction_order:'STRICT_LIST_ORDER',noise_placement:'AFTER_EACH_UNITARY_AND_EXPLICIT_IDLE',measurement:'EXPECTATION_ONLY_NO_RANDOM_SHOTS',global_phase:'DENSITY_MATRIX_INVARIANT',automatic_renormalization:'PROHIBITED'})) throw new WF020Error('WF020-SEMANTICS', 'instruction semantics mismatch');
  const tolerance = Number(config.numeric_policy.absolute_tolerance_decimal);
  if (!Number.isFinite(tolerance) || tolerance <= 0 || tolerance > TOLERANCE) throw new WF020Error('WF020-TOLERANCE', 'tolerance is invalid or weakened');
  if (!sameObject(config.claim_boundary, {physical_qpu:'NOT_RUN',physical_coherence:'NOT_MEASURED',quantum_advantage:'NOT_ESTABLISHED',random_shots:'NOT_GENERATED',laptop_security:'APPLICATION_SCOPE_ONLY',owner_signature:'NOT_APPLIED',public_release:'NOT_AUTHORIZED',release:'HOLD'})) throw new WF020Error('WF020-CLAIM-BOUNDARY', 'claim or release boundary is weakened');
  if (!Array.isArray(config.circuits) || config.circuits.length < 1 || config.circuits.length > policy.max_circuits) throw new WF020Error('WF020-CIRCUITS', 'circuit count is out of bounds');
  const circuitIds = new Set();
  for (const circuit of config.circuits) {
    exactKeys(circuit, ['id','initial_state','instructions'], 'circuit');
    if (!/^C[0-9]{2}_[A-Z0-9_]{1,48}$/u.test(circuit.id) || circuitIds.has(circuit.id)) throw new WF020Error('WF020-CIRCUIT-ID', `invalid or duplicate circuit id ${String(circuit.id)}`);
    circuitIds.add(circuit.id);
    if (!['ZERO','ONE','PLUS','PLUS_I'].includes(circuit.initial_state)) throw new WF020Error('WF020-INITIAL-STATE', `unsupported initial state ${String(circuit.initial_state)}`);
    if (!Array.isArray(circuit.instructions) || circuit.instructions.length < 1 || circuit.instructions.length > policy.max_instructions_per_circuit) throw new WF020Error('WF020-INSTRUCTIONS', `${circuit.id} instruction count is out of bounds`);
    let totalCycles = 0; let measures = 0; const labels = new Set();
    for (let index = 0; index < circuit.instructions.length; index += 1) {
      const instruction = circuit.instructions[index];
      if (!instruction || typeof instruction !== 'object' || Array.isArray(instruction) || typeof instruction.op !== 'string' || !ALL_OPS.includes(instruction.op)) throw new WF020Error('WF020-OPCODE', `${circuit.id}[${index}] has unsupported opcode`);
      if (GATE_OPS.includes(instruction.op)) { exactKeys(instruction, ['op'], 'unitary instruction'); totalCycles += 1; }
      else if (instruction.op === 'IDLE') { exactKeys(instruction, ['op','cycles'], 'IDLE instruction'); totalCycles += requireInteger(instruction.cycles, 'IDLE cycles', 1, policy.max_idle_cycles_per_instruction); }
      else if (instruction.op === 'SNAPSHOT') {
        exactKeys(instruction, ['op','label'], 'SNAPSHOT instruction');
        if (!/^[A-Z][A-Z0-9_]{0,31}$/u.test(instruction.label) || labels.has(instruction.label)) throw new WF020Error('WF020-SNAPSHOT', 'snapshot label is invalid or duplicate');
        labels.add(instruction.label);
      } else { exactKeys(instruction, ['op'], `${instruction.op} instruction`); }
      if (instruction.op === 'MEASURE_Z') {
        measures += 1;
        if (index !== circuit.instructions.length - 1) throw new WF020Error('WF020-MEASUREMENT-ORDER', 'MEASURE_Z must be terminal');
      }
      if (totalCycles > policy.max_total_cycles_per_circuit) throw new WF020Error('WF020-CYCLE-BUDGET', `${circuit.id} exceeds total cycle budget`);
    }
    if (measures !== 1) throw new WF020Error('WF020-MEASUREMENT', `${circuit.id} requires exactly one terminal MEASURE_Z`);
  }
  return { tolerance, policy };
}

export function loadConfig(path) {
  const info = lstatSync(path);
  if (!info.isFile() || info.isSymbolicLink() || info.nlink !== 1) throw new WF020Error('WF020-CONFIG-FILE', 'configuration must be a regular single-link non-symlink file');
  if (info.size > 65536) throw new WF020Error('WF020-CONFIG-SIZE', 'configuration exceeds hard 64 KiB ceiling');
  const raw = readFileSync(path);
  const value = strictJsonParse(raw, path, {maxDepth:16,maxNodes:8192});
  validateConfig(value, raw.length);
  return { raw, value };
}

const c = (re = 0, im = 0) => ({ re, im });
const cadd = (a, b) => c(a.re + b.re, a.im + b.im);
const cmul = (a, b) => c(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);
const cscale = (a, scale) => c(a.re * scale, a.im * scale);
const cconj = (a) => c(a.re, -a.im);
const cabs = (a) => Math.hypot(a.re, a.im);
const zero = () => [[c(),c()],[c(),c()]];
const cloneMatrix = (matrix) => matrix.map((row) => row.map((value) => c(value.re, value.im)));

function dagger(matrix) {
  return [[cconj(matrix[0][0]),cconj(matrix[1][0])],[cconj(matrix[0][1]),cconj(matrix[1][1])]];
}

function multiply(left, right) {
  const output = zero();
  for (let row = 0; row < 2; row += 1) for (let col = 0; col < 2; col += 1) for (let k = 0; k < 2; k += 1) output[row][col] = cadd(output[row][col], cmul(left[row][k], right[k][col]));
  return output;
}

function addMatrix(left, right) {
  return left.map((row, r) => row.map((value, col) => cadd(value, right[r][col])));
}

function scaleMatrix(matrix, scale) {
  return matrix.map((row) => row.map((value) => cscale(value, scale)));
}

function applyOperators(rho, operators) {
  let output = zero();
  for (const operator of operators) output = addMatrix(output, multiply(multiply(operator, rho), dagger(operator)));
  return output;
}

function gateMatrix(name) {
  const s = Math.SQRT1_2;
  const phase = Math.SQRT1_2;
  const gates = {
    I: [[c(1),c()],[c(),c(1)]], X: [[c(),c(1)],[c(1),c()]], Y: [[c(),c(0,-1)],[c(0,1),c()]], Z: [[c(1),c()],[c(),c(-1)]],
    H: [[c(s),c(s)],[c(s),c(-s)]], S: [[c(1),c()],[c(),c(0,1)]], SDG: [[c(1),c()],[c(),c(0,-1)]],
    T: [[c(1),c()],[c(),c(phase,phase)]], TDG: [[c(1),c()],[c(),c(phase,-phase)]],
  };
  return cloneMatrix(gates[name]);
}

function initialDensity(name) {
  if (name === 'ZERO') return [[c(1),c()],[c(),c()]];
  if (name === 'ONE') return [[c(),c()],[c(),c(1)]];
  if (name === 'PLUS') return [[c(0.5),c(0.5)],[c(0.5),c(0.5)]];
  if (name === 'PLUS_I') return [[c(0.5),c(0,-0.5)],[c(0,0.5),c(0.5)]];
  throw new WF020Error('WF020-INITIAL-STATE', `unsupported initial state ${name}`);
}

function matrixMaxError(left, right) {
  let maximum = 0;
  for (let row = 0; row < 2; row += 1) for (let col = 0; col < 2; col += 1) maximum = Math.max(maximum, cabs(cadd(left[row][col], cscale(right[row][col], -1))));
  return maximum;
}

function physicality(rho) {
  const trace = cadd(rho[0][0], rho[1][1]);
  const hermitianError = Math.max(Math.abs(rho[0][0].im), Math.abs(rho[1][1].im), cabs(cadd(rho[0][1], cscale(cconj(rho[1][0]), -1))));
  const diagonalDifference = rho[0][0].re - rho[1][1].re;
  const discriminant = Math.sqrt(Math.max(0, diagonalDifference ** 2 + 4 * cabs(rho[0][1]) ** 2));
  return {
    traceError: Math.max(Math.abs(trace.re - 1), Math.abs(trace.im)),
    hermitianError,
    minimumEigenvalue: (trace.re - discriminant) / 2,
    finite: rho.flat().every((value) => Number.isFinite(value.re) && Number.isFinite(value.im)),
  };
}

function unitarityError(gate) {
  return matrixMaxError(multiply(gate, dagger(gate)), [[c(1),c()],[c(),c(1)]]);
}

function channel(rho, timeNs, config) {
  const eta1 = Math.exp(-timeNs / config.channel.t1_ns);
  const ratePhi = 1 / config.channel.t2_ns - 1 / (2 * config.channel.t1_ns);
  const lambdaPhi = Math.exp(-timeNs * ratePhi);
  const amplitude = [
    [[c(1),c()],[c(),c(Math.sqrt(eta1))]],
    [[c(),c(Math.sqrt(Math.max(0, 1 - eta1)))],[c(),c()]],
  ];
  const phaseZero = Math.sqrt((1 + lambdaPhi) / 2);
  const phaseOne = Math.sqrt((1 - lambdaPhi) / 2);
  const phase = [scaleMatrix(gateMatrix('I'), phaseZero), scaleMatrix(gateMatrix('Z'), phaseOne)];
  const amplitudeCompleteness = addMatrix(multiply(dagger(amplitude[0]), amplitude[0]), multiply(dagger(amplitude[1]), amplitude[1]));
  const phaseCompleteness = addMatrix(multiply(dagger(phase[0]), phase[0]), multiply(dagger(phase[1]), phase[1]));
  return {
    rho: applyOperators(applyOperators(rho, amplitude), phase),
    eta1, lambdaPhi, totalCoherence: Math.sqrt(eta1) * lambdaPhi,
    amplitudeCompletenessError: matrixMaxError(amplitudeCompleteness, gateMatrix('I')),
    phaseCompletenessError: matrixMaxError(phaseCompleteness, gateMatrix('I')),
  };
}

export function decimal(value) {
  if (!Number.isFinite(value)) return value === Number.POSITIVE_INFINITY ? 'INF' : value === Number.NEGATIVE_INFINITY ? '-INF' : 'NAN';
  if (Object.is(value, -0) || Math.abs(value) < 1e-300) value = 0;
  return value.toExponential(16);
}

function serializedMatrix(matrix) {
  return matrix.map((row) => row.map((value) => ({re_decimal:decimal(value.re),im_decimal:decimal(value.im)})));
}

function makeCheck(name, passed, value, threshold, detail) {
  return {name,passed:passed===true,value_decimal:decimal(value),threshold_decimal:decimal(threshold),detail};
}

function physicalChecks(prefix, rho, tolerance) {
  const p = physicality(rho);
  return [
    makeCheck(`${prefix}_trace`, p.traceError <= tolerance, p.traceError, tolerance, 'Trace remains one.'),
    makeCheck(`${prefix}_hermiticity`, p.hermitianError <= tolerance, p.hermitianError, tolerance, 'Density matrix remains Hermitian.'),
    makeCheck(`${prefix}_positivity`, p.minimumEigenvalue >= -tolerance, Math.max(0,-p.minimumEigenvalue), tolerance, 'Minimum eigenvalue remains nonnegative within tolerance.'),
    {name:`${prefix}_finite`,passed:p.finite,value_decimal:p.finite?'0':'1',threshold_decimal:'0',detail:'All matrix components are finite.'},
  ];
}

function measurement(rho, tolerance) {
  const p0 = rho[0][0].re; const p1 = rho[1][1].re;
  const x = 2 * rho[0][1].re; const y = -2 * rho[0][1].im; const z = p0 - p1;
  const radius = Math.sqrt(x*x + y*y + z*z);
  const finite = [p0,p1,x,y,z,radius].every(Number.isFinite);
  return {
    basis:'Z',mode:'EXPECTATION_ONLY_NO_RANDOM_SHOTS',provenance:'CLASSICAL_SIMULATION_OUTPUT',
    probability_0_decimal:decimal(p0),probability_1_decimal:decimal(p1),
    expectation_x_decimal:decimal(x),expectation_y_decimal:decimal(y),expectation_z_decimal:decimal(z),bloch_radius_decimal:decimal(radius),
    checks:[
      makeCheck('measurement_probability_sum', Math.abs(p0+p1-1)<=tolerance, Math.abs(p0+p1-1), tolerance, 'Probabilities sum to one.'),
      makeCheck('measurement_p0_bounds', p0>=-tolerance&&p0<=1+tolerance, Math.max(0,-p0,p0-1), tolerance, 'P(0) lies in [0,1] within tolerance.'),
      makeCheck('measurement_p1_bounds', p1>=-tolerance&&p1<=1+tolerance, Math.max(0,-p1,p1-1), tolerance, 'P(1) lies in [0,1] within tolerance.'),
      makeCheck('measurement_bloch_bound', radius<=1+tolerance, Math.max(0,radius-1), tolerance, 'Bloch radius does not exceed one.'),
      {name:'measurement_finite',passed:finite,value_decimal:finite?'0':'1',threshold_decimal:'0',detail:'Probability and expectation outputs are finite.'},
    ],
  };
}

export function executeCircuit(circuit, config) {
  const { tolerance } = validateConfig(config);
  let rho = initialDensity(circuit.initial_state); let elapsedCycles = 0; let finalMeasurement = null;
  const trace = []; const snapshots = []; const circuitChecks = [
    ...physicalChecks('initial',rho,tolerance),
    {name:'terminal_measurement_declared',passed:circuit.instructions.at(-1).op==='MEASURE_Z',value_decimal:circuit.instructions.at(-1).op==='MEASURE_Z'?'0':'1',threshold_decimal:'0',detail:'Exactly one terminal measurement was prevalidated.'},
  ];
  for (let index = 0; index < circuit.instructions.length; index += 1) {
    const instruction = circuit.instructions[index]; const before = cloneMatrix(rho); const elapsedBefore = elapsedCycles;
    let checks = []; let noise = null; let snapshotLabel = null;
    if (GATE_OPS.includes(instruction.op)) {
      const gate = gateMatrix(instruction.op); const unitaryError = unitarityError(gate);
      rho = multiply(multiply(gate,rho),dagger(gate));
      const applied = channel(rho,config.channel.cycle_ns,config); rho = applied.rho; elapsedCycles += 1;
      checks = [makeCheck('gate_unitarity',unitaryError<=tolerance,unitaryError,tolerance,`${instruction.op} is unitary.`),...physicalChecks('post_gate',rho,tolerance),makeCheck('amplitude_kraus_completeness',applied.amplitudeCompletenessError<=tolerance,applied.amplitudeCompletenessError,tolerance,'Amplitude Kraus operators are complete.'),makeCheck('phase_kraus_completeness',applied.phaseCompletenessError<=tolerance,applied.phaseCompletenessError,tolerance,'Phase Kraus operators are complete.')];
      noise = {duration_ns:config.channel.cycle_ns,eta1_decimal:decimal(applied.eta1),lambda_phi_decimal:decimal(applied.lambdaPhi),total_coherence_decimal:decimal(applied.totalCoherence)};
    } else if (instruction.op === 'IDLE') {
      const duration = instruction.cycles * config.channel.cycle_ns; const applied = channel(rho,duration,config); rho = applied.rho; elapsedCycles += instruction.cycles;
      checks = [...physicalChecks('post_idle',rho,tolerance),makeCheck('amplitude_kraus_completeness',applied.amplitudeCompletenessError<=tolerance,applied.amplitudeCompletenessError,tolerance,'Amplitude Kraus operators are complete.'),makeCheck('phase_kraus_completeness',applied.phaseCompletenessError<=tolerance,applied.phaseCompletenessError,tolerance,'Phase Kraus operators are complete.')];
      noise = {duration_ns:duration,eta1_decimal:decimal(applied.eta1),lambda_phi_decimal:decimal(applied.lambdaPhi),total_coherence_decimal:decimal(applied.totalCoherence)};
    } else if (instruction.op === 'SNAPSHOT') {
      snapshotLabel = instruction.label; checks = physicalChecks('snapshot',rho,tolerance);
      snapshots.push({label:instruction.label,instruction_index:index,elapsed_cycles:elapsedCycles,density_matrix:serializedMatrix(rho)});
    } else if (instruction.op === 'BARRIER') {
      const error = matrixMaxError(before,rho); checks = [makeCheck('barrier_identity',error<=tolerance,error,tolerance,'Barrier preserves state and consumes no cycle.')];
    } else if (instruction.op === 'MEASURE_Z') {
      finalMeasurement = measurement(rho,tolerance); checks = finalMeasurement.checks;
    }
    trace.push({instruction_index:index,op:instruction.op,duration_cycles:elapsedCycles-elapsedBefore,elapsed_cycles_before:elapsedBefore,elapsed_cycles_after:elapsedCycles,snapshot_label:snapshotLabel,state_before:serializedMatrix(before),state_after:serializedMatrix(rho),noise,checks});
    circuitChecks.push(...checks);
  }
  const passed = circuitChecks.filter((item)=>item.passed).length;
  return {id:circuit.id,initial_state:circuit.initial_state,instruction_count:circuit.instructions.length,total_cycles:elapsedCycles,initial_density_matrix:serializedMatrix(initialDensity(circuit.initial_state)),instruction_trace:trace,snapshots,measurement:finalMeasurement,aggregate:{verdict:passed===circuitChecks.length?'PASS':'FAIL',passed_count:passed,check_count:circuitChecks.length}};
}

export function buildCompiledIr(config) {
  validateConfig(config);
  return {
    schema:'qel.wf020.compiled-circuit-ir/v1',cycle_id:config.cycle_id,
    execution_class:config.execution_class,target_backend:config.target_backend,
    channel:config.channel,semantics:config.semantics,instruction_set:[...ALL_OPS],circuits:config.circuits,
  };
}

export function buildTransactionPlan(config) {
  const ir=buildCompiledIr(config); const configRaw=canonicalJson(config); const irRaw=canonicalJson(ir);
  const body={schema:'qel.wf020.official-transaction-plan-body/v1',cycle_id:config.cycle_id,workflow_id:config.workflow_id,attempt:'001',retry_count:0,config_identity:exactIdentity(configRaw,'qel.wf020.circuit-config-canonical.v1'),compiled_ir_identity:exactIdentity(irRaw,'qel.wf020.compiled-circuit-ir.v1'),parent_checkpoint:config.parent_checkpoint,execution_class:config.execution_class,target_backend:config.target_backend,state:{release:'HOLD',signature:'UNSIGNED'}};
  const bodyRaw=canonicalJson(body);
  return {schema:'qel.wf020.official-transaction-plan/v1',plan_body:body,plan_body_identity:exactIdentity(bodyRaw,'qel.wf020.official-transaction-plan-body.v1')};
}

export function buildResultBody(config) {
  validateConfig(config);
  if (sglp2(SGL_KAT_SUBJECT,SGL_KAT_PURPOSE)!==SGL_KAT_EXPECTED) throw new WF020Error('WF020-SGL-KAT','SGL Prime known-answer mismatch');
  const compiledIr=buildCompiledIr(config); const transactionPlan=buildTransactionPlan(config);
  const circuits = config.circuits.map((circuit)=>executeCircuit(circuit,config));
  let passed = 0; let checks = 0; let maximumTraceError = 0; let minimumEigenvalue = Number.POSITIVE_INFINITY;
  for (const circuit of circuits) {
    passed += circuit.aggregate.passed_count; checks += circuit.aggregate.check_count;
    for (const step of circuit.instruction_trace) {
      for (const check of step.checks) {
        if (check.name.endsWith('_trace')) maximumTraceError = Math.max(maximumTraceError,Number(check.value_decimal));
      }
      const matrix = step.state_after.map((row)=>row.map((v)=>c(Number(v.re_decimal),Number(v.im_decimal))));
      minimumEigenvalue = Math.min(minimumEigenvalue,physicality(matrix).minimumEigenvalue);
    }
  }
  return {
    schema:'qel.wf020.circuit-batch-result-body/v1',cycle_id:config.cycle_id,workflow_id:config.workflow_id,
    execution_class:config.execution_class,target_backend:config.target_backend,purpose:config.purpose,
    parent_checkpoint:config.parent_checkpoint,semantics:config.semantics,
    transaction_plan_identity:transactionPlan.plan_body_identity,
    compiled_ir_identity:exactIdentity(canonicalJson(compiledIr),'qel.wf020.compiled-circuit-ir.v1'),
    instruction_set:[...ALL_OPS],circuit_count:circuits.length,circuits,
    aggregate:{verdict:passed===checks?'PASS':'FAIL',passed_count:passed,check_count:checks},
    metrics:{maximum_trace_error_decimal:decimal(maximumTraceError),minimum_observed_eigenvalue_decimal:decimal(minimumEigenvalue),total_noise_bearing_cycles:circuits.reduce((sum,item)=>sum+item.total_cycles,0)},
    provenance:{channel_parameters:'DECLARED_INPUT',circuit_outputs:'CLASSICAL_SIMULATION_OUTPUT',physical_measurement:'NOT_MEASURED'},
    state:{technical:'CONSTRUCTED_WITHIN_DECLARED_SCOPE',owner_acceptance:'PENDING',signature:'UNSIGNED',release:'HOLD'},
    claim_boundary:config.claim_boundary,
  };
}

export function exactIdentity(raw, purpose) {
  return {bytes:raw.length,purpose,sgl_prime:sglp2(raw,purpose),sha256_secondary:sha256(raw),boundary:IDENTITY_BOUNDARY};
}

export function resultEnvelope(resultBody) {
  const raw = canonicalJson(resultBody);
  return {schema:'qel.wf020.circuit-batch-result/v1',result_body:resultBody,result_body_identity:exactIdentity(raw,RESULT_PURPOSE),state:{owner_acceptance:'PENDING',owner_signature:'NOT_APPLIED',public_release:'NOT_AUTHORIZED',release:'HOLD'}};
}

export function validatePortableRelativePath(value, label = 'path') {
  const reject = (detail) => { throw new WF020Error('WF020-PATH', `${label} is not a portable contained relative path: ${detail}`); };
  if (typeof value !== 'string' || value.length === 0) reject('empty or non-text value');
  if (value !== value.normalize('NFC')) reject('non-NFC text');
  if (!/^[A-Za-z0-9._/-]+$/u.test(value)) reject('character outside the frozen ASCII path alphabet');
  if (isAbsolute(value) || value.startsWith('/') || value.includes('\\') || value.includes(':')) reject('absolute, backslash, drive-relative, or alternate-stream syntax');
  if (/[\u0000-\u001f\u007f]/u.test(value)) reject('control character');
  const segments = value.split('/');
  for (const segment of segments) {
    if (!segment || segment === '.' || segment === '..') reject('empty, dot, or dot-dot segment');
    if (/[. ]$/u.test(segment)) reject('segment has a trailing dot or space');
    const stem = segment.split('.')[0].toUpperCase();
    if (/^(?:CON|PRN|AUX|NUL|CLOCK\$|CONIN\$|CONOUT\$|COM[1-9\u00b9\u00b2\u00b3]|LPT[1-9\u00b9\u00b2\u00b3])$/u.test(stem)) reject(`reserved Windows device alias ${segment}`);
  }
  return value;
}

export function resolveContained(root, ...parts) {
  if (parts.some((part) => typeof part !== 'string')) throw new WF020Error('WF020-PATH', 'path is not a portable contained relative path: non-text component');
  const portable = validatePortableRelativePath(parts.join('/'));
  const output = resolve(root,...portable.split('/')); const rel = relative(root,output);
  if (!rel || rel==='.' || isAbsolute(rel) || rel.split(/[\\/]/u).includes('..')) throw new WF020Error('WF020-PATH','path is not a contained child');
  return output;
}

export function atomicWriteNew(path, raw) {
  if (!Buffer.isBuffer(raw)) throw new WF020Error('WF020-WRITE-BYTES','output must be bytes');
  mkdirSync(dirname(path),{recursive:true});
  const parentReal = realpathSync(dirname(path));
  if (existsSync(path)) throw new WF020Error('WF020-WRITE-EXISTS',`refusing existing path ${path}`);
  const temporary = `${path}.partial`;
  if (existsSync(temporary)) throw new WF020Error('WF020-WRITE-PARTIAL',`temporary path already exists ${temporary}`);
  let descriptor;
  try {
    descriptor = openSync(temporary,'wx',0o600); let offset = 0;
    while (offset < raw.length) offset += writeSync(descriptor,raw,offset,raw.length-offset);
    fsyncSync(descriptor); closeSync(descriptor); descriptor = undefined;
    if (realpathSync(dirname(path))!==parentReal) throw new WF020Error('WF020-WRITE-RACE','output parent changed');
    linkSync(temporary,path); unlinkSync(temporary);
    if (!readFileSync(path).equals(raw)) throw new WF020Error('WF020-WRITE-VERIFY','exact reread mismatch');
    return {fsync_completed:true,exact_reread_verified:true};
  } catch (error) {
    if (descriptor!==undefined) closeSync(descriptor);
    if (existsSync(temporary)) unlinkSync(temporary);
    throw error;
  }
}
