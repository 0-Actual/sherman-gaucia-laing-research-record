#!/usr/bin/env python3
"""Replay QEL numerical audit; local computation only, no network actions.
Project originator: Sherman G. Laing. Review agent: GAUCIA / Codex.
Requires the already available numpy and scipy packages.
"""
from pathlib import Path
import importlib.util
import io
import json
import math
import sys
import unittest
import numpy as np

ROOT = Path(__file__).resolve().parent

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def boundary_tests(q):
    class BoundaryTests(unittest.TestCase):
        def test_01_reciprocal_large_scale(self):
            self.assertAlmostEqual(q.analytic_quasi_static_ramsey_coherence(1e200, 1e-200), math.exp(-0.5), places=14)
        def test_02_reciprocal_small_scale(self):
            self.assertAlmostEqual(q.analytic_quasi_static_ramsey_coherence(1e-200, 1e200), math.exp(-0.5), places=14)
        def test_03_zero_time_identity(self):
            self.assertEqual(q.analytic_quasi_static_ramsey_coherence(1e200, 0), 1.0)
        def test_04_zero_spread_identity(self):
            self.assertEqual(q.analytic_quasi_static_ramsey_coherence(0, 1e300), 1.0)
        def test_05_dimensionless_scale_invariance(self):
            for exponent in (-300,-200,-160,-100,0,100,160,200,300):
                with self.subTest(exponent=exponent):
                    self.assertAlmostEqual(q.analytic_quasi_static_ramsey_coherence(10.0**exponent, 10.0**(-exponent)), math.exp(-0.5), places=14)
        def test_06_large_product_decay_limit(self):
            self.assertEqual(q.analytic_quasi_static_ramsey_coherence(1e300,1e300), 0.0)
        def test_07_invalid_ramsey_domain(self):
            for pair in ((-1,1),(1,-1),(float('inf'),0),(1,float('nan'))):
                with self.subTest(pair=pair), self.assertRaises(q.LQCPValidationError):
                    q.analytic_quasi_static_ramsey_coherence(*pair)
        def test_08_modulation_overflow_rejected(self):
            with self.assertRaises(q.LQCPValidationError):
                q.safe_modulation_ratio(1e308,1e-14)
        def test_09_preservation_overflow_rejected(self):
            with self.assertRaises(q.LQCPValidationError):
                q.coherence_preservation_ratio(1e-14,1e308)
        def test_10_negative_modulation_overflow_rejected(self):
            with self.assertRaises(q.LQCPValidationError):
                q.safe_modulation_ratio(-1e308,1e-14)
        def test_11_valid_ratios_remain_exact(self):
            self.assertEqual(q.safe_modulation_ratio(-2,4),-0.5)
            self.assertEqual(q.coherence_preservation_ratio(4,2),0.5)
            self.assertEqual(q.safe_modulation_ratio(1e308,1),1e308)
            self.assertEqual(q.coherence_preservation_ratio(1,1e308),1e308)
        def test_12_tiny_denominator_still_rejected(self):
            for value in (0,1e-16,1e-15):
                with self.subTest(value=value), self.assertRaises(q.LQCPValidationError):
                    q.safe_modulation_ratio(1,value)
    return unittest.defaultTestLoader.loadTestsFromTestCase(BoundaryTests)

def run_suite(suite):
    stream=io.StringIO()
    result=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    return {'tests':result.testsRun,'passed':result.wasSuccessful(),
            'failed_test_methods':sorted({str(t).split()[0] for t,_ in result.failures+result.errors}),
            'failures':[str(t) for t,_ in result.failures],
            'errors':[str(t) for t,_ in result.errors]},stream.getvalue()

def main():
    results={}
    logs=[]
    for label,path in [('original',ROOT/'original/qel_lqcp_reference_v2.py'),
                       ('candidate',ROOT/'source/qel_lqcp_reference_v2_1.py')]:
        q=load('qel_lqcp_reference_v2',path)
        tests=load('qel_original_tests_'+label,ROOT/'original/test_qel_lqcp_reference_v2.py')
        baseline,bl=run_suite(unittest.defaultTestLoader.loadTestsFromModule(tests))
        boundary,bd=run_suite(boundary_tests(q))
        results[label]={'existing_regressions':baseline,'boundary_tests':boundary}
        logs.extend([label+' existing\n'+bl,label+' boundary\n'+bd])
    results['status']='CANDIDATE_PASS' if all(v['passed'] for v in results['candidate'].values()) else 'CANDIDATE_FAIL'
    results['scope']='Classical reference numerical evaluation; no laptop deployment or model comparison.'
    results['numpy']=np.__version__
    (ROOT/'evidence/test_results.json').write_text(json.dumps(results,indent=2)+'\n')
    (ROOT/'evidence/test_output.txt').write_text('\n'.join(logs))
    print(json.dumps(results,indent=2))
    return 0 if results['status']=='CANDIDATE_PASS' else 1

if __name__=='__main__':
    raise SystemExit(main())
