#!/usr/bin/env python3
"""
Project Quantum.Earth.Laing / Q6.1
Author / Originator: Sherman G. Laing
Primary Agent Role: GAUCIA
Challenge Review Role: Leviathan
Provenance and Authority Review Role: Nadine
Attribution: no use without visible credit to the author.

qel_lqcp_reference_v2_1.py

Internal numerical correction candidate, QEL-MATH-20260904-C001.
Parent: /Q6.¹/qel_lqcp_reference_v2.py. Original retained unchanged.
Changes: reciprocal-scale Ramsey evaluation and finite ratio outputs.
Owner release: HOLD / UNSIGNED. No laptop deployment implied.

Clean-room forensic correction of historical Quantum Emulation Algorithm #13,
"Laing Quantum Coherence Preservation" (LQCP).

This is NOT the exact historical textdoc byte object. It is a separately
versioned QEL reference implementation built from the recoverable historical
Python body and documented formulas. It corrects the following central issues:

* mean-squared-amplitude rescaling is identified as global norm inflation,
  not coherence preservation;
* quantum coherence is represented by explicit, basis-dependent density-
  matrix measures (l1 norm and relative entropy of coherence);
* state-vector operators must be unitary and generators used in exp(-iHt)
  must be Hermitian;
* open-system dephasing is modeled explicitly rather than being confused with
  closed-system unitary phase evolution;
* refocusing is demonstrated only for a declared quasi-static detuning model,
  while irreversible Markovian dephasing remains unreversed;
* raw vector difference, global phase, coherence, fidelity, correlation,
  entanglement, and norm are kept distinct;
* historical ratios and operator formulas fail closed when underdefined.

The reference is a deterministic classical simulation. It does not claim
physical quantum hardware, extended experimental coherence lifetime,
cryptographic security, sensor advantage, quantum-AI advantage, or deployed
error correction.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Iterable, Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.linalg import expm

ComplexArray = NDArray[np.complex128]
RealArray = NDArray[np.float64]

ATOL = 1e-10
RTOL = 1e-10
MAX_QUBITS_REFERENCE = 14


class LQCPValidationError(ValueError):
    """Fail-closed validation error for the LQCP reference."""


def _as_complex(value: ArrayLike, *, name: str) -> ComplexArray:
    arr = np.asarray(value, dtype=np.complex128)
    if not np.all(np.isfinite(arr.real)) or not np.all(np.isfinite(arr.imag)):
        raise LQCPValidationError(f"{name} contains non-finite values")
    return arr


def _finite_scalar(value: float, *, name: str) -> float:
    if isinstance(value, (bool, np.bool_)) or not np.isscalar(value):
        raise LQCPValidationError(f"{name} must be a finite scalar")
    result = float(value)
    if not np.isfinite(result):
        raise LQCPValidationError(f"{name} must be finite")
    return result


def validate_num_qubits(num_qubits: int) -> int:
    if isinstance(num_qubits, (bool, np.bool_)) or not isinstance(
        num_qubits, (int, np.integer)
    ):
        raise LQCPValidationError("num_qubits must be an integer")
    n = int(num_qubits)
    if n < 1 or n > MAX_QUBITS_REFERENCE:
        raise LQCPValidationError(
            f"num_qubits must be between 1 and {MAX_QUBITS_REFERENCE}"
        )
    return n


def dimension(num_qubits: int) -> int:
    return 1 << validate_num_qubits(num_qubits)


def validate_state(state: ArrayLike, num_qubits: int | None = None) -> ComplexArray:
    psi = _as_complex(state, name="state")
    if psi.ndim != 1 or psi.size == 0:
        raise LQCPValidationError("state must be a non-empty one-dimensional vector")
    if psi.size & (psi.size - 1):
        raise LQCPValidationError("state dimension must be a power of two")
    if num_qubits is not None and psi.size != dimension(num_qubits):
        raise LQCPValidationError("state dimension does not equal 2**num_qubits")
    norm = float(np.linalg.norm(psi))
    if not np.isfinite(norm) or norm <= 0.0:
        raise LQCPValidationError("state must have finite nonzero norm")
    return psi.copy()


def normalize_state(state: ArrayLike, num_qubits: int | None = None) -> ComplexArray:
    psi = validate_state(state, num_qubits)
    return psi / np.linalg.norm(psi)


def random_state(num_qubits: int, seed: int | np.random.SeedSequence) -> ComplexArray:
    rng = np.random.default_rng(seed)
    size = dimension(num_qubits)
    return normalize_state(rng.normal(size=size) + 1j * rng.normal(size=size))


def basis_state(num_qubits: int, index: int) -> ComplexArray:
    size = dimension(num_qubits)
    if isinstance(index, (bool, np.bool_)) or not isinstance(index, (int, np.integer)):
        raise LQCPValidationError("basis index must be an integer")
    i = int(index)
    if i < 0 or i >= size:
        raise LQCPValidationError("basis index out of range")
    psi = np.zeros(size, dtype=np.complex128)
    psi[i] = 1.0
    return psi


def validate_square_matrix(matrix: ArrayLike, size: int, *, name: str) -> ComplexArray:
    arr = _as_complex(matrix, name=name)
    if arr.ndim != 2 or arr.shape != (size, size):
        raise LQCPValidationError(
            f"{name} shape {arr.shape} does not match ({size}, {size})"
        )
    return arr.copy()


def is_hermitian(matrix: ArrayLike, *, atol: float = ATOL, rtol: float = RTOL) -> bool:
    arr = _as_complex(matrix, name="matrix")
    return bool(
        arr.ndim == 2
        and arr.shape[0] == arr.shape[1]
        and np.allclose(arr, arr.conj().T, atol=atol, rtol=rtol)
    )


def is_unitary(matrix: ArrayLike, *, atol: float = ATOL, rtol: float = RTOL) -> bool:
    arr = _as_complex(matrix, name="matrix")
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1]:
        return False
    eye = np.eye(arr.shape[0], dtype=np.complex128)
    return bool(
        np.allclose(arr.conj().T @ arr, eye, atol=atol, rtol=rtol)
        and np.allclose(arr @ arr.conj().T, eye, atol=atol, rtol=rtol)
    )


def apply_unitary(state: ArrayLike, operator: ArrayLike) -> ComplexArray:
    psi = normalize_state(state)
    unitary = validate_square_matrix(operator, psi.size, name="operator")
    if not is_unitary(unitary):
        raise LQCPValidationError("operator must be unitary")
    out = unitary @ psi
    if not np.isclose(np.linalg.norm(out), 1.0, atol=2e-9, rtol=2e-9):
        raise LQCPValidationError("unitary application did not preserve norm")
    return out.astype(np.complex128)


def evolve_hamiltonian(state: ArrayLike, hamiltonian: ArrayLike, time: float) -> ComplexArray:
    psi = normalize_state(state)
    t = _finite_scalar(time, name="time")
    h = validate_square_matrix(hamiltonian, psi.size, name="hamiltonian")
    if not is_hermitian(h):
        raise LQCPValidationError("Hamiltonian/generator must be Hermitian")
    unitary = expm(-1j * h * t)
    if not is_unitary(unitary, atol=2e-9, rtol=2e-9):
        raise LQCPValidationError("generated evolution failed unitarity check")
    return apply_unitary(psi, unitary)


def density_matrix(state: ArrayLike) -> ComplexArray:
    psi = normalize_state(state)
    return np.outer(psi, psi.conj())


def validate_density_matrix(density: ArrayLike) -> ComplexArray:
    rho = _as_complex(density, name="density")
    if rho.ndim != 2 or rho.shape[0] != rho.shape[1] or rho.size == 0:
        raise LQCPValidationError("density matrix must be non-empty and square")
    if not is_hermitian(rho, atol=1e-9, rtol=1e-9):
        raise LQCPValidationError("density matrix must be Hermitian")
    trace = complex(np.trace(rho))
    if not np.isclose(trace, 1.0, atol=1e-9, rtol=1e-9):
        raise LQCPValidationError("density matrix must have trace one")
    eigenvalues = np.linalg.eigvalsh(rho).real
    if float(np.min(eigenvalues)) < -1e-9:
        raise LQCPValidationError("density matrix must be positive semidefinite")
    return rho.copy()


def von_neumann_entropy(density: ArrayLike, *, base: float = 2.0) -> float:
    rho = validate_density_matrix(density)
    b = _finite_scalar(base, name="base")
    if b <= 0.0 or np.isclose(b, 1.0):
        raise LQCPValidationError("entropy base must be positive and not one")
    eigenvalues = np.clip(np.linalg.eigvalsh(rho).real, 0.0, 1.0)
    nonzero = eigenvalues[eigenvalues > 1e-15]
    result = -float(np.sum(nonzero * np.log(nonzero) / np.log(b)))
    return 0.0 if abs(result) < 1e-14 else result


def dephase_density(density: ArrayLike) -> ComplexArray:
    rho = validate_density_matrix(density)
    return np.diag(np.diag(rho)).astype(np.complex128)


def l1_coherence(density: ArrayLike) -> float:
    """Basis-dependent l1 norm of coherence: sum of off-diagonal magnitudes."""
    rho = validate_density_matrix(density)
    off_diagonal = rho - np.diag(np.diag(rho))
    result = float(np.sum(np.abs(off_diagonal)))
    return 0.0 if abs(result) < 1e-14 else result


def relative_entropy_coherence(density: ArrayLike) -> float:
    """Basis-dependent relative entropy of coherence in bits."""
    rho = validate_density_matrix(density)
    result = von_neumann_entropy(dephase_density(rho)) - von_neumann_entropy(rho)
    if result < -1e-9:
        raise LQCPValidationError("relative entropy coherence became negative")
    return 0.0 if abs(result) < 1e-14 else float(result)


def pure_state_fidelity(state_a: ArrayLike, state_b: ArrayLike) -> float:
    a = normalize_state(state_a)
    b = normalize_state(state_b)
    if a.shape != b.shape:
        raise LQCPValidationError("states must have equal dimensions")
    return float(np.clip(abs(np.vdot(a, b)) ** 2, 0.0, 1.0))


def phase_invariant_distance(state_a: ArrayLike, state_b: ArrayLike) -> float:
    return float(np.sqrt(max(0.0, 1.0 - pure_state_fidelity(state_a, state_b))))


def trace_distance(density_a: ArrayLike, density_b: ArrayLike) -> float:
    a = validate_density_matrix(density_a)
    b = validate_density_matrix(density_b)
    if a.shape != b.shape:
        raise LQCPValidationError("density matrices must have equal dimensions")
    singular_values = np.linalg.svd(a - b, compute_uv=False)
    return float(0.5 * np.sum(singular_values))


def historical_mean_square_rescale(state: ArrayLike) -> ComplexArray:
    """Reproduce the historical mean-squared-amplitude scaling defect."""
    psi = validate_state(state)
    factor = float(np.mean(np.abs(psi) ** 2))
    if not np.isfinite(factor) or factor <= 0.0:
        raise LQCPValidationError("historical coherence factor must be positive")
    return (psi / np.sqrt(factor)).astype(np.complex128)


def historical_lcr_distance(state_prime: ArrayLike, state: ArrayLike) -> float:
    """Historical raw-vector squared distance; not a coherence measure."""
    a = validate_state(state_prime)
    b = validate_state(state)
    if a.shape != b.shape:
        raise LQCPValidationError("states must have equal dimensions")
    return float(np.sum(np.abs(a - b) ** 2))


def safe_modulation_ratio(stabilization: float, coherence: float) -> float:
    numerator = _finite_scalar(stabilization, name="stabilization")
    denominator = _finite_scalar(coherence, name="coherence")
    if abs(denominator) <= 1e-15:
        raise LQCPValidationError("coherence denominator is zero or too small")
    return _finite_scalar(numerator / denominator, name="modulation ratio")


def historical_lcpo_from_kappa(kappa: ArrayLike) -> ComplexArray:
    """Conservative standard-basis interpretation of I-kappa."""
    arr = _as_complex(kappa, name="kappa")
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1]:
        raise LQCPValidationError("kappa must be square")
    return np.eye(arr.shape[0], dtype=np.complex128) - arr


def commutator(operator_a: ArrayLike, operator_b: ArrayLike) -> ComplexArray:
    a = _as_complex(operator_a, name="operator_a")
    b = _as_complex(operator_b, name="operator_b")
    if a.ndim != 2 or b.ndim != 2 or a.shape != b.shape or a.shape[0] != a.shape[1]:
        raise LQCPValidationError("commutator requires equal-size square matrices")
    return a @ b - b @ a


def expectation(state: ArrayLike, operator: ArrayLike) -> float:
    psi = normalize_state(state)
    op = validate_square_matrix(operator, psi.size, name="operator")
    if not is_hermitian(op):
        raise LQCPValidationError("expectation operator must be Hermitian")
    value = complex(np.vdot(psi, op @ psi))
    if abs(value.imag) > 1e-9:
        raise LQCPValidationError("Hermitian expectation acquired a non-negligible imaginary part")
    return float(value.real)


def validate_kraus_operators(operators: Iterable[ArrayLike], size: int) -> list[ComplexArray]:
    ops = [validate_square_matrix(op, size, name="Kraus operator") for op in operators]
    if not ops:
        raise LQCPValidationError("at least one Kraus operator is required")
    completeness = sum((op.conj().T @ op for op in ops), np.zeros((size, size), dtype=np.complex128))
    if not np.allclose(completeness, np.eye(size), atol=1e-9, rtol=1e-9):
        raise LQCPValidationError("Kraus operators are not trace-preserving")
    return ops


def apply_kraus_channel(density: ArrayLike, operators: Iterable[ArrayLike]) -> ComplexArray:
    rho = validate_density_matrix(density)
    ops = validate_kraus_operators(operators, rho.shape[0])
    out = sum((op @ rho @ op.conj().T for op in ops), np.zeros_like(rho))
    out = (out + out.conj().T) / 2.0
    out /= np.trace(out)
    return validate_density_matrix(out)


def dephasing_kraus(eta: float) -> tuple[ComplexArray, ComplexArray]:
    retention = _finite_scalar(eta, name="eta")
    if retention < 0.0 or retention > 1.0:
        raise LQCPValidationError("eta must lie in [0, 1]")
    k0 = np.sqrt((1.0 + retention) / 2.0) * I2
    k1 = np.sqrt((1.0 - retention) / 2.0) * Z
    return k0.astype(np.complex128), k1.astype(np.complex128)


def phase_damping_channel(density: ArrayLike, eta: float) -> ComplexArray:
    rho = validate_density_matrix(density)
    if rho.shape != (2, 2):
        raise LQCPValidationError("reference phase-damping channel is one-qubit only")
    return apply_kraus_channel(rho, dephasing_kraus(eta))


def markovian_dephasing(density: ArrayLike, gamma: float, time: float) -> ComplexArray:
    rate = _finite_scalar(gamma, name="gamma")
    t = _finite_scalar(time, name="time")
    if rate < 0.0 or t < 0.0:
        raise LQCPValidationError("gamma and time must be nonnegative")
    return phase_damping_channel(density, float(np.exp(-rate * t)))


def unitary_density_evolution(density: ArrayLike, unitary: ArrayLike) -> ComplexArray:
    rho = validate_density_matrix(density)
    u = validate_square_matrix(unitary, rho.shape[0], name="unitary")
    if not is_unitary(u):
        raise LQCPValidationError("operator must be unitary")
    return validate_density_matrix(u @ rho @ u.conj().T)


def hamiltonian_density_evolution(
    density: ArrayLike, hamiltonian: ArrayLike, time: float
) -> ComplexArray:
    rho = validate_density_matrix(density)
    t = _finite_scalar(time, name="time")
    h = validate_square_matrix(hamiltonian, rho.shape[0], name="hamiltonian")
    if not is_hermitian(h):
        raise LQCPValidationError("Hamiltonian/generator must be Hermitian")
    return unitary_density_evolution(rho, expm(-1j * h * t))


def quasi_static_ensemble_density(
    sigma: float,
    time: float,
    *,
    samples: int,
    seed: int | np.random.SeedSequence,
    echo: bool = False,
) -> ComplexArray:
    """Seeded ensemble under static Gaussian Z detuning.

    The initial state is |+>. Ramsey evolution accumulates exp(-i delta t).
    A perfect Hahn-echo sign reversal cancels the declared static detuning.
    This is a toy simulation and not a universal decoherence model.
    """
    spread = _finite_scalar(sigma, name="sigma")
    t = _finite_scalar(time, name="time")
    if spread < 0.0 or t < 0.0:
        raise LQCPValidationError("sigma and time must be nonnegative")
    if isinstance(samples, (bool, np.bool_)) or not isinstance(samples, (int, np.integer)):
        raise LQCPValidationError("samples must be an integer")
    count = int(samples)
    if count < 1 or count > 2_000_000:
        raise LQCPValidationError("samples must be between 1 and 2,000,000")
    rng = np.random.default_rng(seed)
    detunings = rng.normal(0.0, spread, size=count)
    phases = np.ones(count, dtype=np.complex128) if echo else np.exp(-1j * detunings * t)
    coherence = complex(np.mean(phases))
    rho = np.array(
        [[0.5, 0.5 * coherence], [0.5 * coherence.conjugate(), 0.5]],
        dtype=np.complex128,
    )
    return validate_density_matrix(rho)


def analytic_quasi_static_ramsey_coherence(sigma: float, time: float) -> float:
    spread = _finite_scalar(sigma, name="sigma")
    t = _finite_scalar(time, name="time")
    if spread < 0.0 or t < 0.0:
        raise LQCPValidationError("sigma and time must be nonnegative")
    # Form the dimensionless product first. Squaring spread in isolation can
    # overflow even when spread*time is small or exactly zero.
    scaled_time = spread * t
    return float(np.exp(-0.5 * scaled_time * scaled_time))


def coherence_preservation_ratio(before: float, after: float) -> float:
    initial = _finite_scalar(before, name="before")
    final = _finite_scalar(after, name="after")
    if initial < 0.0 or final < 0.0:
        raise LQCPValidationError("coherence values must be nonnegative")
    if initial <= 1e-15:
        raise LQCPValidationError("initial coherence is zero or too small")
    return _finite_scalar(final / initial, name="coherence preservation ratio")


def original_example_generator(num_qubits: int) -> ComplexArray:
    n = validate_num_qubits(num_qubits)
    return np.kron(Z, np.eye(1 << (n - 1), dtype=np.complex128))


I2 = np.eye(2, dtype=np.complex128)
X = np.array([[0, 1], [1, 0]], dtype=np.complex128)
Y = np.array([[0, -1j], [1j, 0]], dtype=np.complex128)
Z = np.array([[1, 0], [0, -1]], dtype=np.complex128)
HADAMARD = np.array([[1, 1], [1, -1]], dtype=np.complex128) / np.sqrt(2.0)
PLUS = np.array([1, 1], dtype=np.complex128) / np.sqrt(2.0)
MINUS = np.array([1, -1], dtype=np.complex128) / np.sqrt(2.0)


@dataclass(frozen=True)
class CoherenceMetrics:
    l1: float
    relative_entropy_bits: float
    purity: float


@dataclass(frozen=True)
class EnsembleBenchmark:
    sigma: float
    time: float
    samples: int
    ramsey_l1: float
    ramsey_analytic: float
    ramsey_abs_error: float
    echo_l1: float
    markovian_l1: float
    echo_does_not_reverse_markovian: bool


def coherence_metrics(density: ArrayLike) -> CoherenceMetrics:
    rho = validate_density_matrix(density)
    return CoherenceMetrics(
        l1=l1_coherence(rho),
        relative_entropy_bits=relative_entropy_coherence(rho),
        purity=float(np.trace(rho @ rho).real),
    )


def build_reference_demo() -> dict:
    historical = random_state(3, 13013)
    rescaled = historical_mean_square_rescale(historical)
    normalized_rescaled = normalize_state(rescaled)
    historical_rho = density_matrix(historical)
    rescaled_rho = density_matrix(normalized_rescaled)

    plus_rho = density_matrix(PLUS)
    z_evolved = hamiltonian_density_evolution(plus_rho, Z / 2.0, 5.2)
    markovian = markovian_dephasing(plus_rho, gamma=0.4, time=5.0)

    sigma = 1.0
    t = 2.0
    samples = 200_000
    ramsey = quasi_static_ensemble_density(sigma, t, samples=samples, seed=130130, echo=False)
    echo = quasi_static_ensemble_density(sigma, t, samples=samples, seed=130130, echo=True)
    analytic = analytic_quasi_static_ramsey_coherence(sigma, t)

    # Echo cancels the declared static detuning model but does not undo an
    # independent Markovian dephasing channel.
    echo_then_markovian = markovian_dephasing(echo, gamma=0.4, time=5.0)
    benchmark = EnsembleBenchmark(
        sigma=sigma,
        time=t,
        samples=samples,
        ramsey_l1=l1_coherence(ramsey),
        ramsey_analytic=analytic,
        ramsey_abs_error=abs(l1_coherence(ramsey) - analytic),
        echo_l1=l1_coherence(echo),
        markovian_l1=l1_coherence(echo_then_markovian),
        echo_does_not_reverse_markovian=l1_coherence(echo_then_markovian) < l1_coherence(echo),
    )

    phase_state = -1j * PLUS
    oscillation = [
        {"time": value, "historical_distance": historical_lcr_distance(np.exp(-1j * value) * PLUS, PLUS)}
        for value in (0.0, float(np.pi), float(2.0 * np.pi), float(3.0 * np.pi))
    ]

    return {
        "schema": "qel.lqcp-reference-demo/v2",
        "historical_rescale": {
            "dimension": int(historical.size),
            "norm_before": float(np.linalg.norm(historical)),
            "mean_squared_amplitude": float(np.mean(np.abs(historical) ** 2)),
            "norm_after": float(np.linalg.norm(rescaled)),
            "probability_sum_after": float(np.sum(np.abs(rescaled) ** 2)),
            "normalized_state_fidelity": pure_state_fidelity(historical, normalized_rescaled),
            "l1_before": l1_coherence(historical_rho),
            "l1_after_normalization": l1_coherence(rescaled_rho),
        },
        "basis_dependence": {
            "basis_state_l1": l1_coherence(density_matrix(basis_state(1, 0))),
            "plus_state_l1": l1_coherence(plus_rho),
            "basis_state_relative_entropy": relative_entropy_coherence(density_matrix(basis_state(1, 0))),
            "plus_state_relative_entropy": relative_entropy_coherence(plus_rho),
        },
        "closed_unitary": {
            "generator": "Z/2",
            "time": 5.2,
            "l1_before": l1_coherence(plus_rho),
            "l1_after": l1_coherence(z_evolved),
            "fidelity_to_initial": float(np.trace(plus_rho @ z_evolved).real),
            "meaning": "closed diagonal unitary preserves computational-basis l1 magnitude while changing phase",
        },
        "markovian_dephasing": {
            "gamma": 0.4,
            "time": 5.0,
            "eta": float(np.exp(-2.0)),
            "l1_before": l1_coherence(plus_rho),
            "l1_after": l1_coherence(markovian),
        },
        "quasi_static_benchmark": asdict(benchmark),
        "global_phase_counterexample": {
            "historical_distance": historical_lcr_distance(phase_state, PLUS),
            "fidelity": pure_state_fidelity(phase_state, PLUS),
            "phase_invariant_distance": phase_invariant_distance(phase_state, PLUS),
        },
        "long_time_limit_counterexample": oscillation,
        "claim_boundary": [
            "classical quantum-information simulation",
            "basis-dependent coherence metrics declared",
            "toy quasi-static and Markovian dephasing models only",
            "no physical lifetime extension claim",
            "no cryptographic-security claim",
            "no sensor or quantum-AI advantage claim",
            "no deployed error-correction claim",
        ],
    }


if __name__ == "__main__":
    import json

    print(json.dumps(build_reference_demo(), sort_keys=True, indent=2))
