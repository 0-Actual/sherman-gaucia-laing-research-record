#!/usr/bin/env python3
"""
Project Quantum.Earth.Laing / Q6.1
Author / Originator: Sherman G. Laing
Primary Agent Role: GAUCIA
Challenge Review Role: Leviathan
Provenance and Authority Review Role: Nadine
Attribution: no use without visible credit to the author.

Unit and regression tests for qel_lqcp_reference_v2.py.
"""
from __future__ import annotations

import json
import math
import unittest

import numpy as np
from scipy.linalg import expm

import qel_lqcp_reference_v2 as q


class LQCPReferenceTests(unittest.TestCase):
    def assertArrayClose(self, actual, expected, tol=1e-9):
        self.assertTrue(np.allclose(actual, expected, atol=tol, rtol=tol), (actual, expected))

    # Validation and state construction
    def test_001_validate_qubits_one(self):
        self.assertEqual(q.validate_num_qubits(1), 1)

    def test_002_validate_qubits_bool_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_num_qubits(True)

    def test_003_validate_qubits_zero_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_num_qubits(0)

    def test_004_validate_qubits_too_large_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_num_qubits(q.MAX_QUBITS_REFERENCE + 1)

    def test_005_dimension(self):
        self.assertEqual(q.dimension(5), 32)

    def test_006_non_power_state_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_state([1, 0, 0])

    def test_007_zero_state_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.normalize_state([0, 0])

    def test_008_nonfinite_state_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_state([1, np.nan])

    def test_009_basis_state(self):
        self.assertArrayClose(q.basis_state(2, 2), [0, 0, 1, 0])

    def test_010_basis_index_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.basis_state(2, 4)

    def test_011_random_seed_repeat(self):
        self.assertArrayClose(q.random_state(3, 42), q.random_state(3, 42))

    def test_012_random_seed_difference(self):
        self.assertFalse(np.allclose(q.random_state(3, 42), q.random_state(3, 43)))

    def test_013_random_state_normalized(self):
        self.assertAlmostEqual(float(np.linalg.norm(q.random_state(4, 42))), 1.0, places=12)

    def test_014_density_trace(self):
        self.assertAlmostEqual(float(np.trace(q.density_matrix([1, 1])).real), 1.0, places=12)

    def test_015_density_not_trace_one_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_density_matrix(np.eye(2))

    def test_016_density_nonhermitian_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_density_matrix([[0.5, 1], [0, 0.5]])

    def test_017_density_negative_eigenvalue_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_density_matrix([[1.2, 0], [0, -0.2]])

    def test_018_square_matrix_shape_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.validate_square_matrix(np.eye(3), 2, name="operator")

    def test_019_nonfinite_scalar_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.evolve_hamiltonian([1, 0], q.Z, np.inf)

    def test_020_bool_time_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.evolve_hamiltonian([1, 0], q.Z, True)

    # Operators and closed evolution
    def test_021_pauli_z_hermitian(self):
        self.assertTrue(q.is_hermitian(q.Z))

    def test_022_nonhermitian_detected(self):
        self.assertFalse(q.is_hermitian([[0, 1], [0, 0]]))

    def test_023_hadamard_unitary(self):
        self.assertTrue(q.is_unitary(q.HADAMARD))

    def test_024_nonunitary_detected(self):
        self.assertFalse(q.is_unitary([[2, 0], [0, 1]]))

    def test_025_apply_unitary_preserves_norm(self):
        self.assertAlmostEqual(float(np.linalg.norm(q.apply_unitary([1, 0], q.HADAMARD))), 1.0, places=12)

    def test_026_apply_nonunitary_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.apply_unitary([1, 0], [[2, 0], [0, 1]])

    def test_027_nonhermitian_generator_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.evolve_hamiltonian([1, 0], [[0, 1], [0, 0]], 1.0)

    def test_028_hamiltonian_evolution_norm(self):
        out = q.evolve_hamiltonian(q.PLUS, q.Z / 2.0, 5.2)
        self.assertAlmostEqual(float(np.linalg.norm(out)), 1.0, places=12)

    def test_029_density_unitary_trace(self):
        out = q.unitary_density_evolution(q.density_matrix(q.PLUS), q.Z)
        self.assertAlmostEqual(float(np.trace(out).real), 1.0, places=12)

    def test_030_density_nonunitary_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.unitary_density_evolution(q.density_matrix(q.PLUS), [[1, 0], [0, 2]])

    def test_031_commutator_zero(self):
        self.assertAlmostEqual(float(np.linalg.norm(q.commutator(q.Z, q.Z))), 0.0, places=12)

    def test_032_commutator_nonzero(self):
        self.assertGreater(float(np.linalg.norm(q.commutator(q.X, q.Z))), 1.0)

    def test_033_expectation_conserved_when_commutes(self):
        state = q.normalize_state([1, 1j])
        before = q.expectation(state, q.Z)
        after = q.expectation(q.evolve_hamiltonian(state, q.Z, 1.1), q.Z)
        self.assertAlmostEqual(before, after, places=12)

    def test_034_expectation_not_universally_conserved(self):
        before = q.expectation([1, 0], q.Z)
        after = q.expectation(q.evolve_hamiltonian([1, 0], q.X, math.pi / 4), q.Z)
        self.assertGreater(abs(before - after), 0.9)

    def test_035_nonhermitian_expectation_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.expectation([1, 0], [[0, 1], [0, 0]])

    # Coherence measures and basis dependence
    def test_036_basis_state_l1_zero(self):
        self.assertAlmostEqual(q.l1_coherence(q.density_matrix([1, 0])), 0.0, places=12)

    def test_037_plus_state_l1_one(self):
        self.assertAlmostEqual(q.l1_coherence(q.density_matrix(q.PLUS)), 1.0, places=12)

    def test_038_minus_state_l1_one(self):
        self.assertAlmostEqual(q.l1_coherence(q.density_matrix(q.MINUS)), 1.0, places=12)

    def test_039_mixed_state_l1_zero(self):
        self.assertAlmostEqual(q.l1_coherence(np.eye(2) / 2.0), 0.0, places=12)

    def test_040_plus_relative_entropy_one(self):
        self.assertAlmostEqual(q.relative_entropy_coherence(q.density_matrix(q.PLUS)), 1.0, places=12)

    def test_041_basis_relative_entropy_zero(self):
        self.assertAlmostEqual(q.relative_entropy_coherence(q.density_matrix([1, 0])), 0.0, places=12)

    def test_042_mixed_relative_entropy_zero(self):
        self.assertAlmostEqual(q.relative_entropy_coherence(np.eye(2) / 2.0), 0.0, places=12)

    def test_043_hadamard_changes_basis_coherence(self):
        before = q.l1_coherence(q.density_matrix([1, 0]))
        after = q.l1_coherence(q.density_matrix(q.apply_unitary([1, 0], q.HADAMARD)))
        self.assertAlmostEqual(before, 0.0, places=12)
        self.assertAlmostEqual(after, 1.0, places=12)

    def test_044_z_phase_preserves_l1_magnitude(self):
        before = q.l1_coherence(q.density_matrix(q.PLUS))
        after = q.l1_coherence(q.hamiltonian_density_evolution(q.density_matrix(q.PLUS), q.Z / 2.0, 5.2))
        self.assertAlmostEqual(before, after, places=12)

    def test_045_dephase_removes_coherence(self):
        self.assertAlmostEqual(q.l1_coherence(q.dephase_density(q.density_matrix(q.PLUS))), 0.0, places=12)

    def test_046_entropy_pure_zero(self):
        self.assertAlmostEqual(q.von_neumann_entropy(q.density_matrix(q.PLUS)), 0.0, places=12)

    def test_047_entropy_maximally_mixed_one(self):
        self.assertAlmostEqual(q.von_neumann_entropy(np.eye(2) / 2.0), 1.0, places=12)

    def test_048_metrics_plus_purity_one(self):
        self.assertAlmostEqual(q.coherence_metrics(q.density_matrix(q.PLUS)).purity, 1.0, places=12)

    def test_049_metrics_mixed_purity_half(self):
        self.assertAlmostEqual(q.coherence_metrics(np.eye(2) / 2.0).purity, 0.5, places=12)

    def test_050_coherence_is_basis_dependent(self):
        z_basis = q.l1_coherence(q.density_matrix([1, 0]))
        x_basis_state_in_z_coordinates = q.l1_coherence(q.density_matrix(q.PLUS))
        self.assertNotEqual(z_basis, x_basis_state_in_z_coordinates)

    # Historical defect tests
    def test_051_historical_normalized_mean_is_inverse_dimension(self):
        state = q.random_state(3, 13)
        self.assertAlmostEqual(float(np.mean(np.abs(state) ** 2)), 1 / 8, places=12)

    def test_052_historical_rescale_norm_sqrt_dimension(self):
        state = q.random_state(3, 13)
        out = q.historical_mean_square_rescale(state)
        self.assertAlmostEqual(float(np.linalg.norm(out)), math.sqrt(8), places=12)

    def test_053_historical_rescale_probability_sum_dimension(self):
        state = q.random_state(3, 13)
        out = q.historical_mean_square_rescale(state)
        self.assertAlmostEqual(float(np.sum(np.abs(out) ** 2)), 8.0, places=12)

    def test_054_historical_rescale_same_physical_ray(self):
        state = q.random_state(3, 13)
        out = q.historical_mean_square_rescale(state)
        self.assertAlmostEqual(q.pure_state_fidelity(state, q.normalize_state(out)), 1.0, places=12)

    def test_055_historical_rescale_same_l1_after_normalization(self):
        state = q.random_state(3, 13)
        before = q.l1_coherence(q.density_matrix(state))
        after = q.l1_coherence(q.density_matrix(q.normalize_state(q.historical_mean_square_rescale(state))))
        self.assertAlmostEqual(before, after, places=12)

    def test_056_historical_global_phase_false_positive(self):
        self.assertAlmostEqual(q.historical_lcr_distance(-q.PLUS, q.PLUS), 4.0, places=12)

    def test_057_global_phase_fidelity_one(self):
        self.assertAlmostEqual(q.pure_state_fidelity(-1j * q.PLUS, q.PLUS), 1.0, places=12)

    def test_058_global_phase_distance_zero(self):
        self.assertAlmostEqual(q.phase_invariant_distance(-1j * q.PLUS, q.PLUS), 0.0, places=12)

    def test_059_historical_limit_oscillates_zero(self):
        self.assertAlmostEqual(q.historical_lcr_distance(np.exp(-1j * 0.0) * q.PLUS, q.PLUS), 0.0, places=12)

    def test_060_historical_limit_oscillates_four(self):
        self.assertAlmostEqual(q.historical_lcr_distance(np.exp(-1j * math.pi) * q.PLUS, q.PLUS), 4.0, places=12)

    def test_061_historical_limit_returns_zero(self):
        self.assertAlmostEqual(q.historical_lcr_distance(np.exp(-1j * 2 * math.pi) * q.PLUS, q.PLUS), 0.0, places=12)

    def test_062_lcpo_can_be_nonhermitian(self):
        lcpo = q.historical_lcpo_from_kappa([[0, 1], [0, 0]])
        self.assertFalse(q.is_hermitian(lcpo))

    def test_063_lcpo_can_be_nonunitary(self):
        lcpo = q.historical_lcpo_from_kappa([[0.2, 0], [0, 0]])
        self.assertFalse(q.is_unitary(lcpo))

    def test_064_modulation_ratio(self):
        self.assertAlmostEqual(q.safe_modulation_ratio(2, 4), 0.5, places=12)

    def test_065_modulation_zero_denominator_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.safe_modulation_ratio(1, 0)

    def test_066_original_generator_shape(self):
        self.assertEqual(q.original_example_generator(3).shape, (8, 8))

    def test_067_original_generator_local_z(self):
        self.assertArrayClose(q.original_example_generator(3), np.kron(q.Z, np.eye(4)))

    def test_068_original_generator_hermitian(self):
        self.assertTrue(q.is_hermitian(q.original_example_generator(3)))

    def test_069_original_closed_evolution_preserves_l1(self):
        rho = q.density_matrix(q.random_state(3, 99))
        out = q.hamiltonian_density_evolution(rho, q.original_example_generator(3), 5.2)
        self.assertAlmostEqual(q.l1_coherence(rho), q.l1_coherence(out), places=10)

    def test_070_shape_only_nonhermitian_counterexample(self):
        bad = np.array([[0, 1], [0, 0]], dtype=np.complex128)
        self.assertEqual(bad.shape, (2, 2))
        self.assertFalse(q.is_hermitian(bad))
        self.assertFalse(q.is_unitary(expm(-1j * bad)))

    # Open-system channels
    def test_071_dephasing_eta_one_identity(self):
        rho = q.density_matrix(q.PLUS)
        self.assertArrayClose(q.phase_damping_channel(rho, 1.0), rho)

    def test_072_dephasing_eta_zero_full_dephase(self):
        rho = q.phase_damping_channel(q.density_matrix(q.PLUS), 0.0)
        self.assertArrayClose(rho, np.eye(2) / 2.0)

    def test_073_dephasing_half_l1_half(self):
        rho = q.phase_damping_channel(q.density_matrix(q.PLUS), 0.5)
        self.assertAlmostEqual(q.l1_coherence(rho), 0.5, places=12)

    def test_074_dephasing_eta_out_of_range_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.dephasing_kraus(1.1)

    def test_075_kraus_completeness(self):
        ops = q.dephasing_kraus(0.3)
        total = sum((op.conj().T @ op for op in ops), np.zeros((2, 2), dtype=np.complex128))
        self.assertArrayClose(total, np.eye(2))

    def test_076_invalid_kraus_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.apply_kraus_channel(q.density_matrix(q.PLUS), [np.eye(2), np.eye(2)])

    def test_077_markovian_expected_retention(self):
        rho = q.markovian_dephasing(q.density_matrix(q.PLUS), gamma=0.4, time=5.0)
        self.assertAlmostEqual(q.l1_coherence(rho), math.exp(-2.0), places=12)

    def test_078_markovian_negative_rate_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.markovian_dephasing(q.density_matrix(q.PLUS), gamma=-1, time=1)

    def test_079_markovian_negative_time_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.markovian_dephasing(q.density_matrix(q.PLUS), gamma=1, time=-1)

    def test_080_trace_distance_self_zero(self):
        rho = q.density_matrix(q.PLUS)
        self.assertAlmostEqual(q.trace_distance(rho, rho), 0.0, places=12)

    def test_081_trace_distance_orthogonal_one(self):
        self.assertAlmostEqual(q.trace_distance(q.density_matrix([1, 0]), q.density_matrix([0, 1])), 1.0, places=12)

    def test_082_preservation_ratio(self):
        self.assertAlmostEqual(q.coherence_preservation_ratio(1.0, 0.25), 0.25, places=12)

    def test_083_preservation_ratio_zero_initial_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.coherence_preservation_ratio(0.0, 0.0)

    # Quasi-static refocusing benchmark
    def test_084_analytic_quasi_static_value(self):
        self.assertAlmostEqual(q.analytic_quasi_static_ramsey_coherence(1.0, 2.0), math.exp(-2.0), places=12)

    def test_085_quasi_static_seed_repeat(self):
        a = q.quasi_static_ensemble_density(1.0, 2.0, samples=20_000, seed=77)
        b = q.quasi_static_ensemble_density(1.0, 2.0, samples=20_000, seed=77)
        self.assertArrayClose(a, b)

    def test_086_quasi_static_seed_difference(self):
        a = q.quasi_static_ensemble_density(1.0, 2.0, samples=20_000, seed=77)
        b = q.quasi_static_ensemble_density(1.0, 2.0, samples=20_000, seed=78)
        self.assertFalse(np.allclose(a, b, atol=1e-6, rtol=1e-6))

    def test_087_quasi_static_matches_analytic(self):
        rho = q.quasi_static_ensemble_density(1.0, 2.0, samples=200_000, seed=130130)
        self.assertLess(abs(q.l1_coherence(rho) - math.exp(-2.0)), 0.004)

    def test_088_echo_refocuses_static_detuning(self):
        rho = q.quasi_static_ensemble_density(1.0, 2.0, samples=20_000, seed=77, echo=True)
        self.assertAlmostEqual(q.l1_coherence(rho), 1.0, places=12)

    def test_089_echo_state_is_plus_density(self):
        rho = q.quasi_static_ensemble_density(2.0, 10.0, samples=1000, seed=88, echo=True)
        self.assertArrayClose(rho, q.density_matrix(q.PLUS))

    def test_090_echo_does_not_reverse_markovian_channel(self):
        echo = q.quasi_static_ensemble_density(1.0, 2.0, samples=1000, seed=88, echo=True)
        after = q.markovian_dephasing(echo, gamma=0.4, time=5.0)
        self.assertAlmostEqual(q.l1_coherence(after), math.exp(-2.0), places=12)

    def test_091_quasi_static_negative_sigma_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.quasi_static_ensemble_density(-1, 1, samples=10, seed=1)

    def test_092_quasi_static_zero_samples_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.quasi_static_ensemble_density(1, 1, samples=0, seed=1)

    def test_093_quasi_static_bool_samples_rejected(self):
        with self.assertRaises(q.LQCPValidationError):
            q.quasi_static_ensemble_density(1, 1, samples=True, seed=1)

    def test_094_ramsey_density_trace_one(self):
        rho = q.quasi_static_ensemble_density(1, 2, samples=1000, seed=5)
        self.assertAlmostEqual(float(np.trace(rho).real), 1.0, places=12)

    def test_095_ramsey_density_positive(self):
        rho = q.quasi_static_ensemble_density(1, 2, samples=1000, seed=5)
        self.assertGreaterEqual(float(np.min(np.linalg.eigvalsh(rho).real)), -1e-12)

    # Demo and serializability
    @classmethod
    def setUpClass(cls):
        cls.demo = q.build_reference_demo()

    def test_096_demo_serializable(self):
        json.dumps(self.demo, sort_keys=True)

    def test_097_demo_historical_norm_inflation(self):
        self.assertAlmostEqual(self.demo["historical_rescale"]["norm_after"], math.sqrt(8), places=12)

    def test_098_demo_historical_probability_sum(self):
        self.assertAlmostEqual(self.demo["historical_rescale"]["probability_sum_after"], 8.0, places=12)

    def test_099_demo_basis_dependence(self):
        self.assertEqual(self.demo["basis_dependence"]["basis_state_l1"], 0.0)
        self.assertAlmostEqual(self.demo["basis_dependence"]["plus_state_l1"], 1.0, places=12)

    def test_100_demo_unitary_l1_preserved(self):
        section = self.demo["closed_unitary"]
        self.assertAlmostEqual(section["l1_before"], section["l1_after"], places=12)

    def test_101_demo_markovian_decay(self):
        section = self.demo["markovian_dephasing"]
        self.assertAlmostEqual(section["l1_after"], math.exp(-2.0), places=12)

    def test_102_demo_echo_one(self):
        self.assertAlmostEqual(self.demo["quasi_static_benchmark"]["echo_l1"], 1.0, places=12)

    def test_103_demo_ramsey_close_to_analytic(self):
        self.assertLess(self.demo["quasi_static_benchmark"]["ramsey_abs_error"], 0.004)

    def test_104_demo_echo_does_not_reverse_markovian(self):
        self.assertTrue(self.demo["quasi_static_benchmark"]["echo_does_not_reverse_markovian"])

    def test_105_demo_phase_fidelity_one(self):
        self.assertAlmostEqual(self.demo["global_phase_counterexample"]["fidelity"], 1.0, places=12)

    def test_106_demo_historical_phase_distance_nonzero(self):
        self.assertGreater(self.demo["global_phase_counterexample"]["historical_distance"], 0.0)

    def test_107_demo_limit_oscillates(self):
        values = [row["historical_distance"] for row in self.demo["long_time_limit_counterexample"]]
        self.assertAlmostEqual(values[0], 0.0, places=12)
        self.assertAlmostEqual(values[1], 4.0, places=12)
        self.assertAlmostEqual(values[2], 0.0, places=12)
        self.assertAlmostEqual(values[3], 4.0, places=12)

    def test_108_demo_claim_boundaries_present(self):
        self.assertGreaterEqual(len(self.demo["claim_boundary"]), 6)


if __name__ == "__main__":
    unittest.main(verbosity=2)
