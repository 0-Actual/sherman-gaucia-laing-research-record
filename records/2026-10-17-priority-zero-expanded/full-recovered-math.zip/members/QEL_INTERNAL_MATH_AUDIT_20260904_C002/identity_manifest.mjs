import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join, relative } from 'node:path';
import { fileURLToPath } from 'node:url';
import { sglp2, sha256, SGL_KAT_SUBJECT, SGL_KAT_PURPOSE, SGL_KAT_EXPECTED } from './laptop_review/wf020_core_original.mjs';
const root=fileURLToPath(new URL('.',import.meta.url));
if(sglp2(SGL_KAT_SUBJECT,SGL_KAT_PURPOSE)!==SGL_KAT_EXPECTED) throw Error('SGL Prime known-answer mismatch');
function files(dir){return readdirSync(dir,{withFileTypes:true}).flatMap(e=>e.name==='__pycache__'?[]:e.isDirectory()?files(join(dir,e.name)):[join(dir,e.name)]);}
function witness(path,purpose){const b=readFileSync(path);return {bytes:b.length,purpose,sgl_prime:sglp2(b,purpose),sha256_secondary:sha256(b)};}
if(process.argv[2]==='--witness'){
 console.log(JSON.stringify(witness(process.argv[3],'qel.math-audit.archive.v1'),null,2));
} else if(process.argv[2]==='--verify') {
 const manifest=JSON.parse(readFileSync(join(root,'MANIFEST.json'),'utf8'));
 for(const item of manifest.files){
   const actual=witness(join(root,item.path),item.purpose);
   if(JSON.stringify(actual)!==JSON.stringify(Object.fromEntries(Object.entries(item).filter(([k])=>k!=='path')))) throw Error('Identity mismatch: '+item.path);
 }
 console.log(JSON.stringify({sgl_known_answer:'PASS',verified_members:manifest.files.length,status:'PASS',owner_signature:'UNSIGNED'}));
} else {
 const members=files(root).filter(p=>relative(root,p)!=='MANIFEST.json').sort().map(path=>({path:relative(root,path),...witness(path,'qel.math-audit.member.v1')}));
 writeFileSync(join(root,'MANIFEST.json'),JSON.stringify({schema:'qel.math-audit.manifest.v1',cycle:'QEL-MATH-20260904-C002',sgl_known_answer:'PASS',identity_boundary:'UNKEYED_CONTENT_IDENTITY_NOT_OWNER_SIGNATURE',owner_signature:'UNSIGNED',files:members},null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify({sgl_known_answer:'PASS',members:members.length}));
}
