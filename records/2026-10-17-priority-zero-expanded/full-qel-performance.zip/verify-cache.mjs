import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {loadNumerics,here} from './load-numerics.mjs';import {validateCachedResult} from './result-cache.mjs';
const math=await loadNumerics(),label='v4-compact-a',run=path.join(here,'runs',label);
const predictionBytes=fs.readFileSync(path.join(run,'predictions.json')),execution=JSON.parse(fs.readFileSync(path.join(run,'execution.json')));
const record={key:'declared-key',set:'official',label,prediction_identity:math.hashBytes(predictionBytes,'qel-performance-result')};
const options={key:'declared-key',set:'official',predictionBytes,execution,hashBytes:math.hashBytes};
assert.equal(validateCachedResult(record,options),true);
const cases=[
 ['changed input/code/config key',{...options,key:'changed-key'},record],
 ['different dataset',{...options,set:'additional'},record],
 ['altered prediction bytes',{...options,predictionBytes:Buffer.concat([predictionBytes,Buffer.from(' ')])},record],
 ['incomplete execution',{...options,execution:{...execution,state:'RUNNING'}},record],
 ['wrong prediction count',{...options,execution:{...execution,scalar_predictions:191}},record],
 ['path outside run directory',options,{...record,label:'../outside'}]
];
for(const [name,args,value]of cases)assert.equal(validateCachedResult(value,args),false,name);
const report={utc:new Date().toISOString(),status:'PASS',valid_saved_result_accepted:true,rejected_cases:cases.map(c=>c[0]),
 scope:'Unsigned consistency and staleness checking for local cache; not an adversarial authenticity guarantee'};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n'),file=path.join(here,'cache-verification.json');fs.writeFileSync(file,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(file).equals(bytes));console.log(JSON.stringify(report));
