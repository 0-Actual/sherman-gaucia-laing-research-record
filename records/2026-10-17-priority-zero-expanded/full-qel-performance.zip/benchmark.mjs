// Four serial fresh processes in ABBA order; identical input/config/output work.
import fs from 'node:fs';
import path from 'node:path';
import {execFileSync} from 'node:child_process';
import assert from 'node:assert/strict';
import {here,root} from './load-numerics.mjs';
const version=process.argv[2];assert.match(version||'',/^[a-z0-9_-]+$/);
const plan=[['baseline',version+'-baseline-a'],['compact',version+'-compact-a'],['compact',version+'-compact-b'],['baseline',version+'-baseline-b']];
const contractPath=path.join(here,'benchmark-contract-'+version+'.json');
fs.writeFileSync(contractPath,JSON.stringify({utc:new Date().toISOString(),sequence:plan,
 input_set:'official',points_per_run:24,scalar_predictions_per_run:192,serial:true,child_timeout_ms:180000,
 old_space_mib:128,output_work:'Identical runner and saved records except implementation label and diagnostics metadata',
 target:'At least 20 percent lower median numerical elapsed time, exact matching predictions/parameters, no increase in maximum observed process RSS',
 limitations:'Live laptop; two runs per implementation; elapsed excludes process and module startup',reference_answers_used_for_optimization:false},null,2)+'\n',{flag:'wx',flush:true});
const records=[];
for(const [implementation,label]of plan){
 console.log(JSON.stringify({stage:'starting',implementation,label}));
 const output=execFileSync(process.execPath,['--max-old-space-size=128','--experimental-vm-modules',path.join(here,'run-efficient.mjs'),implementation,'official',label],
  {cwd:root,encoding:'utf8',timeout:180000,maxBuffer:2*1024*1024,windowsHide:true});
 console.log(output.trim());records.push(JSON.parse(fs.readFileSync(path.join(here,'runs',label,'execution.json'))));
}
const readPred=label=>JSON.parse(fs.readFileSync(path.join(here,'runs',label,'predictions.json')));
const strip=p=>p.rows.map(r=>({index:r.index,kpoint:r.kpoint,eigenvalues_ev:r.eigenvalues_ev,bands:r.bands,offset_ev:r.offset_ev,scale_ev:r.scale_ev,maximum_pair_overlap_squared:r.maximum_pair_overlap_squared,maximum_residual_ev:r.maximum_residual_ev}));
const expected=strip(readPred(plan[0][1]));for(const [,label] of plan.slice(1))assert.deepEqual(strip(readPred(label)),expected);
const summarize=kind=>{const rows=records.filter(r=>r.implementation===kind);return {runs:rows.length,
 median_numerical_ms:rows.reduce((s,r)=>s+r.numerical_elapsed_ms,0)/rows.length,
 median_cpu_ms:rows.reduce((s,r)=>s+r.numerical_cpu_microseconds.user+r.numerical_cpu_microseconds.system,0)/rows.length/1000,
 maximum_process_rss_kib:Math.max(...rows.map(r=>r.process_maximum_rss_kib)),maximum_sampled_rss_bytes:Math.max(...rows.map(r=>r.sampled_maximum_rss_bytes))};};
const baseline=summarize('baseline'),compact=summarize('compact');
const report={utc:new Date().toISOString(),status:'COMPLETED',records,baseline,compact,
 speedup:baseline.median_numerical_ms/compact.median_numerical_ms,elapsed_reduction_fraction:1-compact.median_numerical_ms/baseline.median_numerical_ms,
 cpu_reduction_fraction:1-compact.median_cpu_ms/baseline.median_cpu_ms,
 maximum_observed_rss_reduction_fraction:1-compact.maximum_process_rss_kib/baseline.maximum_process_rss_kib,
 all_192_energies_and_parameters_identical_in_all_four_runs:true,
 target_passed:compact.median_numerical_ms<=0.8*baseline.median_numerical_ms&&compact.maximum_process_rss_kib<=baseline.maximum_process_rss_kib};
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n'),file=path.join(here,'benchmark-results-'+version+'.json');fs.writeFileSync(file,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(file).equals(bytes));
console.log(JSON.stringify({...report,records:undefined}));
