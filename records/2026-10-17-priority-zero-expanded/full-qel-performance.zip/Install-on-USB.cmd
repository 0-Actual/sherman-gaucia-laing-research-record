@echo off
"./REDACTED_LOCAL_ROOT/QEL_Q7\Independent_Model_20260919\runtime\node.exe" "%~dp0install-on-usb.mjs"
pause
