// QEL efficient adjoint BFGS. Original update arithmetic; cached gate trigonometry.
import {validateH} from './baseline.mjs';
import {createObjective} from './cached-adjoint.mjs';
import {stateDiagnostics} from './q8-fast.mjs';
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const norm=a=>Math.sqrt(dot(a,a));
const identity=n=>Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>+(i===j)));
const wrap4pi=x=>((x+2*Math.PI)%(4*Math.PI)+4*Math.PI)%(4*Math.PI)-2*Math.PI;
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
function objectiveFor(H,mode){validateH(H);const shift=H.reduce((s,row,i)=>s+row[i][0],0)/8;const centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?shift:0),z[1]]));const obj=createObjective(centered,mode);return {...obj,shift,calls:()=>obj.counters().forward_circuits};}
export function refineBFGS(H,theta,config,mode='adjoint'){
 for(const key of ['gradient_tolerance','maximum_step_norm','armijo'])assert(Number.isFinite(config[key])&&config[key]>0,'Invalid '+key);
 assert(Number.isInteger(config.line_search_steps)&&config.line_search_steps>=1&&config.line_search_steps<=100,'Invalid line-search budget');
 assert(Array.isArray(theta)&&theta.length===18&&theta.every(Number.isFinite),'18 finite parameters required');
 assert(Number.isInteger(config.max_iterations)&&config.max_iterations>=1&&config.max_iterations<=600,'Invalid iteration budget');
 let x=theta.map(wrap4pi);const obj=objectiveFor(H,mode),N=x.length;
 let f=obj.objective(x),g=obj.gradient(x),B=identity(N),reason='iteration_budget',resets=0;
 const startE=f+obj.shift;let iterations=0;
 for(let iteration=0;iteration<config.max_iterations;iteration++){
  if(norm(g)<=config.gradient_tolerance){reason='gradient_tolerance';break;}
  let p=B.map(row=>-dot(row,g)),directional=dot(p,g);
  if(!Number.isFinite(directional)||directional>=-1e-20){B=identity(N);p=g.map(v=>-v);directional=-dot(g,g);resets++;}
  const pn=norm(p);if(pn>config.maximum_step_norm){p=p.map(v=>v*config.maximum_step_norm/pn);directional=dot(p,g);}
  let alpha=1,accepted=false,next=null,nf=NaN,backtracks=0;
  for(;backtracks<config.line_search_steps;backtracks++){next=x.map((v,i)=>v+alpha*p[i]);nf=obj.objective(next);if(Number.isFinite(nf)&&nf<=f+config.armijo*alpha*directional+1e-14){accepted=true;break;}alpha*=0.5;}
  if(!accepted){reason='line_search_exhausted';break;}
  const ng=obj.gradient(next),s=next.map((v,i)=>v-x[i]),y=ng.map((v,i)=>v-g[i]),ys=dot(y,s);
  if(ys>1e-12*norm(y)*Math.max(norm(s),1e-20)){
   const By=B.map(row=>dot(row,y)),factor=(1+dot(y,By)/ys)/ys;
   const updated=B.map((row,i)=>row.map((v,j)=>v+factor*s[i]*s[j]-(s[i]*By[j]+By[i]*s[j])/ys));
   if(updated.every(row=>row.every(Number.isFinite)))B=updated;else{B=identity(N);resets++;}
  }else{B=identity(N);resets++;}
  iterations++;
  x=next;f=nf;g=ng;
 }
 const state=stateDiagnostics(H,x);assert(state.energy_ev<=startE+1e-9,'Refinement increased energy');
 return {initial_energy_ev:startE,final_energy_ev:state.energy_ev,parameters:x,gradient:g,gradient_norm:norm(g),iterations,reason,history_retained:false,resets,objective_evaluations:obj.calls(),centering_shift_ev:obj.shift,work:obj.counters(),...state};
}
