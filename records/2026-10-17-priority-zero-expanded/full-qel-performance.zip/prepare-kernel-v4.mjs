import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {here,root} from './load-numerics.mjs';
const old=fs.readFileSync(path.join(root,'numerics/q8-fast.mjs'),'utf8');
const start=old.indexOf('export function refineBFGS('),end=old.indexOf('export function optimizeCandidate(');
assert.ok(start>=0&&end>start);let body=old.slice(start,end);
body=body.replace('const startE=f+obj.shift,history=[];','const startE=f+obj.shift;let iterations=0;')
 .replace(/history\.push\(\{iteration:iteration\+1,[^\n]+\);/,'iterations++;')
 .replace('iterations:history.length,reason,history,resets','iterations,reason,history_retained:false,resets');
assert.ok(!body.includes('history.push'));assert.ok(body.includes('iterations++'));
const header=`// QEL efficient adjoint BFGS. Original update arithmetic; cached gate trigonometry.
import {validateH} from './baseline.mjs';
import {createObjective} from './cached-adjoint.mjs';
import {stateDiagnostics} from './q8-fast.mjs';
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const norm=a=>Math.sqrt(dot(a,a));
const identity=n=>Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>+(i===j)));
const wrap4pi=x=>((x+2*Math.PI)%(4*Math.PI)+4*Math.PI)%(4*Math.PI)-2*Math.PI;
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
function objectiveFor(H,mode){validateH(H);const shift=H.reduce((s,row,i)=>s+row[i][0],0)/8;const centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?shift:0),z[1]]));const obj=createObjective(centered,mode);return {...obj,shift,calls:()=>obj.counters().forward_circuits};}
`;
fs.writeFileSync(path.join(here,'compact-bfgs.mjs'),header+body,{flush:true});
console.log('Prepared cached-adjoint candidate; original USB source unchanged.');
