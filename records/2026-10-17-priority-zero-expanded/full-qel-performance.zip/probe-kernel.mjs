import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
import {loadNumerics,here,original,assessment} from './load-numerics.mjs';
const math=await loadNumerics(),fixture=JSON.parse(fs.readFileSync(path.join(original,'inputs/hamiltonians_24x8x8.json')));
const saved=JSON.parse(fs.readFileSync(path.join(assessment,'vqd-full-v1/predictions.json'))),cases=[];
for(const [index,band]of [[3,6],[11,4],[11,7],[20,5]]){
 const H=fixture.rows[index].matrix_ev,offset=H.reduce((s,row,i)=>s+row[i][0]/8,0),centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?offset:0),z[1]]));
 const scale=Math.max(...centered.map(row=>row.reduce((s,z)=>s+Math.hypot(...z),0)));
 const states=saved.rows[index].bands.slice(0,band).map(b=>b.amplitudes);
 const penalized=centered.map((row,i)=>row.map((z,j)=>{let re=z[0]/scale,im=z[1]/scale;for(const state of states){const a=state[i],b=state[j];re+=4*(a[0]*b[0]+a[1]*b[1]);im+=4*(a[1]*b[0]-a[0]*b[1]);}return [re,im];}));
 const random=math.base.rng((math.config.seed+index*100003+band*1009)>>>0),theta=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
 cases.push({H:penalized,theta});
}
const rounds=[];let reference=null;
for(const variant of ['baseline','compact','compact','baseline']){
 const begin=performance.now(),outputs=cases.map(c=>(variant==='baseline'?math.old:math.compact).refineBFGS(c.H,c.theta,math.config.bfgs));
 const elapsed=performance.now()-begin,normalized=outputs.map(o=>({energy:o.energy_ev,parameters:Array.from(o.parameters),iterations:o.iterations,reason:o.reason}));
 if(reference===null)reference=normalized;else assert.deepEqual(normalized,reference);
 rounds.push({variant,elapsed_ms:elapsed,iterations:outputs.map(o=>o.iterations)});
}
const mean=v=>rounds.filter(r=>r.variant===v).reduce((s,r)=>s+r.elapsed_ms,0)/2;
const report={utc:new Date().toISOString(),rounds,speedup:mean('baseline')/mean('compact'),identical:true,candidate_identity:math.candidate_identity};
const label=process.argv[2];assert.match(label||'',/^[a-z0-9_-]+$/);fs.writeFileSync(path.join(here,label+'.json'),JSON.stringify(report,null,2)+'\n',{flag:'wx',flush:true});console.log(JSON.stringify(report));
