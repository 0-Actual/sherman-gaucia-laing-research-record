import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {spawnSync} from 'node:child_process';
import {here,assessment} from './load-numerics.mjs';
const cache=JSON.parse(fs.readFileSync(path.join(here,'cache/additional.json')));
const fresh=JSON.parse(fs.readFileSync(path.join(here,'runs',cache.label,'predictions.json')));
const old=JSON.parse(fs.readFileSync(path.join(assessment,'vqd-additional-v1/predictions.json')));
const fields=p=>p.rows.map(r=>({index:r.index,kpoint:r.kpoint,eigenvalues_ev:r.eigenvalues_ev,bands:r.bands}));
assert.deepEqual(fields(fresh),fields(old));
const lock=path.join(here,'ACTIVE.lock'),sentinel=Buffer.from('Concurrency verification sentinel; not a running calculation.\n');
fs.writeFileSync(lock,sentinel,{flag:'wx',flush:true});let rejected=false;
try{
 const child=spawnSync(process.execPath,['--max-old-space-size=128','--experimental-vm-modules',path.join(here,'launch-efficient.mjs'),'additional'],{cwd:here,encoding:'utf8',timeout:10000,windowsHide:true});
 assert.equal(child.status,1);assert.match(child.stderr,/EEXIST/);assert.ok(fs.readFileSync(lock).equals(sentinel));rejected=true;
}finally{assert.ok(fs.readFileSync(lock).equals(sentinel));fs.unlinkSync(lock);}
const reuse=spawnSync(process.execPath,['--max-old-space-size=128','--experimental-vm-modules',path.join(here,'launch-efficient.mjs'),'additional'],{cwd:here,encoding:'utf8',timeout:10000,windowsHide:true});
assert.equal(reuse.status,0,reuse.stderr);const receipt=JSON.parse(reuse.stdout);
assert.equal(receipt.status,'REUSED_VERIFIED_RESULT');assert.equal(receipt.new_optimization,false);
assert.equal(receipt.output_directory,path.join(here,'runs',cache.label));assert.equal(fs.existsSync(lock),false);
const result={utc:new Date().toISOString(),status:'PASS',additional_192_values_and_parameters_identical_to_prior_run:true,
 active_lock_rejected_without_modification:rejected,repeat_request:receipt,lock_released:true};
const label=process.argv[2]||'launcher-verification';assert.match(label,/^[a-z0-9_-]+$/);
const bytes=Buffer.from(JSON.stringify(result,null,2)+'\n'),file=path.join(here,label+'.json');fs.writeFileSync(file,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(file).equals(bytes));console.log(JSON.stringify(result));
