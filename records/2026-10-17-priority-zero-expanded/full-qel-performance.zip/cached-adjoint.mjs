// Same Q8 gate order/adjoint derivatives; reuse trigonometry for reverse gates.
import {validateH} from './baseline.mjs';
import {layout} from './q8-adjoint.mjs';
function angles(theta){if(theta.length!==18)throw Error('18 finite angles required');for(let i=0;i<18;i++)if(!Number.isFinite(theta[i]))throw Error('18 finite angles required');}
export function createObjective(H,mode='adjoint'){
 validateH(H);if(mode!=='adjoint')throw Error('Cached objective supports adjoint derivatives');
 const h=new Float64Array(128),psi=new Float64Array(16),lambda=new Float64Array(16),phi=new Float64Array(16);
 const cosine=new Float64Array(18),sine=new Float64Array(18);
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){h[2*(8*i+j)]=H[i][j][0];h[2*(8*i+j)+1]=H[i][j][1];}
 let cached=null,value=0,grad=null,objectiveCalls=0,gradientCalls=0,forwards=0,reverseGates=0,trigEvaluations=0;
 function apply(v,g,inverse=false){
  if(g.kind==='CNOT'){for(let i=0;i<8;i++)if((i&g.control)&&!(i&g.mask)){const a=2*i,b=2*(i|g.mask),re=v[a],im=v[a+1];v[a]=v[b];v[a+1]=v[b+1];v[b]=re;v[b+1]=im;}return;}
  const c=cosine[g.parameter],s=inverse?-sine[g.parameter]:sine[g.parameter];
  if(g.kind==='RY'){for(let i=0;i<8;i++)if(!(i&g.mask)){const a=2*i,b=2*(i|g.mask),ar=v[a],ai=v[a+1],br=v[b],bi=v[b+1];v[a]=c*ar-s*br;v[a+1]=c*ai-s*bi;v[b]=s*ar+c*br;v[b+1]=s*ai+c*bi;}}
  else if(g.kind==='RZ'){for(let i=0;i<8;i++){const a=2*i,t=i&g.mask?s:-s,re=v[a],im=v[a+1];v[a]=c*re-t*im;v[a+1]=t*re+c*im;}}
 }
 function evaluate(theta){
  angles(theta);if(cached&&cached.every((x,i)=>x===theta[i]))return value;
  for(let i=0;i<18;i++){cosine[i]=Math.cos(theta[i]/2);sine[i]=Math.sin(theta[i]/2);}trigEvaluations+=36;
  psi.fill(0);psi[0]=1;for(const g of layout)apply(psi,g);forwards++;
  for(let i=0;i<8;i++){let re=0,im=0;for(let j=0;j<8;j++){const k=2*(8*i+j),a=2*j;re+=h[k]*psi[a]-h[k+1]*psi[a+1];im+=h[k]*psi[a+1]+h[k+1]*psi[a];}lambda[2*i]=re;lambda[2*i+1]=im;}
  value=0;let imag=0;for(let i=0;i<16;i+=2){value+=psi[i]*lambda[i]+psi[i+1]*lambda[i+1];imag+=psi[i]*lambda[i+1]-psi[i+1]*lambda[i];}
  if(!Number.isFinite(value)||Math.abs(imag)>1e-9)throw Error('Nonfinite expectation');cached=Array.from(theta);grad=null;return value;
 }
 function gradient(theta){
  gradientCalls++;evaluate(theta);if(grad)return grad.slice();grad=new Array(18).fill(0);phi.set(psi);
  for(let k=layout.length-1;k>=0;k--){const g=layout[k];let sum=0;
   if(g.kind==='RY'){for(let i=0;i<8;i++)if(!(i&g.mask)){const a=2*i,b=2*(i|g.mask);sum+=-lambda[a]*phi[b]-lambda[a+1]*phi[b+1]+lambda[b]*phi[a]+lambda[b+1]*phi[a+1];}grad[g.parameter]=sum;}
   if(g.kind==='RZ'){for(let i=0;i<8;i++){const a=2*i,sign=i&g.mask?1:-1;sum+=sign*(lambda[a+1]*phi[a]-lambda[a]*phi[a+1]);}grad[g.parameter]=sum;}
   apply(phi,g,true);apply(lambda,g,true);reverseGates+=2;
  }
  if(!grad.every(Number.isFinite))throw Error('Nonfinite derivative');return grad.slice();
 }
 return {objective:theta=>{objectiveCalls++;return evaluate(theta);},gradient,
 state:theta=>{evaluate(theta);return Array.from({length:8},(_,i)=>[psi[2*i],psi[2*i+1]]);},
 counters:()=>({objective_calls:objectiveCalls,gradient_calls:gradientCalls,forward_circuits:forwards,reverse_gate_applications:reverseGates,
 state_workspace_bytes:psi.byteLength+lambda.byteLength+phi.byteLength,trigonometry_cache_bytes:cosine.byteLength+sine.byteLength,
 trigonometry_evaluations:trigEvaluations,hamiltonian_bytes:h.byteLength,mode})};
}
