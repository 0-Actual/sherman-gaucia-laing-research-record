# QEL laptop workload performance upgrade

This implements a measured improvement in the existing JARVIS circuit calculations on this laptop. Desktop Commander is not required. The existing USB engine, scientific inputs and fitted answers are preserved.

## Measured advantage

Audit update, September 28 late evening: an independent arithmetic and state-reconstruction review confirmed the saved results. A fresh four-run old/new/new/old repetition measured **18.522 to 16.050 seconds (13.3% less calculation time)**, **13.1% less CPU time**, and **26.6% lower maximum observed process peak memory**, again with exact agreement of all 192 energies and fitted parameters. The two controlled batches therefore show observed time reductions of **13.3% and 17.1%**, not a guaranteed fixed percentage. Both missed the predeclared 20% time target. See the bundled `benchmark-results-audit-v1.json`. The full audit remains in the laptop task's `outputs/governance-output-audit` folder. The original batch is preserved below.

Four fresh processes ran the same 24-point, 192-energy workload in old/new/new/old order, with the same starting values and iteration limits.

| Measurement | Previous solver | Improved solver | Change |
| --- | ---: | ---: | ---: |
| Median calculation time | 17.870 seconds | 14.807 seconds | 17.1% less time |
| Median process CPU time | 18.852 seconds | 15.852 seconds | 15.9% less CPU time |
| Largest observed process peak memory | 91.1 MiB | 66.7 MiB | 26.8% less memory |

All 192 energies, fitted angles, optimization attempts, stopping reasons and state diagnostics matched exactly across the four runs. The additional 24-point/192-energy dataset also matched the prior results exactly. This is an improvement to the same useful calculation, with no replacement by classical reference answers or reduced iteration budgets.

The improvement caches each circuit angle's sine and cosine for reuse in the reverse derivative calculation, and stops retaining unused per-iteration history. The original BFGS matrix update and Q8 circuit order remain. Final results still pass through the unchanged USB SOP engine and separate dense calculation.

The initial goal of 20% less calculation time was missed in both batches. Each batch has two runs per version on a live laptop and provides bounded evidence, not a general Windows speed rating. The timings exclude process/module startup. Process memory includes the runtime but is not the computer's total RAM. Existing apps remained open. CPU time may exceed elapsed time because runtime threads also consume CPU.

Earlier attempts are preserved: the first allocation rewrite reduced memory but increased time by 52%, and two focused variants remained slower. They were not selected for installation. `benchmark-results.json` records that failed first candidate; `benchmark-results-v4.json` records the selected implementation.

## Normal use

Open **Run-QEL-JARVIS.cmd** in this folder. It runs the original aluminum benchmark with the improved method and the existing USB engine. It reports whether it computed new results or reused a verified saved result, the elapsed time, and the result folder. The USB must remain connected as drive D:.

Current installation status: the requested write grant for `./REDACTED_LOCAL_ROOT/Q8\Performance_20260928` returned no access grant. The working upgrade therefore remains in this laptop folder. The prepared **Install-on-USB.cmd** adds sixteen declared payload files, including both benchmark summaries, to that new USB folder, verifies a complete fresh calculation and saved-result reuse, and records the result in `installation-receipt.json`. It refuses to overwrite an existing installation. The installer's preparation check passed; installation itself has not been performed by the assistant. The owner's latest direction puts the output audit before returning to permissions/installation. After a successful installation, use **Run-QEL-JARVIS.cmd** in that USB folder.

An unchanged request can reuse its existing answer. The verified single-process launcher replay took 0.062 seconds after entry-point startup, versus 16.804 seconds for its preceding fresh additional-data run. This is saved-result reuse, not a new calculation or a claim that fresh calculations became hundreds of times faster.

The reuse key includes the input, optimizer settings, runtime version and relevant implementation files. Predictions must retain their recorded content identity, complete point ordering and execution receipt. Changed data/code, damaged output or unfinished work cause a fresh calculation. This is local consistency checking, not a cryptographic owner signature or protection against an adversary able to alter all records.

For a deliberately fresh calculation, run the command with `--fresh`. For the additional aluminum points, use `additional`. These runs cover the existing aluminum data; support for arbitrary materials has not been claimed.

The launcher allows one job in its folder at a time, requests below-normal process priority, uses a 128 MiB old-space limit and retains the solver's 180-second work budget checked between bounded optimization starts. It uses one process for normal calculations. It does not start the old lab/controller, remove security holds, alter Windows protections or require Desktop Commander. An interrupted job can leave `ACTIVE.lock`; it is deliberately not silently discarded.

## Verification and files

- `kernel-verification-v4.json`: twelve direct-kernel comparisons, exactly matching outputs; malformed inputs rejected.
- `benchmark-results-v4.json`: complete matched timing, CPU, memory and equality results.
- `cache-verification.json`: valid result accepted; six stale, corrupt, incomplete or invalid cases rejected.
- `launcher-verification*.json`: complete additional-data comparison, concurrent-job refusal, preserved lock and successful result reuse.
- `compact-bfgs.mjs` and `cached-adjoint.mjs`: selected numerical implementation.
- `source-lock.json` and `vqd-source-original.mjs`: pinned USB-source identities/configuration and preserved original full-spectrum method.
- `runs/`, `cache/`, `receipts/`: results, reusable-result records and actual operation receipts.

The runtime remains `./REDACTED_LOCAL_ROOT/QEL_Q7\Independent_Model_20260919\runtime\node.exe`. Numerical dependencies remain under `./REDACTED_LOCAL_ROOT/QEL_Q7\Q8_Testing_Space\JARVIS_Private_20260920_04`; the existing original aluminum input remains in the corresponding `_01` directory. The prepared package supplies its own extra fixture and requires no C: task files during installed operation. New files are additive; original USB source is unchanged.

Installation and a run from the actual USB destination are recorded separately in `installation-receipt.json` when verified. Do not infer installation merely from this guide or a package filename. Work is PRIVATE / UNSIGNED, with no GitHub publication, paid service or new cloud computation.
