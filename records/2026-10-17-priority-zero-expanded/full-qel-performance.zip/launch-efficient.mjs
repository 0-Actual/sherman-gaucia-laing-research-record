// User entry point: bounded fresh work, one job at a time, validated result reuse.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import assert from 'node:assert/strict';
import {loadNumerics,here,original} from './load-numerics.mjs';import {readCache} from './result-cache.mjs';
import {runWork} from './run-efficient.mjs';
const start=performance.now(),args=process.argv.slice(2),set=args.find(a=>!a.startsWith('--'))||'official';
assert.ok(['official','additional'].includes(set));assert.ok(args.every(a=>['official','additional','--fresh','--friendly'].includes(a)));
const lock=path.join(here,'ACTIVE.lock');
fs.writeFileSync(lock,JSON.stringify({pid:process.pid,utc:new Date().toISOString()})+'\n',{flag:'wx',flush:true});
try{
 const math=await loadNumerics();
 const fixture=set==='official'?path.join(original,'inputs/hamiltonians_24x8x8.json'):path.join(here,'inputs/additional-hamiltonians.json');
 const codeNames=['compact-bfgs.mjs','cached-adjoint.mjs','load-numerics.mjs','run-efficient.mjs','vqd-source-original.mjs','source-lock.json'];
 const identityParts=[math.hashBytes(fs.readFileSync(fixture),'qel-performance-input'),JSON.stringify(math.config),process.version,
  ...codeNames.map(name=>math.hashBytes(fs.readFileSync(path.join(here,name)),'qel-performance-code'))];
 const key=math.hashBytes(Buffer.from(identityParts.join('\n')),'qel-performance-cache-key');
 const cached=args.includes('--fresh')?null:readCache(here,{key,set,hashBytes:math.hashBytes});
 let result;
 if(cached){
  result={utc:new Date().toISOString(),status:'REUSED_VERIFIED_RESULT',set,scalar_predictions:192,elapsed_ms:performance.now()-start,
   output_directory:cached.run,new_optimization:false,cache_key:key};
 }else{
  let priority='unchanged';try{os.setPriority(0,os.constants.priority.PRIORITY_BELOW_NORMAL);priority=os.getPriority(0);}catch{}
  const label=(new Date().toISOString().replace(/[:.]/g,'-')+'-'+process.pid).toLowerCase();
  await runWork('compact',set,label,math);
  const run=path.join(here,'runs',label),predictionBytes=fs.readFileSync(path.join(run,'predictions.json'));
  const record={utc:new Date().toISOString(),key,set,label,prediction_identity:math.hashBytes(predictionBytes,'qel-performance-result')};
  fs.mkdirSync(path.join(here,'cache'),{recursive:true});
  const dest=path.join(here,'cache',set+'.json'),temporary=dest+'.'+process.pid+'.tmp';
  fs.writeFileSync(temporary,JSON.stringify(record,null,2)+'\n',{flag:'wx',flush:true});fs.renameSync(temporary,dest);
  assert.ok(readCache(here,{key,set,hashBytes:math.hashBytes}),'Fresh output did not pass cache validation');
  result={utc:new Date().toISOString(),status:'COMPUTED_AND_VERIFIED',set,scalar_predictions:192,elapsed_ms:performance.now()-start,
   output_directory:run,new_optimization:true,priority,cache_key:key};
 }
 math.verifySources();
 fs.mkdirSync(path.join(here,'receipts'),{recursive:true});
 const receipt=path.join(here,'receipts',(new Date().toISOString().replace(/[:.]/g,'-')+'-'+process.pid+'.json').toLowerCase());
 const bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');fs.writeFileSync(receipt,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(receipt).equals(bytes));
 if(args.includes('--friendly')){
  console.log(result.new_optimization?'QEL JARVIS calculation completed.':'QEL JARVIS reused the verified saved result.');
  console.log('192 energy values. Elapsed time: '+(result.elapsed_ms/1000).toFixed(2)+' seconds.');
  console.log('Results: '+result.output_directory);
 }else console.log(JSON.stringify(result));
}finally{fs.unlinkSync(lock);}
