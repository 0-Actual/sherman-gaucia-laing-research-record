// Cache verified results only for exactly matching inputs, configuration and code.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
export function validateCachedResult(record,{key,set,predictionBytes,execution,hashBytes}){
 try{
  assert.equal(record.key,key);assert.equal(record.set,set);assert.match(record.label,/^[a-z0-9_-]{1,60}$/);
  assert.equal(record.prediction_identity,hashBytes(predictionBytes,'qel-performance-result'));
  assert.equal(execution.state,'PREDICTIONS_FROZEN');assert.equal(execution.implementation,'compact');assert.equal(execution.set,set);
  assert.equal(execution.scalar_predictions,192);
  const pred=JSON.parse(predictionBytes);assert.equal(pred.material,'JVASP-816');assert.equal(pred.units,'eV');
  assert.equal(pred.implementation,'compact');assert.equal(pred.set,set);assert.equal(pred.rows.length,24);
  for(const [i,row]of pred.rows.entries()){
   assert.equal(row.index,i);assert.equal(row.eigenvalues_ev.length,8);assert.ok(row.eigenvalues_ev.every(Number.isFinite));
   assert.equal(row.bands.length,8);for(let j=1;j<8;j++)assert.ok(row.eigenvalues_ev[j]>=row.eigenvalues_ev[j-1]);
  }
  return true;
 }catch{return false;}
}
export function readCache(directory,{key,set,hashBytes}){
 try{
  const record=JSON.parse(fs.readFileSync(path.join(directory,'cache',set+'.json')));
  assert.match(record.label,/^[a-z0-9_-]{1,60}$/);
  const run=path.join(directory,'runs',record.label),predictionBytes=fs.readFileSync(path.join(run,'predictions.json'));
  const execution=JSON.parse(fs.readFileSync(path.join(run,'execution.json')));
  return validateCachedResult(record,{key,set,predictionBytes,execution,hashBytes})?{record,run}:null;
 }catch{return null;}
}
