// Run by the owner to add the verified package to its declared USB destination.
// --check-only validates preparation and makes no USB changes.
// --copy-only installs and verifies bytes without starting deferred JARVIS work.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {execFileSync} from 'node:child_process';
const here=path.dirname(fileURLToPath(import.meta.url));
const manifest=JSON.parse(fs.readFileSync(path.join(here,'package-manifest.json')));
const destination=path.resolve('./REDACTED_LOCAL_ROOT/Q8/Performance_20260928');
assert.equal(path.resolve(manifest.destination),destination);
const options=process.argv.slice(2);
assert.ok(options.every(a=>['--check-only','--copy-only'].includes(a)));
assert.equal(new Set(options).size,options.length,'Duplicate options refused');
const copyOnly=options.includes('--copy-only');
const prefix=destination.toLowerCase()+path.sep;
assert.equal(manifest.files.length,manifest.file_count);
assert.equal(manifest.file_count,16);
const names=new Set(),payload=[];
for(const entry of manifest.files){
 assert.ok(!path.isAbsolute(entry.relative_path)&&!entry.relative_path.split(/[\\/]/).includes('..'));
 const target=path.resolve(destination,entry.relative_path);
 assert.ok(target.toLowerCase().startsWith(prefix));
 assert.ok(!names.has(target.toLowerCase()));names.add(target.toLowerCase());
 const bytes=fs.readFileSync(path.join(here,entry.relative_path));
 assert.equal(bytes.length,entry.bytes,'Package size changed: '+entry.relative_path);
 payload.push({target,bytes,name:entry.relative_path});
}
assert.equal(payload.reduce((total,entry)=>total+entry.bytes.length,0),manifest.total_bytes);
const expected=JSON.parse(fs.readFileSync(path.join(here,'runs/v4-baseline-a/predictions.json')));
const comparable=p=>p.rows.map(r=>({index:r.index,kpoint:r.kpoint,eigenvalues_ev:r.eigenvalues_ev,bands:r.bands,offset_ev:r.offset_ev,scale_ev:r.scale_ev,maximum_pair_overlap_squared:r.maximum_pair_overlap_squared,maximum_residual_ev:r.maximum_residual_ev}));
const statusFile='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_04/LIVE_STATUS.json';
const originalStatus=fs.readFileSync(statusFile);
assert.equal(JSON.parse(originalStatus).numerical_work_active,false,'Original controller must remain paused');
assert.equal(JSON.parse(originalStatus).phase,'OWNER_PAUSED_FOR_SECURITY');
if(process.argv.includes('--check-only')){
 console.log(JSON.stringify({state:'PREPARATION_CHECKED',files:payload.length,bytes:manifest.total_bytes,destination,destination_exists:fs.existsSync(destination),usb_changes:false,requested_installation_mode:copyOnly?'COPY_AND_BYTE_VERIFY_ONLY':'COPY_AND_RUN_CALCULATION'}));
 process.exit(0);
}
assert.ok(!fs.existsSync(destination),'Destination already exists; preserve it and review before installing');
fs.mkdirSync(destination,{recursive:true});
const receipt={utc:new Date().toISOString(),state:'INSTALLING',destination,payload_files:payload.length,publication:false};
const saveReceipt=()=>{
 const bytes=Buffer.from(JSON.stringify(receipt,null,2)+'\n');
 for(const folder of [here,destination]){
  const output=path.join(folder,'installation-receipt.json');
  fs.writeFileSync(output,bytes,{flush:true});assert.ok(fs.readFileSync(output).equals(bytes));
 }
};
try{
 for(const entry of payload){
  fs.mkdirSync(path.dirname(entry.target),{recursive:true});
  fs.writeFileSync(entry.target,entry.bytes,{flag:'wx',flush:true});
  assert.ok(fs.readFileSync(entry.target).equals(entry.bytes));
 }
 if(copyOnly){
  for(const entry of payload)assert.ok(fs.readFileSync(entry.target).equals(entry.bytes));
  assert.ok(fs.readFileSync(statusFile).equals(originalStatus));
  Object.assign(receipt,{state:'INSTALLED_BYTE_VERIFIED_CALCULATION_DEFERRED',completed_utc:new Date().toISOString(),payload_byte_verified:true,original_controller_status_unchanged:true,calculation_started:false,installed_runtime_tested:false,reason:'Owner prioritizes laptop and USB installation; JARVIS tests remain deferred.'});
  saveReceipt();
  console.log('USB files installed and byte-verified. No JARVIS calculation or new training was started.');
  process.exit(0);
 }
 const invoke=args=>JSON.parse(execFileSync(process.execPath,['--max-old-space-size=128','--experimental-vm-modules',path.join(destination,'launch-efficient.mjs'),...args],{cwd:destination,windowsHide:true,encoding:'utf8',timeout:180000,maxBuffer:2*1024*1024}));
 console.log('Files installed. Verifying one fresh USB calculation.');
 const fresh=invoke(['official','--fresh']);
 assert.equal(fresh.status,'COMPUTED_AND_VERIFIED');
 const actual=JSON.parse(fs.readFileSync(path.join(fresh.output_directory,'predictions.json')));
 assert.deepEqual(comparable(actual),comparable(expected));
 const reused=invoke(['official']);
 assert.equal(reused.status,'REUSED_VERIFIED_RESULT');
 assert.equal(reused.output_directory,fresh.output_directory);
 for(const entry of payload)assert.ok(fs.readFileSync(entry.target).equals(entry.bytes));
 assert.ok(fs.readFileSync(statusFile).equals(originalStatus));
 Object.assign(receipt,{state:'INSTALLED_AND_VERIFIED',completed_utc:new Date().toISOString(),payload_byte_verified:true,all_192_energies_and_parameters_match:true,original_controller_status_unchanged:true,fresh,reused});
 saveReceipt();
 console.log('Installation verified. Open '+path.join(destination,'Run-QEL-JARVIS.cmd')+' for normal use.');
}catch(error){
 Object.assign(receipt,{state:'INCOMPLETE_REVIEW_REQUIRED',message:error.message});saveReceipt();throw error;
}
