@echo off
"./REDACTED_LOCAL_ROOT/QEL_Q7\Independent_Model_20260919\runtime\node.exe" --max-old-space-size=128 --experimental-vm-modules "%~dp0launch-efficient.mjs" --friendly %*
pause
