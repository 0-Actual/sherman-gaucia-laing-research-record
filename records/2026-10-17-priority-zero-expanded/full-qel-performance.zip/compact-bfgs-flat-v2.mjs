// QEL performance upgrade: same adjoint BFGS arithmetic, bounded reusable workspace.
// Existing USB objective and final SOP/dense validation remain authoritative.
import {validateH} from './baseline.mjs';
import {createObjective} from './q8-adjoint.mjs';
import {stateDiagnostics} from './q8-fast.mjs';
const N=18;
const wrap=x=>((x+2*Math.PI)%(4*Math.PI)+4*Math.PI)%(4*Math.PI)-2*Math.PI;
const dot=(a,b)=>{let v=0;for(let i=0;i<N;i++)v+=a[i]*b[i];return v;};
const norm=a=>Math.sqrt(dot(a,a));
function identity(B){B.fill(0);for(let i=0;i<N;i++)B[N*i+i]=1;}
export function refineBFGS(H,theta,config,mode='adjoint'){
 if(!Array.isArray(theta)||theta.length!==N||!theta.every(Number.isFinite))throw Error('18 finite parameters required');
 if(!Number.isInteger(config.max_iterations)||config.max_iterations<1||config.max_iterations>600)throw Error('Invalid iteration budget');
 for(const key of ['gradient_tolerance','maximum_step_norm','armijo'])if(!Number.isFinite(config[key])||config[key]<=0)throw Error('Invalid '+key);
 if(!Number.isInteger(config.line_search_steps)||config.line_search_steps<1||config.line_search_steps>100)throw Error('Invalid line-search budget');
 validateH(H);
 const shift=H.reduce((s,row,i)=>s+row[i][0],0)/8;
 const centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?shift:0),z[1]]));
 const workspace=n=>new Array(n).fill(NaN).fill(0);
 const obj=createObjective(centered,mode),B=workspace(N*N);
 const p=workspace(N),s=workspace(N),y=workspace(N),By=workspace(N);
 let x=theta.map(wrap),next=new Array(N).fill(0),f=obj.objective(x),g=obj.gradient(x);
 let reason='iteration_budget',resets=0,iterations=0,totalBacktracks=0;
 identity(B);const startE=f+shift;
 for(let iteration=0;iteration<config.max_iterations;iteration++){
  if(norm(g)<=config.gradient_tolerance){reason='gradient_tolerance';break;}
  for(let i=0;i<N;i++){let v=0;for(let j=0;j<N;j++)v+=B[N*i+j]*g[j];p[i]=-v;}
  let directional=dot(p,g);
  if(!Number.isFinite(directional)||directional>=-1e-20){identity(B);for(let i=0;i<N;i++)p[i]=-g[i];directional=-dot(g,g);resets++;}
  const pn=norm(p);
  if(pn>config.maximum_step_norm){for(let i=0;i<N;i++)p[i]=p[i]*config.maximum_step_norm/pn;directional=dot(p,g);}
  let alpha=1,accepted=false,nf=NaN,backtracks=0;
  for(;backtracks<config.line_search_steps;backtracks++){
   for(let i=0;i<N;i++)next[i]=x[i]+alpha*p[i];
   nf=obj.objective(next);
   if(Number.isFinite(nf)&&nf<=f+config.armijo*alpha*directional+1e-14){accepted=true;break;}
   alpha*=0.5;
  }
  if(!accepted){reason='line_search_exhausted';break;}
  const ng=obj.gradient(next);
  for(let i=0;i<N;i++){s[i]=next[i]-x[i];y[i]=ng[i]-g[i];}
  const ys=dot(y,s);
  if(ys>1e-12*norm(y)*Math.max(norm(s),1e-20)){
   for(let i=0;i<N;i++){let v=0;for(let j=0;j<N;j++)v+=B[N*i+j]*y[j];By[i]=v;}
   const factor=(1+dot(y,By)/ys)/ys;let finite=true;
   for(let i=0;i<N;i++)for(let j=0;j<N;j++){
    const k=N*i+j,value=B[k]+factor*s[i]*s[j]-(s[i]*By[j]+By[i]*s[j])/ys;
    B[k]=value;if(!Number.isFinite(value))finite=false;
   }
   if(!finite){identity(B);resets++;}
  }else{identity(B);resets++;}
  iterations++;totalBacktracks+=backtracks;
  const prior=x;x=next;next=prior;f=nf;g=ng;
 }
 const state=stateDiagnostics(H,x);
 if(!(state.energy_ev<=startE+1e-9))throw Error('Refinement increased energy');
 return {initial_energy_ev:startE,final_energy_ev:state.energy_ev,parameters:x.slice(),gradient:g.slice(),gradient_norm:norm(g),
  iterations,reason,resets,objective_evaluations:obj.counters().forward_circuits,centering_shift_ev:shift,work:obj.counters(),
  diagnostics:{iteration_history_retained:false,total_backtracks:totalBacktracks,reused_optimizer_numeric_payload_bytes:8*(B.length+p.length+s.length+y.length+By.length)},...state};
}
