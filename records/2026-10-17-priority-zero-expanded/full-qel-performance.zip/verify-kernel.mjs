import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {loadNumerics,here,original,assessment} from './load-numerics.mjs';
const math=await loadNumerics();
const fixture=JSON.parse(fs.readFileSync(path.join(original,'inputs/hamiltonians_24x8x8.json')));
const additional=JSON.parse(fs.readFileSync(path.join(assessment,'additional-data/hamiltonians_24x8x8.json')));
const cases=[...fixture.rows.filter((_,i)=>[0,3,6,11,17,23].includes(i)),...additional.rows.filter((_,i)=>[0,3,5,11,17,23].includes(i))];
const result=[];let largest=0;
for(const [index,row]of cases.entries()){
 const random=math.base.rng((2026092907+index*97)>>>0),theta=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
 const a=math.old.refineBFGS(row.matrix_ev,theta,math.config.bfgs,'adjoint');
 const b=math.compact.refineBFGS(row.matrix_ev,theta,math.config.bfgs,'adjoint');
 const delta=Math.max(...a.parameters.map((v,i)=>Math.abs(v-b.parameters[i])));largest=Math.max(largest,delta);
 assert.equal(a.energy_ev,b.energy_ev);assert.deepEqual(Array.from(a.parameters),Array.from(b.parameters));
 assert.equal(a.iterations,b.iterations);assert.equal(a.reason,b.reason);assert.equal(a.objective_evaluations,b.objective_evaluations);
 assert.equal(a.gradient_norm,b.gradient_norm);assert.equal(a.resets,b.resets);
 result.push({case:index,energy_ev:b.energy_ev,iterations:b.iterations,parameter_difference:delta,identical:true});
}
const bad=[];
for(const [name,args]of [
 ['invalid angles',[fixture.rows[0].matrix_ev,[NaN],math.config.bfgs]],
 ['zero iterations',[fixture.rows[0].matrix_ev,new Array(18).fill(0),{...math.config.bfgs,max_iterations:0}]],
 ['nonfinite step',[fixture.rows[0].matrix_ev,new Array(18).fill(0),{...math.config.bfgs,maximum_step_norm:Infinity}]],
 ['invalid matrix',[[[]],new Array(18).fill(0),math.config.bfgs]]
]){assert.throws(()=>math.compact.refineBFGS(...args));bad.push(name);}
math.verifySources();
const report={utc:new Date().toISOString(),status:'PASS',cases:result,largest_parameter_difference:largest,
 invalid_inputs_rejected:bad,same_arithmetic_results:true,usb_sources_unchanged:true,candidate_identity:math.candidate_identity};
const label=process.argv[2]||'kernel-verification';assert.match(label,/^[a-z0-9_-]+$/);
const bytes=Buffer.from(JSON.stringify(report,null,2)+'\n'),dest=path.join(here,label+'.json');
fs.writeFileSync(dest,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(dest).equals(bytes));
console.log(JSON.stringify({...report,cases:result.length}));
