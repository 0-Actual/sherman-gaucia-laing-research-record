import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
export const here=path.dirname(fileURLToPath(import.meta.url));
export const root='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_04';
export const original='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_01';
export const assessment=path.resolve(here,'../jarvis-assessment');
export async function loadNumerics(){
 const {hashBytes}=await import(pathToFileURL(path.join(root,'control/vendor/sgl-prime.mjs')));
 const contract=JSON.parse(fs.readFileSync(path.join(here,'source-lock.json')));
 const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}}),cache=new Map(),sources=[];
 for(const entry of contract.sources){
  const file=path.join(root,'numerics',entry.name),bytes=fs.readFileSync(file);
  assert.equal(hashBytes(bytes,'qel-jarvis-source'),entry.identity,'USB numerical source changed: '+entry.name);
  sources.push({file,bytes});cache.set(entry.name,new vm.SourceTextModule(bytes.toString('utf8'),{context,identifier:entry.name}));
 }
 const candidatePath=path.join(here,'compact-bfgs.mjs'),candidateBytes=fs.readFileSync(candidatePath);
 const cachedPath=path.join(here,'cached-adjoint.mjs'),cachedBytes=fs.readFileSync(cachedPath);
 sources.push({file:cachedPath,bytes:cachedBytes});
 cache.set('cached-adjoint.mjs',new vm.SourceTextModule(cachedBytes.toString('utf8'),{context,identifier:'cached-adjoint.mjs'}));
 cache.set('compact-bfgs.mjs',new vm.SourceTextModule(candidateBytes.toString('utf8'),{context,identifier:'compact-bfgs.mjs'}));
 const candidate=cache.get('compact-bfgs.mjs');
 await candidate.link((specifier,parent)=>{assert.ok(specifier.startsWith('./'));const name=path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),specifier));assert.ok(cache.has(name));return cache.get(name);});
 await candidate.evaluate({timeout:5000});
 const bindings=vm.runInContext('({process:typeof process,require:typeof require,fetch:typeof fetch,WebSocket:typeof WebSocket})',context);
 assert.ok(Object.values(bindings).every(v=>v==='undefined'));
 const spectrumSource=fs.readFileSync(path.join(here,'vqd-source-original.mjs'),'utf8');
 const start=spectrumSource.indexOf('function solveCircuit(H,index){'),end=spectrumSource.indexOf('\ntry{\n const rows=[];');
 assert.ok(start>=0&&end>start);
 const spectrumFunction=spectrumSource.slice(start,end),overlap=spectrumSource.split(/\r?\n/).find(l=>l.startsWith('const overlap='));
 assert.ok(overlap);
 return {base:cache.get('baseline.mjs').namespace,old:cache.get('q8-fast.mjs').namespace,compact:candidate.namespace,
  config:contract.config,hashBytes,candidate_identity:hashBytes(candidateBytes,'qel-compact-bfgs'),adjoint_identity:hashBytes(cachedBytes,'qel-cached-adjoint'),bindings,
  async createSpectrumSolver(implementation){
   assert.ok(['baseline','compact'].includes(implementation));
   const text=`import {refineBFGS} from './${implementation==='baseline'?'q8-fast':'compact-bfgs'}.mjs';
import {stateDiagnostics} from './q8-fast.mjs';
import * as base from './baseline.mjs';
const fast={refineBFGS,stateDiagnostics};
const config=${JSON.stringify(contract.config)};
const began=Date.now();
const checkBudget=()=>{if(Date.now()-began>config.maximum_elapsed_ms)throw Error('Spectrum time budget exceeded');};
${overlap}
export ${spectrumFunction}`;
   const module=new vm.SourceTextModule(text,{context,identifier:'spectrum-'+implementation+'.mjs'});
   await module.link(specifier=>{assert.ok(specifier.startsWith('./'));const name=specifier.slice(2);assert.ok(cache.has(name));return cache.get(name);});
   await module.evaluate({timeout:5000});return module.namespace.solveCircuit;
  },
  verifySources(){for(const source of sources)assert.ok(fs.readFileSync(source.file).equals(source.bytes));assert.ok(fs.readFileSync(candidatePath).equals(candidateBytes));}};
}
