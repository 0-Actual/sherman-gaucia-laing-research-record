import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {loadNumerics,here,original,assessment} from './load-numerics.mjs';
export async function runWork(implementation,set,label,providedMath){
assert.ok(['baseline','compact'].includes(implementation));assert.ok(['official','additional'].includes(set));
assert.match(label||'',/^[a-z0-9_-]{1,60}$/);
const out=path.join(here,'runs',label);assert.ok(!fs.existsSync(out),'Existing result must remain preserved');
const math=providedMath||await loadNumerics(),solve=await math.createSpectrumSolver(implementation);
const fixture=set==='official'?path.join(original,'inputs/hamiltonians_24x8x8.json'):path.join(here,'inputs/additional-hamiltonians.json');
const inputBytes=fs.readFileSync(fixture),input=JSON.parse(inputBytes);
assert.equal(input.material_id,'JVASP-816');assert.equal(input.rows.length,24);assert.equal(input.fermi_shift_ev,0);
for(const [i,row]of input.rows.entries()){assert.equal(row.kpoint_index,i);math.base.validateH(row.matrix_ev);}
fs.mkdirSync(out,{recursive:true});
const write=(name,value)=>{const bytes=Buffer.from(JSON.stringify(value,null,2)+'\n'),file=path.join(out,name);fs.writeFileSync(file,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(file).equals(bytes));};
write('contract.json',{utc:new Date().toISOString(),implementation,set,config:math.config,input:fixture,input_identity:math.hashBytes(inputBytes,'qel-jarvis-input'),
 candidate_identity:math.candidate_identity,adjoint_identity:math.adjoint_identity,method:'Same QEL VQD function and BFGS updates; compact variant caches gate trigonometry for adjoint reversal and omits unused per-iteration history; unchanged USB SOP/dense validation',
 physical_QPU:false,publication:false,reference_answers_read:false,existing_controller_started:false,security_hold_modified:false});
const began=performance.now(),cpu=process.cpuUsage();let peak=process.memoryUsage().rss;const rows=[];
try{
 for(const inputRow of input.rows){
  const start=performance.now(),prediction=solve(inputRow.matrix_ev,inputRow.kpoint_index);
  rows.push({index:inputRow.kpoint_index,kpoint:inputRow.kpoint_fractional_reciprocal,...prediction,elapsed_ms:performance.now()-start});
  peak=Math.max(peak,process.memoryUsage().rss);
 }
 const computeElapsed=performance.now()-began,computeCpu=process.cpuUsage(cpu);
 write('predictions.json',{material:'JVASP-816',units:'eV',implementation,set,rows,physical_QPU:false,reference_answers_read:false});
 math.verifySources();assert.ok(fs.readFileSync(fixture).equals(inputBytes));
 const resources=process.resourceUsage();
 const result={utc:new Date().toISOString(),state:'PREDICTIONS_FROZEN',implementation,set,points:24,scalar_predictions:192,
  numerical_elapsed_ms:computeElapsed,numerical_cpu_microseconds:computeCpu,elapsed_with_save_ms:performance.now()-began,
  sampled_maximum_rss_bytes:peak,process_maximum_rss_kib:resources.maxRSS,node:process.version,usb_sources_unchanged:true};
 write('execution.json',result);return result;
}catch(error){write('failure.json',{utc:new Date().toISOString(),message:error.message,completed_points:rows.length});throw error;}
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url))console.log(JSON.stringify(await runWork(...process.argv.slice(2))));
