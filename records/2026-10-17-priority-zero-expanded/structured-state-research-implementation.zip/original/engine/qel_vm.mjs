/**
 * QEL register-machine prototype prepared for Sherman G. Laing.
 * Bible-first review: report measured behavior honestly, disclose limitations,
 * preserve attribution, and use this prototype only for peaceful work.
 * Original implementation of conventional numerical/register-machine concepts.
 * Virtual instructions run inside Node.js and the host OS; this is not an OS,
 * native-process sandbox, hardware emulator, neural model, or training system.
 */
const LIMITS = Object.freeze({ registers: 16, memoryWords: 4096, instructions: 4096, outputValues: 4096, steps: 100000 });
const SPECS = Object.freeze({
  CONST: ['r', 'n'], MOV: ['r', 'r'],
  ADD: ['r', 'r', 'r'], SUB: ['r', 'r', 'r'], MUL: ['r', 'r', 'r'], DIV: ['r', 'r', 'r'],
  LOAD: ['r', 'm'], STORE: ['m', 'r'], JMP: ['p'], JZ: ['r', 'p'], OUT: ['r'], HALT: []
});
class VmFault extends Error {
  constructor(code, message) { super(message); this.name = 'QelVmFault'; this.code = code; }
}
function fault(code, message) { throw new VmFault(code, message); }
function boundedInteger(value, minimum, maximum, code, label) {
  if (!Number.isInteger(value) || value < minimum || value > maximum) fault(code, label + ' is outside its integer bounds.');
  return value;
}
function finiteNumber(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) fault('NONFINITE_NUMBER', 'Numeric operands and arithmetic results must be finite numbers.');
  return value;
}
function dataElement(array, index) {
  const descriptor = Object.getOwnPropertyDescriptor(array, String(index));
  if (!descriptor || !Object.hasOwn(descriptor, 'value')) fault('INVALID_PROGRAM', 'Instructions must contain dense data elements, not getters or missing entries.');
  return descriptor.value;
}
export class QelVM {
  #registers;
  #memory;
  #pc = 0;
  #halted = false;
  #committedRuns = 0;
  #committedSteps = 0;
  constructor({ registers = 8, memoryWords = 256 } = {}) {
    boundedInteger(registers, 1, LIMITS.registers, 'REGISTER_CONFIG', 'Register count');
    boundedInteger(memoryWords, 1, LIMITS.memoryWords, 'MEMORY_CONFIG', 'Memory word count');
    this.#registers = new Float64Array(registers);
    this.#memory = new Float64Array(memoryWords);
  }
  status() {
    return {
      kind: 'QEL_VIRTUAL_REGISTER_MACHINE_PROTOTYPE',
      hostIsolationClaim: false,
      registerCount: this.#registers.length,
      memoryWords: this.#memory.length,
      registers: Array.from(this.#registers),
      memory: Array.from(this.#memory),
      pc: this.#pc, halted: this.#halted,
      committedRuns: this.#committedRuns, committedSteps: this.#committedSteps,
      limits: { ...LIMITS }
    };
  }
  #compile(program) {
    if (!Array.isArray(program)) fault('INVALID_PROGRAM', 'Program must be an array of instruction arrays.');
    boundedInteger(program.length, 1, LIMITS.instructions, 'PROGRAM_SIZE', 'Instruction count');
    const code = [];
    for (let pc = 0; pc < program.length; pc++) {
      const instruction = dataElement(program, pc);
      if (!Array.isArray(instruction) || instruction.length < 1 || instruction.length > 4) {
        fault('INVALID_INSTRUCTION', 'Each instruction must be an array of one to four data elements.');
      }
      const op = dataElement(instruction, 0);
      if (typeof op !== 'string' || !Object.hasOwn(SPECS, op)) fault('ILLEGAL_OPCODE', 'Only the documented fixed opcodes are allowed.');
      const spec = SPECS[op];
      if (instruction.length !== spec.length + 1) fault('OPERAND_COUNT', 'Instruction operand count does not match its opcode.');
      const copy = [op];
      for (let i = 0; i < spec.length; i++) {
        const value = dataElement(instruction, i + 1);
        switch (spec[i]) {
          case 'r': boundedInteger(value, 0, this.#registers.length - 1, 'REGISTER_BOUNDS', 'Register index'); break;
          case 'm': boundedInteger(value, 0, this.#memory.length - 1, 'MEMORY_BOUNDS', 'Memory address'); break;
          case 'p': boundedInteger(value, 0, program.length - 1, 'PC_BOUNDS', 'Jump target'); break;
          case 'n': finiteNumber(value); break;
        }
        copy.push(value);
      }
      code.push(copy);
    }
    return code;
  }
  run(program, maxSteps = 10000) {
    let steps = 0;
    let pc = 0;
    try {
      boundedInteger(maxSteps, 1, LIMITS.steps, 'STEP_LIMIT', 'Maximum step count');
      const code = this.#compile(program);
      // Work only on bounded private copies. Nothing commits until HALT.
      const registers = this.#registers.slice();
      const memory = this.#memory.slice();
      const output = [];
      while (steps < maxSteps) {
        boundedInteger(pc, 0, code.length - 1, 'PC_BOUNDS', 'Program counter');
        const [op, a, b, c] = code[pc];
        steps++;
        switch (op) {
          case 'CONST': registers[a] = b; break;
          case 'MOV': registers[a] = registers[b]; break;
          case 'ADD': registers[a] = finiteNumber(registers[b] + registers[c]); break;
          case 'SUB': registers[a] = finiteNumber(registers[b] - registers[c]); break;
          case 'MUL': registers[a] = finiteNumber(registers[b] * registers[c]); break;
          case 'DIV':
            if (registers[c] === 0) fault('DIVISION_BY_ZERO', 'Division by zero is rejected.');
            registers[a] = finiteNumber(registers[b] / registers[c]);
            break;
          case 'LOAD': registers[a] = memory[b]; break;
          case 'STORE': memory[a] = registers[b]; break;
          case 'JMP': pc = a; continue;
          case 'JZ': if (registers[a] === 0) { pc = b; continue; } break;
          case 'OUT':
            if (output.length >= LIMITS.outputValues) fault('OUTPUT_LIMIT', 'Output buffer limit reached.');
            output.push(registers[a]); break;
          case 'HALT':
            if (!Number.isSafeInteger(this.#committedRuns + 1) || !Number.isSafeInteger(this.#committedSteps + steps)) {
              fault('COUNTER_LIMIT', 'Committed execution counters would exceed safe integer bounds.');
            }
            this.#registers = registers;
            this.#memory = memory;
            this.#pc = pc;
            this.#halted = true;
            this.#committedRuns++;
            this.#committedSteps += steps;
            return { ok: true, steps, output, rolledBack: false, status: this.status() };
          default: fault('ILLEGAL_OPCODE', 'Unknown opcode reached execution.');
        }
        pc++;
      }
      fault('MAX_STEPS', 'Execution reached its step limit without HALT.');
    } catch (error) {
      return {
        ok: false, steps, output: [], rolledBack: true, attemptedPc: pc,
        error: { code: error instanceof VmFault ? error.code : 'VM_FAILURE', message: error instanceof VmFault ? error.message : 'Program rejected due to an unexpected input or execution failure.' },
        status: this.status()
      };
    }
  }
}
export { LIMITS };
