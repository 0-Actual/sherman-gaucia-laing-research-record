import {SOP} from './qel60_sop.mjs';
import {MPS} from './qel60_mps.mjs';
const H=[Math.SQRT1_2,0,Math.SQRT1_2,0,Math.SQRT1_2,0,-Math.SQRT1_2,0];
export function quantumRun({qubits=8,kind='ghz'}={}){
 if(!Number.isInteger(qubits)||qubits<2||qubits>60)throw Error('Qubits must be 2..60');
 if(!['ghz','product'].includes(kind))throw Error('Allowed circuits: ghz, product');
 const began=performance.now(),sop=new SOP(qubits,64),mps=new MPS(qubits,{maxBond:32,zeroTol:1e-13});
 if(kind==='ghz'){sop.gate({kind:'H',q:0});mps.gate1(0,H);for(let i=0;i<qubits-1;i++){sop.gate({kind:'CNOT',c:i,t:i+1});mps.cx(i,i+1);}}
 else for(let q=0;q<qubits;q++){sop.gate({kind:'H',q});mps.gate1(q,H);}
 const samples=[Array(qubits).fill(0),Array(qubits).fill(1),Array.from({length:qubits},(_,i)=>i%2)];
 let maxAmplitudeError=0,maxAnalyticError=0;
 const witnesses=samples.map(bits=>{const a=sop.amplitude(bits),b=mps.amplitude(bits.join(''));const expected=kind==='ghz'?(bits.every(v=>v===bits[0])?Math.SQRT1_2:0):2**(-qubits/2);maxAmplitudeError=Math.max(maxAmplitudeError,Math.hypot(a[0]-b[0],a[1]-b[1]));maxAnalyticError=Math.max(maxAnalyticError,Math.hypot(a[0]-expected,a[1]),Math.hypot(b[0]-expected,b[1]));return{basis:bits.join(''),sop:a,mps:b,expected};});
 const sopNorm=sop.norm(),mpsNorm=mps.norm(),maxNormError=Math.max(Math.abs(sopNorm[0]-1),Math.abs(sopNorm[1]),Math.abs(mpsNorm-1));
 const passed=Math.max(maxAmplitudeError,maxAnalyticError,maxNormError)<1e-10;
 if(!passed)throw Error('Quantum verification failed; state not promoted');
 return {verification_scope: 'Three basis-amplitude witnesses and normalization for the selected structured circuit; not exhaustive state verification',kind,qubits,passed,elapsed_ms:performance.now()-began,sop_norm:sopNorm,mps_norm:mpsNorm,max_amplitude_difference:maxAmplitudeError,max_analytic_error:maxAnalyticError,max_norm_error:maxNormError,witnesses,sop_storage:sop.storage(),mps_numeric_payload_bytes:mps.storageBytes(),mps_max_bond:mps.maxBond(),mps_diagnostics:mps.diagnostics,representation:'Structured quantum-state simulation on classical host; not a dense 2^n state vector, physical QPU, energy-free computer, or arbitrary 60-qubit capacity',checkpoint:{sop:{n:sop.n,cap:sop.cap,branches:sop.branches},mps:{n:mps.n,zeroTol:mps.zeroTol,bondLimit:mps._bondLimit,sites:mps._sites.map(x=>({left:x.left,right:x.right,data:Array.from(x.data)}))}}};
}
export function verifyQuantumRollback(){
 const sop=new SOP(4,2);sop.gate({kind:'H',q:0}).gate({kind:'CNOT',c:0,t:1}).gate({kind:'H',q:2});
 const before=JSON.stringify(sop.branches);let rejected=false;try{sop.gate({kind:'CNOT',c:2,t:3})}catch(e){rejected=e.name==='RankLimitError'}
 const m=new MPS(2,{maxBond:1});m.gate1(0,H);const mb=JSON.stringify(m._sites);let mr=false;try{m.cx(0,1)}catch(e){mr=/bond cap/.test(e.message)}
 return{sop_rejected:rejected,sop_branch_state_unchanged:before===JSON.stringify(sop.branches),mps_rejected:mr,mps_tensor_state_unchanged:mb===JSON.stringify(m._sites),passed:rejected&&before===JSON.stringify(sop.branches)&&mr&&mb===JSON.stringify(m._sites)};
}
