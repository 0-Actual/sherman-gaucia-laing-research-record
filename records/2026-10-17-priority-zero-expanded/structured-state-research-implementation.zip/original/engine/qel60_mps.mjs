/**
 * QEL additive research prototype: complex, open-boundary matrix product state.
 * Authorship: prepared for Sherman G. Laing / Quantum.Earth.Laing.
 * Q8 transition status: HOLD. No networking, filesystem, hashing or signing.
 *
 * Each tensor stores A[left, physical_bit, right] as interleaved real/imaginary
 * Float64 values. Adjacent CNOT uses an explicit two-site contraction followed
 * by twice-reorthogonalized modified Gram-Schmidt column QR. There is no
 * singular-value truncation. Residual columns at or below zeroTol are omitted
 * and EVERY omitted column norm is retained in diagnostics. This is an
 * absolute local factorization tolerance, not a global-state error guarantee.
 * Rank above maxBond throws before either state tensor is replaced.
 */

function finiteArray(values, label) {
  for (let i = 0; i < values.length; i++) {
    if (!Number.isFinite(values[i])) throw new RangeError(`${label}: non-finite value at ${i}`);
  }
}

function vectorNorm(values) {
  // Scaled sum-of-squares avoids overflow/underflow in the norm itself.
  let scale = 0, ssq = 1;
  for (const value of values) {
    const a = Math.abs(value);
    if (!Number.isFinite(a)) throw new RangeError('QR residual is not finite');
    if (a === 0) continue;
    if (scale < a) {
      ssq = 1 + ssq * (scale / a) ** 2;
      scale = a;
    } else ssq += (a / scale) ** 2;
  }
  const result = scale === 0 ? 0 : scale * Math.sqrt(ssq);
  if (!Number.isFinite(result)) throw new RangeError('QR residual norm is not finite');
  return result;
}

function copyDiagnostics(d) {
  return {
    factorizations: d.factorizations,
    discardedColumnResidualMax: d.discardedColumnResidualMax,
    discardedColumnResidualSum: d.discardedColumnResidualSum,
    rankCapHits: d.rankCapHits,
    discardedColumnResiduals: d.discardedColumnResiduals.map(entry => ({ ...entry })),
  };
}

export class MPS {
  constructor(n, { maxBond = 32, zeroTol = 1e-13 } = {}) {
    if (!Number.isSafeInteger(n) || n < 1) throw new RangeError('n must be a positive safe integer');
    if (!Number.isSafeInteger(maxBond) || maxBond < 1) throw new RangeError('maxBond must be a positive safe integer');
    if (!Number.isFinite(zeroTol) || zeroTol < 0) throw new RangeError('zeroTol must be finite and nonnegative');
    this.n = n;
    this._bondLimit = maxBond;
    this.zeroTol = zeroTol;
    this._sites = Array.from({ length: n }, () => ({
      left: 1, right: 1, data: new Float64Array([1, 0, 0, 0]),
    }));
    this.diagnostics = {
      factorizations: 0,
      discardedColumnResidualMax: 0,
      discardedColumnResidualSum: 0,
      rankCapHits: 0,
      discardedColumnResiduals: [],
    };
  }

  _checkQubit(q) {
    if (!Number.isInteger(q) || q < 0 || q >= this.n) throw new RangeError(`Invalid qubit index: ${q}`);
  }

  /** Apply a complex 2x2 matrix in row-major interleaved order; q0 is leftmost. */
  gate1(q, U) {
    this._checkQubit(q);
    if (U == null || U.length !== 8) throw new TypeError('gate1 requires eight interleaved complex matrix entries');
    finiteArray(U, 'gate1');
    const site = this._sites[q], R = site.right, source = site.data;
    const result = new Float64Array(source.length);
    for (let l = 0; l < site.left; l++) {
      for (let r = 0; r < R; r++) {
        const i0 = 2 * (l * 2 * R + r), i1 = i0 + 2 * R;
        const ar = source[i0], ai = source[i0 + 1], br = source[i1], bi = source[i1 + 1];
        result[i0] = U[0] * ar - U[1] * ai + U[2] * br - U[3] * bi;
        result[i0 + 1] = U[0] * ai + U[1] * ar + U[2] * bi + U[3] * br;
        result[i1] = U[4] * ar - U[5] * ai + U[6] * br - U[7] * bi;
        result[i1 + 1] = U[4] * ai + U[5] * ar + U[6] * bi + U[7] * br;
      }
    }
    finiteArray(result, 'gate1 result');
    this._sites[q] = { left: site.left, right: R, data: result };
    return this;
  }

  /** Apply adjacent CNOT in either direction. Nonadjacent gates are rejected. */
  cx(c, t) {
    this._checkQubit(c);
    this._checkQubit(t);
    if (Math.abs(c - t) !== 1) throw new RangeError('cx requires distinct adjacent qubits');
    const q = Math.min(c, t), A = this._sites[q], B = this._sites[q + 1];
    if (A.right !== B.left) throw new Error('Internal MPS bond mismatch');
    const L = A.left, K = A.right, R = B.right, rows = 2 * L, cols = 2 * R;
    const matrix = new Float64Array(2 * rows * cols);
    for (let l = 0; l < L; l++) for (let s = 0; s < 2; s++) {
      for (let bit = 0; bit < 2; bit++) for (let r = 0; r < R; r++) {
        let real = 0, imag = 0;
        for (let k = 0; k < K; k++) {
          const ia = 2 * ((l * 2 + s) * K + k), ib = 2 * ((k * 2 + bit) * R + r);
          const ar = A.data[ia], ai = A.data[ia + 1], br = B.data[ib], bi = B.data[ib + 1];
          real += ar * br - ai * bi;
          imag += ar * bi + ai * br;
        }
        const outS = c === q ? s : s ^ bit;
        const outT = c === q ? bit ^ s : bit;
        const dst = 2 * ((l * 2 + outS) * cols + outT * R + r);
        matrix[dst] = real;
        matrix[dst + 1] = imag;
      }
    }
    finiteArray(matrix, 'CNOT contraction');
    const { rank, qColumns, rRows } = this._factorColumns(matrix, rows, cols, q);
    const leftData = new Float64Array(2 * L * 2 * rank);
    const rightData = new Float64Array(2 * rank * 2 * R);
    for (let k = 0; k < rank; k++) {
      for (let row = 0; row < rows; row++) {
        const dst = 2 * (row * rank + k);
        leftData[dst] = qColumns[k][2 * row];
        leftData[dst + 1] = qColumns[k][2 * row + 1];
      }
      rightData.set(rRows[k], 2 * k * cols);
    }
    finiteArray(leftData, 'CNOT left factor');
    finiteArray(rightData, 'CNOT right factor');
    // Both replacements occur only after contraction, QR and validation succeed.
    this._sites[q] = { left: L, right: rank, data: leftData };
    this._sites[q + 1] = { left: rank, right: R, data: rightData };
    return this;
  }

  _factorColumns(matrix, rows, cols, leftQubit) {
    const d = this.diagnostics;
    const factorization = ++d.factorizations; // Attempts, including rank-cap failures.
    const qColumns = [], rRows = [];
    for (let col = 0; col < cols; col++) {
      const residual = new Float64Array(2 * rows);
      for (let row = 0; row < rows; row++) {
        const src = 2 * (row * cols + col);
        residual[2 * row] = matrix[src];
        residual[2 * row + 1] = matrix[src + 1];
      }
      // Two complete MGS passes. The second projection is accumulated into R.
      for (let pass = 0; pass < 2; pass++) {
        for (let k = 0; k < qColumns.length; k++) {
          const basis = qColumns[k];
          let pr = 0, pi = 0;
          for (let row = 0; row < rows; row++) {
            const qr = basis[2 * row], qi = basis[2 * row + 1];
            const vr = residual[2 * row], vi = residual[2 * row + 1];
            pr += qr * vr + qi * vi;
            pi += qr * vi - qi * vr;
          }
          rRows[k][2 * col] += pr;
          rRows[k][2 * col + 1] += pi;
          for (let row = 0; row < rows; row++) {
            const qr = basis[2 * row], qi = basis[2 * row + 1];
            residual[2 * row] -= qr * pr - qi * pi;
            residual[2 * row + 1] -= qr * pi + qi * pr;
          }
        }
      }
      const norm = vectorNorm(residual);
      if (norm <= this.zeroTol) {
        d.discardedColumnResidualMax = Math.max(d.discardedColumnResidualMax, norm);
        d.discardedColumnResidualSum += norm;
        d.discardedColumnResiduals.push({ factorization, leftQubit, column: col, norm });
        continue;
      }
      if (qColumns.length >= this._bondLimit) {
        d.rankCapHits++;
        throw new RangeError(`MPS bond cap ${this._bondLimit} exceeded at cut ${leftQubit}|${leftQubit + 1}; residual ${norm}; state unchanged`);
      }
      for (let i = 0; i < residual.length; i++) residual[i] /= norm;
      const rRow = new Float64Array(2 * cols);
      rRow[2 * col] = norm;
      qColumns.push(residual);
      rRows.push(rRow);
    }
    // Preserve legal dimension-one bonds for the zero vector as well.
    if (qColumns.length === 0) {
      const basis = new Float64Array(2 * rows);
      basis[0] = 1;
      qColumns.push(basis);
      rRows.push(new Float64Array(2 * cols));
    }
    return { rank: qColumns.length, qColumns, rRows };
  }

  /** Return <bits|state>; q0 corresponds to the first character. */
  amplitude(bits) {
    if (typeof bits !== 'string' || bits.length !== this.n || !/^[01]+$/.test(bits)) {
      throw new TypeError(`amplitude requires a string of exactly ${this.n} binary digits`);
    }
    let vector = new Float64Array([1, 0]);
    for (let q = 0; q < this.n; q++) {
      const site = this._sites[q], bit = bits.charCodeAt(q) - 48;
      const next = new Float64Array(2 * site.right);
      for (let l = 0; l < site.left; l++) for (let r = 0; r < site.right; r++) {
        const src = 2 * ((l * 2 + bit) * site.right + r);
        const vr = vector[2 * l], vi = vector[2 * l + 1], ar = site.data[src], ai = site.data[src + 1];
        next[2 * r] += vr * ar - vi * ai;
        next[2 * r + 1] += vr * ai + vi * ar;
      }
      vector = next;
    }
    finiteArray(vector, 'Amplitude');
    return [vector[0], vector[1]];
  }

  /** Contract <this|other> without forming the exponentially sized statevector. */
  inner(other) {
    if (!(other instanceof MPS) || other.n !== this.n) throw new TypeError('inner requires an MPS with the same qubit count');
    let environment = new Float64Array([1, 0]);
    for (let q = 0; q < this.n; q++) {
      const A = this._sites[q], B = other._sites[q];
      const intermediate = new Float64Array(2 * 2 * A.right * B.left);
      for (let s = 0; s < 2; s++) for (let ar = 0; ar < A.right; ar++) {
        for (let bl = 0; bl < B.left; bl++) {
          let real = 0, imag = 0;
          for (let al = 0; al < A.left; al++) {
            const ai = 2 * ((al * 2 + s) * A.right + ar), ei = 2 * (al * B.left + bl);
            const xr = A.data[ai], xi = A.data[ai + 1], er = environment[ei], em = environment[ei + 1];
            real += xr * er + xi * em;
            imag += xr * em - xi * er;
          }
          const dst = 2 * ((s * A.right + ar) * B.left + bl);
          intermediate[dst] = real;
          intermediate[dst + 1] = imag;
        }
      }
      const next = new Float64Array(2 * A.right * B.right);
      for (let ar = 0; ar < A.right; ar++) for (let br = 0; br < B.right; br++) {
        let real = 0, imag = 0;
        for (let s = 0; s < 2; s++) for (let bl = 0; bl < B.left; bl++) {
          const zi = 2 * ((s * A.right + ar) * B.left + bl), bi = 2 * ((bl * 2 + s) * B.right + br);
          const zr = intermediate[zi], zm = intermediate[zi + 1], yr = B.data[bi], yi = B.data[bi + 1];
          real += zr * yr - zm * yi;
          imag += zr * yi + zm * yr;
        }
        const dst = 2 * (ar * B.right + br);
        next[dst] = real;
        next[dst + 1] = imag;
      }
      environment = next;
    }
    finiteArray(environment, 'Inner product');
    return [environment[0], environment[1]];
  }

  /** Squared Hilbert-space norm <state|state>; no normalization or clamping. */
  norm() { return this.inner(this)[0]; }

  clone() {
    const result = Object.create(MPS.prototype);
    result.n = this.n;
    result._bondLimit = this._bondLimit;
    result.zeroTol = this.zeroTol;
    result._sites = this._sites.map(site => ({ left: site.left, right: site.right, data: site.data.slice() }));
    result.diagnostics = copyDiagnostics(this.diagnostics);
    return result;
  }

  /** Tensor payload bytes only; excludes JS objects, diagnostic records and temporaries. */
  storageBytes() { return this._sites.reduce((sum, site) => sum + site.data.byteLength, 0); }

  /** Largest current internal bond dimension, or one for a one-qubit state. */
  maxBond() { return this._sites.reduce((maximum, site) => Math.max(maximum, site.left, site.right), 1); }
}

export default MPS;

