// Sherman G. Laing / GAUCIA. Research prototype. Q8 HOLD. UNSIGNED.
// Exact algebraic sum-of-products representation; floating-point arithmetic.
// No branch truncation, tolerance-based pruning, approximate merging or networking.
export const cx=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];
const sum=(a,b)=>[a[0]+b[0],a[1]+b[1]];
const conj=a=>[a[0],-a[1]];
const zero=a=>a[0]===0&&a[1]===0;
const basis=b=>b?[0,0,1,0]:[1,0,0,0];
function mv(m,v){
  return [...sum(cx(m.slice(0,2),v.slice(0,2)),cx(m.slice(2,4),v.slice(2,4))),
          ...sum(cx(m.slice(4,6),v.slice(0,2)),cx(m.slice(6,8),v.slice(2,4)))];
}
export class RankLimitError extends Error {constructor(rank,cap){super(`Exact branch count ${rank} exceeds cap ${cap}; state unchanged`);this.name='RankLimitError';this.rank=rank;this.cap=cap;}}
export class SOP {
  constructor(n,cap=64){
    if(!Number.isInteger(n)||n<1||n>60)throw new RangeError('Qubit count must be 1..60');
    if(!Number.isInteger(cap)||cap<1||cap>64)throw new RangeError('Rank cap must be 1..64');
    this.n=n;this.cap=cap;this.branches=[{c:[1,0],v:Array.from({length:n},()=>basis(0))}];this.maxRank=1;
  }
  checkQ(q){if(!Number.isInteger(q)||q<0||q>=this.n)throw new RangeError('Qubit index out of range');}
  local(q,m){
    this.checkQ(q);
    if(!Array.isArray(m)||m.length!==8||!m.every(Number.isFinite))throw new TypeError('Finite complex 2x2 matrix required');
    let unitError=0;
    for(let a=0;a<2;a++)for(let b=0;b<2;b++){
      let z=[0,0];for(let r=0;r<2;r++)z=sum(z,cx(conj(m.slice(4*r+2*a,4*r+2*a+2)),m.slice(4*r+2*b,4*r+2*b+2)));
      unitError=Math.max(unitError,Math.hypot(z[0]-(a===b?1:0),z[1]));
    }
    if(unitError>1e-12)throw new RangeError('Matrix is not unitary within 1e-12');
    this.branches=this.branches.map(b=>({c:b.c.slice(),v:b.v.map((v,j)=>j===q?mv(m,v):v.slice())}));
    return this;
  }
  controlled(c,t,kind){
    this.checkQ(c);this.checkQ(t);if(c===t)throw new RangeError('Control and target must differ');
    if(kind!=='CNOT'&&kind!=='CZ')throw new TypeError('Unsupported controlled gate');
    const next=[];
    for(const b of this.branches)for(let bit=0;bit<2;bit++){
      const a=b.v[c].slice(2*bit,2*bit+2);if(zero(a)||zero(b.c))continue;
      const v=b.v.map(x=>x.slice());v[c]=basis(bit);
      if(bit&&kind==='CNOT')v[t]=[v[t][2],v[t][3],v[t][0],v[t][1]];
      if(bit&&kind==='CZ')v[t]=[v[t][0],v[t][1],-v[t][2],-v[t][3]];
      next.push({c:cx(b.c,a),v});
    }
    if(next.length>this.cap)throw new RankLimitError(next.length,this.cap);
    this.branches=next;this.maxRank=Math.max(this.maxRank,next.length);return this;
  }
  gate(g){
    const q=g.q,a=g.angle;
    if(g.kind==='CNOT'||g.kind==='CZ')return this.controlled(g.c,g.t,g.kind);
    if(g.kind==='H'){const h=Math.SQRT1_2;return this.local(q,[h,0,h,0,h,0,-h,0]);}
    if(g.kind==='S')return this.local(q,[1,0,0,0,0,0,0,1]);
    if(g.kind==='SDG')return this.local(q,[1,0,0,0,0,0,0,-1]);
    if(g.kind==='X')return this.local(q,[0,0,1,0,1,0,0,0]);
    if(!Number.isFinite(a))throw new TypeError('Finite rotation angle required');
    if(g.kind==='RY'){const c=Math.cos(a/2),s=Math.sin(a/2);return this.local(q,[c,0,-s,0,s,0,c,0]);}
    if(g.kind==='RZ'){const c=Math.cos(a/2),s=Math.sin(a/2);return this.local(q,[c,-s,0,0,0,0,c,s]);}
    throw new TypeError('Unsupported gate');
  }
  amplitude(bits){
    if(!Array.isArray(bits)||bits.length!==this.n||!bits.every(b=>b===0||b===1))throw new TypeError('One binary value per qubit required');
    let re=0,im=0,cr=0,ci=0;
    for(const b of this.branches){
      let z=b.c;for(let j=0;j<this.n;j++)z=cx(z,b.v[j].slice(2*bits[j],2*bits[j]+2));
      const yr=z[0]-cr,tr=re+yr;cr=(tr-re)-yr;re=tr;
      const yi=z[1]-ci,ti=im+yi;ci=(ti-im)-yi;im=ti;
    }
    return [re,im];
  }
  norm(){
    let re=0,im=0,cr=0,ci=0;
    for(const a of this.branches)for(const b of this.branches){
      let z=cx(conj(a.c),b.c);
      for(let j=0;j<this.n;j++){
        const u=a.v[j],v=b.v[j];
        z=cx(z,[u[0]*v[0]+u[1]*v[1]+u[2]*v[2]+u[3]*v[3],u[0]*v[1]-u[1]*v[0]+u[2]*v[3]-u[3]*v[2]]);
      }
      const yr=z[0]-cr,tr=re+yr;cr=(tr-re)-yr;re=tr;
      const yi=z[1]-ci,ti=im+yi;ci=(ti-im)-yi;im=ti;
    }
    return [re,im];
  }
  storage(){return {qubits:this.n,branches:this.branches.length,maximum_observed_branches:this.maxRank,branch_cap:this.cap,numeric_payload_bytes:this.branches.length*(4*this.n+2)*8,definition:'Numeric doubles only; excludes JavaScript array/object overhead, measured separately with process RSS.'};}
}

