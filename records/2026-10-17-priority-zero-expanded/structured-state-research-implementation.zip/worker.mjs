// A dedicated module Worker, with a bounded request and one response per job.
import {runResearch} from './research.mjs';
let received = false;
self.addEventListener('message', event => {
  if (received) return;
  received = true;
  const input = event.data;
  const id = typeof input?.id === 'string' && input.id.length <= 80 ? input.id : null;
  try {
    if (id === null) throw new TypeError('A bounded request ID is required.');
    const result = runResearch({kind: input.kind, options: input.options ?? {}});
    self.postMessage({id, ok: true, result});
  } catch (error) {
    self.postMessage({id, ok: false, error: {name: error.name, message: error.message}});
  } finally {
    self.close();
  }
});
