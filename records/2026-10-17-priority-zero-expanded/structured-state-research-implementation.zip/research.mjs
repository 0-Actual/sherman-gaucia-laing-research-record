// Q8 research adapters, prepared for Sherman G. Laing. Acquired engines stay unchanged.
// Browser-compatible fixed demonstrations; no file, network, eval or native calls.
import {QelVM} from './original/engine/qel_vm.mjs';
import {ByteModel} from './original/engine/qel_byte_model.mjs';
import {quantumRun} from './original/engine/quantum_bridge.mjs';

export const PUBLIC_SAMPLE = 'The morning light crosses the garden. The garden grows in the light. We observe, learn, and test our ideas.\n'.repeat(4);
export const RESEARCH_LIMITS = Object.freeze({
  factorialN: 18, vmRegisters: 4, vmMemoryWords: 8, vmSteps: 128,
  textBytes: 2048, epochs: 8, updates: 16376, generatedBytes: 256,
  modelParameterBytes: 262144, qubits: 60, workerDeadlineMs: 8000,
});
const encoder = new TextEncoder();

function integer(value, low, high, label) {
  if (!Number.isSafeInteger(value) || value < low || value > high) throw new RangeError(`${label} must be an integer from ${low} to ${high}.`);
  return value;
}
function optionsOnly(value, allowed) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) throw new TypeError('Options must be a plain object.');
  for (const key of Reflect.ownKeys(value)) {
    if (!allowed.includes(key) || !Object.hasOwn(Object.getOwnPropertyDescriptor(value, key), 'value')) throw new TypeError('Unsupported option or accessor.');
  }
  return value;
}
function packet(kind, result, limits, claims) {
  return {schema: 'QEL.Q8.ResearchResult.1', kind, ok: true, result, limits, claims};
}

/** Exact safe-integer factorial for n=0..18 using the acquired instruction VM. */
export function runFactorial(options = {}) {
  optionsOnly(options, ['n']);
  const n = integer(options.n === undefined ? 6 : options.n, 0, RESEARCH_LIMITS.factorialN, 'n');
  const program = [
    ['CONST', 0, n], ['CONST', 1, 1], ['CONST', 2, 1], ['JZ', 0, 7],
    ['MUL', 1, 1, 0], ['SUB', 0, 0, 2], ['JMP', 3], ['OUT', 1], ['HALT'],
  ];
  const vm = new QelVM({registers: RESEARCH_LIMITS.vmRegisters, memoryWords: RESEARCH_LIMITS.vmMemoryWords});
  const execution = vm.run(program, RESEARCH_LIMITS.vmSteps);
  if (!execution.ok) throw new Error(`VM demo failed: ${execution.error.code}`);
  const value = execution.output[0];
  if (!Number.isSafeInteger(value)) throw new Error('Factorial result exceeded exact integer range.');
  return packet('vm', {n, value, steps: execution.steps, halted: execution.status.halted, program, registers: execution.status.registers},
    {n: [0, 18], steps: 128, registers: 4, memoryWords: 8},
    {virtualRegisterMachine: true, nativeProcessIsolation: false});
}

/** Fresh, deterministic one-byte-context model; only explicitly supplied public text. */
export function runByteModel(options = {}) {
  optionsOnly(options, ['text', 'epochs', 'generatedBytes', 'seed']);
  const text = options.text === undefined ? PUBLIC_SAMPLE : options.text;
  if (typeof text !== 'string' || text.length > RESEARCH_LIMITS.textBytes) throw new RangeError('Public sample must contain 2..2048 UTF-8 bytes.');
  const data = encoder.encode(text);
  if (data.length < 2 || data.length > RESEARCH_LIMITS.textBytes) throw new RangeError('Public sample must contain 2..2048 UTF-8 bytes.');
  const epochs = integer(options.epochs === undefined ? 3 : options.epochs, 1, RESEARCH_LIMITS.epochs, 'epochs');
  const length = integer(options.generatedBytes === undefined ? 64 : options.generatedBytes, 0, RESEARCH_LIMITS.generatedBytes, 'generatedBytes');
  const seed = integer(options.seed === undefined ? 1 : options.seed, 0, 4294967295, 'seed');
  const model = new ByteModel({seed});
  const training = model.train(data, {epochs, maxTransitions: RESEARCH_LIMITS.textBytes - 1, lr: 0.2});
  const contextByte = data[data.length - 1];
  const generated = model.generate(Uint8Array.of(contextByte), length, seed).slice(1);
  let generatedUtf8Valid = true;
  try { new TextDecoder('utf-8', {fatal: true}).decode(generated); } catch { generatedUtf8Valid = false; }
  // Preserve exact numeric bytes; escape display control characters in the preview.
  const generatedText = new TextDecoder().decode(generated).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, c => `\\x${c.charCodeAt(0).toString(16).padStart(2, '0')}`);
  const nextBytes = Array.from(model.predict(contextByte), (probability, byte) => ({byte, probability})).sort((a, b) => b.probability - a.probability || a.byte - b.byte).slice(0, 8);
  return packet('byte-model', {training, parameterBytes: model.parameterBytes, contextByte, nextBytes, generatedText, generatedBytes: Array.from(generated), generatedUtf8Valid, seed},
    {textBytes: [2, 2048], epochs: [1, 8], updates: RESEARCH_LIMITS.updates, generatedBytes: [0, 256], parameterBytes: 262144},
    {architecture: 'softmax byte bigram', contextBytes: 1, lossScope: 'training sample only', factualAccuracyMeasured: false, generalLanguageModel: false, inputOrModelSaved: false});
}

/** Compare the original SOP and MPS engines for a fixed structured circuit. */
export function runQuantumWitness(options = {}) {
  optionsOnly(options, ['qubits', 'kind']);
  const qubits = integer(options.qubits === undefined ? 8 : options.qubits, 2, RESEARCH_LIMITS.qubits, 'qubits');
  const kind = options.kind === undefined ? 'ghz' : options.kind;
  if (!['ghz', 'product'].includes(kind)) throw new TypeError('Circuit must be ghz or product.');
  const measured = quantumRun({qubits, kind});
  // Checkpoints are not needed by this UI and are not returned or persisted.
  const {checkpoint, ...witness} = measured;
  const outcomes = witness.witnesses.map(x => ({basis: x.basis, amplitude: x.sop, probability: x.sop[0] ** 2 + x.sop[1] ** 2}));
  return packet('quantum', {...witness, outcomes},
    {qubits: [2, 60], circuits: ['ghz', 'product'], basisWitnesses: 3, mpsMaxBond: 32, sopBranchCap: 64},
    {classicalSimulation: true, physicalQuantumHardware: false, fullStateExhaustivelyVerified: false, arbitrary60QubitCapacity: false, mpsToleranceIsGlobalErrorBound: false});
}

/** Fixed dispatch used by browser and Node worker adapters. No arbitrary code. */
export function runResearch(request) {
  optionsOnly(request, ['kind', 'options']);
  if (request.kind === 'vm') return runFactorial(request.options ?? {});
  if (request.kind === 'byte-model') return runByteModel(request.options ?? {});
  if (request.kind === 'quantum') return runQuantumWitness(request.options ?? {});
  throw new TypeError('Research kind must be vm, byte-model or quantum.');
}

/** Validate scalars before worker structured-clone allocation; performs no model work. */
export function validateResearchRequest(request) {
  optionsOnly(request, ['kind', 'options']);
  const options = request.options === undefined ? {} : request.options;
  const allowed = {'vm': ['n'], 'byte-model': ['text', 'epochs', 'generatedBytes', 'seed'], 'quantum': ['qubits', 'kind']};
  if (!Object.hasOwn(allowed, request.kind)) throw new TypeError('Research kind must be vm, byte-model or quantum.');
  optionsOnly(options, allowed[request.kind]);
  const value = (key, fallback) => options[key] === undefined ? fallback : options[key];
  if (request.kind === 'vm') return {kind: 'vm', options: {n: integer(value('n', 6), 0, 18, 'n')}};
  if (request.kind === 'quantum') {
    const qubits = integer(value('qubits', 8), 2, 60, 'qubits'), kind = value('kind', 'ghz');
    if (!['ghz', 'product'].includes(kind)) throw new TypeError('Circuit must be ghz or product.');
    return {kind: 'quantum', options: {qubits, kind}};
  }
  const text = value('text', PUBLIC_SAMPLE);
  if (typeof text !== 'string' || text.length > 2048) throw new RangeError('Public sample must contain 2..2048 UTF-8 bytes.');
  const bytes = encoder.encode(text).length;
  if (bytes < 2 || bytes > 2048) throw new RangeError('Public sample must contain 2..2048 UTF-8 bytes.');
  return {kind: 'byte-model', options: {text, epochs: integer(value('epochs', 3), 1, 8, 'epochs'), generatedBytes: integer(value('generatedBytes', 64), 0, 256, 'generatedBytes'), seed: integer(value('seed', 1), 0, 4294967295, 'seed')}};
}
