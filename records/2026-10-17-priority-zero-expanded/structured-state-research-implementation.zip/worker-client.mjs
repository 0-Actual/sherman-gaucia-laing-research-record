// Browser client. One active worker per client; termination discards transient state.
import {RESEARCH_LIMITS, validateResearchRequest} from './research.mjs';

export function createResearchClient() {
  let active = null, sequence = 0;
  function cancel() {
    if (active) active.finish(new DOMException('Research run cancelled.', 'AbortError'));
  }
  function run(kind, options = {}, {signal} = {}) {
    if (active) return Promise.reject(new Error('A research run is already active.'));
    if (signal?.aborted) return Promise.reject(new DOMException('Research run cancelled.', 'AbortError'));
    return new Promise((resolve, reject) => {
      const request = validateResearchRequest({kind, options});
      const id = String(++sequence);
      const resource = globalThis.Q8Modules?.createResearchWorker
        ? globalThis.Q8Modules.createResearchWorker()
        : {worker:new Worker(new URL('./worker.mjs', import.meta.url), {type:'module',name:'q8-bounded-research'}),release(){}};
      const worker = resource.worker;
      let timer, done = false;
      const abort = () => finish(new DOMException('Research run cancelled.', 'AbortError'));
      const finish = (error, value) => {
        if (done) return;
        done = true;
        clearTimeout(timer);
        signal?.removeEventListener('abort', abort);
        worker.terminate();
        resource.release();
        active = null;
        error ? reject(error) : resolve(value);
      };
      active = {finish};
      timer = setTimeout(() => finish(new Error('Research run exceeded the 8-second limit.')), RESEARCH_LIMITS.workerDeadlineMs);
      signal?.addEventListener('abort', abort, {once: true});
      worker.addEventListener('message', ({data}) => {
        if (data?.id !== id) return finish(new Error('Unexpected research result ID.'));
        if (data.ok !== true) return finish(new Error(data.error?.message || 'Research run failed.'));
        if (data.result?.schema !== 'QEL.Q8.ResearchResult.1' || data.result.kind !== kind || data.result.ok !== true) return finish(new Error('Invalid research result.'));
        finish(null, data.result);
      });
      worker.addEventListener('error', () => finish(new Error('Research worker failed.')));
      worker.addEventListener('messageerror', () => finish(new Error('Research result could not be decoded.')));
      try { worker.postMessage({id, ...request}); } catch (error) { finish(error); }
    });
  }
  return Object.freeze({run, cancel, get busy() { return active !== null; }});
}
