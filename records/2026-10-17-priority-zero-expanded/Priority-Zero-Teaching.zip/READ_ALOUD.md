# Priority Zero — what the existing work teaches

Sherman Gaucia Laing describes the purpose of this work as teaching humanity. His dedication is: “to God be the glory.” He gave this direction on his and his wife's anniversary, October 16, 2026. This compilation preserves his voice and gathers the work that was already produced.

The teaching account follows the question, the attempted method, the recorded result, the control, the correction and the lesson. It includes outcomes that were encouraging, outcomes that missed their target and mistakes that changed the interpretation. Those parts belong together.

One early lesson is to read the implemented mathematics carefully. A function's name does not settle what it measures. In the historical core, a quantity called energy was a squared norm; it was not a Hamiltonian expectation. A predicate filter did not normalize a quantum state. Understanding that distinction helps a reader move from a promising idea to a precisely stated algorithm.

The exact Task Alpha reference provided a clear expected answer for bounded classical emulation. Its saved exact fidelity was one out of one. The recorded policy methods, workload methods and paired replay comparisons are different units and remain separately counted. This is useful verification of the represented calculation. It is not a measurement of physical entanglement.

The numerical repair history teaches a related lesson. Mathematically meaningful formulas can behave poorly in a finite numerical representation. The retained C002 candidate passed 142 methods, while its parent failed 13 of 22 newly added precision methods. The original and successor remain separately identified so the correction can be examined rather than hidden.

The JARVIS numerical solver work is also a teaching sequence. An early point missed its stated energy target, and adaptive follow-ups still missed it. Later synthetic cases showed that a small energy error could coexist with poor state fidelity. Some starts exhausted their iteration budget. A reused, already-solved seed weakened one control; the original 720-case view and the corrected 719-case exclusion view remain separate. These are lessons about initialization, stopping rules and the need for more than one quality measure.

The aluminum-spectrum work retained useful local prediction results. It also retained a stronger conventional control that was faster and more accurate on the recorded comparison. That control is part of the result. Same-material follow-ups do not automatically establish accuracy across unrelated materials, and cached retrieval speed does not describe the speed of a fresh solve.

The JARVIS materials-data study is a separate branch. It inspected 1,103 records and 65 fields from a published dataset. Three named deterministic outputs matched in a recorded replay. A geometric follow-up supported a repeated-cell interpretation for 40 of 42 count differences at a tolerance of 0.001 angstrom, while two cases remained unresolved. Successful execution and repeated output can coexist with checks that correctly report data anomalies. The anomalies should remain visible; they do not turn a completed computation into an unexecuted one.

For Q8 and the USB work, the representation and execution location matter. A dense state-vector study completed 25 trials through 21 qubits; a 22-qubit case was refused before allocation. The retained structured implementation supports selected product and GHZ circuits up to 60 indexed qubits under explicit branch, bond and verification limits; its separate historical benchmark linkage remains limited. These statements describe different workloads and cannot be collapsed into one arbitrary-circuit capacity claim. The portable environment and preserved software work should be explained through their actual mechanisms.

The host-resource observations retain 990 readings and 33 means across three windows. They are historical observations with their original conditions. They are not by themselves a controlled demonstration that the USB caused a whole-system improvement. The owner's observation of a real-world correlation is preserved as his observation while the required causal evidence remains an open question.

The mathematical bridges are part of the teaching material: the matrix contains 20 mechanism rows, connecting definitions, representations, algorithms, checks and limits. They do not declare new mathematics merely because a technique was useful. The reader can follow the existing reasoning and decide what a result supports.

The review now keeps persistent state. Five recovered exports have been indexed once into a private local database with source pointers, timestamps and all retained message versions. A second invocation reused that state and parsed zero exports. The 291-conversation topic matrix is navigation, not a claim that every conversation has been semantically reviewed. The existing 12,153-file quantum source register remains the source map for the preserved code and evidence, without repeatedly scanning its object store.

There is still work to finish: five numerical or interface boundary corrections, reproduction-package assembly, dataset anomalies, final privacy screening, USB preservation and the exact publication selection. No new experiment was run to fill a missing result. The master controller and master node remain excluded, and publication still awaits the owner's review.

The complete matrix below is the durable teaching record. Its 94 rows are overlapping learning points, not 94 newly counted experiments.

## All teaching points

### Simulations and mathematics

- **Recovered historical core function semantics** — Names must be matched to the implemented quantity: squared norm is not Hamiltonian energy, and a predicate filter is not quantum measurement.
- **Task Alpha classical three-qubit GHZ emulator** — Exact arithmetic and a declared oracle make a bounded emulator testable; exact GHZ output on a classical computer is not physical entanglement.
- **LQCP, entropy and three-qubit corrections** — Preserve mathematical meaning, floating-point representability and source identity as separate checks.
- **Aluminum VQD assessment and additional points** — Mean energy accuracy, eigenstate convergence, runtime and generalization require separate comparisons.
- **QEL compact optimizer performance comparison** — A measured gain can coexist with a failed target; cache retrieval must be separated from new computation.
- **JARVIS original local numerical dependencies** — An available dependency and an executed dependency are different facts.
- **Generation A 21-capability successor simulation suite and B–D kernel integration** — Use domain-specific models and controls; maintain classical signal/field lanes as classical. Do not backdate corrected successors.
- **September 18 dense state-vector workload scaling** — State storage, process memory, admission policy and algorithm capacity are different measurements.
- **Squared norm called energy in an early dynamics function** — Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.
- **Observer naming exceeds the implemented predicate filter** — The documentary review separates implementation from the physical implication of the name.
- **Guidance routine has random perturbation but no implemented ethical objective** — The later review preserves the project attribution but describes the actual perturbation function.
- **Greedy gate placement rejected valid plateau-crossing solutions** — Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.
- **Mean-square amplitude rescaling was incorrectly associated with coherence** — The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.
- **Algebraically equivalent Ramsey evaluation failed reciprocal scales** — C001 forms spread*t first, preserving the dimensionless product, then squares it.
- **Finite ratio inputs produced infinite outputs** — C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.
- **Unknown circuit operation was skipped while the API reported PASS** — A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.
- **The corrected v2.1 reference still rejected valid extreme-scale states** — v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.
- **Near-one fidelity subtraction lost tiny distances or invented self-distance** — v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.
- **Three-qubit normalization accepted zero output after overflow** — Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.
- **Entropy uniqueness test confused numerical threshold with mathematical existence** — A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.
- **Dense scaling attempt 01 was stopped before any circuit** — Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.
- **Dense admission initially counted runtime reserve twice; resident controller also constrained continuation** — Child admission used actual post-load free memory; a PowerShell supervisor removed resident Node-controller cost for continuation while retaining the same 256 MiB reserve.
- **The dense 22-qubit trial never ran** — The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.
- **JARVIS first variational pass missed one of six energy targets** — Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.
- **The first adaptive follow-up still missed point 4** — A separately declared 256-sweep follow-up followed.
- **The second adaptive follow-up remained above goal** — Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.
- **Energy accuracy hid two synthetic fidelity misses** — State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.
- **Passing energy did not mean every BFGS start converged** — Report separates stopping reason, energy, state residual and fidelity.
- **Pass-03 baseline and first Rayleigh repair retained many acceptance misses** — The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.
- **Wrong zero-gradient flat starts were mistaken for useful stopping points** — Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.
- **A reused seed made one supposed test already solved** — Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.
- **Centering cannot recover input information already rounded away** — The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.
- **Hybrid target computation limits discovery and quantum-advantage claims** — Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.
- **Stage-04 energy-only baseline missed 18 runs and direct solving remained cheaper** — Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.
- **Stage 05 target-free protocol was prepared but not executed** — Numerical work was set aside for the owner-requested security priority; sources/protocol preserved.
- **Low original-path VQD average error concealed unconverged states** — Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.
- **Additional aluminum cases retained substantial iteration-budget stops** — Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.
- **First allocation rewrite saved memory but increased time 52.1%** — The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.
- **Flat-array v2 probe remained slower** — Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.
- **Row-array v3 probe also remained slower** — The variant was retained but not selected; cached trigonometry and compact history became v4.
- **Selected performance v4 improved time but missed the 20% target** — The selected code retained the measured gain honestly; a later batch checked it again.
- **Audit repeat also missed the 20% target** — The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.
- **Structured 60-qubit labels require branch, bond and verification limits** — The later review states compact representation limits and separates the dense 21-qubit trial results.
- **Windows observation changes cannot be promoted to causal USB speedup** — The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.
- **common_kernel_v1** — Unitary dynamics preserve norm, inner products, global density spectrum and entropy. Kraus closure ΣK_i†K_i=I gives trace preservation; operator-sum form gives complete positivity. Computational coherence is basis-dependent. Unitary motion does not generally converge or erase information.
- **computational_stability_v1 (#20)** — Numerical linear algebra: small residual and small forward error are distinct and linked through conditioning. Exact U hasκ2(U)=1 but floating point repetition accumulates defects. Passing a bounded run does not establish universal numerical stability.
- **energy_optimization_v1 (#7)** — Rayleigh–Ritz E≥λmin(H). Grid optimum is only optimum among evaluated ansatz states; general ground state accessibility is not proved. For H=−(X⊗X+Z⊗Z), Bell-family E=−1−sinθ reaches−2 at θ=π/2. Ground-vector fidelity can depend on the arbitrary eigenvector selected within a degenerate ground eigenspace; energy gap is the invariant quantity.
- **entropic_balancing_v1 (#18)** — Partial SWAP preserves global spectrum and identical-local-H total energy, can create correlations, and is reversible rather than asymptotically mixing. Random SWAP marginal difference contracts by(1−2η), in trace distance by\|1−2η\|; for0<η<1 full state converges to(ρ+SWAPρSWAP)/2, depending on initialρ. It does not have a unique global fixed state. η=1 gives swap oscillation;η=1/2 gives one-step marginal equality.
- **entropy_stabilization_control_v1 (#12)** — T(ρ)=aρ+bI/2+cτ, a=(1−η)(1−p), b=(1−η)p,c=η. Unique ρ*=(bI/2+cτ)/(b+c) iff p orη>0; differences contract exactly by a. Unitary transformations preserve entropy; nonunital replacement supplies purification resources. Entropy target does not specify orientation. Original numerical existence gate is incorrect for weak positive channels; C002 corrects it.
- **error_correction_stabilization_v1 (#3)** — Exactly corrects identity plus all15 single-qubit Pauli errors under ideal recovery. Guaranteed correctable probability under independent error probability p is (1−p)^5+5p(1−p)^4. This is an ideal code/noise/recovery simulation, not a new universal correction theorem or an ancilla/latency/fault-tolerance demonstration.
- **error_mitigation_v1 (#19)** — Estimator correction, not state recovery. For p<1/2, inverse coefficients((1−p)/(1−2p),−p/(1−2p)), normΓ=1/(1−2p); L-layer sampling overheadΓ^(2L). Atp=1/2 information is erased and inverse singular; calibration mismatch biases result. Richardson cancels polynomial terms to declared order, not all noise.
- **field_stabilization_v1 (#6)** — E=Δx(pᵀp+qᵀKq)/2. Conservative midpoint preserves quadratic energy in exact arithmetic. Controlled energy accounts for work. Mode frequencies obey ω_k²=m²+4c² sin²(πk/N)/Δx²; leapfrog requires Δtωmax<2 for bounded nondegenerate stable oscillations. With positive damping and restoring stiffness, error modes decay. This is classical finite-difference dynamics, not operator-valued QFT.
- **noise_reduction_v1 (#17)** — Models Hahn/CPMG dynamical decoupling and explicit pulse-error costs. Computational populations remain1/2 for the equatorial memory; coherence and fidelity change. More pulses need not improve W because pulse errors accumulate. Markovian factor is not reversed by this idealized sequence.
- **phase_synchronization_v1 (#9)** — Local zero-detuning small-angle error dynamics involve gI+K L_rw; connectivity governs disagreement, pinning controls global reference mode. Adler equation δdot=Δ−Ksinδ locks for \|Δ\|<K; boundary \|Δ\|=K has zero linear contraction. Network order parameter1 does not by itself establish lock to the required reference/offsets. Finite noisy simulations are not global convergence proofs.
- **probability_distribution_control_v1 (#16)** — ρ_n−τ=(1−η)^n(ρ0−τ); TV(p_n,p_target)=(1−η)^n TV(p0,p_target). Unique fixed density τ iffη>0; η=0 identity. Same output probabilities need not mean same state, coherence, or phase. Target replacement requires target-description resources, and finite-shot frequencies have sampling error.
- **resonance_amplification_v1 (#8)** — Positive relaxation gives a stable affine equilibrium. p_e≤1/2 in the steady driven model; FWHM=2√(Γ2²+Ω²Γ2/Γ1). Increasing drive produces saturation and power broadening. Closed-system Rabi probability can reach1 but oscillates. This is driven two-level response, not amplitude amplification in Grover's algorithm or unrestricted gain.
- **signal_integrity_v1 (#11)** — Regularized inverse estimation with BER/EVM and gain metrics. No density matrix or quantum channel is used in the core signal path. Complex numbers alone do not make baseband processing quantum. It is a classical signal-estimation mechanism.
- **state_regeneration_v1 (#4)** — Relative logical phase survives inside each coherent flagged branch, allowing recovery. Environment-distinguishable leakage destroys it. Target replacement is state preparation using a known description, not inference of the erased unknown input.
- **state_reinforcement_v1 (#21)** — For target\|+⟩, H=0, Fdot=(κ+γ)−(κ+2γ)F, so F*= (κ+γ)/(κ+2γ), with exponential observable convergence. Fixed-target pumping erases distinctions among input states. Withκ>0 the benchmark has a unique stationary density; κ=0,γ>0 pure dephasing retains all Z-diagonal populations and has many stationary densities despite F→1/2. Numerical tolerance gate and kernel multiplicity issues remain.
- **state_stability_v1 (helper)** — Checks ordinary quantum unitary invariants and numerical drift. Under common U, \|\|Uψ−Uφ\|\|=\|\|ψ−φ\|\| and fidelity is invariant: closed unitary evolution alone cannot contract different states.
- **state_transition_v1 (#1)** — Unitarity and normalization validated; measurement returns one basis state. A user-supplied draw makes simulation replayable; it does not change Born's rule or create measurement-free access to an unknown state. Eigenrays are fixed projectively under their Hamiltonian; generic superpositions oscillate.
- **superposition_stability_v1 (#15)** — q<p for0<p<1/2; q>p for1/2<p<1. Corrects one Z error, not arbitrary single-qubit Pauli error. Parity accumulation p_n=[1−(1−2p)^n]/2. At logical level remaining errors act as a bit flip in the declared logical basis; encoded protection preserves a manifold of arbitrary logical states within the specified noise model.
- **thermal_regulation_v1 (#10)** — Excited population p(t)=p_ss+(p0−p_ss)e^(−Γtotal t), coherence magnitude decays e^(−Γtotal t/2), Gibbs fixed point for one bath. Several baths give p_ss=ΣΓup/Σ(Γup+Γdown), not generally a single-bath equilibrium; nonzero heat currents may persist. Fixed-population effective temperature requires specified Hamiltonian/units and an energy-diagonal noninverted state.
- **wavefunction_stabilization_v1 (#5)** — Ideal correction gives θ'=θ−α and V'=sin²((θ−α)/2), strictly smaller for θ>0, g>0, αmax>0. Gain0 gives identity. Disturbance is followed by correction, so disturbance-driven tracking differs from autonomous convergence. State-dependent feedback assumes exact estimation and ideal rotations; mixed-state spectrum cannot be purified by it. Source's sampled margin is a sampled diagnostic, not a continuum proof.

### JARVIS materials data

- **Identify the dataset before interpreting results** — Fix the input version and population before comparing findings or describing coverage.
- **Preserve the roles of dates** — A supplied label, recorded execution time, later review and public release are different chronological facts.
- **Catalog counts and downloaded counts** — An unreconciled scope difference is a finding to retain, not evidence that the analysis failed to execute.
- **Treat missing data as unknown** — Preserve the missingness mask; unknown values are not measured zeros.
- **Separate count differences from corruption** — An inconsistency can reflect representation rather than data corruption; keep the original and test alternatives.
- **Add a geometric diagnostic without erasing the initial finding** — A stronger interpretation can be appended while retaining the original observation and unresolved cases.
- **Check formulas against atomic composition** — Cross-field agreement is a separate check from array shape and finiteness.
- **A finite tensor is not automatically physically reliable** — Check finiteness, magnitude, units and slab normalization separately before drawing physical conclusions.
- **Do not infer stability from a constant field or one sign** — Constant values supply no ranking, and different physical observables answer different questions.
- **Compare methods on matched records** — A matched comparison controls the sample composition; higher predicted values do not establish greater accuracy.
- **Validate descriptor dimensions and informative columns** — Finiteness is a structural condition; it does not establish predictive value or physical validity.
- **Keep duplicate inputs together during evaluation** — Future splits should group duplicates so repeated inputs do not inflate apparent generalization.
- **Bind descriptor interpretation to its generation revision** — A column mapping and historical generator provenance are separate evidence requirements.
- **Keep transport scaling attached to the quantity** — A correct arithmetic operation can still be scientifically wrong if applied to quantities with incompatible units or normalizations.
- **Interpret error fields narrowly** — Name the reference, observable and population of every error metric.
- **Deterministic replay checks consistency, not physical truth** — Repeatable output supports computational consistency while leaving source anomalies and scientific calibration open.
- **Keep performance measurements within their measurement scope** — Report timing conditions and memory instruments before comparing efficiency.
- **Preserve scientific corrections and derivative identities** — Separate documentary maintenance from scientific changes and keep the earlier observation plus dated interpretation.

### Q8 and USB

- **USB-hosted research software and host computation** — A portable application can be useful without moving the computation off the host. Describe the measured mechanism before naming the achievement.
- **Dense state-vector capacity with explicit workload and memory** — Dense state storage grows with 2^n amplitudes; a stated qubit count needs a representation and a circuit. A capacity demonstration is bounded by what actually ran.
- **Memory admission refusal versus numerical failure** — A guard can correctly stop a run. Teaching the stop condition prevents a safety/resource decision from becoming a false scientific failure.
- **Structured states and the meaning of a large qubit index** — Compression works by using structure. A local numerical threshold does not automatically provide a global error guarantee.
- **Conventional byte prediction and bounded register machine** — Small interpretable models are teaching tools. Their explicit limits make the implementation easier to test and explain.
- **Historical Windows resource observations and correlation** — A real observation is worth preserving even when it cannot establish causation. Report favorable and unfavorable indicators together and identify changing background conditions.
- **Reproducing arithmetic from retained observations** — Reproducible arithmetic and experimental replication answer different questions. Both have value when labeled precisely.
- **Unsigned manifest consistency and variable check durations** — A hash verifies agreement with specified bytes. It does not by itself authenticate who produced them or why a later check was faster.
- **Partial installation, later readback and preserved mistakes** — An earlier incomplete report may be correct at its time. Correct the current summary without deleting that intermediate evidence.
- **Bounded operation from the installed USB environment** — A real runtime success can be narrow. Credit exactly what ran without requiring unrelated tasks to have succeeded, and without promoting it to complete readiness.
- **GAUCIA repair installation versus live conversation readiness** — State must be chronological and stage-specific. A successful installation is meaningful even while a later usable-service check remains open.
- **Reproducible teaching package and remaining source work** — Teach the question, representation, method, checks, unfavorable results and limits together. Reuse a saved review state keyed to source hashes, and revisit only changed inputs or unresolved questions.

