# Priority Zero — corrections and attention

This is an action register for the existing work. A documented issue is not silently converted into a newly fixed implementation, and a failed check is not automatically a failed execution.

| ID | Current status | Required attention | Existing evidence |
|---|---|---|---|
| A01 | Corrected in this compilation | Replace the blanket “original conversations unavailable” statement for the five recovered exports; preserve limits on attachments and semantic review. | Corpus acquisition/inventory receipts and private state index |
| A02 | Corrected in this compilation | The complete RC1 entropy module is retained: 662 lines, 26,285 bytes. Keep the separate C002 successor and missing full Library digest distinct. | PZ-SIM-CORR-01; source SHA-256 5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f |
| A03 | Code work remains | Five version-specific static findings: tiny-error zero-gain contraction acceptance; one-sided thermal-error predicate; ignored decoder normalization option; first-scale labeling; workflow-name membership checks. Prepare a separately identified corrected edition and focused verification before claiming those boundaries fixed. | PZ-SIM-CORR-02; retained depth-audit corrections 3 and 6 |
| A04 | Reproduction assembly remains | Complete pinned dependency/path assembly, output-guard integration and the self-contained JARVIS materials reproduction selection. This compilation does not run or modify the historical calculations. | PZ-SIM-CORR-03; PZ-JARVIS-016 |
| A05 | Scientific interpretation remains open | Keep the catalog population difference, two unresolved geometric cases, formula/tensor/descriptor anomalies and transport conventions visible. Missing values are unknowns. | JARVIS rows 003–015 |
| A06 | Calibration evidence remains bounded | Saved numerical controls, dataset consistency checks and owner-observed correlations do not supply missing physical calibration, independent causal tests or broad material generalization. Retain each statement at its supported evidence level. | Simulation work summaries, JARVIS rows 016–017 and Q8 host-observation rows |
| A07 | Release selection remains open | The frozen 493-file candidate contains protected controller-derived excerpts. A new screened release must exclude the master controller/master node and receive fresh exact-selection approval. | Priority Zero exclusion decision and C23=exclude |
| A08 | USB preservation and live readiness remain open | Library/laptop storage and historic installation receipts do not establish a new USB copy or a currently ready live model/service. Do not repeat denied probes without changed conditions. | Current continuity and Q8 installation/readiness rows |

The unsuccessful attempts remain part of the teaching account: energy checks that missed poor state fidelity, reused-seed contamination, budget stops, a slower first rewrite, below-target speed improvements, and stronger conventional controls. They should be explained alongside successes.

The owner's observed real-world correlations remain explicitly attributed to his observation. No causal or hardware claim is added. The original mistakes and earlier wording remain in their frozen sources and preservation archives.
