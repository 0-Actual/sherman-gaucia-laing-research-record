# Priority Zero — teaching matrix

Prepared 2026-10-16T19:41:24.864573+00:00. Existing work only; owner review edition.

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting reviewer: Codex.

Owner’s dedication: “to God be the glory.” His stated purpose is “to teach humanity.” These words preserve the motivation he gave for this compilation.

This matrix contains **94 overlapping teaching rows**: 64 simulation/mathematics rows, 18 JARVIS materials-data rows and 12 Q8/USB rows. They are lessons and views of existing work, not 94 separate experiments or discoveries. Source dates, later reviews, execution evidence, controls and unresolved corrections remain separate.

Each detailed row preserves the problem → method → recorded result → control/calibration → lesson → remaining attention chain. Exact locators and hashes are in the JSON and the private supporting lane records. No new simulation was run.

| Row | Area | Teaching subject | Lesson |
|---|---|---|---|
| [PZ-SIM-WORK-historical-core](#pz-sim-work-historical-core) | Simulations and mathematics | Recovered historical core function semantics | Names must be matched to the implemented quantity: squared norm is not Hamiltonian energy, and a predicate filter is not quantum measurement. |
| [PZ-SIM-WORK-task-alpha](#pz-sim-work-task-alpha) | Simulations and mathematics | Task Alpha classical three-qubit GHZ emulator | Exact arithmetic and a declared oracle make a bounded emulator testable; exact GHZ output on a classical computer is not physical entanglement. |
| [PZ-SIM-WORK-recovered-math](#pz-sim-work-recovered-math) | Simulations and mathematics | LQCP, entropy and three-qubit corrections | Preserve mathematical meaning, floating-point representability and source identity as separate checks. |
| [PZ-SIM-WORK-jarvis-aluminum](#pz-sim-work-jarvis-aluminum) | Simulations and mathematics | Aluminum VQD assessment and additional points | Mean energy accuracy, eigenstate convergence, runtime and generalization require separate comparisons. |
| [PZ-SIM-WORK-qel-performance](#pz-sim-work-qel-performance) | Simulations and mathematics | QEL compact optimizer performance comparison | A measured gain can coexist with a failed target; cache retrieval must be separated from new computation. |
| [PZ-SIM-WORK-jarvis-local-dependencies](#pz-sim-work-jarvis-local-dependencies) | Simulations and mathematics | JARVIS original local numerical dependencies | An available dependency and an executed dependency are different facts. |
| [PZ-SIM-WORK-generation-a-rc1](#pz-sim-work-generation-a-rc1) | Simulations and mathematics | Generation A 21-capability successor simulation suite and B–D kernel integration | Use domain-specific models and controls; maintain classical signal/field lanes as classical. Do not backdate corrected successors. |
| [PZ-SIM-WORK-live-dense-scaling](#pz-sim-work-live-dense-scaling) | Simulations and mathematics | September 18 dense state-vector workload scaling | State storage, process memory, admission policy and algorithm capacity are different measurements. |
| [PZ-SIM-LEARN-T001](#pz-sim-learn-t001) | Simulations and mathematics | Squared norm called energy in an early dynamics function | Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made. |
| [PZ-SIM-LEARN-T002](#pz-sim-learn-t002) | Simulations and mathematics | Observer naming exceeds the implemented predicate filter | The documentary review separates implementation from the physical implication of the name. |
| [PZ-SIM-LEARN-T003](#pz-sim-learn-t003) | Simulations and mathematics | Guidance routine has random perturbation but no implemented ethical objective | The later review preserves the project attribution but describes the actual perturbation function. |
| [PZ-SIM-LEARN-T005](#pz-sim-learn-t005) | Simulations and mathematics | Greedy gate placement rejected valid plateau-crossing solutions | Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added. |
| [PZ-SIM-LEARN-T012](#pz-sim-learn-t012) | Simulations and mathematics | Mean-square amplitude rescaling was incorrectly associated with coherence | The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function. |
| [PZ-SIM-LEARN-T013](#pz-sim-learn-t013) | Simulations and mathematics | Algebraically equivalent Ramsey evaluation failed reciprocal scales | C001 forms spread*t first, preserving the dimensionless product, then squares it. |
| [PZ-SIM-LEARN-T014](#pz-sim-learn-t014) | Simulations and mathematics | Finite ratio inputs produced infinite outputs | C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value. |
| [PZ-SIM-LEARN-T015](#pz-sim-learn-t015) | Simulations and mathematics | Unknown circuit operation was skipped while the API reported PASS | A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution. |
| [PZ-SIM-LEARN-T016](#pz-sim-learn-t016) | Simulations and mathematics | The corrected v2.1 reference still rejected valid extreme-scale states | v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector. |
| [PZ-SIM-LEARN-T017](#pz-sim-learn-t017) | Simulations and mathematics | Near-one fidelity subtraction lost tiny distances or invented self-distance | v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars. |
| [PZ-SIM-LEARN-T018](#pz-sim-learn-t018) | Simulations and mathematics | Three-qubit normalization accepted zero output after overflow | Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences. |
| [PZ-SIM-LEARN-T019](#pz-sim-learn-t019) | Simulations and mathematics | Entropy uniqueness test confused numerical threshold with mathematical existence | A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero. |
| [PZ-SIM-LEARN-T026](#pz-sim-learn-t026) | Simulations and mathematics | Dense scaling attempt 01 was stopped before any circuit | Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited. |
| [PZ-SIM-LEARN-T027](#pz-sim-learn-t027) | Simulations and mathematics | Dense admission initially counted runtime reserve twice; resident controller also constrained continuation | Child admission used actual post-load free memory; a PowerShell supervisor removed resident Node-controller cost for continuation while retaining the same 256 MiB reserve. |
| [PZ-SIM-LEARN-T028](#pz-sim-learn-t028) | Simulations and mathematics | The dense 22-qubit trial never ran | The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21. |
| [PZ-SIM-LEARN-T029](#pz-sim-learn-t029) | Simulations and mathematics | JARVIS first variational pass missed one of six energy targets | Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02. |
| [PZ-SIM-LEARN-T030](#pz-sim-learn-t030) | Simulations and mathematics | The first adaptive follow-up still missed point 4 | A separately declared 256-sweep follow-up followed. |
| [PZ-SIM-LEARN-T031](#pz-sim-learn-t031) | Simulations and mathematics | The second adaptive follow-up remained above goal | Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters. |
| [PZ-SIM-LEARN-T032](#pz-sim-learn-t032) | Simulations and mathematics | Energy accuracy hid two synthetic fidelity misses | State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study. |
| [PZ-SIM-LEARN-T033](#pz-sim-learn-t033) | Simulations and mathematics | Passing energy did not mean every BFGS start converged | Report separates stopping reason, energy, state residual and fidelity. |
| [PZ-SIM-LEARN-T035](#pz-sim-learn-t035) | Simulations and mathematics | Pass-03 baseline and first Rayleigh repair retained many acceptance misses | The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting. |
| [PZ-SIM-LEARN-T036](#pz-sim-learn-t036) | Simulations and mathematics | Wrong zero-gradient flat starts were mistaken for useful stopping points | Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases. |
| [PZ-SIM-LEARN-T037](#pz-sim-learn-t037) | Simulations and mathematics | A reused seed made one supposed test already solved | Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced. |
| [PZ-SIM-LEARN-T038](#pz-sim-learn-t038) | Simulations and mathematics | Centering cannot recover input information already rounded away | The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits. |
| [PZ-SIM-LEARN-T039](#pz-sim-learn-t039) | Simulations and mathematics | Hybrid target computation limits discovery and quantum-advantage claims | Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity. |
| [PZ-SIM-LEARN-T042](#pz-sim-learn-t042) | Simulations and mathematics | Stage-04 energy-only baseline missed 18 runs and direct solving remained cheaper | Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements. |
| [PZ-SIM-LEARN-T044](#pz-sim-learn-t044) | Simulations and mathematics | Stage 05 target-free protocol was prepared but not executed | Numerical work was set aside for the owner-requested security priority; sources/protocol preserved. |
| [PZ-SIM-LEARN-T047](#pz-sim-learn-t047) | Simulations and mathematics | Low original-path VQD average error concealed unconverged states | Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test. |
| [PZ-SIM-LEARN-T048](#pz-sim-learn-t048) | Simulations and mathematics | Additional aluminum cases retained substantial iteration-budget stops | Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates. |
| [PZ-SIM-LEARN-T049](#pz-sim-learn-t049) | Simulations and mathematics | First allocation rewrite saved memory but increased time 52.1% | The variant was retained but not selected; flat/row probes and later angle-cache implementation followed. |
| [PZ-SIM-LEARN-T050](#pz-sim-learn-t050) | Simulations and mathematics | Flat-array v2 probe remained slower | Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed. |
| [PZ-SIM-LEARN-T051](#pz-sim-learn-t051) | Simulations and mathematics | Row-array v3 probe also remained slower | The variant was retained but not selected; cached trigonometry and compact history became v4. |
| [PZ-SIM-LEARN-T052](#pz-sim-learn-t052) | Simulations and mathematics | Selected performance v4 improved time but missed the 20% target | The selected code retained the measured gain honestly; a later batch checked it again. |
| [PZ-SIM-LEARN-T053](#pz-sim-learn-t053) | Simulations and mathematics | Audit repeat also missed the 20% target | The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain. |
| [PZ-SIM-LEARN-T055](#pz-sim-learn-t055) | Simulations and mathematics | Structured 60-qubit labels require branch, bond and verification limits | The later review states compact representation limits and separates the dense 21-qubit trial results. |
| [PZ-SIM-LEARN-T056](#pz-sim-learn-t056) | Simulations and mathematics | Windows observation changes cannot be promoted to causal USB speedup | The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing. |
| [PZ-SIM-MATH-QEL-SER-M001](#pz-sim-math-qel-ser-m001) | Simulations and mathematics | common_kernel_v1 | Unitary dynamics preserve norm, inner products, global density spectrum and entropy. Kraus closure ΣK_i†K_i=I gives trace preservation; operator-sum form gives complete positivity. Computational coherence is basis-dependent. Unitary motion does not generally converge or erase information. |
| [PZ-SIM-MATH-QEL-SER-M002](#pz-sim-math-qel-ser-m002) | Simulations and mathematics | computational_stability_v1 (#20) | Numerical linear algebra: small residual and small forward error are distinct and linked through conditioning. Exact U hasκ2(U)=1 but floating point repetition accumulates defects. Passing a bounded run does not establish universal numerical stability. |
| [PZ-SIM-MATH-QEL-SER-M003](#pz-sim-math-qel-ser-m003) | Simulations and mathematics | energy_optimization_v1 (#7) | Rayleigh–Ritz E≥λmin(H). Grid optimum is only optimum among evaluated ansatz states; general ground state accessibility is not proved. For H=−(X⊗X+Z⊗Z), Bell-family E=−1−sinθ reaches−2 at θ=π/2. Ground-vector fidelity can depend on the arbitrary eigenvector selected within a degenerate ground eigenspace; energy gap is the invariant quantity. |
| [PZ-SIM-MATH-QEL-SER-M004](#pz-sim-math-qel-ser-m004) | Simulations and mathematics | entropic_balancing_v1 (#18) | Partial SWAP preserves global spectrum and identical-local-H total energy, can create correlations, and is reversible rather than asymptotically mixing. Random SWAP marginal difference contracts by(1−2η), in trace distance by\\|1−2η\\|; for0<η<1 full state converges to(ρ+SWAPρSWAP)/2, depending on initialρ. It does not have a unique global fixed state. η=1 gives swap oscillation;η=1/2 gives one-step marginal equality. |
| [PZ-SIM-MATH-QEL-SER-M005](#pz-sim-math-qel-ser-m005) | Simulations and mathematics | entropy_stabilization_control_v1 (#12) | T(ρ)=aρ+bI/2+cτ, a=(1−η)(1−p), b=(1−η)p,c=η. Unique ρ*=(bI/2+cτ)/(b+c) iff p orη>0; differences contract exactly by a. Unitary transformations preserve entropy; nonunital replacement supplies purification resources. Entropy target does not specify orientation. Original numerical existence gate is incorrect for weak positive channels; C002 corrects it. |
| [PZ-SIM-MATH-QEL-SER-M006](#pz-sim-math-qel-ser-m006) | Simulations and mathematics | error_correction_stabilization_v1 (#3) | Exactly corrects identity plus all15 single-qubit Pauli errors under ideal recovery. Guaranteed correctable probability under independent error probability p is (1−p)^5+5p(1−p)^4. This is an ideal code/noise/recovery simulation, not a new universal correction theorem or an ancilla/latency/fault-tolerance demonstration. |
| [PZ-SIM-MATH-QEL-SER-M007](#pz-sim-math-qel-ser-m007) | Simulations and mathematics | error_mitigation_v1 (#19) | Estimator correction, not state recovery. For p<1/2, inverse coefficients((1−p)/(1−2p),−p/(1−2p)), normΓ=1/(1−2p); L-layer sampling overheadΓ^(2L). Atp=1/2 information is erased and inverse singular; calibration mismatch biases result. Richardson cancels polynomial terms to declared order, not all noise. |
| [PZ-SIM-MATH-QEL-SER-M008](#pz-sim-math-qel-ser-m008) | Simulations and mathematics | field_stabilization_v1 (#6) | E=Δx(pᵀp+qᵀKq)/2. Conservative midpoint preserves quadratic energy in exact arithmetic. Controlled energy accounts for work. Mode frequencies obey ω_k²=m²+4c² sin²(πk/N)/Δx²; leapfrog requires Δtωmax<2 for bounded nondegenerate stable oscillations. With positive damping and restoring stiffness, error modes decay. This is classical finite-difference dynamics, not operator-valued QFT. |
| [PZ-SIM-MATH-QEL-SER-M009](#pz-sim-math-qel-ser-m009) | Simulations and mathematics | noise_reduction_v1 (#17) | Models Hahn/CPMG dynamical decoupling and explicit pulse-error costs. Computational populations remain1/2 for the equatorial memory; coherence and fidelity change. More pulses need not improve W because pulse errors accumulate. Markovian factor is not reversed by this idealized sequence. |
| [PZ-SIM-MATH-QEL-SER-M010](#pz-sim-math-qel-ser-m010) | Simulations and mathematics | phase_synchronization_v1 (#9) | Local zero-detuning small-angle error dynamics involve gI+K L_rw; connectivity governs disagreement, pinning controls global reference mode. Adler equation δdot=Δ−Ksinδ locks for \\|Δ\\|<K; boundary \\|Δ\\|=K has zero linear contraction. Network order parameter1 does not by itself establish lock to the required reference/offsets. Finite noisy simulations are not global convergence proofs. |
| [PZ-SIM-MATH-QEL-SER-M011](#pz-sim-math-qel-ser-m011) | Simulations and mathematics | probability_distribution_control_v1 (#16) | ρ_n−τ=(1−η)^n(ρ0−τ); TV(p_n,p_target)=(1−η)^n TV(p0,p_target). Unique fixed density τ iffη>0; η=0 identity. Same output probabilities need not mean same state, coherence, or phase. Target replacement requires target-description resources, and finite-shot frequencies have sampling error. |
| [PZ-SIM-MATH-QEL-SER-M012](#pz-sim-math-qel-ser-m012) | Simulations and mathematics | resonance_amplification_v1 (#8) | Positive relaxation gives a stable affine equilibrium. p_e≤1/2 in the steady driven model; FWHM=2√(Γ2²+Ω²Γ2/Γ1). Increasing drive produces saturation and power broadening. Closed-system Rabi probability can reach1 but oscillates. This is driven two-level response, not amplitude amplification in Grover's algorithm or unrestricted gain. |
| [PZ-SIM-MATH-QEL-SER-M013](#pz-sim-math-qel-ser-m013) | Simulations and mathematics | signal_integrity_v1 (#11) | Regularized inverse estimation with BER/EVM and gain metrics. No density matrix or quantum channel is used in the core signal path. Complex numbers alone do not make baseband processing quantum. It is a classical signal-estimation mechanism. |
| [PZ-SIM-MATH-QEL-SER-M014](#pz-sim-math-qel-ser-m014) | Simulations and mathematics | state_regeneration_v1 (#4) | Relative logical phase survives inside each coherent flagged branch, allowing recovery. Environment-distinguishable leakage destroys it. Target replacement is state preparation using a known description, not inference of the erased unknown input. |
| [PZ-SIM-MATH-QEL-SER-M015](#pz-sim-math-qel-ser-m015) | Simulations and mathematics | state_reinforcement_v1 (#21) | For target\\|+⟩, H=0, Fdot=(κ+γ)−(κ+2γ)F, so F*= (κ+γ)/(κ+2γ), with exponential observable convergence. Fixed-target pumping erases distinctions among input states. Withκ>0 the benchmark has a unique stationary density; κ=0,γ>0 pure dephasing retains all Z-diagonal populations and has many stationary densities despite F→1/2. Numerical tolerance gate and kernel multiplicity issues remain. |
| [PZ-SIM-MATH-QEL-SER-M016](#pz-sim-math-qel-ser-m016) | Simulations and mathematics | state_stability_v1 (helper) | Checks ordinary quantum unitary invariants and numerical drift. Under common U, \\|\\|Uψ−Uφ\\|\\|=\\|\\|ψ−φ\\|\\| and fidelity is invariant: closed unitary evolution alone cannot contract different states. |
| [PZ-SIM-MATH-QEL-SER-M017](#pz-sim-math-qel-ser-m017) | Simulations and mathematics | state_transition_v1 (#1) | Unitarity and normalization validated; measurement returns one basis state. A user-supplied draw makes simulation replayable; it does not change Born's rule or create measurement-free access to an unknown state. Eigenrays are fixed projectively under their Hamiltonian; generic superpositions oscillate. |
| [PZ-SIM-MATH-QEL-SER-M018](#pz-sim-math-qel-ser-m018) | Simulations and mathematics | superposition_stability_v1 (#15) | q<p for0<p<1/2; q>p for1/2<p<1. Corrects one Z error, not arbitrary single-qubit Pauli error. Parity accumulation p_n=[1−(1−2p)^n]/2. At logical level remaining errors act as a bit flip in the declared logical basis; encoded protection preserves a manifold of arbitrary logical states within the specified noise model. |
| [PZ-SIM-MATH-QEL-SER-M019](#pz-sim-math-qel-ser-m019) | Simulations and mathematics | thermal_regulation_v1 (#10) | Excited population p(t)=p_ss+(p0−p_ss)e^(−Γtotal t), coherence magnitude decays e^(−Γtotal t/2), Gibbs fixed point for one bath. Several baths give p_ss=ΣΓup/Σ(Γup+Γdown), not generally a single-bath equilibrium; nonzero heat currents may persist. Fixed-population effective temperature requires specified Hamiltonian/units and an energy-diagonal noninverted state. |
| [PZ-SIM-MATH-QEL-SER-M020](#pz-sim-math-qel-ser-m020) | Simulations and mathematics | wavefunction_stabilization_v1 (#5) | Ideal correction gives θ'=θ−α and V'=sin²((θ−α)/2), strictly smaller for θ>0, g>0, αmax>0. Gain0 gives identity. Disturbance is followed by correction, so disturbance-driven tracking differs from autonomous convergence. State-dependent feedback assumes exact estimation and ideal rotations; mixed-state spectrum cannot be purified by it. Source's sampled margin is a sampled diagnostic, not a continuum proof. |
| [PZ-JARVIS-001](#pz-jarvis-001) | JARVIS materials data | Identify the dataset before interpreting results | Fix the input version and population before comparing findings or describing coverage. |
| [PZ-JARVIS-002](#pz-jarvis-002) | JARVIS materials data | Preserve the roles of dates | A supplied label, recorded execution time, later review and public release are different chronological facts. |
| [PZ-JARVIS-003](#pz-jarvis-003) | JARVIS materials data | Catalog counts and downloaded counts | An unreconciled scope difference is a finding to retain, not evidence that the analysis failed to execute. |
| [PZ-JARVIS-004](#pz-jarvis-004) | JARVIS materials data | Treat missing data as unknown | Preserve the missingness mask; unknown values are not measured zeros. |
| [PZ-JARVIS-005](#pz-jarvis-005) | JARVIS materials data | Separate count differences from corruption | An inconsistency can reflect representation rather than data corruption; keep the original and test alternatives. |
| [PZ-JARVIS-006](#pz-jarvis-006) | JARVIS materials data | Add a geometric diagnostic without erasing the initial finding | A stronger interpretation can be appended while retaining the original observation and unresolved cases. |
| [PZ-JARVIS-007](#pz-jarvis-007) | JARVIS materials data | Check formulas against atomic composition | Cross-field agreement is a separate check from array shape and finiteness. |
| [PZ-JARVIS-008](#pz-jarvis-008) | JARVIS materials data | A finite tensor is not automatically physically reliable | Check finiteness, magnitude, units and slab normalization separately before drawing physical conclusions. |
| [PZ-JARVIS-009](#pz-jarvis-009) | JARVIS materials data | Do not infer stability from a constant field or one sign | Constant values supply no ranking, and different physical observables answer different questions. |
| [PZ-JARVIS-010](#pz-jarvis-010) | JARVIS materials data | Compare methods on matched records | A matched comparison controls the sample composition; higher predicted values do not establish greater accuracy. |
| [PZ-JARVIS-011](#pz-jarvis-011) | JARVIS materials data | Validate descriptor dimensions and informative columns | Finiteness is a structural condition; it does not establish predictive value or physical validity. |
| [PZ-JARVIS-012](#pz-jarvis-012) | JARVIS materials data | Keep duplicate inputs together during evaluation | Future splits should group duplicates so repeated inputs do not inflate apparent generalization. |
| [PZ-JARVIS-013](#pz-jarvis-013) | JARVIS materials data | Bind descriptor interpretation to its generation revision | A column mapping and historical generator provenance are separate evidence requirements. |
| [PZ-JARVIS-014](#pz-jarvis-014) | JARVIS materials data | Keep transport scaling attached to the quantity | A correct arithmetic operation can still be scientifically wrong if applied to quantities with incompatible units or normalizations. |
| [PZ-JARVIS-015](#pz-jarvis-015) | JARVIS materials data | Interpret error fields narrowly | Name the reference, observable and population of every error metric. |
| [PZ-JARVIS-016](#pz-jarvis-016) | JARVIS materials data | Deterministic replay checks consistency, not physical truth | Repeatable output supports computational consistency while leaving source anomalies and scientific calibration open. |
| [PZ-JARVIS-017](#pz-jarvis-017) | JARVIS materials data | Keep performance measurements within their measurement scope | Report timing conditions and memory instruments before comparing efficiency. |
| [PZ-JARVIS-018](#pz-jarvis-018) | JARVIS materials data | Preserve scientific corrections and derivative identities | Separate documentary maintenance from scientific changes and keep the earlier observation plus dated interpretation. |
| [PZ-Q8-01](#pz-q8-01) | Q8 and USB | USB-hosted research software and host computation | A portable application can be useful without moving the computation off the host. Describe the measured mechanism before naming the achievement. |
| [PZ-Q8-02](#pz-q8-02) | Q8 and USB | Dense state-vector capacity with explicit workload and memory | Dense state storage grows with 2^n amplitudes; a stated qubit count needs a representation and a circuit. A capacity demonstration is bounded by what actually ran. |
| [PZ-Q8-03](#pz-q8-03) | Q8 and USB | Memory admission refusal versus numerical failure | A guard can correctly stop a run. Teaching the stop condition prevents a safety/resource decision from becoming a false scientific failure. |
| [PZ-Q8-04](#pz-q8-04) | Q8 and USB | Structured states and the meaning of a large qubit index | Compression works by using structure. A local numerical threshold does not automatically provide a global error guarantee. |
| [PZ-Q8-05](#pz-q8-05) | Q8 and USB | Conventional byte prediction and bounded register machine | Small interpretable models are teaching tools. Their explicit limits make the implementation easier to test and explain. |
| [PZ-Q8-06](#pz-q8-06) | Q8 and USB | Historical Windows resource observations and correlation | A real observation is worth preserving even when it cannot establish causation. Report favorable and unfavorable indicators together and identify changing background conditions. |
| [PZ-Q8-07](#pz-q8-07) | Q8 and USB | Reproducing arithmetic from retained observations | Reproducible arithmetic and experimental replication answer different questions. Both have value when labeled precisely. |
| [PZ-Q8-08](#pz-q8-08) | Q8 and USB | Unsigned manifest consistency and variable check durations | A hash verifies agreement with specified bytes. It does not by itself authenticate who produced them or why a later check was faster. |
| [PZ-Q8-09](#pz-q8-09) | Q8 and USB | Partial installation, later readback and preserved mistakes | An earlier incomplete report may be correct at its time. Correct the current summary without deleting that intermediate evidence. |
| [PZ-Q8-10](#pz-q8-10) | Q8 and USB | Bounded operation from the installed USB environment | A real runtime success can be narrow. Credit exactly what ran without requiring unrelated tasks to have succeeded, and without promoting it to complete readiness. |
| [PZ-Q8-11](#pz-q8-11) | Q8 and USB | GAUCIA repair installation versus live conversation readiness | State must be chronological and stage-specific. A successful installation is meaningful even while a later usable-service check remains open. |
| [PZ-Q8-12](#pz-q8-12) | Q8 and USB | Reproducible teaching package and remaining source work | Teach the question, representation, method, checks, unfavorable results and limits together. Reuse a saved review state keyed to source hashes, and revisit only changed inputs or unresolved questions. |

## PZ-SIM-WORK-historical-core

**Recovered historical core function semantics**

Dates and roles: Initial Git commit metadata December19 2024; latest snapshot source date separate; October14 2026 observations source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: What do the historical function bodies actually do?

Method: Repeated matrix-vector transformation and squared-norm selection Predicate list filter Random scalar perturbation

Recorded result: Eight saved observations cover nine calls; all eight passed the stated behavior checks. Filtering does not normalize states; the value named energy is squared norm, not Hamiltonian expectation.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Exact pinned snapshots; later observation harness; incomplete overall pipeline

Controls and calibration: Saved deterministic semantic harness: eight observations/nine calls; no complete application or hardware calibration.

Teaching lesson: Names must be matched to the implemented quantity: squared norm is not Hamiltonian energy, and a predicate filter is not quantum measurement.

Attention remaining: Missing QuantumAI, multiagent and encryption components prevent full pipeline reproduction. December 19, 2024 initial commit does not date later source to that day.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-historical-core`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='historical-core']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 1; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.
- [be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/be/be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4>) — collection_id: full-historical-core; logical_path: observation-01.json; SHA-256 `be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4`.
- [ecdfeda77867b96835ed1ae999435c2f0261405ec08292d0bd3a9725e5f73e33](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ec/ecdfeda77867b96835ed1ae999435c2f0261405ec08292d0bd3a9725e5f73e33>) — collection_id: full-historical-core; logical_path: RESULTS.md; SHA-256 `ecdfeda77867b96835ed1ae999435c2f0261405ec08292d0bd3a9725e5f73e33`.

## PZ-SIM-WORK-task-alpha

**Task Alpha classical three-qubit GHZ emulator**

Dates and roles: 2026-08-25T21:25:00-04:00 declared creation; saved receipts source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Can a small circuit have an exact auditable known-answer reference?

Method: Gaussian-integer amplitudes over shared powers of sqrt(2) H, X, Z, S and CNOT GHZ preparation with exact probabilities and fidelity Strict typed workload and purpose-bound integrity checks

Recorded result: Saved 82 policy and 73 workload unit methods; 155 total, with eight paired canonical comparisons separately. GHZ exact fidelity one and probabilities one-half at 000 and 111.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Exact bounded classical three-qubit emulator and policy workload

Controls and calibration: Exact normalization/state/fidelity oracle; 155 test methods and eight separate paired comparisons. Fixed synthetic admission inputs, not hardware calibration.

Teaching lesson: Exact arithmetic and a declared oracle make a bounded emulator testable; exact GHZ output on a classical computer is not physical entanglement.

Attention remaining: Classical simulation of selected Clifford gates; no physical QPU or speedup. Unkeyed source fingerprints are not signatures. Task Alpha is distinct from the earlier 21-capability Generation A integration.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-task-alpha`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='task-alpha']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 2; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.
- [d42c386e992fd52708506d674098804fb5ddc57c546d6ec68d5eed40987de409](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d4/d42c386e992fd52708506d674098804fb5ddc57c546d6ec68d5eed40987de409>) — collection_id: full-task-alpha; logical_path: TASK_ALPHA_CLASSICAL_QPU_EMULATOR_20260825T2125ET_V1_RUN_RECEIPT.sgl.json; SHA-256 `d42c386e992fd52708506d674098804fb5ddc57c546d6ec68d5eed40987de409`.

## PZ-SIM-WORK-recovered-math

**LQCP, entropy and three-qubit corrections**

Dates and roles: Archive label2026-09-04; entropy/three-qubit receipts September5 UTC; recovered/reviewed October14 source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Can historical state, channel and circuit definitions remain valid near numerical boundaries?

Method: Scaled finite complex-vector normalization Projection-residual projective distance Depolarization/replacement fixed point with scaled parameter weights Fixed three semantic qubits with extra carrier modes Circuit API and frozen-result checks

Recorded result: LQCP: 108 inherited + 12 C001 + 22 C002 methods = 142; parent fails 13 of new 22, candidate passes all. Entropy: 13 methods, with subordinate 10 high-precision oracle pairs, 72 channel invariance and 100 seeded density subcases. Three-qubit: 22 methods and separate 504-leaf comparison, maximum change 2.53681827024348e-14. Windows review: 16 focused methods, 13 frozen circuits, 383 existing engine checks; distinct populations.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Separately versioned numerical successors, partial original recovery and bounded Windows circuit review

Controls and calibration: Parent/candidate regression and boundary comparisons; fixed-point high-precision oracle; three-qubit inherited-output comparison. Counts remain separate.

Teaching lesson: Preserve mathematical meaning, floating-point representability and source identity as separate checks.

Attention remaining: LQCP clean-room successor is not exact historical textdoc. Three-qubit reconstruction is 16,248 bytes versus reported original 16,249; original-byte gate remains open. Simulation only; convergence, entropy, phase and carrier size have distinct meanings. Earlier narrower-selection absence wording is superseded: complete 662-line RC1 entropy source is retained; Library full-content identity and standalone C002 successor identity remain distinct.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-recovered-math`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='recovered-math']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 3–6; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.
- [bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/bc/bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/evidence/precision_results.json; SHA-256 `bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115`.
- [d72f96ee0a94d3ecc671006754f9c442ed5493cb27d7c2df7715c0da92628aab](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d7/d72f96ee0a94d3ecc671006754f9c442ed5493cb27d7c2df7715c0da92628aab>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/validation_receipt.json; SHA-256 `d72f96ee0a94d3ecc671006754f9c442ed5493cb27d7c2df7715c0da92628aab`.
- [fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/fb/fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/entropy_results.json; SHA-256 `fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e`.
- [5805511ddcfc73e68e7d8f918c3a52859965c257d9600732fcc9a7446517c771](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/58/5805511ddcfc73e68e7d8f918c3a52859965c257d9600732fcc9a7446517c771>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/WINDOWS_TEST_001_RECEIPT.json; SHA-256 `5805511ddcfc73e68e7d8f918c3a52859965c257d9600732fcc9a7446517c771`.
- [5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/5f/5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f>) — collection_id: august21-successor-integration; logical_path: vendor/rc1/vendor/qel_quantum_entropy_stabilization_control_v1.py; SHA-256 `5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f`.
- [PUBLICATION_CORRECTIONS.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Depth-Review/PUBLICATION_CORRECTIONS.md>) — correction 1; SHA-256 `2b11d1fc5a3028050926292514b11c88a6aa6db767331fe06c65ef09521cc9f9`.

## PZ-SIM-WORK-jarvis-aluminum

**Aluminum VQD assessment and additional points**

Dates and roles: 2026-09-28 local; verification 2026-09-29T01:19:28Z source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Can a three-qubit variational circuit reproduce the specified aluminum spectrum?

Method: Eight-orbital 8x8 Hermitian Hamiltonians at 24 ordered points Three-qubit 18-angle RY/RZ/CNOT ansatz Sequential VQD H_j=H_normalized+4 sum_previous |psi><psi| Two seeded BFGS starts per band, 400 iteration budget, direct adjoint gradients Independent dense/SOP final-state replay and Jacobi control

Recorded result: Original 192 energies: MAE 3.4501989767139057e-6 eV; max error 2.424081433360925e-4 eV; ~20.582 s. Classical control MAE 2.3408413332703937e-9 eV; ~0.911 s; faster and more accurate. Additional 24 points/192 energies: MAE 1.2888900558943352e-6 eV; max error 4.240288216550425e-5 eV; 23.6091527 s. 187/384 original and 239/384 additional starts stop at iteration budget; largest residuals ~0.00524 and ~0.00961 eV.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Classical state-vector VQD assessment of one aluminum Wannier model plus classical control

Controls and calibration: Conventional Jacobi control and independent saved-state reconstruction; original answers previously seen; additional set is same material, not new-material validation.

Teaching lesson: Mean energy accuracy, eigenstate convergence, runtime and generalization require separate comparisons.

Attention remaining: One material, no physical QPU or quantum advantage; historical benchmark answers already seen. Approximately 859-fold score comparison is not rank or matched runtime comparison. Additional points freeze settings/input before fitting but remain same-material coverage. Saved state replay is not a new optimizer run.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-jarvis-aluminum`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='jarvis-aluminum']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 7; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.
- [7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/79/7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1>) — collection_id: full-jarvis-aluminum; logical_path: README.md; SHA-256 `7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1`.
- [c5a847c26b3ae90a1cf058f9693b562dbd05e2efde37db806d3b94395e70005a](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c5/c5a847c26b3ae90a1cf058f9693b562dbd05e2efde37db806d3b94395e70005a>) — collection_id: full-jarvis-aluminum; logical_path: verification.json; SHA-256 `c5a847c26b3ae90a1cf058f9693b562dbd05e2efde37db806d3b94395e70005a`.

## PZ-SIM-WORK-qel-performance

**QEL compact optimizer performance comparison**

Dates and roles: 2026-09-28 local / September 29 UTC saved batch records source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Can implementation cost be reduced without changing the saved answers?

Method: Reuse trigonometric gate values during adjoint traversal Do not retain unused BFGS iteration history Old/new/new/old fresh-process batches Cache tied to input/settings/runtime/source identity

Recorded result: First controlled batch time -17.1%, CPU -15.9%, largest observed process peak -26.8%. Later audit batch time -13.3%, CPU -13.1%, process peak -26.6%. Both batches miss 20% time target; initial allocation rewrite was 52% slower. 192 energies, fitted parameters, attempts, stops and diagnostics match exactly within each batch. Cache valid case accepted and six invalid/stale/corrupt cases rejected; 0.062 s reuse is retrieval, not fresh optimization.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Classical implementation optimization and cache controls on the same VQD workload

Controls and calibration: Two four-process old/new/new/old batches; two observations/version/batch. Live laptop, limited sample; output equivalence checked.

Teaching lesson: A measured gain can coexist with a failed target; cache retrieval must be separated from new computation.

Attention remaining: Two observations per implementation per batch; live laptop, workload-specific. Old-space limit is not total RSS cap; time budget checked between starts. No system-wide Windows performance or physical energy inference.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-qel-performance`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='qel-performance']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 8; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.
- [f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/f0/f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12>) — collection_id: full-qel-performance; logical_path: benchmark-results-v4.json; SHA-256 `f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12`.
- [3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/3f/3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a>) — collection_id: full-qel-performance; logical_path: benchmark-results-audit-v1.json; SHA-256 `3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a`.
- [4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/47/4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f>) — collection_id: full-qel-performance; logical_path: benchmark-results.json; SHA-256 `4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f`.

## PZ-SIM-WORK-jarvis-local-dependencies

**JARVIS original local numerical dependencies**

Dates and roles: Original September 20 private collections; used by later September 28/29 assessment source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Can the saved solver, input and scoring dependencies be reconstructed?

Method: Fixed three-qubit adjoint and separate parameter-shift options BFGS direct optimizer SOP circuit kernel and helpers

Recorded result: Assessment calls direct refineBFGS, not the separate classical-target fastRefine hybrid. Three omitted required files are located in broader original laptop collection; two match exact retained archive members.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Exact local numerical dependencies; includes imported and unused alternative paths

Controls and calibration: Source-identity and dependency recovery evidence; no new numerical execution or physical calibration.

Teaching lesson: An available dependency and an executed dependency are different facts.

Attention remaining: Twenty-five preserved files are not twenty-five executed modules. Availability resolved; portable path assembly remains required.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-jarvis-local-dependencies`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='jarvis-local-dependencies']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 7; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.

## PZ-SIM-WORK-generation-a-rc1

**Generation A 21-capability successor simulation suite and B–D kernel integration**

Dates and roles: August 21 RC1; August 22, 2026 01:01 ET integration report; not March original implementations source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Can similarly named historical capabilities be separated into explicit mathematical models?

Method: Quantum state/unitary/Kraus models, stabilizer codes, target channels, numerical dynamics and estimator mitigation Distinct classical lattice-field, phase-network and OFDM/QPSK domains Generation-aware dispatch and bounded beam gate look-ahead

Recorded result: RC1 report: 1665 domain + 57 integration = 1722 unique unit methods; 21 capability paths, six workflows, 26 gates separately. Kernel report: 87 behavioral + 59 new = 146 methods; 21 saved checkpoint replays. Migration: 8 corrected successors, 12 primitives, 3 intent choices, 8 non-quantum lanes = 31 generation-bound records.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Corrected domain successors and historical behavior reconstructions; exact B–D original bytes remain open

Controls and calibration: Historical RC1 and kernel suites, declared oracles and separate workflow/gate populations; not independent hardware validation.

Teaching lesson: Use domain-specific models and controls; maintain classical signal/field lanes as classical. Do not backdate corrected successors.

Attention remaining: Counts are preserved report/receipt populations, not new execution or independent scientific trials. No new proof audit or physical QPU validation. Later C002 fixes do not silently rewrite RC1 source.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-generation-a-rc1`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='generation-a-rc1']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 9; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.

## PZ-SIM-WORK-live-dense-scaling

**September 18 dense state-vector workload scaling**

Dates and roles: 2026-09-18; final admission observation 23:40:17.343 UTC source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates

Problem: Which dense state-vector sizes completed the declared laptop workload?

Method: Two Float64 arrays, 16*2^n state bytes H/CX GHZ forward/inverse and deterministic full-support four-phase state forward/inverse Serial workers, 256 MiB reserve, 30 s child timeout

Recorded result: 25 PASS trials across sizes 1–21 and one admission stop at 22. Nine checks each: 225 repeated check evaluations. 21 qubits: 2097152 amplitudes, 32 MiB state arrays; median 766.6211 ms for specified validation workload. 22 qubits not executed: 307.7109375 MiB free vs 320 required.

Units and population: Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

Evidence class: Historical laptop experiment in classical state-vector simulation

Controls and calibration: Analytic GHZ and structured full-support forward/inverse controls; 25 trials and 225 repeated checks; 22-qubit admission stopped before allocation.

Teaching lesson: State storage, process memory, admission policy and algorithm capacity are different measurements.

Attention remaining: Largest demonstrated size under current load, not hard maximum, arbitrary algorithm capacity or dense-matrix capacity. 64 MiB old-space setting is not process-memory cap. Attempt 03 null device field retained; other receipts corroborate context.

Review depth: Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-WORK-live-dense-scaling`. Exact source references:

- [WORK_INDEX.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/WORK_INDEX.json>) — works[work_id='live-dense-scaling']; SHA-256 `97dbe41247cdea321dcd308d0139b05aeb68f256129e09b733abca5f9a6bd384`.
- [CONSOLIDATED_QUANTUM_RESEARCH.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/CONSOLIDATED_QUANTUM_RESEARCH.md>) — Computational chapter 10; SHA-256 `f4ee13f5a66f79607691a6df333a4c4b65bdd6c421723e2a3b01b0d57c57be86`.
- [50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/50/50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: READ_ME_RESULTS.md; SHA-256 `50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5`.
- [c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c8/c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_03/result_22_1.json; SHA-256 `c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc`.

## PZ-SIM-LEARN-T001

**Squared norm called energy in an early dynamics function**

Dates and roles: Not specified in this row; follow the recorded source. Function inception not established; source captured and observed October 14, 2026.

Problem: The historical dynamics routine names sum(abs(state)**2) energy and selects returned states using energy_threshold.

Method: Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.

Recorded result: There is no Hamiltonian. A nonunitary scaling example gives norm squared four; rejected output states still feed the next gate. The saved bounded observations reproduce these semantics.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained source semantics/static implementation review; not physical measurement

Controls and calibration: A complete exact early body is retained as exhibit E01. It can be studied as conventional array processing, not evidence of physical energy selection.

Teaching lesson: Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.

Attention remaining: The file inception date and intended original physical contract are not established by the capture date.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T001`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T001']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [3029903ee74c0f2dbc442467910240dd3122b01033242fe5e7260d9c128d6d3f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/30/3029903ee74c0f2dbc442467910240dd3122b01033242fe5e7260d9c128d6d3f>) — collection_id: full-historical-core; logical_path: source/quantum-core/src/sherman_g_laing_dynamics.py; SHA-256 `3029903ee74c0f2dbc442467910240dd3122b01033242fe5e7260d9c128d6d3f`.
- [ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ef/ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00>) — collection_id: full-historical-core; logical_path: SOURCE_REVIEW.md; SHA-256 `ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00`.
- [be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/be/be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4>) — collection_id: full-historical-core; logical_path: observation-01.json; SHA-256 `be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4`.
- [ecdfeda77867b96835ed1ae999435c2f0261405ec08292d0bd3a9725e5f73e33](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ec/ecdfeda77867b96835ed1ae999435c2f0261405ec08292d0bd3a9725e5f73e33>) — collection_id: full-historical-core; logical_path: RESULTS.md; SHA-256 `ecdfeda77867b96835ed1ae999435c2f0261405ec08292d0bd3a9725e5f73e33`.

## PZ-SIM-LEARN-T002

**Observer naming exceeds the implemented predicate filter**

Dates and roles: Not specified in this row; follow the recorded source. Undated historical body; October 14, 2026 source observation.

Problem: The produced observer_effect function retains entries satisfying a supplied predicate.

Method: The documentary review separates implementation from the physical implication of the name.

Recorded result: It preserves order, duplicates and object references; no quantum probability, collapse, renormalization or copied state is implemented.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained source semantics/static implementation review; not physical measurement

Controls and calibration: Complete exact body preserved as E02. This is a semantic limit, not a claim that list filtering malfunctioned.

Teaching lesson: The documentary review separates implementation from the physical implication of the name.

Attention remaining: No missing measurement mechanism is invented.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T002`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T002']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [a07d3847e897dbcf8df9b099f586bd07780a1e0765784e254cdb4c216e8e0924](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/a0/a07d3847e897dbcf8df9b099f586bd07780a1e0765784e254cdb4c216e8e0924>) — collection_id: full-historical-core; logical_path: source/quantum-core/src/observer_effect.py; SHA-256 `a07d3847e897dbcf8df9b099f586bd07780a1e0765784e254cdb4c216e8e0924`.
- [ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ef/ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00>) — collection_id: full-historical-core; logical_path: SOURCE_REVIEW.md; SHA-256 `ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00`.
- [be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/be/be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4>) — collection_id: full-historical-core; logical_path: observation-01.json; SHA-256 `be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4`.

## PZ-SIM-LEARN-T003

**Guidance routine has random perturbation but no implemented ethical objective**

Dates and roles: Not specified in this row; follow the recorded source. Undated body; reviewed October 14, 2026.

Problem: The historical guidance routine probabilistically adds a uniform perturbation between -0.1 and 0.1 to numeric decisions.

Method: The later review preserves the project attribution but describes the actual perturbation function.

Recorded result: The inspected body contains no ethical criterion, probability validation, output clipping or optimization objective; deterministic mocked draws confirm the branch behavior.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained source semantics/static implementation review; not physical measurement

Controls and calibration: Source remains preserved; no claim of learned ethical behavior is supported.

Teaching lesson: The later review preserves the project attribution but describes the actual perturbation function.

Attention remaining: No broader implementation is inferred from this small routine.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T003`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T003']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [826b7929f0bbe026c18856a4214b6bc39a8acd3bad24ac6b39eaa5e36e0b76fb](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/82/826b7929f0bbe026c18856a4214b6bc39a8acd3bad24ac6b39eaa5e36e0b76fb>) — collection_id: full-historical-core; logical_path: source/quantum-core/src/divine_guidance.py; SHA-256 `826b7929f0bbe026c18856a4214b6bc39a8acd3bad24ac6b39eaa5e36e0b76fb`.
- [ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ef/ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00>) — collection_id: full-historical-core; logical_path: SOURCE_REVIEW.md; SHA-256 `ef92eaf291c59e2eb0d129c72fa5d2d5a3d054e446c7df2b76f1e8d5be6c3c00`.
- [be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/be/be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4>) — collection_id: full-historical-core; logical_path: observation-01.json; SHA-256 `be6293643ec22eef06a0658c577cf37c3c25558b9c94c3984641ea3e07a7d5c4`.

## PZ-SIM-LEARN-T005

**Greedy gate placement rejected valid plateau-crossing solutions**

Dates and roles: 2026-08-21 Generation A integration correction cycle; no exact first-failure timestamp.

Problem: The first placer required each individual chosen gate to improve target fidelity.

Method: Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.

Recorded result: |00> to |11> needs two X gates; either first gate alone leaves target fidelity zero, so the one-step rule rejected a valid sequence.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Correction receipt states corrected and retested. This is bounded search, not universal optimizer completeness.

Teaching lesson: Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.

Attention remaining: Exact first greedy body is not separately identified in this selected register; correction receipt and final implementation lineage remain.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T005`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T005']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [0f214ad75bcd223610dce5d3563ff96b1e720a2caf8144050533b7618fbec062](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/0f/0f214ad75bcd223610dce5d3563ff96b1e720a2caf8144050533b7618fbec062>) — collection_id: august21-successor-integration; logical_path: evidence/CORRECTION_001_ADAPTIVE_LOOKAHEAD.json; SHA-256 `0f214ad75bcd223610dce5d3563ff96b1e720a2caf8144050533b7618fbec062`.
- [a9f82e120d880119ec8bc52df5c2bc61922dae43745df898c71d4b50c2268453](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/a9/a9f82e120d880119ec8bc52df5c2bc61922dae43745df898c71d4b50c2268453>) — collection_id: august21-successor-integration; logical_path: evidence/CORRECTION_003_FAIL_CLOSED_TYPES_AND_RECEIPTS.json; SHA-256 `a9f82e120d880119ec8bc52df5c2bc61922dae43745df898c71d4b50c2268453`.
- [5d1917091d88224767845de72f78d3c7dda1d974643c02c3ba78087cfb7e79b6](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/5d/5d1917091d88224767845de72f78d3c7dda1d974643c02c3ba78087cfb7e79b6>) — collection_id: august21-successor-integration; logical_path: evidence/FINAL_VALIDATION_REPORT_V1.json; SHA-256 `5d1917091d88224767845de72f78d3c7dda1d974643c02c3ba78087cfb7e79b6`.

## PZ-SIM-LEARN-T012

**Mean-square amplitude rescaling was incorrectly associated with coherence**

Dates and roles: 2026-09-04 C001 recheck of an older already-corrected model; not the first discovery date.

Problem: Historical Algorithm 13 divided a vector by sqrt(mean(abs(psi)**2)) as a coherence-preservation operation.

Method: The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.

Recorded result: A unit-norm d-dimensional vector then has norm sqrt(d), giving raw probability sum 8 at three qubits. Global rescaling does not establish coherence preservation.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: This was already known before C001; it is not counted as a newly discovered C001 defect.

Teaching lesson: The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.

Attention remaining: The exact original historical text-document bytes remain distinct from the clean-room reference.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T012`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T012']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/fc/fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/C001_REPORT.md; SHA-256 `fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7`.
- [d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d1/d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py; SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`.
- [77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/77/77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/source/qel_lqcp_reference_v2_2.py; SHA-256 `77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3`.

## PZ-SIM-LEARN-T013

**Algebraically equivalent Ramsey evaluation failed reciprocal scales**

Dates and roles: 2026-09-04 C001 checkpoint 20:19 Eastern; September 5 UTC.

Problem: The parent evaluated exp(-0.5*spread*spread*t*t).

Method: C001 forms spread*t first, preserving the dimensionless product, then squares it.

Recorded result: For spread=1e200,t=1e-200 it returned 0 instead of exp(-1/2); reversed scales returned 1; spread=1e200,t=0 produced NaN.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: The corrected v2.1 parent is preserved. C001 reports 108 inherited and 12 boundary methods passing; seven of the 12 boundary methods exposed parent failures.

Teaching lesson: C001 forms spread*t first, preserving the dimensionless product, then squares it.

Attention remaining: The pre-C001 v2 body is described by the retained report but is not separately selected in this C002 register; no arbitrary-precision claim.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T013`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T013']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/fc/fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/C001_REPORT.md; SHA-256 `fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7`.
- [d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d1/d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py; SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`.

## PZ-SIM-LEARN-T014

**Finite ratio inputs produced infinite outputs**

Dates and roles: 2026-09-04 C001 checkpoint date.

Problem: safe_modulation_ratio and coherence_preservation_ratio checked inputs and denominators but not representability of the quotient.

Method: C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.

Recorded result: 1e308/1e-14 returned positive infinity; the signed function could return negative infinity.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Bounded correction passes reported regression/boundary tests, preserving ordinary finite behavior.

Teaching lesson: C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.

Attention remaining: Tiny valid quotients may still underflow to zero; the correction does not guarantee arbitrary relative accuracy.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T014`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T014']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/fc/fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/C001_REPORT.md; SHA-256 `fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7`.
- [d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d1/d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py; SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`.

## PZ-SIM-LEARN-T015

**Unknown circuit operation was skipped while the API reported PASS**

Dates and roles: 2026-09-04 C001 reproduction; isolated Windows candidate checked September 5 UTC.

Problem: executeCircuit validated the configuration but not a separately supplied circuit argument.

Method: A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.

Recorded result: A separate UNKNOWN then MEASURE_Z circuit returned PASS with 10/10 checks; the unknown operation generated zero checks.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Sixteen focused methods passed; 13 frozen circuits retained exact bodies and 383 existing engine checks. Later same-device candidate test recorded separately.

Teaching lesson: A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.

Attention remaining: No evidence says malformed operations occurred in the historical production path, which selected validated configuration circuits; candidate deployment is not inferred.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T015`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T015']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/fc/fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/C001_REPORT.md; SHA-256 `fcce1cb2f3d870ed6ff1e7cc92b381f21f58c4fdf12f93faf7776a175cbe64b7`.
- [c6157430b457693ed968209ab97fc386c93b7cebc9e4ce7e14a651f14a65f8a0](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c6/c6157430b457693ed968209ab97fc386c93b7cebc9e4ce7e14a651f14a65f8a0>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/wf020_core_original.mjs; SHA-256 `c6157430b457693ed968209ab97fc386c93b7cebc9e4ce7e14a651f14a65f8a0`.
- [26f721cbe0c56213d7f0a119c0cf371de1aa18fdf98b9cdae9686b8543e96145](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/26/26f721cbe0c56213d7f0a119c0cf371de1aa18fdf98b9cdae9686b8543e96145>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/wf020_core_candidate.mjs; SHA-256 `26f721cbe0c56213d7f0a119c0cf371de1aa18fdf98b9cdae9686b8543e96145`.
- [5805511ddcfc73e68e7d8f918c3a52859965c257d9600732fcc9a7446517c771](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/58/5805511ddcfc73e68e7d8f918c3a52859965c257d9600732fcc9a7446517c771>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/WINDOWS_TEST_001_RECEIPT.json; SHA-256 `5805511ddcfc73e68e7d8f918c3a52859965c257d9600732fcc9a7446517c771`.

## PZ-SIM-LEARN-T016

**The corrected v2.1 reference still rejected valid extreme-scale states**

Dates and roles: 2026-09-04 C002 began 20:41 Eastern; September 5 UTC.

Problem: v2.1 normalized using a direct Euclidean norm after validation.

Method: v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.

Recorded result: Finite nonzero [1e300,1e300] and [1e-300,1e-300] overflowed/underflowed the direct norm although the normalized direction is ordinary.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Parent fails 13 of 22 new precision methods; candidate passes all 22 plus 108 inherited and 12 earlier methods, 142 total. Full parent retained as E03.

Teaching lesson: v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.

Attention remaining: Extreme relative components can still round to zero; no recovery of information outside the chosen numeric format.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T016`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T016']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d5/d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/REPORT.md; SHA-256 `d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373`.
- [d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d1/d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py; SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`.
- [77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/77/77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/source/qel_lqcp_reference_v2_2.py; SHA-256 `77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3`.
- [bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/bc/bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/evidence/precision_results.json; SHA-256 `bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115`.

## PZ-SIM-LEARN-T017

**Near-one fidelity subtraction lost tiny distances or invented self-distance**

Dates and roles: 2026-09-04 C002 cycle, September 5 UTC execution receipts.

Problem: v2.1 evaluated sqrt(max(0,1-fidelity)).

Method: v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.

Recorded result: It reported about 2.1073424255447017e-8 self-distance for [1+2j,3-4j], while structured perturbations 1e-12 and 1e-300 vanished to zero.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Saved focused examples yield zero self-distance and retain the structured perturbations.

Teaching lesson: v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.

Attention remaining: This does not establish sensitivity to arbitrary 1e-300 changes in general nearly collinear floating-point vectors.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T017`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T017']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d5/d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/REPORT.md; SHA-256 `d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373`.
- [d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d1/d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py; SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`.
- [77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/77/77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/source/qel_lqcp_reference_v2_2.py; SHA-256 `77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3`.
- [bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/bc/bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/evidence/precision_results.json; SHA-256 `bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115`.

## PZ-SIM-LEARN-T018

**Three-qubit normalization accepted zero output after overflow**

Dates and roles: 2026-09-04 C002 source-text reconstruction/correction; historical body inception unresolved.

Problem: The reconstructed validator rejected norm<=tol but did not reject an infinite norm before division; lifted reduction also used a direct norm.

Method: Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.

Recorded result: Huge finite input divided by infinity became a zero vector, and lifted reduction could yield a zero-trace density. Invalid NaN tolerance could permit zero-vector division.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: 22 focused methods pass; 504 inherited numeric leaves differ by at most 2.53681827024348e-14 against 1e-12. Reconstructed parent retained as E04.

Teaching lesson: Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.

Attention remaining: Original exact 16,249-byte object remains unrecovered; results apply to 16,248-byte recovered text.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T018`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T018']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d5/d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/REPORT.md; SHA-256 `d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373`.
- [e7b1b2e34c8edbaaab4c6a59cb60ae2680cc6b12bfb2eb08f19db94dcd456584](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/e7/e7b1b2e34c8edbaaab4c6a59cb60ae2680cc6b12bfb2eb08f19db94dcd456584>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/fixed_three_qubit_scale_source_text_reconstruction.py; SHA-256 `e7b1b2e34c8edbaaab4c6a59cb60ae2680cc6b12bfb2eb08f19db94dcd456584`.
- [e7d4bd4416d3540d501ff58938a853327a6c2b798afc0ef68bb2e14999682c22](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/e7/e7d4bd4416d3540d501ff58938a853327a6c2b798afc0ef68bb2e14999682c22>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/fixed_three_qubit_scale.py; SHA-256 `e7d4bd4416d3540d501ff58938a853327a6c2b798afc0ef68bb2e14999682c22`.
- [d72f96ee0a94d3ecc671006754f9c442ed5493cb27d7c2df7715c0da92628aab](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d7/d72f96ee0a94d3ecc671006754f9c442ed5493cb27d7c2df7715c0da92628aab>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/validation_receipt.json; SHA-256 `d72f96ee0a94d3ecc671006754f9c442ed5493cb27d7c2df7715c0da92628aab`.
- [e4e5f51b9ef4db8f37552ba48ac575da46f81c2e448b152eb5c6d778a750d20b](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/e4/e4e5f51b9ef4db8f37552ba48ac575da46f81c2e448b152eb5c6d778a750d20b>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/source_provenance.json; SHA-256 `e4e5f51b9ef4db8f37552ba48ac575da46f81c2e448b152eb5c6d778a750d20b`.

## PZ-SIM-LEARN-T019

**Entropy uniqueness test confused numerical threshold with mathematical existence**

Dates and roles: 2026-09-04 C002 review and September 5 UTC successor receipt.

Problem: The historical excerpt rejected 1-(1-eta)*(1-p)<=1e-10 as no unique fixed point.

Method: A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.

Recorded result: For p=1e-20,eta=0 the exact fixed point is I/2; for p=0,eta=1e-20 it is tau. Only p=eta=0 is nonunique. Near-one subtraction and unscaled products were numerically fragile.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: 13 methods passed with a 760-digit oracle over ten difficult pairs and separate invariance/generated-density subcases.

Teaching lesson: A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.

Attention remaining: The old missing-full-module statement applies to the narrower historical selection. Complete RC1 source is retained (662 lines, 26,285 bytes); no full Library-object digest is supplied. Mathematical uniqueness is not fast convergence or thermodynamic benefit.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T019`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T019']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d5/d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/REPORT.md; SHA-256 `d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373`.
- [4432ba9052bc038528946943d578675849c9478378bf79d64a52c61cda3dde68](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/44/4432ba9052bc038528946943d578675849c9478378bf79d64a52c61cda3dde68>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/evidence/entropy_source_reads.json; SHA-256 `4432ba9052bc038528946943d578675849c9478378bf79d64a52c61cda3dde68`.
- [9023f7346018aa481baa63d8d808ae5812ae3ae3ae61d778260b63f80d692457](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/90/9023f7346018aa481baa63d8d808ae5812ae3ae3ae61d778260b63f80d692457>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/fixed_point_reference.py; SHA-256 `9023f7346018aa481baa63d8d808ae5812ae3ae3ae61d778260b63f80d692457`.
- [fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/fb/fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e>) — collection_id: full-recovered-math; logical_path: members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/entropy_results.json; SHA-256 `fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e`.
- [5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/5f/5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f>) — collection_id: august21-successor-integration; logical_path: vendor/rc1/vendor/qel_quantum_entropy_stabilization_control_v1.py; SHA-256 `5f0f1cce5a2c6f0c171115f9ee63fa18e6675f12548862fb33cf6c2e5452376f`.
- [PUBLICATION_CORRECTIONS.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Depth-Review/PUBLICATION_CORRECTIONS.md>) — correction 1; SHA-256 `2b11d1fc5a3028050926292514b11c88a6aa6db767331fe06c65ef09521cc9f9`.

## PZ-SIM-LEARN-T026

**Dense scaling attempt 01 was stopped before any circuit**

Dates and roles: 2026-09-18 Attempt day; exact saved timing is in its result object.

Problem: The first dense scaling parent tried to admit a ladder under a 256 MiB reserve plus launch allowance.

Method: Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.

Recorded result: It observed 269,041,664 free bytes, below the parent threshold. No circuit ran.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: unexecuted numerical stage / admission or pause record; not a failed numerical answer

Controls and calibration: Attempt 01 code and result are preserved.

Teaching lesson: Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.

Attention remaining: Not evidence of a numerical defect or hard machine-capacity limit.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T026`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T026']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/50/50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: READ_ME_RESULTS.md; SHA-256 `50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5`.
- [074501c1679f572a4bcb4d3ce255480a32c434f07c95d7dde3e01031d92dbd55](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/07/074501c1679f572a4bcb4d3ce255480a32c434f07c95d7dde3e01031d92dbd55>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_01/LIVE_SCALING_RESULTS.json; SHA-256 `074501c1679f572a4bcb4d3ce255480a32c434f07c95d7dde3e01031d92dbd55`.
- [34607868779f824600895cb10d35785c9359be98ada7478a4a8e733ef8b0fe99](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/34/34607868779f824600895cb10d35785c9359be98ada7478a4a8e733ef8b0fe99>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_01/live_scale.mjs; SHA-256 `34607868779f824600895cb10d35785c9359be98ada7478a4a8e733ef8b0fe99`.

## PZ-SIM-LEARN-T027

**Dense admission initially counted runtime reserve twice; resident controller also constrained continuation**

Dates and roles: 2026-09-18 Attempts 02 and 03 in the same cycle.

Problem: The child admission rule reserved runtime memory after runtime/kernel memory was already reflected in measured free RAM.

Method: Child admission used actual post-load free memory; a PowerShell supervisor removed resident Node-controller cost for continuation while retaining the same 256 MiB reserve.

Recorded result: The later report identifies duplicate reserve accounting. Attempt 02 passed sizes 1–13, then the parent stopped before 14 at 334,376,960 free bytes versus 335,806,464 required.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Attempt 03 continued 14–21. The parent stop and later success are retained as different orchestration states.

Teaching lesson: Child admission used actual post-load free memory; a PowerShell supervisor removed resident Node-controller cost for continuation while retaining the same 256 MiB reserve.

Attention remaining: Memory snapshots vary with other activity; this is not proof of an intrinsic increase in hardware capacity.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T027`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T027']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/50/50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: READ_ME_RESULTS.md; SHA-256 `50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5`.
- [32fd456d19a6c6a076d5d3d0df03b92ac55f63b5895a13857726d613a642548d](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/32/32fd456d19a6c6a076d5d3d0df03b92ac55f63b5895a13857726d613a642548d>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_02/LIVE_SCALING_RESULTS.json; SHA-256 `32fd456d19a6c6a076d5d3d0df03b92ac55f63b5895a13857726d613a642548d`.
- [b8571fb09a873d681c9f34a48fd3b7c57c71de366530e39a98171608f5e4394a](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/b8/b8571fb09a873d681c9f34a48fd3b7c57c71de366530e39a98171608f5e4394a>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_03/LIVE_SCALING_RESULTS.json; SHA-256 `b8571fb09a873d681c9f34a48fd3b7c57c71de366530e39a98171608f5e4394a`.
- [34607868779f824600895cb10d35785c9359be98ada7478a4a8e733ef8b0fe99](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/34/34607868779f824600895cb10d35785c9359be98ada7478a4a8e733ef8b0fe99>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_01/live_scale.mjs; SHA-256 `34607868779f824600895cb10d35785c9359be98ada7478a4a8e733ef8b0fe99`.
- [1e40043c78e9bcd8772203e9b3bbd1b22117ecb452c314254f15390aceddd734](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/1e/1e40043c78e9bcd8772203e9b3bbd1b22117ecb452c314254f15390aceddd734>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_02/live_scale.mjs; SHA-256 `1e40043c78e9bcd8772203e9b3bbd1b22117ecb452c314254f15390aceddd734`.

## PZ-SIM-LEARN-T028

**The dense 22-qubit trial never ran**

Dates and roles: 2026-09-18T23:40:17.343Z Final admission measurement UTC.

Problem: After three successful 21-qubit trials, the driver evaluated admission for 22.

Method: The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.

Recorded result: Required free memory was 335,544,320 bytes including reserve; observed 322,658,304 was short by 12,886,016 bytes.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: unexecuted numerical stage / admission or pause record; not a failed numerical answer

Controls and calibration: Twenty-five completed trials across sizes 1–21 and one stopped child are separate units; no 22-qubit execution is credited.

Teaching lesson: The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.

Attention remaining: A different load/policy could admit another size, but no such new run is asserted.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T028`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T028']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/50/50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: READ_ME_RESULTS.md; SHA-256 `50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5`.
- [c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c8/c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc>) — collection_id: live-dense-qubit-scaling-20260918; logical_path: QEL_Live_Qubit_Scaling_20260918_03/result_22_1.json; SHA-256 `c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc`.

## PZ-SIM-LEARN-T029

**JARVIS first variational pass missed one of six energy targets**

Dates and roles: 2026-09-20 Day stated in original report; first run has separate timestamps.

Problem: Two seeded starts and at most 12 coordinate sweeps attempted six ground-energy cases using the unchanged 18-angle circuit.

Method: Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.

Recorded result: Original point 4 ended 0.0004007142024144983 eV above reference versus a <=0.0001 eV goal; five of six passed.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Original failed point and all other successes remain; no all-targets-passed claim for pass 01.

Teaching lesson: Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.

Attention remaining: The first pass alone did not isolate landscape, expressivity or numerical cause.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T029`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T029']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/9e/9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24>) — collection_id: jarvis-private-01; logical_path: REPORT.md; SHA-256 `9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24`.
- [3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/3d/3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832>) — collection_id: jarvis-private-01; logical_path: compute.mjs; SHA-256 `3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832`.
- [ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ed/ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3>) — collection_id: jarvis-private-02; logical_path: REPORT.md; SHA-256 `ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3`.

## PZ-SIM-LEARN-T030

**The first adaptive follow-up still missed point 4**

Dates and roles: 2026-09-20 Same-day bounded follow-up, exact time not repeated here.

Problem: Four starts and 64 sweeps revisited the already examined original point.

Method: A separately declared 256-sweep follow-up followed.

Recorded result: Energy gap improved to 0.00014289359835650828 eV but exceeded unchanged 0.0001 eV target.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Improvement is retained without reclassifying the miss as a pass or a fresh held-out test.

Teaching lesson: A separately declared 256-sweep follow-up followed.

Attention remaining: This follow-up was run once; no independent deterministic replay is claimed.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T030`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T030']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/9e/9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24>) — collection_id: jarvis-private-01; logical_path: REPORT.md; SHA-256 `9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24`.
- [a2967616983444fb074086f92921f52b36220fe714814b338230fd2cbb827268](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/a2/a2967616983444fb074086f92921f52b36220fe714814b338230fd2cbb827268>) — collection_id: jarvis-private-01; logical_path: FOLLOWUP_CONTRACT.json; SHA-256 `a2967616983444fb074086f92921f52b36220fe714814b338230fd2cbb827268`.

## PZ-SIM-LEARN-T031

**The second adaptive follow-up remained above goal**

Dates and roles: 2026-09-20 Same-day second bounded follow-up.

Problem: Four starts and 256 sweeps revisited point 4.

Method: Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.

Recorded result: Final gap 0.00012074495903213744 eV remained above 0.0001 despite a 69.8676% reduction from the initial gap.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: All four saved warm-start refinements and a cold seeded point-4 check reached the target in the later pass. The 256-sweep miss remains unchanged.

Teaching lesson: Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.

Attention remaining: Adaptive follow-up was not blind or independently replayed; more sweeps alone did not establish convergence.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T031`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T031']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/9e/9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24>) — collection_id: jarvis-private-01; logical_path: REPORT.md; SHA-256 `9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24`.
- [a284badcfa7c52f2e8afa7acaeb336c43d98c79d94779ca210bb1fc476a9f70e](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/a2/a284badcfa7c52f2e8afa7acaeb336c43d98c79d94779ca210bb1fc476a9f70e>) — collection_id: jarvis-private-01; logical_path: FOLLOWUP_STAGE2_CONTRACT.json; SHA-256 `a284badcfa7c52f2e8afa7acaeb336c43d98c79d94779ca210bb1fc476a9f70e`.
- [ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ed/ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3>) — collection_id: jarvis-private-02; logical_path: REPORT.md; SHA-256 `ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3`.
- [f5d31dd83d7e9f1c721000516400a730a9de771ce4074eec029c0983a30513e8](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/f5/f5d31dd83d7e9f1c721000516400a730a9de771ce4074eec029c0983a30513e8>) — collection_id: jarvis-private-02; logical_path: candidate.mjs; SHA-256 `f5d31dd83d7e9f1c721000516400a730a9de771ce4074eec029c0983a30513e8`.

## PZ-SIM-LEARN-T032

**Energy accuracy hid two synthetic fidelity misses**

Dates and roles: 2026-09-20 Pass 02 report and stress receipts.

Problem: Pass 02 evaluated six representable known-spectrum synthetic states with energy and fidelity requirements.

Method: State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.

Recorded result: At gap 1e-6 eV, energy error 5.61226507949274e-8 passed but fidelity 0.9438801949621364 missed 0.9999. At gap 1e-8, energy error 2.762947736350209e-9 passed while fidelity 0.7237052008836223 missed; that case also met gradient tolerance.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Four of six fidelity cases passed; the two misses are substantive negative results, not discarded energy successes.

Teaching lesson: State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.

Attention remaining: Small residual/gradient/energy alone does not identify a unique ground state at a tiny gap.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T032`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T032']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ed/ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3>) — collection_id: jarvis-private-02; logical_path: REPORT.md; SHA-256 `ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3`.
- [d39f3188d17adf7d56cec9e7eb177bc4882c53dc45d98093b95a57d2f013a798](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/d3/d39f3188d17adf7d56cec9e7eb177bc4882c53dc45d98093b95a57d2f013a798>) — collection_id: jarvis-private-02; logical_path: stress_01/summary.json; SHA-256 `d39f3188d17adf7d56cec9e7eb177bc4882c53dc45d98093b95a57d2f013a798`.
- [35cbe416d5b4403657f5449a7561dd60b6c98721382c3ccd3196151bbe98498f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/35/35cbe416d5b4403657f5449a7561dd60b6c98721382c3ccd3196151bbe98498f>) — collection_id: jarvis-private-02; logical_path: LEARNING_RECORD.json; SHA-256 `35cbe416d5b4403657f5449a7561dd60b6c98721382c3ccd3196151bbe98498f`.
- [aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4>) — collection_id: jarvis-private-03; logical_path: runs/study_aggregation_01/summary.json; SHA-256 `aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4`.

## PZ-SIM-LEARN-T033

**Passing energy did not mean every BFGS start converged**

Dates and roles: 2026-09-20 Pass 02 expanded-validation report.

Problem: The 42 ordered cases used two starts each and up to 400 BFGS iterations after warmup.

Method: Report separates stopping reason, energy, state residual and fidelity.

Recorded result: Of 84 starts, 33 reached gradient tolerance and 51 exhausted iteration budget. Largest state residual was 0.0008444199310936169 eV despite all 42 energy targets passing.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: No claim of universal convergence or 84 successful convergence events is retained.

Teaching lesson: Report separates stopping reason, energy, state residual and fidelity.

Attention remaining: Further convergence at larger budgets is not measured by this receipt.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T033`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T033']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ed/ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3>) — collection_id: jarvis-private-02; logical_path: REPORT.md; SHA-256 `ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3`.
- [f5d31dd83d7e9f1c721000516400a730a9de771ce4074eec029c0983a30513e8](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/f5/f5d31dd83d7e9f1c721000516400a730a9de771ce4074eec029c0983a30513e8>) — collection_id: jarvis-private-02; logical_path: candidate.mjs; SHA-256 `f5d31dd83d7e9f1c721000516400a730a9de771ce4074eec029c0983a30513e8`.

## PZ-SIM-LEARN-T035

**Pass-03 baseline and first Rayleigh repair retained many acceptance misses**

Dates and roles: 2026-09-20 Final report recorded 21:01:46.962 UTC; individual study times separate.

Problem: A matched 720-case study compared the previous optimizer, first Rayleigh repair and bracketed revision.

Method: The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.

Recorded result: Baseline passed energy 696/720 but full acceptance 424/720. First repair passed energy 720/720 but full acceptance 681/720: 39 failures remained. All 39 fitted their supplied target accurately; target iteration stalled at a distant lower-bound shift.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Bracketed revision accepted 720/720, gaining 296 over baseline and 39 over first repair with no lost prior pass. One seed-collision control must also be disclosed (T037).

Teaching lesson: The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.

Attention remaining: Finite, partly shared synthetic populations do not prove universal convergence; bracket is floating-point, not interval certified.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T035`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T035']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527>) — collection_id: jarvis-private-03; logical_path: reports/FINAL_CHAT_REPORT_01.json; SHA-256 `aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527`.
- [aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4>) — collection_id: jarvis-private-03; logical_path: runs/study_aggregation_01/summary.json; SHA-256 `aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4`.
- [8215971948269e1b86f843bfd7be4b8de1e62c6c2ec84b22a01670793743b788](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/82/8215971948269e1b86f843bfd7be4b8de1e62c6c2ec84b22a01670793743b788>) — collection_id: jarvis-private-03; logical_path: runs/target_stagnation_analysis_01/summary.json; SHA-256 `8215971948269e1b86f843bfd7be4b8de1e62c6c2ec84b22a01670793743b788`.
- [3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/3d/3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832>) — collection_id: jarvis-private-03; logical_path: numerics/baseline.mjs; SHA-256 `3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832`.
- [7134c5f70fd9055349ad565ded0cc1356d77e602559c87a81197691c8481b54e](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/71/7134c5f70fd9055349ad565ded0cc1356d77e602559c87a81197691c8481b54e>) — collection_id: jarvis-private-03; logical_path: numerics/hybrid.mjs; SHA-256 `7134c5f70fd9055349ad565ded0cc1356d77e602559c87a81197691c8481b54e`.
- [c9b676df814ca7cfe33c04181d96155d32ac5a061b93e42742388f8464735f07](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c9/c9b676df814ca7cfe33c04181d96155d32ac5a061b93e42742388f8464735f07>) — collection_id: jarvis-private-03; logical_path: numerics/bracketed.mjs; SHA-256 `c9b676df814ca7cfe33c04181d96155d32ac5a061b93e42742388f8464735f07`.

## PZ-SIM-LEARN-T036

**Wrong zero-gradient flat starts were mistaken for useful stopping points**

Dates and roles: 2026-09-20 Pass-03 supplemental study.

Problem: Unperturbed circuit fitting began at basis-state flat starts.

Method: Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.

Recorded result: Only 8/64 passed; 56 stopped at zero iterations in wrong states.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: The original 56 misses and corrected finite population are retained.

Teaching lesson: Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.

Attention remaining: This does not establish escape from every stationary point or universal optimizer success.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T036`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T036']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [01436cfddf99aab56d7706d4b1ed35931905e20f3cbf3af71cd89169f11ae963](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/01/01436cfddf99aab56d7706d4b1ed35931905e20f3cbf3af71cd89169f11ae963>) — collection_id: jarvis-private-03; logical_path: runs/supplemental_aggregation_01/summary.json; SHA-256 `01436cfddf99aab56d7706d4b1ed35931905e20f3cbf3af71cd89169f11ae963`.
- [aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527>) — collection_id: jarvis-private-03; logical_path: reports/FINAL_CHAT_REPORT_01.json; SHA-256 `aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527`.
- [c2ac260c1a39eb49ff98b954711013dded1c813a3c9b6b8f56639ae61a07b747](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c2/c2ac260c1a39eb49ff98b954711013dded1c813a3c9b6b8f56639ae61a07b747>) — collection_id: jarvis-private-03; logical_path: numerics/conditioned.mjs; SHA-256 `c2ac260c1a39eb49ff98b954711013dded1c813a3c9b6b8f56639ae61a07b747`.

## PZ-SIM-LEARN-T037

**A reused seed made one supposed test already solved**

Dates and roles: 2026-09-20 Final initialization review within pass 03.

Problem: Matrix-family and optimizer seed reuse made one synthetic initial state nearly identical to the target.

Method: Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.

Recorded result: Initial fidelity was 0.9999999999999993 and parameter maximum difference 4.440892098500626e-16. It supplied an already-solved control, not independent difficulty.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: A separate confirmation began at fidelity 0.09613601511106884 and reached approximately one in 47 iterations. The improvement counts of 296 and 39 remain unchanged.

Teaching lesson: Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.

Attention remaining: The new confirmation does not retroactively make the original case independent.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T037`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T037']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [4411c49d84d3b9713fcd885e45a283f33adf014c0c8ee1072a410029df36344f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/44/4411c49d84d3b9713fcd885e45a283f33adf014c0c8ee1072a410029df36344f>) — collection_id: jarvis-private-03; logical_path: runs/initialization_independence_confirmation_01/initialization_review.json; SHA-256 `4411c49d84d3b9713fcd885e45a283f33adf014c0c8ee1072a410029df36344f`.
- [945580f69d88eddaa0f50ce5068d04e41091f46fa1143fdcb63fb7cc7253e0be](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/94/945580f69d88eddaa0f50ce5068d04e41091f46fa1143fdcb63fb7cc7253e0be>) — collection_id: jarvis-private-03; logical_path: runs/initialization_independence_confirmation_01/summary.json; SHA-256 `945580f69d88eddaa0f50ce5068d04e41091f46fa1143fdcb63fb7cc7253e0be`.
- [a7fd0444211be3266031be0dcb4de36c232dda4389b9bac1e8c2d1fadfdbcf6d](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/a7/a7fd0444211be3266031be0dcb4de36c232dda4389b9bac1e8c2d1fadfdbcf6d>) — collection_id: jarvis-private-03; logical_path: jobs/initialization-independence.mjs; SHA-256 `a7fd0444211be3266031be0dcb4de36c232dda4389b9bac1e8c2d1fadfdbcf6d`.
- [aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527>) — collection_id: jarvis-private-03; logical_path: reports/FINAL_CHAT_REPORT_01.json; SHA-256 `aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527`.

## PZ-SIM-LEARN-T038

**Centering cannot recover input information already rounded away**

Dates and roles: 2026-09-20 Pass-03 affine diagnostic.

Problem: Affine scale/offset transformations were tested before and after conditioning.

Method: The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.

Recorded result: Conditioned targets passed all 45 represented-matrix cases, but three inputs had already lost information. One intended-state fidelity remained about 0.26515785 even though represented-reference fidelity was approximately one.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: All 45 represented-matrix results and the three input-representation limits remain.

Teaching lesson: The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.

Attention remaining: Recovering the intended input would require additional precision or original information, not another claim of pass.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T038`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T038']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [0199fa5b31809e66f208ac47670e059ca7fc527abd410c59f78bdd0353e37079](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/01/0199fa5b31809e66f208ac47670e059ca7fc527abd410c59f78bdd0353e37079>) — collection_id: jarvis-private-03; logical_path: runs/conditioned_affine_diagnostic_01/summary.json; SHA-256 `0199fa5b31809e66f208ac47670e059ca7fc527abd410c59f78bdd0353e37079`.
- [aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527>) — collection_id: jarvis-private-03; logical_path: reports/FINAL_CHAT_REPORT_01.json; SHA-256 `aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527`.
- [c2ac260c1a39eb49ff98b954711013dded1c813a3c9b6b8f56639ae61a07b747](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c2/c2ac260c1a39eb49ff98b954711013dded1c813a3c9b6b8f56639ae61a07b747>) — collection_id: jarvis-private-03; logical_path: numerics/conditioned.mjs; SHA-256 `c2ac260c1a39eb49ff98b954711013dded1c813a3c9b6b8f56639ae61a07b747`.

## PZ-SIM-LEARN-T039

**Hybrid target computation limits discovery and quantum-advantage claims**

Dates and roles: 2026-09-20 Passes03/04 source and reports.

Problem: The hybrid first calculates a target conventionally, then fits the Q8 circuit.

Method: Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.

Recorded result: Source groundTarget and target-projector fitting provide a classical answer construction inside the pipeline. No external answer file is not the same as no classical target.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: This is an actual algorithmic limitation, not evidence that an unassisted-discovery claim was ever independently verified.

Teaching lesson: Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.

Attention remaining: No physical QPU, quantum advantage or universal discovery follows from these software comparisons.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T039`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T039']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [7134c5f70fd9055349ad565ded0cc1356d77e602559c87a81197691c8481b54e](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/71/7134c5f70fd9055349ad565ded0cc1356d77e602559c87a81197691c8481b54e>) — collection_id: jarvis-private-03; logical_path: numerics/hybrid.mjs; SHA-256 `7134c5f70fd9055349ad565ded0cc1356d77e602559c87a81197691c8481b54e`.
- [c9b676df814ca7cfe33c04181d96155d32ac5a061b93e42742388f8464735f07](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c9/c9b676df814ca7cfe33c04181d96155d32ac5a061b93e42742388f8464735f07>) — collection_id: jarvis-private-03; logical_path: numerics/bracketed.mjs; SHA-256 `c9b676df814ca7cfe33c04181d96155d32ac5a061b93e42742388f8464735f07`.
- [aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/aa/aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527>) — collection_id: jarvis-private-03; logical_path: reports/FINAL_CHAT_REPORT_01.json; SHA-256 `aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527`.
- [139f8a995cecdb270b533f08c6dd15f8d07b8e9b91bc19e440296f206a12d8a9](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/13/139f8a995cecdb270b533f08c6dd15f8d07b8e9b91bc19e440296f206a12d8a9>) — collection_id: jarvis-private-04; logical_path: numerics/q8-fast.mjs; SHA-256 `139f8a995cecdb270b533f08c6dd15f8d07b8e9b91bc19e440296f206a12d8a9`.
- [b1f5f0105c8c2c2d4dceb7b4c25ff787719f235a4e809a98ac622a25e3c66d68](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/b1/b1f5f0105c8c2c2d4dceb7b4c25ff787719f235a4e809a98ac622a25e3c66d68>) — collection_id: jarvis-private-04; logical_path: reports/SUBSTANTIVE_HANDOFF.json; SHA-256 `b1f5f0105c8c2c2d4dceb7b4c25ff787719f235a4e809a98ac622a25e3c66d68`.
- [7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/79/7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1>) — collection_id: full-jarvis-aluminum; logical_path: README.md; SHA-256 `7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1`.

## PZ-SIM-LEARN-T042

**Stage-04 energy-only baseline missed 18 runs and direct solving remained cheaper**

Dates and roles: 2026-09-20 Recorded timing populations, final report day.

Problem: Five methods were timed on 24 unique cases, with three repetitions each: 72 runs per method.

Method: Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.

Recorded result: Energy-only accepted 54/72. Old and fast hybrid accepted 72/72, but direct mean solver time of 22.815 ms was cheaper than the fast hybrid mean of 111.487 ms; direct complete requests also beat circuit mode.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: No blanket Q8 speedup over the strongest conventional solver is supported.

Teaching lesson: Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.

Attention remaining: The solver and complete-request populations/timing boundaries differ.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T042`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T042']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [286aaea12be6f374517d9888891347fbe07956ffb3e63cd5c16d8d6f13e6fbca](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/28/286aaea12be6f374517d9888891347fbe07956ffb3e63cd5c16d8d6f13e6fbca>) — collection_id: jarvis-private-04; logical_path: runs/performance_assessment_01/summary.json; SHA-256 `286aaea12be6f374517d9888891347fbe07956ffb3e63cd5c16d8d6f13e6fbca`.
- [16ea93dc638252e87507c83be41e869672bb69c23dbf4b69d8602301dbdddfdf](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/16/16ea93dc638252e87507c83be41e869672bb69c23dbf4b69d8602301dbdddfdf>) — collection_id: jarvis-private-04; logical_path: reports/FRESH_PROCESS_BENCHMARK.json; SHA-256 `16ea93dc638252e87507c83be41e869672bb69c23dbf4b69d8602301dbdddfdf`.
- [b1f5f0105c8c2c2d4dceb7b4c25ff787719f235a4e809a98ac622a25e3c66d68](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/b1/b1f5f0105c8c2c2d4dceb7b4c25ff787719f235a4e809a98ac622a25e3c66d68>) — collection_id: jarvis-private-04; logical_path: reports/SUBSTANTIVE_HANDOFF.json; SHA-256 `b1f5f0105c8c2c2d4dceb7b4c25ff787719f235a4e809a98ac622a25e3c66d68`.

## PZ-SIM-LEARN-T044

**Stage 05 target-free protocol was prepared but not executed**

Dates and roles: 2026-09-21T01:05:22.513Z Exact owner-security-redirection receipt UTC.

Problem: The protocol proposed independent starts and a holdout, target-free solver variants and explicit fidelity/energy acceptance.

Method: Numerical work was set aside for the owner-requested security priority; sources/protocol preserved.

Recorded result: The redirection receipt says PAUSED_BEFORE_NEW_SOLVER_EXECUTION and new_numerical_jobs: 0.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: unexecuted numerical stage / admission or pause record; not a failed numerical answer

Controls and calibration: The planned 72 trials per method and 24 holdout matrices are not credited as observed data.

Teaching lesson: Numerical work was set aside for the owner-requested security priority; sources/protocol preserved.

Attention remaining: A later VQD assessment is a separately versioned study, not proof this protocol ran.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T044`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T044']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [12e0d57fc05f6dcbfd12c20b553ada2b39db936b136c2a2248ee8a05b57e476c](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/12/12e0d57fc05f6dcbfd12c20b553ada2b39db936b136c2a2248ee8a05b57e476c>) — collection_id: jarvis-private-05; logical_path: STUDY_PROTOCOL.json; SHA-256 `12e0d57fc05f6dcbfd12c20b553ada2b39db936b136c2a2248ee8a05b57e476c`.
- [a380964916292eee07002cc4b353483d67f242e812fe3f3c12da18544a383550](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/a3/a380964916292eee07002cc4b353483d67f242e812fe3f3c12da18544a383550>) — collection_id: jarvis-private-05; logical_path: reports/OWNER_SECURITY_REDIRECTION.json; SHA-256 `a380964916292eee07002cc4b353483d67f242e812fe3f3c12da18544a383550`.

## PZ-SIM-LEARN-T047

**Low original-path VQD average error concealed unconverged states**

Dates and roles: 2026-09-28 Approximately 21:20 Eastern assessment.

Problem: One full run fitted 192 states from 384 starts on 24 ordered aluminum path points.

Method: Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.

Recorded result: MAE 3.4501989767139057e-6 eV passed the local goal, but maximum error 0.0002424081433360925 eV and largest residual 0.005244191334342701 eV remained. Of 384 starts, 197 reached gradient tolerance and 187 hit the iteration limit. Two points contributed 94.93% of total absolute error.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: The conventional solver remained both faster (0.911 s versus 20.582 s) and more accurate. No matched timing comparison against the public Qiskit implementation ran.

Teaching lesson: Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.

Attention remaining: Wavefunction convergence, new materials, physical advantage and commercial value are not established.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T047`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T047']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/79/7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1>) — collection_id: full-jarvis-aluminum; logical_path: README.md; SHA-256 `7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1`.
- [ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ed/ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622>) — collection_id: full-jarvis-aluminum; logical_path: run-assessment.mjs; SHA-256 `ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622`.

## PZ-SIM-LEARN-T048

**Additional aluminum cases retained substantial iteration-budget stops**

Dates and roles: 2026-09-28 Approximately 21:28 Eastern separate assessment.

Problem: The unchanged VQD method predicted 192 energies at 24 additional same-material points.

Method: Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.

Recorded result: MAE 1.2888900558943352e-6 eV and maximum error 4.240288216550425e-5 eV passed local goals, but largest residual 0.009607193267454683 eV remained. Of 384 starts, 145 met gradient tolerance and 239 hit the iteration budget.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Useful bounded additional evidence, not an all-convergence success or a new-material test.

Teaching lesson: Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.

Attention remaining: No generalization beyond aluminum or universal convergence is measured.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T048`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T048']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/79/7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1>) — collection_id: full-jarvis-aluminum; logical_path: README.md; SHA-256 `7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1`.
- [ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ed/ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622>) — collection_id: full-jarvis-aluminum; logical_path: run-assessment.mjs; SHA-256 `ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622`.

## PZ-SIM-LEARN-T049

**First allocation rewrite saved memory but increased time 52.1%**

Dates and roles: 2026-09-29T02:12:31.070Z Exact benchmark receipt UTC; September28Eastern.

Problem: Typed-array compact BFGS attempted to reduce resource cost for the same 192-energy workload.

Method: The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.

Recorded result: The old/new/new/old batch had medians of 17,591.91365 ms for baseline and 26,757.5566 ms for candidate: 52.1014548636% slower. CPU time increased 43.0189%; maximum observed process RSS decreased 40.6022%. All 192 energies and parameters matched.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: This is a completed unfavorable performance comparison, not an incorrect numerical answer.

Teaching lesson: The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.

Attention remaining: Two runs per version on one laptop are bounded observations; no total-system memory or electrical-energy claim.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T049`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T049']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/47/4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f>) — collection_id: full-qel-performance; logical_path: benchmark-results.json; SHA-256 `4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f`.
- [b0f518fd42b62eeed969f2806b84822dbe83edef5e7869d454f06f32a4933b3e](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/b0/b0f518fd42b62eeed969f2806b84822dbe83edef5e7869d454f06f32a4933b3e>) — collection_id: full-qel-performance; logical_path: compact-bfgs-typed-v1.mjs; SHA-256 `b0f518fd42b62eeed969f2806b84822dbe83edef5e7869d454f06f32a4933b3e`.
- [1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/1c/1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400>) — collection_id: full-qel-performance; logical_path: README.md; SHA-256 `1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400`.

## PZ-SIM-LEARN-T050

**Flat-array v2 probe remained slower**

Dates and roles: 2026-09-29T02:14:07.020Z Exact focused-probe receipt UTC.

Problem: A flat-array variant tested whether allocation organization improved the same optimizer work.

Method: Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.

Recorded result: Four focused rounds preserved iteration counts and identical output; the baseline/candidate speed ratio of 0.806597963663965 is below one.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: The two baseline observations, 281.2636 and 229.6612 ms, and candidate observations, 332.5347 and 300.8971 ms, remain explicit.

Teaching lesson: Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.

Attention remaining: This focused probe is not the full24-point benchmark and is not an independent material study.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T050`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T050']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [f33affce8825e635d2ce788aea80cff52aa925301496f179cdafbc0a91db3e11](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/f3/f33affce8825e635d2ce788aea80cff52aa925301496f179cdafbc0a91db3e11>) — collection_id: full-qel-performance; logical_path: array-probe-v2.json; SHA-256 `f33affce8825e635d2ce788aea80cff52aa925301496f179cdafbc0a91db3e11`.
- [748e47616c488bc7fc517c5f3528ec0ccc74b746628891fdc7c8db6e8de1a47d](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/74/748e47616c488bc7fc517c5f3528ec0ccc74b746628891fdc7c8db6e8de1a47d>) — collection_id: full-qel-performance; logical_path: compact-bfgs-flat-v2.mjs; SHA-256 `748e47616c488bc7fc517c5f3528ec0ccc74b746628891fdc7c8db6e8de1a47d`.
- [1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/1c/1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400>) — collection_id: full-qel-performance; logical_path: README.md; SHA-256 `1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400`.

## PZ-SIM-LEARN-T051

**Row-array v3 probe also remained slower**

Dates and roles: 2026-09-29T02:15:42.196Z Exact focused-probe receipt UTC.

Problem: A row-array variant attempted another BFGS allocation layout.

Method: The variant was retained but not selected; cached trigonometry and compact history became v4.

Recorded result: Baseline observations were 284.7159 and 234.2065 ms versus candidate 389.8639 and 402.8986 ms; the reported ratio 0.6545748569085952 is below one. Outputs and iteration counts were identical.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: The unfavorable result remains with actual source and receipt.

Teaching lesson: The variant was retained but not selected; cached trigonometry and compact history became v4.

Attention remaining: A focused kernel probe is not full-workload timing.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T051`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T051']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [051946876001cc992c26e34bef73c1616cc69abdd1462154c61e47e920660a4a](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/05/051946876001cc992c26e34bef73c1616cc69abdd1462154c61e47e920660a4a>) — collection_id: full-qel-performance; logical_path: row-probe-v3.json; SHA-256 `051946876001cc992c26e34bef73c1616cc69abdd1462154c61e47e920660a4a`.
- [ac1e36f0bf55f04e354d270d7c59dea0153b44802055b923724081d9b5ddd5a2](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ac/ac1e36f0bf55f04e354d270d7c59dea0153b44802055b923724081d9b5ddd5a2>) — collection_id: full-qel-performance; logical_path: compact-bfgs-rows-v3.mjs; SHA-256 `ac1e36f0bf55f04e354d270d7c59dea0153b44802055b923724081d9b5ddd5a2`.
- [1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/1c/1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400>) — collection_id: full-qel-performance; logical_path: README.md; SHA-256 `1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400`.

## PZ-SIM-LEARN-T052

**Selected performance v4 improved time but missed the 20% target**

Dates and roles: 2026-09-29 Exact UTC is in benchmark-results-v4.json; local September 28.

Problem: The selected angle-cache and compact-history implementation targeted at least 20% less calculation time.

Method: The selected code retained the measured gain honestly; a later batch checked it again.

Recorded result: The four-process old/new/new/old batch decreased median time from 17.8700468 s to 14.8067205 s, a 17.14223994% reduction; target_passed is false. All 192 energies and parameters were identical.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: Useful improvement and a failed target are both true; neither erases the other.

Teaching lesson: The selected code retained the measured gain honestly; a later batch checked it again.

Attention remaining: This is not a guaranteed fixed percentage; startup is excluded.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T052`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T052']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/f0/f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12>) — collection_id: full-qel-performance; logical_path: benchmark-results-v4.json; SHA-256 `f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12`.
- [ffc7c28235dc400f769e9f52a1e55fb665477b753d51aba808e71efb266790e1](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/ff/ffc7c28235dc400f769e9f52a1e55fb665477b753d51aba808e71efb266790e1>) — collection_id: full-qel-performance; logical_path: compact-bfgs.mjs; SHA-256 `ffc7c28235dc400f769e9f52a1e55fb665477b753d51aba808e71efb266790e1`.
- [4b792d890394c11f6889f2aa40e26bf69aec205d7b3bcac3b6e157624fcce9bb](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/4b/4b792d890394c11f6889f2aa40e26bf69aec205d7b3bcac3b6e157624fcce9bb>) — collection_id: full-qel-performance; logical_path: cached-adjoint.mjs; SHA-256 `4b792d890394c11f6889f2aa40e26bf69aec205d7b3bcac3b6e157624fcce9bb`.
- [1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/1c/1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400>) — collection_id: full-qel-performance; logical_path: README.md; SHA-256 `1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400`.

## PZ-SIM-LEARN-T053

**Audit repeat also missed the 20% target**

Dates and roles: 2026-09-29 UTC receipt; local September 28 late evening.

Problem: A second four-process batch repeated the accepted comparison.

Method: The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.

Recorded result: Median time decreased from 18.52155325 s to 16.04999345 s, a 13.34423613% reduction; target_passed is false with identical 192 energies and parameters.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained historical numerical/software result described by a source-linked review

Controls and calibration: The second miss is retained separately from the first; neither becomes numerous independent studies.

Teaching lesson: The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.

Attention remaining: Small live-laptop sample; no causal Windows-wide effect.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T053`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T053']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/3f/3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a>) — collection_id: full-qel-performance; logical_path: benchmark-results-audit-v1.json; SHA-256 `3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a`.
- [1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/1c/1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400>) — collection_id: full-qel-performance; logical_path: README.md; SHA-256 `1cee38c5b1da5790abff93057628059c278ab59b6fd4f9644d46d3f8e53fe400`.

## PZ-SIM-LEARN-T055

**Structured 60-qubit labels require branch, bond and verification limits**

Dates and roles: Not specified in this row; follow the recorded source. Implementation date unresolved; retained later Q8 snapshot and current static review.

Problem: The SOP/MPS bridge represents selected product and GHZ states up to 60 indexed qubits.

Method: The later review states compact representation limits and separates the dense 21-qubit trial results.

Recorded result: SOP caps branches at 64 and throws before overflow. The bridge MPS bond cap is 32, with a local QR omission threshold of 1e-13. Verification uses three selected amplitude witnesses plus norm, not all 2^60 amplitudes.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: retained source semantics/static implementation review; not physical measurement

Controls and calibration: These are implementation boundaries, not proof that 60 physical qubits or arbitrary dense 60-qubit states were executed.

Teaching lesson: The later review states compact representation limits and separates the dense 21-qubit trial results.

Attention remaining: Full historical benchmark-to-version linkage remains limited; the local QR threshold is not a global error certificate.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T055`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T055']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [68d4f51bada186064abef80cb1dba8f5a41a546aae6ead1c8add819583ce5964](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/68/68d4f51bada186064abef80cb1dba8f5a41a546aae6ead1c8add819583ce5964>) — collection_id: structured-state-research-implementation; logical_path: original/engine/qel60_sop.mjs; SHA-256 `68d4f51bada186064abef80cb1dba8f5a41a546aae6ead1c8add819583ce5964`.
- [b006ec5c202b629b6ba42eb058f4a752d63faa18bf0ce702dc3855d4fe1b4fac](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/b0/b006ec5c202b629b6ba42eb058f4a752d63faa18bf0ce702dc3855d4fe1b4fac>) — collection_id: structured-state-research-implementation; logical_path: original/engine/qel60_mps.mjs; SHA-256 `b006ec5c202b629b6ba42eb058f4a752d63faa18bf0ce702dc3855d4fe1b4fac`.
- [c1c39f2306776bf4617794faaaa0d8d6a7098055fd97b47bd933c0edc0a99c5d](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/quantum-consolidation/private-package/objects/c1/c1c39f2306776bf4617794faaaa0d8d6a7098055fd97b47bd933c0edc0a99c5d>) — collection_id: structured-state-research-implementation; logical_path: original/engine/quantum_bridge.mjs; SHA-256 `c1c39f2306776bf4617794faaaa0d8d6a7098055fd97b47bd933c0edc0a99c5d`.
- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/q8-usb-publication-review/claims/claims.json>) — collection_id: current-documentary-review; logical_path: q8-usb-publication-review/claims.json; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.

## PZ-SIM-LEARN-T056

**Windows observation changes cannot be promoted to causal USB speedup**

Dates and roles: 2026-09-29 Three original UTC observation windows; documentary review October 16.

Problem: Three windows recorded Windows resource counters and then checked the USB package.

Method: The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.

Recorded result: 990 readings (3 × 11 × 30) yield 33 means. In all three windows, the last counter precedes USB verification. Checks took 12.5676291, 1.620652 and 9.3315077 seconds against 40 declared files.

Units and population: As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

Evidence class: historical host-counter observations; causal attribution not established

Controls and calibration: Observed resource changes are preserved; no controlled Windows-wide causal estimate is inferred.

Teaching lesson: The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.

Attention remaining: Background activity, cache effects and storage-placement causality were not isolated. No new measurements.

Review depth: Complete structured case read; exact source identities linked; historical results not rerun.

Source-row identity: `simulation-rows.json` / `PZ-SIM-LEARN-T056`. Exact source references:

- [records.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Research-Learning-History/technical/records.json>) — records[id='T056']; SHA-256 `ca69128c6c212deb744a5d06ca4fbd5ac1c7cfb0b20c06ec72a53730daf43849`.
- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/work/q8-usb-publication-review/claims/claims.json>) — collection_id: current-documentary-review; logical_path: q8-usb-publication-review/claims.json; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [counter-readings.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/observations/counter-readings.json>) — collection_id: current-documentary-review; logical_path: q8-usb-publication-review/observations/counter-readings.json; SHA-256 `1c90c38ad439569cfc664de51e838201191bc14072514784ff68e92c82b88643`.

## PZ-SIM-MATH-QEL-SER-M001

**common_kernel_v1**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Normalized ψ∈C^(2^n); density ρ≥0, Trρ=1; Uψ, U=e^(−iHt/ℏ); p_i=\|ψ_i\|²; Kraus maps ΣK_iρK_i†; partial trace; S(ρ)=−Trρlog₂ρ; concurrence2\|ad−bc\|; negativity from partial-transpose eigenvalues.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Unitary dynamics preserve norm, inner products, global density spectrum and entropy. Kraus closure ΣK_i†K_i=I gives trace preservation; operator-sum form gives complete positivity. Computational coherence is basis-dependent. Unitary motion does not generally converge or erase information.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M001`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M001']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M002

**computational_stability_v1 (#20)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Matrix conditioningκ(A), Hermiticity/unitarity defects, repeated vs direct e^(−iHt), norm/probability conservation, SVD-backed least squares and normalized residual.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Numerical linear algebra: small residual and small forward error are distinct and linked through conditioning. Exact U hasκ2(U)=1 but floating point repetition accumulates defects. Passing a bounded run does not establish universal numerical stability.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M002`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M002']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M003

**energy_optimization_v1 (#7)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Variational minimization E(θ)=⟨ψ(θ)\|H\|ψ(θ)⟩ over explicit finite grids, compared to `eigh(H)`. Product RY and Bell-family ansätze are explicit.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Rayleigh–Ritz E≥λmin(H). Grid optimum is only optimum among evaluated ansatz states; general ground state accessibility is not proved. For H=−(X⊗X+Z⊗Z), Bell-family E=−1−sinθ reaches−2 at θ=π/2. Ground-vector fidelity can depend on the arbitrary eigenvector selected within a degenerate ground eigenspace; energy gap is the invariant quantity.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M003`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M003']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M004

**entropic_balancing_v1 (#18)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Partial SWAP Uθ=cosθ I−i sinθ SWAP; random-SWAP channel Tη=(1−η)Id+η Ad_SWAP; separate open replacement toward a declared bipartite target.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Partial SWAP preserves global spectrum and identical-local-H total energy, can create correlations, and is reversible rather than asymptotically mixing. Random SWAP marginal difference contracts by(1−2η), in trace distance by\|1−2η\|; for0<η<1 full state converges to(ρ+SWAPρSWAP)/2, depending on initialρ. It does not have a unique global fixed state. η=1 gives swap oscillation;η=1/2 gives one-step marginal equality.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M004`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M004']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M005

**entropy_stabilization_control_v1 (#12)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Qubit depolarization D_p(ρ)=(1−p)ρ+pI/2, followed by replacement C_η(ρ)=(1−η)ρ+ητ. Target τ selected by binary entropy inversion plus Bloch axis.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: T(ρ)=aρ+bI/2+cτ, a=(1−η)(1−p), b=(1−η)p,c=η. Unique ρ*=(bI/2+cτ)/(b+c) iff p orη>0; differences contract exactly by a. Unitary transformations preserve entropy; nonunital replacement supplies purification resources. Entropy target does not specify orientation. Original numerical existence gate is incorrect for weak positive channels; C002 corrects it.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M005`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M005']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M006

**error_correction_stabilization_v1 (#3)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Five-qubit [[5,1,3]] stabilizer code; projector P=Π_j(I+S_j)/2; encode one qubit; syndrome projection and Pauli recovery R(ρ)=Σ_s C_sP_sρP_sC_s†. Knill–Laflamme blocks V†E_a†E_bV are tested against scalar identity.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Exactly corrects identity plus all15 single-qubit Pauli errors under ideal recovery. Guaranteed correctable probability under independent error probability p is (1−p)^5+5p(1−p)^4. This is an ideal code/noise/recovery simulation, not a new universal correction theorem or an ancilla/latency/fault-tolerance demonstration.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M006`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M006']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M007

**error_mitigation_v1 (#19)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Readout confusion-matrix inversion; Richardson extrapolation weights Σ_jc_j s_j^k=δ_k0; signed inverse-channel quasi-probabilities for bit/phase flips; symmetry postselection.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Estimator correction, not state recovery. For p<1/2, inverse coefficients((1−p)/(1−2p),−p/(1−2p)), normΓ=1/(1−2p); L-layer sampling overheadΓ^(2L). Atp=1/2 information is erased and inverse singular; calibration mismatch biases result. Richardson cancels polynomial terms to declared order, not all noise.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M007`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M007']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M008

**field_stabilization_v1 (#6)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Classical lattice quadratures q,p∈R^N; K=m²I−c²Δ_d; qdot=p, pdot=−Kq+u+f; PD tracking u=kp(qt−q)+kd(pt−p); implicit midpoint step; optional zero-mode projection.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static description of a classical model

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: E=Δx(pᵀp+qᵀKq)/2. Conservative midpoint preserves quadratic energy in exact arithmetic. Controlled energy accounts for work. Mode frequencies obey ω_k²=m²+4c² sin²(πk/N)/Δx²; leapfrog requires Δtωmax<2 for bounded nondegenerate stable oscillations. With positive damping and restoring stiffness, error modes decay. This is classical finite-difference dynamics, not operator-valued QFT.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M008`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M008']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M009

**noise_reduction_v1 (#17)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Gaussian Ornstein–Uhlenbeck detuning C(t,s)=σ²e^(−\|t−s\|/τc); toggling pulse function y(t); Varφ=∫∫y(t)y(s)C(t,s)dtds; coherence W=e^(−Varφ/2)e^(−γT)(1−4p_pulse/3)^N.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Models Hahn/CPMG dynamical decoupling and explicit pulse-error costs. Computational populations remain1/2 for the equatorial memory; coherence and fidelity change. More pulses need not improve W because pulse errors accumulate. Markovian factor is not reversed by this idealized sequence.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M009`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M009']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M010

**phase_synchronization_v1 (#9)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Classical phase network θdot_i=ω_i+noise_i+(K/d_i)ΣAij sin[(θ_j−offset_j)−(θ_i−offset_i)]−g sin(θ_i−ω_ref t−offset_i). Equatorial states connect phase error to fidelity (1+cosδ)/2.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static description of a classical model

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Local zero-detuning small-angle error dynamics involve gI+K L_rw; connectivity governs disagreement, pinning controls global reference mode. Adler equation δdot=Δ−Ksinδ locks for \|Δ\|<K; boundary \|Δ\|=K has zero linear contraction. Network order parameter1 does not by itself establish lock to the required reference/offsets. Finite noisy simulations are not global convergence proofs.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M010`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M010']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M011

**probability_distribution_control_v1 (#16)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: p∈simplex, amplitude preparation ψ_i=√p_i e^(iφ_i); known-target unitary completion; replacement Tη(ρ)=(1−η)ρ+ητ with diagonal or coherent τ.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: ρ_n−τ=(1−η)^n(ρ0−τ); TV(p_n,p_target)=(1−η)^n TV(p0,p_target). Unique fixed density τ iffη>0; η=0 identity. Same output probabilities need not mean same state, coherence, or phase. Target replacement requires target-description resources, and finite-shot frequencies have sampling error.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M011`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M011']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M012

**resonance_amplification_v1 (#8)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Optical Bloch affine ODE rdot=Ar+b, Γ2=Γ1/2+Γφ. Driven population p_e=Ω²Γ2/[2(Γ1(Δ²+Γ2²)+Ω²Γ2)].

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Positive relaxation gives a stable affine equilibrium. p_e≤1/2 in the steady driven model; FWHM=2√(Γ2²+Ω²Γ2/Γ1). Increasing drive produces saturation and power broadening. Closed-system Rabi probability can reach1 but oscillates. This is driven two-level response, not amplitude amplification in Grover's algorithm or unrestricted gain.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M012`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M012']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M013

**signal_integrity_v1 (#11)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Classical QPSK mapping, OFDM FFT/IFFT and cyclic prefix; multipath/AWGN/carrier-offset model; estimated channel equalization z_k=H*_k y_k/(\|H_k\|²+λ median\|H\|²).

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static description of a classical model

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Regularized inverse estimation with BER/EVM and gain metrics. No density matrix or quantum channel is used in the core signal path. Complex numbers alone do not make baseband processing quantum. It is a classical signal-estimation mechanism.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M013`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M013']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M014

**state_regeneration_v1 (#4)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Logical qubit embedded in a 4D code/leakage space. Flagged leakage uses E0=√(1−p)P+Q, E1=√pV_leak V_code†. Recovery uses P and V_code V_leak†. Separate target replacement uses K_i=\|ψ_target⟩⟨i\|.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Relative logical phase survives inside each coherent flagged branch, allowing recovery. Environment-distinguishable leakage destroys it. Target replacement is state preparation using a known description, not inference of the erased unknown input.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M014`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M014']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M015

**state_reinforcement_v1 (#21)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: GKSL generator Lρ=−i[H,ρ]+Σ(JρJ†−{J†J,ρ}/2), with Jpump=√κ\|target⟩⟨orthogonal\| and Jnoise=√γ Z.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: For target\|+⟩, H=0, Fdot=(κ+γ)−(κ+2γ)F, so F*= (κ+γ)/(κ+2γ), with exponential observable convergence. Fixed-target pumping erases distinctions among input states. Withκ>0 the benchmark has a unique stationary density; κ=0,γ>0 pure dephasing retains all Z-diagonal populations and has many stationary densities despite F→1/2. Numerical tolerance gate and kernel multiplicity issues remain.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M015`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M015']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M016

**state_stability_v1 (helper)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Tensor products, operator sequences/inverses, repeated U†U cycles, substep composition, perturbation distances.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Checks ordinary quantum unitary invariants and numerical drift. Under common U, \|\|Uψ−Uφ\|\|=\|\|ψ−φ\|\| and fidelity is invariant: closed unitary evolution alone cannot contract different states.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M016`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M016']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M017

**state_transition_v1 (#1)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Explicit basis/custom/uniform state preparation, Hamiltonian exponentiation, unitary transition and inverse-CDF projective measurement.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Unitarity and normalization validated; measurement returns one basis state. A user-supplied draw makes simulation replayable; it does not change Born's rule or create measurement-free access to an unknown state. Eigenrays are fixed projectively under their Hamiltonian; generic superpositions oscillate.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M017`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M017']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M018

**superposition_stability_v1 (#15)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Three-qubit phase-flip repetition code \|0L⟩=\|+++⟩, \|1L⟩=\|−−−⟩; ideal syndrome recovery. Logical error q=3p²−2p³ under independent physical Z-flips.

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: q<p for0<p<1/2; q>p for1/2<p<1. Corrects one Z error, not arbitrary single-qubit Pauli error. Parity accumulation p_n=[1−(1−2p)^n]/2. At logical level remaining errors act as a bit flip in the declared logical basis; encoded protection preserves a manifold of arbitrary logical states within the specified noise model.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M018`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M018']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M019

**thermal_regulation_v1 (#10)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: Two-level Gibbs state e^(−H/kBT)/Z; bath rates Γup=γnbar, Γdown=γ(nbar+1), nbar=(e^(gap/kBT)−1)^−1. Generalized amplitude damping with λ=1−e^(−Γtotal t).

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Excited population p(t)=p_ss+(p0−p_ss)e^(−Γtotal t), coherence magnitude decays e^(−Γtotal t/2), Gibbs fixed point for one bath. Several baths give p_ss=ΣΓup/Σ(Γup+Γdown), not generally a single-bath equilibrium; nonzero heat currents may persist. Fixed-population effective temperature requires specified Hamiltonian/units and an energy-diagonal noninverted state.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M019`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M019']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-SIM-MATH-QEL-SER-M020

**wavefunction_stabilization_v1 (#5)**

Dates and roles: Not specified in this row; follow the recorded source. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

Problem: Identify the actual mechanism and its domain/assumptions behind the historical capability label.

Method: One-qubit Bloch geometry with exact state estimate. Let θ be angular distance to target; apply α=min(gθ,αmax,θ) about the minimal correction axis. V=1−F=sin²(θ/2).

Recorded result: Not specified in this row; follow the recorded source.

Units and population: No independent experiment population or execution metric is asserted by this static mechanism row.

Evidence class: static mathematical/source-analysis description of a classical quantum simulation

Controls and calibration: Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

Teaching lesson: Ideal correction gives θ'=θ−α and V'=sin²((θ−α)/2), strictly smaller for θ>0, g>0, αmax>0. Gain0 gives identity. Disturbance is followed by correction, so disturbance-driven tracking differs from autonomous convergence. State-dependent feedback assumes exact estimation and ideal rotations; mixed-state spectrum cannot be purified by it. Source's sampled margin is a sampled diagnostic, not a continuum proof.

Attention remaining: Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

Review depth: Complete structured mechanism and boundary read; not a repeated proof or code audit.

Source-row identity: `simulation-rows.json` / `PZ-SIM-MATH-QEL-SER-M020`. Exact source references:

- [mathematical-mechanisms.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/supplements/mathematical-mechanisms.json>) — rows[id='QEL-SER-M020']; SHA-256 `7df38c9e9f01a5bae9a5c6609f5b15beeac8bb0446d9d798d1d2193a6cc65347`.

## PZ-JARVIS-001

**Identify the dataset before interpreting results**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Keep the exact acquired data population distinct from the whole JARVIS program.

Method: The historical study inspected the selected Figshare version-8 archive and traversed the acquired snapshot.

Recorded result: 1,103 records, 65 top-level fields and 1,861,469 scalar-leaf occurrences; linked raw archives downloaded for this census: 0.

Units and population: population: One acquired JARVIS-DFT 2D snapshot, not every JARVIS dataset or linked calculation.; units: records top-level fields scalar-leaf occurrences downloaded archives

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Fix the input version and population before comparing findings or describing coverage.

Attention remaining: The raw input archive and analysis code are outside this public companion; no claim of new DFT, quantum-circuit simulation, discovery or hardware validation.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-001`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /source; /scope; /interpretation_limits; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [README.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/README.md>) — Source, attribution, and license scope; SHA-256 `87663d1b3a58d248856ae92743a2bd575200d214631760420601cba9d8ff8a81`.

## PZ-JARVIS-002

**Preserve the roles of dates**

Dates and roles: value: 2026-09-18T01:11:34.580384+00:00; role: historical analysis execution timestamp as reported by the saved receipt; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: An owner-supplied clock label could be mistaken for execution or publication time.

Method: Retain the literal label while using separately recorded UTC run and replay times.

Recorded result: Owner label: 9:15 p.m. EST. Analysis: 2026-09-18T01:11:34.580384+00:00; replay: 2026-09-18T01:12:03.433950+00:00; byte-comparison verification: 2026-09-18T01:13:42.423869+00:00.

Units and population: population: One historical inspection and its replay.; units: timestamps verbatim owner label

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: A supplied label, recorded execution time, later review and public release are different chronological facts.

Attention remaining: Do not backdate execution, public disclosure or early project origins from the label; neither timestamp is presented as independently signed.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-002`. Exact source references:

- [replay_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/replay_evidence.json>) — /owner_supplied_time_literal; /time_note; /final_analysis_run/execution_utc; /replay_run/execution_utc; /replay_verification/verified_utc; SHA-256 `5f7dbb7d5a821ca6a54203c2cf770842d9b7405b8c621c7d0bc34e44d0b0c907`.

## PZ-JARVIS-003

**Catalog counts and downloaded counts**

Dates and roles: value: 2026-09-18T01:11:34.580384+00:00; role: historical analysis execution timestamp as reported by the saved receipt; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: The catalog count and downloaded file population differ.

Method: Count source records and distinct identifiers, then compare the recorded catalog population.

Recorded result: 1,103 records and 1,103 distinct IDs in the archive versus 1,109 catalog-listed records; catalog_count_matches_download is false.

Units and population: population: Selected archive and catalog count captured at the historical review.; units: records distinct record IDs

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: An unreconciled scope difference is a finding to retain, not evidence that the analysis failed to execute.

Attention remaining: Cause of the catalog/file difference remains unresolved; do not invent six missing rows or merge a different dataset version.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-003`. Exact source references:

- [replay_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/replay_evidence.json>) — /catalog_records; /measured_records; /distinct_jids; /checks/catalog_count_matches_download; SHA-256 `5f7dbb7d5a821ca6a54203c2cf770842d9b7405b8c621c7d0bc34e44d0b0c907`.
- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /retained_observations/catalog_difference_explanation; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.

## PZ-JARVIS-004

**Treat missing data as unknown**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Absent targets and properties can distort summaries if silently filled.

Method: Classify missing exfoliation values separately from numeric values and profile all top-level fields.

Recorded result: 748 numeric exfoliation-energy values and 355 missing values (na); 15 top-level fields entirely empty, including Tc_supercon.

Units and population: population: 1,103 source records; each missingness count belongs to its named property.; units: values fields

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Preserve the missingness mask; unknown values are not measured zeros.

Attention remaining: No superconducting transition-temperature result can be inferred from an entirely empty field; keep target-imputation decisions explicit and absent here.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-004`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /retained_observations; /all_empty_top_level_fields; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [missing_exfoliation_values.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/missing_exfoliation_values.json>) — entire selected missing-value record list; SHA-256 `9ad9389ce28816d15b707e378d4c625c876760832424d136e467180b3bb4cdec`.

## PZ-JARVIS-005

**Separate count differences from corruption**

Dates and roles: value: 2026-09-18T01:11:34.580384+00:00; role: historical analysis execution timestamp as reported by the saved receipt; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: The nat metadata and supplied atomic structure counts differ for selected records.

Method: Compare nat, atom-array length and coordinate count without changing source records.

Recorded result: 42 records differ; 41 supplied structures have twice nat, one has three times nat; coordinate and element counts match.

Units and population: population: 42 flagged records within the 1,103-record snapshot.; units: records atoms dimensionless structure/nat ratio

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: An inconsistency can reflect representation rather than data corruption; keep the original and test alternatives.

Attention remaining: Do not delete, label corrupt or silently repair these records. Historical exporter cause remains unverified.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-005`. Exact source references:

- [README.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/README.md>) — All 42 atom-count differences; SHA-256 `87663d1b3a58d248856ae92743a2bd575200d214631760420601cba9d8ff8a81`.
- [atom_count_differences.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/atom_count_differences.json>) — entire 42-record difference list; SHA-256 `faa34fc4c9a6efe8ce5c3040414b2859ee9d92f67f8ada38b5edf04cb0a8176d`.
- [replay_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/replay_evidence.json>) — /checks/coordinate_shapes_and_element_counts_consistent; /checks/nat_metadata_matches_supplied_structure; SHA-256 `5f7dbb7d5a821ca6a54203c2cf770842d9b7405b8c621c7d0bc34e44d0b0c907`.

## PZ-JARVIS-006

**Add a geometric diagnostic without erasing the initial finding**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: A repeated-cell interpretation needed evidence beyond count ratios.

Method: Candidate periodic translations must map each site to a distinct same-species site within 0.001 angstrom.

Recorded result: 40 of 42 flagged records support the repeated-cell interpretation under the diagnostic; JVASP-60484 and JVASP-6751 remain unresolved.

Units and population: population: 42 atom-count-difference records.; units: records angstrom tolerance

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: Documented geometric tolerance: 0.001 angstrom. No tolerance-convergence study, reference-standard validation or hardware calibration is established in this companion.

Teaching lesson: A stronger interpretation can be appended while retaining the original observation and unresolved cases.

Attention remaining: This limited diagnostic is not full crystallographic standardization; failing this tolerance does not prove no smaller representation exists, and it does not establish the historical export cause.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-006`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /atom_count_followup; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — What changed; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-007

**Check formulas against atomic composition**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Formula strings and supplied atom lists may describe different compositions.

Method: Compare compositions implied by formula strings with species counts from atomic arrays.

Recorded result: Four flagged records: JVASP-60545, JVASP-27866, JVASP-20042 and JVASP-28027.

Units and population: population: Four flagged formula/structure pairs in the selected snapshot.; units: records

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Cross-field agreement is a separate check from array shape and finiteness.

Attention remaining: A digit-formatting explanation remains plausible but unverified; retain source values and investigate exporter/raw-calculation evidence before correction.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-007`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /formula_composition_disagreement_jids; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Atomic structures and Formula disagreements; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-008

**A finite tensor is not automatically physically reliable**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Elastic tensors contain nonfinite and extreme values.

Method: Inspect tensor shapes/components and identify the affected record IDs.

Recorded result: 229 tensors are present; four tensors contain 20 nonfinite components in total. JVASP-28262 has an extreme finite component reported near 2.10 × 10^17.

Units and population: population: 229 available tensors in the selected 1,103-record snapshot.; units: tensors nonfinite components raw component value with physical units unresolved here

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Check finiteness, magnitude, units and slab normalization separately before drawing physical conclusions.

Attention remaining: Review raw output, exporter conventions, component units and slab scaling; do not claim universal mechanical stability.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-008`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /elastic; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Elasticity; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-009

**Do not infer stability from a constant field or one sign**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Stored energy and vibration fields can invite overbroad stability claims.

Method: Inspect stored ehull values, formation-energy signs and available mode lists as separate observables.

Recorded result: All 1,103 stored ehull values are zero; formation energy: 952 negative and 151 positive; 187 vibration mode lists each include a negative entry.

Units and population: population: 1,103 ehull/formation-energy rows and the separate 187-row available vibration subset.; units: records mode lists sign counts

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Constant values supply no ranking, and different physical observables answer different questions.

Attention remaining: Formation energy alone does not establish phase stability; negative mode entries alone do not certify instability. Calculation settings and finite-cell/export handling remain relevant.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-009`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /ehull; /interpretation_limits; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Energy above hull, Formation energy and Vibrations; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-010

**Compare methods on matched records**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Different subsets can create misleading method comparisons.

Method: Compare mBJ and OptB88 gaps on the same available rows.

Recorded result: OptB88 gaps: 397 zero and 706 positive. On 246 matched rows, mBJ is higher for 160, equal for 44 and lower for 42.

Units and population: population: 1,103 OptB88 values; a separate 246-record matched-method subset.; units: records matched-record direction counts

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: Descriptive matched-method comparison only; no experimental calibration or proficiency score established.

Teaching lesson: A matched comparison controls the sample composition; higher predicted values do not establish greater accuracy.

Attention remaining: Experimental reference values, convergence and a specified error metric are not established by this companion; do not label either method more accurate from these signs.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-010`. Exact source references:

- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — OptB88 bandgaps and Method comparison; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.
- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /interpretation_limits; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.

## PZ-JARVIS-011

**Validate descriptor dimensions and informative columns**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Numeric input arrays may contain finite but uninformative features.

Method: Check descriptor length, component finiteness and constant columns.

Recorded result: 1,557 components per vector; 1,717,371 values inspected and finite; 77 constant-zero columns and 1,480 variable columns.

Units and population: population: 1,103 descriptor vectors in the selected snapshot.; units: components per vector values columns

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Finiteness is a structural condition; it does not establish predictive value or physical validity.

Attention remaining: Do not present this as trained-model accuracy. Any later feature selection needs to retain its source mapping and training/evaluation boundary.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-011`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /descriptors/vector_length; /descriptors/values_inspected; /descriptors/all_values_finite; /descriptors/constant_zero_columns; /descriptors/variable_columns; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.

## PZ-JARVIS-012

**Keep duplicate inputs together during evaluation**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Exact descriptor duplicates could leak information between train and test sets.

Method: Group exact duplicate descriptor vectors and inspect the selected target agreement.

Recorded result: 34 exact descriptor pairs, also equal in OptB88 gap and formation energy; missing targets were not imputed.

Units and population: population: 34 duplicate pairs among the source descriptor vectors, not 34 independent discoveries or model tests.; units: duplicate pairs

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: Leakage-risk diagnostic; no held-out prediction metric or calibration run is recorded here.

Teaching lesson: Future splits should group duplicates so repeated inputs do not inflate apparent generalization.

Attention remaining: This is a preserved evaluation-design lesson, not an already executed split, training run or accuracy correction.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-012`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /descriptors/duplicate_vector_groups; /descriptors/duplicates_keep_together_in_future_train_test_split; /descriptors/missing_targets_not_imputed; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Duplicate inputs; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-013

**Bind descriptor interpretation to its generation revision**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Current column names may not prove how older vectors were generated.

Method: Flag extreme entries and cross-check current mapped density against top-level density.

Recorded result: Nine extremely negative entries at the current packing-fraction position; 1,007 density differences above 0.001 under the current mapping.

Units and population: population: Nine flagged entries and 1,007 flagged record comparisons within the snapshot.; units: entries record comparisons raw threshold 0.001; physical convention requires confirmation

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: A column mapping and historical generator provenance are separate evidence requirements.

Attention remaining: Historical descriptor-generation revision is unverified; do not assert a confirmed exporter bug or alter the original vectors from the current mapping alone.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-013`. Exact source references:

- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /descriptors/negative_packing_fraction_entries_under_current_mapping; /descriptors/density_difference_count_above_0_001_under_current_mapping; /descriptors/historical_descriptor_generation_revision_verified; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Descriptor flags; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-014

**Keep transport scaling attached to the quantity**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: Raw thermal-transport exports can be mistaken for conductivity with interchangeable units.

Method: Interpret quantities using their source exporter conventions and periodic-slab context.

Recorded result: The saved study explicitly separates raw thermal-transport export scaling from conductivity scaling; no device figure of merit is established.

Units and population: population: Raw nkappa/pkappa and conductivity-related fields in the acquired snapshot.; units: units/scaling unresolved for physical reinterpretation

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: A correct arithmetic operation can still be scientifically wrong if applied to quantities with incompatible units or normalizations.

Attention remaining: Resolve raw-output/exporter scaling, vacuum treatment and physical conventions before assigning conductivity units or calculating device performance.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-014`. Exact source references:

- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Transport; Scientific meaning and scope; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.
- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /interpretation_limits; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.

## PZ-JARVIS-015

**Interpret error fields narrowly**

Dates and roles: value: 2026-09-18T02:43:17.444616+00:00; role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: A domain-specific comparison field could be mislabeled a general dataset error rate.

Method: Keep maxdiff_mesh and maxdiff_bz tied to their documented Wannier-versus-DFT comparison role.

Recorded result: These fields are populated in 431 rows; the study does not report a global accuracy percentage from them.

Units and population: population: 431 populated record rows for the named comparison fields.; units: populated rows

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: Specific model-versus-model comparison availability; no general external calibration established.

Teaching lesson: Name the reference, observable and population of every error metric.

Attention remaining: Do not generalize a method-specific comparison into dataset accuracy, experimental correlation or overall proficiency.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-015`. Exact source references:

- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — Additional findings from the complete acquired snapshot — Wannier fields; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-JARVIS-016

**Deterministic replay checks consistency, not physical truth**

Dates and roles: value: 2026-09-18T01:13:42.423869+00:00; role: historical deterministic-output comparison verification timestamp; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: An analysis should yield the same deterministic outputs from the same input.

Method: Two separate Python standard-library processes analyzed the same archive; deterministic output files were compared byte-for-byte, excluding variable metrics.

Recorded result: analysis.json, checks.json and record_index.json matched: 3 of 3. The follow-up also records exact full-field-profile and structure-evidence replay.

Units and population: population: Three named deterministic files from the initial two-process replay; follow-up replay statements are separate evidence.; units: files byte comparison

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: Deterministic reproducibility recorded. No accuracy-to-experiment, hardware calibration or quantum advantage established.

Teaching lesson: Repeatable output supports computational consistency while leaving source anomalies and scientific calibration open.

Attention remaining: The public companion withholds analysis code/full inputs and is not a self-contained reproduction package. Preserve false catalog/nat check flags alongside successful execution and replay.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-016`. Exact source references:

- [replay_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/replay_evidence.json>) — /commands; /replay_verification; /checks; /code_publication; SHA-256 `5f7dbb7d5a821ca6a54203c2cf770842d9b7405b8c621c7d0bc34e44d0b0c907`.
- [followup_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/followup_evidence.json>) — /replay; SHA-256 `986694d5add12b645621742d12ed8a77df440a35271d02fe479ac25dd09ed131`.

## PZ-JARVIS-017

**Keep performance measurements within their measurement scope**

Dates and roles: value: 2026-09-18T01:11:34.580384+00:00; role: historical analysis execution timestamp as reported by the saved receipt; precision: timestamp with numeric UTC offset Use the role retained inside each date object.

Problem: A small analysis timing could be exaggerated into system-wide performance.

Method: The saved receipts separately record elapsed time and tracemalloc allocations for read/decompress/parse/analyze/write, with download excluded.

Recorded result: Analysis 1.6917715249946923 s and replay 2.091641733997676 s; tracked peak allocations 113,852,701 and 113,852,477 bytes. Zero network operations during analysis.

Units and population: population: Two historical Python processes in the recorded Linux execution environment for one selected archive.; units: seconds Python-tracked allocation bytes network operations

Evidence class: historical dataset-inspection evidence; current documentary synthesis

Controls and calibration: Instrumentation scope is documented; no system-wide or energy-efficiency calibration is established.

Teaching lesson: Report timing conditions and memory instruments before comparing efficiency.

Attention remaining: No laptop-wide memory, process RSS, USB speed, scaling benchmark or controlled energy comparison follows from these two measurements; timing variation is not a failed replay.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-017`. Exact source references:

- [replay_evidence.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/replay_evidence.json>) — /final_analysis_run; /replay_run; /replay_verification/metrics_excluded; SHA-256 `5f7dbb7d5a821ca6a54203c2cf770842d9b7405b8c621c7d0bc34e44d0b0c907`.

## PZ-JARVIS-018

**Preserve scientific corrections and derivative identities**

Dates and roles: value: 2026-10-16; role: current local identity verification and teaching compilation date; source historical findings retain their own dates; precision: day Use the role retained inside each date object.

Problem: Link repairs or later interpretation can obscure what originally changed.

Method: The saved companion records original/derivative hashes and repairs missing relative links to a pinned repository revision; original findings remain in the historical record.

Recorded result: Six companion-file identity entries; three have link repairs, three have none. All six current derivative identities match the recorded hashes in this bounded review.

Units and population: population: Six files listed in MATERIALS_COMPANION_DERIVATIONS.json; not the entire research collection.; units: files SHA-256 identities

Evidence class: current local documentary identity check; historical link-repair manifest

Controls and calibration: No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

Teaching lesson: Separate documentary maintenance from scientific changes and keep the earlier observation plus dated interpretation.

Attention remaining: The pinned external targets were not refreshed in this local review. Hash matches establish file identity, not scientific correctness, signature or endorsement.

Review depth: Bounded documentary review; no new numerical execution.

Source-row identity: `jarvis-rows.json` / `PZ-JARVIS-018`. Exact source references:

- [MATERIALS_COMPANION_DERIVATIONS.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/MATERIALS_COMPANION_DERIVATIONS.json>) — /notice; /files; SHA-256 `53d9e3ceb00f3de6a073dbcd4ce653d096679d5c2e59b502d696e0fe6969a638`.
- [FULL_STUDY_UPDATE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Quantum-Research/materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md>) — What changed; Publication practice; SHA-256 `a1308f6d0c94324b0deae7ff4e52ca18878b7314baa3d02a99cbbff6eea40ed8`.

## PZ-Q8-01

**USB-hosted research software and host computation**

Dates and roles: value: 2026-10-16; role: documentary review date; precision: day value: Not specified in this row; follow the recorded source.; role: original inception date; precision: not established by this selection Use the role retained inside each date object.

Problem: Describe what the portable environment actually supplies and where the calculations run.

Method: Retained code describes host Node processes, typed-array numerical operations, worker processes, host CPU/memory reporting and mirrored storage roots.

Recorded result: statement: Substantive software computation and portable storage/custody paths are supported by retained implementation. A USB device-side QPU or independent processor is not established.; values: 

Units and population: population: Selected source implementation, not a hardware benchmark population.; units: Embedded in the result; not inferred.

Evidence class: implementation description supported by earlier code review

Controls and calibration: recorded_checks: Source identity and implementation review.; not_established: USB device-side computation or physical QPU execution.; attention: Keep execution location, storage location and claimed hardware type in separate fields.

Teaching lesson: A portable application can be useful without moving the computation off the host. Describe the measured mechanism before naming the achievement.

Attention remaining: Qualify the project processor name with software/emulator where used. Do not describe USB storage as a separately measured compute device.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-01`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/0 [id=Q8-C01]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/10 [id=Q8-C11]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [TECHNICAL_REVIEW.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/TECHNICAL_REVIEW.md>) — ## What Q8 actually computes; SHA-256 `f161ceb1958162011782ce3fbb804788f26dfd4d3bdd95ba9d150f32bf9f3fc8`.

## PZ-Q8-02

**Dense state-vector capacity with explicit workload and memory**

Dates and roles: value: 2026-09-18; role: historical scaling work date; precision: day; exact trial timestamps not transcribed here Use the role retained inside each date object.

Problem: Determine the executable state-vector sizes under the laptop load and reserve policy then in effect.

Method: Two Float64 arrays store the real and imaginary amplitudes. Retained tests use GHZ H/CX operations and their inverse plus a four-phase full-support input, with serial workers and admission checks.

Recorded result: statement: Recorded sizes 1 through 21 completed for the specified workloads.; values: value: 25; unit: completed passing trials value: 9; unit: checks per trial value: 225; unit: repeated check evaluations value: 2097152; unit: complex amplitudes at 21 qubits value: 33554432; unit: state-array bytes at 21 qubits value: 766.6211; unit: median full validation milliseconds from three 21-qubit samples

Units and population: population: 25 trials across the saved size ladder; three samples at 21 qubits. Repeated checks are not independent research studies.; units: Embedded in the result; not inferred.

Evidence class: historical saved execution result implementation and review-linked

Controls and calibration: recorded_checks: Nine checks per trial and forward/inverse workloads; retain the original reserve policy.; not_established: Capacity for arbitrary algorithms or dense operators; physical quantum trials.; attention: Keep workload, state representation, trial count, validation cost and memory accounting together.

Teaching lesson: Dense state storage grows with 2^n amplitudes; a stated qubit count needs a representation and a circuit. A capacity demonstration is bounded by what actually ran.

Attention remaining: Preserve the 21-qubit result with its explicit workload and trial population. Do not label 225 check evaluations as 225 studies.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-02`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/7 [id=Q8-C08]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [TECHNICAL_REVIEW.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/TECHNICAL_REVIEW.md>) — **Dense capacity.**; SHA-256 `f161ceb1958162011782ce3fbb804788f26dfd4d3bdd95ba9d150f32bf9f3fc8`.

## PZ-Q8-03

**Memory admission refusal versus numerical failure**

Dates and roles: value: 2026-09-18; role: historical scaling admission decision; precision: day Use the role retained inside each date object.

Problem: Protect the required free-memory reserve before attempting a larger dense state.

Method: Compare available memory with the state-plus-reserve requirement before starting the next trial.

Recorded result: statement: The 22-qubit trial was not admitted; it did not produce a failed numerical result.; values: value: 322658304; unit: observed free bytes value: 335544320; unit: required free bytes value: 268435456; unit: unchanged memory-reserve bytes

Units and population: population: One saved admission boundary; no executed 22-qubit trial in this record.; units: Embedded in the result; not inferred.

Evidence class: historical admission decision

Controls and calibration: recorded_checks: A fixed reserve was enforced before allocation/trial.; not_established: A permanent hardware maximum or correctness failure at 22 qubits.; attention: Track not-started separately from started, completed, accepted and target-met.

Teaching lesson: A guard can correctly stop a run. Teaching the stop condition prevents a safety/resource decision from becoming a false scientific failure.

Attention remaining: Use not admitted, not failed, for this trial. Do not replace observed-load limits with general hardware limits.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-03`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/8 [id=Q8-C09]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.

## PZ-Q8-04

**Structured states and the meaning of a large qubit index**

Dates and roles: value: Not specified in this row; follow the recorded source.; role: original structured implementation date; precision: not established by this selected later source snapshot value: 2026-10-16; role: documentary review date; precision: day Use the role retained inside each date object.

Problem: Represent selected large-index product and GHZ states without allocating every dense amplitude.

Method: SOP stores a sum of product branches; MPS contracts bounded tensors and uses reorthogonalized QR. The bridge checks selected amplitudes and normalization.

Recorded result: statement: Selected structured product/GHZ implementation supports a 60 indexed-qubit limit with explicit representation caps; historical benchmark linkage remains limited.; values: value: 60; unit: indexed-qubit limit value: 64; unit: SOP branch cap value: 32; unit: bridge MPS bond cap value: 1e-13; unit: local QR residual omission threshold value: 3; unit: selected basis-amplitude witnesses

Units and population: population: A selected implementation and three-amplitude bridge check, not exhaustive dense state verification.; units: Embedded in the result; not inferred.

Evidence class: implementation supported historical benchmark linkage limited

Controls and calibration: recorded_checks: SOP refuses branch overflow; MPS records local omitted residual diagnostics; bridge uses three amplitudes plus normalization.; not_established: A certified global state-error bound or arbitrary dense 60-qubit capacity.; attention: Separate algebraic representation, floating-point error, local omission threshold and global state accuracy.

Teaching lesson: Compression works by using structure. A local numerical threshold does not automatically provide a global error guarantee.

Attention remaining: Retain dense and structured capacities as separate achievements. Do not infer original implementation date from the later copy folder. Attach exact historical benchmark evidence before publishing an additional performance assertion.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-04`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/9 [id=Q8-C10]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [TECHNICAL_REVIEW.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/TECHNICAL_REVIEW.md>) — **Structured capacity.**; SHA-256 `f161ceb1958162011782ce3fbb804788f26dfd4d3bdd95ba9d150f32bf9f3fc8`.

## PZ-Q8-05

**Conventional byte prediction and bounded register machine**

Dates and roles: value: Not specified in this row; follow the recorded source.; role: original implementation date; precision: not established in selected register value: 2026-10-16; role: documentary review date; precision: day Use the role retained inside each date object.

Problem: Explain additional prototype capabilities without overstating their scope.

Method: One-byte-context softmax/SGD prediction and a bounded arithmetic/memory/branch register-machine implementation in the host process.

Recorded result: statement: The selected Q8 source contains these concrete conventional software components.; values: value: 256; unit: byte vocabulary value: 65536; unit: bigram weights value: 16; unit: maximum VM registers value: 4096; unit: maximum VM memory words value: 100000; unit: maximum VM steps

Units and population: population: Implementation parameters, not a measured general intelligence or OS-isolation study.; units: Embedded in the result; not inferred.

Evidence class: implementation description

Controls and calibration: recorded_checks: Bounded implementation described in previous code review.; not_established: General language-model capability, a new OS or a native-process security sandbox.; attention: Use component-level acceptance criteria and avoid upgrading a model name into a capability claim.

Teaching lesson: Small interpretable models are teaching tools. Their explicit limits make the implementation easier to test and explain.

Attention remaining: Describe the byte predictor as a one-byte-context model. Keep VM limits separate from operating-system guarantees.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-05`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/12 [id=Q8-C13]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.

## PZ-Q8-06

**Historical Windows resource observations and correlation**

Dates and roles: value: 2026-09-29T03:24:21.3923759Z; end: 2026-09-29T03:24:51.0207323Z; role: historical counter sampling: before; precision: exact source timestamp strings value: 2026-09-29T03:28:03.4200452Z; end: 2026-09-29T03:28:32.8982117Z; role: historical counter sampling: after; precision: exact source timestamp strings value: 2026-09-29T04:27:01.0738435Z; end: 2026-09-29T04:27:30.4675116Z; role: historical counter sampling: post-install-20260929; precision: exact source timestamp strings Use the role retained inside each date object.

Problem: Understand the host conditions surrounding the work and keep observed changes distinct from causal conclusions.

Method: Three saved windows sample eleven counter identities thirty times each at a scheduled one-second interval. Background workloads changed. All sampling ended before the associated USB checks.

Recorded result: statement: Later windows show lower sampled CPU pressure and higher available-memory counter means; other indicators do not improve monotonically.; values: value: 40.954661803379665 16.632889047421816 12.057595117859382; unit: mean percent processor time in before/after/post-install order value: 301.96666666666664 339.6 421.46666666666664; unit: mean values of the Windows available mbytes counter, same window order value: 926.5994757837885 0.5207366614199194 370.687491257829; unit: mean pages output per second value: 0.0005620876636694995 0.0006296199070738684 0.0007796027563135101; unit: unweighted mean sampled disk seconds/read

Units and population: population: 990 saved readings = 3 windows × 11 counters × 30 samples. These are repeated counter readings, not 990 independent experiments.; units: Embedded in the result; not inferred.

Evidence class: historical observation association under changing background conditions

Controls and calibration: recorded_checks: Source derivative retains values, status codes and exact timestamps; all selected values finite with status zero.; not_established: Controlled Windows-wide acceleration, USB causal effect, electrical energy, battery, thermal or unrelated-program responsiveness gain.; attention: Keep the original counter name/unit and window timing. Disk-latency samples are unweighted and include idle intervals. A future causal claim would need a separately designed controlled comparison; none was performed here.

Teaching lesson: A real observation is worth preserving even when it cannot establish causation. Report favorable and unfavorable indicators together and identify changing background conditions.

Attention remaining: Do not claim these counters measured the later USB verification workload. Preserve counter-reported Mbytes terminology; the older README labels it MiB, while the technical review uses the exact counter unit. Do not promote lower observed pressure into general Windows or energy improvement.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-06`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/10 [id=Q8-C11]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/14 [id=Q8-C15]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.
- [README.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/observations/README.md>) — ## Interpretation; SHA-256 `f6bff9061355ac9d9ee7c8dda5bf16543976a1009eafa17172308983de4fa3ae`.
- [reproduction-result.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/observations/reproduction-result.json>) — /results; SHA-256 `381456cda4d69fc38f18da1b0ca578e2b40fef0e4154ee8005da28681e8d4741`.

## PZ-Q8-07

**Reproducing arithmetic from retained observations**

Dates and roles: value: 2026-09-29; role: UTC date of original observations; precision: day; exact windows in PZ-Q8-06 value: 2026-10-16; role: earlier documentary replay/review date; precision: day Use the role retained inside each date object.

Problem: Make the saved resource data independently checkable without treating a replay as a new experiment.

Method: A standard-library Python replay sums thirty saved values for each counter/window, divides by thirty and compares with its saved mean using absolute and relative tolerances of 1e-12.

Recorded result: statement: The saved preparation receipt records all selected means reproduced and the source comparison passed.; values: value: 990; unit: saved readings compared value: 33; unit: saved means reproduced value: 0; unit: new observations in that replay

Units and population: population: The same 990 readings as PZ-Q8-06; do not add this row to the observation population.; units: Embedded in the result; not inferred.

Evidence class: saved documentary replay receipt derived arithmetic on historical data

Controls and calibration: recorded_checks: All values, statuses and exact timestamps compared to originals; independent temporary replay produced the same output bytes, as reported in the retained review.; not_established: Independent repetition of the historical workload.; attention: State whether a result is a new measurement, recomputation, cached retrieval or code fixture.

Teaching lesson: Reproducible arithmetic and experimental replication answer different questions. Both have value when labeled precisely.

Attention remaining: Keep new_observations equal to zero for documentary replay. Reuse the saved validated replay state unless input bytes or method change; no need to rerun it to compile this matrix.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-07`. Exact source references:

- [observations-source-check.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/observations-source-check.json>) — /status, /readings_compared, /saved_means_compared, /means; SHA-256 `3b90f8720ff0652339412179e64a92d5603fab0ba7d65779556fa7844aca67e3`.
- [reproduction-result.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/observations/reproduction-result.json>) — /status, /readings, /means, /new_observations; SHA-256 `381456cda4d69fc38f18da1b0ca578e2b40fef0e4154ee8005da28681e8d4741`.
- [REPRODUCTION_SCOPE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/REPRODUCTION_SCOPE.md>) — opening three paragraphs; SHA-256 `38ae5ad736bc8cd6dd131008b31768002c2406ef0f3d4c5c691a2eeef0fe07ec`.

## PZ-Q8-08

**Unsigned manifest consistency and variable check durations**

Dates and roles: value: 2026-09-29T03:24:56.7680401Z; role: historical package check: before; precision: exact saved timestamp value: 2026-09-29T03:28:38.0299580Z; role: historical package check: after; precision: exact saved timestamp value: 2026-09-29T04:27:35.7322933Z; role: historical package check: post-install-20260929; precision: exact saved timestamp Use the role retained inside each date object.

Problem: Verify the declared installed package without confusing byte consistency with authenticated provenance or performance.

Method: Each saved operation checks the same declared forty-file package against an unsigned manifest after the counter sampling ends.

Recorded result: statement: All three saved operations reported the declared package check succeeded.; values: value: 40; unit: declared package files in each check value: 3; unit: saved check operations value: 12.5676291 1.620652 9.3315077; unit: elapsed verification seconds by recorded operation value: Not specified in this row; follow the recorded source.; unit: signature field in each receipt

Units and population: population: Three operations over the same declared forty-file set; not 120 distinct files or the full USB.; units: Embedded in the result; not inferred.

Evidence class: historical package consistency receipt

Controls and calibration: recorded_checks: Fingerprint comparison within the declared manifest scope.; not_established: Authenticated release, ownership, malicious replacement protection, or controlled speed improvement.; attention: Retain signature=null and the stated fingerprint scope. Different cache/background conditions make check durations unsuitable as a causal speedup comparison.

Teaching lesson: A hash verifies agreement with specified bytes. It does not by itself authenticate who produced them or why a later check was faster.

Attention remaining: Keep the package population explicit. Do not treat variable verification times as a fresh research calculation benchmark.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-08`. Exact source references:

- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/15 [id=Q8-C16]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.

## PZ-Q8-09

**Partial installation, later readback and preserved mistakes**

Dates and roles: value: 2026-09-29T04:02:43.211Z; role: earlier partial repair-copy observation; precision: exact saved timestamp value: 2026-09-29T04:23:04.767Z; role: performance-package installation receipt; precision: exact saved timestamp value: 2026-09-29T04:30:48.386Z; role: later selected-package readback receipt; precision: exact saved timestamp Use the role retained inside each date object.

Problem: Reconcile a genuine incomplete intermediate state with the later recorded completed installation.

Method: Order the saved copy, installation and readback receipts by their own timestamps and distinguish writes from later verification.

Recorded result: statement: The earlier repair-copy check recorded 43 of 47; the later readback reported all 78 selected payload rows matched across three packages.; values: value: 43; unit: earlier matching repair files out of 47 value: 47; unit: later repair files value: 16; unit: performance-package files value: 15; unit: adaptive-package files value: 78; unit: later matched selected payload rows

Units and population: population: Three declared packages; not the complete USB or a current file inventory.; units: Embedded in the result; not inferred.

Evidence class: historical partial observation historical installation/readback receipt

Controls and calibration: recorded_checks: Saved receipt reports present/matched rows; later local custody checks do not supply retroactive per-row historical digests.; not_established: Current USB contents or a calculation from the newly installed performance package.; attention: The performance receipt explicitly defers calculation and installed-runtime testing.

Teaching lesson: An earlier incomplete report may be correct at its time. Correct the current summary without deleting that intermediate evidence.

Attention remaining: Preserve the 43/47 checkpoint and supersede only its use as current status. Do not interpret readback usbWritesPerformed=false as denying preceding installation writes. Do not upgrade installed bytes to an executed scientific benchmark.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-09`. Exact source references:

- [CUSTODY_AND_OPERATION.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CUSTODY_AND_OPERATION.md>) — paragraphs on 78 matching installed files; SHA-256 `0f9862948b182561597d7e1b8ecb769b7ed9cf84e6717a58e2a35a6df69ba02b`.
- [CHRONOLOGY.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CHRONOLOGY.md>) — Q8USB-11; X03; X05; SHA-256 `e17c8e2954650017a348b3366344584d3a84c09b667aafae5f7248c69a2be960`.
- [claims.json](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/claims.json>) — /claims/11 [id=Q8-C12]; SHA-256 `03ec2d1fcfb9942574b77b2df73449917afd3eb48de16019f67c8e494e8bc38b`.

## PZ-Q8-10

**Bounded operation from the installed USB environment**

Dates and roles: value: 2026-09-29T04:33:44.399Z; end: 2026-09-29T04:33:45.301Z; role: historical installed-runtime interaction; precision: exact saved start/end fields Use the role retained inside each date object.

Problem: Establish what an actual recorded interaction with the installed environment did.

Method: The saved receipt names a USB executable and working directory, performs declared file checks, local library retrieval and means from existing readings.

Recorded result: statement: The bounded operation recorded verification, retrieval and arithmetic; it did not start a language model or collect new observations.; values: value: 14; unit: package files checked value: 10; unit: source files checked value: 4; unit: persistent library records loaded value: 3; unit: retrieval results value: 660; unit: previously saved readings value: 22; unit: derived means

Units and population: population: One saved installed-runtime interaction; its 14 checked package files differ from the 15 adaptive files in the installation receipt.; units: Embedded in the result; not inferred.

Evidence class: historical bounded execution receipt derived arithmetic on previously saved observations

Controls and calibration: recorded_checks: Receipt binds executable/working-folder context and individual action flags.; not_established: A ready conversational service today or a new model/numerical experiment.; attention: Keep model launch, service/network activity, writes, retrieval and calculation as separate flags.

Teaching lesson: A real runtime success can be narrow. Credit exactly what ran without requiring unrelated tasks to have succeeded, and without promoting it to complete readiness.

Attention remaining: Do not label the 660 readings as new samples. Use start/end fields rather than a filename time. Do not merge differently scoped file counts.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-10`. Exact source references:

- [CUSTODY_AND_OPERATION.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CUSTODY_AND_OPERATION.md>) — paragraph on separate September 29 bounded run; SHA-256 `0f9862948b182561597d7e1b8ecb769b7ed9cf84e6717a58e2a35a6df69ba02b`.
- [CHRONOLOGY.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CHRONOLOGY.md>) — Q8USB-12; X12; SHA-256 `e17c8e2954650017a348b3366344584d3a84c09b667aafae5f7248c69a2be960`.

## PZ-Q8-11

**GAUCIA repair installation versus live conversation readiness**

Dates and roles: value: 2026-10-16T01:00:15.847Z; end: 2026-10-16T01:00:47.21Z; role: owner-run installation receipt; precision: exact saved UTC fields; completed October 15 9:00:47.210 p.m. EDT Use the role retained inside each date object.

Problem: Avoid erasing a successful installation because older not-installed prose remains, while retaining the separate live-readiness gap.

Method: Use the later owner-run receipt and matched package manifest as the installation evidence; keep earlier fixture tests and historical UI visibility separate.

Recorded result: statement: R3 installed bytes are recorded; the installer did not launch or verify a live conversation.; values: value: 8; unit: installed repair target files value: 45; unit: listed package files verified value: 944; unit: preserved non-target entries, including directory and hold markers

Units and population: population: One owner-run installation and its manifest/readback evidence; entries are not all files.; units: Embedded in the result; not inferred.

Evidence class: historical owner-run installation receipt separate local fixture evidence

Controls and calibration: recorded_checks: Target bytes, manifest and preservation counts; local fixtures are a separate population.; not_established: Current live model/service/conversation readiness or complete USB mirroring.; attention: Report installed, launched and ready as independent outcomes; preserve older states at their original timestamps.

Teaching lesson: State must be chronological and stage-specific. A successful installation is meaningful even while a later usable-service check remains open.

Attention remaining: Do not reinstall merely because stale prose says pending. Do not call 944 preserved entries 944 files. Controller/node content and OP-06 operational exhibits remain outside this teaching selection.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-11`. Exact source references:

- [CUSTODY_AND_OPERATION.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CUSTODY_AND_OPERATION.md>) — paragraph on October 15 9:00:47 p.m. EDT; SHA-256 `0f9862948b182561597d7e1b8ecb769b7ed9cf84e6717a58e2a35a6df69ba02b`.
- [CHRONOLOGY.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CHRONOLOGY.md>) — Q8USB-17; X04; X11; SHA-256 `e17c8e2954650017a348b3366344584d3a84c09b667aafae5f7248c69a2be960`.

## PZ-Q8-12

**Reproducible teaching package and remaining source work**

Dates and roles: value: 2026-10-16; role: saved documentary review and teaching compilation date; precision: day Use the role retained inside each date object.

Problem: Give a reader enough information to inspect and reproduce the selected work without inventing new research or silently rewriting historical programs.

Method: Bind claims to source identities, distinguish raw receipts from derivatives, preserve negative results and document runtime/dependency/workload/acceptance requirements.

Recorded result: statement: The selected review binds sixteen claim decisions to forty source identities and contains a self-contained replay of saved counter means. This is not the executable dependency tree for every experiment.; values: value: 16; unit: technical claim decisions in the retained review value: 40; unit: selected source identities in that review value: 33; unit: means reproducible by the selected arithmetic companion

Units and population: population: Documentary coverage of the bounded Q8 supplement; source references and copied reports are not additional studies.; units: Embedded in the result; not inferred.

Evidence class: documentary reproduction scope source-identity register

Controls and calibration: recorded_checks: Selected archive identities and saved replay checks were verified in the previous review.; not_established: Complete per-experiment portable dependency environments, all-history semantic coverage or independent scientific replication.; attention: A future portable adapter must be a separate identified derivative; original source and historical baseline remain intact.

Teaching lesson: Teach the question, representation, method, checks, unfavorable results and limits together. Reuse a saved review state keyed to source hashes, and revisit only changed inputs or unresolved questions.

Attention remaining: Update new summaries for the now-recovered five original exports without editing frozen older documents. Replace the frozen chronology’s superseded controller-selection question with the active controller/node exclusion. Keep unresolved original benchmark/dependency links separate from acquired raw-text coverage.

Review depth: reviewed documentary teaching row

Source-row identity: `q8-rows.json` / `PZ-Q8-12`. Exact source references:

- [REPRODUCTION_SCOPE.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/REPRODUCTION_SCOPE.md>) — complete document; SHA-256 `38ae5ad736bc8cd6dd131008b31768002c2406ef0f3d4c5c691a2eeef0fe07ec`.
- [TECHNICAL_REVIEW.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/TECHNICAL_REVIEW.md>) — ## Source linkage and remaining work; SHA-256 `f161ceb1958162011782ce3fbb804788f26dfd4d3bdd95ba9d150f32bf9f3fc8`.
- [CHRONOLOGY.md](<./REDACTED_LOCAL_ROOT/Documents/Codex/2026-10-15/check-the-library-space-and-let/outputs/Q8-USB-Publication-Review/CHRONOLOGY.md>) — ## Coverage and remaining decisions; SHA-256 `e17c8e2954650017a348b3366344584d3a84c09b667aafae5f7248c69a2be960`.
