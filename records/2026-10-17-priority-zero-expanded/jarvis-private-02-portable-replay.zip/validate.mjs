import {createRun,read,readText,modules} from './runtime.mjs';
const run=createRun();
try{
 const cfg=read('CONTRACT.json'),{candidate:c,baseline:b,containment}=await modules();run.save('containment.json',containment);
 const controls=b.controls();run.save('controls.json',controls);
 if(!controls.every(x=>x.rejected===true||(Number.isFinite(x.error)&&x.error<=1e-10)||(x.id==='phase_sensitive_comparison'&&x.amplitude_difference>0.1&&x.same_probabilities)))throw Error('Analytic control failure');
 const fixture=read('inputs/hamiltonians_24x8x8.json'),previous=read('prior/run_01/new_hamiltonians.json').points,blocks=b.parseWannier(readText('inputs/wannier90_hr.dat'));
 const points=[...fixture.rows.map(r=>({k:r.kpoint_fractional_reciprocal,expected:r.matrix_ev,group:'original_path'})),...previous.map(r=>({k:r.kpoint,expected:r.matrix_ev,group:'first_pass_additional'})),...cfg.fresh_points.map(k=>({k,expected:null,group:'new_pass2_point'}))];
 const seen=new Set(points.slice(0,30).map(r=>JSON.stringify(r.k)));for(const p of points.slice(30)){if(seen.has(JSON.stringify(p.k)))throw Error('Additional point is not new');seen.add(JSON.stringify(p.k));}
 run.log('validation_started',{ordered_points:points.length,new_points:cfg.fresh_points.length,seed:cfg.seed});
 const states=[],summaries=[],references=[],holdoutPredictions=[];
 for(let i=0;i<points.length;i++){
  const point=points[i],constructed=b.constructH(blocks,point.k),H=constructed.h;
  let reconstruction=0;if(point.expected){b.validateH(point.expected);for(let a=0;a<8;a++)for(let j=0;j<8;j++)reconstruction=Math.max(reconstruction,Math.hypot(H[a][j][0]-point.expected[a][j][0],H[a][j][1]-point.expected[a][j][1]));if(reconstruction>1e-10)throw Error('Input reconstruction failed');}
  const checks=b.circuitChecks(H,(cfg.seed+i)>>>0);for(const q of checks)if(q.max_amplitude_error>2e-10||q.energy_error_ev>1e-9||Math.abs(q.norm-1)>2e-10)throw Error('Q8 circuit comparison failed');
  const predicted=c.optimizeCandidate(H,cfg.method,(cfg.seed+1000+i)>>>0);
  run.save('case_'+String(i).padStart(2,'0')+'_prediction.json',{index:i,kpoint:point.k,group:point.group,route:'unchanged Q8 circuit; new optimizer',prediction:predicted,circuit_checks:checks,reconstructed_hamiltonian_ev:H});
  holdoutPredictions.push({index:i,kpoint:point.k,group:point.group,energy_ev:predicted.final_energy_ev,parameters:predicted.parameters,amplitudes:predicted.amplitudes});
  const ref=b.jacobi(H);references.push({index:i,kpoint:point.k,eigenvalues_ev:ref.eigenvalues,residual_ev:ref.residual,orthogonality:ref.orthogonality});
  if(ref.residual>1e-9||ref.orthogonality>1e-10)throw Error('Reference diagnostics failed');
  const signedGap=predicted.final_energy_ev-ref.eigenvalues[0];
  const correct=predicted.starts.every(s=>s.final_energy_ev<=s.warmup_final_energy_ev+1e-9&&s.history.every(h=>h.improvement_ev>=-1e-9)&&s.max_amplitude_error<=2e-10&&s.dense_energy_error_ev<=1e-9&&Math.abs(s.norm-1)<=2e-10)&&signedGap>=-1e-8&&Number.isFinite(predicted.total_objective_evaluations);
  if(!correct)throw Error('Variational correctness failure');
  const score={index:i,kpoint:point.k,group:point.group,initial_energy_ev:predicted.initial_best_energy_ev,warmup_energy_ev:predicted.warmup_best_energy_ev,final_energy_ev:predicted.final_energy_ev,ground_reference_ev:ref.eigenvalues[0],signed_gap_ev:signedGap,absolute_gap_ev:Math.abs(signedGap),goal_pass:signedGap<=cfg.tolerances.ground_gap_ev,improved_goal_pass:signedGap<=cfg.tolerances.improved_ground_gap_ev,variational_correctness:true,gradient_norm:predicted.gradient_norm,residual_ev:predicted.residual_ev,iterations_by_start:predicted.starts.map(s=>s.iterations),stop_reasons:predicted.starts.map(s=>s.reason),total_evaluations:predicted.total_objective_evaluations,input_reconstruction_ev:reconstruction,max_amplitude_error:Math.max(...checks.map(q=>q.max_amplitude_error),...predicted.starts.map(s=>s.max_amplitude_error)),max_dense_energy_error_ev:Math.max(...checks.map(q=>q.energy_error_ev),...predicted.starts.map(s=>s.dense_energy_error_ev)),max_branches:Math.max(...predicted.starts.map(s=>s.storage.maximum_observed_branches))};
  summaries.push(score);states.push({index:i,amplitudes:predicted.amplitudes});
  run.save('case_'+String(i).padStart(2,'0')+'_score.json',score);
  run.log('point_saved',{index:i,group:point.group,gap_ev:signedGap,goal_pass:score.goal_pass,iterations:score.iterations_by_start,evaluations:score.total_evaluations});
 }
 run.save('predictions.json',holdoutPredictions);run.save('references.json',references);run.save('scores.json',summaries);
 const official=read('references/official_reference.json').test['JVASP-816'].split(';').map(Number),numpy=read('references/classical_reference_predictions.json').eigenvalues.flat(),bands=references.slice(0,24).flatMap(r=>r.eigenvalues_ev);
 if(official.length!==192||numpy.length!==192)throw Error('Reference shape mismatch');
 const comparisons=bands.map((v,i)=>({index:i,prediction_ev:v,official_ev:official[i],numpy_ev:numpy[i],official_error_ev:Math.abs(v-official[i]),numpy_error_ev:Math.abs(v-numpy[i])}));
 const mae=comparisons.reduce((s,c)=>s+c.official_error_ev,0)/192,numpyMax=Math.max(...comparisons.map(c=>c.numpy_error_ev));
 if(mae>1e-4||numpyMax>1e-9)throw Error('Classical control drift');run.save('reference_comparisons.json',comparisons);
 const groups=Object.fromEntries(['original_path','first_pass_additional','new_pass2_point'].map(g=>{const rows=summaries.filter(s=>s.group===g);return [g,{count:rows.length,goal_passes:rows.filter(r=>r.goal_pass).length,improved_goal_passes:rows.filter(r=>r.improved_goal_pass).length,max_absolute_gap_ev:Math.max(...rows.map(r=>r.absolute_gap_ev))}];}));
 const summary={owner:cfg.owner,status:'COMPLETED',signature:'UNSIGNED',original_goal_ev:cfg.tolerances.ground_gap_ev,improved_goal_ev:cfg.tolerances.improved_ground_gap_ev,ordered_cases:summaries.length,unique_points:new Set(summaries.map(r=>JSON.stringify(r.kpoint))).size,groups,goal_passes:summaries.filter(r=>r.goal_pass).length,improved_goal_passes:summaries.filter(r=>r.improved_goal_pass).length,variational_correctness_passes:summaries.filter(r=>r.variational_correctness).length,complex_state_energy_cases:3*summaries.length,max_absolute_gap_ev:Math.max(...summaries.map(r=>r.absolute_gap_ev)),max_state_residual_ev:Math.max(...summaries.map(r=>r.residual_ev)),max_amplitude_error:Math.max(...summaries.map(r=>r.max_amplitude_error)),max_dense_energy_error_ev:Math.max(...summaries.map(r=>r.max_dense_energy_error_ev)),max_branches:Math.max(...summaries.map(r=>r.max_branches)),official_mae_ev:mae,numpy_max_error_ev:numpyMax,total_objective_evaluations:summaries.reduce((s,r)=>s+r.total_evaluations,0),physical_qpu:false,language_model_trained:false,ansatz_changed:false,q8_engine_changed:false};
 run.save('summary.json',summary);run.finish();run.log('validation_complete',summary);
}catch(e){run.fail(e);}
