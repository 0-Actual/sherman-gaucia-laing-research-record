import {createRun,read,readText,modules} from './runtime.mjs';
const run=createRun();
try{
 const cfg=read('CONTRACT.json'),sc=read('STRESS_CONTRACT.json'),{candidate:c,baseline:b,containment}=await modules();run.save('containment.json',containment);run.save('stress_contract.json',sc);
 const random=b.rng(sc.seed),points=Array.from({length:sc.random_points},()=>Array.from({length:3},()=>sc.random_range[0]+random()*(sc.random_range[1]-sc.random_range[0])));
 const cases=points.map((k,i)=>({kind:'random_same_material',kpoint:k,id:'random_'+i}));
 for(let axis=0;axis<3;axis++)for(const delta of sc.neighborhood_steps){const k=sc.neighborhood_center.slice();k[axis]+=delta;cases.push({kind:'failure_neighborhood',kpoint:k,id:'axis_'+axis+'_delta_'+delta});}
 const blocks=b.parseWannier(readText('inputs/wannier90_hr.dat'));
 for(const item of cases)item.H=b.constructH(blocks,item.kpoint).h;
 const gates=b.ansatz(Array.from({length:18},(_,i)=>.137*(i+1))),columns=Array.from({length:8},(_,j)=>b.dense(3,gates,j));
 const add=(x,y)=>[x[0]+y[0],x[1]+y[1]],mul=(x,y)=>[x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]],conj=z=>[z[0],-z[1]];
 for(const gap of sc.synthetic_gaps_ev){
  const values=[0,gap,1.5,2,3,4,6,9];
  const H=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>{let z=[0,0];for(let k=0;k<8;k++){const q=mul(columns[k][i],conj(columns[k][j]));z=add(z,[values[k]*q[0],values[k]*q[1]]);}return z;}));
  cases.push({kind:'synthetic_known_spectrum',id:'gap_'+gap,declared_gap_ev:gap,known_eigenvalues:values,known_columns:columns,H});
 }
 if(cases.length!==sc.case_total)throw Error('Unexpected case count');
 run.save('inputs.json',cases);run.log('stress_started',{cases:cases.length,seed:sc.seed});const scores=[];
 for(let i=0;i<cases.length;i++){
  const item=cases[i];b.validateH(item.H);
  const p=c.optimizeCandidate(item.H,cfg.method,(sc.seed+1000+i)>>>0);
  run.save('case_'+String(i).padStart(2,'0')+'_prediction.json',{index:i,id:item.id,kind:item.kind,prediction:p});
  const ref=b.jacobi(item.H);if(ref.residual>1e-9||ref.orthogonality>1e-10)throw Error('Reference failure');
  if(item.known_eigenvalues&&Math.max(...item.known_eigenvalues.map((v,j)=>Math.abs(v-ref.eigenvalues[j])))>1e-9)throw Error('Constructed spectrum mismatch');
  const gap=p.final_energy_ev-ref.eigenvalues[0];
  const correct=p.starts.every(s=>Math.abs(s.norm-1)<2e-10&&s.max_amplitude_error<=2e-10&&s.dense_energy_error_ev<=1e-9&&s.final_energy_ev<=s.warmup_final_energy_ev+1e-9)&&gap>=-1e-8;
  if(!correct)throw Error('Variational check failed');
  let fidelity=null,fidelityScope=null;
  if(item.known_columns){
   const overlap=col=>{let z=[0,0];for(let j=0;j<8;j++)z=add(z,mul(conj(col[j]),p.amplitudes[j]));return z[0]*z[0]+z[1]*z[1];};
   fidelity=overlap(item.known_columns[0]);fidelityScope='unique_ground_state';
   if(item.declared_gap_ev===0){fidelity+=overlap(item.known_columns[1]);fidelityScope='two_dimensional_ground_subspace';}
  }
  const row={index:i,id:item.id,kind:item.kind,kpoint:item.kpoint||null,declared_gap_ev:item.declared_gap_ev??null,ground_reference_ev:ref.eigenvalues[0],energy_ev:p.final_energy_ev,signed_energy_gap_ev:gap,absolute_energy_gap_ev:Math.abs(gap),goal_pass:gap<=sc.energy_goal_ev,improved_goal_pass:gap<=sc.improved_energy_goal_ev,variational_correctness:true,ground_fidelity:fidelity,fidelity_scope:fidelityScope,fidelity_goal_pass:fidelity===null?null:fidelity>=sc.fidelity_goal,gradient_norm:p.gradient_norm,residual_ev:p.residual_ev,total_evaluations:p.total_objective_evaluations,iterations:p.starts.map(s=>s.iterations),stop_reasons:p.starts.map(s=>s.reason)};
  scores.push(row);run.save('case_'+String(i).padStart(2,'0')+'_score.json',row);run.log('stress_case_saved',{index:i,kind:item.kind,gap_ev:gap,energy_goal:row.goal_pass,fidelity});
 }
 run.save('scores.json',scores);
 const groups=Object.fromEntries(['random_same_material','failure_neighborhood','synthetic_known_spectrum'].map(g=>{const rows=scores.filter(r=>r.kind===g);return [g,{count:rows.length,energy_goal_passes:rows.filter(r=>r.goal_pass).length,improved_goal_passes:rows.filter(r=>r.improved_goal_pass).length,fidelity_goal_passes:rows.filter(r=>r.fidelity_goal_pass===true).length,max_absolute_energy_gap_ev:Math.max(...rows.map(r=>r.absolute_energy_gap_ev))}];}));
 const summary={owner:sc.owner,cases:scores.length,groups,energy_goal_passes:scores.filter(r=>r.goal_pass).length,improved_goal_passes:scores.filter(r=>r.improved_goal_pass).length,correctness_passes:scores.filter(r=>r.variational_correctness).length,synthetic_fidelity_goal_passes:scores.filter(r=>r.fidelity_goal_pass===true).length,synthetic_cases:sc.synthetic_gaps_ev.length,energy_pass_but_fidelity_miss:scores.filter(r=>r.goal_pass&&r.fidelity_goal_pass===false).map(r=>r.index),max_absolute_energy_gap_ev:Math.max(...scores.map(r=>r.absolute_energy_gap_ev)),total_evaluations:scores.reduce((s,r)=>s+r.total_evaluations,0),signature:'UNSIGNED',interpretation:'Energy, eigenstate fidelity, and degenerate-subspace fidelity are separate metrics. No references are fed into the optimizer.'};
 run.save('summary.json',summary);run.finish();run.log('stress_complete',summary);
}catch(e){run.fail(e);}
