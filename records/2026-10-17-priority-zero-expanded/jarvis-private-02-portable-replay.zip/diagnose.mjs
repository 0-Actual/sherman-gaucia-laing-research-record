import {createRun,read,modules} from './runtime.mjs';
const run=createRun();
try{
 const cfg=read('CONTRACT.json'),{candidate:c,baseline:b,containment}=await modules();run.save('containment.json',containment);
 const H=read('inputs/hamiltonians_24x8x8.json').rows[4].matrix_ev,old=read('prior/stage2_01/prediction.json'),records=[];
 run.log('diagnosis_started',{point:4,starts:old.starts.length});
 for(const s of old.starts){
  const diagnostics=c.gradientDiagnostics(H,s.parameters);
  if(diagnostics.gradient_max_difference>cfg.tolerances.gradient_crosscheck)throw Error('Gradient crosscheck failed');
  const improved=c.refineBFGS(H,s.parameters,cfg.method.bfgs);
  if(improved.max_amplitude_error>2e-10||improved.dense_energy_error_ev>1e-9)throw Error('Circuit comparison failed');
  const record={start:s.start,diagnostics,improved};records.push(record);run.save('start_'+s.start+'.json',record);
  run.log('diagnostic_state_refined',{start:s.start,old_energy_ev:s.final_energy_ev,new_energy_ev:improved.final_energy_ev,iterations:improved.iterations,gradient_norm:improved.gradient_norm});
 }
 run.save('predictions.json',records);
 const reference=b.jacobi(H),scores=records.map(r=>({start:r.start,old_gap_ev:r.diagnostics.original.energy_ev-reference.eigenvalues[0],new_gap_ev:r.improved.final_energy_ev-reference.eigenvalues[0],old_residual_ev:r.diagnostics.original.residual_ev,new_residual_ev:r.improved.residual_ev,initial_gradient_norm:r.diagnostics.gradient_norm,final_gradient_norm:r.improved.gradient_norm,gradient_crosscheck_error:r.diagnostics.gradient_max_difference,wrapping_energy_difference_ev:r.diagnostics.wrapping_energy_difference_ev,objective_evaluations:r.improved.objective_evaluations,iterations:r.improved.iterations,goal_pass:r.improved.final_energy_ev-reference.eigenvalues[0]<=1e-4}));
 run.save('diagnosis.json',{spectral_values:reference.eigenvalues,spectral_gap_ev:reference.eigenvalues[1]-reference.eigenvalues[0],same_ansatz:true,same_q8_engine:true,scores,all_saved_starts_meet_goal:scores.every(s=>s.goal_pass),interpretation:scores.some(s=>s.goal_pass)?'The unchanged ansatz can meet the target; coupled optimization resolves the earlier miss for the passing starts. This does not prove global convergence.':'The tested correction has not yet resolved the miss.'});
 run.finish();run.log('diagnosis_complete',{scores});
}catch(e){run.fail(e);}
