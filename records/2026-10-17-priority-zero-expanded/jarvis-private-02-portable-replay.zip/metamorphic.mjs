// Numerical identity checks for the corrected private workflow.
import {createRun,read,modules} from './runtime.mjs';
const run=createRun();
try{
 const {candidate:c,baseline:b,containment}=await modules();run.save('containment.json',containment);
 const contract=read('INVARIANCE_CONTRACT.json');run.save('invariance_contract.json',contract);
 const add=(x,y)=>[x[0]+y[0],x[1]+y[1]],mul=(x,y)=>[x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0]],conj=x=>[x[0],-x[1]],abs=x=>Math.hypot(x[0],x[1]);
 const matvec=(A,x)=>A.map(row=>row.reduce((s,z,j)=>add(s,mul(z,x[j])),[0,0]));
 const dagger=A=>A[0].map((_,i)=>A.map(row=>conj(row[i])));
 const matmul=(A,B)=>A.map(row=>B[0].map((_,j)=>row.reduce((s,z,k)=>add(s,mul(z,B[k][j])),[0,0])));
 const Fnorm=A=>Math.sqrt(A.reduce((s,row)=>s+row.reduce((t,z)=>t+z[0]*z[0]+z[1]*z[1],0),0));
 const records=[];function expect(id,actual,bound,detail={}){const pass=Number.isFinite(actual)&&actual<=bound;records.push({id,actual,bound,pass,...detail});if(!pass)throw Error(id+' exceeds '+bound+': '+actual);}
 const angles=Array.from({length:18},(_,i)=>.137*(i+1)),gates=b.ansatz(angles),columns=[];
 for(let j=0;j<8;j++){
  const prep=[];for(let q=0;q<3;q++)if(j&(1<<(2-q)))prep.push({kind:'X',q});
  const actual=b.actualState([...prep,...gates]).state,reference=b.dense(3,gates,j);
  expect('unitary_column_'+j,Math.max(...actual.map((z,i)=>abs(add(z,[-reference[i][0],-reference[i][1]])))),2e-10);columns.push(actual);
 }
 const U=columns[0].map((_,i)=>columns.map(col=>col[i])),Ud=dagger(U),unit=matmul(Ud,U);
 expect('unitarity',Math.max(...unit.flatMap((r,i)=>r.map((z,j)=>abs([z[0]-(i===j?1:0),z[1]])))),1e-10);
 for(const index of contract.case_indices){
  const data=read('validation_01/case_'+String(index).padStart(2,'0')+'_prediction.json'),H=data.reconstructed_hamiltonian_ev,psi=data.prediction.amplitudes,theta=data.prediction.parameters;
  const E=b.energy(H,psi),evals=b.jacobi(H).eigenvalues;
  const rotated=psi.map(z=>mul(z,[Math.cos(.731),Math.sin(.731)]));
  expect('global_phase_energy_'+index,Math.abs(b.energy(H,rotated)-E),1e-9);
  expect('global_phase_probability_'+index,Math.max(...psi.map((z,i)=>Math.abs(abs(z)**2-abs(rotated[i])**2))),2e-10);
  const Hp=matmul(matmul(Ud,H),U),psip=matvec(Ud,psi);b.validateH(Hp);
  expect('basis_energy_'+index,Math.abs(b.energy(Hp,psip)-E),1e-9);
  const evp=b.jacobi(Hp).eigenvalues;expect('basis_spectrum_'+index,Math.max(...evals.map((v,j)=>Math.abs(v-evp[j]))),1e-9);
  const gd=c.gradientDiagnostics(H,theta);expect('gradient_crosscheck_'+index,gd.gradient_max_difference,3e-8);
  for(const shift of contract.energy_shifts_ev){
   const shifted=H.map((row,i)=>row.map((z,j)=>[z[0]+(i===j?shift:0),z[1]]));
   expect('energy_shift_'+index+'_'+shift,Math.abs(b.energy(shifted,psi)-(E+shift)),1e-9);
   const es=b.jacobi(shifted).eigenvalues;expect('spectrum_shift_'+index+'_'+shift,Math.max(...evals.map((v,j)=>Math.abs(es[j]-(v+shift)))),1e-9);
   const gs=c.gradientDiagnostics(shifted,theta);expect('gradient_shift_'+index+'_'+shift,Math.max(...gd.gradient.map((v,j)=>Math.abs(v-gs.gradient[j]))),1e-9);
  }
  const random=b.rng((contract.seed+index)>>>0),D=Array.from({length:8},()=>Array.from({length:8},()=>[0,0]));
  for(let i=0;i<8;i++)for(let j=i;j<8;j++){const z=[(2*random()-1)*1e-5,i===j?0:(2*random()-1)*1e-5];D[i][j]=z;D[j][i]=conj(z);}
  const perturbed=H.map((row,i)=>row.map((z,j)=>add(z,D[i][j]))),bound=Fnorm(D),pe=b.jacobi(perturbed).eigenvalues;
  expect('perturbation_spectrum_'+index,Math.max(...evals.map((v,j)=>Math.abs(v-pe[j]))),bound+1e-9,{frobenius_bound_ev:bound});
  expect('perturbation_expectation_'+index,Math.abs(b.energy(perturbed,psi)-E),bound+1e-9,{frobenius_bound_ev:bound});
  run.log('invariance_case_complete',{index});
 }
 run.save('checks.json',records);run.save('summary.json',{owner:'Sherman G. Laing',checks:records.length,passed:records.filter(r=>r.pass).length,all_passed:records.every(r=>r.pass),case_indices:contract.case_indices,scope:'Fixed same-material states; global phase, complex basis covariance, energy offsets, gradients, and bounded Hermitian perturbations',signature:'UNSIGNED'});run.finish();run.log('invariance_complete',{checks:records.length});
}catch(e){run.fail(e);}
