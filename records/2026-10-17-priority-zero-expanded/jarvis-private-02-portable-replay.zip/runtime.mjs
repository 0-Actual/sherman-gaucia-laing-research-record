// Local-only mirrored evidence utilities. Sherman G. Laing / GAUCIA.
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {fileURLToPath} from 'node:url';import {performance} from 'node:perf_hooks';
import {hashBytes,PROFILE} from './vendor/sgl-prime.mjs';
export const root=path.dirname(fileURLToPath(import.meta.url));
export const read=rel=>JSON.parse(fs.readFileSync(path.join(root,rel),'utf8'));
export const readText=rel=>fs.readFileSync(path.join(root,rel),'utf8');
export function createRun(){
 const label=process.argv[2],mirror=process.argv[3];if(!/^[a-z0-9_-]{1,60}$/.test(label)||!mirror)throw Error('Unique run label and mirror required');
 const dirs=[path.join(root,label),path.join(mirror,label)];for(const d of dirs)fs.mkdirSync(d);
 const start=performance.now(),cpu=process.cpuUsage(),at=new Date().toISOString();let peak=process.memoryUsage().rss;
 const save=(name,value)=>{const b=Buffer.from(JSON.stringify(value,null,2)+'\n');for(const d of dirs){const p=path.join(d,name);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,b,{flag:'wx'});if(!b.equals(fs.readFileSync(p)))throw Error('Mirror mismatch');}};
 const log=(stage,data={})=>{peak=Math.max(peak,process.memoryUsage().rss);const e={at_utc:new Date().toISOString(),stage,...data};for(const d of dirs)fs.appendFileSync(path.join(d,'events.ndjson'),JSON.stringify(e)+'\n');console.log(JSON.stringify(e));};
 const sources=['candidate.mjs','baseline.mjs','CONTRACT.json','runtime.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs',path.basename(process.argv[1])];
 const ids=sources.map(f=>({file:f,identity:hashBytes(fs.readFileSync(path.join(root,f)),'jarvis-pass2-source')}));
 save('source_identities.json',{profile:PROFILE,files:ids,signature:'UNSIGNED'});save('contract.json',read('CONTRACT.json'));
 const finish=()=>{for(const r of ids)if(hashBytes(fs.readFileSync(path.join(root,r.file)),'jarvis-pass2-source')!==r.identity)throw Error('Source changed');save('execution.json',{started_utc:at,finished_utc:new Date().toISOString(),elapsed_ms:performance.now()-start,cpu_microseconds:process.cpuUsage(cpu),sampled_maximum_rss_bytes:Math.max(peak,process.memoryUsage().rss),resource_usage:process.resourceUsage(),node:process.version,platform:process.platform,source_unchanged:true,mirror_bytes_verified:true});};
 return {save,log,finish,fail:e=>{save('failure.json',{error:String(e),stack:e.stack});console.error(e);process.exitCode=1;}};
}
export async function modules(){
 const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}}),cache=new Map(),allow=new Set(['candidate.mjs','baseline.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']);
 async function load(rel){if(!allow.has(rel))throw Error('Import outside allowlist');if(cache.has(rel))return cache.get(rel);const m=new vm.SourceTextModule(readText(rel),{context,identifier:rel});cache.set(rel,m);await m.link((s,p)=>{if(!s.startsWith('./'))throw Error('External import denied');return load(path.posix.normalize(path.posix.join(path.posix.dirname(p.identifier),s)));});return m;}
 const m=await load('candidate.mjs');await m.evaluate({timeout:5000});
 const bindings=vm.runInContext('({process:typeof process,require:typeof require,fetch:typeof fetch,WebSocket:typeof WebSocket})',context);if(Object.values(bindings).some(v=>v!=='undefined'))throw Error('Host/network binding present');
 return {candidate:m.namespace,baseline:cache.get('baseline.mjs').namespace,containment:{bindings,allowlist:[...allow],code_generation_disabled:true,node_permissions:!!process.permission,os_network_isolation:false}};
}
