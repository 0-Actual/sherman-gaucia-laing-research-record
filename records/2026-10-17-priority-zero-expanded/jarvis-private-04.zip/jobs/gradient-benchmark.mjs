import {modules,read} from './runtime.mjs';
export async function run({save,log}){
 const m=await modules(),H=read('inputs/challenge-inputs.json')[0].H,random=m.b.rng(398541727),angles=Array.from({length:64},()=>Array.from({length:18},()=>random()*6-3)),rows=[];
 const old=t=>t.map((_,j)=>{const p=t.slice(),n=t.slice();p[j]+=Math.PI/2;n[j]-=Math.PI/2;return (m.b.energy(H,m.b.actualState(m.b.ansatz(p)).state)-m.b.energy(H,m.b.actualState(m.b.ansatz(n)).state))/2;});
 const shift=m.ad.createObjective(H,'shift'),adjoint=m.ad.createObjective(H,'adjoint'),methods={old,compiled_shift:t=>shift.gradient(t),adjoint:t=>adjoint.gradient(t)};
 for(const fn of Object.values(methods))for(const t of angles.slice(0,4))fn(t);
 for(let repeat=0;repeat<5;repeat++){const names=Object.keys(methods),r=repeat%3,order=names.slice(r).concat(names.slice(0,r));for(const method of order){const at=performance.now(),cpu=process.cpuUsage();let checksum=0;for(const t of angles){const g=methods[method](t);checksum+=g.reduce((s,x,i)=>s+x*(i+1),0);}rows.push({repeat,method,gradients:angles.length,wall_ms:performance.now()-at,cpu_microseconds:process.cpuUsage(cpu),checksum});}}
 const spread=Math.max(...rows.map(r=>r.checksum))-Math.min(...rows.map(r=>r.checksum)),passed=spread<1e-8;
 save('rows.json',rows);save('summary.json',{passed,fixed_parameter_sets:64,repeats:5,checksum_spread:spread,compiled_shift:shift.counters(),adjoint:adjoint.counters(),interpretation:'Same matrices and parameters; compiled_shift isolates representation change, adjoint isolates derivative reuse. Warm-up of four gradients per method excluded from reported timings.'});log('gradient_benchmark',{passed,spread});if(!passed)throw Error('Gradient benchmark disagreed');
}
