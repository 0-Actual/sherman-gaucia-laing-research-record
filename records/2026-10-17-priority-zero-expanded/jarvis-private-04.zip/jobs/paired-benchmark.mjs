import {modules,read} from './runtime.mjs';
import {score,directSolve} from './assessment.mjs';
export async function run({save,log,args}){
 const group=Number(args[0]);if(!Number.isInteger(group)||group<0||group>5)throw Error('Benchmark group 0..5 required');
 const m=await modules(),all=read('inputs/challenge-inputs.json'),ids=[...Array.from({length:12},(_,i)=>i),...Array.from({length:12},(_,i)=>48+i)].slice(group*4,group*4+4),cfg=read('inputs/BRACKETED_CONTRACT.json').method,rows=[];
 const methods=['direct','energy_only','old_hybrid','compiled_shift','fast_hybrid'];
 for(let repeat=0;repeat<3;repeat++)for(const id of ids){
  const c=all[id],rotation=(repeat+id)%methods.length,order=methods.slice(rotation).concat(methods.slice(0,rotation));
  for(const method of order){
   log('method_started',{id,repeat,method});const at=performance.now(),cpu=process.cpuUsage();
   const prediction=method==='direct'?directSolve(m,c.H):method==='energy_only'?m.c.refineBFGS(c.H,c.initial,cfg.fit):method==='old_hybrid'?m.cg.conditionedRefine(c.H,c.initial,cfg,c.solver_seed):m.fast.fastRefine(c.H,c.initial,cfg,c.solver_seed,method==='compiled_shift'?'shift':'adjoint');
   const wall=performance.now()-at,usage=process.cpuUsage(cpu),name='prediction_'+id+'_'+repeat+'_'+method+'.json';
   save(name,{id,repeat,method,initial_parameters:c.initial,prediction});
   const reference=read('inputs/challenge-references.json')[id],assessment=score(m,c.H,prediction,reference),fit=prediction.fit_starts||prediction.normalized_prediction?.fit_starts||[{iterations:prediction.iterations,evaluations:prediction.objective_evaluations}];
   const row={id,kind:c.kind,gap:c.gap,repeat,method,order:order.indexOf(method),wall_ms:wall,cpu_microseconds:usage,assessment,iterations:fit.reduce((s,x)=>s+(x.iterations||0),0),forward_evaluations:fit.reduce((s,x)=>s+(x.evaluations||0),0)};
   rows.push(row);save('score_'+id+'_'+repeat+'_'+method+'.json',row);log('method_finished',{id,repeat,method,ms:wall,accepted:assessment.accepted});
  }
 }
 save('rows.json',rows);
 const counts=Object.fromEntries(methods.map(method=>[method,{runs:rows.filter(r=>r.method===method).length,passed:rows.filter(r=>r.method===method&&r.assessment.accepted).length,total_ms:rows.filter(r=>r.method===method).reduce((s,r)=>s+r.wall_ms,0)}]));
 save('summary.json',{group,ids,repeats:3,counts,comparison:'Same Hamiltonians, starting parameters, fit budgets, target algorithm and perturbation seeds; method order rotated. Direct solution produces no circuit. Energy-only BFGS has no target assistance. All prediction files committed before reading scoring references.'});log('benchmark_complete',{group,counts});
 if(rows.some(r=>r.method==='fast_hybrid'&&!r.assessment.accepted))throw Error('Fast hybrid acceptance regressed');
}
