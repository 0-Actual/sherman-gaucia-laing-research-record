@echo off
setlocal
"./REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe" --no-warnings --max-old-space-size=64 "%~dp0local-lab.mjs" %*
set "qel_lab_exit=%errorlevel%"
if not "%qel_lab_exit%"=="0" pause
exit /b %qel_lab_exit%
