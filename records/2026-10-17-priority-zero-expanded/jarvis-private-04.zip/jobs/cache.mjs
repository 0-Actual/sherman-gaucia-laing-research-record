import fs from 'node:fs';
import path from 'node:path';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export const CACHE_SCHEMA='qel-wannier-f64le-v1';
export function verifyCache({raw,payload,metadata,parserSource,packedSource}){
 const m=metadata;
 if(m.schema!==CACHE_SCHEMA||m.blocks!==1041||m.orbitals!==8||m.stride!==131||m.endian!=='LE'||m.weighting!=='coefficients divided by original block degeneracy')throw Error('Cache schema mismatch');
 if(payload.length!==1041*131*8||m.payload_bytes!==payload.length)throw Error('Cache payload length mismatch');
 if(hashBytes(raw,'qel-jarvis-input')!==m.raw_identity)throw Error('Cache raw-source identity mismatch');
 if(hashBytes(parserSource,'qel-work-artifact')!==m.parser_identity||hashBytes(packedSource,'qel-work-artifact')!==m.packed_identity)throw Error('Cache implementation identity mismatch');
 if(hashBytes(payload,'qel-wannier-cache')!==m.payload_identity)throw Error('Cache payload identity mismatch');
 const data=new Float64Array(1041*131);for(let i=0;i<data.length;i++){const v=payload.readDoubleLE(8*i);if(!Number.isFinite(v)||(i%131<3&&!Number.isInteger(v)))throw Error('Invalid packed coefficient');data[i]=v;}return data;
}
export function loadCache(root){
 const metadata=JSON.parse(fs.readFileSync(path.join(root,'cache','metadata.json'),'utf8'));
 return verifyCache({metadata,raw:fs.readFileSync(path.join(root,'inputs','wannier90_hr.dat')),payload:fs.readFileSync(path.join(root,'cache','wannier-f64.bin')),parserSource:fs.readFileSync(path.join(root,'numerics','baseline.mjs')),packedSource:fs.readFileSync(path.join(root,'numerics','packed-wannier.mjs'))});
}
