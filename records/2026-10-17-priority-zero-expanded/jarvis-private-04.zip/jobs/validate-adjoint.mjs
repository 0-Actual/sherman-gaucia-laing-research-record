import {modules} from './runtime.mjs';
export async function run({save,log}){
 const {b,ad}=await modules(),random=b.rng(2875140197),rows=[];
 let maxState=0,maxGradient=0,maxFiniteDifference=0,maxInverse=0,stateChecks=0,gradientComponents=0;
 for(let sample=0;sample<64;sample++){
  const theta=Array.from({length:18},(_,i)=>sample===0?0:sample===1?Math.PI*(i%3-1):(2*random()-1)*8*Math.PI);
  const H=Array.from({length:8},()=>Array.from({length:8},()=>[0,0]));
  for(let i=0;i<8;i++){H[i][i]=[2*random()-1,0];for(let j=0;j<i;j++){const z=[2*random()-1,2*random()-1];H[i][j]=z;H[j][i]=[z[0],-z[1]];}}
  const obj=ad.createObjective(H),g=obj.gradient(theta),f=obj.objective(theta),actual=b.actualState(b.ansatz(theta)).state;
  let stateError=Math.max(...actual.map((z,i)=>Math.hypot(z[0]-obj.state(theta)[i][0],z[1]-obj.state(theta)[i][1]))),gradientError=0,finiteError=0;
  for(let j=0;j<18;j++){
   const plus=theta.slice(),minus=theta.slice();plus[j]+=Math.PI/2;minus[j]-=Math.PI/2;
   const shift=(b.energy(H,b.actualState(b.ansatz(plus)).state)-b.energy(H,b.actualState(b.ansatz(minus)).state))/2;
   const ap=theta.slice(),am=theta.slice();ap[j]+=1e-5;am[j]-=1e-5;
   const fd=(b.independentEnergy(H,b.dense(3,b.ansatz(ap)))-b.independentEnergy(H,b.dense(3,b.ansatz(am))))/(2e-5);
   gradientError=Math.max(gradientError,Math.abs(g[j]-shift));finiteError=Math.max(finiteError,Math.abs(g[j]-fd));gradientComponents++;
  }
  for(let basis=0;basis<8;basis++){
   const v=ad.stateVector(theta,basis),d=b.dense(3,b.ansatz(theta),basis);
   maxState=Math.max(maxState,...d.map((z,i)=>Math.hypot(z[0]-v[2*i],z[1]-v[2*i+1])));stateChecks++;
   for(let k=ad.layout.length-1;k>=0;k--)ad.applyGate(v,ad.layout[k],theta,true);
   maxInverse=Math.max(maxInverse,...Array.from(v,(x,i)=>Math.abs(x-+(i===2*basis))));
  }
  maxState=Math.max(maxState,stateError);maxGradient=Math.max(maxGradient,gradientError);maxFiniteDifference=Math.max(maxFiniteDifference,finiteError);
  rows.push({sample,state_error:stateError,gradient_error:gradientError,finite_difference_error:finiteError,energy_error:Math.abs(f-b.energy(H,actual)),counts:obj.counters()}); }
 const passed=maxState<=2e-12&&maxGradient<=2e-10&&maxFiniteDifference<=2e-7&&maxInverse<=2e-12;
 save('rows.json',rows);save('summary.json',{passed,angle_sets:64,basis_state_checks:stateChecks,derivative_components:gradientComponents,max_state_error:maxState,max_parameter_shift_error:maxGradient,max_finite_difference_error:maxFiniteDifference,max_inverse_error:maxInverse,thresholds:{state:2e-12,gradient:2e-10,finite_difference:2e-7,inverse:2e-12}});
 log('derivative_validation',{passed,maxState,maxGradient,maxFiniteDifference,maxInverse});if(!passed)throw Error('Adjoint correctness gate failed');
}
