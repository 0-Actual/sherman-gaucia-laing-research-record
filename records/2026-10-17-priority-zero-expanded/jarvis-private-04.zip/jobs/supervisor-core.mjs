import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {spawn} from 'node:child_process';
import {pathToFileURL} from 'node:url';
import {roots,root,read,saveBoth,environment} from './runtime.mjs';
import {openLedger,mirroredArtifact} from './work-ledger-v2.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export async function executeJob(job,label,args=[],onLog=()=>{}) {
if(!/^[a-z0-9-]+$/.test(job)||!/^[a-z0-9_-]{1,60}$/.test(label))throw Error('Invalid job or label');
const contract=read('WORK_CONTRACT.json'),ledger=openLedger(roots,contract),locks=[roots[0].replace('_04','_03')+'/CONTROLLER.lock',roots[0]+'/CONTROLLER.lock'],owned=[];
let registered=false,started=false,finished=false;
const at=new Date().toISOString(),begin=performance.now(),cpu=process.cpuUsage();
try{
 for(const r of roots)if(!fs.existsSync(r))throw Error('Both local destinations required');
 for(const lock of locks){fs.writeFileSync(lock,JSON.stringify({pid:process.pid,label,mode:'qel_private_performance',at}),{flag:'wx'});owned.push(lock);}
 try{os.setPriority(process.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);}catch{}
 const files=[...fs.readdirSync(root+'/numerics',{recursive:true}).filter(f=>fs.statSync(root+'/numerics/'+f).isFile()).map(f=>'numerics/'+f.replaceAll('\\','/')),'jobs/runtime.mjs','jobs/runner.mjs','jobs/worker.mjs','jobs/work-guard-v2.mjs','jobs/work-ledger-v2.mjs','control/vendor/sgl-prime.mjs','WORK_CONTRACT.json','jobs/'+job+'.mjs'];
 files.push(...fs.readdirSync(root+'/jobs').filter(f=>f.endsWith('.mjs')).map(f=>'jobs/'+f));files.push(...fs.readdirSync(root+'/inputs').filter(f=>fs.statSync(root+'/inputs/'+f).isFile()).map(f=>'inputs/'+f));if(fs.existsSync(root+'/jobs/assessment.mjs'))files.push('jobs/assessment.mjs');
 if(fs.existsSync(root+'/cache'))files.push(...fs.readdirSync(root+'/cache').map(f=>'cache/'+f));if(fs.existsSync(root+'/APP_MANIFEST.json'))files.push('APP_MANIFEST.json');
 const pins=[...new Set(files)].map(f=>mirroredArtifact(roots,f)),artifacts=[];
 const save=(name,data)=>{if(!/^[a-zA-Z0-9_.-]+$/.test(name))throw Error('Invalid output name');const record=saveBoth('runs/'+label+'/'+name,data);artifacts.push(record);return record;};
 const log=(stage,data={})=>onLog({at_utc:new Date().toISOString(),label,stage,...data});
 ledger.appendMany([{type:'JOB_REGISTERED',data:{id:label,purpose:'Execute verified private laptop study: '+job,source_pins:pins}},{type:'JOB_STARTED',data:{id:label}}]);registered=true;started=true;
 save('sources.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',files:pins});save('environment.json',environment());
 const flags=['--no-warnings','--max-old-space-size=128','--experimental-vm-modules','--permission',...roots.map(r=>'--allow-fs-read='+r),...roots.map(r=>'--allow-fs-write='+r)];
 const child=spawn(process.execPath,[...flags,root+'/jobs/worker.mjs',job,label,...args],{stdio:['ignore','pipe','pipe'],windowsHide:true,timeout:1200000}); let stdout='',stderr='';child.stdout.on('data',chunk=>{stdout+=chunk;});child.stderr.on('data',chunk=>{stderr+=chunk;});
 const result=await new Promise((resolve,reject)=>{child.on('error',reject);child.on('exit',(code,signal)=>resolve({code,signal}));});save('worker-stdout.log',Buffer.from(stdout));save('worker-stderr.log',Buffer.from(stderr));if(result.code!==0)throw Error('Contained worker failed: '+JSON.stringify(result)+' '+stderr.slice(-500));
 for(const file of fs.readdirSync(root+'/runs/'+label)){const rel='runs/'+label+'/'+file;const record=mirroredArtifact(roots,rel);for(const r of roots){const fd=fs.openSync(path.join(r,rel),'r+');try{fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}if(!artifacts.some(a=>a.path===rel))artifacts.push(record);}
 for(const p of pins)if(mirroredArtifact(roots,p.path).identity!==p.identity)throw Error('Source changed during execution: '+p.path);
 const elapsed=performance.now()-begin;save('execution.json',{started_utc:at,finished_utc:new Date().toISOString(),elapsed_ms:elapsed,cpu_microseconds:process.cpuUsage(cpu),maximum_rss_kib:process.resourceUsage().maxRSS,ending_environment:environment(),source_unchanged:true,mirrored:true});
 let remaining=elapsed;while(remaining>0){const delta=Math.min(remaining,65000);ledger.append('SESSION_PROGRESS',{elapsed_ms:delta,basis:'Measured monotonic job duration partitioned for bounded ledger entries'});remaining-=delta;}
 ledger.appendMany([{type:'JOB_FINISHED',data:{id:label,exit_code:0,bytes_verified:true,elapsed_ms:elapsed,artifacts}},{type:'CHECKPOINT',data:{evidence:'runs/'+label+'/execution.json'}}]);finished=true;log('FINISHED',{elapsed_ms:elapsed,artifacts:artifacts.length});return {ok:true,label,elapsed_ms:elapsed};
}catch(error){
 try{saveBoth('forensics/'+label+'_'+Date.now()+'.json',{at_utc:new Date().toISOString(),job,label,error:String(error),stack:error.stack,signature:'UNSIGNED'});if(started&&!finished)ledger.append('JOB_FAILED',{id:label,error:String(error)});}catch(e){console.error('Forensic recording: '+e.message);}
 return {ok:false,label,error:String(error)};
}finally{for(const lock of owned.reverse())if(fs.existsSync(lock)&&JSON.parse(fs.readFileSync(lock)).pid===process.pid)fs.unlinkSync(lock);}

}
