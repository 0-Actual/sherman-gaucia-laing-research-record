import {modules,bytes,read} from './app-runtime.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
import {verifyCache,CACHE_SCHEMA} from './cache.mjs';
export async function run({save,log}){
 const m=await modules(),raw=bytes('inputs/wannier90_hr.dat'),parserSource=bytes('numerics/baseline.mjs'),packedSource=bytes('numerics/packed-wannier.mjs');
 const dependencyPins=['jobs/app-runtime.mjs','jobs/cache.mjs'].map(file=>({file,identity:hashBytes(bytes(file),'qel-work-artifact')}));save('dependency-pins.json',dependencyPins);
 const started=performance.now(),blocks=m.b.parseWannier(raw.toString('utf8')),payload=Buffer.alloc(1041*131*8);
 for(let b=0;b<1041;b++){const values=blocks[b].R.concat(blocks[b].h.flatMap(row=>row.flat()));for(let j=0;j<131;j++)payload.writeDoubleLE(values[j],8*(b*131+j));}
 const metadata={schema:CACHE_SCHEMA,owner:'Sherman G. Laing',signature:'UNSIGNED',blocks:1041,orbitals:8,stride:131,endian:'LE',weighting:'coefficients divided by original block degeneracy',payload_bytes:payload.length,raw_identity:hashBytes(raw,'qel-jarvis-input'),parser_identity:hashBytes(parserSource,'qel-work-artifact'),packed_identity:hashBytes(packedSource,'qel-work-artifact'),payload_identity:hashBytes(payload,'qel-wannier-cache')};
 const params={raw,payload,metadata,parserSource,packedSource},data=verifyCache(params);m.packed.validatePacked(data);const buildMs=performance.now()-started;
 const points=[];for(let i=0;i<5;i++)for(let j=0;j<5;j++)for(let k=0;k<5;k++)points.push([i/5,j/5,k/5]);points.push(...read('inputs/challenge-inputs.json').filter(c=>c.kind==='material').map(c=>c.kpoint));
 const rows=[];let maxError=0,maxPeriodic=0,maxHermitian=0;
 for(const k of points){const a=m.b.constructH(blocks,k),b=m.packed.constructPacked(data,k),periodic=m.packed.constructPacked(data,k.map((x,i)=>x+[1,-2,1][i])),error=Math.max(...a.h.flatMap((row,i)=>row.map((z,j)=>Math.hypot(z[0]-b.h[i][j][0],z[1]-b.h[i][j][1])))),pe=Math.max(...b.h.flatMap((row,i)=>row.map((z,j)=>Math.hypot(z[0]-periodic.h[i][j][0],z[1]-periodic.h[i][j][1]))));
  maxError=Math.max(maxError,error);maxPeriodic=Math.max(maxPeriodic,pe);maxHermitian=Math.max(maxHermitian,b.rawDefect);rows.push({k,error,periodicity_error:pe});
 }
 const corruptions=[];
 const reject=(name,change)=>{let rejected=false;try{verifyCache(change(params));}catch{rejected=true;}corruptions.push({name,rejected});};
 reject('flipped_payload_byte',p=>{const b=Buffer.from(p.payload);b[41]^=1;return {...p,payload:b};});
 reject('truncated_payload',p=>({...p,payload:p.payload.subarray(0,-8)}));reject('appended_payload',p=>({...p,payload:Buffer.concat([p.payload,Buffer.alloc(8)])}));
 reject('wrong_schema',p=>({...p,metadata:{...p.metadata,schema:'unknown'}}));reject('wrong_count',p=>({...p,metadata:{...p.metadata,blocks:1040}}));reject('wrong_endian',p=>({...p,metadata:{...p.metadata,endian:'BE'}}));
 reject('changed_raw_input',p=>({...p,raw:Buffer.concat([p.raw,Buffer.from('\n')])}));reject('changed_parser',p=>({...p,parserSource:Buffer.concat([p.parserSource,Buffer.from('\n')])}));reject('changed_packed_code',p=>({...p,packedSource:Buffer.concat([p.packedSource,Buffer.from('\n')])}));
 const timings=[];for(let repeat=0;repeat<5;repeat++){for(const method of repeat%2?['packed','original']:['original','packed']){const at=performance.now();for(const k of points)method==='packed'?m.packed.constructPacked(data,k):m.b.constructH(blocks,k);timings.push({repeat,method,matrix_count:points.length,wall_ms:performance.now()-at});}}
 const abA=[points[2],points[37],points[2]].map(k=>m.packed.constructPacked(data,k).h),repeatStable=JSON.stringify(abA[0])===JSON.stringify(abA[2]);
 const passed=maxError<=1e-12&&maxPeriodic<=1e-9&&maxHermitian<=1e-8&&repeatStable&&corruptions.every(c=>c.rejected);
 save('wannier-f64.bin',payload);save('metadata.json',metadata);save('matrix-comparisons.json',rows);save('timings.json',timings);save('summary.json',{passed,matrices:points.length,payload_bytes:payload.length,build_ms:buildMs,max_matrix_error:maxError,max_periodic_error:maxPeriodic,max_hermiticity_defect:maxHermitian,repeat_A_B_A_stable:repeatStable,corruptions});
 for(const pin of dependencyPins)if(hashBytes(bytes(pin.file),'qel-work-artifact')!==pin.identity)throw Error('Cache dependency changed');
 log('cache_validated',{passed,matrices:points.length,maxError,maxPeriodic,buildMs});if(!passed)throw Error('Packed cache validation failed');}
