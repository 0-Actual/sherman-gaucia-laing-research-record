import {modules,read} from './runtime.mjs';
import {score,directSolve} from './assessment.mjs';
export async function run({save,log,args}){
 const m=await modules(),cases=read('inputs/challenge-inputs.json'),cfg=read('inputs/BRACKETED_CONTRACT.json').method,rows=[];
 for(const c of cases){const times={},predictions={};for(const method of ['direct','fast']){const at=performance.now(),cpu=process.cpuUsage();predictions[method]=method==='direct'?directSolve(m,c.H):m.fast.fastRefine(c.H,c.initial,cfg,c.solver_seed);times[method]={wall_ms:performance.now()-at,cpu_microseconds:process.cpuUsage(cpu)};}
  save('prediction_'+String(c.id).padStart(3,'0')+'.json',{id:c.id,predictions});
  const ref=read('inputs/challenge-references.json')[c.id],scores=Object.fromEntries(Object.entries(predictions).map(([key,p])=>[key,score(m,c.H,p,ref)]));rows.push({id:c.id,kind:c.kind,gap:c.gap,times,scores});log('case_scored',{id:c.id,fast:scores.fast.accepted,direct:scores.direct.accepted,fast_ms:times.fast.wall_ms});
 }
 const summary={cases:rows.length,direct_passes:rows.filter(r=>r.scores.direct.accepted).length,fast_passes:rows.filter(r=>r.scores.fast.accepted).length,fast_total_ms:rows.reduce((s,r)=>s+r.times.fast.wall_ms,0),direct_total_ms:rows.reduce((s,r)=>s+r.times.direct.wall_ms,0),minimum_fast_fidelity:Math.min(...rows.map(r=>r.scores.fast.measurement.fidelity)),maximum_fast_energy_error_ev:Math.max(...rows.map(r=>r.scores.fast.measurement.energy_error_ev)),failures:rows.filter(r=>!r.scores.fast.accepted||!r.scores.direct.accepted).map(r=>r.id)};
 save('rows.json',rows);save('summary.json',summary);log('accuracy_complete',summary);if(summary.failures.length)throw Error('Challenge acceptance gate failed');
}
