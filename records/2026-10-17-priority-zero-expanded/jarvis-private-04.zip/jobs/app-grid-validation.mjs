import {modules,root,read,bytes} from './app-runtime.mjs';
import {loadCache} from './cache.mjs';
import {score} from './assessment.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export async function run({save,log}){
 const dependencies=['jobs/app-runtime.mjs','jobs/cache.mjs','cache/metadata.json','cache/wannier-f64.bin'].map(file=>({file,identity:hashBytes(bytes(file),'qel-work-artifact')}));save('dependency-pins.json',dependencies);
 const m=await modules(),data=loadCache(root),cfg=read('inputs/BRACKETED_CONTRACT.json').method,points=[],rows=[];
 for(let i=0;i<5;i++)for(let j=0;j<5;j++)for(let k=0;k<5;k++)points.push([i/5,j/5,k/5]);points.push(...read('inputs/challenge-inputs.json').filter(c=>c.kind==='material').map(c=>c.kpoint));
 for(let id=0;id<points.length;id++){
  const k=points[id],H=m.packed.constructPacked(data,k).h,random=m.b.rng(2026092053),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI),started=performance.now(),prediction=m.fast.fastRefine(H,initial,cfg,2026092154),elapsed=performance.now()-started;
  save('prediction_'+id+'.json',prediction);
  const bands=m.b.jacobi(H),A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);})),e=m.n.symmetricEigen(A),difference=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(e.values[2*j]+e.values[2*j+1])/2)));
  if(difference>1e-9||bands.residual>1e-9||e.residual>1e-9)throw Error('Grid reference mismatch');
  const ref={kind:'real_eigenvectors',real_vectors:e.vectors,energy_ev:bands.eigenvalues[0],dimension:bands.eigenvalues.filter(v=>v-bands.eigenvalues[0]<=1e-9).length,residual:Math.max(bands.residual,e.residual)},assessment=score(m,H,prediction,ref);
  rows.push({id,kpoint:k,elapsed_ms:elapsed,assessment});if(id%25===0)log('grid_progress',{completed:id+1,total:points.length});if(!assessment.accepted)log('grid_miss',{id,k,assessment});
 }
 for(const pin of dependencies)if(hashBytes(bytes(pin.file),'qel-work-artifact')!==pin.identity)throw Error('Application grid dependency changed');
 const summary={cases:rows.length,passed:rows.filter(r=>r.assessment.accepted).length,minimum_fidelity:Math.min(...rows.map(r=>r.assessment.measurement.fidelity)),maximum_energy_error_ev:Math.max(...rows.map(r=>r.assessment.measurement.energy_error_ev)),total_solver_ms:rows.reduce((s,r)=>s+r.elapsed_ms,0),scope:'Actual packed builder, default application seed, 125 grid points plus 24 previously frozen fresh material points. Every solve restarts; overlapping with other validation sets.'};
 save('rows.json',rows);save('summary.json',summary);log('app_grid_complete',summary);if(summary.passed!==summary.cases)throw Error('Default application accuracy gate failed');
}
