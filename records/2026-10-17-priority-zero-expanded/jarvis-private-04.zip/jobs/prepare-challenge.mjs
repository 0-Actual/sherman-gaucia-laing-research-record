import {modules,bytes} from './runtime.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export async function run({save,log}){
 const {b,n}=await modules(),inputs=[],references=[],seeds=new Set(),gaps=[1,.01,.0001,.000001,.00000001,0];
 const seed=(domain,i)=>{const id=hashBytes(Buffer.from('QEL private performance study 2026-09-20 | '+domain+' | '+i),'qel-study-seed');let s=parseInt(id.slice(-8),16)>>>0;while(!s||seeds.has(s))s=(s+1)>>>0;seeds.add(s);return s;};
 const inner=(a,c)=>a.reduce((s,z,i)=>[s[0]+z[0]*c[i][0]+z[1]*c[i][1],s[1]+z[0]*c[i][1]-z[1]*c[i][0]],[0,0]);
 function basis(s){const random=b.rng(s),normal=()=>Math.sqrt(-2*Math.log(Math.max(random(),1e-15)))*Math.cos(2*Math.PI*random()),cols=[];
  for(let j=0;j<8;j++){let v=Array.from({length:8},()=>[normal(),normal()]);for(let pass=0;pass<2;pass++)for(const u of cols){const z=inner(u,v);v=v.map((a,i)=>[a[0]-u[i][0]*z[0]+u[i][1]*z[1],a[1]-u[i][0]*z[1]-u[i][1]*z[0]]);}const norm=Math.sqrt(inner(v,v)[0]);if(norm<1e-10)throw Error('Ill-conditioned generated basis');cols.push(v.map(z=>[z[0]/norm,z[1]/norm]));}return cols;}
 function add(H,meta,reference){
  const initialSeed=seed('initial-parameters',inputs.length),random=b.rng(initialSeed),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
  const psi=b.actualState(b.ansatz(initial)).state;
  const f=reference.kind==='known_basis'?reference.columns.slice(0,reference.dimension).reduce((sum,col)=>{const z=inner(col,psi);return sum+z[0]**2+z[1]**2;},0):reference.real_vectors.slice(0,2*reference.dimension).reduce((sum,col)=>{const v=psi.map(z=>z[0]).concat(psi.map(z=>z[1]));return sum+col.reduce((s,x,i)=>s+x*v[i],0)**2;},0);
  if(!(f<.9999))throw Error('Initially solved challenge case rejected');
  const id=inputs.length;inputs.push({id,H,initial,initial_seed:initialSeed,solver_seed:seed('solver-perturbations',id),...meta});references.push({id,...reference,initial_fidelity:f});
 }
 for(let family=0;family<8;family++){const bs=seed('gaussian-basis',family),cols=basis(bs);
  for(const gap of gaps){const spectrum=[-.75,-.75+gap,1,2,3,4,5,6],H=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>{let re=0,im=0;for(let k=0;k<8;k++){re+=spectrum[k]*(cols[k][i][0]*cols[k][j][0]+cols[k][i][1]*cols[k][j][1]);im+=spectrum[k]*(cols[k][i][1]*cols[k][j][0]-cols[k][i][0]*cols[k][j][1]);}return [re,im];}));
   const bands=b.jacobi(H);if(Math.max(...bands.eigenvalues.map((v,i)=>Math.abs(v-spectrum[i])))>1e-10)throw Error('Known spectrum mismatch');
   add(H,{kind:'synthetic',family,gap,basis_seed:bs},{kind:'known_basis',columns:cols,spectrum,energy_ev:spectrum[0],dimension:gap===0?2:1,residual:bands.residual});
  }
 }
 const blocks=b.parseWannier(bytes('inputs/wannier90_hr.dat').toString('utf8')),random=b.rng(seed('new-material-coordinates',0));
 for(let i=0;i<24;i++){const kpoint=Array.from({length:3},()=>Math.round(random()*1e9)/1e9),built=b.constructH(blocks,kpoint),H=built.h,bands=b.jacobi(H);
  const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);})),ref=n.symmetricEigen(A),difference=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(ref.values[2*j]+ref.values[2*j+1])/2)));
  if(ref.residual>1e-9||difference>1e-9||built.rawDefect>1e-8)throw Error('Material reference disagreement');  add(H,{kind:'material',kpoint},{kind:'real_eigenvectors',real_vectors:ref.vectors,spectrum:bands.eigenvalues,energy_ev:bands.eigenvalues[0],dimension:bands.eigenvalues.filter(v=>v-bands.eigenvalues[0]<=1e-9).length,residual:ref.residual,spectrum_error:difference});
 }
 save('inputs.json',inputs);save('references.json',references);save('summary.json',{cases:inputs.length,synthetic:48,material:24,distinct_seeds:seeds.size,seed_domains_separate:true,initially_solved:references.filter(r=>r.initial_fidelity>=.9999).length,maximum_initial_fidelity:Math.max(...references.map(r=>r.initial_fidelity)),reference_interface:'Solver receives only H, initial parameters, method budget and perturbation seed. References stored separately.'});log('challenge_frozen',{cases:inputs.length});
}
