import {modules,bytes,read,root} from './app-runtime.mjs';
import {loadCache} from './cache.mjs';
import {directSolve,score} from './assessment.mjs';
export async function run({save,log,args}){
 const [mode,ktext,seedText]=args;if(!['circuit','direct','legacy'].includes(mode))throw Error('Unknown material mode');
 const requested=JSON.parse(ktext),seed=Number(seedText);if(!Array.isArray(requested)||requested.length!==3||!requested.every(x=>Number.isFinite(x)&&Math.abs(x)<=1e6)||!Number.isSafeInteger(seed)||seed<1||seed>0xffffffff)throw Error('Invalid coordinates or seed');
 const k=requested.map(x=>{const v=x%1;return v===0?0:v<0?v+1:v;}),timings={},measure=(name,fn)=>{const t=performance.now(),value=fn();timings[name]=performance.now()-t;return value;};
 const m=await modules();let H,built;
 if(mode==='legacy'){const blocks=measure('load_model_ms',()=>m.b.parseWannier(bytes('inputs/wannier90_hr.dat').toString('utf8')));built=measure('construct_matrix_ms',()=>m.b.constructH(blocks,k));}
 else{const data=measure('load_model_ms',()=>loadCache(root));built=measure('construct_matrix_ms',()=>m.packed.constructPacked(data,k));}
 H=built.h;if(built.rawDefect>1e-8)throw Error('Hermiticity check failed');
 const random=m.b.rng(seed),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI),cfg=read('inputs/BRACKETED_CONTRACT.json').method;
 save('input.json',{mode,kpoint_requested:requested,kpoint_periodic:k,seed,H,initial_parameters:initial,raw_hermiticity_defect:built.rawDefect});
 const prediction=measure('solve_ms',()=>mode==='direct'?directSolve(m,H):mode==='legacy'?m.cg.conditionedRefine(H,initial,cfg,(seed+101)>>>0):m.fast.fastRefine(H,initial,cfg,(seed+101)>>>0));
 save('prediction.json',prediction);
 const reference=measure('reference_ms',()=>{const bands=m.b.jacobi(H),A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);})),e=m.n.symmetricEigen(A),diff=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(e.values[2*j]+e.values[2*j+1])/2)));if(diff>1e-9||e.residual>1e-9||bands.residual>1e-9)throw Error('Independent eigensolver disagreement');return {kind:'real_eigenvectors',real_vectors:e.vectors,spectrum:bands.eigenvalues,energy_ev:bands.eigenvalues[0],dimension:bands.eigenvalues.filter(v=>v-bands.eigenvalues[0]<=1e-9).length,residual:Math.max(e.residual,bands.residual),spectrum_error:diff};});
 const assessment=score(m,H,prediction,reference);save('reference.json',reference);save('summary.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',mode,kpoint_requested:requested,kpoint_periodic:k,seed,accepted:assessment.accepted,assessment,energy_ev:prediction.energy_ev,ground_space_dimension:reference.dimension,timings,meaning:mode==='direct'?'Eight-orbital classical material state calculation.':'Eight-orbital classical target plus three-qubit Q8 circuit fitting and unchanged SOP verification.'});log('material_result',{mode,accepted:assessment.accepted,energy_ev:prediction.energy_ev,fidelity:assessment.measurement.fidelity,timings});if(!assessment.accepted)throw Error('Material acceptance checks failed');
}
