import {modules,read} from './runtime.mjs';
import {score} from './assessment.mjs';
export async function run({save,log}){
 const m=await modules(),cases=read('inputs/REGRESSION_CASES.json'),cfg=read('inputs/BRACKETED_CONTRACT.json').method,rows=[];
 for(const c of cases){
  const at=performance.now(),prediction=m.fast.fastRefine(c.H,c.parameters,cfg,(2026092089+104729*c.index)>>>0),ms=performance.now()-at;save('prediction_'+c.index+'.json',prediction);
  const H=c.H,bands=m.b.jacobi(H),A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);})),e=m.n.symmetricEigen(A),diff=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(e.values[2*j]+e.values[2*j+1])/2)));
  if(diff>1e-9||e.residual>1e-9||bands.residual>1e-9)throw Error('Regression reference disagreement');
  const ref={kind:'real_eigenvectors',real_vectors:e.vectors,spectrum:bands.eigenvalues,energy_ev:bands.eigenvalues[0],dimension:c.ground_degeneracy,residual:Math.max(e.residual,bands.residual)},assessment=score(m,H,prediction,ref);
  rows.push({id:c.index,group:c.group,wall_ms:ms,assessment});if(!assessment.accepted)log('regression_miss',{id:c.index,assessment});
 }
 const summary={cases:rows.length,passed:rows.filter(r=>r.assessment.accepted).length,minimum_fidelity:Math.min(...rows.map(r=>r.assessment.measurement.fidelity)),maximum_energy_error_ev:Math.max(...rows.map(r=>r.assessment.measurement.energy_error_ev)),scope:'Preserved prior 72 matrices and saved starts; these are regression checks, not fresh independent solves.'};
 save('rows.json',rows);save('summary.json',summary);log('regression_complete',summary);if(summary.passed!==summary.cases)throw Error('Prior regression acceptance failed');
}
