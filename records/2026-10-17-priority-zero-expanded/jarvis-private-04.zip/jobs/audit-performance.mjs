import fs from 'node:fs';
import path from 'node:path';
import {root,roots,read} from './runtime.mjs';
import {openLedger,mirroredArtifact} from './work-ledger-v2.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export async function run({save,log,label}){
 const provenance=read('reports/BASELINE_PROVENANCE.json'),oldRoot=provenance.source,baseline=[];
 const originalCheck=read('reports/ORIGINAL_BASELINE_READBACK.json');if(!originalCheck.passed||originalCheck.source!==oldRoot||originalCheck.files.length!==provenance.files.length)throw Error('Original baseline readback missing');
 for(const item of provenance.files){const prior=originalCheck.files.find(f=>f.file===item.file),now=fs.readFileSync(path.join(root,item.file));if(!prior?.passed||prior.identity!==item.identity||hashBytes(now,'qel-work-artifact')!==item.identity)throw Error('Preserved baseline changed: '+item.file);baseline.push(item.file);}
 const snapshots=new Set();for(const file of fs.readdirSync(root+'/forensics')){try{const o=JSON.parse(fs.readFileSync(root+'/forensics/'+file,'utf8'));for(const k of ['source','original_source'])if(typeof o[k]==='string')snapshots.add(hashBytes(Buffer.from(o[k]),'qel-work-artifact'));}catch{}}
 const ledger=openLedger(roots,read('WORK_CONTRACT.json')).read();let artifactCount=0,historicalPins=0,archivedVersions=0;
 for(const [id,job] of Object.entries(ledger.state.jobs)){if(job.status!=='FINISHED')continue;for(const a of job.artifacts){if(mirroredArtifact(roots,a.path).identity!==a.identity)throw Error('Job artifact changed: '+a.path);artifactCount++;}for(const p of job.source_pins||[]){historicalPins++;if(mirroredArtifact(roots,p.path).identity!==p.identity){if(!snapshots.has(p.identity))throw Error('Historical source missing: '+p.path);archivedVersions++;}}}
 const replay=[];for(let i=0;i<72;i++){const f='prediction_'+String(i).padStart(3,'0')+'.json',a=fs.readFileSync(root+'/runs/challenge_accuracy_01/'+f),b=fs.readFileSync(root+'/runs/challenge_accuracy_replay_01/'+f);if(!a.equals(b))throw Error('Scientific replay mismatch: '+f);replay.push({file:f,identity:hashBytes(a,'qel-work-artifact')});}
 const app=read('APP_MANIFEST.json');for(const f of app.files)if(mirroredArtifact(roots,f.path).identity!==f.identity)throw Error('Installed file mismatch: '+f.path);
 const required=['runs/adjoint_validation_02/summary.json','runs/challenge_accuracy_01/summary.json','runs/prior_regression_01/summary.json','runs/cache_validation_01/summary.json','runs/app_grid_validation_01/summary.json','runs/performance_assessment_01/summary.json','reports/INSTALLATION_VALIDATION.json','reports/FRESH_PROCESS_BENCHMARK.json'];
 for(const file of required)mirroredArtifact(roots,file);
 const list=fs.readdirSync(root,{recursive:true}).map(f=>f.replaceAll('\\','/')).filter(f=>fs.statSync(path.join(root,f)).isFile()).filter(f=>!f.startsWith('ledger/.')&&f!=='CONTROLLER.lock'&&f!=='LIVE_STATUS.json'&&f!=='LIVE_STATUS.json.tmp'&&!f.startsWith('runs/'+label+'/')&&!f.startsWith('runs/'+label+'_'));
 const files=[];let bytes=0;for(const f of list){const id=mirroredArtifact(roots,f);files.push(id);bytes+=id.bytes;}
 const summary={passed:true,at_utc:new Date().toISOString(),files:files.length,bytes,preserved_baseline_files:baseline.length,ledger_events_at_audit:ledger.count,finished_artifact_checks:artifactCount,historical_source_checks:historicalPins,preserved_source_version_references:archivedVersions,byte_exact_scientific_replays:replay.length,installed_manifest_files:app.files.length,known_failed_jobs:Object.entries(ledger.state.jobs).filter(([id,j])=>j.status==='FAILED').map(([id])=>id),exclusions:['active audit outputs','active audit stdout/stderr','live status','session locks','temporary ledger access locks'],signature:'UNSIGNED'};
 save('manifest.json',{files});save('replay.json',{files:replay});save('summary.json',summary);log('audit_complete',summary);
}
