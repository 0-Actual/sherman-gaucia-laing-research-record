import fs from 'node:fs';
import path from 'node:path';
import {createInterface} from 'node:readline/promises';
import {root,roots,read} from './app-runtime.mjs';
import {executeJob} from './supervisor-core.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
function verifyInstallation(){
 const manifest=read('APP_MANIFEST.json');
 if(manifest.schema!=='qel-private-runtime-manifest-v1'||manifest.signature!=='UNSIGNED'||!Array.isArray(manifest.files)||!manifest.files.length)throw Error('Invalid installation manifest');
 for(const f of manifest.files){if(typeof f.path!=='string'||f.path.includes('..')||path.isAbsolute(f.path)||f.path.includes(':'))throw Error('Unsafe manifest path');for(const base of roots){const b=fs.readFileSync(path.join(base,f.path));if(b.length!==f.bytes||hashBytes(b,'qel-work-artifact')!==f.identity)throw Error('Installation verification failed: '+f.path);}}
 return manifest;
}
async function main(){
 verifyInstallation();const args=process.argv.slice(2),allowed=new Set(['--k','--mode','--seed','--label']);
 for(let i=0;i<args.length;i+=2)if(!allowed.has(args[i])||args[i+1]===undefined)throw Error('Use --k, --mode, --seed, --label with values.');
 const value=k=>{const i=args.indexOf(k);return i<0?undefined:args[i+1];},mode=value('--mode')||'circuit',seed=Number(value('--seed')||2026092053);
 if(!['circuit','direct','legacy'].includes(mode)||!Number.isSafeInteger(seed)||seed<1||seed>0xffffffff)throw Error('Invalid mode or seed');
 console.log('Q8 Private Lab | Sherman G. Laing');
 console.log(mode==='direct'?'Material calculation: direct classical solver.':mode==='legacy'?'Previous circuit method: comparison and rollback.':'Material calculation with accelerated Q8 circuit verification.');
 console.log('JVASP-816 aluminum | local eight-orbital model');
 const interactive=value('--k')===undefined,terminal=interactive?createInterface({input:process.stdin,output:process.stdout}):null;
 try{while(true){
  const input=interactive?await terminal.question('Coordinates [0 0 0], or q to quit: '):value('--k');
  if(interactive&&input.trim().toLowerCase()==='q')break;
  const coordinates=(input.trim()||'0 0 0').split(/[\s,]+/).map(Number);  if(coordinates.length!==3||!coordinates.every(x=>Number.isFinite(x)&&Math.abs(x)<=1e6)){if(interactive){console.log('Enter three finite coordinates, such as 0.2 0.4 0.6.');continue;}throw Error('Invalid coordinates');}
  const label=value('--label')||'local_'+Date.now();if(!/^[a-z0-9_-]{1,60}$/.test(label))throw Error('Invalid run label');
  console.log('Calculating and checking...');const start=performance.now(),result=await executeJob('material-request',label,[mode,JSON.stringify(coordinates),String(seed)]);
  if(!result.ok)throw Error(result.error);
  const report=read('runs/'+label+'/summary.json');console.log(report.accepted?'PASS':'FAIL');
  console.log('Energy: '+report.energy_ev.toFixed(10)+' eV');
  console.log('State match: '+(Math.min(1,Math.max(0,report.assessment.measurement.fidelity))*100).toFixed(8)+'%');
  console.log('Calculation and evidence: '+((performance.now()-start)/1000).toFixed(3)+' seconds.');
  console.log('Saved locally and on USB.');if(!interactive)break;
 }}finally{terminal?.close();}
}
main().catch(e=>{console.error('Could not complete: '+e.message);process.exitCode=1;});
