import {modules,saveBoth,environment,root} from './runtime.mjs';
import {pathToFileURL} from 'node:url';
const [job,label,...args]=process.argv.slice(2);
if(!/^[a-z0-9-]+$/.test(job)||!/^[a-z0-9_-]{1,60}$/.test(label))throw Error('Invalid job');
const began=performance.now(),cpu=process.cpuUsage(),save=(f,d)=>{if(!/^[a-zA-Z0-9_.-]+$/.test(f))throw Error('Invalid output');return saveBoth('runs/'+label+'/'+f,d);};
const log=(stage,data={})=>console.log(JSON.stringify({at_utc:new Date().toISOString(),label,stage,...data}));
const mod=await import(pathToFileURL(root+'/jobs/'+job+'.mjs').href);
await mod.run({save,log,args,label});
save('worker-execution.json',{elapsed_ms:performance.now()-began,cpu_microseconds:process.cpuUsage(cpu),maximum_rss_kib:process.resourceUsage().maxRSS,environment:environment(),durability:'Worker readback verified; supervisor fsync required before ledger success.'});
