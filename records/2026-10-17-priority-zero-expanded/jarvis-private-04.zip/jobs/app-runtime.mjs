import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import os from 'node:os';
import {fileURLToPath} from 'node:url';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export const root=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
export const laptop='./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_04';
export const usb='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_04';
export const roots=[laptop,usb];
export const read=rel=>JSON.parse(fs.readFileSync(path.join(root,rel),'utf8'));
export const bytes=rel=>fs.readFileSync(path.join(root,rel));
export function saveBoth(rel,data){const b=Buffer.isBuffer(data)?data:Buffer.from(JSON.stringify(data,null,2)+'\n');for(const r of roots){const p=path.join(r,rel);fs.mkdirSync(path.dirname(p),{recursive:true});const fd=fs.openSync(p,'wx');try{fs.writeFileSync(fd,b);if(!process.permission)fs.fsyncSync(fd);}finally{fs.closeSync(fd);}if(!fs.readFileSync(p).equals(b))throw Error('Mirror readback failed: '+rel);}return {path:rel,bytes:b.length,identity:hashBytes(b,'qel-work-artifact')};}
export async function modules(){
 const base=path.join(root,'numerics'),allow=new Set(['baseline.mjs','candidate.mjs','newton.mjs','hybrid.mjs','bracketed.mjs','conditioned.mjs','acceptance.mjs','q8-adjoint.mjs','q8-fast.mjs','packed-wannier.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']),cache=new Map(),context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}});
 async function load(rel){if(!allow.has(rel))throw Error('Numerical import rejected: '+rel);if(cache.has(rel))return cache.get(rel);const m=new vm.SourceTextModule(fs.readFileSync(path.join(base,rel),'utf8'),{context,identifier:rel});cache.set(rel,m);await m.link((s,p)=>{if(!s.startsWith('./'))throw Error('Nonlocal numerical import');return load(path.posix.normalize(path.posix.join(path.posix.dirname(p.identifier),s)));});return m;}
 const out={};for(const [key,file]of Object.entries({b:'baseline.mjs',c:'candidate.mjs',n:'newton.mjs',cg:'conditioned.mjs',a:'acceptance.mjs',ad:'q8-adjoint.mjs',fast:'q8-fast.mjs',packed:'packed-wannier.mjs'})){if(!fs.existsSync(path.join(base,file)))continue;const m=await load(file);await m.evaluate({timeout:5000});out[key]=m.namespace;}
 const bindings=vm.runInContext('({process:typeof process,require:typeof require,fetch:typeof fetch,WebSocket:typeof WebSocket})',context);if(Object.values(bindings).some(x=>x!=='undefined'))throw Error('Unexpected numerical host binding');
 return {...out,containment:{bindings,imports:[...cache.keys()],code_generation_disabled:true,os_network_isolation:false}};
}
export function environment(){return {utc:new Date().toISOString(),node:process.version,cpu:os.cpus()[0].model,available_ram_bytes:os.freemem(),process_rss_bytes:process.memoryUsage().rss,priority:os.getPriority(process.pid)};}
