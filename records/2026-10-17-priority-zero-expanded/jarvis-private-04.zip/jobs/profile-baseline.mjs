import {modules,bytes,read} from './runtime.mjs';
export async function run({save,log}){
 const m=await modules(),timings={},measure=(name,fn)=>{const t=performance.now(),c=process.cpuUsage(),v=fn();timings[name]={wall_ms:performance.now()-t,cpu_microseconds:process.cpuUsage(c)};return v;};
 const blocks=measure('parse_wannier',()=>m.b.parseWannier(bytes('inputs/wannier90_hr.dat').toString('utf8')));
 const H=measure('construct_hamiltonian',()=>m.b.constructH(blocks,[.6,0,.8]).h),cfg=read('inputs/BRACKETED_CONTRACT.json').method;
 const random=m.b.rng(3092017991),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
 save('input.json',{kpoint:[.6,0,.8],H,initial,seed:3092018092,purpose:'Seen worst-grid coordinate for profiling only; excluded from fresh benchmark.'});
 measure('circuit_100_evaluations',()=>{for(let i=0;i<100;i++)m.b.energy(H,m.b.actualState(m.b.ansatz(initial)).state);});
 const target=measure('conditioned_target',()=>m.cg.conditionedTarget(H,cfg));log('profile_target_done',timings);
 const prediction=measure('baseline_hybrid',()=>m.cg.conditionedRefine(H,initial,cfg,3092018092));
 save('prediction.json',prediction);save('summary.json',{timings,fit_starts:prediction.normalized_prediction.fit_starts,target_energy_ev:target.energy_ev,final_energy_ev:prediction.energy_ev,containment:m.containment});log('profile_complete',timings);
}
