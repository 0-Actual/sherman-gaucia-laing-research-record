// Additional inputs only. No reference answers, eigenvalue solver or optimizer is called.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),out=path.join(here,'additional-data');
const root='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_04';
const old='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_01';
const {hashBytes}=await import(pathToFileURL(path.join(root,'control/vendor/sgl-prime.mjs')));
assert.ok(!fs.existsSync(out),'Preserve existing additional data');
const originalContract=JSON.parse(fs.readFileSync(path.join(here,'vqd-full-v1/contract.json')));
const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}}),cache=new Map();
for(const name of ['baseline.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']){
 const bytes=fs.readFileSync(path.join(root,'numerics',name));
 assert.equal(hashBytes(bytes,'qel-jarvis-source'),originalContract.sources.find(e=>e.name===name).identity);
 cache.set(name,new vm.SourceTextModule(bytes.toString('utf8'),{context,identifier:name}));
}
const module=cache.get('baseline.mjs');await module.link((specifier,parent)=>{
 assert.ok(specifier.startsWith('./'));const name=path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),specifier));
 assert.ok(cache.has(name));return cache.get(name);
});await module.evaluate({timeout:5000});const base=module.namespace;
const originalFixture=JSON.parse(fs.readFileSync(path.join(old,'inputs/hamiltonians_24x8x8.json')));
const historical=JSON.parse(fs.readFileSync(path.join(old,'CONTRACT.json')));
const exclude=[...originalFixture.rows.map(r=>r.kpoint_fractional_reciprocal),...historical.new_kpoints];
const forbidden=new Set(exclude.map(k=>k.map(v=>v.toFixed(6)).join(',')));
const seed=2026092901,random=base.rng(seed),points=[];
while(points.length<24){
 const k=Array.from({length:3},()=>Math.floor(random()*1000000)/1000000),key=k.map(v=>v.toFixed(6)).join(',');
 if(!forbidden.has(key)){points.push(k);forbidden.add(key);}
}
fs.mkdirSync(out);
const write=(name,value)=>{const bytes=Buffer.from(JSON.stringify(value,null,2)+'\n');const p=path.join(out,name);fs.writeFileSync(p,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(p).equals(bytes));};
const hr=fs.readFileSync(path.join(old,'inputs/wannier90_hr.dat'));
write('contract.json',{utc:new Date().toISOString(),assessment_set:'additional-aluminum-v1',material:'JVASP-816',
 selection:'24 unique PRNG points in [0,1)^3 at six decimal places; exclude original 24 and six historical extension coordinates',
 selection_seed:seed,points,solver_config:originalContract.config,
 solver_change:false,hyperparameter_selection_using_answers:false,reference_generation:'Only after circuit predictions are frozen',
 interpretation:'Same material, new coordinates for this assessment; not unseen materials or a public leaderboard score',
 engineering_targets:{mean_absolute_error_ev:0.0001,maximum_absolute_error_ev:0.001,official_threshold:false},
 source:old+'/inputs/wannier90_hr.dat',source_identity:hashBytes(hr,'qel-jarvis-additional-input'),
 source_provenance:'Same archived input whose archive-member bytes were verified in archive-verification.json',
 original_code_snapshot:'run-assessment-original-v1.mjs',publication:false,physical_QPU:false});
const blocks=base.parseWannier(hr.toString('utf8'));
const rows=points.map((k,i)=>{const r=base.constructH(blocks,k);return {kpoint_index:i,kpoint_fractional_reciprocal:k,matrix_ev:r.h,raw_hermitian_defect_ev:r.rawDefect};});
write('hamiltonians_24x8x8.json',{schema:'qel.jarvis.hamiltonian-input-fixture/v1',assessment_set:'additional-aluminum-v1',
 material_id:'JVASP-816',fermi_shift_ev:0,unit:'eV',rows});
const extract=s=>s.slice(s.indexOf('function solveCircuit(H,index){'),s.indexOf('\ntry{\n const rows=[];'));
assert.equal(extract(fs.readFileSync(path.join(here,'run-assessment.mjs'),'utf8')),extract(fs.readFileSync(path.join(here,'run-assessment-original-v1.mjs'),'utf8')));
write('preparation.json',{utc:new Date().toISOString(),status:'INPUTS_FROZEN',points:24,energies_to_predict:192,
 exact_solver_function_unchanged:true,reference_answers_generated:false,source_readback_unchanged:fs.readFileSync(path.join(old,'inputs/wannier90_hr.dat')).equals(hr)});
console.log(JSON.stringify({status:'INPUTS_FROZEN',points:24,energies_to_predict:192,solver_unchanged:true}));
