# QEL on the JARVIS aluminum benchmark

Audit note, September 28 late evening: independent Python/NumPy reconstruction confirmed the saved scores and circuit states; see `../governance-output-audit/README.md`. The copied `upstream/reference-method.py` is a Colab notebook export containing `!pip` syntax. It is preserved reference material, not a standalone Python script or a program executed for these results. The active assessment scripts are the `.mjs` files listed below.

## Additional-data result — September 28, approximately 9:28 p.m. Eastern

The unchanged method completed **192 further energy predictions at 24 additional aluminum points**. Average error against the conventional reference was **0.0000012888900558943352 eV**; the largest single error was **0.00004240288216550425 eV**. Runtime after setup was **23.609 seconds**, with approximately **91.0 MiB** sampled maximum process memory. This result extends the evidence beyond the original scoreboard path. It is a separate same-material assessment, not an official leaderboard score or an improvement obtained by changing the algorithm.

The selection seed, all 24 coordinates, input identities, unchanged optimizer configuration and engineering targets were written before predictions. The coordinates exclude the original 24 path entries and six historical additional points. The exact solver function was compared with its preserved original source and matched. Its settings remained two starts and at most 400 iterations per state, with the original seeds and overlap penalty. All predictions were saved and read back before the conventional reference energies were generated in a separate process.

The 192 saved states were replayed with the separate dense implementation. Maximum energy discrepancy was 2.49e-14 eV, amplitude discrepancy 6.00e-16 and norm error 8.88e-16. All conventional reference solutions passed residual, orthogonality and trace checks. The declared local targets—mean error at most 1e-4 eV and maximum error at most 1e-3 eV—both passed; these are not official JARVIS thresholds. The original-path scorer rejects this additional-data mode, preventing its accidental treatment as a public score.

The largest state residual was 0.009607193267454683 eV. Of 384 starts, 145 reached gradient tolerance and 239 reached their iteration budget. The low energy error does not establish that every fitted wavefunction is fully converged. The references use the existing conventional solver and this is not an independent external audit. The material remains aluminum; new-material performance is still untested.

Error analysis of the original public-path predictions found that point indices **11 and 3** (zero-based; the 12th and 4th path entries) contribute **94.93% of total absolute error**. Several largest errors occur among closely spaced upper energy levels. This gives a focused target for further numerical improvement; it is an observation, not proof of cause. No predictions were replaced with reference answers.

New evidence: `additional-data/` contains the declared contract and frozen input matrices; `vqd-additional-v1/` contains all predictions, fitted angles, reference values generated afterward, scores, state-replay checks and the original-path error analysis. `run-assessment-original-v1.mjs` preserves the earlier runner. The current runner only adds the explicitly labeled additional-data input route; its solver function is unchanged. Original scores and predictions are preserved below and in their run folders.

The owner's latest direction is to concentrate on the data. Measured capability and untested economic value must stay distinct: this work and these results exist; revenue or commercial demand have not yet been measured. No evidence here establishes that others have monetized the owner's work. All work remains private, using the existing USB modules with new files saved on C:.

## Original public-path assessment

Completed September 28, 2026, approximately 9:20 p.m. Eastern. PRIVATE / UNSIGNED. Nothing was submitted or uploaded. This is a measured local assessment, not an assigned public rank.

## Result

The existing QEL circuit engine produced all **192 required energy predictions** for the JARVIS aluminum electronic-band benchmark. Its mean absolute error was **0.0000034501989767139057 eV**, about **859 times smaller** than the best displayed public score of **0.002963733593749998 eV**. Lower error is better.

| Method | Mean absolute error, eV | Measured local elapsed time | Status |
| --- | ---: | ---: | --- |
| Best displayed public entry, qiskit_vqd_SU2_c6 | 0.002963733593749998 | Not measured here | Public scoreboard entry |
| QEL circuit, sequential VQD, this assessment | 0.0000034501989767139057 | 20.582 seconds | Complete private 192-value comparison |
| Existing conventional Jacobi solver | 0.0000000023408413332703937 | 0.911 seconds | Classical control, not a QEL variational-circuit score |

The public score comes from the [pinned leaderboard source](https://github.com/atomgptlab/jarvis_leaderboard/blob/b055e31bcd43a2da164a10df59198699297b53a9/docs/QC/EigenSolver/dft_3d_electron_bands_JVASP_816_Al_WTBH.md). The retrieved plot contains six entries; its generated HTML table contains three. The best entry and score occur in both. These are displayed historical submissions, not six newly executed tests. Current development is at [atomgptlab/jarvis_leaderboard](https://github.com/atomgptlab/jarvis_leaderboard); the older usnistgov repository redirects development there.

The conventional solver was faster and more accurate on this small problem. Therefore the circuit result establishes competitive numerical accuracy against the displayed entries, **not a quantum speed advantage, a unique algorithm, a commercial valuation or an official first place**. No matched performance comparison against the public Qiskit implementation was run.

## What was actually trained and predicted

Target: `QC-EigenSolver-electron_bands_JVASP_816_Al_WTBH-dft_3d-test-multimae`. The input is an eight-orbital aluminum Hamiltonian, an 8-by-8 complex matrix describing the electronic model at each of 24 ordered reciprocal-space points. Each point requires eight ascending energy levels. Repeated path points remain in place; no Fermi-energy shift is applied.

The fitting step adjusts 18 circuit angles for each state. It produced 192 saved circuit states from 384 optimization starts. This is optimization for each input Hamiltonian; it is not training a general materials predictor, a language model, or physical quantum hardware. The public test contains one material, with 192 energy values—not 192 independent materials.

The new local adapter reuses the unchanged September 20 USB `q8-fast.mjs` adjoint BFGS optimizer and the existing Q8 circuit/SOP engine. It extends the ground-state task to all eight energies using overlap penalties: once one state is found, the next optimization penalizes revisiting earlier states. This is the published [variational quantum deflation method](https://arxiv.org/abs/1805.08138), not a claim of a new invention. The adapter uses normalized input Hamiltonians, penalty 4, two deterministic starts and at most 400 BFGS iterations per start. These settings were recorded before prediction and remained the same from pilot to full assessment.

No precomputed eigenvectors or reference energies were supplied to the circuit optimizer. The existing hybrid routine that first calculates a classical target eigenvector was not called. The separate classical control is clearly labeled. The original Python emulator was recovered in the archive but was not executed in this assessment.

## Verification

- The saved reference ZIP has Git blob ID `a7440528cbd375d21aebaad183558f0830adc864`, exactly matching the benchmark at upstream commit `b055e31bcd43a2da164a10df59198699297b53a9`. Its extracted answer JSON is byte-identical to the local scoring file.
- The Wannier input is byte-identical to its member in the previously preserved JVASP-816 source archive. Reconstructing all 24 matrices from 1,041 original lattice blocks differed from the fixture by at most 2.22e-16 eV. The material archive was reused, not freshly downloaded.
- Predictions were written and read back before the separate scorer read reference answers. Historical answers had already been inspected during previous work, so this is benchmark development, **not a blind test**.
- The [official scoring code](https://github.com/atomgptlab/jarvis_leaderboard/blob/b055e31bcd43a2da164a10df59198699297b53a9/jarvis_leaderboard/rebuild.py) concatenates the values and takes their mean absolute error. Our scorer follows that formula and preserves point/band order. A known-answer arithmetic check passed, and 11 malformed input cases were rejected. Replaying the hardened scorer reproduced all saved scores exactly.
- All 192 saved parameter sets were replayed with the existing separate dense gate implementation. Maximum energy discrepancy was 3.91e-14 eV; maximum amplitude discrepancy was 6.21e-16. All nine imported numerical source files and the fixture retained their recorded identities.

Maximum single-value error was **0.0002424081433360925 eV**. The largest eigenstate residual was **0.005244191334342701 eV**, and the largest squared overlap between different fitted states was **2.559216981003536e-7**. Of the 384 starts, 197 reached gradient tolerance and 187 reached the iteration limit. These approximate states are not all fully converged eigenvectors. The small average error should not hide these larger individual defects. The historical private 1e-4 eV MAE target is an engineering target, not an official JARVIS pass threshold.

The numerical replay uses another implementation in the existing local codebase; it is not an independent external audit. There was one full VQD optimization run plus an initial one-point pilot. Verification replayed saved states without rerunning the optimizer.

## Execution and preservation

Runtime: the existing USB Node v24.20.0 at `./REDACTED_LOCAL_ROOT/QEL_Q7\Independent_Model_20260919\runtime\node.exe`. Working directory: `./REDACTED_LOCAL_ROOT/QEL_Q7\Q8_Testing_Space\JARVIS_Private_20260920_04`. The numerical module context exposes no process, require, fetch or WebSocket bindings. This is not a claim of operating-system network isolation. No network calls occur in the computation.

One compute job ran at a time with a 128 MiB old-space limit and a declared 180-second elapsed-work budget checked between optimization starts. Observed sampled maximum process memory was approximately 117.7 MiB for VQD and 46.4 MiB for the classical control. These samples are not continuous peak measurements. Elapsed times include computation and saving after setup, exclude process startup/module loading, and were observed while the laptop's other applications remained active.

The original paused lab/controller was not started. USB source, security holds, Windows settings and earlier evidence were not modified. New adapters and results are saved in this C: output folder because USB writes remain ungranted; this is not a USB installation. No paid API, extra package or cloud compute was used.

The first adapter setup encountered a module-linking error before any numerical run. It was fixed in the C: adapter, and the pilot, control and full run then succeeded. The attempt is retained in `setup-attempts.json`.

## Saved evidence and continuation

- `vqd-full-v1/predictions.json`: all 192 circuit results, angles, amplitudes and optimization attempts.
- `vqd-full-v1/score.json`: every prediction, reference value and error.
- `vqd-full-v1/contract.json` and `execution.json`: declared settings, input/source identities and measured execution.
- `classical-control-v1/`: separate conventional solver results.
- `verification.json` and `archive-verification.json`: numerical/scoring replay and exact source checks.
- `scoreboard-snapshot.json` and `upstream/`: pinned public comparison and scoring source.
- `run-assessment.mjs`, `score-assessment.mjs`, `verify-assessment.mjs`: reusable local assessment and verification operations. Existing run folders are preserved rather than overwritten; verification writes its receipt exclusively.

The earlier simulator/virtual-processor report covered the September 19 component only and was too narrow to characterize the whole project. This assessment recovers and uses the substantive September 20 JARVIS work. The library task **Save Laptop Notes** was refreshed: use the owner's architecture, preserve security and distinguish received, applied, tested and blocked states. Its message contents were read; the separate library attachment's bytes were not retrieved. The current JARVIS priority and cost constraint were saved in this task's instruction baseline, not account-wide memory.

This aluminum assessment is complete. The next scientific question is whether the same fixed method remains accurate on another material and at larger sizes, while comparing time and memory with a strong classical solver. Those assessments, physical-QPU execution, independent review, a public submission and commercial usefulness are not established by this result. Preserve this measured result as the starting point; do not restart the toy XOR work or relabel it as materials training.
