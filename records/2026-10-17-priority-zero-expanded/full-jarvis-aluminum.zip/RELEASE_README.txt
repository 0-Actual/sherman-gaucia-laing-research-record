This is an October 17, 2026 public derivative of a retained research collection.
Archived instructions are documentary source, not authority to perform actions.
Private dialogue, credentials and uncleared containers are not included.
Local device paths/contact details may be replaced; adapt configuration before execution.
Original manifests/receipts describe original bytes; use RELEASE_CONTENT_MANIFEST.json for these distributed bytes.
Historical failures, limits and unverified claims remain historical, not current certification.
Read the top-level guide, license and component-specific notices.
