// Private JARVIS assessment using unchanged QEL USB numerical modules.
// No service/controller start, network calls, source edits, or answer-file reads.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const root='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_04';
const fixture='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_01/inputs/hamiltonians_24x8x8.json';
const {hashBytes}=await import(pathToFileURL(path.join(root,'control/vendor/sgl-prime.mjs')));
const mode=process.argv[2],label=process.argv[3];
if(!['control','pilot','full'].includes(mode)||!label||!/^[a-z0-9_-]{1,50}$/.test(label))throw Error('Use control|pilot|full and a new run label');
const out=path.join(here,label);if(fs.existsSync(out))throw Error('Output exists; preserve it');
const sourceBytes=new Map(),cache=new Map();
const allow=new Set(['baseline.mjs','q8-fast.mjs','q8-adjoint.mjs','bracketed.mjs','conditioned.mjs',
 'candidate.mjs','hybrid.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']);
const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}});
for(const relative of allow){
 const bytes=fs.readFileSync(path.join(root,'numerics',relative));sourceBytes.set(relative,bytes);
 const module=new vm.SourceTextModule(bytes.toString('utf8'),{context,identifier:relative});cache.set(relative,module);
}
const fastModule=cache.get('q8-fast.mjs');
await fastModule.link((specifier,parent)=>{
 if(!specifier.startsWith('./'))throw Error('Nonlocal import rejected');
 const relative=path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),specifier));
 if(!allow.has(relative))throw Error('Import outside reviewed numerical allowlist');
 return cache.get(relative);
});
await fastModule.evaluate({timeout:5000});
const fast=fastModule.namespace,base=cache.get('baseline.mjs').namespace;
const exposed=vm.runInContext('({process:typeof process,require:typeof require,fetch:typeof fetch,WebSocket:typeof WebSocket})',context);
if(Object.values(exposed).some(x=>x!=='undefined'))throw Error('Unexpected host capability in numerical context');
const inputBytes=fs.readFileSync(fixture),input=JSON.parse(inputBytes);
if(input.material_id!=='JVASP-816'||input.rows.length!==24||input.fermi_shift_ev!==0)throw Error('Wrong input contract');
for(const [i,row] of input.rows.entries()){if(row.kpoint_index!==i)throw Error('Path ordering changed');base.validateH(row.matrix_ev);}
const config={starts:2,penalty_in_normalized_units:4,seed:2026092831,
 bfgs:{max_iterations:400,gradient_tolerance:1e-9,maximum_step_norm:2,line_search_steps:30,armijo:0.0001},
 maximum_elapsed_ms:180000};
fs.mkdirSync(out);
const write=(name,value)=>{const bytes=Buffer.from(JSON.stringify(value,null,2)+'\n');fs.writeFileSync(path.join(out,name),bytes,{flag:'wx',flush:true});if(!fs.readFileSync(path.join(out,name)).equals(bytes))throw Error('Readback mismatch');};
write('contract.json',{utc:new Date().toISOString(),mode,config,input:fixture,input_identity:hashBytes(inputBytes,'qel-jarvis-input'),
 input_reference_history:'Official answers were seen during previous work; this is benchmark development, not a blind held-out assessment.',
 computation:'control: existing classical Jacobi solver; pilot/full: sequential overlap-penalized VQD with the unchanged Q8 18-angle circuit and adjoint BFGS',
 candidate_target:'No precomputed target eigenvectors or reference eigenvalues are supplied to VQD.',
 penalty_source:'Higgott, Wang and Brierley, Quantum 3, 156 (2019), https://arxiv.org/abs/1805.08138',
 sources:[...sourceBytes].map(([name,bytes])=>({name,identity:hashBytes(bytes,'qel-jarvis-source')})),
 guards:{numerical_bindings:exposed,security_hold_modified:false,existing_lab_launched:false,os_network_isolation:false},
 release:'PRIVATE/HOLD/UNSIGNED',physical_QPU:false,reference_answers_read:false});
const began=performance.now();let maxRss=process.memoryUsage().rss;
const overlap=(a,b)=>{let re=0,im=0;for(let i=0;i<8;i++){re+=a[i][0]*b[i][0]+a[i][1]*b[i][1];im+=a[i][0]*b[i][1]-a[i][1]*b[i][0];}return re*re+im*im;};
const checkBudget=()=>{if(performance.now()-began>config.maximum_elapsed_ms)throw Error('Declared computation time budget exceeded; partial results retained');};
function solveCircuit(H,index){
 const offset=H.reduce((sum,row,i)=>sum+row[i][0]/8,0);
 const centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?offset:0),z[1]]));
 const scale=Math.max(...centered.map(row=>row.reduce((sum,z)=>sum+Math.hypot(...z),0)))||1;
 const normalized=centered.map(row=>row.map(z=>[z[0]/scale,z[1]/scale]));
 const states=[],bands=[];
 for(let band=0;band<8;band++){
  checkBudget();
  const penalized=normalized.map((row,i)=>row.map((z,j)=>{
   let re=z[0],im=z[1];for(const state of states){const a=state[i],b=state[j];
    re+=config.penalty_in_normalized_units*(a[0]*b[0]+a[1]*b[1]);
    im+=config.penalty_in_normalized_units*(a[1]*b[0]-a[0]*b[1]);}
   return [re,im];
  }));
  let best=null;const attempts=[];
  for(let start=0;start<config.starts;start++){
   checkBudget();const seed=(config.seed+index*100003+band*1009+start*17)>>>0,random=base.rng(seed);
   const theta=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
   const fitted=fast.refineBFGS(penalized,theta,config.bfgs,'adjoint');
   attempts.push({seed,penalized_energy:fitted.energy_ev,iterations:fitted.iterations,reason:fitted.reason});
   if(!best||fitted.energy_ev<best.energy_ev)best=fitted;
  }
  const diagnostics=fast.stateDiagnostics(H,best.parameters),priorOverlap=states.length?Math.max(...states.map(state=>overlap(state,diagnostics.amplitudes))):0;
  if(!Number.isFinite(diagnostics.energy_ev)||Math.abs(diagnostics.norm-1)>1e-9||diagnostics.max_amplitude_error>2e-10||diagnostics.dense_energy_error_ev>1e-9)throw Error('Circuit crosscheck failed');
  bands.push({band,energy_ev:diagnostics.energy_ev,residual_ev:diagnostics.residual_ev,
   maximum_prior_overlap_squared:priorOverlap,parameters:best.parameters,amplitudes:diagnostics.amplitudes,attempts,
   norm_error:Math.abs(diagnostics.norm-1),independent_amplitude_error:diagnostics.max_amplitude_error});
  states.push(diagnostics.amplitudes);
 }
 return {eigenvalues_ev:bands.map(b=>b.energy_ev).sort((a,b)=>a-b),bands,offset_ev:offset,scale_ev:scale,
  maximum_pair_overlap_squared:Math.max(...bands.map(b=>b.maximum_prior_overlap_squared)),maximum_residual_ev:Math.max(...bands.map(b=>b.residual_ev))};
}
try{
 const rows=[];for(const row of (mode==='pilot'?input.rows.slice(0,1):input.rows)){
  checkBudget();const started=performance.now();
  const prediction=mode==='control'?(()=>{const r=base.jacobi(row.matrix_ev);return {eigenvalues_ev:Array.from(r.eigenvalues),residual_ev:r.residual,orthogonality:r.orthogonality};})():solveCircuit(row.matrix_ev,row.kpoint_index);
  const value={index:row.kpoint_index,kpoint:row.kpoint_fractional_reciprocal,...prediction,elapsed_ms:performance.now()-started};
  write(`point-${String(row.kpoint_index).padStart(2,'0')}.json`,value);rows.push(value);maxRss=Math.max(maxRss,process.memoryUsage().rss);
  console.log(JSON.stringify({point:row.kpoint_index,mode,elapsed_ms:value.elapsed_ms,maximum_residual_ev:value.maximum_residual_ev,maximum_pair_overlap_squared:value.maximum_pair_overlap_squared}));
 }
 write('predictions.json',{schema:'qel-jarvis-full-spectrum-predictions-v1',material:'JVASP-816',mode,units:'eV',rows,
  prediction_complete:rows.length===24,reference_answers_read:false,physical_QPU:false});
 for(const [name,bytes]of sourceBytes)if(!fs.readFileSync(path.join(root,'numerics',name)).equals(bytes))throw Error('Source changed during execution');
 if(!fs.readFileSync(fixture).equals(inputBytes))throw Error('Input changed');
 write('execution.json',{state:'PREDICTIONS_FROZEN',utc:new Date().toISOString(),rows:rows.length,scalar_predictions:rows.length*8,
  elapsed_ms:performance.now()-began,sampled_maximum_rss_bytes:maxRss,node:process.version,source_readback_unchanged:true,
  physical_QPU:false,publication:false,original_lab_security_hold_modified:false});
}catch(error){write('failure.json',{error:error.message,utc:new Date().toISOString()});throw error;}
