// Generate conventional reference values only after the separate VQD run is frozen.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url)),out=path.join(here,'vqd-additional-v1');
const root='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_04';
const {hashBytes}=await import(pathToFileURL(path.join(root,'control/vendor/sgl-prime.mjs')));
const read=p=>JSON.parse(fs.readFileSync(p));
const predictionFile=path.join(out,'predictions.json'),predictionBytes=fs.readFileSync(predictionFile),predictions=JSON.parse(predictionBytes);
const execution=read(path.join(out,'execution.json')),contract=read(path.join(out,'contract.json'));
const preparation=read(path.join(here,'additional-data/contract.json'));
assert.equal(execution.state,'PREDICTIONS_FROZEN');assert.equal(execution.scalar_predictions,192);
assert.equal(predictions.assessment_set,'additional-aluminum-v1');assert.equal(predictions.mode,'additional');
assert.equal(predictions.material,'JVASP-816');assert.equal(predictions.units,'eV');assert.equal(predictions.rows.length,24);
assert.deepEqual(contract.config,preparation.solver_config);
const inputBytes=fs.readFileSync(path.join(here,'additional-data/hamiltonians_24x8x8.json')),input=JSON.parse(inputBytes);
assert.equal(hashBytes(inputBytes,'qel-jarvis-input'),contract.input_identity);
const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}}),cache=new Map();
for(const name of ['baseline.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']){
 const bytes=fs.readFileSync(path.join(root,'numerics',name));
 assert.equal(hashBytes(bytes,'qel-jarvis-source'),contract.sources.find(s=>s.name===name).identity);
 cache.set(name,new vm.SourceTextModule(bytes.toString('utf8'),{context,identifier:name}));
}
const module=cache.get('baseline.mjs');await module.link((specifier,parent)=>{
 assert.ok(specifier.startsWith('./'));const name=path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),specifier));
 assert.ok(cache.has(name));return cache.get(name);
});await module.evaluate({timeout:5000});const base=module.namespace;
const write=(name,value)=>{const bytes=Buffer.from(JSON.stringify(value,null,2)+'\n'),p=path.join(out,name);fs.writeFileSync(p,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(p).equals(bytes));};
const began=performance.now(),referenceRows=[];
for(const [i,row]of input.rows.entries()){
 assert.equal(row.kpoint_index,i);base.validateH(row.matrix_ev);
 const result=base.jacobi(row.matrix_ev);
 assert.ok(result.residual<=1e-9);assert.ok(result.orthogonality<=1e-10);assert.ok(result.traceError<=1e-9);
 referenceRows.push({index:i,kpoint:row.kpoint_fractional_reciprocal,eigenvalues_ev:Array.from(result.eigenvalues),
  residual_ev:result.residual,orthogonality:result.orthogonality,trace_error_ev:result.traceError});
}
write('reference-predictions.json',{utc:new Date().toISOString(),method:'Existing conventional Jacobi solver',
 generated_after_vqd_frozen:true,vqd_prediction_identity:hashBytes(predictionBytes,'qel-jarvis-additional-predictions'),
 elapsed_ms:performance.now()-began,rows:referenceRows});
let maxEnergyReplay=0,maxAmplitudeReplay=0,maxNormError=0,maxResidual=0;
const values=[],perPoint=[],stops={};
for(const [i,row]of predictions.rows.entries()){
 assert.equal(row.index,i);assert.equal(row.eigenvalues_ev.length,8);assert.equal(row.bands.length,8);
 assert.deepEqual(row.kpoint,referenceRows[i].kpoint);assert.ok(row.eigenvalues_ev.every(Number.isFinite));
 assert.deepEqual(row.eigenvalues_ev,[...row.bands.map(b=>b.energy_ev)].sort((a,b)=>a-b));
 const matrix=input.rows[i].matrix_ev,truth=referenceRows[i].eigenvalues_ev,pointValues=[];
 for(const band of row.bands){
  assert.equal(band.parameters.length,18);assert.ok(band.parameters.every(Number.isFinite));
  const state=base.dense(3,base.ansatz(band.parameters)),energy=base.independentEnergy(matrix,state);
  maxEnergyReplay=Math.max(maxEnergyReplay,Math.abs(energy-band.energy_ev));
  let norm=0,residualSquared=0;
  for(let a=0;a<8;a++){
   norm+=state[a][0]**2+state[a][1]**2;
   maxAmplitudeReplay=Math.max(maxAmplitudeReplay,Math.hypot(state[a][0]-band.amplitudes[a][0],state[a][1]-band.amplitudes[a][1]));
   let re=-energy*state[a][0],im=-energy*state[a][1];
   for(let b=0;b<8;b++){re+=matrix[a][b][0]*state[b][0]-matrix[a][b][1]*state[b][1];im+=matrix[a][b][0]*state[b][1]+matrix[a][b][1]*state[b][0];}
   residualSquared+=re*re+im*im;
  }
  const residual=Math.sqrt(residualSquared);assert.ok(Math.abs(residual-band.residual_ev)<=1e-9);
  maxResidual=Math.max(maxResidual,residual);maxNormError=Math.max(maxNormError,Math.abs(norm-1));
  for(const attempt of band.attempts)stops[attempt.reason]=(stops[attempt.reason]||0)+1;
 }
 for(let band=0;band<8;band++){
  const neighbors=[];if(band>0)neighbors.push(truth[band]-truth[band-1]);if(band<7)neighbors.push(truth[band+1]-truth[band]);
  const value={index:i,band,prediction_ev:row.eigenvalues_ev[band],reference_ev:truth[band],
   absolute_error_ev:Math.abs(row.eigenvalues_ev[band]-truth[band]),nearest_reference_gap_ev:Math.min(...neighbors)};
  values.push(value);pointValues.push(value);
 }
 perPoint.push({index:i,kpoint:row.kpoint,mean_absolute_error_ev:pointValues.reduce((s,v)=>s+v.absolute_error_ev,0)/8,
  maximum_absolute_error_ev:Math.max(...pointValues.map(v=>v.absolute_error_ev)),maximum_residual_ev:row.maximum_residual_ev});
}
assert.equal(values.length,192);assert.ok(maxEnergyReplay<=1e-9);assert.ok(maxAmplitudeReplay<=2e-10);assert.ok(maxNormError<=1e-9);
const mean=values.reduce((s,v)=>s+v.absolute_error_ev,0)/192,max=Math.max(...values.map(v=>v.absolute_error_ev));
const result={utc:new Date().toISOString(),assessment_set:'additional-aluminum-v1',material:'JVASP-816',
 points:24,scalar_predictions:192,metric:'MEAN_ABSOLUTE_ERROR_AGAINST_LOCAL_CLASSICAL_REFERENCE',mean_absolute_error_ev:mean,
 maximum_absolute_error_ev:max,elapsed_ms:execution.elapsed_ms,sampled_maximum_rss_bytes:execution.sampled_maximum_rss_bytes,
 fixed_config_matches_original:true,mean_target_ev:preparation.engineering_targets.mean_absolute_error_ev,
 maximum_target_ev:preparation.engineering_targets.maximum_absolute_error_ev,
 mean_target_passed:mean<=preparation.engineering_targets.mean_absolute_error_ev,
 maximum_target_passed:max<=preparation.engineering_targets.maximum_absolute_error_ev,
 official_score:false,official_rank:null,publication:false,unseen_materials:false,
 verification:{replayed_states:192,maximum_dense_energy_difference_ev:maxEnergyReplay,maximum_dense_amplitude_difference:maxAmplitudeReplay,
 maximum_norm_error:maxNormError,maximum_residual_ev:maxResidual,reference_generated_after_predictions_frozen:true,
 optimizer_stop_reasons:stops},per_point:perPoint,largest_errors:[...values].sort((a,b)=>b.absolute_error_ev-a.absolute_error_ev).slice(0,12),values};
assert.ok(fs.readFileSync(predictionFile).equals(predictionBytes));write('score.json',result);
// Analyze prior public-path results without fitting or changing any predictions.
const original=read(path.join(here,'vqd-full-v1/score.json'));
const groups=Array.from({length:24},(_,index)=>({index,total_absolute_error_ev:original.values.filter(v=>v.index===index).reduce((s,v)=>s+v.absolute_error_ev,0)})).sort((a,b)=>b.total_absolute_error_ev-a.total_absolute_error_ev);
const total=groups.reduce((s,g)=>s+g.total_absolute_error_ev,0);
const worstOriginal=[...original.values].sort((a,b)=>b.absolute_error_ev-a.absolute_error_ev).slice(0,8).map(v=>{
 const t=original.values.filter(a=>a.index===v.index).map(a=>a.reference_ev),g=[];
 if(v.band>0)g.push(t[v.band]-t[v.band-1]);if(v.band<7)g.push(t[v.band+1]-t[v.band]);
 return {...v,nearest_reference_gap_ev:Math.min(...g)};
});
write('original-path-error-analysis.json',{utc:new Date().toISOString(),predictions_changed:false,point_error_totals:groups,
 two_largest_point_indices:groups.slice(0,2).map(g=>g.index),two_point_share_of_total_absolute_error:groups.slice(0,2).reduce((s,g)=>s+g.total_absolute_error_ev,0)/total,
 largest_errors:worstOriginal,interpretation:'Error concentration and spectral gaps are diagnostic observations, not proof of cause.'});
console.log(JSON.stringify({...result,values:undefined,per_point:undefined,largest_errors:result.largest_errors.slice(0,3)}));
