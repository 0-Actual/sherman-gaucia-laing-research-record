// isolated publication fixture
