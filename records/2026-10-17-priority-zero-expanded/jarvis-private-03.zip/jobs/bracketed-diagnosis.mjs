import {createRun,read,modules,overlap} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]);
try{
 const {g,c,b,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json'),inputs=read('inputs/pass2_stress_inputs.json'),saved=read('inputs/pass2_synthetic_states.json'),scores=[];
 run.save('contract.json',cfg);run.save('containment.json',containment);
 for(const old of saved)for(const initial of old.prediction.starts){
  const item=inputs[old.index],p=g.bracketedRefine(item.H,initial.parameters,cfg.method,(20260920+old.index*10+initial.start)>>>0);run.save('case_'+old.index+'_start_'+initial.start+'_prediction.json',{index:old.index,start:initial.start,prediction:p});
  const diag=c.stateDiagnostics(item.H,p.parameters),ref=b.jacobi(item.H);let fidelity=overlap(item.known_columns[0],p.amplitudes),targetFidelity=overlap(item.known_columns[0],p.target.amplitudes);if(item.declared_gap_ev===0){fidelity+=overlap(item.known_columns[1],p.amplitudes);targetFidelity+=overlap(item.known_columns[1],p.target.amplitudes);}
  const error=p.energy_ev-ref.eigenvalues[0],correct=Math.abs(p.norm-1)<2e-10&&diag.max_amplitude_error<2e-10&&diag.dense_energy_error_ev<1e-9&&error>=-1e-8;
  if(!correct)throw Error('Circuit correctness failure');
  if(!(p.target.bracket.lower<=ref.eigenvalues[0]+1e-12&&p.target.bracket.upper>=ref.eigenvalues[0]-1e-12))throw Error('Numerical bracket crosscheck failure');
  const row={index:old.index,start:initial.start,gap_ev:item.declared_gap_ev,fidelity,target_fidelity:targetFidelity,target_fit:p.target_fit_fidelity,energy_error_ev:error,fidelity_pass:fidelity>=cfg.fidelity_goal,energy_pass:error<=cfg.energy_goal_ev,correctness:true,residual_ev:p.residual_ev,bracket_width_ev:p.target.bracket.width,fit_starts:p.fit_starts};scores.push(row);run.save('case_'+old.index+'_start_'+initial.start+'_score.json',row);run.log('bracketed_case_scored',row);
 }
 run.save('scores.json',scores);run.save('summary.json',{owner:'Sherman G. Laing',states:scores.length,fidelity_passes:scores.filter(r=>r.fidelity_pass).length,energy_passes:scores.filter(r=>r.energy_pass).length,correctness_passes:scores.filter(r=>r.correctness).length,remaining_misses:scores.filter(r=>!r.fidelity_pass),signature:'UNSIGNED'});run.finish();
}catch(e){run.fail(e);}
