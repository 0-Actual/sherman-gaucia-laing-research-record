import {createRun,read} from '../numerics/runtime-v5.mjs';
const run=createRun(process.argv[2]);
try {
  const plan=read('inputs/ROBUSTNESS_PLAN.json');
  const pad=(n,width)=>String(n).padStart(width,'0');
  const collect=(prefix,batches,width)=>Array.from({length:batches},(_,i)=>read('runs/'+prefix+pad(i,width)+'/scores.json')).flat();
  const rows=collect('robustness_',72,3),paired=collect('bracketed_study_',72,3);
  const regression=collect('material_regression_',8,2),cold=collect('cold_compilation_',12,2);
  const independent=collect('independent_holdout_',4,2),conditioned=collect('conditioned_validation_',10,2);
  function coverage(name,list,expected) {
    if(list.length!==expected||new Set(list.map(x=>x.index)).size!==expected||list.some((x,i)=>x.index!==i))throw Error('Incomplete or duplicate '+name+' coverage');
    return {name,expected,actual:list.length,unique_indices:expected,complete:true};
  }
  const coverageChecks=[coverage('robustness',rows,720),coverage('paired_bracketed',paired,720),coverage('saved_regression',regression,72),coverage('cold_compilation',cold,138),coverage('independent_holdout',independent,48),coverage('conditioned_validation',conditioned,120)];
  for(let i=0;i<720;i++) {
    const r=rows[i],p=paired[i];
    if(r.matrix!==p.matrix||r.optimizer_seed!==p.optimizer_seed||r.gap_ev!==p.gap_ev)throw Error('Mismatched paired case');
    for(const m of [r.baseline,r.hybrid]) {
      if(![m.fidelity,m.energy_error_ev,m.norm,m.amplitude_error,m.dense_energy_error_ev].every(Number.isFinite)||m.fidelity < -1e-10||m.fidelity>1+1e-10||m.correctness!==true)throw Error('Invalid study measurement');
      if(m.fidelity_pass!==(m.fidelity>=plan.fidelity_goal)||m.energy_pass!==(m.energy_error_ev<=plan.energy_goal_ev))throw Error('Inconsistent stored classification');
    }
    if(![p.bracketed_fidelity,p.target_fidelity,p.energy_error_ev].every(Number.isFinite)||p.correctness!==true||p.fidelity_pass!==(p.bracketed_fidelity>=plan.fidelity_goal)||p.energy_pass!==(p.energy_error_ev<=plan.energy_goal_ev))throw Error('Invalid paired measurement');
  }
  const count=(list,predicate)=>list.filter(predicate).length;
  const accepted=x=>x.energy_pass&&x.fidelity_pass&&x.correctness;
  const methodCounts=indices=>({
    cases:indices.length,
    baseline_energy:count(indices,i=>rows[i].baseline.energy_pass),
    baseline_fidelity:count(indices,i=>rows[i].baseline.fidelity_pass),
    baseline_accepted:count(indices,i=>accepted(rows[i].baseline)),
    rayleigh_energy:count(indices,i=>rows[i].hybrid.energy_pass),
    rayleigh_fidelity:count(indices,i=>rows[i].hybrid.fidelity_pass),
    rayleigh_accepted:count(indices,i=>accepted(rows[i].hybrid)),
    bracketed_energy:count(indices,i=>paired[i].energy_pass),
    bracketed_fidelity:count(indices,i=>paired[i].fidelity_pass),
    bracketed_accepted:count(indices,i=>accepted(paired[i])),
    bracketed_target_misses:count(indices,i=>paired[i].target_fidelity<plan.fidelity_goal),
    bracketed_circuit_fit_misses:count(indices,i=>paired[i].diagnosis==='circuit_fit_miss')
  });
  const byGap=plan.gaps_ev.map(gap=>({gap_ev:gap,...methodCounts(rows.filter(x=>x.gap_ev===gap).map(x=>x.index))}));
  const byFamily=Array.from({length:plan.matrix_families},(_,family)=>({family,...methodCounts(rows.filter(x=>x.family===family).map(x=>x.index))}));
  const all=rows.map(x=>x.index),transitions={
    bracketed_gains_over_baseline:count(all,i=>!accepted(rows[i].baseline)&&accepted(paired[i])),
    bracketed_losses_vs_baseline:count(all,i=>accepted(rows[i].baseline)&&!accepted(paired[i])),
    bracketed_gains_over_rayleigh:count(all,i=>!accepted(rows[i].hybrid)&&accepted(paired[i])),
    bracketed_losses_vs_rayleigh:count(all,i=>accepted(rows[i].hybrid)&&!accepted(paired[i]))
  };
  const stats=values=>{if(!values.length||!values.every(x=>Number.isFinite(x)&&x>=0))throw Error('Invalid cost measurements');const sorted=values.slice().sort((a,b)=>a-b);return {count:values.length,total:values.reduce((s,x)=>s+x,0),mean:values.reduce((s,x)=>s+x,0)/values.length,median:(sorted[Math.floor((sorted.length-1)/2)]+sorted[Math.ceil((sorted.length-1)/2)])/2,p95:sorted[Math.ceil(.95*sorted.length)-1],min:sorted[0],max:sorted.at(-1)};};
  const baselineTimes=[],rayleighTimes=[],coldTimes=[],conditionedTimes=[],coldPairs=[];
  for(const r of rows) {
    const p=read('runs/robustness_'+pad(Math.floor(r.index/10),3)+'/case_'+pad(r.index,4)+'_prediction.json');
    baselineTimes.push(p.timing_excluded_from_exact_replay.baseline_ms);
    rayleighTimes.push(p.timing_excluded_from_exact_replay.hybrid_ms);
  }
  for(const r of cold) {
    const time=read('runs/cold_compilation_'+pad(Math.floor(r.index/12),2)+'/case_'+pad(r.index,3)+'_timing.json').elapsed_ms;
    coldTimes.push(time);
    if(r.source==='synthetic') {
      const index=r.paired_robustness_index;
      if(r.seed!==rows[index].optimizer_seed)throw Error('Cold seed pairing mismatch');
      coldPairs.push({cold_index:r.index,robustness_index:index,gap_ev:rows[index].gap_ev,baseline_ms:baselineTimes[index],cold_bracketed_ms:time,baseline_accepted:accepted(rows[index].baseline),cold_accepted:accepted(r),baseline_fidelity:rows[index].baseline.fidelity,cold_fidelity:r.fidelity});
    }
  }
  for(const r of conditioned)conditionedTimes.push(read('runs/conditioned_validation_'+pad(Math.floor(r.index/12),2)+'/case_'+pad(r.index,3)+'_timing.json').elapsed_ms);
  const stops={};for(const row of rows)for(const reason of row.baseline_stop_reasons)stops[reason]=(stops[reason]||0)+1;
  const timing={
    units:'milliseconds',baseline_from_fresh_parameters:stats(baselineTimes),
    rayleigh_increment_after_baseline:stats(rayleighTimes),
    baseline_plus_rayleigh:stats(baselineTimes.map((x,i)=>x+rayleighTimes[i])),
    cold_bracketed_full_method:stats(coldTimes),
    conditioned_mixed_warm_and_cold:stats(conditionedTimes),
    interpretation:'Observed laptop runs, not a quantum speedup benchmark. Incremental refinements start from already optimized states. Cold paired cases share baseline start-zero seed but method budgets differ. Timing includes OS variation; paired cases reuse matrices and are not independent population samples.'
  };
  const summaries={
    owner:'Sherman G. Laing',signature:'UNSIGNED',coverage:coverageChecks,
    study:methodCounts(all),by_gap:byGap,by_family:byFamily,paired_transitions:transitions,
    saved_regression:{cases:72,energy_passes:count(regression,x=>x.energy_pass),fidelity_passes:count(regression,x=>x.fidelity_pass),accepted:count(regression,accepted)},
    cold_compilation:{cases:138,energy_passes:count(cold,x=>x.energy_pass),fidelity_passes:count(cold,x=>x.fidelity_pass),accepted:count(cold,accepted)},
    independent_holdout:{cases:48,accepted:count(independent,accepted)},
    conditioned_validation:{cases:120,accepted:count(conditioned,x=>x.assessment.accepted)},
    baseline_stopping_reasons:stops,
    limitations:['Eight-dimensional complex matrices and three logical qubits, evaluated by a classical Q8 engine.','The target-refinement stages are explicit classical solvers followed by circuit fitting.','The factorial study uses 12 circuit-generated matrix families; a separate four-family Gaussian-basis holdout addresses this restriction.','Empirical success rates do not establish universal convergence.','Energy, fidelity, circuit correctness, input precision, and workflow completion are separate claims.']
  };
  run.save('coverage.json',coverageChecks);run.save('summary.json',summaries);run.save('timing.json',timing);run.save('cold_paired_comparison.json',coldPairs);
  run.save('remaining_misses.json',{baseline:rows.filter(x=>!accepted(x.baseline)).map(x=>({index:x.index,gap_ev:x.gap_ev,measurement:x.baseline})),rayleigh:rows.filter(x=>!accepted(x.hybrid)).map(x=>({index:x.index,gap_ev:x.gap_ev,measurement:x.hybrid})),bracketed:paired.filter(x=>!accepted(x)),regression:regression.filter(x=>!accepted(x)),cold:cold.filter(x=>!accepted(x)),independent:independent.filter(x=>!accepted(x)),conditioned:conditioned.filter(x=>!x.assessment.accepted)});
  run.finish();run.log('study_aggregation_complete',{study:summaries.study,conditioned:summaries.conditioned_validation});
} catch(e){run.fail(e);}
