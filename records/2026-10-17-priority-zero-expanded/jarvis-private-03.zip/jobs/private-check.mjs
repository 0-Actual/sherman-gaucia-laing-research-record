import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {createInterface} from 'node:readline/promises';
import {root,mirror} from '../numerics/runtime-v6.mjs';
import {solvePrivateCheck} from './private-check-core.mjs';
async function main() {
  const args=process.argv.slice(2),value=flag=>{const i=args.indexOf(flag);return i<0?undefined:args[i+1];};
  if(args.includes('--help')){console.log('JARVIS private check: node private-check.mjs [--k "0 0 0"] [--seed 2026092053] [--label unique_name]');return;}
  const allowed=new Set(['--k','--seed','--label']);
  for(let i=0;i<args.length;i+=2)if(!allowed.has(args[i])||args[i+1]===undefined)throw Error('Use --k, --seed, and --label with a value, or run without arguments.');
  const preferredRoot=root.toLowerCase().startsWith('d:')?mirror:root;
  const locks=[root,mirror].map(r=>path.join(r,'CONTROLLER.lock')),lock=path.join(preferredRoot,'CONTROLLER.lock');
  if(locks.some(file=>fs.existsSync(file))) {
    console.error('A private session lock is present. This check has not started.');
    console.error('Read LIVE_STATUS.json for progress; a lock left after interruption needs inspection.');
    process.exitCode=2;return;
  }
  if(!fs.existsSync(root)||!fs.existsSync(mirror))throw Error('Both private destinations must be available. Connect the D: drive and try again.');
  console.log('JARVIS private laptop check — JVASP-816 aluminum');
  console.log('Enter a k point in fractional reciprocal coordinates.');
  let input=value('--k');
  if(input===undefined){const terminal=createInterface({input:process.stdin,output:process.stdout});try{input=await terminal.question('Three coordinates [0 0 0]: ');}finally{terminal.close();}}
  const kpoint=(input.trim()||'0 0 0').split(/[\s,]+/).map(Number);
  if(kpoint.length!==3||!kpoint.every(x=>Number.isFinite(x)&&Math.abs(x)<=1e6))throw Error('Enter exactly three finite numbers between -1000000 and 1000000.');
  const seed=value('--seed')===undefined?2026092053:Number(value('--seed'));
  const label=value('--label')||'private_check_'+Date.now();
  if(!Number.isSafeInteger(seed)||seed<0||seed>0xffffffff||!/^[a-z0-9_-]{1,60}$/.test(label))throw Error('Invalid seed or run label.');
  let owned=false;
  try {
    fs.writeFileSync(lock,JSON.stringify({pid:process.pid,mode:'private_check',label,started_utc:new Date().toISOString()}),{flag:'wx'});owned=true;
    if(locks.some(file=>file!==lock&&fs.existsSync(file)))throw Error('Another private session owns the other destination.');
    try{os.setPriority(process.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);}catch{}
    const result=await solvePrivateCheck({label,kpoint,seed,onProgress:message=>console.log(message)});
    console.log(result.accepted?'PASS — energy, state fidelity, and circuit checks passed.':'FAIL — the requested state checks did not all pass.');
    console.log('Energy error: '+result.measurement.energy_error_ev.toExponential(6)+' eV (goal <= 1e-6 eV).');
    console.log('Ground-space fidelity: '+Math.min(1,Math.max(0,result.measurement.fidelity)).toPrecision(12)+' (goal >= 0.9999).');
    console.log('Ground-space dimension: '+result.ground_space_dimension+'.');
    if(result.reasons.length)console.log('Reasons: '+result.reasons.join(', '));
    console.log('This uses a classical target solver and the three-qubit Q8 simulation.');
    console.log('Private evidence: '+result.evidence_directory);
    process.exitCode=result.accepted?0:1;
  } finally {
    if(owned&&fs.existsSync(lock)){const current=JSON.parse(fs.readFileSync(lock));if(current.pid===process.pid&&current.mode==='private_check')fs.unlinkSync(lock);}
  }
}
main().catch(error=>{console.error('Check could not finish: '+error.message);process.exitCode=3;});
