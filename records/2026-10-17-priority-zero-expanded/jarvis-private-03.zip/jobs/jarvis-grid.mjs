import fs from 'node:fs';
import path from 'node:path';
import {createRun,read,root,modules} from '../numerics/runtime-v5.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
const run=createRun(process.argv[2]),start=Number(process.argv[3]),count=Number(process.argv[4]);
try {
  const {cg,n,c,b,a,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json'),plan=read('inputs/JARVIS_GRID_PLAN.json');
  const cases=plan.cases.slice(start,start+count);
  if(!Number.isInteger(start)||!Number.isInteger(count)||count<1||count>12||cases.length!==count)throw Error('Invalid JARVIS grid batch');
  const inputPath=path.join(root,'inputs/wannier90_hr.dat'),inputBytes=fs.readFileSync(inputPath),inputIdentity=hashBytes(inputBytes,'qel-jarvis-input');
  const blocks=b.parseWannier(inputBytes.toString('utf8'));
  run.save('contract.json',{...cfg,plan:{...plan,cases},ground_space_definition:'Eigenvalues within the predeclared numerical degeneracy tolerance of the smallest reference eigenvalue.'});
  run.save('containment.json',containment);run.save('input_source.json',{path:'inputs/wannier90_hr.dat',identity:inputIdentity,bytes:inputBytes.length,blocks:blocks.length});
  const scores=[];
  for(const item of cases) {
    const constructed=b.constructH(blocks,item.kpoint),H=constructed.h;
    const shifted=b.constructH(blocks,item.kpoint.map((v,i)=>v+plan.periodicity_shift[i])).h;
    const periodicError=Math.max(...H.flatMap((row,i)=>row.map((z,j)=>Math.hypot(z[0]-shifted[i][j][0],z[1]-shifted[i][j][1]))));
    if(constructed.rawDefect>plan.raw_hermiticity_tolerance||periodicError>plan.periodicity_tolerance)throw Error('Wannier reconstruction or periodicity failure');
    run.save('case_'+String(item.index).padStart(3,'0')+'_input.json',{...item,H,raw_hermiticity_defect:constructed.rawDefect,periodicity_error:periodicError});
    const random=b.rng(item.seed),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
    const started=performance.now(),p=cg.conditionedRefine(H,initial,cfg.method,(item.seed+101)>>>0),elapsed=performance.now()-started;
    run.save('case_'+String(item.index).padStart(3,'0')+'_prediction.json',{case:item,initial_parameters:initial,prediction:p});
    const bands=b.jacobi(H),A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);}));
    const ref=n.symmetricEigen(A),degeneracy=bands.eigenvalues.filter(v=>v-bands.eigenvalues[0]<=plan.ground_degeneracy_tolerance_ev).length;
    const projection=state=>{const v=state.map(z=>z[0]).concat(state.map(z=>z[1]));return ref.vectors.slice(0,2*degeneracy).reduce((s,col)=>s+col.reduce((t,x,i)=>t+x*v[i],0)**2,0);};
    const fidelity=projection(p.amplitudes),targetFidelity=projection(p.normalized_prediction.target.amplitudes),diag=c.stateDiagnostics(H,p.parameters);
    const spectrumError=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(ref.values[2*j]+ref.values[2*j+1])/2))),predictionEnergyError=Math.abs(p.energy_ev-diag.energy_ev);
    const measurement={energy_error_ev:p.energy_ev-bands.eigenvalues[0],fidelity,norm_error:Math.abs(diag.norm-1),amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,reference_verified:ref.residual<=1e-9&&bands.residual<=1e-9&&spectrumError<=1e-9&&predictionEnergyError<=1e-9};
    const assessment=a.assessState(measurement,{energy_goal_ev:plan.energy_goal_ev,fidelity_goal:plan.fidelity_goal});
    const row={...item,measurement,assessment,target_fidelity:targetFidelity,target_fit:p.normalized_prediction.target_fit_fidelity,ground_degeneracy:degeneracy,gap_to_next_space_ev:degeneracy<8?bands.eigenvalues[degeneracy]-bands.eigenvalues[0]:null,reference_eigenvalues_ev:bands.eigenvalues,reference_residual:ref.residual,reference_spectrum_error:spectrumError,prediction_energy_consistency_ev:predictionEnergyError,raw_hermiticity_defect:constructed.rawDefect,periodicity_error:periodicError};
    scores.push(row);run.save('case_'+String(item.index).padStart(3,'0')+'_score.json',row);run.save('case_'+String(item.index).padStart(3,'0')+'_timing.json',{elapsed_ms:elapsed,scope:'Conditioned target solve and Q8 fit from fresh parameters; reconstruction and scoring excluded from this per-case timer.'});
    run.log('jarvis_grid_scored',{index:item.index,kpoint:item.kpoint,fidelity,energy_error_ev:measurement.energy_error_ev,accepted:assessment.accepted,degeneracy});
  }
  if(hashBytes(fs.readFileSync(inputPath),'qel-jarvis-input')!==inputIdentity)throw Error('Wannier input changed during job');
  run.save('scores.json',scores);
  run.save('summary.json',{owner:plan.owner,start,count,accepted:scores.filter(x=>x.assessment.accepted).length,numerically_degenerate_cases:scores.filter(x=>x.ground_degeneracy>1).length,min_fidelity:Math.min(...scores.map(x=>x.measurement.fidelity)),max_periodicity_error:Math.max(...scores.map(x=>x.periodicity_error)),remaining_misses:scores.filter(x=>!x.assessment.accepted),signature:'UNSIGNED'});
  run.finish();
} catch(e){run.fail(e);}
