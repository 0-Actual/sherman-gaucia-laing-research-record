import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';import {initialState,completionGate} from '../control/guard.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),mirror='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_03',c=JSON.parse(fs.readFileSync(path.join(root,'WORK_CONTRACT.json'),'utf8'));
const state=initialState(c,Date.parse(c.recorded_utc)),gate=completionGate(c,state,state.started_ms+35*60000);
if(gate.can_prepare_final_handoff||gate.can_declare_task_complete)throw Error('Previous early-stop scenario was accepted');
const result={owner:c.owner,kind:'controller integration probe',recorded_utc:new Date().toISOString(),early_stop_rejected:true,gate,meaning:'This successful child job must create a checkpoint while leaving the work session open.',signature:'UNSIGNED'};
for(const r of [root,mirror]){fs.mkdirSync(path.join(r,'runs/control_probe_02'),{recursive:true});fs.writeFileSync(path.join(r,'runs/control_probe_02/result.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});}
console.log(JSON.stringify({probe_passed:true,session_complete:false}));
