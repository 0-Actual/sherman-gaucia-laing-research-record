import {createRun,read,modules,overlap} from '../numerics/runtime.mjs';
const label=process.argv[2],run=createRun(label);
try{
 const {n,c,b,containment}=await modules(),cfg=read('inputs/NEWTON_CONTRACT.json'),inputs=read('inputs/pass2_stress_inputs.json'),saved=read('inputs/pass2_synthetic_states.json');run.save('contract.json',cfg);run.save('containment.json',containment);
 const checks=[],scores=[];
 for(const old of saved){
  const item=inputs[old.index],diag=n.derivativeDiagnostics(item.H,old.prediction.parameters);
  if(diag.gradient_error>2e-8||diag.hessian_error>2e-8||diag.state_derivative_error>2e-9||diag.hessian_eigen_residual>1e-9)throw Error('Exact derivative crosscheck failed: '+JSON.stringify(diag));
  checks.push({index:old.index,...diag});run.log('derivatives_checked',{index:old.index,...diag});
  for(const initial of old.prediction.starts){
   const p=n.refineNewton(item.H,initial.parameters,cfg.method);
   run.save('case_'+old.index+'_start_'+initial.start+'_prediction.json',{index:old.index,start:initial.start,prediction:p});
   const dense=c.stateDiagnostics(item.H,p.parameters),ref=b.jacobi(item.H),gap=p.energy_ev-ref.eigenvalues[0];
   let fidelity=overlap(item.known_columns[0],p.amplitudes);if(item.declared_gap_ev===0)fidelity+=overlap(item.known_columns[1],p.amplitudes);
   const correct=Math.abs(p.norm-1)<=2e-10&&dense.max_amplitude_error<=2e-10&&dense.dense_energy_error_ev<=1e-9&&gap>=-1e-8&&p.energy_ev<=initial.final_energy_ev+1e-10;
   if(!correct)throw Error('Numerical correctness failed');
   const row={index:old.index,start:initial.start,gap_ev:item.declared_gap_ev,energy_error_ev:gap,old_energy_ev:initial.final_energy_ev,new_energy_ev:p.energy_ev,old_best_fidelity:old.score.ground_fidelity,new_fidelity:fidelity,fidelity_goal_pass:fidelity>=cfg.fidelity_goal,energy_goal_pass:gap<=cfg.energy_goal_ev,gradient_norm:p.gradient_norm,residual_ev:p.residual_ev,iterations:p.iterations,reason:p.reason,state_evaluations:p.state_evaluations,correctness:true,max_amplitude_error:dense.max_amplitude_error};
   scores.push(row);run.save('case_'+old.index+'_start_'+initial.start+'_score.json',row);run.log('refinement_scored',row);
  }
 }
 run.save('derivative_checks.json',checks);run.save('scores.json',scores);const summary={owner:'Sherman G. Laing',cases:saved.length,starting_states:scores.length,correctness_passes:scores.filter(r=>r.correctness).length,fidelity_passes:scores.filter(r=>r.fidelity_goal_pass).length,energy_passes:scores.filter(r=>r.energy_goal_pass).length,previous_failures:scores.filter(r=>[27,28].includes(r.index)),max_derivative_error:Math.max(...checks.map(r=>r.gradient_error)),max_hessian_error:Math.max(...checks.map(r=>r.hessian_error)),signature:'UNSIGNED'};run.save('summary.json',summary);run.finish();run.log('refinement_complete',{cases:summary.cases,fidelity_passes:summary.fidelity_passes,starting_states:summary.starting_states});
}catch(e){run.fail(e);}

