import {createRun,read,modules,overlap} from '../numerics/runtime-v2.mjs';
const label=process.argv[2],start=Number(process.argv[3]),count=Number(process.argv[4]),run=createRun(label);
try{
 const {h,c,b,containment}=await modules(),plan=read('inputs/ROBUSTNESS_PLAN.json'),cfg=read('inputs/pass2_contract.json'),hybrid=read('inputs/HYBRID_CONTRACT.json'),matrices=read('runs/robustness_inputs/matrices.json'),all=read('runs/robustness_inputs/cases.json'),cases=all.slice(start,start+count),scores=[];
 if(!Number.isInteger(start)||!Number.isInteger(count)||count<1||count>20||cases.length!==count)throw Error('Invalid batch');
 run.save('plan.json',{plan,case_indices:cases.map(x=>x.index),method:cfg.method,hybrid:hybrid.method});run.save('containment.json',containment);
 for(const item of cases){
  const m=matrices[item.matrix],t0=performance.now(),baseline=c.optimizeCandidate(m.H,cfg.method,item.optimizer_seed),baseMs=performance.now()-t0,t1=performance.now(),improved=h.hybridRefine(m.H,baseline.parameters,hybrid.method),hybridMs=performance.now()-t1;
  run.save('case_'+String(item.index).padStart(4,'0')+'_prediction.json',{case:item,baseline,improved,timing_excluded_from_exact_replay:{baseline_ms:baseMs,hybrid_ms:hybridMs}});
  const reference=b.jacobi(m.H),grade=(state,theta,E)=>{
   const diag=c.stateDiagnostics(m.H,theta);let fidelity=overlap(m.known_columns[0],state);if(m.gap_ev===0)fidelity+=overlap(m.known_columns[1],state);
   const correct=Math.abs(diag.norm-1)<=plan.correctness_tolerances.norm&&diag.max_amplitude_error<=plan.correctness_tolerances.amplitude&&diag.dense_energy_error_ev<=plan.correctness_tolerances.dense_energy_ev&&E-reference.eigenvalues[0]>=-1e-8;
   if(!correct)throw Error('Circuit correctness error at case '+item.index);
   return {fidelity,energy_ev:E,energy_error_ev:E-reference.eigenvalues[0],energy_pass:E-reference.eigenvalues[0]<=plan.energy_goal_ev,fidelity_pass:fidelity>=plan.fidelity_goal,norm:diag.norm,residual_ev:diag.residual_ev,amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,correctness:true};
  };
  const before=grade(baseline.amplitudes,baseline.parameters,baseline.final_energy_ev),after=grade(improved.amplitudes,improved.parameters,improved.energy_ev),row={...item,baseline:before,hybrid:after,hybrid_target_fit:improved.target_fit_fidelity,hybrid_energy_increased:improved.physical_energy_nondecreasing,baseline_evaluations:baseline.total_objective_evaluations,hybrid_fit_evaluations:improved.fit_rounds.reduce((n,r)=>n+r.evaluations,0),baseline_stop_reasons:baseline.starts.map(x=>x.reason)};
  scores.push(row);run.save('case_'+String(item.index).padStart(4,'0')+'_score.json',row);run.log('robustness_case_scored',{index:item.index,family:item.family,gap_ev:item.gap_ev,baseline_fidelity:before.fidelity,hybrid_fidelity:after.fidelity,baseline_pass:before.fidelity_pass,hybrid_pass:after.fidelity_pass,baseline_ms:baseMs,hybrid_ms:hybridMs});
 }
 run.save('scores.json',scores);const summary={owner:plan.owner,start,count,completed:scores.length,correctness_passes:scores.length,baseline_energy_passes:scores.filter(x=>x.baseline.energy_pass).length,hybrid_energy_passes:scores.filter(x=>x.hybrid.energy_pass).length,baseline_fidelity_passes:scores.filter(x=>x.baseline.fidelity_pass).length,hybrid_fidelity_passes:scores.filter(x=>x.hybrid.fidelity_pass).length,improved_fidelity_cases:scores.filter(x=>x.hybrid.fidelity>x.baseline.fidelity+1e-10).length,worsened_fidelity_cases:scores.filter(x=>x.hybrid.fidelity<x.baseline.fidelity-1e-10).length,remaining_fidelity_misses:scores.filter(x=>!x.hybrid.fidelity_pass).map(x=>x.index),signature:'UNSIGNED'};run.save('summary.json',summary);run.finish();run.log('batch_complete',summary);
}catch(e){run.fail(e);}

