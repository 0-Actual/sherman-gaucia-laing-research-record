import fs from 'node:fs';
import path from 'node:path';
import {createRun,root,read} from '../numerics/runtime-v5.mjs';
const run=createRun(process.argv[2]);
try {
  const pairs=[
    {first:'robustness_004',second:'robustness_replay_gap1e8',strip_prediction_timing:true},
    {first:'bracketed_confirmation_gap1e8',second:'bracketed_study_004'},
    {first:'conditioned_affine_diagnostic_01',second:'conditioned_affine_diagnostic_02'},
    {first:'conditioned_validation_00',second:'conditioned_validation_replay_00'}
  ];
  run.save('contract.json',{pairs,rule:'Compare all deterministic JSON, excluding execution telemetry and dedicated timing files. Robustness predictions exclude only their named timing_excluded_from_exact_replay property.'});
  const results=[];
  for(const pair of pairs) {
    const directory=name=>path.join(root,'runs',name);
    const names=name=>fs.readdirSync(directory(name)).filter(f=>f.endsWith('.json')&&f!=='execution.json'&&!f.endsWith('_timing.json')).sort();
    const first=names(pair.first),second=names(pair.second);
    if(JSON.stringify(first)!==JSON.stringify(second))throw Error('Replay file membership mismatch: '+pair.first);
    const files=[];
    for(const name of first) {
      const x=fs.readFileSync(path.join(directory(pair.first),name)),y=fs.readFileSync(path.join(directory(pair.second),name));
      let exact=x.equals(y),mode='byte_exact';
      if(pair.strip_prediction_timing&&name.endsWith('_prediction.json')) {
        const a=JSON.parse(x),b=JSON.parse(y);
        if(!Object.hasOwn(a,'timing_excluded_from_exact_replay')||!Object.hasOwn(b,'timing_excluded_from_exact_replay'))throw Error('Expected timing field missing');
        delete a.timing_excluded_from_exact_replay;delete b.timing_excluded_from_exact_replay;
        exact=JSON.stringify(a)===JSON.stringify(b);mode='all_prediction_fields_exact_except_named_timing';
      }
      files.push({file:name,mode,exact});
      if(!exact)throw Error('Replay mismatch: '+pair.first+'/'+name);
    }
    results.push({...pair,compared_files:files.length,all_exact:files.every(x=>x.exact),files});
  }
  run.save('comparisons.json',results);
  run.save('summary.json',{owner:'Sherman G. Laing',pairs:results.length,deterministic_json_files:results.reduce((s,x)=>s+x.compared_files,0),all_exact:results.every(x=>x.all_exact),prior_hybrid_replay:read('reports/HYBRID_REPLAY_01.json'),signature:'UNSIGNED'});
  run.finish();run.log('replay_verification_complete',{pairs:results.length,files:results.reduce((s,x)=>s+x.compared_files,0)});
} catch(e){run.fail(e);}
