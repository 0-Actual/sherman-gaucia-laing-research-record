import {createRun,read,modules} from '../numerics/runtime-v2.mjs';
const run=createRun(process.argv[2]);
try{
 const {b,containment}=await modules(),plan=read('inputs/ROBUSTNESS_PLAN.json'),matrices=[],cases=[],checks=[];
 run.save('plan.json',plan);run.save('containment.json',containment);
 const mul=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]],conj=a=>[a[0],-a[1]];
 for(let family=0;family<plan.matrix_families;family++){
  const rng=b.rng((plan.seed+7919*family)>>>0),angles=Array.from({length:18},()=>2*Math.PI*(rng()-.5)),gates=b.ansatz(angles),columns=Array.from({length:8},(_,j)=>b.dense(3,gates,j)),tail=[1.5,2.5,3.5,4.5,6.5,9.5].map(x=>x+.25*rng());
  let amplitudeError=0,unitarityError=0;
  for(let j=0;j<8;j++){const prep=[];for(let q=0;q<3;q++)if(j&(1<<(2-q)))prep.push({kind:'X',q});const actual=b.actualState([...prep,...gates]).state;for(let i=0;i<8;i++)amplitudeError=Math.max(amplitudeError,Math.hypot(actual[i][0]-columns[j][i][0],actual[i][1]-columns[j][i][1]));
   for(let k=0;k<8;k++){let re=0,im=0;for(let i=0;i<8;i++){const z=mul(conj(columns[j][i]),columns[k][i]);re+=z[0];im+=z[1];}unitarityError=Math.max(unitarityError,Math.hypot(re-(j===k?1:0),im));}
  }
  if(amplitudeError>2e-10||unitarityError>1e-10)throw Error('Input unitary check failed');
  checks.push({family,amplitude_error:amplitudeError,unitarity_error:unitarityError});
  for(let gi=0;gi<plan.gaps_ev.length;gi++){
   const gap=plan.gaps_ev[gi],values=[0,gap,...tail],H=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>{let re=0,im=0;for(let k=0;k<8;k++){const z=mul(columns[k][i],conj(columns[k][j]));re+=values[k]*z[0];im+=values[k]*z[1];}return [re,im];}));
   b.validateH(H);const ref=b.jacobi(H);if(Math.max(...values.map((v,j)=>Math.abs(v-ref.eigenvalues[j])))>1e-9)throw Error('Known spectrum mismatch');
   const matrix=matrices.length;matrices.push({matrix,family,gap_ev:gap,values,H,known_columns:columns,known_ground_parameters:angles});
   for(let seedIndex=0;seedIndex<plan.optimizer_seeds_per_matrix;seedIndex++){const index=cases.length;cases.push({index,matrix,family,gap_ev:gap,seed_index:seedIndex,optimizer_seed:(plan.seed+104729*family+15485863*gi+32452843*seedIndex)>>>0});}
  }
  run.log('matrix_family_prepared',{family,matrices:matrices.length,cases:cases.length});
 }
 if(cases.length!==plan.cases)throw Error('Case count mismatch');run.save('matrices.json',matrices);run.save('cases.json',cases);run.save('input_checks.json',checks);run.save('summary.json',{owner:plan.owner,matrices:matrices.length,cases:cases.length,unitary_columns_checked:checks.length*8,all_inputs_valid:true,signature:'UNSIGNED'});run.finish();
}catch(e){run.fail(e);}

