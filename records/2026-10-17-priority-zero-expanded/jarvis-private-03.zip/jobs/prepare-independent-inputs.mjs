import {createRun,modules} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]);
try {
  const {b,containment}=await modules();
  const plan={owner:'Sherman G. Laing',seed:2026092017,families:4,gaps_ev:[1,0.01,1e-4,1e-6,1e-8,0],starts_per_matrix:2,fidelity_goal:0.9999,energy_goal_ev:1e-6,generation:'Complex Gaussian columns, twice-reorthogonalized Gram-Schmidt; independent of Q8 ansatz.'};
  run.save('plan.json',plan); run.save('containment.json',containment);
  const mul=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];
  const conj=z=>[z[0],-z[1]];
  const inner=(a,b)=>a.reduce((s,z,i)=>{const t=mul(conj(z),b[i]);return [s[0]+t[0],s[1]+t[1]];},[0,0]);
  const matrices=[],cases=[],checks=[];
  for(let family=0;family<plan.families;family++) {
    const random=b.rng((plan.seed+family*104729)>>>0);
    const normal=()=>Math.sqrt(-2*Math.log(Math.max(random(),Number.MIN_VALUE)))*Math.cos(2*Math.PI*random());
    const columns=[];
    for(let k=0;k<8;k++) {
      let v=Array.from({length:8},()=>[normal(),normal()]);
      for(let pass=0;pass<2;pass++) for(const q of columns) {
        const a=inner(q,v);v=v.map((z,i)=>{const t=mul(q[i],a);return [z[0]-t[0],z[1]-t[1]];});
      }
      const norm=Math.sqrt(inner(v,v)[0]);if(!(norm>1e-10))throw Error('Degenerate Gaussian column');
      columns.push(v.map(z=>[z[0]/norm,z[1]/norm]));
    }
    let error=0;
    for(let i=0;i<8;i++)for(let j=0;j<8;j++){const z=inner(columns[i],columns[j]);error=Math.max(error,Math.hypot(z[0]-(i===j?1:0),z[1]));}
    if(error>1e-12)throw Error('Independent basis orthogonality failure');
    checks.push({family,unitarity_error:error});
    for(const gap of plan.gaps_ev) {
      const values=[0,gap,2,3,4,5,7,11];
      const H=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>{
        let re=0,im=0;for(let k=0;k<8;k++){const z=mul(columns[k][i],conj(columns[k][j]));re+=values[k]*z[0];im+=values[k]*z[1];}return [re,im];
      }));
      b.validateH(H);const ref=b.jacobi(H);
      if(Math.max(...values.map((v,k)=>Math.abs(v-ref.eigenvalues[k])))>1e-9)throw Error('Independent input spectrum failure');
      const matrix=matrices.length;matrices.push({matrix,family,gap_ev:gap,values,H,known_columns:columns});
      for(let seed_index=0;seed_index<plan.starts_per_matrix;seed_index++)cases.push({index:cases.length,matrix,family,gap_ev:gap,seed_index,seed:(plan.seed+matrix*15485863+seed_index*32452843)>>>0});
    }
  }
  run.save('matrices.json',matrices);run.save('cases.json',cases);run.save('checks.json',checks);
  run.save('summary.json',{owner:plan.owner,matrices:matrices.length,cases:cases.length,all_inputs_valid:true,signature:'UNSIGNED'});run.finish();
} catch(e){run.fail(e);}
