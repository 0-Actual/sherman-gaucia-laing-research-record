import fs from 'node:fs';
import path from 'node:path';
import {createRun,read,root,mirror} from '../numerics/runtime-v5.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
import {openLedger} from '../control/ledger.mjs';
const label=process.argv[2],run=createRun(label);
try {
  const control=read('control/MANIFEST.sgl.json'),sourceCache=new Map(),files=new Set(),runSources=[];
  for(const entry of control.files) {
    const bytes=fs.readFileSync(path.join(root,entry.path));
    if(bytes.length!==entry.bytes||hashBytes(bytes,'qel-work-artifact')!==entry.identity)throw Error('Tested control changed: '+entry.path);
    files.add(entry.path);
  }
  files.add('control/MANIFEST.sgl.json');
  function walk(relative) {
    for(const entry of fs.readdirSync(path.join(root,relative),{withFileTypes:true})) {
      const next=path.posix.join(relative,entry.name);
      if(entry.isSymbolicLink())throw Error('Unsupported symbolic link in evidence scope');
      if(entry.isDirectory())walk(next);else if(entry.isFile())files.add(next);
    }
  }
  for(const directory of ['inputs','numerics','jobs','queue','reports'])walk(directory);
  const runNames=fs.readdirSync(path.join(root,'runs'),{withFileTypes:true}).filter(x=>x.isDirectory()&&x.name!==label).map(x=>x.name).sort();
  let elapsed=0,userCpu=0,systemCpu=0,rss=0;
  for(const name of runNames) {
    walk('runs/'+name);
    if(fs.existsSync(path.join(root,'runs',name,'failure.json')))throw Error('Unresolved failed numerical run: '+name);
    if(['control_probe','control_probe_02'].includes(name))continue;
    const execution=read('runs/'+name+'/execution.json'),source=read('runs/'+name+'/sources.json');
    if(execution.source_unchanged!==true||execution.mirrored!==true)throw Error('Incomplete execution evidence: '+name);
    for(const entry of source.files) {
      if(!sourceCache.has(entry.file))sourceCache.set(entry.file,hashBytes(fs.readFileSync(path.join(root,entry.file)),'qel-numerical-source'));
      if(sourceCache.get(entry.file)!==entry.identity)throw Error('Numerical source changed since run: '+name+'/'+entry.file);
    }
    runSources.push({run:name,source_files:source.files.length,all_unchanged:true});
    elapsed+=execution.elapsed_ms;userCpu+=execution.cpu_microseconds.user;systemCpu+=execution.cpu_microseconds.system;
    rss=Math.max(rss,execution.sampled_maximum_rss_bytes);
  }
  for(const entry of fs.readdirSync(path.join(root,'runs'),{withFileTypes:true}))if(entry.isFile()&&!entry.name.startsWith(label+'_'))files.add('runs/'+entry.name);
  const expectedGroups=[['robustness_',72,3,4],['bracketed_study_',72,3,4],['material_regression_',8,2,2],['cold_compilation_',12,2,3],['independent_holdout_',4,2,3],['conditioned_validation_',10,2,3]];
  let predictionPairs=0;
  for(const [prefix,count,width,indexWidth] of expectedGroups)for(let k=0;k<count;k++) {
    const relative='runs/'+prefix+String(k).padStart(width,'0'),scores=read(relative+'/scores.json');
    for(const row of scores) {
      const stem=relative+'/case_'+String(row.index).padStart(indexWidth,'0');
      for(const suffix of ['_prediction.json','_score.json'])if(!files.has(stem+suffix))throw Error('Missing case evidence: '+stem+suffix);
      predictionPairs++;
    }
  }
  const replay=read('runs/replay_verification_01/summary.json');
  if(replay.pairs!==4||replay.deterministic_json_files!==185||replay.all_exact!==true||replay.prior_hybrid_replay.all_exact!==true||replay.prior_hybrid_replay.compared_json_files!==29)throw Error('Replay coverage incomplete');
  const manifest=[];
  for(const relative of [...files].sort()) {
    const primary=fs.readFileSync(path.join(root,relative)),copy=fs.readFileSync(path.join(mirror,relative));
    if(!primary.equals(copy))throw Error('Evidence mirror mismatch: '+relative);
    manifest.push({path:relative,bytes:primary.length,identity:hashBytes(primary,'qel-work-artifact')});
  }
  const contract=read('WORK_CONTRACT.json'),snapshot=openLedger([root,mirror],contract).read();
  for(const filename of fs.readdirSync(path.join(root,'queue')).filter(x=>x.endsWith('.json'))) {
    const spec=read('queue/'+filename);
    if(spec.id!==label&&snapshot.state.jobs[spec.id]?.status!=='FINISHED')throw Error('Queued work remains at audit: '+spec.id);
  }
  run.save('artifact_manifest.sgl.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',scope:'Inputs, numerical and job sources, queue descriptors, completed scientific run evidence, existing reports, and exact tested-control manifest members. Intentional tamper fixtures, live controller status and lock, this running audit, and future report files are excluded.',files:manifest});
  run.save('source_preservation.json',runSources);
  run.save('ledger_snapshot.json',{count:snapshot.count,head:snapshot.previous,at_utc:new Date().toISOString(),state:snapshot.state,scope:'Verified consistent ledger snapshot while this audit job is active; later controller completion events are outside this snapshot.'});
  run.save('execution_totals.json',{completed_recorded_runs:runSources.length,recorded_run_wall_ms:elapsed,process_cpu_microseconds:{user:userCpu,system:systemCpu},maximum_sampled_rss_bytes:rss,interpretation:'Run wall times include setup and evidence I/O. CPU time is measured by each child process. RSS is sampled, not a continuous peak measurement.'});
  run.save('summary.json',{owner:'Sherman G. Laing',passed:true,covered_files:manifest.length,covered_bytes:manifest.reduce((s,x)=>s+x.bytes,0),case_prediction_score_pairs:predictionPairs,source_preserved_runs:runSources.length,control_files_unchanged:control.files.length,replay_files_verified:185+29,ledger_events_verified:snapshot.count,signature:'UNSIGNED'});
  run.finish();run.log('evidence_audit_complete',{files:manifest.length,prediction_score_pairs:predictionPairs});
} catch(e){run.fail(e);}
