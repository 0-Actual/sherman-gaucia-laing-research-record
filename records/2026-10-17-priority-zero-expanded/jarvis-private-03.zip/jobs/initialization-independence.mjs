import {createRun,read,modules,overlap} from '../numerics/runtime-v5.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
const run=createRun(process.argv[2]);
try {
 const {cg,n,c,b,a,containment}=await modules(),plan=read('inputs/ROBUSTNESS_PLAN.json'),cfg=read('inputs/BRACKETED_CONTRACT.json');
 const matrices=read('runs/robustness_inputs/matrices.json'),cases=read('runs/robustness_inputs/cases.json'),m=matrices[0];
 const collisions=cases.filter(x=>x.optimizer_seed===((plan.seed+7919*x.family)>>>0));
 const old=read('runs/cold_compilation_05/case_066_prediction.json'),oldScore=read('runs/cold_compilation_05/case_066_score.json');
 const study=read('runs/study_aggregation_01/summary.json'),oldPair=read('runs/bracketed_study_000/scores.json')[0],oldStudy=read('runs/robustness_000/scores.json')[0],accepted=x=>x.energy_pass&&x.fidelity_pass&&x.correctness;
 const oldInitial=b.actualState(b.ansatz(old.initial_parameters)).state,oldFidelity=overlap(m.known_columns[0],oldInitial);
 const occupied=new Set([...matrices.map(x=>(plan.seed+7919*x.family)>>>0),...cases.map(x=>x.optimizer_seed)]);
 const derive=(domain,attempt)=>Number.parseInt(hashBytes(Buffer.from(JSON.stringify({base_seed:plan.seed,domain,attempt})),'qel-validation-seed').split(':').at(-1).slice(0,8),16)>>>0;
 let initial,initialFidelity,seed,attempt;
 for(attempt=0;attempt<32;attempt++){
  seed=derive('screened-initial-parameters',attempt);if(occupied.has(seed))continue;
  const random=b.rng(seed);initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
  initialFidelity=overlap(m.known_columns[0],b.actualState(b.ansatz(initial)).state);
  if(Number.isFinite(initialFidelity)&&initialFidelity<cfg.fidelity_goal)break;
 }
 if(attempt===32)throw Error('No screened non-solution starting state found');
 let fitSeed,fitAttempt;
 for(fitAttempt=0;fitAttempt<32;fitAttempt++){fitSeed=derive('fitting-perturbations',fitAttempt);if(fitSeed!==seed&&!occupied.has(fitSeed))break;}
 if(fitAttempt===32)throw Error('No disjoint perturbation seed found');
 run.save('containment.json',containment);
 run.save('contract.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',matrix:0,original_study_case:0,original_cold_case:66,initial_seed:seed,fit_seed:fitSeed,initial_seed_attempt:attempt,fit_seed_attempt:fitAttempt,method:cfg.method,policy:'Domain-separated deterministic streams; reject reused seeds and already-solved starts. Screening uses the known reference only to identify a nontrivial test start. The solver receives only H and initial parameters.'});
 run.save('input.json',{H:m.H,initial_parameters:initial,initial_fidelity:initialFidelity});
 const started=performance.now(),prediction=cg.conditionedRefine(m.H,initial,cfg.method,fitSeed),elapsed=performance.now()-started;
 const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=m.H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);}));
 const ref=n.symmetricEigen(A),bands=b.jacobi(m.H),diag=c.stateDiagnostics(m.H,prediction.parameters);
 const vector=prediction.amplitudes.map(z=>z[0]).concat(prediction.amplitudes.map(z=>z[1]));
 const fidelity=ref.vectors.slice(0,2).reduce((s,col)=>s+col.reduce((t,x,i)=>t+x*vector[i],0)**2,0),known=overlap(m.known_columns[0],prediction.amplitudes);
 const spectrumError=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(ref.values[2*j]+ref.values[2*j+1])/2)));
 const measurement={energy_error_ev:prediction.energy_ev-bands.eigenvalues[0],fidelity,norm_error:Math.abs(diag.norm-1),amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,reference_verified:ref.residual<=1e-9&&spectrumError<=1e-9&&Math.abs(prediction.energy_ev-diag.energy_ev)<=1e-9};
 const assessment=a.assessState(measurement),iterations=prediction.normalized_prediction.fit_starts.reduce((s,x)=>s+x.iterations,0);
 const checks={original_case_passed_all_methods:accepted(oldStudy.baseline)&&accepted(oldStudy.hybrid)&&accepted(oldPair),single_detected_seed_reuse:collisions.length===1&&collisions[0].index===0,old_case_initially_solved:oldFidelity>=cfg.fidelity_goal&&oldScore.fit_starts[0].iterations===0,initial_seed_disjoint:!occupied.has(seed),perturbation_seed_disjoint:fitSeed!==seed&&!occupied.has(fitSeed),new_start_not_already_solved:initialFidelity<cfg.fidelity_goal,fit_did_real_iterations:iterations>0,independent_fidelity_agreement:Math.abs(known-fidelity)<=1e-8,scientific_acceptance:assessment.accepted};
 if(Object.values(checks).some(x=>!x))throw Error('Initialization-independence confirmation failed: '+JSON.stringify(checks));
 const review={collisions,old_initial_fidelity:oldFidelity,old_parameter_max_difference:Math.max(...old.initial_parameters.map((x,i)=>Math.abs(x-m.known_ground_parameters[i]))),original_counts_preserved:{study:study.study.cases,cold:study.cold_compilation.cases},excluding_identified_already_solved_case:{study_cases:study.study.cases-1,baseline_accepted:study.study.baseline_accepted-Number(accepted(oldStudy.baseline)),rayleigh_accepted:study.study.rayleigh_accepted-Number(accepted(oldStudy.hybrid)),bracketed_accepted:study.study.bracketed_accepted-Number(accepted(oldPair)),cold_cases:study.cold_compilation.cases-1,cold_accepted:study.cold_compilation.accepted-Number(accepted(oldScore))},interpretation:'The original paired study is preserved. One case was an already-solved seeded control; excluding it does not alter the 296 and 39 observed improvement counts. This separate confirmation supplies a screened starting state for the affected matrix.'};
 run.save('initialization_review.json',review);run.save('prediction.json',prediction);run.save('reference.json',{eigenvalues:bands.eigenvalues,residual:ref.residual,spectrum_error:spectrumError,known_fidelity:known});
 run.save('summary.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',checks,all_passed:true,initial_fidelity:initialFidelity,measurement,assessment,iterations,solver_elapsed_ms:elapsed,initial_seed:seed,fit_seed:fitSeed,review});
 run.finish();run.log('initialization_independence_confirmed',{initial_fidelity:initialFidelity,final_fidelity:fidelity,accepted:assessment.accepted,checks:Object.keys(checks).length});
} catch(error){run.fail(error);}
