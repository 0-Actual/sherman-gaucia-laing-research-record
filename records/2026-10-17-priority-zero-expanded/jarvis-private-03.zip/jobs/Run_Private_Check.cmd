@echo off
setlocal
"./REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe" --no-warnings --max-old-space-size=128 --permission "--allow-fs-read=./REDACTED_LOCAL_ROOT/Documents\Codex\Q8_Testing_Space\JARVIS_Private_20260920_03" "--allow-fs-read=./REDACTED_LOCAL_ROOT/QEL_Q7\Q8_Testing_Space\JARVIS_Private_20260920_03" "--allow-fs-write=./REDACTED_LOCAL_ROOT/Documents\Codex\Q8_Testing_Space\JARVIS_Private_20260920_03" "--allow-fs-write=./REDACTED_LOCAL_ROOT/QEL_Q7\Q8_Testing_Space\JARVIS_Private_20260920_03" --experimental-vm-modules "%~dp0private-check.mjs"
set "qel_check_exit=%errorlevel%"
echo.
pause
exit /b %qel_check_exit%
