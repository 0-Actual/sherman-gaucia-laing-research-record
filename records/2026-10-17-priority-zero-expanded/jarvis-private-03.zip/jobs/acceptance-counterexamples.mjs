import {createRun,modules} from '../numerics/runtime-v5.mjs';
const run=createRun(process.argv[2]);
try {
  const {a,b,containment}=await modules();run.save('containment.json',containment);
  run.save('contract.json',{energy_goal_ev:1e-6,fidelity_goal:0.9999,purpose:'Reject low-energy wrong states, exact excited states, missing evidence, nonfinite evidence, and inconsistent circuit results.'});
  const tests=[],physical=[];
  const check=(name,pass,details={})=>{tests.push({name,pass,...details});if(!pass)throw Error('Acceptance regression failed: '+name);};
  const cases=[
    {name:'exact_ground',angle:0,gap:1e-8,degeneracy:1,expected:true},
    {name:'exact_excited_low_energy',angle:Math.PI,gap:1e-8,degeneracy:1,expected:false},
    {name:'mixed_wrong_state_low_energy',angle:Math.PI/2,gap:1e-8,degeneracy:1,expected:false},
    {name:'high_fidelity_excess_energy',angle:2*Math.asin(Math.sqrt(1e-5)),gap:1000,degeneracy:1,expected:false},
    {name:'degenerate_ground_subspace',angle:Math.PI/2,gap:0,degeneracy:2,expected:true}
  ];
  for(const item of cases) {
    const gates=[{kind:'RY',q:2,angle:item.angle},{kind:'RZ',q:2,angle:0.37}];
    const state=b.actualState(gates).state,dense=b.dense(3,gates),norm=state.reduce((s,z)=>s+z[0]**2+z[1]**2,0),normDense=dense.reduce((s,z)=>s+z[0]**2+z[1]**2,0);
    const probability=state.map(z=>z[0]**2+z[1]**2),energy=item.gap*probability[1]/norm;
    const measurement={energy_error_ev:energy,fidelity:probability.slice(0,item.degeneracy).reduce((s,x)=>s+x,0)/norm,norm_error:Math.abs(norm-1),amplitude_error:Math.max(...state.map((z,i)=>Math.hypot(z[0]-dense[i][0],z[1]-dense[i][1]))),dense_energy_error_ev:Math.abs(energy-item.gap*(dense[1][0]**2+dense[1][1]**2)/normDense),reference_verified:true};
    const residual=Math.sqrt(probability[0]*energy**2+probability[1]*(item.gap-energy)**2);
    const decision=a.assessState(measurement);physical.push({case:item,measurement,residual_ev:residual,decision});
    check(item.name,decision.accepted===item.expected,{status:decision.status,reasons:decision.reasons});
  }
  const good=physical[0].measurement;
  for(const [name,patch] of [['nan_fidelity',{fidelity:NaN}],['infinite_energy',{energy_error_ev:Infinity}],['bad_norm',{norm_error:0.1}],['complex_circuit_mismatch',{amplitude_error:1e-7}],['dense_energy_mismatch',{dense_energy_error_ev:1e-6}],['unverified_reference',{reference_verified:false}],['impossible_energy',{energy_error_ev:-1e-5}],['impossible_fidelity',{fidelity:1.1}]])check(name,!a.assessState({...good,...patch}).accepted);
  const missing={...good};delete missing.fidelity;check('energy_only_is_insufficient',a.assessState(missing).status==='INSUFFICIENT_EVIDENCE');
  check('null_measurement_is_insufficient',a.assessState(null).status==='INSUFFICIENT_EVIDENCE');
  let rejected=false;try{a.assessState(good,{fidelity_goal:NaN});}catch{rejected=true;}check('invalid_threshold_rejected',rejected);
  check('small_gap_energy_bound_is_uninformative',a.energyFidelityLowerBound({energy_error_upper_ev:1e-6,gap_lower_ev:1e-8}).lower_bound===0);
  check('tight_energy_bound_certifies_target',a.energyFidelityLowerBound({energy_error_upper_ev:1e-12,gap_lower_ev:1e-8}).lower_bound>=0.9999);
  check('zero_gap_requires_subspace',!a.energyFidelityLowerBound({energy_error_upper_ev:1e-12,gap_lower_ev:0}).available);
  run.save('physical_counterexamples.json',physical);run.save('tests.json',tests);
  run.save('summary.json',{owner:'Sherman G. Laing',checks:tests.length,passed:tests.filter(x=>x.pass).length,physical_cases:physical.length,all_passed:tests.every(x=>x.pass),signature:'UNSIGNED'});run.finish();
} catch(e){run.fail(e);}
