JARVIS PRIVATE LAPTOP CHECK
Owner: Sherman G. Laing
Implementation assistance: GAUCIA
Signature status: UNSIGNED

Double-click Run_Private_Check.cmd in this folder.
Enter three fractional reciprocal coordinates, separated by spaces or commas.
Press Enter without coordinates to use 0 0 0.
Example: 0.2 0.4 0.6
Coordinates are folded periodically into the interval [0, 1).

Keep the laptop copy and the D: USB destination available.
If the research controller is still active, the command refuses to start a competing numerical run.
An interruption can leave a session lock that needs inspection; do not delete another process's lock.

The command reconstructs the eight-orbital JVASP-816 aluminum Wannier matrix,
finds a target with centered classical linear algebra, and fits the unchanged Q8 circuit.
It checks the actual circuit against independent dense calculations and checks the state
against an independently computed reference ground space.
Acceptance requires energy error <= 1e-6 eV and ground-space fidelity >= 0.9999,
along with circuit and reference consistency. Numerical degeneracy uses 1e-9 eV.

The console prints PASS or FAIL and the measured errors.
Detailed evidence is saved in a new runs/private_check_<timestamp> folder on both drives.
Existing runs are preserved. No GitHub publication is part of this command.
The calculation uses eight complex amplitudes and three logical qubits in a classical simulation.
It describes the lowest eigenstate of this Wannier matrix, not the full many-electron material ground state.

Exit codes: 0 passed; 1 scientific checks failed; 2 an existing session blocked the run; 3 execution error.
The standard launcher caps the Node heap at 128 MiB and restricts file access to the two private project folders.
The numerical module context has no host or network bindings. This is not an OS-wide network isolation guarantee.
