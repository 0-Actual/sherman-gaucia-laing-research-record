import {createRun,read,modules,overlap} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]),batch=Number(process.argv[3]);
try{
 const {g,c,b,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json'),matrices=read('runs/robustness_inputs/matrices.json'),cases=read('runs/robustness_inputs/cases.json').slice(batch*10,batch*10+10),scores=[];
 if(!Number.isInteger(batch)||batch<0||batch>=72||cases.length!==10)throw Error('Invalid paired batch');run.save('contract.json',cfg);run.save('containment.json',containment);
 for(const item of cases){
  const original=read('runs/robustness_'+String(batch).padStart(3,'0')+'/case_'+String(item.index).padStart(4,'0')+'_prediction.json'),oldScore=read('runs/robustness_'+String(batch).padStart(3,'0')+'/case_'+String(item.index).padStart(4,'0')+'_score.json'),m=matrices[item.matrix],p=g.bracketedRefine(m.H,original.baseline.parameters,cfg.method,(item.optimizer_seed+101)>>>0);
  run.save('case_'+String(item.index).padStart(4,'0')+'_prediction.json',{case:item,prediction:p});
  const diag=c.stateDiagnostics(m.H,p.parameters),ref=b.jacobi(m.H);let fidelity=overlap(m.known_columns[0],p.amplitudes),targetFidelity=overlap(m.known_columns[0],p.target.amplitudes);if(m.gap_ev===0){fidelity+=overlap(m.known_columns[1],p.amplitudes);targetFidelity+=overlap(m.known_columns[1],p.target.amplitudes);}
  const error=p.energy_ev-ref.eigenvalues[0],correct=Math.abs(p.norm-1)<2e-10&&diag.max_amplitude_error<2e-10&&diag.dense_energy_error_ev<1e-9&&error>=-1e-8;if(!correct)throw Error('Q8 circuit correctness failure');
  const row={...item,baseline_fidelity:oldScore.baseline.fidelity,rayleigh_hybrid_fidelity:oldScore.hybrid.fidelity,bracketed_fidelity:fidelity,target_fidelity:targetFidelity,target_fit:p.target_fit_fidelity,fidelity_pass:fidelity>=cfg.fidelity_goal,energy_error_ev:error,energy_pass:error<=cfg.energy_goal_ev,correctness:true,residual_ev:p.residual_ev,fit_starts:p.fit_starts,diagnosis:fidelity>=cfg.fidelity_goal?'passes':targetFidelity<cfg.fidelity_goal?'target_refinement_miss':'circuit_fit_miss'};
  scores.push(row);run.save('case_'+String(item.index).padStart(4,'0')+'_score.json',row);run.log('paired_bracketed_case',{index:item.index,gap_ev:item.gap_ev,baseline_fidelity:row.baseline_fidelity,rayleigh_fidelity:row.rayleigh_hybrid_fidelity,bracketed_fidelity:fidelity,diagnosis:row.diagnosis});
 }
 run.save('scores.json',scores);run.save('summary.json',{owner:'Sherman G. Laing',batch,cases:10,fidelity_passes:scores.filter(r=>r.fidelity_pass).length,energy_passes:scores.filter(r=>r.energy_pass).length,correctness_passes:10,misses:scores.filter(r=>!r.fidelity_pass||!r.energy_pass),signature:'UNSIGNED'});run.finish();
}catch(e){run.fail(e);}
