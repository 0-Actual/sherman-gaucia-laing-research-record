import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';import {fileURLToPath} from 'node:url';
import {initialState,applyEvent,applyEventInPlace} from './work-guard-v2.mjs';
import {applyEvent as oldApply} from '../control/guard.mjs';
import {openLedger as oldOpen} from '../control/ledger.mjs';
import {openLedger} from './work-ledger-v2.mjs';import {hashBytes} from '../control/vendor/sgl-prime.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),mirror='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_03',roots=[root,mirror],c=JSON.parse(fs.readFileSync(path.join(root,'WORK_CONTRACT.json'),'utf8')),t=Date.parse(c.recorded_utc),rows=[];
const fixtures=roots.map(r=>path.join(r,'tests','batch-ledger-v1'));for(const r of fixtures)fs.mkdirSync(path.join(r,'ledger'),{recursive:true});
const journal=openLedger(fixtures,c),event=(type,data)=>({type,data,at_ms:t});
function test(name,fn){try{fn();rows.push({name,pass:true});}catch(e){rows.push({name,pass:false,error:String(e)});}}
function unchanged(fn){const before=journal.read();assert.throws(fn);assert.deepEqual(journal.read(),before);}
test('invalid later transition writes no earlier event',()=>unchanged(()=>journal.appendMany([event('CHECKPOINT',{evidence:'would-be-first.json'}),event('JOB_STARTED',{id:'missing'})])));
test('duplicate registration within a batch writes neither event',()=>unchanged(()=>journal.appendMany([event('JOB_REGISTERED',{id:'same',purpose:'Check duplicate identifiers before any event writes.'}),event('JOB_REGISTERED',{id:'same',purpose:'Check duplicate identifiers before any event writes.'})])));
test('empty batches are refused without writes',()=>unchanged(()=>journal.appendMany([])));
test('oversized batches are refused without writes',()=>unchanged(()=>journal.appendMany(Array.from({length:33},()=>event('CHECKPOINT',{evidence:'x'})))));
test('NaN progress is refused after canonicalization',()=>unchanged(()=>journal.appendMany([event('SESSION_PROGRESS',{elapsed_ms:NaN})])));
test('infinite timestamps are refused',()=>unchanged(()=>journal.appendMany([{type:'CHECKPOINT',data:{evidence:'x'},at_ms:Infinity}])));
let returned;
test('four valid job transitions commit and match legacy reader exactly',()=>{
 returned=journal.appendMany([event('JOB_REGISTERED',{id:'sample',purpose:'Verify compatibility across full sequential job transitions.'}),event('JOB_STARTED',{id:'sample'}),event('JOB_FINISHED',{id:'sample',exit_code:0,bytes_verified:true,elapsed_ms:12,artifacts:[{path:'sample.json',bytes:12,identity:'fixture'}]}),event('CHECKPOINT',{evidence:'sample.json'})]);
 assert.equal(returned.count,4);assert.deepEqual(returned,oldOpen(fixtures,c).read());assert.equal(returned.state.jobs.sample.status,'FINISHED');
});
test('returned snapshot cannot mutate persisted evidence',()=>{returned.state.jobs.sample.status='BAD';assert.equal(journal.read().state.jobs.sample.status,'FINISHED');});
test('caller data cannot mutate the returned canonical snapshot',()=>{const d={id:'workflow_controls',passed:true,evidence:['fixture.json'],metrics:{count:1}};const result=journal.appendMany([event('GOAL_MEASURED',d)]);d.evidence.push('later');d.metrics.count=999;assert.deepEqual(result.state.goals.workflow_controls.evidence,['fixture.json']);assert.equal(result.state.goals.workflow_controls.metrics.count,1);assert.deepEqual(result,journal.read());});
test('public state transition remains nonmutating',()=>{const prior=initialState(c,t),saved=structuredClone(prior),next=applyEvent(c,prior,event('CHECKPOINT',{evidence:'x'}));assert.deepEqual(prior,saved);assert.equal(next.checkpoints.length,1);});
const prefixCount=619,prefix=[],contractIdentity=hashBytes(Buffer.from(JSON.stringify(c)),'qel-work-contract');let previous=null;
test('fixed production prefix retains every mirror and chain check',()=>{for(let i=1;i<=prefixCount;i++){const name=String(i).padStart(6,'0')+'.json',bytes=roots.map(r=>fs.readFileSync(path.join(r,'ledger',name)));assert(bytes[0].equals(bytes[1]));const item=JSON.parse(bytes[0]);assert.equal(item.payload.sequence,i);assert.equal(item.payload.previous,previous);assert.equal(item.payload.contract,contractIdentity);assert.equal(item.identity,hashBytes(Buffer.from(JSON.stringify(item.payload)),'qel-work-event'));prefix.push(item.payload.event);previous=item.identity;}});
function replay(fn){let state=initialState(c,t);const start=performance.now(),cpuStart=process.cpuUsage();for(const e of prefix)state=fn(c,state,e);return {state,wall_ms:performance.now()-start,cpu_us:process.cpuUsage(cpuStart)};}
const old=replay(oldApply),optimized=replay(applyEventInPlace);
test('optimized replay equals the original fold on the same 619 real events',()=>assert.deepEqual(optimized.state,old.state));
test('optimized completion gate inputs retain the original contract and timing',()=>{assert.equal(optimized.state.started_ms,t);assert.equal(optimized.state.observed_session_ms,old.state.observed_session_ms);assert.deepEqual(optimized.state.goals,old.state.goals);});
const result={owner:c.owner,at_utc:new Date().toISOString(),tests:rows.length,passes:rows.filter(x=>x.pass).length,failures:rows.filter(x=>!x.pass),rows,benchmark:{scope:'Identical already-read event prefix; wall and process CPU exclude disk I/O and lock wait. Single measurement on the active laptop.',events:prefix.length,prefix_head:previous,original:{wall_ms:old.wall_ms,cpu_us:old.cpu_us},optimized:{wall_ms:optimized.wall_ms,cpu_us:optimized.cpu_us},wall_ratio:old.wall_ms/optimized.wall_ms},limitation:'Batch transition validation precedes all writes; hardware crash atomicity is not claimed.',signature:'UNSIGNED'};
for(const r of roots)fs.writeFileSync(path.join(r,'reports','BATCH_CONTROL_TEST_RESULTS_V1.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(result));if(result.failures.length)process.exitCode=1;
