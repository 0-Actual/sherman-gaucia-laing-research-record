import fs from 'node:fs';
import path from 'node:path';
import {createRun,read,root} from '../numerics/runtime-v5.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
const run=createRun(process.argv[2]);
try {
  const plan=read('inputs/JARVIS_GRID_PLAN.json'),rows=[],identities=[];
  for(let batch=0;batch<11;batch++) {
    const directory='runs/jarvis_grid_'+String(batch).padStart(2,'0');
    rows.push(...read(directory+'/scores.json'));identities.push(read(directory+'/input_source.json').identity);
  }
  if(rows.length!==125||new Set(rows.map(x=>x.index)).size!==125||rows.some((x,i)=>x.index!==i||JSON.stringify(x.kpoint)!==JSON.stringify(plan.cases[i].kpoint)))throw Error('Incomplete or mismatched material grid');
  if(new Set(identities).size!==1||identities[0]!==hashBytes(fs.readFileSync(path.join(root,'inputs/wannier90_hr.dat')),'qel-jarvis-input'))throw Error('Wannier input identity changed across grid');
  const exactFiles=[];
  for(const [first,second] of [['robustness_inputs','robustness_inputs_replay'],['independent_inputs','independent_inputs_replay']]) {
    const filenames=name=>fs.readdirSync(path.join(root,'runs',name)).filter(x=>x.endsWith('.json')&&x!=='execution.json').sort();
    const firstNames=filenames(first),secondNames=filenames(second);
    if(firstNames.length!==7||JSON.stringify(firstNames)!==JSON.stringify(secondNames))throw Error('Input replay membership mismatch');
    for(const file of firstNames) {
      const exact=fs.readFileSync(path.join(root,'runs',first,file)).equals(fs.readFileSync(path.join(root,'runs',second,file)));
      if(!exact)throw Error('Input replay differs: '+first+'/'+file);
      exactFiles.push({first,second,file,byte_exact:true});
    }
  }
  for(const suffix of ['input','prediction','score']) {
    const file='case_000_'+suffix+'.json';
    if(!fs.readFileSync(path.join(root,'runs/jarvis_grid_pilot_01',file)).equals(fs.readFileSync(path.join(root,'runs/jarvis_grid_00',file))))throw Error('Full JARVIS pipeline replay differs: '+file);
    exactFiles.push({first:'jarvis_grid_pilot_01',second:'jarvis_grid_00',file,byte_exact:true});
  }
  const previous=read('inputs/REGRESSION_CASES.json').filter(x=>x.group!=='synthetic'&&Array.isArray(x.kpoint));
  const canonical=k=>k.map(x=>(((x%1)+1)%1).toFixed(12)).join(',');
  const previousKeys=new Set(previous.map(x=>canonical(x.kpoint)));
  const newPoints=rows.filter(x=>!previousKeys.has(canonical(x.kpoint))).length;
  const rawKeys=new Set(previous.map(x=>JSON.stringify(x.kpoint)));
  const flat=Array.from({length:4},(_,i)=>read('runs/flat_start_regression_'+String(i).padStart(2,'0')+'/scores.json')).flat();
  if(flat.length!==64||flat.some((x,i)=>x.index!==i))throw Error('Flat-start coverage incomplete');
  const publication=read('reports/QUEUE_PUBLICATION_TESTS_01.json');
  if(!publication.all_passed||publication.checks!==15||publication.source_identity!==hashBytes(fs.readFileSync(path.join(root,'jobs/queue-publisher.mjs')),'qel-work-artifact')||publication.test_identity!==hashBytes(fs.readFileSync(path.join(root,'jobs/queue-publication-check.mjs')),'qel-work-artifact'))throw Error('Queue publication control evidence invalid');
  const times=rows.map(x=>read('runs/jarvis_grid_'+String(Math.floor(x.index/12)).padStart(2,'0')+'/case_'+String(x.index).padStart(3,'0')+'_timing.json').elapsed_ms);
  if(!times.every(x=>Number.isFinite(x)&&x>=0)||rows.some(x=>!Number.isFinite(x.measurement.fidelity)||!Number.isFinite(x.measurement.energy_error_ev)))throw Error('Invalid material metrics');
  const summary={
    owner:'Sherman G. Laing',signature:'UNSIGNED',
    grid:{cases:125,accepted:rows.filter(x=>x.assessment.accepted).length,new_periodic_coordinates_vs_prior_material_cases:newPoints,previous_distinct_raw_coordinates:rawKeys.size,previous_distinct_periodic_coordinates:previousKeys.size,numerically_degenerate_cases:rows.filter(x=>x.ground_degeneracy>1).length,min_fidelity:Math.min(...rows.map(x=>x.measurement.fidelity)),max_energy_error_ev:Math.max(...rows.map(x=>x.measurement.energy_error_ev)),max_periodicity_error:Math.max(...rows.map(x=>x.periodicity_error)),max_raw_hermiticity_defect:Math.max(...rows.map(x=>x.raw_hermiticity_defect)),minimum_gap_to_next_ground_space_ev:Math.min(...rows.filter(x=>x.gap_to_next_space_ev!==null).map(x=>x.gap_to_next_space_ev)),lowest_band_energy_range_ev:[Math.min(...rows.map(x=>x.reference_eigenvalues_ev[0])),Math.max(...rows.map(x=>x.reference_eigenvalues_ev[0]))],full_solver_case_time_ms:{total:times.reduce((s,x)=>s+x,0),mean:times.reduce((s,x)=>s+x,0)/125},misses:rows.filter(x=>!x.assessment.accepted)},
    flat_starts:{cases:64,plain_accepted:flat.filter(x=>x.plain.assessment.accepted).length,conditioned_accepted:flat.filter(x=>x.corrected.assessment.accepted).length,zero_iteration_wrong_states:flat.filter(x=>x.plain_iterations===0&&!x.plain.assessment.accepted).length,misses:flat.filter(x=>!x.corrected.assessment.accepted)},
    additional_exact_replay_files:exactFiles.length,queue_publication_checks:publication.checks,
    interpretation:'JARVIS results concern the lowest eigenstate of an eight-orbital Wannier matrix at each reciprocal point, not the full many-electron ground state. Numerical degeneracy uses the declared 1e-9 eV reference tolerance.'
  };
  run.save('summary.json',summary);run.save('grid_scores.json',rows);run.save('additional_replay_comparisons.json',exactFiles);run.finish();
  run.log('supplemental_aggregation_complete',{grid_accepted:summary.grid.accepted,flat_accepted:summary.flat_starts.conditioned_accepted,replay_files:exactFiles.length});
} catch(e){run.fail(e);}
