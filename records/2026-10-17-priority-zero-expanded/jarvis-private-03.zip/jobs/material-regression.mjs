import {createRun,read,modules,overlap} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]),start=Number(process.argv[3]),count=Number(process.argv[4]);
try{
 const {g,n,c,b,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json'),all=read('inputs/REGRESSION_CASES.json'),cases=all.slice(start,start+count),scores=[];
 if(!Number.isInteger(start)||!Number.isInteger(count)||cases.length!==count||count<1||count>12)throw Error('Invalid regression batch');
 run.save('contract.json',{...cfg,scope:'Refine the 72 saved second-pass states and independently score eigenvector fidelity, including the real-material cases.',start,count});run.save('containment.json',containment);
 for(const item of cases){
  const p=g.bracketedRefine(item.H,item.parameters,cfg.method,(20260920+item.index*7919)>>>0);run.save('case_'+String(item.index).padStart(2,'0')+'_prediction.json',{index:item.index,prediction:p});
  const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=item.H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);})),reference=n.symmetricEigen(A),bands=b.jacobi(item.H),vector=p.amplitudes.map(z=>z[0]).concat(p.amplitudes.map(z=>z[1])),oldState=b.actualState(b.ansatz(item.parameters)).state,oldVector=oldState.map(z=>z[0]).concat(oldState.map(z=>z[1]));
  const projection=v=>reference.vectors.slice(0,2*item.ground_degeneracy).reduce((s,col)=>s+col.reduce((a,x,i)=>a+x*v[i],0)**2,0),fidelity=projection(vector),oldFidelity=projection(oldVector),spectrumError=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(reference.values[2*j]+reference.values[2*j+1])/2)));
  if(reference.residual>1e-9||spectrumError>1e-9)throw Error('Independent eigenvector reference failed');
  let knownFidelity=null;if(item.known_columns){knownFidelity=0;for(let i=0;i<item.ground_degeneracy;i++)knownFidelity+=overlap(item.known_columns[i],p.amplitudes);if(Math.abs(knownFidelity-fidelity)>1e-8)throw Error('Known and independent fidelity references disagree');}
  const diag=c.stateDiagnostics(item.H,p.parameters),error=p.energy_ev-bands.eigenvalues[0],correct=Math.abs(p.norm-1)<2e-10&&diag.max_amplitude_error<2e-10&&diag.dense_energy_error_ev<1e-9&&error>=-1e-8;
  if(!correct)throw Error('Actual Q8 circuit correctness failed');
  const row={index:item.index,group:item.group,kpoint:item.kpoint,ground_degeneracy:item.ground_degeneracy,old_fidelity:oldFidelity,fidelity,known_fidelity:knownFidelity,fidelity_pass:fidelity>=cfg.fidelity_goal,energy_error_ev:error,energy_pass:error<=cfg.energy_goal_ev,correctness:true,residual_ev:p.residual_ev,reference_residual:reference.residual,reference_spectrum_error:spectrumError,max_amplitude_error:diag.max_amplitude_error,fit_starts:p.fit_starts};scores.push(row);run.save('case_'+String(item.index).padStart(2,'0')+'_reference.json',{index:item.index,values:reference.values,vectors:reference.vectors,residual:reference.residual});run.save('case_'+String(item.index).padStart(2,'0')+'_score.json',row);run.log('regression_scored',{index:item.index,group:item.group,old_fidelity:oldFidelity,fidelity,energy_error_ev:error,pass:row.fidelity_pass&&row.energy_pass});
 }
 run.save('scores.json',scores);run.save('summary.json',{owner:'Sherman G. Laing',start,count,correctness_passes:scores.filter(x=>x.correctness).length,fidelity_passes:scores.filter(x=>x.fidelity_pass).length,energy_passes:scores.filter(x=>x.energy_pass).length,min_fidelity:Math.min(...scores.map(x=>x.fidelity)),misses:scores.filter(x=>!x.fidelity_pass||!x.energy_pass),signature:'UNSIGNED'});run.finish();
}catch(e){run.fail(e);}
