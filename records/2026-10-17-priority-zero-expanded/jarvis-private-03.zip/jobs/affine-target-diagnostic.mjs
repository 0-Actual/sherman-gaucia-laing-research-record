import {createRun,read,modules,overlap} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]);
try {
  const {g,n,b,containment}=await modules();
  const cfg=read('inputs/BRACKETED_CONTRACT.json');
  const matrices=read('runs/robustness_inputs/matrices.json');
  const plan={gaps_ev:[1,1e-6,1e-8],scales:[0.001,1,1000],offsets_ev:[0,-40,40,10000,1000000],fidelity_goal:cfg.fidelity_goal};
  run.save('plan.json',plan); run.save('containment.json',containment);
  const scores=[];
  for(const gap of plan.gaps_ev) for(const scale of plan.scales) for(const offset of plan.offsets_ev) {
    const m=matrices.find(x=>x.family===0&&x.gap_ev===gap);
    const H=m.H.map((row,i)=>row.map((z,j)=>[scale*z[0]+(i===j?offset:0),scale*z[1]]));
    b.validateH(H);
    const p=g.groundTarget(H,cfg.method);
    run.save('case_'+String(scores.length).padStart(3,'0')+'_prediction.json',{gap,scale,offset,prediction:p});
    const center=H.reduce((s,row,i)=>s+row[i][0],0)/8;
    const K=H.map((row,i)=>row.map((z,j)=>[(z[0]-(i===j?center:0))/scale,z[1]/scale]));
    const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{
      const z=K[i%8][j%8]; return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);
    }));
    const ref=n.symmetricEigen(A);
    const vector=p.amplitudes.map(z=>z[0]).concat(p.amplitudes.map(z=>z[1]));
    const referenceFidelity=ref.vectors.slice(0,2).reduce((sum,v)=>sum+v.reduce((s,x,i)=>s+x*vector[i],0)**2,0);
    const intendedFidelity=overlap(m.known_columns[0],p.amplitudes);
    const representedGap=(ref.values[2]+ref.values[3]-ref.values[0]-ref.values[1])/2;
    if(!Number.isFinite(referenceFidelity)||ref.residual>1e-9) throw Error('Affine reference failure');
    const row={index:scores.length,gap_ev:gap,scale,offset_ev:offset,represented_fidelity:referenceFidelity,intended_fidelity:intendedFidelity,represented_gap_normalized:representedGap,reference_residual:ref.residual,pass:referenceFidelity>=plan.fidelity_goal,target_residual_ev:p.residual_ev,bracket_width_ev:p.bracket.width,regularization_ev:cfg.method.shift_regularization*p.bracket.scale};
    scores.push(row); run.save('case_'+String(row.index).padStart(3,'0')+'_score.json',row);
  }
  run.save('scores.json',scores);
  run.save('summary.json',{owner:'Sherman G. Laing',cases:scores.length,passes:scores.filter(x=>x.pass).length,misses:scores.filter(x=>!x.pass),scope:'Target solver shift and scale invariance; represented-matrix and intended-matrix fidelities are distinguished. No Q8 fitting in this diagnostic.',signature:'UNSIGNED'});
  run.finish(); run.log('affine_target_diagnostic_complete',{cases:scores.length,passes:scores.filter(x=>x.pass).length});
} catch(e) {run.fail(e);}
