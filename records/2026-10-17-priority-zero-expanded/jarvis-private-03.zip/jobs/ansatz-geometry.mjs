import {createRun,read,modules} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]);
try{
 const {b,n,containment}=await modules(),random=b.rng(2026092017),rows=[];run.save('containment.json',containment);
 const inner=(a,b)=>a.reduce((s,z,i)=>[s[0]+z[0]*b[i][0]+z[1]*b[i][1],s[1]+z[0]*b[i][1]-z[1]*b[i][0]],[0,0]);
 for(let k=0;k<100;k++){
  const theta=k===0?Array(18).fill(0):Array.from({length:18},()=>2*Math.PI*(random()-.5)),p=b.actualState(b.ansatz(theta)).state,D=theta.map((_,i)=>{const t=theta.slice();t[i]+=Math.PI;return b.actualState(b.ansatz(t)).state.map(z=>[z[0]/2,z[1]/2]);}),projection=D.map(d=>inner(p,d)),G=D.map((a,i)=>D.map((bb,j)=>inner(a,bb)[0]-projection[i][0]*projection[j][0]-projection[i][1]*projection[j][1])),eig=n.symmetricEigen(G);
  if(eig.residual>1e-10||eig.values[0]<-1e-10)throw Error('State geometry reference failed');const active=eig.values.filter(x=>x>1e-10),row={index:k,parameters:theta,physical_tangent_rank:active.length,smallest_resolved_metric_eigenvalue:active[0]||0,largest_metric_eigenvalue:active.at(-1)||0,condition_on_resolved_directions:active.length?active.at(-1)/active[0]:null,eigenvalues:eig.values,residual:eig.residual};rows.push(row);
 }
 run.save('samples.json',rows);run.save('summary.json',{owner:'Sherman G. Laing',samples:rows.length,zero_parameter_rank:rows[0].physical_tangent_rank,random_sample_rank_counts:rows.slice(1).reduce((s,r)=>(s[r.physical_tangent_rank]=(s[r.physical_tangent_rank]||0)+1,s),{}),maximum_possible_physical_rank:14,interpretation:'Local tangent rank measures nearby controllable state directions. It is not proof of global expressivity or optimizer convergence.',signature:'UNSIGNED'});run.finish();
}catch(e){run.fail(e);}
