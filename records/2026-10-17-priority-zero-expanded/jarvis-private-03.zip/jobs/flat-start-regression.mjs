import {createRun,read,modules} from '../numerics/runtime-v5.mjs';
const run=createRun(process.argv[2]),batch=Number(process.argv[3]);
try {
  const {cg,c,b,a,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json');
  if(!Number.isInteger(batch)||batch<0||batch>=4)throw Error('Invalid flat-start batch');
  run.save('contract.json',{...cfg,batch,full_design:'Eight computational-basis targets by eight computational-basis initial states; 64 cases. Plain BFGS is compared with the pre-existing three-start conditioned method.'});
  run.save('containment.json',containment);const scores=[];
  for(let index=batch*16;index<batch*16+16;index++) {
    const target=Math.floor(index/8),initialBasis=index%8;
    const H=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>[i===j&&i!==target?1:0,0]));
    const initial=Array(18).fill(0);for(let q=0;q<3;q++)if(initialBasis&(1<<(2-q)))initial[12+2*q]=Math.PI;
    const first=b.actualState(b.ansatz(initial)).state;
    if(Math.abs(first[initialBasis][0]**2+first[initialBasis][1]**2-1)>2e-10)throw Error('Basis initialization incorrect');
    const plain=c.refineBFGS(H,initial,cfg.method.fit);
    const corrected=cg.conditionedRefine(H,initial,cfg.method,2026092041+index);
    run.save('case_'+String(index).padStart(2,'0')+'_prediction.json',{index,target,initial_basis:initialBasis,initial_parameters:initial,plain,corrected});
    const grade=p=>{
      const diag=c.stateDiagnostics(H,p.parameters),state=p.amplitudes,norm=state.reduce((s,z)=>s+z[0]**2+z[1]**2,0);
      const fidelity=(state[target][0]**2+state[target][1]**2)/norm;
      const measurement={energy_error_ev:diag.energy_ev,fidelity,norm_error:Math.abs(norm-1),amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,reference_verified:true};
      return {measurement,assessment:a.assessState(measurement)};
    };
    const before=grade(plain),after=grade(corrected);
    const row={index,target,initial_basis:initialBasis,plain:before,corrected:after,plain_stop:plain.reason,plain_iterations:plain.iterations,corrected_fit_starts:corrected.normalized_prediction.fit_starts};
    scores.push(row);run.save('case_'+String(index).padStart(2,'0')+'_score.json',row);
    run.log('flat_start_scored',{index,target,initial_basis:initialBasis,plain_fidelity:before.measurement.fidelity,plain_stop:plain.reason,corrected_fidelity:after.measurement.fidelity,corrected_accepted:after.assessment.accepted,starts:row.corrected_fit_starts.length});
  }
  run.save('scores.json',scores);
  run.save('summary.json',{owner:'Sherman G. Laing',batch,cases:scores.length,plain_accepted:scores.filter(x=>x.plain.assessment.accepted).length,corrected_accepted:scores.filter(x=>x.corrected.assessment.accepted).length,plain_zero_iteration_failures:scores.filter(x=>!x.plain.assessment.accepted&&x.plain_iterations===0).length,remaining_misses:scores.filter(x=>!x.corrected.assessment.accepted),signature:'UNSIGNED'});
  run.finish();
} catch(e){run.fail(e);}
