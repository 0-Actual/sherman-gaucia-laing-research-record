// Sequential controller v2: identical completion policy with verified snapshot reuse.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
import {completionGate} from './work-guard-v2.mjs';import {openLedger,mirroredArtifact} from './work-ledger-v2.mjs';
const root=path.dirname(path.dirname(fileURLToPath(import.meta.url))),mirror=root.toLowerCase().startsWith('d:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_03':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_03',roots=[root,mirror],contract=JSON.parse(fs.readFileSync(path.join(root,'WORK_CONTRACT.json'),'utf8'));
mirroredArtifact(roots,'WORK_CONTRACT.json');const ledger=openLedger(roots,contract),lock=path.join(root,'CONTROLLER.lock');
const status=(extra={},snapshot=null)=>{const record={at_utc:new Date().toISOString(),pid:process.pid,...completionGate(contract,(snapshot||ledger.read()).state,Date.now()),...extra};const bytes=JSON.stringify(record,null,2)+'\n';for(const r of roots)fs.writeFileSync(path.join(r,'LIVE_STATUS.json'),bytes);return record;};
async function job(spec,known){
 if(!/^[a-z0-9_-]{1,60}$/.test(spec.id)||!/^jobs\/[a-z0-9_-]+\.mjs$/.test(spec.script))throw Error('Invalid job scope');
 const source=mirroredArtifact(roots,spec.script);if(spec.source_identity!==source.identity)throw Error('JOB_SOURCE_IDENTITY_MISMATCH');
 const args=spec.args||[];if(!Array.isArray(args)||args.some(x=>typeof x!=='string'||x.length>500))throw Error('Invalid arguments');
 if(known?.status==='FINISHED')return;if(known&&known.status!=='PENDING')throw Error('Partial job requires inspection');
 const events=[];if(!known)events.push({type:'JOB_REGISTERED',data:{id:spec.id,purpose:spec.purpose,source:source.identity}});events.push({type:'JOB_STARTED',data:{id:spec.id}});
 status({active_job:spec.id},ledger.appendMany(events));
 const start=performance.now();
 await new Promise((resolve,reject)=>{
  const child=spawn(process.execPath,['--max-old-space-size='+contract.job_heap_mb,'--permission',...roots.map(r=>'--allow-fs-read='+r),...roots.map(r=>'--allow-fs-write='+r),'--experimental-vm-modules',path.join(root,spec.script),...args],{cwd:root,env:{SystemRoot:process.env.SystemRoot,WINDIR:process.env.WINDIR,PATH:path.dirname(process.execPath)},windowsHide:true,stdio:['ignore','pipe','pipe']});
  try{os.setPriority(child.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);}catch(e){console.error('Priority unchanged: '+e);}
  const timer=setTimeout(()=>child.kill(),contract.job_timeout_ms),pulse=setInterval(()=>status({active_job:spec.id,child_pid:child.pid}),10000);
  for(const [s,n] of [[child.stdout,'stdout'],[child.stderr,'stderr']])s.on('data',b=>{for(const r of roots)fs.appendFileSync(path.join(r,'runs',spec.id+'_'+n+'.log'),b);process[n].write(b);});
  child.on('error',e=>{clearTimeout(timer);clearInterval(pulse);reject(e);});child.on('close',(code,signal)=>{clearTimeout(timer);clearInterval(pulse);code===0?resolve():reject(Error('Child exit '+code+' '+signal));});
 });
 const artifacts=(spec.outputs||[]).map(rel=>mirroredArtifact(roots,rel));if(!artifacts.length)throw Error('Declared output required');
 const finished=ledger.appendMany([{type:'JOB_FINISHED',data:{id:spec.id,exit_code:0,bytes_verified:true,elapsed_ms:performance.now()-start,artifacts}},{type:'CHECKPOINT',data:{evidence:artifacts[0].path}}]);status({},finished);
}
let pulseTimer=null,previousTick=performance.now();
try{
 fs.writeFileSync(lock,JSON.stringify({pid:process.pid,started_utc:new Date().toISOString()}),{flag:'wx'});
 pulseTimer=setInterval(()=>{const now=performance.now(),delta=now-previousTick;previousTick=now;try{const snapshot=delta>65000?ledger.append('INTERRUPTED',{error:'Controller heartbeat gap; elapsed continuity cannot be assumed'}):ledger.append('SESSION_PROGRESS',{elapsed_ms:delta});status({},snapshot);}catch(e){console.error(e);process.exitCode=1;}},30000);
 console.log('Controller v2 active. Original work window and completion policy retained.');
 while(true){
  const snapshot=ledger.read(),state=snapshot.state,gate=status({},snapshot);
  if(state.owner_pause){console.log('Explicit owner pause recorded.');break;}
  if(state.interrupted){console.error('BLOCKED: intervention required; task is not complete.');process.exitCode=2;break;}
  const queued=fs.readdirSync(path.join(root,'queue')).filter(n=>n.endsWith('.json')).sort().map(n=>{mirroredArtifact(roots,'queue/'+n);return JSON.parse(fs.readFileSync(path.join(root,'queue',n),'utf8'));}).filter(s=>state.jobs[s.id]?.status!=='FINISHED');
  if(queued.length){try{await job(queued[0],state.jobs[queued[0].id]);}catch(e){const active=ledger.read().state.jobs[queued[0].id];if(active?.status==='RUNNING')ledger.append('JOB_FAILED',{id:queued[0].id,error:String(e)});else ledger.append('INTERRUPTED',{error:String(e)});throw e;}continue;}
  if(gate.can_prepare_final_handoff){console.log('READY_FOR_CHAT_REPORT. No automatic completion or chat delivery claimed.');break;}
  await new Promise(resolve=>setTimeout(resolve,5000));
 }
}catch(e){console.error(e);try{status({error:String(e),task_complete:false});}catch{}process.exitCode=1;}
finally{if(pulseTimer)clearInterval(pulseTimer);if(fs.existsSync(lock)){const owned=JSON.parse(fs.readFileSync(lock,'utf8'));if(owned.pid===process.pid)fs.unlinkSync(lock);}}
