// Publish complete queue descriptors atomically on each drive, exposing the primary last.
import fs from 'node:fs';
import path from 'node:path';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
let sequence=0;
export function publishQueue(roots,filename,spec,{observe=()=>{}}={}) {
  if(roots.length!==2||!/^\d{3}_[a-z0-9_-]+\.json$/.test(filename)||!/^jobs\/[a-z0-9_-]+\.mjs$/.test(spec.script)||!/^[a-z0-9_-]{1,60}$/.test(spec.id))throw Error('Invalid queue publication scope');
  if(typeof spec.purpose!=='string'||spec.purpose.length<20||!Array.isArray(spec.args)||spec.args.some(x=>typeof x!=='string'||x.length>500))throw Error('Invalid job description');
  if(!Array.isArray(spec.outputs)||!spec.outputs.length||spec.outputs.some(x=>typeof x!=='string'||!x||x.includes('..')||x.includes(':')||path.isAbsolute(x)))throw Error('Unsafe output scope');
  const source=roots.map(r=>fs.readFileSync(path.join(r,spec.script)));
  if(!source[0].equals(source[1])||hashBytes(source[0],'qel-work-artifact')!==spec.source_identity)throw Error('Queue source identity mismatch');
  const bytes=Buffer.from(JSON.stringify(spec,null,2)+'\n'),dest=roots.map(r=>path.join(r,'queue',filename)),lock=path.join(roots[0],'queue','.publisher-lock');
  fs.mkdirSync(lock);
  const suffix='.'+process.pid+'.'+Date.now()+'.'+sequence+++'.tmp',temporary=dest.map(x=>x+suffix);
  try {
    fs.writeFileSync(path.join(lock,'owner.json'),JSON.stringify({pid:process.pid}),{flag:'wx'});
    for(const name of fs.readdirSync(path.join(roots[0],'queue')).filter(x=>x.endsWith('.json')))if(name!==filename&&JSON.parse(fs.readFileSync(path.join(roots[0],'queue',name))).id===spec.id)throw Error('Duplicate queued job id');
    const have=dest.map(x=>fs.existsSync(x));
    for(let i=0;i<2;i++)if(have[i]&&!fs.readFileSync(dest[i]).equals(bytes))throw Error('Refusing to replace published descriptor');
    if(have[0]&&!have[1])throw Error('Primary descriptor has no mirror; inspection required');
    if(have[0]&&have[1])return {published:true,already_present:true,id:spec.id};
    for(let i=0;i<2;i++)if(!have[i]) {
      const fd=fs.openSync(temporary[i],'wx');try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}
      if(!fs.readFileSync(temporary[i]).equals(bytes))throw Error('Staged queue readback mismatch');
    }
    observe('staged',{destinations:dest.slice()});
    if(!have[1])fs.renameSync(temporary[1],dest[1]);
    observe('mirror_committed',{destinations:dest.slice()});
    fs.renameSync(temporary[0],dest[0]);
    observe('primary_committed',{destinations:dest.slice()});
    return {published:true,already_present:false,recovered_mirror_only:have[1],id:spec.id};
  } finally {
    for(const file of temporary)if(fs.existsSync(file))fs.unlinkSync(file);
    fs.rmSync(lock,{recursive:true});
  }
}
