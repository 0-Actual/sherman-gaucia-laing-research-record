import fs from 'node:fs';
import path from 'node:path';
import {publishQueue} from './queue-publisher.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export function checkQueuePublication(productionRoots) {
  const tag='publication_'+Date.now(),roots=productionRoots.map(r=>path.join(r,'tests',tag)),checks=[];
  for(const r of roots){fs.mkdirSync(path.join(r,'jobs'),{recursive:true});fs.mkdirSync(path.join(r,'queue'));fs.writeFileSync(path.join(r,'jobs/probe.mjs'),'// isolated publication fixture\n',{flag:'wx'});}
  const base={id:'fixture',purpose:'Isolated descriptor publication and fault-recovery test.',script:'jobs/probe.mjs',source_identity:hashBytes(fs.readFileSync(path.join(roots[0],'jobs/probe.mjs')),'qel-work-artifact'),args:['fixture'],outputs:['runs/fixture/summary.json']};
  const check=(name,ok,details={})=>checks.push({name,passed:!!ok,...details});
  const rejects=fn=>{try{fn();return false;}catch{return true;}};
  const dest=roots.map(r=>path.join(r,'queue/001_fixture.json'));
  publishQueue(roots,'001_fixture.json',base,{observe:(stage,{destinations})=>{
    if(stage==='staged')check('primary_invisible_while_staged',!fs.existsSync(destinations[0]));
    if(stage==='mirror_committed')check('primary_invisible_until_mirror_complete',!fs.existsSync(destinations[0])&&JSON.parse(fs.readFileSync(destinations[1])).id==='fixture');
    if(stage==='primary_committed')check('visible_primary_is_complete_and_mirrored',fs.readFileSync(destinations[0]).equals(fs.readFileSync(destinations[1]))&&JSON.parse(fs.readFileSync(destinations[0])).id==='fixture');
  }});
  check('idempotent_publication',publishQueue(roots,'001_fixture.json',base).already_present);
  check('published_descriptor_cannot_be_replaced',rejects(()=>publishQueue(roots,'001_fixture.json',{...base,purpose:base.purpose+' changed'})));
  check('duplicate_job_id_rejected',rejects(()=>publishQueue(roots,'002_duplicate.json',base)));
  check('wrong_source_identity_rejected',rejects(()=>publishQueue(roots,'003_badsource.json',{...base,id:'badsource',source_identity:'incorrect'})));
  check('unsafe_output_rejected',rejects(()=>publishQueue(roots,'004_badoutput.json',{...base,id:'badoutput',outputs:['../outside']})));
  check('unsafe_filename_rejected',rejects(()=>publishQueue(roots,'../005_escape.json',{...base,id:'escape'})));
  const interrupted={...base,id:'interrupted'},interruptedDest=roots.map(r=>path.join(r,'queue/006_interrupted.json'));
  const injected=rejects(()=>publishQueue(roots,'006_interrupted.json',interrupted,{observe:stage=>{if(stage==='mirror_committed')throw Error('Injected interruption after USB commit');}}));
  check('interrupted_publication_not_visible_to_controller',injected&&!fs.existsSync(interruptedDest[0])&&fs.existsSync(interruptedDest[1]));
  const recovery=publishQueue(roots,'006_interrupted.json',interrupted);
  check('mirror_only_publication_recovers',recovery.recovered_mirror_only&&fs.readFileSync(interruptedDest[0]).equals(fs.readFileSync(interruptedDest[1])));
  const lock=path.join(roots[0],'queue','.publisher-lock');fs.mkdirSync(lock);
  check('existing_publisher_lock_refuses_write',rejects(()=>publishQueue(roots,'007_locked.json',{...base,id:'locked'})));
  fs.rmdirSync(lock);
  const saved=fs.readFileSync(dest[1]);fs.unlinkSync(dest[1]);
  check('primary_without_mirror_fails_closed',rejects(()=>publishQueue(roots,'001_fixture.json',base)));
  fs.writeFileSync(dest[1],saved,{flag:'wx'});
  const source=path.join(roots[1],'jobs/probe.mjs'),original=fs.readFileSync(source);fs.writeFileSync(source,'// deliberately different fixture source\n');
  check('mismatched_source_mirror_rejected',rejects(()=>publishQueue(roots,'008_source_mismatch.json',{...base,id:'source_mismatch'})));
  fs.writeFileSync(source,original);
  let reentrantBlocked=false;
  publishQueue(roots,'009_outer.json',{...base,id:'outer'},{observe:stage=>{if(stage==='staged')reentrantBlocked=rejects(()=>publishQueue(roots,'010_inner.json',{...base,id:'inner'}));}});
  check('reentrant_publisher_cannot_remove_owner_lock',reentrantBlocked&&fs.existsSync(path.join(roots[0],'queue/009_outer.json'))&&!fs.existsSync(path.join(roots[0],'queue/010_inner.json')));
  return {owner:'Sherman G. Laing',recorded_utc:new Date().toISOString(),checks:checks.length,passed:checks.filter(x=>x.passed).length,all_passed:checks.every(x=>x.passed),results:checks,fixture_roots:roots,scope:'File publication and injected interruption tests; no claim of power-loss durability, hardware write-once storage, or global assistant control.',signature:'UNSIGNED'};
}
