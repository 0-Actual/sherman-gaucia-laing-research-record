import {createRun,read,modules,overlap} from '../numerics/runtime-v3.mjs';
const run=createRun(process.argv[2]),batch=Number(process.argv[3]);
try {
  const {g,n,c,b,containment}=await modules();
  const cfg=read('inputs/BRACKETED_CONTRACT.json');
  const matrices=read('runs/independent_inputs/matrices.json');
  const cases=read('runs/independent_inputs/cases.json').slice(batch*12,batch*12+12);
  if(!Number.isInteger(batch)||batch<0||batch>=4||cases.length!==12)throw Error('Invalid independent batch');
  run.save('contract.json',{...cfg,case_indices:cases.map(x=>x.index),initialization:'Fresh random parameters; targets were generated independently of the ansatz.'});
  run.save('containment.json',containment);const scores=[];
  for(const item of cases) {
    const m=matrices[item.matrix],random=b.rng(item.seed);
    const initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
    const started=performance.now(),p=g.bracketedRefine(m.H,initial,cfg.method,(item.seed+101)>>>0);
    const elapsed=performance.now()-started;
    run.save('case_'+String(item.index).padStart(3,'0')+'_prediction.json',{case:item,initial_parameters:initial,prediction:p});
    const degeneracy=m.gap_ev===0?2:1,diag=c.stateDiagnostics(m.H,p.parameters);
    let fidelity=0,targetFidelity=0;
    for(let k=0;k<degeneracy;k++){fidelity+=overlap(m.known_columns[k],p.amplitudes);targetFidelity+=overlap(m.known_columns[k],p.target.amplitudes);}
    const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=m.H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);}));
    const ref=n.symmetricEigen(A),vector=p.amplitudes.map(z=>z[0]).concat(p.amplitudes.map(z=>z[1]));
    const independentFidelity=ref.vectors.slice(0,2*degeneracy).reduce((s,v)=>s+v.reduce((a,x,i)=>a+x*vector[i],0)**2,0);
    const values=[fidelity,targetFidelity,independentFidelity,p.energy_ev,p.norm,diag.max_amplitude_error,diag.dense_energy_error_ev];
    if(!values.every(Number.isFinite)||Math.abs(p.norm-1)>2e-10||diag.max_amplitude_error>2e-10||diag.dense_energy_error_ev>1e-9||ref.residual>1e-9||Math.abs(fidelity-independentFidelity)>1e-8||p.energy_ev<-1e-8)throw Error('Independent holdout correctness failure');
    const row={...item,fidelity,independent_fidelity:independentFidelity,target_fidelity:targetFidelity,target_fit:p.target_fit_fidelity,fidelity_pass:fidelity>=cfg.fidelity_goal,energy_error_ev:p.energy_ev,energy_pass:p.energy_ev<=cfg.energy_goal_ev,correctness:true,residual_ev:p.residual_ev,fit_starts:p.fit_starts,diagnosis:fidelity>=cfg.fidelity_goal?'passes':targetFidelity<cfg.fidelity_goal?'target_refinement_miss':'circuit_fit_miss'};
    scores.push(row);run.save('case_'+String(item.index).padStart(3,'0')+'_score.json',row);
    run.save('case_'+String(item.index).padStart(3,'0')+'_timing.json',{elapsed_ms:elapsed,scope:'Classical target plus Q8 fitting from fresh parameters'});
    run.log('independent_holdout_scored',{index:item.index,gap_ev:item.gap_ev,fidelity,energy_error_ev:row.energy_error_ev,diagnosis:row.diagnosis});
  }
  run.save('scores.json',scores);
  run.save('summary.json',{owner:'Sherman G. Laing',batch,cases:scores.length,fidelity_passes:scores.filter(x=>x.fidelity_pass).length,energy_passes:scores.filter(x=>x.energy_pass).length,correctness_passes:scores.length,misses:scores.filter(x=>!x.fidelity_pass||!x.energy_pass),signature:'UNSIGNED'});
  run.finish();
} catch(e){run.fail(e);}
