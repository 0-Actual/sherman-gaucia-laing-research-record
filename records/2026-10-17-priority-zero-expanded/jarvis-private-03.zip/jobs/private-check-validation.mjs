import fs from 'node:fs';
import path from 'node:path';
import {createRun,read,root,mirror,overlap} from '../numerics/runtime-v6.mjs';
import {solvePrivateCheck} from './private-check-core.mjs';
const label=process.argv[2],run=createRun(label);
try {
  const cases=[{kpoint:[0,0,0],seed:2026092053},{kpoint:[0.2,0.4,0.6],seed:2026092054},{kpoint:[0.123,0.456,0.789],seed:2026092055},{kpoint:[1.2,-1.6,2.6],seed:2026092054}],results=[],checks=[];
  const check=(name,passed,details={})=>{checks.push({name,passed,...details});if(!passed)throw Error('Private command validation failed: '+name);};
  run.save('contract.json',{owner:'Sherman G. Laing',cases,purpose:'Validate the numerical core shared by the private command, replay the pilot exactly, test periodic coordinates, and reject invalid inputs before writing a run.'});
  for(let i=0;i<cases.length;i++) {
    const item=cases[i],result=await solvePrivateCheck({label:label+'_case_'+i,...item});
    results.push(result);check('accepted_case_'+i,result.accepted,{fidelity:result.measurement.fidelity,energy_error_ev:result.measurement.energy_error_ev});run.log('private_core_case_passed',{case:i,fidelity:result.measurement.fidelity});
  }
  const pilot=read('runs/jarvis_grid_pilot_01/case_000_prediction.json'),first=read('runs/'+label+'_case_0/prediction.json');
  check('pilot_prediction_reproduced_exactly',JSON.stringify(pilot.prediction)===JSON.stringify(first.prediction)&&JSON.stringify(pilot.initial_parameters)===JSON.stringify(first.initial_parameters));
  const a=read('runs/'+label+'_case_1/prediction.json').prediction,b=read('runs/'+label+'_case_3/prediction.json').prediction,periodicOverlap=overlap(a.amplitudes,b.amplitudes);
  check('periodic_coordinate_state_agreement',periodicOverlap>=1-1e-7&&Math.abs(a.energy_ev-b.energy_ev)<=1e-9,{fidelity:periodicOverlap,energy_difference_ev:Math.abs(a.energy_ev-b.energy_ev)});
  const invalid=[{kpoint:[0,0],seed:1},{kpoint:[NaN,0,0],seed:1},{kpoint:[Infinity,0,0],seed:1},{kpoint:[0,0,0],seed:-1}];
  for(let i=0;i<invalid.length;i++) {
    const name='invalid_private_check_'+i;let rejected=false;
    try{await solvePrivateCheck({label:name,...invalid[i]});}catch{rejected=true;}
    check('invalid_input_rejected_before_run_'+i,rejected&&!fs.existsSync(path.join(root,'runs',name))&&!fs.existsSync(path.join(mirror,'runs',name)));
  }
  run.save('checks.json',checks);run.save('summary.json',{owner:'Sherman G. Laing',checks:checks.length,passed:checks.filter(x=>x.passed).length,all_passed:checks.every(x=>x.passed),cases:results,signature:'UNSIGNED'});run.finish();
} catch(error){run.fail(error);}
