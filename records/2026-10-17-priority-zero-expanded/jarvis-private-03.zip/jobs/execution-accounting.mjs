import fs from 'node:fs';
import path from 'node:path';
import {createRun,read,root} from '../numerics/runtime-v5.mjs';
const label=process.argv[2],run=createRun(label);
try {
  const names=fs.readdirSync(path.join(root,'runs'),{withFileTypes:true}).filter(x=>x.isDirectory()&&x.name!==label&&fs.existsSync(path.join(root,'runs',x.name,'execution.json'))).map(x=>x.name).sort();
  const records=names.map(name=>({name,...read('runs/'+name+'/execution.json')})),byName=new Map(records.map(x=>[x.name,x])),nested=new Map();
  for(const parent of records) {
    const summaryPath=path.join(root,'runs',parent.name,'summary.json');if(!fs.existsSync(summaryPath))continue;
    const summary=JSON.parse(fs.readFileSync(summaryPath));
    if(!Array.isArray(summary.cases))continue;
    for(const item of summary.cases)if(item&&typeof item.label==='string'&&item.label!==parent.name&&byName.has(item.label)) {
      const child=byName.get(item.label),contained=Date.parse(child.started_utc)>=Date.parse(parent.started_utc)&&Date.parse(child.finished_utc)<=Date.parse(parent.finished_utc);
      if(!contained)throw Error('Nested run interval outside declared parent');
      if(nested.has(child.name)&&nested.get(child.name)!==parent.name)throw Error('Ambiguous nested run accounting');
      nested.set(child.name,parent.name);
    }
  }
  const exclusive=records.filter(x=>!nested.has(x.name));
  const intervals=exclusive.map(x=>[Date.parse(x.started_utc),Date.parse(x.finished_utc)]).sort((a,b)=>a[0]-b[0]);
  if(intervals.some(([start,end])=>!Number.isFinite(start)||!Number.isFinite(end)||end<start))throw Error('Invalid execution interval');
  let union=0,lastStart=null,lastEnd=null,totalClock=0;
  for(const [start,end] of intervals){totalClock+=end-start;if(lastStart===null){lastStart=start;lastEnd=end;}else if(start<=lastEnd)lastEnd=Math.max(lastEnd,end);else{union+=lastEnd-lastStart;lastStart=start;lastEnd=end;}}
  if(lastStart!==null)union+=lastEnd-lastStart;
  const overlap=totalClock-union;if(overlap>2)throw Error('Unexpected overlapping top-level numerical runs');
  const sum=(items,get)=>items.reduce((s,x)=>s+get(x),0);
  const summary={owner:'Sherman G. Laing',signature:'UNSIGNED',as_of_utc:new Date().toISOString(),recorded_run_directories:records.length,top_level_runs:exclusive.length,nested_runs_excluded_from_sums:nested.size,top_level_run_wall_ms:sum(exclusive,x=>x.elapsed_ms),top_level_process_cpu_microseconds:{user:sum(exclusive,x=>x.cpu_microseconds.user),system:sum(exclusive,x=>x.cpu_microseconds.system)},top_level_timestamp_union_ms:union,top_level_timestamp_overlap_ms:overlap,maximum_sampled_rss_bytes:Math.max(...records.map(x=>x.sampled_maximum_rss_bytes)),raw_sum_of_all_run_wall_ms:sum(records,x=>x.elapsed_ms),nested_wall_ms_removed:sum(records.filter(x=>nested.has(x.name)),x=>x.elapsed_ms),interpretation:'Authoritative non-overlapping run accounting. A validation parent and its four internal solves share one process, so their child intervals and CPU samples are excluded from sums. Raw sums across every execution.json are nonexclusive and must not be called elapsed work or total CPU. This snapshot excludes its own accounting job, later evidence audits, unrecorded interactive analysis, and assistant-side computation.'};
  if(Math.abs(summary.raw_sum_of_all_run_wall_ms-summary.nested_wall_ms_removed-summary.top_level_run_wall_ms)>1e-5)throw Error('Execution accounting identity failed');
  run.save('summary.json',summary);run.save('nested_run_relationships.json',[...nested].map(([child,parent])=>({child,parent})));run.save('top_level_runs.json',exclusive);run.finish();
} catch(error){run.fail(error);}
