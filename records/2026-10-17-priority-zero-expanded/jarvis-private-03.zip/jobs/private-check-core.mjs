import fs from 'node:fs';
import path from 'node:path';
import {createRun,read,root,modules} from '../numerics/runtime-v6.mjs';
import {hashBytes} from '../control/vendor/sgl-prime.mjs';
export async function solvePrivateCheck({label,kpoint,seed=2026092053,onProgress=()=>{}}) {
  if(!/^[a-z0-9_-]{1,60}$/.test(label)||!Array.isArray(kpoint)||kpoint.length!==3||!kpoint.every(x=>Number.isFinite(x)&&Math.abs(x)<=1e6))throw Error('Provide three finite reciprocal coordinates with absolute values no greater than one million.');
  if(!Number.isSafeInteger(seed)||seed<0||seed>0xffffffff)throw Error('Seed must be an unsigned 32-bit integer.');
  const canonical=kpoint.map(x=>{const v=x%1;return v===0?0:v<0?v+1:v;}),run=createRun(label);
  try {
    const {cg,n,c,b,a,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json');
    const bytes=fs.readFileSync(path.join(root,'inputs/wannier90_hr.dat')),identity=hashBytes(bytes,'qel-jarvis-input');
    const blocks=b.parseWannier(bytes.toString('utf8')),built=b.constructH(blocks,canonical),H=built.h;
    const shifted=b.constructH(blocks,canonical.map((x,i)=>x+[1,-2,1][i])).h;
    const periodicityError=Math.max(...H.flatMap((row,i)=>row.map((z,j)=>Math.hypot(z[0]-shifted[i][j][0],z[1]-shifted[i][j][1]))));
    if(built.rawDefect>1e-8||periodicityError>1e-9)throw Error('Wannier reconstruction consistency failed.');
    run.save('contract.json',{owner:'Sherman G. Laing',signature:'UNSIGNED',kpoint_requested:kpoint,kpoint_periodic:canonical,seed,method:cfg,ground_degeneracy_tolerance_ev:1e-9,meaning:'Lowest eigenstate of the eight-orbital Wannier matrix; classical target solve and Q8 circuit fitting.'});
    run.save('input.json',{kpoint_requested:kpoint,kpoint_periodic:canonical,H,source_identity:identity,source_bytes:bytes.length,raw_hermiticity_defect:built.rawDefect,periodicity_error:periodicityError});
    run.save('containment.json',containment);onProgress('Matrix reconstructed. Solving and fitting the circuit.');
    const random=b.rng(seed),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
    const started=performance.now(),prediction=cg.conditionedRefine(H,initial,cfg.method,(seed+101)>>>0),solverMs=performance.now()-started;
    run.save('prediction.json',{initial_parameters:initial,prediction});
    const bands=b.jacobi(H),A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);}));
    const reference=n.symmetricEigen(A),degeneracy=bands.eigenvalues.filter(v=>v-bands.eigenvalues[0]<=1e-9).length;
    const vector=prediction.amplitudes.map(z=>z[0]).concat(prediction.amplitudes.map(z=>z[1]));
    const fidelity=reference.vectors.slice(0,2*degeneracy).reduce((s,col)=>s+col.reduce((t,x,i)=>t+x*vector[i],0)**2,0);
    const diag=c.stateDiagnostics(H,prediction.parameters),spectrumError=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(reference.values[2*j]+reference.values[2*j+1])/2)));
    const measurement={energy_error_ev:prediction.energy_ev-bands.eigenvalues[0],fidelity,norm_error:Math.abs(diag.norm-1),amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,reference_verified:reference.residual<=1e-9&&bands.residual<=1e-9&&spectrumError<=1e-9&&Math.abs(prediction.energy_ev-diag.energy_ev)<=1e-9};
    const assessment=a.assessState(measurement);
    const result={owner:'Sherman G. Laing',signature:'UNSIGNED',label,kpoint_requested:kpoint,kpoint_periodic:canonical,accepted:assessment.accepted,status:assessment.status,reasons:assessment.reasons,measurement,energy_ev:prediction.energy_ev,reference_energy_ev:bands.eigenvalues[0],ground_space_dimension:degeneracy,reference_residual:reference.residual,reference_spectrum_error:spectrumError,solver_elapsed_ms:solverMs,evidence_directory:path.join(root,'runs',label),interpretation:'An eight-state classical simulation with an explicit classical target solver. This is not a physical QPU result or a many-electron ground-state calculation.'};
    run.save('reference.json',{eigenvalues:bands.eigenvalues,real_eigenvectors:reference.vectors,ground_space_dimension:degeneracy,residual:reference.residual});
    run.save('summary.json',result);
    if(hashBytes(fs.readFileSync(path.join(root,'inputs/wannier90_hr.dat')),'qel-jarvis-input')!==identity)throw Error('Wannier source changed during the check.');
    run.finish();return result;
  } catch(error) {run.fail(error);throw error;}
}
