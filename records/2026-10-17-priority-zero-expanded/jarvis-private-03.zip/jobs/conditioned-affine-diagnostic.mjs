import {createRun,read,modules,overlap} from '../numerics/runtime-v4.mjs';
const run=createRun(process.argv[2]);
try {
  const {cg,n,c,b,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json');
  const matrices=read('runs/robustness_inputs/matrices.json'),old=read('runs/affine_target_diagnostic_01/scores.json');
  run.save('contract.json',{...cfg,scope:'Paired correction of all 45 affine target cases, plus actual Q8 fitting on the four failures and one control.'});
  run.save('containment.json',containment);const scores=[],circuitScores=[];
  for(const item of old) {
    const m=matrices.find(x=>x.family===0&&x.gap_ev===item.gap_ev),scale=item.scale,offset=item.offset_ev;
    const H=m.H.map((row,i)=>row.map((z,j)=>[scale*z[0]+(i===j?offset:0),scale*z[1]]));
    const p=cg.conditionedTarget(H,cfg.method);
    run.save('case_'+String(item.index).padStart(3,'0')+'_prediction.json',{case:item,prediction:p});
    const center=H.reduce((s,row,i)=>s+row[i][0],0)/8;
    const K=H.map((row,i)=>row.map((z,j)=>[(z[0]-(i===j?center:0))/scale,z[1]/scale]));
    const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=K[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);}));
    const ref=n.symmetricEigen(A);
    const grade=state=>{const v=state.map(z=>z[0]).concat(state.map(z=>z[1]));return ref.vectors.slice(0,2).reduce((s,q)=>s+q.reduce((a,x,i)=>a+x*v[i],0)**2,0);};
    const fidelity=grade(p.amplitudes),intended=overlap(m.known_columns[0],p.amplitudes);
    const referenceState=Array.from({length:8},(_,i)=>[ref.vectors[0][i],ref.vectors[0][i+8]]);
    const representedVsIntended=overlap(m.known_columns[0],referenceState);
    if(!Number.isFinite(fidelity)||ref.residual>1e-9)throw Error('Conditioned affine reference failure');
    const row={index:item.index,gap_ev:item.gap_ev,scale,offset_ev:offset,original_fidelity:item.represented_fidelity,conditioned_fidelity:fidelity,intended_fidelity:intended,represented_reference_vs_intended_fidelity:representedVsIntended,pass:fidelity>=cfg.fidelity_goal,normalization:p.normalization};
    scores.push(row);run.save('case_'+String(item.index).padStart(3,'0')+'_score.json',row);
    if(!item.pass||item.index===0) {
      const random=b.rng(2026092023+item.index),initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);
      const result=cg.conditionedRefine(H,initial,cfg.method,2026092027+item.index);
      run.save('case_'+String(item.index).padStart(3,'0')+'_circuit_prediction.json',{initial_parameters:initial,prediction:result});
      const diag=c.stateDiagnostics(H,result.parameters),actualFidelity=grade(result.amplitudes),tolerance=Math.max(1e-9,64*Number.EPSILON*Math.max(...H.flat().map(z=>Math.hypot(...z))));
      if(![actualFidelity,diag.norm,diag.max_amplitude_error,diag.dense_energy_error_ev].every(Number.isFinite)||Math.abs(diag.norm-1)>2e-10||diag.max_amplitude_error>2e-10||diag.dense_energy_error_ev>tolerance)throw Error('Conditioned Q8 fitting correctness failure');
      const circuit={index:item.index,represented_fidelity:actualFidelity,intended_fidelity:overlap(m.known_columns[0],result.amplitudes),target_fit:result.normalized_prediction.target_fit_fidelity,fidelity_pass:actualFidelity>=cfg.fidelity_goal,norm:diag.norm,amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,dense_energy_tolerance_ev:tolerance,correctness:true};
      circuitScores.push(circuit);run.save('case_'+String(item.index).padStart(3,'0')+'_circuit_score.json',circuit);
    }
  }
  run.save('scores.json',scores);run.save('circuit_scores.json',circuitScores);
  run.save('summary.json',{owner:'Sherman G. Laing',target_cases:scores.length,target_passes:scores.filter(x=>x.pass).length,target_misses:scores.filter(x=>!x.pass),circuit_cases:circuitScores.length,circuit_passes:circuitScores.filter(x=>x.fidelity_pass).length,circuit_misses:circuitScores.filter(x=>!x.fidelity_pass),input_representation_limits:scores.filter(x=>x.represented_reference_vs_intended_fidelity<cfg.fidelity_goal),signature:'UNSIGNED'});
  run.finish();run.log('conditioned_affine_complete',{target_passes:scores.filter(x=>x.pass).length,circuit_passes:circuitScores.filter(x=>x.fidelity_pass).length});
} catch(e){run.fail(e);}
