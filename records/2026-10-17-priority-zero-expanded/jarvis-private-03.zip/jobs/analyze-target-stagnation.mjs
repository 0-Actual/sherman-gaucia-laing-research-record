import {createRun,read,overlap} from '../numerics/runtime-v5.mjs';
const run=createRun(process.argv[2]);
try {
  const plan=read('inputs/ROBUSTNESS_PLAN.json'),matrices=read('runs/robustness_inputs/matrices.json'),rows=[],misses=[];
  for(let batch=0;batch<72;batch++) {
    const directory='runs/robustness_'+String(batch).padStart(3,'0');
    for(const score of read(directory+'/scores.json')) {
      const prediction=read(directory+'/case_'+String(score.index).padStart(4,'0')+'_prediction.json'),m=matrices[score.matrix],target=prediction.improved.target;
      let targetFidelity=overlap(m.known_columns[0],target.amplitudes);
      if(m.gap_ev===0)targetFidelity+=overlap(m.known_columns[1],target.amplitudes);
      const fit=prediction.improved.target_fit_fidelity;
      if(!Number.isFinite(targetFidelity)||!Number.isFinite(fit))throw Error('Invalid target diagnosis metric');
      const modes={};for(const step of target.history)modes[step.mode]=(modes[step.mode]||0)+1;
      const category=score.hybrid.fidelity_pass?'passes':targetFidelity<plan.fidelity_goal?'target_refinement_miss':fit<plan.fidelity_goal?'circuit_fitting_miss':'combined_small_errors';
      const lowerOnly=target.history.length>0&&target.history.every(x=>x.mode==='lower_bound_inverse'),firstShift=target.history[0]?.shift;
      const row={index:score.index,gap_ev:m.gap_ev,baseline_fidelity:score.baseline.fidelity,final_fidelity:score.hybrid.fidelity,target_fidelity:targetFidelity,circuit_target_fit:fit,energy_error_ev:score.hybrid.energy_error_ev,energy_pass:score.hybrid.energy_pass,category,target_iteration_modes:modes,all_lower_bound_fallback:lowerOnly,first_shift_ev:firstShift,two_level_amplitude_ratio_multiplier_per_fallback:lowerOnly&&firstShift<0?1+m.gap_ev/Math.abs(firstShift):null};
      rows.push(row);if(category!=='passes')misses.push(row);
    }
  }
  if(rows.length!==720||rows.some((x,i)=>x.index!==i))throw Error('Incomplete target diagnosis coverage');
  const categories={};for(const row of rows)categories[row.category]=(categories[row.category]||0)+1;
  const summary={owner:'Sherman G. Laing',cases:rows.length,categories,misses:misses.length,misses_with_accurate_target_fit:misses.filter(x=>x.circuit_target_fit>=plan.fidelity_goal).length,misses_with_only_lower_bound_fallback:misses.filter(x=>x.all_lower_bound_fallback).length,energy_only_false_acceptances:misses.filter(x=>x.energy_pass).length,first_example:misses[0]||null,mathematical_explanation:'In a two-level system with E0=0 and E1=Delta, inverse iteration at a negative shift multiplies the ground/excited amplitude ratio by 1+Delta/abs(shift). When Delta is tiny compared with the distance of the shift below zero, a few iterations make negligible progress. At the Rayleigh shift E=(1-F)*Delta, the ideal two-level ratio multiplier is F/(1-F), which favors the excited component when F<1/2; the monotonic safeguard then falls back. This is an explanatory two-level model, not a universal convergence proof.',applied_correction:'Bracket the lowest eigenvalue, shift just below that bracket, normalize the Hamiltonian against energy offsets, and retain independent ground-subspace fidelity as an acceptance criterion.',signature:'UNSIGNED'};
  run.save('summary.json',summary);run.save('diagnoses.json',rows);run.save('remaining_misses.json',misses);run.finish();
} catch(error){run.fail(error);}
