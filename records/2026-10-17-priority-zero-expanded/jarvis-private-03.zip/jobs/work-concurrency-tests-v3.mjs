import fs from 'node:fs';import path from 'node:path';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';import {openLedger} from './work-ledger-v2.mjs';
const self=fileURLToPath(import.meta.url),root=path.dirname(path.dirname(self)),mirror='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_03',c=JSON.parse(fs.readFileSync(path.join(root,'WORK_CONTRACT.json'),'utf8')),fixtures=[root,mirror].map(r=>path.join(r,'tests','concurrent-ledger-v3'));
if(process.argv[2]==='writer'){const j=openLedger(fixtures,c);for(let i=0;i<25;i++)j.append('CHECKPOINT',{evidence:process.argv[3]+'_'+i});}
else{
 for(const f of fixtures)fs.mkdirSync(path.join(f,'ledger'),{recursive:true});const journal=openLedger(fixtures,c);let reads=0,readError=null;
 const reader=setInterval(()=>{try{journal.read();reads++;}catch(e){readError=String(e);}},20);
 const launch=id=>new Promise((resolve,reject)=>{const ch=spawn(process.execPath,[self,'writer',id],{stdio:['ignore','pipe','pipe']});let stderr='';ch.stderr.on('data',b=>stderr+=b);ch.on('error',reject);ch.on('close',code=>code===0?resolve():reject(Error(stderr)));});
 try{await Promise.all([launch('a'),launch('b')]);}finally{clearInterval(reader);}
 const result=journal.read(),checks={concurrent_writes_preserved:result.count===50,unique_checkpoints:new Set(result.state.checkpoints).size===50,concurrent_reads_safe:readError===null,clock_order_preserved:result.state.clock_rollback===false,read_checks:reads};
 const lock=path.join(fixtures[0],'ledger','.writer-lock');fs.mkdirSync(lock);let refused=false;try{journal.read();}catch(e){refused=String(e).includes('LEDGER_BUSY_OR_STALE_LOCK');}finally{fs.rmdirSync(lock);}checks.stale_lock_refused=refused;
 const data={owner:c.owner,at_utc:new Date().toISOString(),checks,all_passed:Object.entries(checks).filter(([k])=>k!=='read_checks').every(([,v])=>v===true),signature:'UNSIGNED'};
 for(const r of [root,mirror])fs.writeFileSync(path.join(r,'reports/CONCURRENCY_TEST_RESULTS_V3.json'),JSON.stringify(data,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(data));if(!data.all_passed)process.exitCode=1;
}
