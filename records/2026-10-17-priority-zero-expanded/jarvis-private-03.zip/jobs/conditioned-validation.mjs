import {createRun,read,modules,overlap} from '../numerics/runtime-v5.mjs';
const run=createRun(process.argv[2]),start=Number(process.argv[3]),count=Number(process.argv[4]);
try {
  const {cg,n,c,b,a,containment}=await modules(),cfg=read('inputs/BRACKETED_CONTRACT.json');
  const regression=read('inputs/REGRESSION_CASES.json'),independent=read('runs/independent_inputs/cases.json'),matrices=read('runs/independent_inputs/matrices.json');
  if(!Number.isInteger(start)||!Number.isInteger(count)||start<0||count<1||count>12||start+count>120)throw Error('Invalid conditioned validation batch');
  run.save('contract.json',{...cfg,start,count,total_cases:120,scope:'72 saved regression states and 48 fresh starts on independently generated targets; centered solver and strict acceptance.'});
  run.save('containment.json',containment);const scores=[];
  for(let index=start;index<start+count;index++) {
    let H,initial,seed,degeneracy,known,source,sourceIndex,oldFidelity;
    if(index<72) {
      const m=regression[index];H=m.H;initial=m.parameters;seed=(20260920+index*7919)>>>0;degeneracy=m.ground_degeneracy;known=m.known_columns;source='saved_regression';sourceIndex=index;
      oldFidelity=read('runs/material_regression_'+String(Math.floor(index/9)).padStart(2,'0')+'/case_'+String(index).padStart(2,'0')+'_score.json').fidelity;
    } else {
      const item=independent[index-72],m=matrices[item.matrix],random=b.rng(item.seed);H=m.H;initial=Array.from({length:18},()=>2*Math.PI*random()-Math.PI);seed=(item.seed+101)>>>0;degeneracy=m.gap_ev===0?2:1;known=m.known_columns;source='independent_fresh';sourceIndex=item.index;
      oldFidelity=read('runs/independent_holdout_'+String(Math.floor(item.index/12)).padStart(2,'0')+'/case_'+String(item.index).padStart(3,'0')+'_score.json').fidelity;
    }
    const started=performance.now(),p=cg.conditionedRefine(H,initial,cfg.method,seed),elapsed=performance.now()-started;
    run.save('case_'+String(index).padStart(3,'0')+'_prediction.json',{index,source,source_index:sourceIndex,initial_parameters:initial,prediction:p});
    const A=Array.from({length:16},(_,i)=>Array.from({length:16},(_,j)=>{const z=H[i%8][j%8];return i<8?(j<8?z[0]:-z[1]):(j<8?z[1]:z[0]);}));
    const ref=n.symmetricEigen(A),bands=b.jacobi(H),diag=c.stateDiagnostics(H,p.parameters);
    const projection=state=>{const v=state.map(z=>z[0]).concat(state.map(z=>z[1]));return ref.vectors.slice(0,2*degeneracy).reduce((s,col)=>s+col.reduce((t,x,i)=>t+x*v[i],0)**2,0);};
    const fidelity=projection(p.amplitudes),targetFidelity=projection(p.normalized_prediction.target.amplitudes);
    const spectrumError=Math.max(...bands.eigenvalues.map((v,j)=>Math.abs(v-(ref.values[2*j]+ref.values[2*j+1])/2)));
    let knownFidelity=null;if(known){knownFidelity=known.slice(0,degeneracy).reduce((s,col)=>s+overlap(col,p.amplitudes),0);if(Math.abs(knownFidelity-fidelity)>1e-8)throw Error('Independent references disagree');}
    const measurement={energy_error_ev:p.energy_ev-bands.eigenvalues[0],fidelity,norm_error:Math.abs(diag.norm-1),amplitude_error:diag.max_amplitude_error,dense_energy_error_ev:diag.dense_energy_error_ev,reference_verified:ref.residual<=1e-9&&spectrumError<=1e-9};
    const assessment=a.assessState(measurement),row={index,source,source_index:sourceIndex,measurement,assessment,old_bracketed_fidelity:oldFidelity,target_fidelity:targetFidelity,target_fit:p.normalized_prediction.target_fit_fidelity,known_fidelity:knownFidelity,reference_residual:ref.residual,reference_spectrum_error:spectrumError};
    scores.push(row);run.save('case_'+String(index).padStart(3,'0')+'_score.json',row);run.save('case_'+String(index).padStart(3,'0')+'_timing.json',{elapsed_ms:elapsed,scope:source==='independent_fresh'?'Full conditioned solve and Q8 fit from fresh parameters':'Incremental conditioned solve and Q8 fit from saved parameters'});
    run.log('conditioned_validation_scored',{index,source,fidelity,accepted:assessment.accepted,reasons:assessment.reasons});
  }
  run.save('scores.json',scores);run.save('summary.json',{owner:'Sherman G. Laing',start,count,accepted:scores.filter(x=>x.assessment.accepted).length,misses:scores.filter(x=>!x.assessment.accepted),signature:'UNSIGNED'});run.finish();
} catch(e){run.fail(e);}
