import {createRun,read,modules,overlap} from '../numerics/runtime-v2.mjs';
const run=createRun(process.argv[2]);
try{
 const {h,c,b,containment}=await modules(),cfg=read('inputs/HYBRID_CONTRACT.json'),items=read('inputs/pass2_stress_inputs.json'),saved=read('inputs/pass2_synthetic_states.json'),scores=[];
 run.save('contract.json',cfg);run.save('containment.json',containment);
 for(const old of saved)for(const initial of old.prediction.starts){
  const item=items[old.index],p=h.hybridRefine(item.H,initial.parameters,cfg.method);
  run.save('case_'+old.index+'_start_'+initial.start+'_prediction.json',{index:old.index,start:initial.start,prediction:p});
  const diag=c.stateDiagnostics(item.H,p.parameters),ref=b.jacobi(item.H),error=p.energy_ev-ref.eigenvalues[0];
  let fidelity=overlap(item.known_columns[0],p.amplitudes),targetFidelity=overlap(item.known_columns[0],p.target.amplitudes);if(item.declared_gap_ev===0){fidelity+=overlap(item.known_columns[1],p.amplitudes);targetFidelity+=overlap(item.known_columns[1],p.target.amplitudes);}
  const correct=Math.abs(p.norm-1)<=2e-10&&diag.max_amplitude_error<=2e-10&&diag.dense_energy_error_ev<=1e-9&&error>=-1e-8;
  if(!correct)throw Error('Q8 state correctness failed');
  const row={index:old.index,start:initial.start,was_previous_selected_start:initial.start===old.prediction.best_start,gap_ev:item.declared_gap_ev,old_best_fidelity:old.score.ground_fidelity,fidelity,target_fidelity:targetFidelity,target_fit_fidelity:p.target_fit_fidelity,energy_error_ev:error,fidelity_pass:fidelity>=cfg.fidelity_goal,energy_pass:error<=cfg.energy_goal_ev,energy_increased:p.physical_energy_nondecreasing,correctness:correct,residual_ev:p.residual_ev,fit_rounds:p.fit_rounds};
  scores.push(row);run.save('case_'+old.index+'_start_'+initial.start+'_score.json',row);run.log('hybrid_case_scored',row);
 }
 const summary={owner:'Sherman G. Laing',starting_states:scores.length,correctness_passes:scores.filter(x=>x.correctness).length,fidelity_passes:scores.filter(x=>x.fidelity_pass).length,energy_passes:scores.filter(x=>x.energy_pass).length,prior_selected:scores.filter(x=>x.was_previous_selected_start),original_failed_selected:scores.filter(x=>[27,28].includes(x.index)&&x.was_previous_selected_start),signature:'UNSIGNED',method:'Explicit classical inverse refinement plus Q8 fitting; no quantum advantage claim'};run.save('scores.json',scores);run.save('summary.json',summary);run.finish();run.log('hybrid_complete',{fidelity_passes:summary.fidelity_passes,starting_states:summary.starting_states});
}catch(e){run.fail(e);}
