import fs from 'node:fs';import path from 'node:path';import {hashBytes} from './vendor/sgl-prime.mjs';import {initialState,applyEvent,validateContract} from './guard.mjs';
let ticketSequence=0;
function exclusive(root,fn){
 const base=path.join(root,'ledger'),requests=path.join(base,'.access-requests'),lock=path.join(base,'.writer-lock');
 fs.mkdirSync(requests,{recursive:true});
 const ticket=String(Date.now()).padStart(16,'0')+'_'+String(process.pid).padStart(10,'0')+'_'+String(ticketSequence++).padStart(10,'0')+'.json',mine=path.join(requests,ticket);
 fs.writeFileSync(mine,JSON.stringify({pid:process.pid}),{flag:'wx'});
 let acquired=false;
 try{
  const deadline=performance.now()+30000;
  while(performance.now()<deadline){
   if(fs.readdirSync(requests).filter(n=>n.endsWith('.json')).sort()[0]===ticket){try{fs.mkdirSync(lock);acquired=true;break;}catch(e){if(e.code!=='EEXIST')throw e;}}
   Atomics.wait(new Int32Array(new SharedArrayBuffer(4)),0,0,10);
  }
  if(!acquired)throw Error('LEDGER_BUSY_OR_STALE_LOCK_REQUIRES_INSPECTION');
  fs.writeFileSync(path.join(lock,'owner.json'),JSON.stringify({pid:process.pid,at_utc:new Date().toISOString()}),{flag:'wx'});
  return fn();
 }finally{if(acquired)fs.rmSync(lock,{recursive:true});fs.unlinkSync(mine);}
}
const names=dir=>fs.readdirSync(path.join(dir,'ledger')).filter(x=>/^\d{6}\.json$/.test(x)).sort();
export function openLedger(roots,contract){
 validateContract(contract);if(roots.length!==2)throw Error('Two local evidence destinations required');
 const contractIdentity=hashBytes(Buffer.from(JSON.stringify(contract)),'qel-work-contract');
 function readUnlocked(){
  const lists=roots.map(names);if(JSON.stringify(lists[0])!==JSON.stringify(lists[1]))throw Error('LEDGER_MIRROR_INCOMPLETE');
  let previous=null,state=initialState(contract,Date.parse(contract.recorded_utc));
  for(let i=0;i<lists[0].length;i++){
   const file=lists[0][i];if(file!==String(i+1).padStart(6,'0')+'.json')throw Error('LEDGER_SEQUENCE_GAP');
   const bytes=roots.map(r=>fs.readFileSync(path.join(r,'ledger',file)));if(!bytes[0].equals(bytes[1]))throw Error('LEDGER_MIRROR_MISMATCH');
   const item=JSON.parse(bytes[0]),identity=hashBytes(Buffer.from(JSON.stringify(item.payload)),'qel-work-event');
   if(identity!==item.identity||item.payload.previous!==previous||item.payload.contract!==contractIdentity)throw Error('LEDGER_CHAIN_OR_CONTRACT_MISMATCH');
   state=applyEvent(contract,state,item.payload.event);previous=identity;
  }
  return {state,previous,count:lists[0].length};
 }
 function appendUnlocked(type,data={},at=Date.now()){
  const current=readUnlocked(),event={type,data,at_ms:at};applyEvent(contract,current.state,event);
  const payload={sequence:current.count+1,previous:current.previous,contract:contractIdentity,event},identity=hashBytes(Buffer.from(JSON.stringify(payload)),'qel-work-event'),bytes=Buffer.from(JSON.stringify({payload,identity,signature:'UNSIGNED'},null,2)+'\n');
  const file=String(payload.sequence).padStart(6,'0')+'.json';
  for(const root of roots){const target=path.join(root,'ledger',file),fd=fs.openSync(target,'wx');try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}if(!fs.readFileSync(target).equals(bytes))throw Error('LEDGER_READBACK_FAILED');}
  return readUnlocked();
 }
 return {read:()=>exclusive(roots[0],readUnlocked),append:(type,data={},at)=>exclusive(roots[0],()=>appendUnlocked(type,data,at??Date.now()))};
}
export function mirroredArtifact(roots,relative){
 if(typeof relative!=='string'||relative.includes('..')||path.isAbsolute(relative)||relative.includes(':'))throw Error('Unsafe artifact path');
 const data=roots.map(r=>fs.readFileSync(path.join(r,relative)));if(!data[0].equals(data[1]))throw Error('ARTIFACT_MIRROR_MISMATCH');
 return {path:relative,bytes:data[0].length,identity:hashBytes(data[0],'qel-work-artifact')};
}

