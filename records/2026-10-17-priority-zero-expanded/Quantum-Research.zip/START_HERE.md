# QEL quantum research — owner review edition

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting consolidation: Codex.

This collection brings together the located quantum research, code evidence, history, corrections and reproduction boundaries. It forms part of the owner's broader public-history project, “stepping into the light.” No publication has been performed.

1. Read [the complete synthesis](CONSOLIDATED_QUANTUM_RESEARCH.md), or use [the listening edition](READ_ALOUD.md).
2. Follow [problem-to-code development chains](RESEARCH_DEVELOPMENT_CHAINS.md), then [the chronology](chronology/QUANTUM_SOURCE_CHRONOLOGY.md), [the full selected records](chronology/QUANTUM_RECORDS.md) and [proposed GitHub timeline additions](chronology/GITHUB_TIMELINE_GAP_LINKS.md). The [DFT materials-data study](materials-dataset-review/evidence/2026-09-18-jarvis-dft-2d/FULL_STUDY_UPDATE.md) is a separate related branch.
3. Inspect [the source collections](SOURCE_COLLECTIONS.md), [reproduction instructions](REPRODUCIBILITY.md) and [source notices](SOURCE_AND_LICENSE_NOTES.md).
4. Complete the owner checklist (outside the current public selection). Save review decisions outside this frozen folder so verification continues to detect changes.

The private companion preserves 12,153 selected source-file records across 19 collections. These include overlapping versions, archives, inputs, code, reports and receipts. They are not a count of research studies. The documentary edition selects 195 overlapping rows from six populations and retains four exact teaching passages.

The complete original interaction export remains unavailable. Missing original conversations, the B–D source-custody gap and some study artifacts are recorded explicitly. This package does not fill those gaps with invented transcript text. Private-source recovery and public redaction are separate issues. The new source archive is on the laptop; no new USB-copy verification is claimed.

The seven frozen documentary inputs included here make selection replay self-contained. Reproducing numerical studies requires restoring the private source collections and arranging their recorded dependencies. No scientific experiment was rerun during consolidation. Hashes support file identity, not independent certification or historical authorship.
