# Current public selection — October 18, 2026

This derivative contains the currently selected public documents and code. Some source documents remain outside this selection; earlier copies are retained privately. Public-reference corrections distinguish documents available in public repositories from retained internal sources. Counts and status in earlier dated documents describe their original review populations.

RELEASE_CONTENT_MANIFEST.json identifies every byte distributed in this archive. Earlier manifests and receipts are historical records and are not a claim that every original source is included. This packaging check does not establish scientific validity or a complete deployed application.
