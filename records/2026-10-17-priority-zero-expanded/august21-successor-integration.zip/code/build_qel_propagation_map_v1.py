#!/usr/bin/env python3
from __future__ import annotations
import json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
if str(HERE) not in sys.path: sys.path.insert(0,str(HERE))
import qel_qpu_emulator_kernel_v1 as qpu


def main():
    body={
      "schema":"qel.corrected-kernel-propagation-map/v1",
      "project":qpu.PROJECT,
      "owner_principal":qpu.OWNER,
      "current_kernel":"QEL-EMULATED-QPU-KERNEL-V1",
      "generation_a_suite":"QEL-GEN-A-QUANTUM-CAPABILITY-SUITE-RC1",
      "nodes":[
        {
          "work_id":"qel-emulator",
          "title":"QEL Emulator / Quantum Intelligence Emulator",
          "state":"CORRECTED_KERNEL_V1_INTEGRATED_INTERNAL_SIMULATION",
          "evidence":["21 Generation A capabilities","31 B-C-D migration routes","146 current adapter and historical-behavior tests"],
          "open":["exact B-C-D raw-source byte closure","owner acceptance","physical device/QPU execution"]
        },
        {
          "work_id":"qel-quantum-emulation-series",
          "title":"Quantum Emulation Algorithm Series",
          "state":"GENERATION_BOUND_ROUTING_COMPLETE",
          "evidence":["Generation A 21/21 corrected","B-C-D 31/31 routed","number-only identity prohibited"],
          "open":["exact B-C-D source relationships and supersession"]
        },
        {
          "work_id":"qel-qmath",
          "title":"QMath / Foundational Matrix Workspace",
          "state":"NEXT_ACTIVE_PROPAGATION_TARGET",
          "required":["adopt corrected QPU kernel API","audit matrix ladder dimensions and conditioning","bind units/assumptions/objectives","run independent regression"]
        },
        {
          "work_id":"qel-quantum-core",
          "title":"Quantum Core / Sherman G. Laing Dynamics",
          "state":"QUEUED_AFTER_QMATH",
          "required":["formalize observer-effect variables","separate analogy from physical quantum claim","map coherence/entropy/superposition to corrected metrics","run corrected-kernel tests"]
        },
        {
          "work_id":"qel-quantum-earth-emulator",
          "title":"Quantum Earth Emulator / QVC-Render",
          "state":"QUEUED_AFTER_QMATH_AND_QUANTUM_CORE",
          "required":["define render-state contracts","prevent visual overlays from being mislabeled as physical fields","integrate reproducible simulation receipts"]
        },
        {
          "work_id":"qel-98-work-register",
          "title":"Full QEL 98-Work Maturity and Dependency Register",
          "state":"REFRESH_AFTER_CORE_PROPAGATION",
          "required":["recompute maturity","record corrected descendants","retain unresolved source and deployment gates"]
        },
        {
          "work_id":"qel-first-sovereign-node",
          "title":"First Sovereign Device Node",
          "state":"NOT_TOUCHED_THIS_TURN",
          "authorization_required_later":True,
          "required":["device selection","install authorization","vault/key ceremony","negative-egress proof","restore/rollback drill"]
        }
      ],
      "next_operation":"MC-003E-QMATH-FOUNDATIONAL-MATRIX-INTEGRATION",
      "automatic_execution":False,
      "physical_qpu_execution_claimed":False
    }
    return qpu.integrity_receipt(body,"qel-corrected-kernel-propagation-map-v1")

if __name__=='__main__': print(json.dumps(main(),indent=2,sort_keys=True))
