#!/usr/bin/env python3
"""Generation-bound migration map for integrated QEL_Emulator B, C, and D.

This adapter never routes by algorithm number alone. Historical methods remain
preserved; the forward emulator uses corrected Generation A capabilities,
validated QPU primitives, or a separately identified non-quantum lane.
"""
from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Mapping

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
VENDOR_BCD = ROOT / "vendor" / "bcd"
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import qel_qpu_emulator_kernel_v1 as qpu

REGISTRY_PATH = VENDOR_BCD / "QEL_QUANTUM_INTEGRATED_GENERATION_REGISTRY_V1.json"
SCHEMA = "qel.bcd-emulator-migration/v1"


class MigrationError(ValueError):
    pass


@dataclass(frozen=True)
class MigrationRoute:
    record_id: str
    generation_id: str
    algorithm_number: int
    historical_title: str
    disposition: str
    forward_targets: tuple[str, ...]
    corrected_primitive: str | None
    non_quantum_lane: str | None
    rationale: str
    exact_source_bytes_pending: bool = True


def _route(record_id: str, generation_id: str, number: int, title: str, disposition: str,
           targets: tuple[str, ...] = (), primitive: str | None = None,
           lane: str | None = None, rationale: str = "") -> MigrationRoute:
    return MigrationRoute(record_id, generation_id, number, title, disposition, targets, primitive, lane, rationale)


# Explicit generation-bound routing. Number-only mapping is prohibited.
ROUTES: tuple[MigrationRoute, ...] = (
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-01", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 1, "State Encoding & Transition", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-01", "QCAP-GEN-A-20"), rationale="Use normalized encoding, validated unitary/Hermitian evolution, and stability receipts."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-02", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 2, "Synchronization Protocol", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-02", "QCAP-GEN-A-09"), rationale="Replace unconditional reset with explicit entanglement or phase synchronization target."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-03", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 3, "Environment Stabilization", "REQUIRE_INTENT_SELECTION", ("QCAP-GEN-A-17", "QCAP-GEN-A-21"), rationale="Noise reduction and target reinforcement are distinct; select by declared objective."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-04", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 4, "Energy Recycling", "MOVE_TO_NON_QUANTUM_LANE", ("QCAP-GEN-A-07",), lane="QEL_ENERGY_AND_RESOURCE_ACCOUNTING", rationale="Scalar 95% bookkeeping is not quantum energy optimization or physical energy recovery."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-05", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 5, "State Verification", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-01", "QCAP-GEN-A-05", "QCAP-GEN-A-20"), rationale="Use phase-invariant fidelity, norm/probability checks, and declared target/basis."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-06", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 6, "Imaginary Clamp", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-03", "QCAP-GEN-A-13"), rationale="Imaginary-part deletion is not correction; use a declared error model or coherence channel."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-07", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 7, "Data Security", "MOVE_TO_NON_QUANTUM_LANE", lane="SGL_PRIME_SECURITY_AND_KEY_MANAGEMENT", rationale="Random XOR masking is not encryption; use authenticated encryption and owner-controlled keys."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-08", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 8, "Purification", "REQUIRE_INTENT_SELECTION", ("QCAP-GEN-A-04", "QCAP-GEN-A-12"), rationale="Distinguish state recovery, reset, filtering, and entropy control."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-09", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 9, "Autonomous Evolution", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-05", "QCAP-GEN-A-09", "QCAP-GEN-A-20"), rationale="Use declared controller, subsystem map, objective, and stability metric."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-10", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 10, "Global Disclosure Protocol", "MOVE_TO_NON_QUANTUM_LANE", lane="QEL_APPEND_ONLY_DISCLOSURE_LEDGER", rationale="Disclosure requires authorization, durable provenance, privacy controls, and rollback."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-11", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 11, "Memory Integrity Manager", "MOVE_TO_NON_QUANTUM_LANE", lane="SGL_PRIME_QPRINT_INTEGRITY_AND_RECOVERY", rationale="Use SGL Prime identities, manifests, and verified recovery; do not destructively reset on a raw hash mismatch."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-12", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 12, "Enhanced Error Correction", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-03",), rationale="Use encoded logical state, syndrome, recovery map, and logical-fidelity benchmark."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-13", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 13, "Multi-Agent Collaboration", "MOVE_TO_NON_QUANTUM_LANE", lane="QEL_AGENT_GOVERNANCE_AND_CAUSAL_CONTRIBUTION", rationale="Global phase from summed signals is not collaboration; use governed roles and measurable causal outputs."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-14", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 14, "Entanglement Distribution", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-02", "QCAP-GEN-A-14"), primitive="prepare_ghz_state", rationale="Retain GHZ preparation; distribution requires a separate channel/noise/node model."),
    _route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-15", "GEN-B-INTEGRATED-QEL-EMULATOR-1-15", 15, "Resource Estimation", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-20",), primitive="resource_estimate", rationale="Use qubits, dimension, gates, depth, measurements, memory, runtime, and energy fields."),

    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-08", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 8, "Purification", "REQUIRE_INTENT_SELECTION", ("QCAP-GEN-A-04", "QCAP-GEN-A-12"), rationale="Behaviorally matches B-08; exact byte identity remains open."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-09", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 9, "Autonomous Evolution", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-05", "QCAP-GEN-A-09", "QCAP-GEN-A-20"), rationale="Behaviorally matches B-09; exact byte identity remains open."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-10", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 10, "Global Disclosure Protocol", "MOVE_TO_NON_QUANTUM_LANE", lane="QEL_APPEND_ONLY_DISCLOSURE_LEDGER", rationale="Behaviorally matches B-10; exact byte identity remains open."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-11", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 11, "Memory Integrity Manager", "MOVE_TO_NON_QUANTUM_LANE", lane="SGL_PRIME_QPRINT_INTEGRITY_AND_RECOVERY", rationale="Behaviorally matches B-11; exact byte identity remains open."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-12", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 12, "Enhanced Error Correction", "ROUTE_TO_CORRECTED_SUCCESSOR", ("QCAP-GEN-A-03",), rationale="Behaviorally matches B-12; exact byte identity remains open."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-13", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 13, "Multi-Agent Collaboration", "MOVE_TO_NON_QUANTUM_LANE", lane="QEL_AGENT_GOVERNANCE_AND_CAUSAL_CONTRIBUTION", rationale="Behaviorally matches B-13; exact byte identity remains open."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-14", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 14, "Entanglement Distribution", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-02", "QCAP-GEN-A-14"), primitive="prepare_ghz_state", rationale="Behaviorally matches B-14; preserve separate generation identity."),
    _route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-15", "GEN-C-INTEGRATED-QEL-EMULATOR-8-15", 15, "Resource Estimation", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-20",), primitive="resource_estimate", rationale="Behaviorally matches B-15; preserve separate generation identity."),

    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-16", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 16, "Adaptive Gate Placement", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-01", "QCAP-GEN-A-07", "QCAP-GEN-A-20"), primitive="adaptive_gate_placement", rationale="Apply validated unitary gates and select through an explicit objective."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 17, "Phase Gradient Imprinting", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-09",), primitive="phase_gradient", rationale="Retain as a basis-declared diagonal unitary primitive."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-18", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 18, "Multi-Basis Verification", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-16", "QCAP-GEN-A-20"), primitive="verify_in_bases", rationale="Require orthonormal bases and compute declared probabilities/observables."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-19", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 19, "Decoherence Simulation", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-13", "QCAP-GEN-A-17"), primitive="dephasing_channel", rationale="Use density matrices and a valid CPTP dephasing channel."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-20", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 20, "Partial Measurement", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-01",), primitive="measure_qubit", rationale="Support any declared qubit, normalized probabilities, seeded selective measurement, and validation."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-21", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 21, "Phase Kickback", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-01", "QCAP-GEN-A-09"), primitive="controlled_phase_kickback", rationale="Use a controlled relative-phase operation, not a global phase."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-22", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 22, "Nonlinear Dissipation", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-10", "QCAP-GEN-A-12", "QCAP-GEN-A-17"), primitive="amplitude_damping_channel", rationale="Replace nonlinear amplitude cubing with a linear CPTP channel under a declared model."),
    _route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-23", "GEN-D-INTEGRATED-QEL-EMULATOR-16-23", 23, "Reverse Computation", "ROUTE_TO_SAFE_PRIMITIVE", ("QCAP-GEN-A-01", "QCAP-GEN-A-20"), primitive="reverse_unitary_sequence", rationale="Apply stored adjoints in reverse order; measurements and noise remain irreversible boundaries."),
)

_BY_RECORD = {route.record_id: route for route in ROUTES}


def load_historical_registry() -> dict[str, Any]:
    return json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))


def resolve_route(record_id: str) -> MigrationRoute:
    text = str(record_id).strip()
    if text.isdigit():
        raise MigrationError("number-only identity is prohibited; use the full generation-bound record_id")
    try:
        return _BY_RECORD[text]
    except KeyError as exc:
        raise MigrationError(f"unknown generation-bound record: {record_id!r}") from exc


def run_primary_successor_benchmark(record_id: str) -> dict[str, Any]:
    route = resolve_route(record_id)
    if not route.forward_targets:
        raise MigrationError(f"record {record_id} belongs to non-quantum lane {route.non_quantum_lane}")
    return qpu.run_generation_a_capability(route.forward_targets[0])



def dispatch_generation_bound_record(
    record_id: str,
    *,
    forward_target: str | None = None,
    primitive_args: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Dispatch a historical generation-bound record through the governed layer.

    Ambiguous intent, non-quantum lanes, and primitive calls without explicit
    arguments fail closed. The returned execution receipt is SGL Prime identified.
    """
    route = resolve_route(record_id)
    if route.disposition == "MOVE_TO_NON_QUANTUM_LANE":
        raise MigrationError(
            f"record {record_id} belongs to non-quantum lane {route.non_quantum_lane}; "
            "use that lane's governed interface"
        )

    mode: str
    result: Any
    if primitive_args is not None:
        if not route.corrected_primitive:
            raise MigrationError(f"record {record_id} has no corrected primitive")
        primitive = getattr(qpu, route.corrected_primitive, None)
        if not callable(primitive):
            raise MigrationError(
                f"corrected primitive {route.corrected_primitive!r} is unavailable"
            )
        result = primitive(**dict(primitive_args))
        mode = "SAFE_PRIMITIVE"
    else:
        if forward_target is None:
            if route.corrected_primitive:
                raise MigrationError(
                    f"record {record_id} requires explicit primitive_args or a forward_target"
                )
            if len(route.forward_targets) != 1:
                raise MigrationError(
                    f"record {record_id} requires explicit intent selection from "
                    f"{list(route.forward_targets)}"
                )
            forward_target = route.forward_targets[0]
        if forward_target not in route.forward_targets:
            raise MigrationError(
                f"forward target {forward_target!r} is not authorized for {record_id}"
            )
        result = qpu.run_generation_a_capability(forward_target)
        mode = "CORRECTED_SUCCESSOR"

    body = {
        "schema": "qel.bcd-emulator-dispatch/v1",
        "route": route.__dict__,
        "execution_mode": mode,
        "selected_forward_target": forward_target,
        "result": result,
        "exact_historical_source_bytes_used": False,
        "automatic_execution": False,
        "physical_qpu_execution_claimed": False,
    }
    return qpu.integrity_receipt(
        body, f"qel-bcd-emulator-dispatch-{route.record_id}-v1"
    )

def migration_register() -> dict[str, Any]:
    historical = load_historical_registry()
    historical_ids = {record["record_id"] for record in historical["records"]}
    route_ids = set(_BY_RECORD)
    missing = sorted(historical_ids - route_ids)
    extra = sorted(route_ids - historical_ids)
    dispositions: dict[str, int] = {}
    for route in ROUTES:
        dispositions[route.disposition] = dispositions.get(route.disposition, 0) + 1
    body = {
        "schema": SCHEMA,
        "project": "Project Quantum.Earth.Laing / Q6.1",
        "owner_principal": "Sherman G. Laing",
        "historical_registry": REGISTRY_PATH.name,
        "historical_records": len(historical_ids),
        "migration_routes": len(ROUTES),
        "coverage_complete": not missing and not extra and len(ROUTES) == 31,
        "missing_record_ids": missing,
        "extra_record_ids": extra,
        "number_only_identity_prohibited": True,
        "exact_raw_source_byte_closure_complete": False,
        "dispositions": dispositions,
        "routes": [route.__dict__ for route in ROUTES],
        "claim_boundary": {
            "accepted": "GENERATION_BOUND_FORWARD_ROUTING_TO_CORRECTED_EMULATOR_KERNEL",
            "not_claimed": [
                "exact historical B-C-D source-byte closure",
                "silent supersession of historical artifacts",
                "physical QPU execution",
                "automatic external action",
                "owner-accepted signed release",
            ],
        },
        "automatic_execution": False,
    }
    return qpu.integrity_receipt(body, "qel-bcd-emulator-migration-register-v1")


if __name__ == "__main__":
    print(json.dumps(migration_register(), indent=2, sort_keys=True))
