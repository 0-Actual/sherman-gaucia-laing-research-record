#!/usr/bin/env python3
from __future__ import annotations

import json
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import qel_bcd_migration_adapter_v1 as migration
import qel_qpu_emulator_kernel_v1 as qpu


def caught(callable_):
    try:
        callable_()
    except Exception as exc:
        return {"blocked": True, "exception_type": type(exc).__name__, "message": str(exc)}
    return {"blocked": False}


def main() -> dict:
    explicit_successor = migration.dispatch_generation_bound_record(
        "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-03",
        forward_target="QCAP-GEN-A-17",
    )
    safe_primitive = migration.dispatch_generation_bound_record(
        "GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17",
        primitive_args={"state": [1, 0], "gradient_factor": 0.25},
    )
    body = {
        "schema": "qel.bcd-governed-dispatch-benchmark/v1",
        "project": qpu.PROJECT,
        "owner_principal": qpu.OWNER,
        "kernel_id": qpu.KERNEL_ID,
        "explicit_successor_dispatch": {
            "record_id": "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-03",
            "selected_target": "QCAP-GEN-A-17",
            "result_capability_id": explicit_successor["payload"]["result"]["capability"]["capability_id"],
            "receipt_identity": explicit_successor["primary_identity"],
        },
        "safe_primitive_dispatch": {
            "record_id": "GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17",
            "execution_mode": safe_primitive["payload"]["execution_mode"],
            "receipt_identity": safe_primitive["primary_identity"],
        },
        "fail_closed": {
            "number_only_identity": caught(lambda: migration.dispatch_generation_bound_record("17")),
            "ambiguous_intent": caught(lambda: migration.dispatch_generation_bound_record(
                "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-03"
            )),
            "non_quantum_lane": caught(lambda: migration.dispatch_generation_bound_record(
                "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-07"
            )),
            "primitive_without_arguments": caught(lambda: migration.dispatch_generation_bound_record(
                "GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17"
            )),
            "unauthorized_target": caught(lambda: migration.dispatch_generation_bound_record(
                "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-12",
                forward_target="QCAP-GEN-A-07",
            )),
        },
        "exact_historical_source_bytes_used": False,
        "physical_qpu_execution_claimed": False,
        "automatic_execution": False,
    }
    return qpu.integrity_receipt(body, "qel-bcd-governed-dispatch-benchmark-v1")


if __name__ == "__main__":
    print(json.dumps(main(), indent=2, sort_keys=True))
