#!/usr/bin/env python3
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import qel_bcd_migration_adapter_v1 as migration
import qel_qpu_emulator_kernel_v1 as qpu


def complex_list(a: np.ndarray) -> list[dict[str, float]]:
    return [{"real": float(x.real), "imag": float(x.imag)} for x in np.asarray(a).reshape(-1)]


def main() -> dict:
    x = np.array([[0, 1], [1, 0]], dtype=np.complex128)
    h = np.array([[1, 1], [1, -1]], dtype=np.complex128) / math.sqrt(2)
    z = np.array([[1, 0], [0, -1]], dtype=np.complex128)

    state00 = qpu.prepare_basis_state(2, 0)
    state11 = qpu.prepare_basis_state(2, 3)
    placement = qpu.adaptive_gate_placement(
        state00,
        state11,
        2,
        [qpu.GateCandidate("X0", x, 0), qpu.GateCandidate("X1", x, 1)],
    )

    uniform3 = qpu.prepare_uniform_state(3)
    gradient_state, gradient_u = qpu.phase_gradient(uniform3, 0.125)

    plus = h @ np.array([1, 0], dtype=np.complex128)
    bases = qpu.verify_in_bases(plus, {"Z": np.eye(2), "X": h})
    plus_rho = np.outer(plus, plus.conj())
    dephased = qpu.dephasing_channel(plus_rho, 0.3)

    bell = np.array([1, 0, 0, 1], dtype=np.complex128) / math.sqrt(2)
    measurement = qpu.measure_qubit(bell, 2, 1, draw=0.9)

    plus_plus = np.ones(4, dtype=np.complex128) / 2
    kicked, kick_u = qpu.controlled_phase_kickback(plus_plus, 2, 0, 1, math.pi)

    excited = np.array([[0, 0], [0, 1]], dtype=np.complex128)
    damped = qpu.amplitude_damping_channel(excited, 0.25)

    original = np.array([1, 0], dtype=np.complex128)
    forward = qpu.apply_unitary_sequence(original, [h, z, x])
    reversed_state = qpu.reverse_unitary_sequence(forward, [h, z, x])

    ghz4 = qpu.prepare_ghz_state(4)
    resources = qpu.resource_estimate(num_qubits=8, gate_count=100, depth=40, measurement_count=16)
    migration_receipt = migration.migration_register()

    raw = {
        "schema": "qel.emulated-qpu-integration-benchmark/v1",
        "project": qpu.PROJECT,
        "owner_principal": qpu.OWNER,
        "kernel_id": qpu.KERNEL_ID,
        "generation_a_suite_id": qpu.SUITE_ID,
        "generation_a_capabilities": len(qpu.suite_catalog()),
        "bcd_generation_bound_records": migration_receipt["payload"]["migration_routes"],
        "bcd_route_coverage_complete": migration_receipt["payload"]["coverage_complete"],
        "exact_bcd_source_byte_closure_complete": False,
        "corrected_primitives": {
            "D16_adaptive_gate_placement": {
                "initial_fidelity": placement.initial_fidelity,
                "final_fidelity": placement.final_fidelity,
                "applied": list(placement.applied),
                "evaluated_candidates": placement.evaluated_candidates,
                "final_state": complex_list(placement.final_state),
            },
            "D17_phase_gradient": {
                "state_norm": float(np.linalg.norm(gradient_state)),
                "probability_sum": qpu.probability_sum(gradient_state),
                "unitary": qpu.is_unitary(gradient_u),
                "last_to_first_phase": float(np.angle(gradient_state[-1] / gradient_state[0])),
            },
            "D18_multi_basis_verification": bases,
            "D19_decoherence_simulation": {
                "retention": 0.3,
                "off_diagonal_magnitude": float(abs(dephased[0, 1])),
                "trace": float(np.trace(dephased).real),
                "minimum_eigenvalue": float(np.min(np.linalg.eigvalsh(dephased))),
            },
            "D20_partial_measurement": {
                "outcome": measurement["outcome"],
                "probabilities": measurement["probabilities"],
                "post_state": complex_list(measurement["post_state"]),
                "post_probability_sum": measurement["post_probability_sum"],
            },
            "D21_phase_kickback": {
                "state_norm": float(np.linalg.norm(kicked)),
                "probability_sum": qpu.probability_sum(kicked),
                "fidelity_with_input": qpu.pure_fidelity(plus_plus, kicked),
                "unitary": qpu.is_unitary(kick_u),
                "final_state": complex_list(kicked),
            },
            "D22_valid_dissipation": {
                "gamma": 0.25,
                "ground_population": float(damped[0, 0].real),
                "excited_population": float(damped[1, 1].real),
                "trace": float(np.trace(damped).real),
            },
            "D23_reverse_computation": {
                "recovery_fidelity": qpu.pure_fidelity(original, reversed_state),
                "probability_sum": qpu.probability_sum(reversed_state),
            },
            "B14_GHZ_preparation": {
                "qubits": 4,
                "state_dimension": int(ghz4.size),
                "probability_sum": qpu.probability_sum(ghz4),
                "nonzero_indices": np.flatnonzero(np.abs(ghz4) > 1e-12).astype(int).tolist(),
            },
            "B15_resource_estimation": resources,
        },
        "claim_boundary": {
            "accepted": "QEL_EMULATED_QPU_KERNEL_AND_GENERATION_BOUND_MIGRATION_LAYER",
            "not_claimed": [
                "physical hardware QPU execution",
                "quantum advantage",
                "exact B-C-D source-byte closure",
                "owner-accepted signed release",
                "full QMath or Quantum Core propagation",
            ],
        },
        "automatic_execution": False,
    }
    return qpu.integrity_receipt(raw, "qel-emulated-qpu-integration-benchmark-v1")


if __name__ == "__main__":
    print(json.dumps(main(), indent=2, sort_keys=True))
