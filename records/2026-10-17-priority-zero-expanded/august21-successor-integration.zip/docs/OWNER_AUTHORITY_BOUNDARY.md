# Owner authority boundary

Sherman G. Laing's current instruction authorizes continued internal forensic revision, mathematical correction, code integration, testing, and QPRINT preservation.

No additional permission is required for the current QMath/Quantum Core propagation work.

A separate explicit command remains required before:

- generating or using private signing/encryption keys;
- public or external release;
- physical-device installation or permission changes;
- deletion or irreversible transformation of evidence;
- connection to physical QPU hardware or physical-QPU claims;
- any consequential external action.
