from __future__ import annotations

import math
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "code"
if str(CODE) not in sys.path:
    sys.path.insert(0, str(CODE))

import qel_qpu_emulator_kernel_v1 as qpu


class TestQPUKernelFoundation(unittest.TestCase):
    def test_catalog_has_21(self):
        catalog = qpu.suite_catalog()
        self.assertEqual(len(catalog), 21)
        self.assertEqual({x["number"] for x in catalog}, set(range(1, 22)))

    def test_kernel_manifest(self):
        result = qpu.kernel_manifest()
        self.assertEqual(result["payload"]["kernel_id"], qpu.KERNEL_ID)
        self.assertTrue(result["primary_identity"].startswith("sglp1:shake256-512:"))
        self.assertFalse(result["automatic_execution"])
        self.assertFalse(result["physical_qpu_execution_claimed"])

    def test_prepare_basis(self):
        state = qpu.prepare_basis_state(3, 5)
        self.assertEqual(state.shape, (8,))
        self.assertAlmostEqual(qpu.probability_sum(state), 1.0)
        self.assertEqual(int(np.argmax(np.abs(state))), 5)

    def test_prepare_uniform(self):
        state = qpu.prepare_uniform_state(3)
        self.assertAlmostEqual(qpu.probability_sum(state), 1.0)
        np.testing.assert_allclose(np.abs(state) ** 2, np.ones(8) / 8)

    def test_prepare_ghz(self):
        state = qpu.prepare_ghz_state(3)
        expected = np.zeros(8, dtype=np.complex128)
        expected[0] = expected[-1] = 1 / math.sqrt(2)
        self.assertAlmostEqual(qpu.pure_fidelity(state, expected), 1.0)

    def test_invalid_basis_index(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.prepare_basis_state(2, 4)

    def test_normalize_rejects_zero(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.normalize_state([0, 0])


class TestUnitaryAndGatePlacement(unittest.TestCase):
    def setUp(self):
        self.x = np.array([[0, 1], [1, 0]], dtype=np.complex128)
        self.h = np.array([[1, 1], [1, -1]], dtype=np.complex128) / math.sqrt(2)
        self.z = np.array([[1, 0], [0, -1]], dtype=np.complex128)

    def test_expand_single_qubit_gate_big_endian(self):
        u = qpu.expand_single_qubit_gate(self.x, 0, 2)
        state = qpu.apply_unitary(qpu.prepare_basis_state(2, 0), u)
        self.assertEqual(int(np.argmax(np.abs(state))), 2)

    def test_apply_and_reverse_sequence(self):
        state = qpu.prepare_basis_state(1, 0)
        forward = qpu.apply_unitary_sequence(state, [self.h, self.z, self.x])
        recovered = qpu.reverse_unitary_sequence(forward, [self.h, self.z, self.x])
        self.assertAlmostEqual(qpu.pure_fidelity(state, recovered), 1.0)

    def test_reject_nonunitary(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.apply_unitary([1, 0], [[1, 1], [0, 1]])

    def test_adaptive_gate_placement(self):
        state = qpu.prepare_basis_state(2, 0)
        target = qpu.prepare_basis_state(2, 3)
        candidates = [
            qpu.GateCandidate("X0", self.x, 0),
            qpu.GateCandidate("X1", self.x, 1),
        ]
        receipt = qpu.adaptive_gate_placement(state, target, 2, candidates)
        self.assertAlmostEqual(receipt.initial_fidelity, 0.0)
        self.assertAlmostEqual(receipt.final_fidelity, 1.0)
        self.assertEqual(len(receipt.applied), 2)
        self.assertAlmostEqual(qpu.probability_sum(receipt.final_state), 1.0)

    def test_adaptive_gate_does_not_apply_worse_candidate(self):
        state = qpu.prepare_basis_state(1, 0)
        target = state.copy()
        receipt = qpu.adaptive_gate_placement(
            state, target, 1, [qpu.GateCandidate("X", self.x, 0)]
        )
        self.assertEqual(len(receipt.applied), 0)
        self.assertAlmostEqual(receipt.final_fidelity, 1.0)


class TestCorrectedGenerationDPrimitives(unittest.TestCase):
    def setUp(self):
        self.h = np.array([[1, 1], [1, -1]], dtype=np.complex128) / math.sqrt(2)

    def test_phase_gradient(self):
        state = qpu.prepare_uniform_state(2)
        out, u = qpu.phase_gradient(state, 0.2)
        self.assertTrue(qpu.is_unitary(u))
        self.assertAlmostEqual(qpu.probability_sum(out), 1.0)
        phase_ratios = out / state
        np.testing.assert_allclose(phase_ratios, np.exp(1j * 0.2 * np.arange(4)))

    def test_verify_in_bases(self):
        plus = self.h @ np.array([1, 0], dtype=np.complex128)
        result = qpu.verify_in_bases(
            plus,
            {"Z": np.eye(2), "X": self.h},
        )
        np.testing.assert_allclose(result["Z"]["probabilities"], [0.5, 0.5], atol=1e-12)
        np.testing.assert_allclose(result["X"]["probabilities"], [1.0, 0.0], atol=1e-12)

    def test_verify_rejects_nonorthonormal_basis(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.verify_in_bases([1, 0], {"bad": [[1, 1], [0, 1]]})

    def test_dephasing_channel(self):
        plus = np.array([1, 1], dtype=np.complex128) / math.sqrt(2)
        rho = np.outer(plus, plus.conj())
        out = qpu.dephasing_channel(rho, 0.0)
        np.testing.assert_allclose(out, np.eye(2) / 2, atol=1e-12)

    def test_amplitude_damping(self):
        excited = np.array([[0, 0], [0, 1]], dtype=np.complex128)
        out = qpu.amplitude_damping_channel(excited, 1.0)
        np.testing.assert_allclose(out, np.array([[1, 0], [0, 0]], dtype=np.complex128), atol=1e-12)

    def test_measure_any_qubit_bell(self):
        bell = np.array([1, 0, 0, 1], dtype=np.complex128) / math.sqrt(2)
        result0 = qpu.measure_qubit(bell, 2, 1, draw=0.1)
        self.assertEqual(result0["outcome"], 0)
        np.testing.assert_allclose(result0["post_state"], [1, 0, 0, 0], atol=1e-12)
        result1 = qpu.measure_qubit(bell, 2, 1, draw=0.9)
        self.assertEqual(result1["outcome"], 1)
        np.testing.assert_allclose(result1["post_state"], [0, 0, 0, 1], atol=1e-12)

    def test_measure_second_of_product_state(self):
        state = np.array([0, 1, 0, 0], dtype=np.complex128)  # |01>
        result = qpu.measure_qubit(state, 2, 1, draw=0.5)
        self.assertEqual(result["outcome"], 1)
        self.assertAlmostEqual(result["probabilities"][1], 1.0)

    def test_controlled_relative_phase(self):
        plus_plus = np.ones(4, dtype=np.complex128) / 2
        out, u = qpu.controlled_phase_kickback(plus_plus, 2, 0, 1, math.pi)
        self.assertTrue(qpu.is_unitary(u))
        self.assertAlmostEqual(qpu.probability_sum(out), 1.0)
        np.testing.assert_allclose(out, [0.5, 0.5, 0.5, -0.5], atol=1e-12)
        self.assertLess(qpu.pure_fidelity(plus_plus, out), 1.0)

    def test_controlled_phase_rejects_same_qubit(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.controlled_phase_kickback([1, 0, 0, 0], 2, 0, 0, 0.3)


class TestResourceAndReceipts(unittest.TestCase):
    def test_resource_estimate(self):
        result = qpu.resource_estimate(num_qubits=5, gate_count=12, depth=7, measurement_count=4)
        self.assertEqual(result["state_dimension"], 32)
        self.assertEqual(result["statevector_bytes"], 512)
        self.assertEqual(result["density_matrix_bytes"], 16384)

    def test_resource_rejects_negative(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.resource_estimate(num_qubits=2, gate_count=-1)

    def test_integrity_receipt_deterministic(self):
        a = qpu.integrity_receipt({"x": 1, "y": 0.25}, "test-purpose")
        b = qpu.integrity_receipt({"y": 0.25, "x": 1}, "test-purpose")
        self.assertEqual(a["primary_identity"], b["primary_identity"])
        self.assertTrue(a["primary_identity"].startswith("sglp1:shake256-512:"))
        self.assertFalse(a["secondary_witness_authorization_allowed"])

    def test_run_generation_a_capability(self):
        result = qpu.run_generation_a_capability(1)
        self.assertEqual(result["capability"]["capability_id"], "QCAP-GEN-A-01")
        self.assertFalse(result["physical_qpu_execution_claimed"])


class TestFailClosedTypesAndReceipts(unittest.TestCase):
    def test_uniform_rejects_non_integer_qubit_count(self):
        for value in (True, 2.5, 0, -1):
            with self.subTest(value=value), self.assertRaises(qpu.QPUKernelError):
                qpu.prepare_uniform_state(value)

    def test_expand_rejects_invalid_num_qubits(self):
        x = np.array([[0, 1], [1, 0]], dtype=np.complex128)
        with self.assertRaises(qpu.QPUKernelError):
            qpu.expand_single_qubit_gate(x, 0, 1.5)

    def test_measure_rejects_invalid_num_qubits(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.measure_qubit([1, 0], True, 0, draw=0.1)

    def test_controlled_phase_rejects_non_integer_indices(self):
        with self.assertRaises(qpu.QPUKernelError):
            qpu.controlled_phase_kickback([1, 0, 0, 0], 2, 0.0, 1, 0.3)

    def test_adaptive_rejects_fractional_depth(self):
        x = np.array([[0, 1], [1, 0]], dtype=np.complex128)
        with self.assertRaises(qpu.QPUKernelError):
            qpu.adaptive_gate_placement(
                qpu.prepare_basis_state(1, 0),
                qpu.prepare_basis_state(1, 1),
                1,
                [qpu.GateCandidate("X", x, 0)],
                max_depth=0.5,
            )

    def test_integrity_receipt_accepts_canonicalized_arrays_and_complex(self):
        payload = {
            "array": np.array([1.25, 2.5]),
            "complex_array": np.array([1 + 2j, -0.5j]),
            "complex_scalar": 0.25 - 0.75j,
        }
        a = qpu.integrity_receipt(payload, "array-complex-test")
        b = qpu.integrity_receipt(payload, "array-complex-test")
        self.assertEqual(a["primary_identity"], b["primary_identity"])
        self.assertTrue(a["primary_identity"].startswith("sglp1:shake256-512:"))

    def test_manifest_describes_bounded_lookahead(self):
        manifest = qpu.kernel_manifest()
        primitives = manifest["payload"]["validated_primitives"]
        self.assertIn("bounded_lookahead_adaptive_gate_placement", primitives)
        self.assertNotIn("greedy_adaptive_gate_placement", primitives)


if __name__ == "__main__":
    unittest.main()
