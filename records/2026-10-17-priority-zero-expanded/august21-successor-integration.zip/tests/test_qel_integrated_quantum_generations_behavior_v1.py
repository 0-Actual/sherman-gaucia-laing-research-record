#!/usr/bin/env python3
"""Regression and forensic tests for integrated QEL_Emulator generations B-D."""
from __future__ import annotations

import math
import unittest

import numpy as np
from scipy.linalg import expm

import qel_integrated_quantum_generations_behavior_v1 as q


class Base(unittest.TestCase):
    def close(self, a, b, tol=1e-10):
        self.assertTrue(math.isclose(float(a), float(b), rel_tol=0.0, abs_tol=tol), (a, b))

    def array_close(self, a, b, tol=1e-10):
        self.assertTrue(np.allclose(a, b, atol=tol, rtol=tol), (a, b))


class TestHelpers(Base):
    def test_001_normalize(self):
        self.close(np.linalg.norm(q.normalize([1, 1j])), 1.0)

    def test_002_zero_rejected(self):
        with self.assertRaises(q.IntegratedBehaviorError):
            q.normalize([0, 0])

    def test_003_fidelity_global_phase(self):
        psi = q.normalize([1, 2j])
        self.close(q.fidelity_pure(psi, -psi), 1.0)

    def test_004_probability_sum(self):
        self.close(q.probability_sum(q.normalize([1, 1])), 1.0)

    def test_005_hermitian(self):
        self.assertTrue(q.is_hermitian([[1, 1j], [-1j, 2]]))

    def test_006_nonhermitian(self):
        self.assertFalse(q.is_hermitian([[0, 1], [0, 0]]))

    def test_007_unitary(self):
        self.assertTrue(q.is_unitary([[0, 1], [1, 0]]))

    def test_008_nonunitary(self):
        self.assertFalse(q.is_unitary([[2, 0], [0, 1]]))


class TestGenerationB(Base):
    def test_009_b1_hermitian_preserves_norm(self):
        out = q.gen_b_01_encoding_transition([1, 0], [[0, 1], [1, 0]], 0.7)
        self.close(np.linalg.norm(out), 1.0)

    def test_010_b1_nonhermitian_not_blocked(self):
        out = q.gen_b_01_encoding_transition([0, 1], [[0, 1], [0, 0]], 1.0)
        self.assertFalse(math.isclose(float(np.linalg.norm(out)), 1.0, abs_tol=1e-10))

    def test_011_b1_dimension_rejected_by_reconstruction(self):
        with self.assertRaises(q.IntegratedBehaviorError):
            q.gen_b_01_encoding_transition([1, 0], np.eye(4), 1.0)

    def test_012_b2_uniform_norm(self):
        out = q.gen_b_02_uniform_synchronization(3)
        self.close(np.linalg.norm(out), 1.0)

    def test_013_b2_resets_input_information(self):
        target = q.gen_b_02_uniform_synchronization(3)
        basis = np.zeros(8, complex); basis[0] = 1
        self.close(q.fidelity_pure(basis, target), 1/8)

    def test_014_b2_invalid_qubits(self):
        with self.assertRaises(q.IntegratedBehaviorError):
            q.gen_b_02_uniform_synchronization(0)

    def test_015_b3_below_threshold_preserves(self):
        psi = q.normalize([1, 1j])
        out, action = q.gen_b_03_environment_stabilization(psi, 0.005)
        self.array_close(out, psi)
        self.assertEqual(action, "Environment Stable")

    def test_016_b3_above_threshold_resets(self):
        psi = q.normalize([1, 1j])
        out, action = q.gen_b_03_environment_stabilization(psi, 0.02)
        self.array_close(out, [1, 0])
        self.assertEqual(action, "Environment Stabilized")

    def test_017_b3_reset_loses_state(self):
        psi = q.normalize([1, 1])
        out, _ = q.gen_b_03_environment_stabilization(psi, 1.0)
        self.close(q.fidelity_pure(psi, out), 0.5)

    def test_018_b4_recycled_95_percent(self):
        r = q.gen_b_04_energy_recycling([10, 20], 3)
        self.close(r["recycled_energy"], 28.5)
        self.close(r["unaccounted_difference"], 1.5)

    def test_019_b4_zero_qubits_raises(self):
        with self.assertRaises(ZeroDivisionError):
            q.gen_b_04_energy_recycling([1], 0)

    def test_020_b4_negative_energy_accepted(self):
        r = q.gen_b_04_energy_recycling([-10], 1)
        self.close(r["recycled_energy"], -9.5)

    def test_021_b5_uniform_verified(self):
        self.assertTrue(q.gen_b_05_state_verification([1/math.sqrt(2)]*2)["verified"])

    def test_022_b5_global_phase_false_negative(self):
        psi = -np.ones(4, complex)/2
        r = q.gen_b_05_state_verification(psi, tolerance=0.01)
        self.assertFalse(r["verified"])
        self.close(q.fidelity_pure(psi, np.ones(4)/2), 1.0)

    def test_023_b5_basis_state_not_uniform(self):
        self.assertFalse(q.gen_b_05_state_verification([1, 0, 0, 0])["verified"])

    def test_024_b6_clamps_imaginary(self):
        out, count = q.gen_b_06_imaginary_clamp([1/math.sqrt(2), 1j/math.sqrt(2)])
        self.assertEqual(count, 1)
        self.close(out[1].imag, 0.0)

    def test_025_b6_changes_norm(self):
        psi = q.normalize([1, 1j])
        out, _ = q.gen_b_06_imaginary_clamp(psi)
        self.assertLess(np.linalg.norm(out), 1.0)

    def test_026_b6_not_phase_error_correction(self):
        psi = np.array([1, 1j], complex)/math.sqrt(2)
        out, _ = q.gen_b_06_imaginary_clamp(psi)
        self.assertLess(q.fidelity_pure(psi, out), 1.0)

    def test_027_b7_length_mismatch(self):
        self.assertEqual(q.gen_b_07_xor_mask([1, 2], 3)["status"], "length_mismatch")

    def test_028_b7_mask_derivable_from_exposed_pair(self):
        r = q.gen_b_07_xor_mask([1, 2, 3], 3, seed=7)
        derived = [a ^ b for a, b in zip(r["original_data"], r["masked_data"])]
        self.assertEqual(derived, r["audit_masks"])

    def test_029_b7_seed_repeat(self):
        self.assertEqual(q.gen_b_07_xor_mask([1,2],2,seed=3), q.gen_b_07_xor_mask([1,2],2,seed=3))

    def test_030_b8_no_trigger_two_qubits(self):
        psi = np.array([1,0,0,0], complex)
        out, count = q.gen_b_08_purification(psi, 2)
        self.assertEqual(count, 0)
        self.array_close(out, psi)

    def test_031_b8_can_trigger_four_qubits(self):
        psi = np.zeros(16, complex); psi[0] = 1
        out, count = q.gen_b_08_purification(psi, 4)
        self.assertEqual(count, 1)
        self.close(out[0].real, 0.25)

    def test_032_b8_trigger_breaks_normalization(self):
        psi = np.zeros(16, complex); psi[0] = 1
        out, _ = q.gen_b_08_purification(psi, 4)
        self.close(np.linalg.norm(out), 0.25)

    def test_033_b9_three_qubits_leaves_remainder(self):
        psi = np.ones(8, complex)/math.sqrt(8)
        out, touched = q.gen_b_09_autonomous_evolution(psi, 3, [1,2,3])
        self.assertEqual(touched, list(range(6)))
        self.array_close(out[6:], psi[6:])

    def test_034_b9_preserves_norm(self):
        psi = q.normalize(np.arange(1,9)+1j*np.arange(8,0,-1))
        out, _ = q.gen_b_09_autonomous_evolution(psi, 3, [1,2,3])
        self.close(np.linalg.norm(out), 1.0)

    def test_035_b9_bad_feedback_no_change(self):
        psi = q.normalize([1,1,1,1])
        out, touched = q.gen_b_09_autonomous_evolution(psi,2,[1])
        self.array_close(out, psi); self.assertEqual(touched, [])

    def test_036_b10_log_only(self):
        self.assertEqual(q.gen_b_10_global_disclosure(["a"]), [{"anomaly":"a","status":"disclosed"}])

    def test_037_b10_empty(self):
        self.assertEqual(q.gen_b_10_global_disclosure([]), [])

    def test_038_b11_matching_hash_preserves(self):
        psi = q.normalize([1,1j])
        out, status = q.gen_b_11_memory_integrity(psi, q.state_sha256_historical(psi))
        self.array_close(out, psi); self.assertEqual(status, "verified")

    def test_039_b11_mismatch_resets(self):
        psi = q.normalize([1,1j])
        out, status = q.gen_b_11_memory_integrity(psi, "0"*64)
        self.array_close(out, [1,0]); self.assertEqual(status, "reset")

    def test_040_b11_global_phase_hash_differs(self):
        psi = q.normalize([1,1j])
        self.assertNotEqual(q.state_sha256_historical(psi), q.state_sha256_historical(-psi))
        self.close(q.fidelity_pure(psi, -psi), 1.0)

    def test_041_b12_can_break_normalization(self):
        psi = np.array([math.sqrt(.7), math.sqrt(.1), math.sqrt(.1), math.sqrt(.1)], complex)
        out, count = q.gen_b_12_enhanced_error_correction(psi,2,threshold=.2)
        self.assertEqual(count,1)
        self.assertFalse(math.isclose(float(np.linalg.norm(out)),1.0,abs_tol=1e-10))

    def test_042_b12_uniform_unchanged(self):
        psi = np.ones(4,complex)/2
        out, count = q.gen_b_12_enhanced_error_correction(psi,2)
        self.array_close(out,psi); self.assertEqual(count,0)

    def test_043_b12_no_syndrome(self):
        # Behavior is magnitude clamping, evidenced by phase retention.
        psi = np.array([1j,0,0,0],complex)
        out, _ = q.gen_b_12_enhanced_error_correction(psi,2)
        self.close(np.angle(out[0]), math.pi/2)

    def test_044_b13_is_global_phase(self):
        psi = q.normalize([1,2j])
        out = q.gen_b_13_multi_agent(psi,[1,2,3])
        self.close(q.fidelity_pure(psi,out),1.0)

    def test_045_b13_norm_preserved(self):
        psi=q.normalize([1,2j]); self.close(np.linalg.norm(q.gen_b_13_multi_agent(psi,[99])),1.0)

    def test_046_b13_signals_collapse_to_sum(self):
        psi=q.normalize([1,1j])
        self.array_close(q.gen_b_13_multi_agent(psi,[1,2]), q.gen_b_13_multi_agent(psi,[3]))

    def test_047_b14_ghz_norm(self):
        self.close(np.linalg.norm(q.gen_b_14_entanglement_distribution(3)),1.0)

    def test_048_b14_one_qubit_not_entanglement(self):
        self.array_close(q.gen_b_14_entanglement_distribution(1), [1/math.sqrt(2)]*2)

    def test_049_b14_replaces_prior_state(self):
        ghz=q.gen_b_14_entanglement_distribution(2)
        self.close(q.fidelity_pure([1,0,0,0],ghz),0.5)

    def test_050_b15_basis_cost_one(self):
        self.close(q.gen_b_15_resource_estimation([1,0,0,0])["resource_cost"],1.0)

    def test_051_b15_uniform_cost_dimension(self):
        self.close(q.gen_b_15_resource_estimation(np.ones(8)/math.sqrt(8))["resource_cost"],8.0)

    def test_052_b15_basis_dependence(self):
        self.assertNotEqual(q.gen_b_15_resource_estimation([1,0])["resource_cost"], q.gen_b_15_resource_estimation([1,1])["resource_cost"])


class TestGenerationC(Base):
    def test_053_c8_behavior_alias(self):
        psi=np.zeros(16,complex); psi[0]=1
        self.array_close(q.gen_c_08_purification(psi,4)[0], q.gen_b_08_purification(psi,4)[0])

    def test_054_c9_behavior_alias(self):
        psi=np.ones(8,complex)/math.sqrt(8)
        self.array_close(q.gen_c_09_autonomous_evolution(psi,3,[1,2,3])[0], q.gen_b_09_autonomous_evolution(psi,3,[1,2,3])[0])

    def test_055_c10_behavior_alias(self):
        self.assertEqual(q.gen_c_10_global_disclosure([1]), q.gen_b_10_global_disclosure([1]))

    def test_056_c11_behavior_alias(self):
        psi=q.normalize([1,1j]); h=q.state_sha256_historical(psi)
        self.array_close(q.gen_c_11_memory_integrity(psi,h)[0], q.gen_b_11_memory_integrity(psi,h)[0])

    def test_057_c12_behavior_alias(self):
        psi=np.ones(4)/2
        self.array_close(q.gen_c_12_enhanced_error_correction(psi,2)[0], q.gen_b_12_enhanced_error_correction(psi,2)[0])

    def test_058_c13_behavior_alias(self):
        psi=q.normalize([1,1j])
        self.array_close(q.gen_c_13_multi_agent(psi,[1]), q.gen_b_13_multi_agent(psi,[1]))

    def test_059_c14_behavior_alias(self):
        self.array_close(q.gen_c_14_entanglement_distribution(3), q.gen_b_14_entanglement_distribution(3))

    def test_060_c15_behavior_alias(self):
        self.assertEqual(q.gen_c_15_resource_estimation([1,0]), q.gen_b_15_resource_estimation([1,0]))


class TestGenerationD(Base):
    def test_061_d16_empty_gate_division(self):
        with self.assertRaises(ZeroDivisionError):
            q.gen_d_16_adaptive_gate_placement([1,0],[])

    def test_062_d16_only_gate_00_real_used(self):
        psi=np.ones(4,complex)/2
        gate=np.array([[0.25+9j,99,88,77],[0,1,0,0],[0,0,1,0],[0,0,0,1]],complex)
        out,ops=q.gen_d_16_adaptive_gate_placement(psi,[gate])
        self.close(ops[0]["factor"],0.25)
        self.close(np.linalg.norm(out),0.25)

    def test_063_d16_previous_gate_overwritten(self):
        psi=np.ones(4,complex)/2
        g1=np.eye(4); g1[0,0]=0.5
        g2=np.eye(4); g2[0,0]=0.25
        out,ops=q.gen_d_16_adaptive_gate_placement(psi,[g1,g2])
        # A true sequential application would retain both modifications; historical output restarts from psi.
        self.assertEqual(len(ops),2)
        self.assertTrue(np.any(np.isclose(out,psi)))

    def test_064_d16_invalid_shape_becomes_noop_factor(self):
        psi=np.ones(4,complex)/2
        out,ops=q.gen_d_16_adaptive_gate_placement(psi,[np.eye(2)])
        self.close(ops[0]["factor"],1.0)
        self.array_close(out,psi)

    def test_065_d17_preserves_norm(self):
        psi=q.normalize([1,2,3,4])
        self.close(np.linalg.norm(q.gen_d_17_phase_gradient(psi,.2)),1.0)

    def test_066_d17_zero_gradient_no_change(self):
        psi=q.normalize([1,2j]); self.array_close(q.gen_d_17_phase_gradient(psi,0),psi)

    def test_067_d17_phase_pattern(self):
        psi=np.ones(4,complex)/2
        out=q.gen_d_17_phase_gradient(psi,0.1)
        self.close(np.angle(out[3]/out[0]),0.3)

    def test_068_d18_shape_only_accepts_nonunitary(self):
        log=q.gen_d_18_multi_basis_verification([1,0], [[[2,0],[0,1]]])
        self.assertEqual(log[0]["status"],"ok")
        self.assertFalse(q.is_unitary([[2,0],[0,1]]))

    def test_069_d18_rejects_bad_shape(self):
        self.assertEqual(q.gen_d_18_multi_basis_verification([1,0], [np.eye(3)])[0]["status"],"failed")

    def test_070_d19_norm_loss(self):
        psi=q.normalize([1,1j]); out=q.gen_d_19_decoherence_simulation(psi,.1)
        self.close(np.linalg.norm(out),.9)

    def test_071_d19_normalized_ray_unchanged(self):
        psi=q.normalize([1,1j]); out=q.gen_d_19_decoherence_simulation(psi,.1)
        self.close(q.fidelity_pure(psi,out),1.0)

    def test_072_d19_not_decoherence_after_renorm(self):
        psi=q.normalize([1,1]); rho=q.density_matrix(psi)
        out=q.gen_d_19_decoherence_simulation(psi,.5)
        self.close(q.l1_coherence(q.density_matrix(out)), q.l1_coherence(rho))

    def test_073_d19_rate_one_zero_state(self):
        out=q.gen_d_19_decoherence_simulation([1,0],1.0)
        self.close(np.linalg.norm(out),0.0)

    def test_074_d20_qubit0_probabilities(self):
        psi=np.array([1,0,0,1],complex)/math.sqrt(2)
        out,outcome,status=q.gen_d_20_partial_measurement(psi,2,0,draw=.25)
        self.assertEqual((outcome,status),(0,"measured_qubit_0"))
        self.close(np.linalg.norm(out),1.0)

    def test_075_d20_nonzero_qubit_not_implemented(self):
        psi=np.array([1,0,0,1],complex)/math.sqrt(2)
        out,outcome,status=q.gen_d_20_partial_measurement(psi,2,1,draw=.2)
        self.assertIsNone(outcome); self.assertEqual(status,"not_implemented_for_nonzero_qubit")
        self.array_close(out,psi)

    def test_076_d20_correct_comparator_qubit1(self):
        psi=np.array([1,1,0,0],complex)/math.sqrt(2)
        p0, p1 = q.correct_partial_measurement_probabilities(psi,2,1)
        self.close(p0,0.5); self.close(p1,0.5)

    def test_077_d20_unnormalized_probabilities_fail(self):
        with self.assertRaises(q.IntegratedBehaviorError):
            q.gen_d_20_partial_measurement([2,0],1,0,draw=.1)

    def test_078_d21_uses_halves_even_for_control1(self):
        psi=np.array([0,0,1,0],complex)
        out,status=q.gen_d_21_phase_kickback(psi,2,1,.7)
        self.assertEqual(status,"global_phase_applied")
        self.close(q.fidelity_pure(psi,out),1.0)

    def test_079_d21_global_phase_no_physical_change(self):
        psi=q.normalize([1,2j,3,4j])
        out,status=q.gen_d_21_phase_kickback(psi,2,0,.4)
        if status=="global_phase_applied": self.close(q.fidelity_pure(psi,out),1.0)
        else: self.array_close(out,psi)

    def test_080_d21_invalid_control(self):
        psi=np.array([1,0],complex)
        out,status=q.gen_d_21_phase_kickback(psi,1,2,.5)
        self.assertEqual(status,"invalid_control"); self.array_close(out,psi)

    def test_081_d22_not_norm_preserving(self):
        psi=np.ones(2,complex)/math.sqrt(2)
        out=q.gen_d_22_nonlinear_dissipation(psi,.02)
        self.assertFalse(math.isclose(float(np.linalg.norm(out)),1.0,abs_tol=1e-10))

    def test_082_d22_rate_one_zero(self):
        self.close(np.linalg.norm(q.gen_d_22_nonlinear_dissipation([1,0],1.0)),0.0)

    def test_083_d22_nonlinear_scaling(self):
        a=q.gen_d_22_nonlinear_dissipation([1,0],0)
        b=q.gen_d_22_nonlinear_dissipation([2,0],0)
        self.close(abs(b[0]/a[0]),8.0)

    def test_084_d23_involution(self):
        psi=q.normalize([1,2j]); self.array_close(q.gen_d_23_reverse_computation(q.gen_d_23_reverse_computation(psi)),psi)

    def test_085_d23_not_general_inverse(self):
        h=np.array([[1,1],[1,-1]],complex)/math.sqrt(2)
        s=np.diag([1,1j])
        u=s@h
        initial=np.array([1,0],complex)
        evolved=u@initial
        naive=q.gen_d_23_reverse_computation(evolved)
        correct=q.reverse_known_unitary(evolved,u)
        self.close(q.fidelity_pure(initial,correct),1.0)
        self.assertLess(q.fidelity_pure(initial,naive),1.0)

    def test_086_correct_dephasing_reduces_coherence(self):
        psi=np.array([1,1],complex)/math.sqrt(2)
        rho=q.density_matrix(psi)
        self.close(q.l1_coherence(q.corrected_dephasing_density(rho,.5)),.5)

    def test_087_summary_counts(self):
        s=q.GenerationAuditSummary()
        self.assertEqual((s.generation_b_records,s.generation_c_records,s.generation_d_records),(15,8,8))
        self.assertEqual(s.total_registered_records,52)


if __name__ == '__main__':
    unittest.main(verbosity=2)
