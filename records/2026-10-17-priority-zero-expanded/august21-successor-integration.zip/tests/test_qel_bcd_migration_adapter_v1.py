from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
CODE = ROOT / "code"
if str(CODE) not in sys.path:
    sys.path.insert(0, str(CODE))

import qel_bcd_migration_adapter_v1 as migration
import qel_qpu_emulator_kernel_v1 as qpu


class TestMigrationCoverage(unittest.TestCase):
    def test_registry_has_31_records(self):
        registry = migration.load_historical_registry()
        self.assertEqual(len(registry["records"]), 31)

    def test_routes_cover_every_record_exactly(self):
        registry_ids = {r["record_id"] for r in migration.load_historical_registry()["records"]}
        route_ids = {r.record_id for r in migration.ROUTES}
        self.assertEqual(registry_ids, route_ids)
        self.assertEqual(len(route_ids), 31)

    def test_migration_register_complete(self):
        receipt = migration.migration_register()
        body = receipt["payload"]
        self.assertTrue(body["coverage_complete"])
        self.assertEqual(body["historical_records"], 31)
        self.assertEqual(body["migration_routes"], 31)
        self.assertFalse(body["exact_raw_source_byte_closure_complete"])
        self.assertTrue(receipt["primary_identity"].startswith("sglp1:shake256-512:"))

    def test_number_only_identity_blocked(self):
        for value in ("1", "17", "23"):
            with self.subTest(value=value), self.assertRaises(migration.MigrationError):
                migration.resolve_route(value)

    def test_unknown_record_blocked(self):
        with self.assertRaises(migration.MigrationError):
            migration.resolve_route("GEN-X-UNKNOWN-01")

    def test_generation_c_not_silently_merged(self):
        b = migration.resolve_route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-14")
        c = migration.resolve_route("GEN-C-INTEGRATED-QEL-EMULATOR-8-15-14")
        self.assertNotEqual(b.record_id, c.record_id)
        self.assertNotEqual(b.generation_id, c.generation_id)
        self.assertEqual(b.corrected_primitive, c.corrected_primitive)

    def test_every_forward_target_exists(self):
        valid = {item["capability_id"] for item in qpu.suite_catalog()}
        for route in migration.ROUTES:
            for target in route.forward_targets:
                with self.subTest(record=route.record_id, target=target):
                    self.assertIn(target, valid)

    def test_every_primitive_exists(self):
        for route in migration.ROUTES:
            if route.corrected_primitive:
                with self.subTest(record=route.record_id):
                    self.assertTrue(hasattr(qpu, route.corrected_primitive))
                    self.assertTrue(callable(getattr(qpu, route.corrected_primitive)))

    def test_non_quantum_lanes_named(self):
        moved = [r for r in migration.ROUTES if r.disposition == "MOVE_TO_NON_QUANTUM_LANE"]
        self.assertGreaterEqual(len(moved), 5)
        self.assertTrue(all(r.non_quantum_lane for r in moved))

    def test_exact_source_pending_all_routes(self):
        self.assertTrue(all(route.exact_source_bytes_pending for route in migration.ROUTES))


class TestSelectedRoutes(unittest.TestCase):
    def test_b01_routes_to_state_transition(self):
        route = migration.resolve_route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-01")
        self.assertEqual(route.forward_targets[0], "QCAP-GEN-A-01")

    def test_b07_moves_to_security_lane(self):
        route = migration.resolve_route("GEN-B-INTEGRATED-QEL-EMULATOR-1-15-07")
        self.assertEqual(route.disposition, "MOVE_TO_NON_QUANTUM_LANE")
        self.assertEqual(route.non_quantum_lane, "SGL_PRIME_SECURITY_AND_KEY_MANAGEMENT")
        with self.assertRaises(migration.MigrationError):
            migration.run_primary_successor_benchmark(route.record_id)

    def test_d16_adaptive_gate_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-16")
        self.assertEqual(route.corrected_primitive, "adaptive_gate_placement")
        self.assertIn("QCAP-GEN-A-20", route.forward_targets)

    def test_d17_phase_gradient_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17")
        self.assertEqual(route.corrected_primitive, "phase_gradient")

    def test_d18_basis_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-18")
        self.assertEqual(route.corrected_primitive, "verify_in_bases")

    def test_d19_dephasing_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-19")
        self.assertEqual(route.corrected_primitive, "dephasing_channel")

    def test_d20_general_measurement_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-20")
        self.assertEqual(route.corrected_primitive, "measure_qubit")

    def test_d21_controlled_phase_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-21")
        self.assertEqual(route.corrected_primitive, "controlled_phase_kickback")

    def test_d22_cptp_dissipation_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-22")
        self.assertEqual(route.corrected_primitive, "amplitude_damping_channel")

    def test_d23_reverse_route(self):
        route = migration.resolve_route("GEN-D-INTEGRATED-QEL-EMULATOR-16-23-23")
        self.assertEqual(route.corrected_primitive, "reverse_unitary_sequence")

    def test_primary_successor_benchmark(self):
        result = migration.run_primary_successor_benchmark(
            "GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17"
        )
        self.assertEqual(result["capability"]["capability_id"], "QCAP-GEN-A-09")


class TestGovernedDispatch(unittest.TestCase):
    def test_ambiguous_successor_requires_intent(self):
        with self.assertRaises(migration.MigrationError):
            migration.dispatch_generation_bound_record(
                "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-03"
            )

    def test_explicit_successor_dispatch(self):
        receipt = migration.dispatch_generation_bound_record(
            "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-03",
            forward_target="QCAP-GEN-A-17",
        )
        self.assertEqual(receipt["payload"]["execution_mode"], "CORRECTED_SUCCESSOR")
        self.assertEqual(
            receipt["payload"]["result"]["capability"]["capability_id"],
            "QCAP-GEN-A-17",
        )
        self.assertFalse(receipt["payload"]["exact_historical_source_bytes_used"])

    def test_safe_primitive_dispatch(self):
        receipt = migration.dispatch_generation_bound_record(
            "GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17",
            primitive_args={"state": [1, 0], "gradient_factor": 0.25},
        )
        self.assertEqual(receipt["payload"]["execution_mode"], "SAFE_PRIMITIVE")
        self.assertTrue(receipt["primary_identity"].startswith("sglp1:shake256-512:"))

    def test_primitive_requires_explicit_arguments(self):
        with self.assertRaises(migration.MigrationError):
            migration.dispatch_generation_bound_record(
                "GEN-D-INTEGRATED-QEL-EMULATOR-16-23-17"
            )

    def test_non_quantum_lane_cannot_execute_in_qpu(self):
        with self.assertRaises(migration.MigrationError):
            migration.dispatch_generation_bound_record(
                "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-07"
            )

    def test_unauthorized_target_rejected(self):
        with self.assertRaises(migration.MigrationError):
            migration.dispatch_generation_bound_record(
                "GEN-B-INTEGRATED-QEL-EMULATOR-1-15-12",
                forward_target="QCAP-GEN-A-07",
            )


if __name__ == "__main__":
    unittest.main()
