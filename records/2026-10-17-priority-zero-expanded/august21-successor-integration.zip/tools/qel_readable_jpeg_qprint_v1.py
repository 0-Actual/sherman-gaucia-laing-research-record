#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, io, json, os, stat, struct, sys, zipfile
from pathlib import Path, PurePosixPath
from typing import Any
from PIL import Image, ImageDraw, ImageFont
HERE=Path(__file__).resolve().parent; ROOT=HERE.parent
VENDOR=ROOT/'vendor'/'rc1'/'vendor'
if str(VENDOR) not in sys.path: sys.path.insert(0,str(VENDOR))
from sgl_prime.core import canonical_json_bytes, fingerprint, secondary_sha256_witness
MARKER=b'\nQELQPRINTJPEG1\n'

def _font(name,size):
    base=Path('/usr/share/fonts/truetype/dejavu')
    return ImageFont.truetype(str(base/name),size)

def wrap(draw,text,font,width_px):
    words=str(text).split(); lines=[]; cur=''
    for word in words:
        cand=word if not cur else cur+' '+word
        if draw.textlength(cand,font=font)<=width_px: cur=cand
        else:
            if cur: lines.append(cur)
            cur=word
    if cur: lines.append(cur)
    return lines or ['']

def render(metadata:dict[str,Any])->bytes:
    W=2200; margin=105; width=W-2*margin
    title=_font('DejaVuSans-Bold.ttf',48); head=_font('DejaVuSans-Bold.ttf',36); body=_font('DejaVuSans.ttf',30); small=_font('DejaVuSans.ttf',24)
    sections=metadata['visible_sections']; dummy=Image.new('RGB',(W,100),'white'); d=ImageDraw.Draw(dummy)
    blocks=[]; height=margin+34
    for i,s in enumerate(sections):
        hf=title if i==0 else head
        hlines=wrap(d,s['heading'],hf,width)
        items=[]
        for item in s.get('items',[]): items.append(wrap(d,item,small if item.startswith(('SGL Prime','SHA-256')) else body,width-40))
        blocks.append((hlines,hf,items)); height+=len(hlines)*(hf.size+14)+18+sum(len(x)*(body.size+13)+10 for x in items)+38
    height+=margin
    img=Image.new('RGB',(W,height),'white'); draw=ImageDraw.Draw(img); draw.rectangle((0,0,W,28),fill=(20,45,78)); y=margin
    for i,(hlines,hf,items) in enumerate(blocks):
        if i: draw.line((margin,y-18,W-margin,y-18),fill=(175,180,185),width=2)
        for line in hlines: draw.text((margin,y),line,font=hf,fill=(20,45,78)); y+=hf.size+14
        y+=14
        for lines in items:
            for j, line in enumerate(lines):
                text = ('• ' if j == 0 else '  ') + line
                chosen_font = small if line.startswith(('sglp1:', 'SHA-256')) else body
                draw.text((margin + (12 if j == 0 else 0), y), text, font=chosen_font, fill=(28, 28, 28))
                y += chosen_font.size + 13
            y += 10
        y+=38
    out=io.BytesIO(); img.save(out,'JPEG',quality=94,optimize=True,progressive=True); return out.getvalue()

def build(zip_path:Path,output:Path,metadata_path:Path):
    meta=json.loads(metadata_path.read_text(encoding='utf-8')); zip_bytes=zip_path.read_bytes(); image_bytes=render(meta)
    payload={'schema':'qel.readable-jpeg-qprint/v1','qprint_id':meta['qprint_id'],'project':meta['project'],'owner_principal':meta['owner_principal'],'created_et':meta['created_et'],'parent_authorization_qprint':meta['parent_authorization_qprint'],'technical_parent_qprint':meta['technical_parent_qprint'],'image_primary_identity':fingerprint(image_bytes,'qel-readable-jpeg-qprint-image-v1'),'image_secondary_witness':secondary_sha256_witness(image_bytes),'zip_primary_identity':fingerprint(zip_bytes,'qel-readable-jpeg-qprint-payload-zip-v1'),'zip_secondary_witness':secondary_sha256_witness(zip_bytes),'zip_bytes':len(zip_bytes),'validation_result':meta['validation_result'],'operator_signature':'UNSIGNED','encryption':'UNENCRYPTED','automatic_execution':False}
    manifest=canonical_json_bytes(payload); carrier=image_bytes+MARKER+len(manifest).to_bytes(8,'big')+manifest+len(zip_bytes).to_bytes(8,'big')+zip_bytes
    output.write_bytes(carrier)
    return {'payload_manifest':payload,'carrier_bytes':len(carrier),'carrier_primary_identity':fingerprint(carrier,'qel-readable-jpeg-qprint-carrier-v1'),'carrier_secondary_witness':secondary_sha256_witness(carrier)}

def parse(path:Path):
    raw=path.read_bytes(); pos=raw.rfind(MARKER)
    if pos<0: raise ValueError('QPRINT marker not found')
    image=raw[:pos]; cursor=pos+len(MARKER)
    if cursor+8>len(raw): raise ValueError('truncated manifest length')
    ml=int.from_bytes(raw[cursor:cursor+8],'big'); cursor+=8
    manifest=raw[cursor:cursor+ml]; cursor+=ml
    if cursor+8>len(raw): raise ValueError('truncated zip length')
    zl=int.from_bytes(raw[cursor:cursor+8],'big'); cursor+=8; z=raw[cursor:cursor+zl]
    if len(z)!=zl or cursor+zl!=len(raw): raise ValueError('payload length mismatch')
    return image,json.loads(manifest.decode('utf-8')),z

def safe_members(z:zipfile.ZipFile):
    seen=set()
    for info in z.infolist():
        name=info.filename; p=PurePosixPath(name)
        if p.is_absolute() or '..' in p.parts or '\\' in name or name in seen: raise ValueError(f'unsafe zip member: {name}')
        seen.add(name)
        mode=(info.external_attr>>16)&0xFFFF
        if stat.S_ISLNK(mode): raise ValueError(f'symlink member rejected: {name}')
    return seen

def verify(path:Path):
    image,manifest,zbytes=parse(path)
    Image.open(io.BytesIO(image)).verify()
    checks=[]
    def c(i,ok,d): checks.append({'check_id':i,'pass':bool(ok),'detail':d})
    c('IMAGE_PRIMARY_IDENTITY',fingerprint(image,'qel-readable-jpeg-qprint-image-v1')==manifest['image_primary_identity'],manifest['image_primary_identity'])
    c('ZIP_PRIMARY_IDENTITY',fingerprint(zbytes,'qel-readable-jpeg-qprint-payload-zip-v1')==manifest['zip_primary_identity'],manifest['zip_primary_identity'])
    c('ZIP_LENGTH',len(zbytes)==manifest['zip_bytes'],len(zbytes))
    with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
        members=safe_members(z); bad=z.testzip(); c('ZIP_STRUCTURE',bad is None,{'members':len(members),'bad':bad})
        pm=json.loads(z.read('PACKAGE_MANIFEST.json').decode('utf-8')); mism=[]
        for row in pm['entries']:
            data=z.read(row['path'])
            if hashlib.sha256(data).hexdigest()!=row['sha256_secondary_witness']: mism.append(row['path'])
        c('PACKAGE_MANIFEST_MEMBERS',not mism and len(pm['entries'])==len(members)-1,{'manifest_entries':len(pm['entries']),'zip_members':len(members),'mismatches':mism})
    failed=[x for x in checks if not x['pass']]
    return {'schema':'qel.readable-jpeg-qprint-verification/v1','result':'PASS' if not failed else 'HOLD','checks_total':len(checks),'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),'checks':checks,'qprint_id':manifest['qprint_id'],'carrier_primary_identity':fingerprint(path.read_bytes(),'qel-readable-jpeg-qprint-carrier-v1'),'carrier_secondary_witness':secondary_sha256_witness(path.read_bytes()),'automatic_execution':False}

def recover(path:Path,dest:Path):
    _,_,zbytes=parse(path); dest.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(zbytes)) as z:
        safe_members(z)
        for info in z.infolist():
            target=(dest/info.filename).resolve()
            if dest.resolve() not in target.parents and target!=dest.resolve(): raise ValueError('extraction escaped destination')
            target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(z.read(info.filename))
    return {'result':'PASS','files':sum(1 for x in dest.rglob('*') if x.is_file()),'automatic_execution':False}

def main():
    ap=argparse.ArgumentParser(); sub=ap.add_subparsers(dest='cmd',required=True)
    b=sub.add_parser('build'); b.add_argument('--zip',required=True); b.add_argument('--metadata',required=True); b.add_argument('--output',required=True); b.add_argument('--receipt',required=True)
    v=sub.add_parser('verify'); v.add_argument('--input',required=True); v.add_argument('--output',required=True)
    r=sub.add_parser('recover'); r.add_argument('--input',required=True); r.add_argument('--directory',required=True); r.add_argument('--output',required=True)
    a=ap.parse_args()
    if a.cmd=='build': result=build(Path(a.zip),Path(a.output),Path(a.metadata)); Path(a.receipt).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    elif a.cmd=='verify': result=verify(Path(a.input)); Path(a.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    else: result=recover(Path(a.input),Path(a.directory)); Path(a.output).write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps(result,indent=2,sort_keys=True)); return 0 if result.get('result','PASS')=='PASS' else 1
if __name__=='__main__': raise SystemExit(main())
