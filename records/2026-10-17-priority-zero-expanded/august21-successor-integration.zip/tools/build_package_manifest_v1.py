#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent; ROOT_DEFAULT=HERE.parent
VENDOR=ROOT_DEFAULT/'vendor'/'rc1'/'vendor'
if str(VENDOR) not in sys.path: sys.path.insert(0,str(VENDOR))
from sgl_prime.core import canonical_json_bytes, fingerprint, secondary_sha256_witness

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default=str(ROOT_DEFAULT)); ap.add_argument('--output',required=True)
    a=ap.parse_args(); root=Path(a.root).resolve(); out=Path(a.output).resolve(); rows=[]
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        if p.resolve()==out or '__pycache__' in p.parts or p.suffix=='.pyc': continue
        rel=p.relative_to(root).as_posix(); raw=p.read_bytes()
        rows.append({'path':rel,'bytes':len(raw),'primary_identity':fingerprint(raw,f'qel-package-member:{rel}'),'sha256_secondary_witness':hashlib.sha256(raw).hexdigest()})
    body={'schema':'qel.package-manifest/v1','project':'Project Quantum.Earth.Laing / Q6.1','owner_principal':'Sherman G. Laing','package_name':'QEL_QPU_EMULATOR_KERNEL_INTEGRATION_V1.zip','self_reference_excluded':'PACKAGE_MANIFEST.json','entries':rows,'file_count':len(rows),'total_bytes':sum(r['bytes'] for r in rows),'automatic_execution':False}
    subject=canonical_json_bytes(body); body['primary_identity']=fingerprint(subject,'qel-qpu-emulator-kernel-integration-package-manifest-v1'); body['secondary_witness']=secondary_sha256_witness(subject)
    out.write_text(json.dumps(body,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'file_count':body['file_count'],'total_bytes':body['total_bytes'],'primary_identity':body['primary_identity']},indent=2))
if __name__=='__main__': main()
