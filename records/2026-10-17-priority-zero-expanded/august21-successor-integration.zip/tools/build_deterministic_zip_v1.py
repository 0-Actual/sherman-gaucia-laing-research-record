#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, stat, zipfile
from pathlib import Path

FIXED=(1980,1,1,0,0,0)

def safe_files(root:Path):
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        if '__pycache__' in p.parts or p.suffix=='.pyc':
            continue
        yield p

def build(root:Path, output:Path):
    root=root.resolve(); output=output.resolve(); output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9,strict_timestamps=True) as z:
        for p in safe_files(root):
            rel=p.relative_to(root).as_posix()
            info=zipfile.ZipInfo(rel,FIXED); info.create_system=3
            executable=rel.startswith('tools/') or rel.startswith('code/')
            mode=0o755 if executable and p.suffix=='.py' else 0o644
            info.external_attr=(stat.S_IFREG|mode)<<16
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--root',required=True); ap.add_argument('--output',required=True)
    a=ap.parse_args(); build(Path(a.root),Path(a.output))
if __name__=='__main__': main()
