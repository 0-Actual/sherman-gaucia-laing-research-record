#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, re, sys
from pathlib import Path
from typing import Any

HERE=Path(__file__).resolve().parent
ROOT_DEFAULT=HERE.parent
VENDOR=ROOT_DEFAULT/'vendor'/'rc1'/'vendor'
if str(VENDOR) not in sys.path: sys.path.insert(0,str(VENDOR))
from sgl_prime.core import canonical_json_bytes, fingerprint, secondary_sha256_witness

EXPECTED_SUITE_ID='sglp1:shake256-512:15ac73565f998dcc717db2d5c031897935a6c7df2aab4d01d5c2512b4127578a17145753fafa058c381cb56ef10f7d5d60c3d77fc7c1d21d59216a49815e930b'

def load(p:Path)->Any: return json.loads(p.read_text(encoding='utf-8'))
def sha(p:Path)->str: return hashlib.sha256(p.read_bytes()).hexdigest()

def main()->int:
    ap=argparse.ArgumentParser(); ap.add_argument('--root',default=str(ROOT_DEFAULT)); ap.add_argument('--output',required=True)
    a=ap.parse_args(); root=Path(a.root).resolve(); ev=root/'evidence'; checks=[]
    def check(cid,condition,detail): checks.append({'check_id':cid,'pass':bool(condition),'detail':detail})

    required=[
      'code/qel_qpu_emulator_kernel_v1.py','code/qel_bcd_migration_adapter_v1.py',
      'evidence/QEL_QPU_EMULATOR_INTEGRATION_BENCHMARK_V2.json',
      'evidence/QEL_QPU_EMULATOR_KERNEL_MANIFEST_V2.json',
      'evidence/QEL_BCD_MIGRATION_REGISTER_V2.json',
      'evidence/QEL_GOVERNED_DISPATCH_BENCHMARK_V1.json',
      'evidence/CANONICAL_UNIT_TEST_RESULT_005.json','evidence/CANONICAL_UNIT_TEST_RESULT_006.json',
      'evidence/RC1_CHECKPOINT_REPLAY/finalize_stdout.json',
      'evidence/RC1_CHECKPOINT_REPLAY/GENERATION_A_SUITE_RUN_REPLAY_V1.json',
      'evidence/QEL_CORRECTED_KERNEL_PROPAGATION_MAP_V1.json',
      'evidence/SOURCE_INVENTORY_V1.json',
      'docs/QEL_QPU_EMULATOR_KERNEL_INTEGRATION_V1_REPORT.md',
      'parent/QPRINT-QEL-CONSOLIDATED-KNOWLEDGE-QUANTUM-SUITE-OWNER-REVIEW-20260821T205900-0400-V2.qprint.png',
    ]
    missing=[r for r in required if not (root/r).is_file()]
    check('REQUIRED_FILES_PRESENT',not missing,{'required':len(required),'missing':missing})

    tests1=load(ev/'CANONICAL_UNIT_TEST_RESULT_005.json'); tests2=load(ev/'CANONICAL_UNIT_TEST_RESULT_006.json')
    check('CANONICAL_TEST_RECEIPTS_IDENTICAL',(ev/'CANONICAL_UNIT_TEST_RESULT_005.json').read_bytes()==(ev/'CANONICAL_UNIT_TEST_RESULT_006.json').read_bytes(),sha(ev/'CANONICAL_UNIT_TEST_RESULT_005.json'))
    check('CURRENT_AND_BCD_TESTS_146_PASS',tests1['result']=='PASS' and tests1['tests_run']==146 and tests1['successes']==146 and not tests1['failures'] and not tests1['errors'],{'tests':tests1['tests_run'],'successes':tests1['successes']})

    fin=load(ev/'RC1_CHECKPOINT_REPLAY/finalize_stdout.json'); replay=load(ev/'RC1_CHECKPOINT_REPLAY/GENERATION_A_SUITE_RUN_REPLAY_V1.json')
    check('RC1_CHECKPOINT_REPLAY_PASS',fin['result']=='PASS' and fin['capabilities']==21 and fin['expected_byte_semantics_match'],fin)
    check('RC1_SUITE_IDENTITY_MATCH',replay['suite_run_primary_identity']==EXPECTED_SUITE_ID and fin['suite_primary_identity']==EXPECTED_SUITE_ID,replay['suite_run_primary_identity'])
    check('RC1_ALL_21_EXECUTED',replay['capability_count']==21 and replay['all_capabilities_executed'],replay['capability_count'])

    migration=load(ev/'QEL_BCD_MIGRATION_REGISTER_V2.json'); mp=migration['payload']
    check('BCD_31_OF_31_ROUTED',mp['coverage_complete'] and mp['historical_records']==31 and mp['migration_routes']==31 and sum(mp['dispositions'].values())==31,mp['dispositions'])
    check('BCD_NUMBER_ONLY_IDENTITY_PROHIBITED',mp['number_only_identity_prohibited'],True)
    check('BCD_EXACT_SOURCE_CLOSURE_OPEN',mp['exact_raw_source_byte_closure_complete'] is False,False)

    dispatch=load(ev/'QEL_GOVERNED_DISPATCH_BENCHMARK_V1.json')['payload']
    blocked=dispatch['fail_closed']
    check('GOVERNED_DISPATCH_FAILS_CLOSED',all(v['blocked'] for v in blocked.values()),blocked)
    check('EXPLICIT_SUCCESSOR_DISPATCH',dispatch['explicit_successor_dispatch']['result_capability_id']=='QCAP-GEN-A-17',dispatch['explicit_successor_dispatch'])
    check('SAFE_PRIMITIVE_DISPATCH',dispatch['safe_primitive_dispatch']['execution_mode']=='SAFE_PRIMITIVE',dispatch['safe_primitive_dispatch'])

    manifest=load(ev/'QEL_QPU_EMULATOR_KERNEL_MANIFEST_V2.json')['payload']
    primitives=manifest['validated_primitives']
    check('KERNEL_21_CAPABILITY_BASELINE',manifest['generation_a_capabilities']==21,manifest['generation_a_capabilities'])
    check('LOOKAHEAD_MANIFEST_CORRECT','bounded_lookahead_adaptive_gate_placement' in primitives and 'greedy_adaptive_gate_placement' not in primitives,primitives)

    bench=load(ev/'QEL_QPU_EMULATOR_INTEGRATION_BENCHMARK_V2.json')['payload']['corrected_primitives']
    check('D16_LOOKAHEAD_FIDELITY_ONE',bench['D16_adaptive_gate_placement']['final_fidelity']=='1.0',bench['D16_adaptive_gate_placement'])
    check('D17_UNITARY_PHASE_GRADIENT',bench['D17_phase_gradient']['unitary'] and bench['D17_phase_gradient']['probability_sum']=='1.0',bench['D17_phase_gradient'])
    check('D19_DEPHASING_TRACE',abs(float(bench['D19_decoherence_simulation']['trace'])-1.0)<1e-12,bench['D19_decoherence_simulation'])
    check('D23_REVERSE_FIDELITY_ONE',bench['D23_reverse_computation']['recovery_fidelity']=='1.0',bench['D23_reverse_computation'])

    correction_ids=[]
    for p in sorted(ev.glob('CORRECTION_*.json')):
        correction_ids.append(load(p).get('correction_id'))
    required_corrections={'QEL-QPU-INT-C001','QEL-QPU-INT-C002','QEL-QPU-INT-C003','QEL-QPU-INT-C004'}
    check('CORRECTION_LEDGER_COMPLETE',required_corrections.issubset(set(correction_ids)),correction_ids)

    syntax=[]
    for p in sorted(root.rglob('*.py')):
        try: compile(p.read_text(encoding='utf-8'),str(p),'exec')
        except Exception as exc: syntax.append({'file':p.relative_to(root).as_posix(),'error':str(exc)})
    check('PYTHON_SYNTAX_PASS',not syntax,{'files':len(list(root.rglob('*.py'))),'errors':syntax})
    caches=[p.relative_to(root).as_posix() for p in root.rglob('__pycache__')]
    pyc=[p.relative_to(root).as_posix() for p in root.rglob('*.pyc')]
    check('NO_GENERATED_CACHES',not caches and not pyc,{'pycache':caches,'pyc':pyc})

    secret_patterns=[re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH |)PRIVATE KEY-----'),re.compile(rb'\bsk-[A-Za-z0-9_-]{20,}\b'),re.compile(rb'AKIA[0-9A-Z]{16}')]
    findings=[]; scanned=0; scanned_bytes=0
    validation_scan_excludes = {'PACKAGE_MANIFEST.json', 'evidence/FINAL_VALIDATION_REPORT_V1.json'}
    for p in sorted(x for x in root.rglob('*') if x.is_file()):
        rel = p.relative_to(root).as_posix()
        if rel in validation_scan_excludes:
            continue
        if p.suffix.lower() in {'.png','.jpg','.jpeg','.zip','.qprint'}:
            continue
        raw=p.read_bytes(); scanned+=1; scanned_bytes+=len(raw)
        for pattern in secret_patterns:
            if pattern.search(raw): findings.append({'file':p.relative_to(root).as_posix(),'pattern':pattern.pattern.decode(errors='replace')})
    check('HIGH_CONFIDENCE_SECRET_SCAN',not findings,{'files':scanned,'bytes':scanned_bytes,'findings':findings})

    inventory=load(ev/'SOURCE_INVENTORY_V1.json')
    inv_paths=[row['path'] for row in inventory['entries']]
    inv_mismatch=[]
    for row in inventory['entries']:
        path=root/row['path']
        if not path.is_file() or sha(path)!=row['sha256_secondary_witness']:
            inv_mismatch.append(row['path'])
    check('SOURCE_INVENTORY_MATCH',inventory['file_count']==len(inventory['entries']) and len(inv_paths)==len(set(inv_paths)) and not inv_mismatch,{'files':inventory['file_count'],'mismatches':inv_mismatch})

    prop=load(ev/'QEL_CORRECTED_KERNEL_PROPAGATION_MAP_V1.json')['payload']
    check('NEXT_OPERATION_QMATH',prop['next_operation']=='MC-003E-QMATH-FOUNDATIONAL-MATRIX-INTEGRATION',prop['next_operation'])

    failed=[c for c in checks if not c['pass']]
    body={
      'schema':'qel.qpu-emulator-integration-validation/v1',
      'project':'Project Quantum.Earth.Laing / Q6.1',
      'owner_principal':'Sherman G. Laing',
      'result':'PASS' if not failed else 'HOLD',
      'checks_total':len(checks),'checks_passed':len(checks)-len(failed),'checks_failed':len(failed),
      'checks':checks,
      'claim_state':'QEL_INTERNALLY_VERIFIED_EMULATED_QPU_KERNEL_INTEGRATION_V1' if not failed else 'HOLD',
      'physical_qpu_execution_claimed':False,
      'exact_bcd_source_byte_closure_complete':False,
      'owner_acceptance_claimed':False,
      'operator_signature':'UNSIGNED',
      'automatic_execution':False,
    }
    subject=canonical_json_bytes(body); body['primary_identity']=fingerprint(subject,'qel-qpu-emulator-integration-validation-v1'); body['secondary_witness']=secondary_sha256_witness(subject)
    Path(a.output).write_text(json.dumps(body,indent=2,sort_keys=True,ensure_ascii=False)+'\n',encoding='utf-8')
    print(json.dumps({'result':body['result'],'checks_total':body['checks_total'],'checks_passed':body['checks_passed'],'primary_identity':body['primary_identity']},indent=2))
    return 0 if not failed else 1
if __name__=='__main__': raise SystemExit(main())
