#!/usr/bin/env python3
"""Deterministic unittest evidence runner for QEL capability suites."""
from __future__ import annotations
import argparse, hashlib, io, json, sys, unittest
from pathlib import Path
from typing import Any

class CanonicalResult(unittest.TestResult):
    def __init__(self) -> None:
        super().__init__()
        self.success_ids: list[str] = []
    def addSuccess(self, test: unittest.case.TestCase) -> None:
        super().addSuccess(test); self.success_ids.append(test.id())

def flatten(suite: unittest.TestSuite):
    for item in suite:
        if isinstance(item, unittest.TestSuite):
            yield from flatten(item)
        else:
            yield item

def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8")

def main() -> int:
    ap=argparse.ArgumentParser()
    ap.add_argument('--start-directory',required=True)
    ap.add_argument('--pattern',default='test_*.py')
    ap.add_argument('--top-level-directory')
    ap.add_argument('--output',required=True)
    args=ap.parse_args()
    start=Path(args.start_directory).resolve()
    loader=unittest.TestLoader()
    suite=loader.discover(str(start), pattern=args.pattern, top_level_dir=args.top_level_directory)
    discovered=sorted(t.id() for t in flatten(suite))
    # Discover again because flattening may consume nested suite iterators in some runtimes.
    suite=loader.discover(str(start), pattern=args.pattern, top_level_dir=args.top_level_directory)
    result=CanonicalResult(); suite.run(result)
    body={
        'schema':'qel.canonical-unittest-result/v1',
        'result':'PASS' if result.wasSuccessful() else 'FAIL',
        'tests_discovered':len(discovered),
        'tests_run':result.testsRun,
        'successes':len(result.success_ids),
        'failures':[{"test":t.id(),"traceback":tb} for t,tb in result.failures],
        'errors':[{"test":t.id(),"traceback":tb} for t,tb in result.errors],
        'skipped':[{"test":t.id(),"reason":reason} for t,reason in result.skipped],
        'expected_failures':[t.id() for t,_ in result.expectedFailures],
        'unexpected_successes':[t.id() for t in result.unexpectedSuccesses],
        'test_ids':discovered,
        'test_ids_sha256_secondary_witness':hashlib.sha256("\n".join(discovered).encode()).hexdigest(),
        'automatic_execution':False,
    }
    subject=canonical_bytes(body)
    body['result_shake256_512_raw']=hashlib.shake_256(subject).hexdigest(64)
    body['result_sha256_secondary_witness']=hashlib.sha256(subject).hexdigest()
    Path(args.output).write_text(json.dumps(body,indent=2,sort_keys=True,ensure_ascii=False)+"\n",encoding='utf-8')
    print(json.dumps({k:body[k] for k in ['result','tests_discovered','tests_run','successes','result_shake256_512_raw']},indent=2))
    return 0 if result.wasSuccessful() else 1
if __name__=='__main__': raise SystemExit(main())
