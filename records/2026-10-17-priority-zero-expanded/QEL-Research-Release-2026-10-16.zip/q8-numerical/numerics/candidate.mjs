// QEL private JARVIS second pass. Sherman G. Laing / GAUCIA.
// The existing ansatz and Q8 circuit engine are unchanged. No answer reference is imported.
import {validateH,ansatz,actualState,dense,energy,independentEnergy,optimize as coordinateOptimize} from './baseline.mjs';
const dot=(a,b)=>a.reduce((s,x,i)=>s+x*b[i],0);
const norm=a=>Math.sqrt(dot(a,a));
const identity=n=>Array.from({length:n},(_,i)=>Array.from({length:n},(_,j)=>+(i===j)));
const wrap4pi=x=>((x+2*Math.PI)%(4*Math.PI)+4*Math.PI)%(4*Math.PI)-2*Math.PI;
const assert=(ok,msg)=>{if(!ok)throw Error(msg);};
function objectiveFor(H){
 validateH(H);const shift=H.reduce((s,row,i)=>s+row[i][0],0)/8;
 const centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?shift:0),z[1]]));let calls=0;
 const objective=theta=>{calls++;return energy(centered,actualState(ansatz(theta)).state);};
 const gradient=theta=>theta.map((_,i)=>{const a=theta.slice(),b=theta.slice();a[i]+=Math.PI/2;b[i]-=Math.PI/2;return (objective(a)-objective(b))/2;});
 return {objective,gradient,shift,calls:()=>calls};
}
export function stateDiagnostics(H,theta){
 const q=actualState(ansatz(theta)),d=dense(3,ansatz(theta)),E=energy(H,q.state);
 let norm2=0,res2=0,maxAmplitudeError=0;
 for(let i=0;i<8;i++){
  norm2+=q.state[i][0]**2+q.state[i][1]**2;
  maxAmplitudeError=Math.max(maxAmplitudeError,Math.hypot(q.state[i][0]-d[i][0],q.state[i][1]-d[i][1]));
  let re=-E*q.state[i][0],im=-E*q.state[i][1];
  for(let j=0;j<8;j++){re+=H[i][j][0]*q.state[j][0]-H[i][j][1]*q.state[j][1];im+=H[i][j][0]*q.state[j][1]+H[i][j][1]*q.state[j][0];}res2+=re*re+im*im;
 }
 return {energy_ev:E,norm:norm2,residual_ev:Math.sqrt(res2),variance_ev2:res2,max_amplitude_error:maxAmplitudeError,dense_energy_error_ev:Math.abs(E-independentEnergy(H,d)),amplitudes:q.state,storage:q.storage};
}
export function gradientDiagnostics(H,theta){
 const raw=stateDiagnostics(H,theta),wrapped=theta.map(wrap4pi),wrappedStats=stateDiagnostics(H,wrapped),obj=objectiveFor(H);
 const g=obj.gradient(wrapped),step=1e-5,fd=wrapped.map((_,i)=>{const a=wrapped.slice(),b=wrapped.slice();a[i]+=step;b[i]-=step;return (obj.objective(a)-obj.objective(b))/(2*step);});
 return {original:raw,wrapped:wrappedStats,gradient:g,gradient_norm:norm(g),gradient_max:Math.max(...g.map(Math.abs)),finite_difference_step:step,gradient_max_difference:Math.max(...g.map((v,i)=>Math.abs(v-fd[i]))),finite_difference:fd,wrapping_energy_difference_ev:Math.abs(raw.energy_ev-wrappedStats.energy_ev),max_abs_original_angle:Math.max(...theta.map(Math.abs))};
}
export function refineBFGS(H,theta,config){
 assert(Array.isArray(theta)&&theta.length===18&&theta.every(Number.isFinite),'18 finite parameters required');
 assert(Number.isInteger(config.max_iterations)&&config.max_iterations>=1&&config.max_iterations<=600,'Invalid iteration budget');
 let x=theta.map(wrap4pi);const obj=objectiveFor(H),N=x.length;
 let f=obj.objective(x),g=obj.gradient(x),B=identity(N),reason='iteration_budget',resets=0;
 const startE=f+obj.shift,history=[];
 for(let iteration=0;iteration<config.max_iterations;iteration++){
  if(norm(g)<=config.gradient_tolerance){reason='gradient_tolerance';break;}
  let p=B.map(row=>-dot(row,g)),directional=dot(p,g);
  if(!Number.isFinite(directional)||directional>=-1e-20){B=identity(N);p=g.map(v=>-v);directional=-dot(g,g);resets++;}
  const pn=norm(p);if(pn>config.maximum_step_norm){p=p.map(v=>v*config.maximum_step_norm/pn);directional=dot(p,g);}
  let alpha=1,accepted=false,next=null,nf=NaN,backtracks=0;
  for(;backtracks<config.line_search_steps;backtracks++){next=x.map((v,i)=>v+alpha*p[i]);nf=obj.objective(next);if(Number.isFinite(nf)&&nf<=f+config.armijo*alpha*directional+1e-14){accepted=true;break;}alpha*=0.5;}
  if(!accepted){reason='line_search_exhausted';break;}
  const ng=obj.gradient(next),s=next.map((v,i)=>v-x[i]),y=ng.map((v,i)=>v-g[i]),ys=dot(y,s);
  if(ys>1e-12*norm(y)*Math.max(norm(s),1e-20)){
   const By=B.map(row=>dot(row,y)),factor=(1+dot(y,By)/ys)/ys;
   const updated=B.map((row,i)=>row.map((v,j)=>v+factor*s[i]*s[j]-(s[i]*By[j]+By[i]*s[j])/ys));
   if(updated.every(row=>row.every(Number.isFinite)))B=updated;else{B=identity(N);resets++;}
  }else{B=identity(N);resets++;}
  history.push({iteration:iteration+1,energy_ev:nf+obj.shift,improvement_ev:f-nf,gradient_norm:norm(ng),step_scale:alpha,backtracks});
  x=next;f=nf;g=ng;
 }
 const state=stateDiagnostics(H,x);assert(state.energy_ev<=startE+1e-9,'Refinement increased energy');
 return {initial_energy_ev:startE,final_energy_ev:state.energy_ev,parameters:x,gradient:g,gradient_norm:norm(g),iterations:history.length,reason,history,resets,objective_evaluations:obj.calls(),centering_shift_ev:obj.shift,...state};
}
export function optimizeCandidate(H,config,seed){
 const warm=coordinateOptimize(H,config.warmup,seed),starts=[];
 for(const s of warm.starts)starts.push({start:s.start,warmup_initial_energy_ev:s.initial_energy_ev,warmup_final_energy_ev:s.final_energy_ev,warmup_evaluations:s.evaluations,...refineBFGS(H,s.parameters,config.bfgs)});
 const best=starts.reduce((a,b)=>a.final_energy_ev<=b.final_energy_ev?a:b);
 return {method:'original coordinate warmup plus coupled BFGS with parameter-shift gradients',seed,best_start:best.start,initial_best_energy_ev:Math.min(...warm.starts.map(s=>s.initial_energy_ev)),warmup_best_energy_ev:warm.final_energy_ev,final_energy_ev:best.final_energy_ev,parameters:best.parameters,amplitudes:best.amplitudes,gradient_norm:best.gradient_norm,residual_ev:best.residual_ev,starts,total_objective_evaluations:warm.total_evaluations+starts.reduce((s,r)=>s+r.objective_evaluations,0),warmup_total_evaluations:warm.total_evaluations};
}
