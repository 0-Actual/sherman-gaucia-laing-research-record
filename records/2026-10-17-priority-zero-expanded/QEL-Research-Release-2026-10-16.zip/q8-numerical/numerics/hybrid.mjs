// Hybrid Rayleigh refinement and Q8 circuit fitting. Explicitly classical linear algebra plus Q8 simulation.
// Only the Hamiltonian and current Q8 circuit parameters enter this method; no scoring reference is imported.
import {ansatz,actualState,validateH,energy} from './baseline.mjs';import {refineBFGS} from './candidate.mjs';
const add=(a,b)=>[a[0]+b[0],a[1]+b[1]],sub=(a,b)=>[a[0]-b[0],a[1]-b[1]],mul=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]],conj=z=>[z[0],-z[1]],abs=z=>Math.hypot(z[0],z[1]);
const div=(a,b)=>{const s=b[0]*b[0]+b[1]*b[1];return [(a[0]*b[0]+a[1]*b[1])/s,(a[1]*b[0]-a[0]*b[1])/s];};
const mv=(A,p)=>A.map(row=>row.reduce((s,z,j)=>add(s,mul(z,p[j])),[0,0]));
const inner=(a,b)=>a.reduce((s,z,i)=>add(s,mul(conj(z),b[i])),[0,0]);
const normalize=p=>{const norm=Math.sqrt(inner(p,p)[0]);if(!Number.isFinite(norm)||norm===0)throw Error('Invalid target norm');return p.map(z=>[z[0]/norm,z[1]/norm]);};
const overlap=(a,b)=>abs(inner(a,b))**2;
function diagnostics(H,p){const E=inner(p,mv(H,p))[0]/inner(p,p)[0],res=mv(H,p).map((z,i)=>sub(z,[E*p[i][0],E*p[i][1]]));return {energy_ev:E,residual_ev:Math.sqrt(res.reduce((s,z)=>s+abs(z)**2,0))};}
export function solveComplex(A,rhs){
 const n=A.length,M=A.map((row,i)=>[...row.map(z=>z.slice()),rhs[i].slice()]),scale=Math.max(...A.flat().map(abs));let minimumPivot=Infinity;
 for(let k=0;k<n;k++){
  let pivot=k;for(let i=k+1;i<n;i++)if(abs(M[i][k])>abs(M[pivot][k]))pivot=i;
  const size=abs(M[pivot][k]);minimumPivot=Math.min(minimumPivot,size);if(size<=Math.max(1,scale)*1e-18)throw Error('Singular shifted solve');
  [M[k],M[pivot]]=[M[pivot],M[k]];
  for(let i=k+1;i<n;i++){const factor=div(M[i][k],M[k][k]);M[i][k]=[0,0];for(let j=k+1;j<=n;j++)M[i][j]=sub(M[i][j],mul(factor,M[k][j]));}
 }
 const x=Array.from({length:n},()=>[0,0]);
 for(let i=n-1;i>=0;i--){let value=M[i][n];for(let j=i+1;j<n;j++)value=sub(value,mul(M[i][j],x[j]));x[i]=div(value,M[i][i]);}
 const residual=mv(A,x).map((z,i)=>sub(z,rhs[i])),absolute=Math.sqrt(residual.reduce((s,z)=>s+abs(z)**2,0)),denominator=Math.sqrt(A.flat().reduce((s,z)=>s+abs(z)**2,0))*Math.sqrt(x.reduce((s,z)=>s+abs(z)**2,0))+Math.sqrt(rhs.reduce((s,z)=>s+abs(z)**2,0)),backward=absolute/denominator;
 if(!x.flat().every(Number.isFinite)||backward>1e-12)throw Error('Shifted solve failed its backward-error check');
 return {x,minimum_pivot:minimumPivot,relative_backward_error:backward};
}
export function refineTarget(H,initial,cfg){
 validateH(H);let p=normalize(initial);const span=Math.max(1,...H.flat().map(abs)),lower=Math.min(...H.map((row,i)=>row[i][0]-row.reduce((s,z,j)=>s+(i===j?0:abs(z)),0)))-cfg.shift_regularization*span,history=[];
 for(let i=0;i<cfg.inverse_iterations;i++){
  const old=diagnostics(H,p);let chosen=null;
  for(const shift of [old.energy_ev-cfg.shift_regularization*span,lower]){
   try{const A=H.map((row,a)=>row.map((z,b)=>[z[0]-(a===b?shift:0),z[1]])),solve=solveComplex(A,p),candidate=normalize(solve.x),next=diagnostics(H,candidate);
    if(next.energy_ev<=old.energy_ev+cfg.monotonic_slack_ev){chosen={p:candidate,...next,shift,backward_error:solve.relative_backward_error,fidelity_to_previous:overlap(p,candidate),mode:shift===lower?'lower_bound_inverse':'rayleigh_inverse'};break;}
   }catch(e){if(shift===lower)throw e;}
  }
  if(!chosen)break;
  history.push({iteration:i+1,old_energy_ev:old.energy_ev,energy_ev:chosen.energy_ev,residual_ev:chosen.residual_ev,shift:chosen.shift,mode:chosen.mode,backward_error:chosen.backward_error,fidelity_to_previous:chosen.fidelity_to_previous});p=chosen.p;
 }
 return {amplitudes:p,...diagnostics(H,p),history,method:'Safeguarded classical Rayleigh inverse iteration'};
}
export function hybridRefine(H,theta,cfg){
 const original=actualState(ansatz(theta)).state,old=diagnostics(H,original),target=refineTarget(H,original,cfg);
 const P=target.amplitudes.map((a,i)=>target.amplitudes.map((b,j)=>{const z=mul(a,conj(b));return [(i===j?1:0)-z[0],-z[1]];}));
 let parameters=theta.slice(),fitted=null;const rounds=[];
 for(let i=0;i<cfg.fit_rounds;i++){
  const fit=refineBFGS(P,parameters,cfg.fit),fidelity=overlap(target.amplitudes,fit.amplitudes);rounds.push({round:i+1,fit_fidelity:fidelity,fit_gradient:fit.gradient_norm,iterations:fit.iterations,reason:fit.reason,evaluations:fit.objective_evaluations});
  if(!fitted||fidelity>fitted.fidelity)fitted={fit,fidelity};parameters=fit.parameters;if(fidelity>=cfg.required_target_fit)break;
 }
 const state=fitted.fit.amplitudes,physical=diagnostics(H,state);
 return {parameters:fitted.fit.parameters,amplitudes:state,energy_ev:physical.energy_ev,residual_ev:physical.residual_ev,norm:inner(state,state)[0],old_energy_ev:old.energy_ev,target,target_fit_fidelity:fitted.fidelity,fit_rounds:rounds,physical_energy_nondecreasing:physical.energy_ev>old.energy_ev+cfg.monotonic_slack_ev,method:'Classical inverse-iteration target refinement, then unchanged Q8 ansatz fitting',external_reference_used:false};
}

