// Sherman G. Laing / GAUCIA. Private implementation of a published adjoint method.
// Mathematical source: Jones & Gacon (2020), https://arxiv.org/abs/2009.02823.
// Fixed 3-qubit, 18-angle Q8 circuit. O(1) state-vector count, not O(1) in qubits.
import {validateH} from './baseline.mjs';
export const layout=[];
for(let layer=0,p=0;layer<3;layer++){
 for(let q=0;q<3;q++){layout.push(Object.freeze({kind:'RY',mask:1<<(2-q),parameter:p++}));layout.push(Object.freeze({kind:'RZ',mask:1<<(2-q),parameter:p++}));}
 if(layer===0)layout.push(Object.freeze({kind:'CNOT',control:4,mask:2}),Object.freeze({kind:'CNOT',control:2,mask:1}));
 if(layer===1)layout.push(Object.freeze({kind:'CNOT',control:4,mask:1}),Object.freeze({kind:'CNOT',control:1,mask:2}));
}Object.freeze(layout);
function angles(theta){if(theta.length!==18||!Array.from(theta).every(Number.isFinite))throw Error('18 finite angles required');}
export function applyGate(v,g,theta,inverse=false){
 if(g.kind==='CNOT'){for(let i=0;i<8;i++)if((i&g.control)&&!(i&g.mask)){const a=2*i,b=2*(i|g.mask),re=v[a],im=v[a+1];v[a]=v[b];v[a+1]=v[b+1];v[b]=re;v[b+1]=im;}return;}
 const angle=theta[g.parameter]*(inverse?-1:1),c=Math.cos(angle/2),s=Math.sin(angle/2);
 if(g.kind==='RY'){for(let i=0;i<8;i++)if(!(i&g.mask)){const a=2*i,b=2*(i|g.mask),ar=v[a],ai=v[a+1],br=v[b],bi=v[b+1];v[a]=c*ar-s*br;v[a+1]=c*ai-s*bi;v[b]=s*ar+c*br;v[b+1]=s*ai+c*bi;}}
 else if(g.kind==='RZ'){for(let i=0;i<8;i++){const a=2*i,t=i&g.mask?s:-s,re=v[a],im=v[a+1];v[a]=c*re-t*im;v[a+1]=t*re+c*im;}}
 else throw Error('Unsupported compiled gate');
}
function forward(theta,out,index=0){out.fill(0);out[2*index]=1;for(const g of layout)applyGate(out,g,theta);return out;}
export function stateVector(theta,index=0){angles(theta);if(!Number.isInteger(index)||index<0||index>7)throw Error('Invalid basis index');return forward(theta,new Float64Array(16),index);}
export const pairs=v=>Array.from({length:8},(_,i)=>[v[2*i],v[2*i+1]]);
export function createObjective(H,mode='adjoint'){
 validateH(H);if(!['adjoint','shift'].includes(mode))throw Error('Invalid derivative mode');
 const h=new Float64Array(128),psi=new Float64Array(16),lambda=new Float64Array(16),phi=new Float64Array(16),temporary=new Float64Array(16);
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){h[2*(8*i+j)]=H[i][j][0];h[2*(8*i+j)+1]=H[i][j][1];} let cached=null,value=0,grad=null,objectiveCalls=0,gradientCalls=0,forwards=0,reverseGates=0;
 function matvec(v,out){for(let i=0;i<8;i++){let re=0,im=0;for(let j=0;j<8;j++){const k=2*(8*i+j),a=2*j;re+=h[k]*v[a]-h[k+1]*v[a+1];im+=h[k]*v[a+1]+h[k+1]*v[a];}out[2*i]=re;out[2*i+1]=im;}}
 function evaluate(theta){angles(theta);if(cached&&cached.every((x,i)=>x===theta[i]))return value;forward(theta,psi);forwards++;matvec(psi,lambda);value=0;let imag=0;for(let i=0;i<16;i+=2){value+=psi[i]*lambda[i]+psi[i+1]*lambda[i+1];imag+=psi[i]*lambda[i+1]-psi[i+1]*lambda[i];}if(!Number.isFinite(value)||Math.abs(imag)>1e-9)throw Error('Nonfinite expectation');cached=Array.from(theta);grad=null;return value;}
 function shifted(theta){forward(theta,temporary);forwards++;let out=0;for(let i=0;i<8;i++){let re=0,im=0;for(let j=0;j<8;j++){const k=2*(8*i+j),a=2*j;re+=h[k]*temporary[a]-h[k+1]*temporary[a+1];im+=h[k]*temporary[a+1]+h[k+1]*temporary[a];}out+=temporary[2*i]*re+temporary[2*i+1]*im;}return out;}
 function gradient(theta){
  gradientCalls++;evaluate(theta);if(grad)return grad.slice();grad=new Array(18).fill(0);
  if(mode==='shift'){for(let j=0;j<18;j++){const a=Array.from(theta),b=Array.from(theta);a[j]+=Math.PI/2;b[j]-=Math.PI/2;grad[j]=(shifted(a)-shifted(b))/2;}return grad.slice();}
  phi.set(psi);
  for(let k=layout.length-1;k>=0;k--){const g=layout[k];let sum=0;
   if(g.kind==='RY'){for(let i=0;i<8;i++)if(!(i&g.mask)){const a=2*i,b=2*(i|g.mask);sum+=-lambda[a]*phi[b]-lambda[a+1]*phi[b+1]+lambda[b]*phi[a]+lambda[b+1]*phi[a+1];}grad[g.parameter]=sum;}
   if(g.kind==='RZ'){for(let i=0;i<8;i++){const a=2*i,sign=i&g.mask?1:-1;sum+=sign*(lambda[a+1]*phi[a]-lambda[a]*phi[a+1]);}grad[g.parameter]=sum;}
   applyGate(phi,g,theta,true);applyGate(lambda,g,theta,true);reverseGates+=2;
  }if(!grad.every(Number.isFinite))throw Error('Nonfinite derivative');return grad.slice();
 }
 return {objective:theta=>{objectiveCalls++;return evaluate(theta);},gradient,state:theta=>{evaluate(theta);return pairs(psi);},counters:()=>({objective_calls:objectiveCalls,gradient_calls:gradientCalls,forward_circuits:forwards,reverse_gate_applications:reverseGates,state_workspace_bytes:psi.byteLength+lambda.byteLength+phi.byteLength+temporary.byteLength,hamiltonian_bytes:h.byteLength,mode})};
}
