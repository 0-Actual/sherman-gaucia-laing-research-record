// Explicit classical lowest-eigenvalue bracketing and Q8 state fitting; no external scoring answers.
import {ansatz,actualState,validateH,rng} from './baseline.mjs';import {refineBFGS} from './candidate.mjs';import {solveComplex} from './hybrid.mjs';
const mul=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]],conj=z=>[z[0],-z[1]],abs=z=>Math.hypot(z[0],z[1]),inner=(a,b)=>a.reduce((s,z,i)=>{const v=mul(conj(z),b[i]);return [s[0]+v[0],s[1]+v[1]];},[0,0]);
const mv=(H,p)=>H.map(row=>row.reduce((s,z,j)=>{const v=mul(z,p[j]);return [s[0]+v[0],s[1]+v[1]];},[0,0])),normalize=p=>{const n=Math.sqrt(inner(p,p)[0]);return p.map(z=>[z[0]/n,z[1]/n]);},overlap=(a,b)=>abs(inner(a,b))**2;
function metrics(H,p){const hp=mv(H,p),E=inner(p,hp)[0]/inner(p,p)[0],residual=Math.sqrt(hp.reduce((s,z,i)=>s+(z[0]-E*p[i][0])**2+(z[1]-E*p[i][1])**2,0));return {energy_ev:E,residual_ev:residual};}
export function positiveDefinite(H,shift){
 const n=H.length,L=Array.from({length:n},()=>Array.from({length:n},()=>[0,0]));let minimumPivot=Infinity;
 for(let i=0;i<n;i++)for(let j=0;j<=i;j++){
  let re=H[i][j][0]-(i===j?shift:0),im=H[i][j][1];
  for(let k=0;k<j;k++){const z=mul(L[i][k],conj(L[j][k]));re-=z[0];im-=z[1];}
  if(i===j){if(!(re>0)||!Number.isFinite(re)||Math.abs(im)>1e-9)return {positive:false,minimum_pivot:Math.min(minimumPivot,re)};minimumPivot=Math.min(minimumPivot,re);L[i][j]=[Math.sqrt(re),0];}
  else L[i][j]=[re/L[j][j][0],im/L[j][j][0]];
 }
 return {positive:true,minimum_pivot:minimumPivot};
}
export function groundTarget(H,cfg){
 validateH(H);const scale=Math.max(1,...H.flat().map(abs));let lower=Math.min(...H.map((row,i)=>row[i][0]-row.reduce((s,z,j)=>s+(i===j?0:abs(z)),0)))-cfg.shift_regularization*scale,upper=Math.min(...H.map((row,i)=>row[i][0]));
 if(!positiveDefinite(H,lower).positive)throw Error('Initial lower bracket not positive definite');
 const history=[];
 for(let i=0;i<cfg.bracket_iterations&&upper-lower>cfg.bracket_tolerance*scale;i++){const mid=lower+(upper-lower)/2,test=positiveDefinite(H,mid);history.push({iteration:i+1,mid,positive_definite:test.positive});if(test.positive)lower=mid;else upper=mid;}
 const shift=lower-cfg.shift_regularization*scale,A=H.map((r,i)=>r.map((z,j)=>[z[0]-(i===j?shift:0),z[1]])),candidates=[];
 for(let j=0;j<8;j++){const e=Array.from({length:8},(_,i)=>[+(i===j),0]),solve=solveComplex(A,e),p=normalize(solve.x);candidates.push({basis:j,p,...metrics(H,p),backward_error:solve.relative_backward_error});}
 let best=candidates.reduce((a,b)=>a.energy_ev<=b.energy_ev?a:b),p=best.p;const inverse=[];
 for(let i=0;i<cfg.inverse_iterations;i++){const solve=solveComplex(A,p);p=normalize(solve.x);inverse.push({iteration:i+1,...metrics(H,p),backward_error:solve.relative_backward_error});}
 return {amplitudes:p,...metrics(H,p),bracket:{lower,upper,width:upper-lower,shift,scale,history,interpretation:'Floating-point positive-definiteness bracket; not an interval-arithmetic proof.'},basis_candidates:candidates.map(({p,...r})=>r),selected_basis:best.basis,inverse_history:inverse};
}
export function bracketedRefine(H,initial,cfg,seed){
 const target=groundTarget(H,cfg),P=target.amplitudes.map((a,i)=>target.amplitudes.map((b,j)=>{const z=mul(a,conj(b));return [(i===j?1:0)-z[0],-z[1]];})),random=rng(seed>>>0),rounds=[];let best=null;
 for(let i=0;i<cfg.fit_starts;i++){const start=i===0?initial.slice():(best?best.fit.parameters:initial).map(x=>x+(random()-.5)*cfg.perturbation_width),fit=refineBFGS(P,start,cfg.fit),fidelity=overlap(target.amplitudes,fit.amplitudes);rounds.push({start:i,fit_fidelity:fidelity,iterations:fit.iterations,gradient_norm:fit.gradient_norm,reason:fit.reason,evaluations:fit.objective_evaluations});if(!best||fidelity>best.fidelity)best={fit,fidelity};if(fidelity>=cfg.required_target_fit)break;}
 const p=best.fit.amplitudes;return {parameters:best.fit.parameters,amplitudes:p,norm:inner(p,p)[0],...metrics(H,p),target,target_fit_fidelity:best.fidelity,fit_starts:rounds,method:'Classical positive-definiteness bracket and inverse solve, followed by unchanged Q8 ansatz fitting',external_reference_used:false};
}

