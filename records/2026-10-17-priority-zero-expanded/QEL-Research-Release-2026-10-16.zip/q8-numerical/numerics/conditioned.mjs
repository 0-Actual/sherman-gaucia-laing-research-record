// Positive energy scaling and identity shifts preserve eigenspaces.
// This wrapper conditions the represented input; it cannot recover input rounding losses.
import {validateH} from './baseline.mjs';
import {groundTarget,bracketedRefine} from './bracketed.mjs';
export function conditionHamiltonian(H) {
  validateH(H);
  const offset=H.reduce((sum,row,i)=>sum+row[i][0]/8,0);
  const centered=H.map((row,i)=>row.map((z,j)=>[z[0]-(i===j?offset:0),z[1]]));
  const scale=Math.max(...centered.map(row=>row.reduce((sum,z)=>sum+Math.hypot(z[0],z[1]),0)))||1;
  if(!Number.isFinite(offset)||!Number.isFinite(scale)||!(scale>0))throw Error('Hamiltonian conditioning overflow');
  const matrix=centered.map(row=>row.map(z=>[z[0]/scale,z[1]/scale]));
  validateH(matrix);
  return {matrix,offset_ev:offset,scale_ev:scale,relation:'H = offset * I + scale * normalized_H'};
}
function wrap(normalization,prediction) {
  return {amplitudes:prediction.amplitudes,parameters:prediction.parameters,
    normalization:{offset_ev:normalization.offset_ev,scale_ev:normalization.scale_ev,relation:normalization.relation},
    normalized_prediction:prediction,
    energy_ev:normalization.offset_ev+normalization.scale_ev*prediction.energy_ev,
    residual_ev:normalization.scale_ev*prediction.residual_ev,
    method:'Centered and scaled classical bracketed target, optionally followed by unchanged Q8 ansatz fitting',
    external_reference_used:false};
}
export function conditionedTarget(H,cfg) {
  const normalized=conditionHamiltonian(H);
  return wrap(normalized,groundTarget(normalized.matrix,cfg));
}
export function conditionedRefine(H,initial,cfg,seed) {
  const normalized=conditionHamiltonian(H);
  return wrap(normalized,bracketedRefine(normalized.matrix,initial,cfg,seed));
}
