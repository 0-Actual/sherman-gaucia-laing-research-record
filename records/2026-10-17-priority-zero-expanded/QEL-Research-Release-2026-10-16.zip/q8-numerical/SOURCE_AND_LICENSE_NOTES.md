# Source identities, attribution and rights

The source map identifies every copied file using a logical private-collection
ID, relative source name and SHA-256; it does not publish laptop locators. Exact
private originals remain preserved separately. Four runner files have their
source and derivative hashes and unchanged calculation-body hashes recorded.
Five historical contracts are locator-only JSON derivatives: one device-path
value was replaced in each; other parsed data remain unchanged. Prior release
labels such as PRIVATE/HOLD/UNSIGNED remain dated historical source facts and
are not silently rewritten as current certification or permission.

The exact numerical sources attribute Sherman G. Laing / GAUCIA. GAUCIA Actual
is the primary project agent; this later portable selection and supporting
review do not backdate authorship or runtime activation. Source comments retain
the published variational quantum deflation attribution to Higgott, Wang and
Brierley and the adjoint-method attribution to Jones and Gacon. Their methods
are prior foundations, not new-invention claims by this packet.

The aluminum Wannier input and derived fixtures retain
[the CC BY 4.0 notice](notices/CC_BY_4_0_NOTICE.md), including the cited dataset
attribution and DOI. Preserve the exact
[JARVIS notice](notices/JARVIS_LICENSE.rst) and
[leaderboard notice](notices/LEADERBOARD_LICENSE.rst), their disclaimers and
[pinned source provenance](notices/upstream-source.json). They are separate
component notices, not a blanket new license for all QEL code. The owner's
review must settle the intended public reuse terms; no universal unrestricted
license or maintainer endorsement is asserted here.

Source hashes establish which bytes were retained, not authorship,
authenticated historical time, novelty, signature, certification or correctness.
No benchmark upload or submission was made by this preparation.
