# What changed, what can be reproduced, and what remains unverified

The original assessment, scorer, saved-state verifier and additional-point
analyzer used device-specific module/input locations. The new copies use only
the files supplied in this selection. The new entry point requires a fresh
explicit output directory outside the public candidate; existing output is
never reused or deleted. It does not start processes, services or listeners,
change permissions, mirror to a USB, or contact a network service.

The nine numerical modules and generic identity helper are exact copies. The
assessment's full `solveCircuit` calculation and its configuration remain
unchanged. The scorer's arithmetic and acceptance checks remain unchanged.
The saved-state verifier retains the matrix/state/energy checks and scorer
negative cases. Its in-memory scorer harness now provides only the new routing
helper in addition to the same mock filesystem/path/assert/url imports. The
additional-point analyzer keeps its conventional reference calculation and
diagnostic calculations. Local paths, output routing and an explanatory header
are the runner changes. SOURCE_MAP.json identifies the specific unchanged body
regions; it does not imply every byte of a derivative equals the original.

The original runtime/mirroring modules, controllers, service/worker code and
device-specific launch wrappers are excluded. They are not dependencies of the
selected numerical closure. The original path-dependent runner bytes and full
replacement ledger remain private. Additional-point selection is represented
by the exact frozen fixture and its historical contract; the original input
generation wrapper is not presented as a newly reproduced step.

The retained Node VM context checks the locally exposed bindings and restricts
the numerical import set. It is not operating-system network or process
isolation. Historical `PRIVATE/HOLD/UNSIGNED` fields and comments are retained
source semantics, not a new authorization requirement or an assertion that the
portable review changed an installed security hold.

Syntax checks and a dry run first established parseability and planned local
input/output resolution. The new adapter then completed its saved-state replay
on a byte-verified disposable copy with a fresh external output directory. The
24-point matrix reconstruction, 192 saved states/energies, three retained scores,
known-answer metric and eleven malformed-record rejections passed. Original and
copied source files remained unchanged. No routing repair was needed.

This is actual validation of the new saved-data route, not a rerun of the
optimizer or original experiment. Its 384 described optimization starts and
197 gradient-tolerance/187 iteration-budget stops belong to the saved historical
full run; zero optimization starts were executed by this replay. New pilot,
full, classical-control and additional-data optimization/analysis modes remain
unexecuted in this preparation. No historical timing was reproduced or new
performance claim measured. The companion counter replay and teaching fixtures
do not substitute for this numerical study.

There is no machine-lock file or bundled Node executable. The receipts identify
Node 24.20.0 and the program uses standard Node modules. The complete optional
run performs a finite but nontrivial workload; exact elapsed time and memory
are hardware/runtime observations, not portable expected constants. Numerical
comparison tolerances are those in the retained verifier. A successful replay
would validate only those declared calculations, not physical QPU behavior,
system-wide acceleration, a complete USB environment, novelty or external
certification.
