// New portable routing helper; does not load numerical modules or create outputs.
import path from 'node:path';
let configured;
export function configurePaths({packageRoot,outputRoot,outputDirectory,runDirectory,mode}) {
  for (const value of [packageRoot,outputRoot,outputDirectory,runDirectory]) {
    if (typeof value!=='string'||!path.isAbsolute(value)) throw Error('Absolute resolved paths required');
  }
  for (const target of [outputDirectory,runDirectory]) {
    const relative=path.relative(outputRoot,target);
    if (relative==='..'||relative.startsWith('..'+path.sep)||path.isAbsolute(relative)) throw Error('Result path escapes fresh output root');
  }
  configured=Object.freeze({packageRoot,outputRoot,outputDirectory,runDirectory,mode});
}
export function getPaths() {
  if (!configured) throw Error('Use run-study.mjs with an explicit fresh --output directory');
  return configured;
}
