// October 16 portable derivative: path and output routing only; historical numerical logic retained.
// Read-only replay of saved predictions; no optimizer or original lab startup.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import assert from 'node:assert/strict';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {getPaths} from './portable-paths.mjs';
const {packageRoot,outputDirectory}=getPaths();
const here=path.join(packageRoot,'expected');
const root=packageRoot;
const old=packageRoot;
const {hashBytes}=await import(pathToFileURL(path.join(root,'identity/sgl-prime.mjs')));
const read=p=>JSON.parse(fs.readFileSync(p));
const predictions=read(path.join(here,'vqd-full-v1/predictions.json'));
const fixture=read(path.join(old,'inputs/hamiltonians_24x8x8.json'));
const contract=read(path.join(here,'vqd-full-v1/contract.json'));
const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}}),modules=new Map();
for(const entry of contract.sources){
 const bytes=fs.readFileSync(path.join(root,'numerics',entry.name));
 assert.equal(hashBytes(bytes,'qel-jarvis-source'),entry.identity);
 modules.set(entry.name,new vm.SourceTextModule(bytes.toString('utf8'),{context,identifier:entry.name}));
}
assert.equal(hashBytes(fs.readFileSync(path.join(old,'inputs/hamiltonians_24x8x8.json')),'qel-jarvis-input'),contract.input_identity);
const entry=modules.get('q8-fast.mjs');
await entry.link((specifier,parent)=>{
 assert.ok(specifier.startsWith('./'));
 const name=path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),specifier));
 assert.ok(modules.has(name));return modules.get(name);
});await entry.evaluate({timeout:5000});
const base=modules.get('baseline.mjs').namespace;
const blocks=base.parseWannier(fs.readFileSync(path.join(old,'inputs/wannier90_hr.dat'),'utf8'));
let reconstruction=0,energyReplay=0,normError=0,amplitudeReplay=0,maximumResidual=0;
let maximumOverlap=0,maximumTraceError=0;
const stopReasons={};
for(const [i,row] of predictions.rows.entries()){
 assert.equal(row.index,i);assert.equal(row.bands.length,8);
 assert.equal(JSON.stringify(row.kpoint),JSON.stringify(fixture.rows[i].kpoint_fractional_reciprocal));
 const H=base.constructH(blocks,row.kpoint).h,original=fixture.rows[i].matrix_ev;
 for(let a=0;a<8;a++)for(let b=0;b<8;b++)for(let c=0;c<2;c++)reconstruction=Math.max(reconstruction,Math.abs(H[a][b][c]-original[a][b][c]));
 const states=[];
 for(const band of row.bands){
  assert.equal(band.parameters.length,18);assert.ok(band.parameters.every(Number.isFinite));
  const state=base.dense(3,base.ansatz(band.parameters));
  const energy=base.independentEnergy(original,state);
  energyReplay=Math.max(energyReplay,Math.abs(energy-band.energy_ev));
  let norm=0,residualSquared=0;
  for(let a=0;a<8;a++){
   norm+=state[a][0]**2+state[a][1]**2;
   amplitudeReplay=Math.max(amplitudeReplay,Math.hypot(state[a][0]-band.amplitudes[a][0],state[a][1]-band.amplitudes[a][1]));
   let re=-energy*state[a][0],im=-energy*state[a][1];
   for(let b=0;b<8;b++){re+=original[a][b][0]*state[b][0]-original[a][b][1]*state[b][1];im+=original[a][b][0]*state[b][1]+original[a][b][1]*state[b][0];}
   residualSquared+=re*re+im*im;
  }
  const residual=Math.sqrt(residualSquared);assert.ok(Math.abs(residual-band.residual_ev)<1e-9);
  maximumResidual=Math.max(maximumResidual,residual);normError=Math.max(normError,Math.abs(norm-1));
  for(const prior of states){let re=0,im=0;for(let a=0;a<8;a++){re+=prior[a][0]*state[a][0]+prior[a][1]*state[a][1];im+=prior[a][0]*state[a][1]-prior[a][1]*state[a][0];}maximumOverlap=Math.max(maximumOverlap,re*re+im*im);}
  states.push(state);
  for(const attempt of band.attempts)stopReasons[attempt.reason]=(stopReasons[attempt.reason]||0)+1;
 }
 assert.deepEqual(row.eigenvalues_ev,[...row.bands.map(b=>b.energy_ev)].sort((a,b)=>a-b));
 maximumTraceError=Math.max(maximumTraceError,Math.abs(row.eigenvalues_ev.reduce((a,b)=>a+b,0)-original.reduce((a,r,j)=>a+r[j][0],0)));
}
assert.ok(reconstruction<=1e-10);assert.ok(energyReplay<=1e-9);assert.ok(normError<=1e-9);assert.ok(amplitudeReplay<=2e-10);

// Exercise the actual scorer against controlled in-memory records, including bad inputs.
const scorer=fs.readFileSync(path.join(packageRoot,'runners/score-assessment.mjs'),'utf8');
const board=read(path.join(here,'scoreboard-snapshot.json'));
async function scoreInMemory(pred,receipt,reference){
 const files=new Map([
  ['predictions.json',Buffer.from(JSON.stringify(pred))],['execution.json',Buffer.from(JSON.stringify(receipt))],
  ['official_reference.json',Buffer.from(JSON.stringify(reference))],['scoreboard-snapshot.json',Buffer.from(JSON.stringify(board))]
 ]);
 const mockFs={readFileSync(p){assert.ok(files.has(path.basename(p)));return files.get(path.basename(p));},
  writeFileSync(p,bytes,options){assert.equal(options.flag,'wx');assert.ok(!files.has(path.basename(p)));files.set(path.basename(p),bytes);}};
 const ctx=vm.createContext({Buffer,process:{argv:['node','score','verification']},console:{log(){}}});
 const values={'node:fs':{default:mockFs},'node:path':{default:path},'node:assert/strict':{default:assert},'node:url':{fileURLToPath},'./portable-paths.mjs':{getPaths:()=>({packageRoot,runDirectory:'verification',outputDirectory:'verification'})}};
 const mod=new vm.SourceTextModule(scorer,{context:ctx,initializeImportMeta(meta){meta.url=pathToFileURL(path.join(here,'score-assessment.mjs')).href;}});
 await mod.link(spec=>{const exports=values[spec];assert.ok(exports);return new vm.SyntheticModule(Object.keys(exports),function(){for(const [k,v]of Object.entries(exports))this.setExport(k,v);},{context:ctx});});
 await mod.evaluate({timeout:5000});return JSON.parse(files.get('score.json'));
}
const example={material:'JVASP-816',units:'eV',mode:'full',prediction_complete:true,
 rows:Array.from({length:24},(_,index)=>({index,eigenvalues_ev:Array.from({length:8},(_,b)=>index*8+b)}))};
const exampleReceipt={state:'PREDICTIONS_FROZEN',rows:24,scalar_predictions:192};
const exampleTruth={test:{'JVASP-816':Array.from({length:192},(_,i)=>i+(i%2?2:0)).join(';')}};
const metric=await scoreInMemory(example,exampleReceipt,exampleTruth);assert.equal(metric.mean_absolute_error_ev,1);assert.equal(metric.maximum_absolute_error_ev,2);
const negativeCases=[
 ['missing point',p=>p.rows.pop()],['missing energy',p=>p.rows[0].eigenvalues_ev.pop()],
 ['duplicate point index',p=>p.rows[1].index=0],['nonfinite energy',p=>p.rows[0].eigenvalues_ev[0]=null],
 ['unsorted bands',p=>p.rows[0].eigenvalues_ev.reverse()],['wrong material',p=>p.material='JVASP-OTHER'],
 ['wrong units',p=>p.units='Hartree'],['unknown mode',p=>p.mode='unknown'],
 ['false completeness',p=>p.prediction_complete=false],['unfrozen prediction',(_p,e)=>e.state='RUNNING'],
 ['receipt count mismatch',(_p,e)=>e.scalar_predictions=191]
];
const rejections=[];for(const [name,mutate]of negativeCases){const p=structuredClone(example),e=structuredClone(exampleReceipt);mutate(p,e);await assert.rejects(()=>scoreInMemory(p,e,exampleTruth));rejections.push(name);}
const reference=read(path.join(old,'references/official_reference.json'));
const scores={};for(const label of ['vqd-pilot-v1','classical-control-v1','vqd-full-v1']){
 const pred=read(path.join(here,label,'predictions.json')),receipt=read(path.join(here,label,'execution.json'));
 const recomputed=await scoreInMemory(pred,receipt,reference),saved=read(path.join(here,label,'score.json'));
 assert.equal(recomputed.mean_absolute_error_ev,saved.mean_absolute_error_ev);assert.deepEqual(recomputed.values,saved.values);
 scores[label]={score_unchanged:true,mean_absolute_error_ev:saved.mean_absolute_error_ev};
}
const result={utc:new Date().toISOString(),status:'PASS',
 numerical_replay:{ordered_points:24,circuit_states:192,scalar_energies:192,parameters_per_state:18,optimization_starts:384,
  source_modules_unchanged:contract.sources.length,input_identity_unchanged:true,
  wannier_blocks:blocks.length,maximum_reconstructed_matrix_difference_ev:reconstruction,
  maximum_dense_replay_energy_difference_ev:energyReplay,maximum_dense_replay_amplitude_difference:amplitudeReplay,
  maximum_norm_error:normError,maximum_residual_ev:maximumResidual,maximum_pair_overlap_squared:maximumOverlap,
  maximum_trace_difference_ev:maximumTraceError,optimizer_stop_reasons:stopReasons},
 scoring:{known_answer_mae:metric.mean_absolute_error_ev,expected_mae:1,malformed_record_rejections:rejections,saved_scores:scores},
 limits:{optimizer_rerun:false,independent_implementation:'Dense gate replay and double-sum energy from existing baseline; not an independent external audit',
 physical_QPU:false,unseen_materials:false,blind_test:false,publication:false}};
const bytes=Buffer.from(JSON.stringify(result,null,2)+'\n'),destination=path.join(outputDirectory,'verification.json');
fs.writeFileSync(destination,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(destination).equals(bytes));
console.log(JSON.stringify(result));
