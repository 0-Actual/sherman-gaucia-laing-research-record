// October 16 portable derivative: path and output routing only; historical numerical logic retained.
// The official MULTIMAE implementation concatenates values and computes their mean absolute error.
// This separate scoring process runs only after predictions have been frozen.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {getPaths} from './portable-paths.mjs';
const {packageRoot,runDirectory:directory,outputDirectory}=getPaths();
const here=path.join(packageRoot,'expected'),predictionBytes=fs.readFileSync(path.join(directory,'predictions.json'));
const predictions=JSON.parse(predictionBytes),execution=JSON.parse(fs.readFileSync(path.join(directory,'execution.json')));
assert.equal(execution.state,'PREDICTIONS_FROZEN');
assert.equal(predictions.material,'JVASP-816');assert.equal(predictions.units,'eV');
assert.ok(['control','pilot','full'].includes(predictions.mode));
assert.equal(predictions.rows.length,predictions.mode==='pilot'?1:24);
assert.equal(execution.rows,predictions.rows.length);assert.equal(execution.scalar_predictions,predictions.rows.length*8);
const reference=JSON.parse(fs.readFileSync(path.join(packageRoot,'references/official_reference.json')));
const truth=reference.test['JVASP-816'].split(';').map(Number);assert.equal(truth.length,192);assert.ok(truth.every(Number.isFinite));
const values=[];for(const [i,row] of predictions.rows.entries()){
 assert.equal(row.index,i);assert.equal(row.eigenvalues_ev.length,8);assert.ok(row.eigenvalues_ev.every(Number.isFinite));
 for(let j=1;j<8;j++)assert.ok(row.eigenvalues_ev[j]>=row.eigenvalues_ev[j-1]);
 for(let band=0;band<8;band++)values.push({index:i,band,prediction_ev:row.eigenvalues_ev[band],reference_ev:truth[8*i+band],absolute_error_ev:Math.abs(row.eigenvalues_ev[band]-truth[8*i+band])});
}
assert.ok(values.length===8||values.length===192);assert.equal(predictions.prediction_complete,values.length===192);
const score=values.reduce((sum,row)=>sum+row.absolute_error_ev,0)/values.length;
const board=JSON.parse(fs.readFileSync(path.join(here,'scoreboard-snapshot.json')));
const result={utc:new Date().toISOString(),mode:predictions.mode,complete_benchmark:values.length===192,
 rows:predictions.rows.length,scalar_values:values.length,metric:values.length===192?'MULTIMAE':'PILOT_MAE_NOT_LEADERBOARD_SCORE',
 mean_absolute_error_ev:score,maximum_absolute_error_ev:Math.max(...values.map(v=>v.absolute_error_ev)),
 best_displayed_upstream_error_ev:board.rows[0].score,upstream_commit:board.commit,
 numeric_error_below_displayed_best:values.length===192?score<board.rows[0].score:null,
 official_rank:null,submission:false,eligibility_reviewed_by_maintainers:false,
 method_scope:predictions.mode==='control'?'Classical control; not a QEL variational-circuit result':'QEL circuit VQD simulation on a classical CPU; no physical quantum hardware',
 repeated_kpoints_retained:true,unseen_materials:false,blind_test:false,values};
const destination=path.join(outputDirectory,'score.json'),bytes=Buffer.from(JSON.stringify(result,null,2)+'\n');
fs.writeFileSync(destination,bytes,{flag:'wx',flush:true});assert.ok(fs.readFileSync(destination).equals(bytes));
assert.ok(fs.readFileSync(path.join(directory,'predictions.json')).equals(predictionBytes));
console.log(JSON.stringify({...result,values:undefined}));
