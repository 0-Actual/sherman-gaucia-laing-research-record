# Q8 aluminum numerical study: exact sources and portable routing

This selection supplies the actual nine-module numerical closure used by the
September 28–29 aluminum assessment, its fixed inputs, reference data and saved
results. It also supplies four clearly identified runner derivatives. Their
changes concern local input/module locations and fresh output routing; the
numerical, scoring and saved-state replay calculations retain their source
bodies. This is classical CPU computation using the Q8 circuit implementation,
not a physical quantum processor. No service/controller, USB mirror or network
operation is required.

The portable derivative was prepared on October 16, 2026. Syntax, imports,
file identities and dry-run argument/input resolution passed. A subsequent
saved-state replay on a byte-verified disposable copy also passed: it rebuilt
24 matrices from 1,041 Wannier blocks, replayed 192 saved states and energies,
matched the three saved pilot/control/full scores, and rejected eleven malformed
scorer cases. Both the copied and original sources remained unchanged.
**No optimizer, classical-control solver run or timing benchmark was executed
in this preparation.** Historical result files keep their original dates. The
new saved-state verification checks the portable adapter; it does not regenerate
the historical optimization or timing results.

Use Node.js 24.20.0 to match the runtime named in the historical execution
receipts. Node is not bundled. No npm packages are required. Floating-point
results and especially timing may vary with runtime and machine; the retained
replay assertions define their stated tolerances. The saved-state check passed
with Node 24.20.0 on Windows. Other runtimes/platforms and the optional new
optimization modes have not been executed in this preparation.

From this study directory, first inspect the exact file selection and planned
paths without loading any numerical module or creating a results directory:

```text
node run-study.mjs --mode replay --output ../q8-aluminum-results-01 --dry-run
```

When this study is inside the integrated repository's `q8-numerical` folder,
choose an output outside the whole repository, for example
`../../q8-aluminum-results-01`. The output parent must already exist and the
chosen output directory must not exist. The script rejects outputs inside the
study or its enclosing public candidate. It verifies all manifest identities
before any calculation and again after successful execution.

Run the retained verification on saved circuit parameters, amplitudes,
Hamiltonians and scores with:

```text
node --experimental-vm-modules run-study.mjs --mode replay --output ../../q8-aluminum-replay-01
```

This reconstructs matrices from the Wannier data, replays 192 saved circuit
states/energies, tests the scorer's known answer and eleven malformed-record
cases, and checks the saved pilot, full VQD and classical-control scores. It
does **not** refit the optimizer and is not an independent external audit.

To run the original full optimizer and scorer, after the same saved-data check:

```text
node --experimental-vm-modules run-study.mjs --mode full --output ../../q8-aluminum-full-01
```

`--mode control` performs the conventional Jacobi control; `--mode pilot` fits
one point; `--mode additional` fits the supplied 24 extra coordinates and then
generates their local classical reference; `--mode all` performs all four
stages after saved replay. Each invocation requires a different fresh output
directory. Failures retain partial results. No mode regenerates or overwrites
the packaged historical evidence. Additional coordinate generation is not
repeated: its exact frozen fixture and selection contract are supplied.

The original full study has 24 ordered points, eight energies per point and
192 scalar predictions, all for JVASP-816 aluminum. The original full VQD MAE
is 3.4501989767139057e-6 eV in about 20.582 seconds. The classical control MAE is
2.3408413332703937e-9 eV in about 0.911 seconds: the conventional method was
faster and more accurate. The additional-point VQD MAE is
1.2888900558943352e-6 eV in about 23.609 seconds. These times describe historical
runs, not promises for this portable adapter. Original/reference answers had
been seen; this was not blind testing, unseen-material testing, a public
leaderboard submission or evidence of quantum advantage.

The VQD runner calls direct `refineBFGS` with the penalized Hamiltonian. The
retained `q8-fast.mjs` also contains a separate classical-target hybrid path;
that path is not the assessment's VQD method. Several modules are imported
because of this static dependency closure, not because every exported routine
was used. The nine numerical modules retain exact bytes. The tenth exact code
file is a generic fingerprint helper used to verify historical source/input
identities; it is not an operational controller.

Read [SOURCE_AND_LICENSE_NOTES.md](SOURCE_AND_LICENSE_NOTES.md),
[PORTABILITY.md](PORTABILITY.md), [SOURCE_MAP.json](SOURCE_MAP.json) and
[VERIFICATION.json](VERIFICATION.json) before interpreting the results.
