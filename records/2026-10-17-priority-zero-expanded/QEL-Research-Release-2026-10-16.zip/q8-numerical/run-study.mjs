// New portable entry point. Full optimization is opt-in. No service, network or USB target.
import fs from 'node:fs';
import path from 'node:path';
import {createHash} from 'node:crypto';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {configurePaths} from './runners/portable-paths.mjs';

const packageRoot=fs.realpathSync(path.dirname(fileURLToPath(import.meta.url)));
const supported=new Set(['replay','pilot','control','full','additional','all']);
const args=process.argv.slice(2);let mode='replay',outputArgument,dryRun=false;
const seen=new Set();
for(let i=0;i<args.length;i++) {
  const flag=args[i];
  if(seen.has(flag))throw Error('Duplicate argument: '+flag);seen.add(flag);
  if(flag==='--dry-run'){dryRun=true;continue;}
  if(!['--mode','--output'].includes(flag)||i+1>=args.length||args[i+1].startsWith('--'))throw Error('Use --mode replay|pilot|control|full|additional|all --output NEW_DIRECTORY [--dry-run]');
  const value=args[++i];if(flag==='--mode')mode=value;else outputArgument=value;
}
if(!supported.has(mode)||!outputArgument)throw Error('Supported --mode and explicit --output required');

// Reject outputs inside this study or its enclosing integrated public candidate.
let candidateRoot=packageRoot;
for(let p=path.dirname(packageRoot);;p=path.dirname(p)) {
  if(fs.existsSync(path.join(p,'DISCLOSURE_REGISTER.json'))){candidateRoot=fs.realpathSync(p);break;}
  if(path.dirname(p)===p)break;
}
const proposed=path.resolve(outputArgument);
let exists=false;try{fs.lstatSync(proposed);exists=true;}catch(error){if(error.code!=='ENOENT')throw error;}
if(exists)throw Error('Output already exists; choose a fresh directory');
const parent=fs.realpathSync(path.dirname(proposed));
if(!fs.statSync(parent).isDirectory())throw Error('Output parent must already be a directory');
const outputRoot=path.join(parent,path.basename(proposed));
const relative=path.relative(candidateRoot,outputRoot);
if(relative===''||(!relative.startsWith('..'+path.sep)&&relative!=='..'&&!path.isAbsolute(relative)))throw Error('Output must be outside the complete public candidate');

function verifyManifest() {
  const manifest=JSON.parse(fs.readFileSync(path.join(packageRoot,'MANIFEST.json'),'utf8'));
  const paths=new Set();
  for(const row of manifest.files) {
    if(typeof row.path!=='string'||row.path.includes('\\')||row.path.includes(':')||row.path.startsWith('/')||row.path.split('/').some(x=>!x||x==='.'||x==='..')||paths.has(row.path))throw Error('Unsafe or duplicate manifest path');
    paths.add(row.path);const file=path.join(packageRoot,row.path);
    if(fs.lstatSync(file).isSymbolicLink()||!fs.statSync(file).isFile())throw Error('Source must be a regular file');
    const real=fs.realpathSync(file),rel=path.relative(packageRoot,real);
    if(rel.startsWith('..'+path.sep)||rel==='..'||path.isAbsolute(rel))throw Error('Source escapes package');
    const bytes=fs.readFileSync(file);
    if(bytes.length!==row.bytes||createHash('sha256').update(bytes).digest('hex')!==row.sha256)throw Error('Source identity mismatch: '+row.path);
  }
  const actual=[];
  function walk(folder,prefix='') {for(const item of fs.readdirSync(folder,{withFileTypes:true})) {
    if(['.git','__pycache__'].includes(item.name))continue;
    const rel=prefix+item.name;if(item.isSymbolicLink())throw Error('Symbolic links not allowed');
    if(item.isDirectory())walk(path.join(folder,item.name),rel+'/');else if(item.isFile()&&rel!=='MANIFEST.json')actual.push(rel);
  }}
  walk(packageRoot);if(actual.length!==paths.size||actual.some(p=>!paths.has(p)))throw Error('Study file set differs from manifest');
  return paths.size;
}
const sourceFiles=verifyManifest();
const inputs=JSON.parse(fs.readFileSync(path.join(packageRoot,'inputs/hamiltonians_24x8x8.json'),'utf8'));
const additional=JSON.parse(fs.readFileSync(path.join(packageRoot,'inputs/additional-hamiltonians_24x8x8.json'),'utf8'));
const reference=JSON.parse(fs.readFileSync(path.join(packageRoot,'references/official_reference.json'),'utf8'));
if(inputs.material_id!=='JVASP-816'||inputs.rows.length!==24||additional.rows.length!==24||reference.test['JVASP-816'].split(';').length!==192)throw Error('Input-resolution contract mismatch');
const plannedModes=mode==='all'?['pilot','control','full','additional']:mode==='replay'?[]:[mode];
const plan={state:'DRY_RUN_INPUTS_RESOLVED',mode,source_files_verified:sourceFiles,output_directory:outputRoot,saved_replay_planned:true,optimizer_modes:plannedModes.filter(x=>x!=='control'),classical_control_planned:plannedModes.includes('control'),physical_QPU:false,network_or_service_operation:false,numerical_module_loaded:false,output_created:false};
if(dryRun) {
  console.log(JSON.stringify(plan,null,2));
} else {
  if(!process.execArgv.includes('--experimental-vm-modules'))throw Error('Run Node with --experimental-vm-modules; inspect README.md first');
  fs.mkdirSync(outputRoot);const started=new Date().toISOString();
  const write=(name,value)=>fs.writeFileSync(path.join(outputRoot,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
  try {
    const replay=path.join(outputRoot,'saved-replay');fs.mkdirSync(replay);
    configurePaths({packageRoot,outputRoot,outputDirectory:replay,runDirectory:replay,mode:'replay'});
    await import(pathToFileURL(path.join(packageRoot,'runners/verify-assessment.mjs')).href);
    for(const currentMode of plannedModes) {
      const run=path.join(outputRoot,currentMode);
      configurePaths({packageRoot,outputRoot,outputDirectory:run,runDirectory:run,mode:currentMode});
      await import(pathToFileURL(path.join(packageRoot,'runners/run-assessment.mjs')).href+'?mode='+currentMode);
      const scorer=currentMode==='additional'?'analyze-additional-data.mjs':'score-assessment.mjs';
      await import(pathToFileURL(path.join(packageRoot,'runners',scorer)).href+'?mode='+currentMode);
    }
    verifyManifest();
    write('RUN_SUMMARY.json',{state:'PASS',started_utc:started,completed_utc:new Date().toISOString(),node:process.version,source_files_verified:sourceFiles,saved_state_replay_completed:true,optimizer_modes:plannedModes.filter(x=>x!=='control'),classical_control_executed:plannedModes.includes('control'),source_files_unchanged:true,physical_QPU:false,network_or_service_operation:false,comparison_note:'New runtime timings are not expected to equal historical timings; consult the independent saved score/control limits.'});
  } catch(error) {
    write('RUN_FAILURE.json',{state:'FAILED_WITH_PARTIAL_OUTPUTS_PRESERVED',message:String(error.message),at_utc:new Date().toISOString()});
    throw error;
  }
}
