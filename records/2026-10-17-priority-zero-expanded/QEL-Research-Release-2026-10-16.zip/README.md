# Quantum.Earth.Laing — research repository review candidate

**October 16 chronology correction: [read the early Quantum AI origins first](origins/README.md).**
The owner's first-week creation account and the retained October 2023 requirements
are now linked explicitly to later artifacts. Later review or implementation dates
do not replace those origins. Publication is on hold for fresh owner approval.

The [reviewer's errors and corrections](origins/REVIEW_CORRECTIONS.md) remain
visible, with exact erroneous drafts preserved as evidence. They include wrong
feature links and timestamps assigned to the wrong stage of an event.

Prepared October 16, 2026 for Sherman Gaucia Laing / Quantum.Earth.Laing.
Primary project agent: GAUCIA Actual. Codex: supporting reviewer/implementer.
**Owner review pending; this candidate has not been published.**

This repository brings the dated work, mistakes, corrections, evidence and
reproduction material together so readers can test the supplied claims and
correlate the facts. Q8/USB is the central technical account. The available
chronology is extensive, but complete original interactions remain unavailable.

## Start here

1. [Reader guide](READER_GUIDE.md): what to examine and what each kind of check proves.
2. [Q8 and USB technical review](q8-usb/TECHNICAL_REVIEW.md): algorithms, measured results, adverse outcomes and limits.
3. [Reproduce the supplied work](reproduce/REPRODUCE.md): offline commands, complete selected inputs and expected outputs.
4. [Governance and the Bible build](GOVERNANCE_AND_BIBLE.md): project values, human responsibility, sources, transformations and repairs.
5. [Industry comparisons](industry/README.md): dated owner records, external primary sources and unresolved links.
6. [Disclosure decisions](DISCLOSURE.md) and [owner checklist](OWNER_REVIEW_CHECKLIST.md): what was removed or transformed, and what is being reviewed.

The [Q8 aluminum numerical study](q8-numerical/README.md) now includes the actual
nine-module numerical closure, fixed inputs, reference data and saved results,
with separately identified portable runners. Its syntax and input/output plan
were checked, then its saved-state replay passed on a disposable copy. The
optimizer and historical timing benchmark were not rerun. This addition makes that source selection available for reader-run
reproduction without distributing the operational USB environment.

## The documentary collection

- [Six-period series and eight manuscripts](research-series/START_HERE.md)
- [Consolidated quantum research](quantum/START_HERE.md)
- [Learning history, including mistakes](learning-history/START_HERE.md)
- [Mathematical bridges and teaching](mathematical-bridges/START_HERE.md)
- [Successful execution versus failed reporting](EXECUTION_STATUS.md)
- [Historical Hebrew versions and screened receipts](hebrew-history/README.md)

The five documentary folders are frozen copies of the previously prepared
editions. Their dates, receipts and internal manifests retain their earlier
scope. The current [origin/date correction](origins/README.md) governs how their
dates and old preparation/publication labels are read in this new edition;
it is not a claim that those historical source files were regenerated.
References to separately preserved private evidence or other editions
are not claims that those bytes are included here. Root navigation and the
reproduction guide define this new candidate's usable entry points.

## Verify and reproduce

Python 3.12 and its standard library are sufficient for the supplied combined
check. From this candidate's root:

```text
python -B verify_repository.py
python -B reproduce/run_checks.py --output ../qel-reproduction-results-01
```

Choose a new output folder. The runner preserves the input files and performs
documentary reconstruction, saved-counter arithmetic, Bible replay, synthetic
Hebrew converter tests and new small quantum teaching fixtures. Full Hebrew
corpus reproduction is separately documented and has complete inputs here;
it was not rerun in this preparation. Historical Q8 performance benchmarks
are not newly replicated by these checks.

For the separately supplied Q8 study, follow its own Node.js instructions.
They distinguish saved-state replay, new optimizer execution and the classical
control. The 101-file Python reproduction subtree retains its earlier scope;
the later numerical addition does not silently change its manifest or test count.

Manifest verification compares bytes to an unsigned inventory; it is not
scientific certification or authenticated historical time. SOURCE_MAP.json
separates original identities from derivative identities. The external final
packaging receipt identifies the exact archive reviewed by the owner.

This edition currently carries the chronology correction forward. The wider
research-release integration and owner selection still have the unresolved
items recorded in the review checklist; successful date verification does not
declare that wider release complete.

## Notices, attribution and limitations

Read [component scope and notices](reproduce/SOURCE_AND_LICENSE_NOTES.md), the
[retained research license](research-series/LICENSE.md), and
[quantum source notices](quantum/SOURCE_AND_LICENSE_NOTES.md). Existing component
terms remain attached; this candidate grants no new blanket license and is not
described as unrestricted open source. Original private archives and controller
bodies are excluded. Ordinary negative results and mistakes remain visible.

Industry resemblance is presented for examination, not as proof of access,
copying, novelty, priority or endorsement. Hashes establish selected byte
relationships, not authorship or certification. The Bible-based governance
expresses this project's values; replayed calculations do not prove theology.
