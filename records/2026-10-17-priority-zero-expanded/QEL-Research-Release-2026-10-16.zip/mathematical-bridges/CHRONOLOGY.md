# Mathematical bridges in the recorded research

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting reviewer: Codex.

This map preserves the owner's question about mathematical bridges, optimization leaps and possible new mathematics as a question to investigate. It identifies five substantive connections in the located record. A connection can be valuable as a corrected formulation, implementation, counterexample or measured improvement without establishing a new mathematical theorem.

The five chains are editorial cross-references among overlapping records, not five independently proved discoveries. They do not reconstruct missing conversations or prove that one discussion caused every later implementation. This preparation read existing summaries, source indexes and selected saved receipts; it ran no research program and accessed no USB. The private locator companion preserves exact paths, source-row identities and SHA-256 values. No posting has occurred.

## 1. Coherence labels → projective geometry → stable numerical state comparison

**What connects.** This chain joins the project's early complex-state/coherence vocabulary to a precise distinction between a vector's scale, its physical state ray, basis-dependent coherence and numerical distance. The later correction connects those definitions to floating-point arithmetic. It is more substantive than changing the algorithm's label: a mathematically equivalent expression can behave differently near the limits of a computer's number representation.

| Recorded date and precision | Stage and source |
|---|---|
| March 13, 2025, `13:06:56.253697-04:00`; fractional-second timestamp as recorded | `CODE-DATE-18` dates the coherence-labelled historical source. `QEL-SER-C171` describes the related radial-rescaling family, with its own earlier timestamp. These are source metadata, not original run receipts. |
| August 26, 2026; day only | `QEL-SER-C278` reviews the gap between the historical names and actual mechanisms. A later corrective review does not backdate its conclusions or implementation to March. |
| September 4–5, 2026; package/report interval | `QEL-SER-C288`, `QEL-PW-0350` and the retained C002 records describe the v2.1→v2.2 numerical repair. `precision_results.json` has a cycle label but no execution timestamp; an exact start/end cannot be assigned from that file. |

**Prior work and correction.** A global rescaling can change norm while leaving the normalized state ray unchanged. It therefore does not by itself demonstrate preserved coherence. The corrected reference separates unitary evolution, density-matrix coherence, open-system channels and phase-invariant distance. Its numerical parent also overflowed or underflowed when normalizing extreme but finite components.

The successor scales real and imaginary components before normalization. For distance it uses the orthogonal projection residual `r = b − a·(<a,b>/<a,a>)`, followed by `||r||/||b||`, rather than subtracting a fidelity close to one from one. The exact-arithmetic relation is the sine distance between state rays; numerical stability remains a separate question.

**What is demonstrated.** The saved receipt retains 108 inherited methods and 12 earlier boundary methods passing both versions. The parent fails 13 of 22 new precision methods; the successor passes all 22. The 142 candidate passes are method counts, not mathematical discoveries. Structured tiny-perturbation examples do not prove universal accuracy at `1e−300`.

**Proof and novelty status.** The record supports a concrete numerical repair and a better alignment between mathematical definitions and code. It does not establish a new projective metric, general floating-point error bound, measured physical coherence extension or novelty priority. The exact earlier document-object bytes remain distinct from the preserved v2.1 body and the explicitly labelled forensic successor. This is an appropriate place to explain a useful implementation contribution without calling it new mathematics.

## 2. Entropy-control vocabulary → affine channels → a corrected fixed point

**What connects.** This chain links density matrices and channel composition to an elementary fixed-point equation, then to a numerical recipe that survives very small positive parameters. It also separates three questions that had been conflated: whether the fixed point is unique, how fast iteration approaches it, and whether one floating-point update can resolve that change.

| Recorded date and precision | Stage and source |
|---|---|
| March 13, 2025, `13:05:51.660937-04:00`; fractional-second timestamp as recorded | `CODE-DATE-17` dates the historical entropy-labelled source. |
| August 20, 2026; day only | `QEL-PW-0325` separates von Neumann, measurement and subsystem entropy and preserves the achieved-versus-target discrepancy. |
| September 5, 2026, `00:56:01.683802+00:00`; receipt timestamp to six fractional digits | `entropy_results.json` records the standalone successor's result. This is September 4 at 20:56:01.683802 EDT, so the September 4 package label and September 5 UTC receipt are compatible. `QEL-SER-C301` and `QEL-PW-0366` provide day-level chronology links. |

**Prior work and correction.** The declared model applies depolarization and then target replacement:

`F(ρ) = (1−η)(1−p)ρ + (1−η)p I/2 + ητ`.

For `0 ≤ p, η ≤ 1` and a target density matrix `τ`, the fixed point is unique when `p` and `η` are not both zero. When both are zero the map is the identity. A previous numerical threshold treated a sufficiently small denominator as nonunique, turning a representation problem into the wrong mathematical classification.

The successor rescales the weights before division. It avoids losing the result through subtraction of nearly equal numbers or premature underflow. Equal smallest positive binary64 parameters and the specified pure-zero target give the saved diagonal result `(0.75, 0.25)`.

**What is demonstrated.** The receipt reports 13 passing methods, including a 760-digit Decimal reference over ten parameter pairs, 72 channel-invariance subcases and 100 seeded density subcases. Those subordinate populations are not added to produce a larger independent-test count. The receipt explicitly says the complete original module was not executed and deployment was not performed.

**Proof and novelty status.** The affine equation provides a clear mathematical argument under the stated model; the saved tests support the bounded implementation. Uniqueness does not prove useful convergence speed, physical entropy reduction or thermodynamic efficiency. The full historical 662-line module is unavailable in this selection. No new fixed-point theorem or novelty priority is established. The contribution supported here is correcting a mathematical/numerical boundary and implementing it robustly.

## 3. SAT repair → energy representation → counterexamples and proof obligations

**What connects.** The SAT sequence connects a discrete violation count, a diagonal Hamiltonian representation and expected energy under a canonical product-state model. It then asks whether repair or rounding can find a satisfying assignment. Representing the objective correctly and searching it efficiently are different mathematical obligations; an energy formulation does not supply the missing search guarantee.

All timestamps below are the exact recorded UTC labels in the public prior-work catalogue. They end in `:00` and should be read as the recorded event labels, not newly authenticated execution times or finer-duration measurements.

| September 19, 2026 UTC label | Stage and source |
|---|---|
| `04:53:00Z` | `QEL-PW-0399`: the contract requires arbitrary encoded 3-SAT, correctness, worst-case bit cost, precision, readout and UNSAT obligations. The logarithmic-branch resource bound remains conditional. |
| `05:24:00Z` | `QEL-PW-0400`: Study001 preserves a satisfiable four-variable/eight-clause local minimum. One violation at the starting state becomes two at every one-bit neighbor, defeating the greedy repair rule. |
| `05:54:00Z` | `QEL-PW-0401`: Study002 reports bounded false-clause branching with `O(3^k poly(N))` cost, a distance argument and 18,590 retained oracle queries. The unrestricted polynomial-time claim remains open. |
| `06:03:00Z` | `QEL-PW-0402`: Study003 links Boolean violations, a diagonal clause Hamiltonian and canonical product-state expected energy. Its separate populations are 384 formulas, 4,096 assignments and 4,608 expectation checks. Repeated-literal handling required correction. |
| `06:25:00Z` then `06:26:00Z` | `QEL-PW-0403–0404`: a mixed five-track study is followed by exact-rounding and clause-edge corrections. The candidate returns 370 SAT witnesses, UNKNOWN on 14 UNSAT inputs and a connected 12-variable counterexample after 379 starts. |

**Prior work and correction.** The meaningful progression is from a proposed greedy rule to an explicit counterexample, then a bounded algorithm with a stated parameter cost, and finally a representation/rounding formulation whose edge cases remain visible. Counterexamples are useful mathematical results because they exclude a proposed general claim; they do not show that every related bounded method is worthless.

**Proof and novelty status.** The inspected summaries report representation equivalence, bounded arguments and counterexamples. Full original Study001–004/SAT packages and original conversations are not acquired in this collection, so this chronology cannot claim an independent proof audit of them. UNKNOWN is not an UNSAT certificate. No unrestricted SAT solver, P-versus-NP result or novel general search theorem is established. The potentially publishable contribution is a source-bounded record of the attempted bridge, its assumptions and its negative results, with proof-level claims kept conditional pending original-source review.

The September 20 day-level `QEL-PW-0408` proof-obligation summary reinforces this discipline: it retains corrections concerning regularity assumptions, infinite signed integrals, rounded bounds and effective certificates. It does not close those obligations merely by listing them. `QEL-PW-0410` similarly preserves requirement-to-implementation mismatches; a name-derived vector is not owner authentication and a dimensionless array is not physical energy.

## 4. Dense state capacity → sparse representation → a workload-specific scale increase

**What connects.** This chain connects the mathematical support of a state to the resources needed to store it. A general dense state vector and a two-amplitude GHZ state are very different objects even when both are labelled by a qubit count. A higher count achieved by changing representation is useful when the intended workload fits that representation.

| Recorded date and precision | Stage and source |
|---|---|
| September 18, 2026; day-level chronology | `QEL-PW-0392` records dense GHZ forward/inverse and structured full-support workloads. The preserved dense collection contains the contracts, source and result records. |
| September 18, 2026, `23:40:17.343Z`; millisecond resource-snapshot label | The final `result_22_1.json` records the pre-allocation resource observation for the refused 22-qubit request. It is an admission snapshot, not a failed executed circuit or a universal hardware maximum. |
| September 19, 2026; day-level chronology | `QEL-PW-0393` reports a sparse BigInt/complex-amplitude 60-qubit GHZ candidate with two populated amplitudes and 66 native assessment tests. This chain's evidence for that result is the historical summary; it does not silently substitute a later source for the exact original sparse assessment. |

**Prior work and correction.** The dense implementation uses two Float64 arrays, or `16 × 2^n` state bytes. Its preserved sequence includes an initial reserve stop, a double-reservation correction and removal of resident-supervisor overhead before the later admitted sizes. Twenty-five trials complete sizes 1–21 with 225 repeated evaluations of nine checks. At 21 qubits the state occupies 32 MiB. The next size needs 64 MiB plus the fixed 256 MiB reserve and is refused under the observed load.

The sparse result represents a 60-qubit GHZ state using only the two nonzero basis amplitudes. That is a different resource regime, not evidence that the laptop now stores all `2^60` amplitudes. The chronology supports explaining the change of representation; it does not prove that the dense memory stop directly caused the later sparse design. This narrative linkage remains editorial.

**Proof and novelty status.** The dense storage relation and the GHZ support structure make the distinction intelligible. The records support workload-specific capacity and a separately bounded sparse result. They do not establish arbitrary dense 60-qubit capacity, a general efficient simulator, physical quantum hardware or a new complexity result. Novelty of the representation is not established by these sources. Any additional SOP/MPS claims must retain their own exact source dates and truncation/error boundaries rather than being attached to the September 19 summary by name alone.

## 5. Wannier matrices → three-qubit variational energy → faster implementation with unchanged answers

**What connects.** This Q8-related chain joins a materials representation to an eight-dimensional numerical Hamiltonian, then to a three-qubit state-vector ansatz and constrained optimization. The next bridge is computational: avoid repeated trigonometric work and unnecessary history storage while preserving the fitted answers. These are connected stages, not interchangeable claims of quantum advantage or new mathematics.

| Recorded time and precision | Stage and source |
|---|---|
| September 29, 2026, `01:14:37.182Z`; millisecond contract label | `vqd-full-v1/contract.json` identifies the original full assessment. This is September 28 at 21:14:37.182 EDT; it is the contract's timestamp, not automatically the optimizer's start or finish. |
| `01:19:28.112Z`; millisecond verification label | `verification.json` records the saved numerical reconstruction and scoring checks. |
| `02:12:31.070Z`; millisecond benchmark-result label | `benchmark-results.json` preserves the first rewrite's unfavorable timing. |
| `02:20:03.206Z` and `02:45:43.686Z`; millisecond benchmark-result labels | `benchmark-results-v4.json` and `benchmark-results-audit-v1.json` preserve the accepted improvement and later audit batch. All are September 29 UTC / September 28 EDT. |

**Prior work and correction.** The assessment constructs 24 ordered aluminum k-point matrices with eight orbitals, giving 192 energy predictions. A three-qubit, 18-angle ansatz fits successive states with overlap penalties. The inspected synthesis attributes the variational deflation and adjoint methods to prior published methods; the history does not convert their use into a new-invention claim. The assessment's optimizer receives penalized Hamiltonians rather than reference answer vectors, which distinguishes this path from a separate retained target-assisted hybrid routine.

The ordinary Jacobi control is both faster and more accurate on the original small problem: approximately `2.34084e−9` eV MAE in 0.911 seconds, compared with approximately `3.45020e−6` eV in 20.582 seconds for the variational path. One hundred eighty-seven of 384 original optimization starts hit the iteration budget. These limits remain part of the result.

The later implementation reuses per-angle sine/cosine values during the adjoint pass and removes unused per-iteration history. The objective, initialization, BFGS arithmetic and stopping rules remain aligned with the retained workload. The first rewrite is 52% slower. Later old/new/new/old batches preserve all 192 energy and parameter outputs exactly while reducing median workload wall time by 17.1% and 13.3%; both miss the declared 20% target. Each batch has only two observations per version. The separate near-instant cache path retrieves a prior result and is not a new solve.

**Proof and novelty status.** The record supports an implemented connection among established models and a measured improvement in this software workload. It does not establish a new variational theorem, optimizer, general speed guarantee, physical quantum advantage or Windows-wide acceleration. Good energy error alone is not a proof that every approximate state is converged. Additional same-material points extend aluminum coverage; they do not establish blind cross-material generalization.

## How to describe the possible contribution

The strongest supported account is that the project repeatedly connected a stated requirement to a mathematical object, found where the implementation or inference broke, and preserved a corrected, more testable version. The most concrete results in this selection are numerical repairs, explicit counterexamples, declared model boundaries, reproducible output identities and bounded software improvements.

“Possible new mathematics” remains a research question. These sources do not establish novelty merely because an expression was newly derived in the project or connected two existing domains. A defensible stronger claim would need the precise new statement and assumptions, a complete proof or properly delimited conjecture, and comparison with prior work. No novelty search or fresh proof certification was performed for this chronology.

The source register below binds the reviewed documentary inputs and selected receipts. Hashes establish file identity; they do not establish correctness, trusted event time, ownership or priority. The source populations overlap. A record absent from the pinned main timeline may still exist in its prior-work appendix; the saved snapshot is not a claim about the current remote repository.

<!-- SOURCE_IDENTITIES -->

| Source ID | Reviewed source | SHA-256 |
|---|---|---|
| SRC-C | Frozen chronology projection | `4986a23a669feae7c99fd1133bc0ea7c10660697e668e516d92c6c6a721712b4` |
| SRC-T | Pinned main timeline | `7c6f831b0574a7ed5743fec37f005a885e51dc2016206abff139ca85a98d0735` |
| SRC-P | Pinned prior-work catalogue | `b3094f255109ade62560608a409e58f1ccf16895c3efffe07c20db23eec49f2f` |
| SRC-CHAINS | Existing research development chains | `b7c079dba13672c31b27d87ed2b5a74bab9551cdf5284a10214a984151360c5c` |
| SRC-TECH | Existing computational research synthesis | `c122586a64f74573d70e96436d785313316fc26a5cf3f50103e245b0d72a9504` |
| SRC-INDEX | Private computational source index | `61373f53713fff719608a8a7d1d41b6634ffc0495102c3dfa02028da3f2da280` |
| SRC-NUM | C002 normalization/projective-distance result | `bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115` |
| SRC-ENT | Entropy fixed-point result | `fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e` |
| SRC-AL-CONTRACT | Aluminum full-assessment contract | `fccc816facff1b120d3dc2c212afe33e0f7f664ea60af962157ab2de91686e10` |
| SRC-AL-CHECK | Aluminum retained numerical verification | `c5a847c26b3ae90a1cf058f9693b562dbd05e2efde37db806d3b94395e70005a` |
| SRC-PERF-FIRST | First, slower optimizer benchmark | `4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f` |
| SRC-PERF-V4 | Accepted optimizer benchmark | `f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12` |
| SRC-PERF-AUDIT | Later optimizer benchmark audit | `3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a` |
| SRC-DENSE | Dense 22-qubit pre-allocation admission record | `c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc` |
