"""Check this edition's listed file identities; execute no research code."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
failures = []
for item in manifest['files']:
    path = (root / item['path']).resolve()
    if not path.is_relative_to(root) or not path.is_file():
        failures.append(item['path'])
        continue
    data = path.read_bytes()
    if len(data) != item['bytes'] or hashlib.sha256(data).hexdigest() != item['sha256']:
        failures.append(item['path'])
print(json.dumps({'status': 'PASS' if not failures else 'FAIL',
                  'listed_payload_files': len(manifest['files']),
                  'failures': failures,
                  'scope': 'Byte identities only; manifest excludes itself.'}))
raise SystemExit(1 if failures else 0)
