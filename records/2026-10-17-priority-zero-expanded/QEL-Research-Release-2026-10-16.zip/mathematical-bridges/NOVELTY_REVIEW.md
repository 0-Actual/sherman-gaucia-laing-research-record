# What would establish a new mathematical contribution?

The owner's wording was tentative: “probably even discovered new math.” This
edition preserves that possibility as a question to investigate. It does not
announce a new theorem or infer novelty from a speedup, unfamiliar terminology,
file hash or the absence of a matching result in a limited search.

The six foundation references show that several central ingredients already
have established formulations: sums of products, matrix product states,
deflation by overlap penalties, clause-energy mappings, scaled norm evaluation
and energy/gap overlap bounds. Their presence does not decide whether a precise
combination, implementation or additional proposition contributes something new.

| Proposed contribution type | What must be specified | Evidence needed before the stronger claim |
|---|---|---|
| New identity or theorem | Exact statement, quantifiers, domain, hypotheses and difference from known results | A complete valid proof, edge-case analysis and comparison with the closest literature |
| New algorithm | Inputs, outputs, steps, termination, correctness and claimed cost | Proof or explicitly limited guarantee, appropriate complexity accounting and prior-method comparison |
| Faster implementation | Exact old/new versions, objective, environment and workload | Fair timings, preserved answers, adverse results, resource definitions and repeatability |
| Useful mathematical connection | Both source formulations and the transformation between them | Derivation, assumptions, examples and attribution; novelty assessed separately |
| New teaching explanation | Learning objective, derivation, examples and known misconception | Mathematical review and clearly stated educational scope |

For this edition, no candidate is promoted to “established new mathematics.”
This is a statement about the scope and evidence of this review, not a proof
that the broader archive contains no original result. The bridge catalogue
identifies places where a precise contribution can be formulated and reviewed.

Use this claim record when a concrete candidate is selected:

- Candidate ID and exact proposition:
- Author/source evidence and earliest supported date:
- Definitions, domain, quantifiers and assumptions:
- Closest established statements and precise difference:
- Derivation or proof, including dependencies:
- Counterexamples sought and excluded cases:
- Implementation and reproduction materials, if applicable:
- Independent review findings and unresolved objections:
- Literature-search scope and date:
- Present label: conjecture / proof proposed / proof reviewed / novelty unresolved:

Do not prefill these fields with stronger claims than the evidence supports.
An absent field remains a gap. Owner review still precedes publication.
