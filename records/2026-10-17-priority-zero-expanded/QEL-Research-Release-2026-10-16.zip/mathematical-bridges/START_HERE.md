# Mathematical bridges — teaching and review edition

Prepared for Sherman Gaucia Laing / Quantum.Earth.Laing. GAUCIA Actual is the
primary project agent; Codex supports review and preparation. October 16, 2026.

The purpose is to explain how the mathematics connects to the implementation,
what the optimization changed, and what the evidence establishes. Q8 and the USB
remain the central technical subject within the broader research history.

1. Start with the [listening edition](READ_ALOUD.md).
2. Work through [five mathematical lessons](WORKED_BRIDGES.md), including
   derivations, concrete examples and failure boundaries.
3. Use the [eight-bridge catalogue](BRIDGE_CATALOGUE.md) and its
   [structured source map](technical-map.json) to identify preserved code,
   source hashes, results and limits.
4. Follow the [five chronology chains](CHRONOLOGY.md) to keep earlier mistakes,
   later corrections and date precision visible.
5. Consult [six primary or official foundations](FOUNDATIONS.md) and the
   [reference register](FOUNDATION_SOURCES.json) for established background.
6. Apply the [teaching standard](TEACHING_STANDARD.md),
   [novelty review](NOVELTY_REVIEW.md) and [owner checklist](OWNER_REVIEW_CHECKLIST.md)
   before selecting public claims and files.

The eight bridges, five chronology chains and five lessons overlap. They are
editorial teaching units, not counts of independent studies or new discoveries.
Seven catalogue bridges have preserved code and receipts; the SAT bridge is
supported here by documentary summaries, with original implementation/proof
materials still unavailable. The foundations are a targeted reference review,
not an exhaustive novelty search.

Mathematical equivalence, finite numerical agreement, optimizer convergence,
runtime improvement, novelty and historical authorship require different
evidence. None is automatically established by the others. This edition does
not claim a new theorem or certify the whole research archive.

## Evidence and reproduction scope

The earlier research, quantum, Q8/USB and learning-history editions remain
unchanged. `RELATED_EDITIONS.json` identifies them from their saved verification
receipts; this edition did not repeat their archive verification or experiments.
Original source trees remain in the earlier private evidence collections. The
new private companion contains preparation records, source locators and review
receipts; it is not a duplicate of every original source tree.

The public manifest binds the files in this edition and excludes itself.
Run `python verify_manifest.py` to check listed file identities after extraction.
That utility reads bytes; it does not execute the historical algorithms or
demonstrate experimental repeatability. The mathematical examples were reviewed
algebraically. No historical program, benchmark, installation or USB operation
was rerun. The new packages are saved on the laptop; their USB copies remain
unverified. Raw interaction gaps remain explicit in the earlier editions.

Owner review of the exact final files precedes publication. Nothing was uploaded.
