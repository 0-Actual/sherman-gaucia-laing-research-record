# From mathematical idea to responsible explanation

These five lessons connect the retained project work to explicit mathematics.
The derivations and small examples were written for this teaching edition;
they are not newly executed research experiments. Read [the teaching standard](TEACHING_STANDARD.md)
for claim labels and [the source catalogue](BRIDGE_CATALOGUE.md) for historical
versions, source identities, dates and correction chains.

## 1. A change in scale is not necessarily a change in state

**Starting point.** A pure state is represented by a nonzero complex vector
\(x\in\mathbb C^d\). Its normalized representative is
\(\psi=x/\|x\|_2\). The zero vector does not define a pure state.

**Bridge.** For any nonzero complex scalar \(a\),

\[
\frac{ax}{\|ax\|_2}=\frac{a}{|a|}\frac{x}{\|x\|_2}.
\]

The prefactor has unit magnitude and is a global phase. The density matrix
\(\rho=\psi\psi^\dagger\) is unchanged. Uniformly shrinking a nonzero vector
and normalizing it again therefore does not establish decoherence, loss of
entanglement, or physical cooling. Those claims require the relevant state
operation, observable or physical model.

**Worked example.** Both \((3,4)\) and \((6,8)\) normalize to
\((3/5,4/5)\). Their raw squared norms differ, but the normalized state is the
same. A norm called “energy” in code does not automatically become the physical
expectation \(\langle\psi,H\psi\rangle\).

**Bridge to stable code.** Directly squaring very large components can overflow.
For finite input, choose
\(m=\max_j\{|\operatorname{Re}x_j|,|\operatorname{Im}x_j|\}>0\), set
\(y=x/m\), and normalize as \(y/\sqrt{\sum_j|y_j|^2}\).
In exact arithmetic this is the same normalized vector, while the scaled
components avoid the original large-square problem. Computing a large norm and
then dividing can still fail if that norm cannot be represented; direct scaled
normalization avoids requiring that final large norm. Stable sum-of-squares
methods are established numerical analysis; the precise project repair and
its checks must be credited separately.

Foundation: [LAPACK's scaled sum-of-squares method](https://netlib.org/lapack/explore-html/d8/d76/group__lassq_gae8f40b0a34771b4f2d9c863de3af7be5.html).

**Failure cases and checks.** Reject zero and nonfinite inputs explicitly.
Floating-point rounding, small-component underflow and implementation bugs still
need analysis. Test norm, finiteness and scale invariance over the stated input
domain; a handful of successes does not prove universal robustness. Historical
radial/coherence wording and later normalization repairs belong beside this lesson.

## 2. Energy accuracy connects to state accuracy through a gap

**Starting point.** Let \(H\) be a finite Hermitian matrix with ground energy
\(E_0\), ground-eigenspace projector \(P_0\), and a positive gap \(\Delta\)
from that eigenspace to the rest of the spectrum. Let \(\psi\) be normalized.
Define \(E=\langle\psi,H\psi\rangle\) and
\(p_0=\langle\psi,P_0\psi\rangle\).

**Derivation.** Expand \(\psi\) in an orthonormal eigenbasis. Every component
outside the ground eigenspace has energy at least \(E_0+\Delta\). Therefore

\[
E\ge E_0p_0+(E_0+\Delta)(1-p_0),\qquad
p_0\ge\max\!\left(0,1-\frac{E-E_0}{\Delta}\right).
\]

Trial energy is an upper bound on the ground energy. The ground energy is a lower
bound on trial energies. These are two descriptions of the same ordering.

Foundation: [Hangleiter and colleagues, energy/gap overlap bound](https://arxiv.org/html/1602.00703v4).

**Worked example.** In arbitrary consistent energy units, take
\(H=\operatorname{diag}(0,2)\) and
\(\psi=(\sqrt{0.99},0.1)\). Then \(E=0.02\), \(\Delta=2\), and
\(p_0=0.99\): the bound is attained. But with
\(H=\operatorname{diag}(0,0.001)\) and an equal superposition, the energy error
is only \(0.0005\) while \(p_0=0.5\). A small absolute energy error can coexist
with poor ground-state agreement when the gap is small.

**Bridge to Q8 acceptance.** Energy error, state agreement and eigenstate residual
answer different questions. Record all criteria that the historical study used.
A successful energy test must not erase a recorded fidelity miss. If the ground
space is degenerate, \(p_0\) measures agreement with the entire ground space,
not with one arbitrarily chosen eigenvector. The bound needs a justified ground
energy and positive gap; estimates need their own uncertainty treatment.

## 3. Logical clauses become a diagonal energy function

**Starting point.** Write a Boolean assignment as \(x_i\in\{0,1\}\), with one
meaning true. A positive literal \(x_i\) is false when \(1-x_i=1\); a negative
literal \(\neg x_i\) is false when \(x_i=1\).

**Bridge.** A clause is violated exactly when all its literals are false. Its
violation indicator is the product of those false indicators. Sum over clauses
to obtain \(E(x)\), the number of violated clauses. A diagonal matrix with
entries \(E(x)\) in the computational basis is a Hamiltonian encoding of that
same objective. In operator form, the bit projector is
\(N_i=(I-Z_i)/2\); substitute \(N_i\) for \(x_i\).

**Worked example.** For the clause \(x_1\lor\neg x_2\),
\(E(x)=(1-x_1)x_2\). Of the assignments 00, 01, 10 and 11, only 01 has energy
one. The other three have energy zero. Thus its diagonal operator has entries
\((0,1,0,0)\) in that explicitly stated basis order.

**The correction that matters.** Repeated occurrences of a variable are not
independent random variables. For \(x\lor x\), the Boolean identity
\((1-x)^2=1-x\) holds, so under true probability \(p\) the expected violation
is \(1-p\), not \((1-p)^2\). Likewise \(x\lor\neg x\) is always satisfied:
\((1-x)x=0\). Multiplying separate marginal probabilities would incorrectly
produce \((1-p)p\). Simplify repeated/complementary literals, or retain their
shared-variable dependence, before calculating expectations.

**Bridge to implementation.** For a product-state probability distribution,
distinct bits are independent, so a simplified clause expectation factors across
its distinct variables. An entangled state need not have that property. This is
the sort of assumption a teaching account must make visible. The retained
Study003 repeated-literal correction provides the historical connection.

**Limit.** Encoding a SAT instance as energy does not solve the minimization
problem. Zero minimum energy is equivalent to satisfiability, but finding it
can remain difficult. A clause with many variables generally creates a many-body
diagonal term; calling it a pairwise Ising model requires an additional justified
reduction. No speedup or general SAT solver follows from the representation alone.

Foundation: [Farhi and colleagues, clause penalties and diagonal Hamiltonians](https://arxiv.org/html/quant-ph/0001106v1).

## 4. Representation can remove work for a structured family

**Starting point.** A dense \(n\)-qubit pure state stores \(2^n\) complex
amplitudes. With two eight-byte floating-point numbers per amplitude, the arrays
alone use \(16\cdot2^n\) bytes. At \(n=21\), that is 33,554,432 bytes,
excluding runtime and other allocations.

**Bridge.** A sum of products writes

\[
\psi=\sum_{r=1}^{R}c_r\bigotimes_{j=1}^{n}v_{rj}.
\]

A GHZ state has a two-term expression,
\((|0\rangle^{\otimes n}+|1\rangle^{\otimes n})/\sqrt2\).
Its compact description remains small as \(n\) grows. A matrix product state
instead expresses each amplitude as a chain of small matrices; its storage is
of order \(n\chi^2\) for bounded local dimension and maximum bond dimension
\(\chi\). The bound on \(\chi\), or on product branches \(R\), is essential.

**Bridge to Q8.** The preserved dense receipts and the selected SOP/MPS circuits
describe different representation/workload populations. The structured source
uses a branch cap of 64 and bridge bond cap of 32. Selected product/GHZ circuits
with up to 60 indexed qubits do not establish an arbitrary dense 60-qubit engine.
General states and gate sequences can require large branch or bond dimensions.

**Failure cases and checks.** A cap overflow needs a declared response; a discarded
local QR residual needs an error account. A local omission threshold is not by
itself a global state-error bound. A few amplitude witnesses and a norm check
can validate those witnesses, but cannot establish every amplitude of an arbitrary
state. Compact representation is established mathematics; the implementation,
validation choices and measured workloads are the project-specific account.

Foundations: [Tensor Toolbox's product-sum representation](https://www.tensortoolbox.org/ktensor_doc.html)
and [Vidal's structured simulation result](https://arxiv.org/html/quant-ph/0301063v2).

## 5. An exact derivative can support a faster implementation

**Starting point.** For a differentiable normalized circuit state
\(\psi(\theta)=U_L\cdots U_1|0\rangle\) and a fixed Hermitian \(H\),
\(E(\theta)=\langle\psi,H\psi\rangle\). For a real parameter \(\theta\) that changes the state,

\[
\partial_\theta E=2\operatorname{Re}\langle\partial_\theta\psi,H\psi\rangle.
\]

This follows by differentiating the bra and ket terms and using Hermiticity.
If a parameter occurs in multiple gates, the chain rule includes every occurrence.
If \(H\) itself depends on the parameter, its derivative adds another term.

**Bridge.** Forward intermediate states and backward propagated vectors can reuse
the chain rule across parameters. Caching sine/cosine for unchanged angles avoids
repeating the same arithmetic. Removing unused history can reduce memory traffic.
These are implementation choices; changing the objective or importing a target
answer changes the comparison and must be disclosed separately.

**Q8's two distinct accounts.** The stage-04 hybrid calculated a conventional
ground-state target and fitted a circuit to it. Its old-versus-fast hybrid solver
comparison and separate complete-request comparison are not a target-free
quantum-advantage claim. The later VQD objective adds overlap penalties,

\[
F_k(\psi)=\langle\psi,H\psi\rangle+
\sum_{i<k}\beta_i|\langle\phi_i,\psi\rangle|^2.
\]

For exact normalized, mutually orthogonal prior eigenstates covering all earlier
levels \(i<k\), choosing \(\beta_i>E_k-E_i\) raises those states above the
target energy \(E_k\) in the ideal objective. Actual
approximate states, a restricted circuit family and local optimization need
separate analysis; the formula does not guarantee convergence to the desired
eigenstate. The retained later performance revision optimized that VQD workload.

Foundation: [Higgott, Wang and Brierley's VQD formulation](https://arxiv.org/html/1805.08138v2).

**Measured result.** The two recorded later batches reduced calculation time by
about 17.1% and 13.3%, both below the declared 20% target. The earlier rewrite was
about 52% slower. Preserve those outcomes beside the derivative checks and fitted
result comparisons. These are historical task-level measurements, not new runs
for this edition or causal evidence that USB storage accelerated Windows.

**Teaching test.** Ask the learner to distinguish mathematical equivalence,
numerical agreement, convergence, implementation speed and comparison fairness.
Each needs different evidence. The targeted [foundation references](FOUNDATIONS.md)
identify established background; they are not an exhaustive novelty determination.
