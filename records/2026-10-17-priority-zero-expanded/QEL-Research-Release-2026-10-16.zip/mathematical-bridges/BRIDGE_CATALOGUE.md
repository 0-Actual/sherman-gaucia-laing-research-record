# Mathematical bridges in the preserved Q8 and quantum work

Prepared for Sherman G. Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting editorial review: Codex.

The strongest teaching material is a sequence of **mathematical definition → justified transformation → actual implementation → measured or reported result → remaining limit**. These eight bridges explain that sequence. They do not assert that familiar identities were invented here. Implementation improvements can be valuable without becoming new mathematical theorems. No experiment or source program was run for this map.

| Bridge | Mathematical connection | Evidence level |
|---|---|---|
| MB-T01 | State amplitudes → factored representations → bounded simulation | established representation identity; implementation strategy; bounded empirical capacity |
| MB-T02 | Wannier material blocks → a Hermitian matrix → circuit energy | established Fourier construction; finite-dimensional encoding; verified implementation |
| MB-T03 | Spectral gap → an energy/fidelity bound → better acceptance rules | established inequality; acceptance-contract correction; empirical solver improvement |
| MB-T04 | Overlap penalties → successive variational states → a spectrum | established VQD method; implementation extension; bounded empirical accuracy |
| MB-T05 | The chain rule and reversible gates → adjoint gradients → less repeated work | established derivative method; implementation optimization; empirical performance improvement |
| MB-T06 | Scale invariance and projective geometry → robust normalization and distance | established identities; numerical reformulation; verified boundary correction |
| MB-T07 | An affine quantum channel → fixed-point algebra → stable convex weights | established affine fixed-point derivation; numerical correction; bounded reference implementation |
| MB-T08 | Boolean clause violations → diagonal energy → product-state expectation | established representation identity; documentary historical bridge; original implementation/proof unavailable; novelty unassessed |

Seven bridges have preserved code and receipts. The SAT bridge has documentary summaries only; its original code and full proof ledger remain a source gap. Exact source identities are in `technical-map.json`; private filesystem locators are kept separately.

## MB-T01 — State amplitudes → factored representations → bounded simulation

**Dates:** Dense observations: September 18, 2026. Structured implementation date is not established by its later preserved-copy date.

**Starting mathematics.** A pure n-qubit state is a unit vector in C^(2^n): psi = sum_x a_x |x>, with sum_x |a_x|² = 1. The same amplitudes can sometimes be factored: SOP psi = sum_(b=1)^B c_b tensor_(j=1)^n v_(b,j); MPS a_(x1...xn) = A1[x1] A2[x2] ... An[xn].

**Transformation.** Replace an explicit amplitude array with factors when the state/circuit permits small branch count B or bond dimension chi. For two Float64 arrays, dense state storage is 16·2^n bytes. Factor storage can scale as O(Bn) or O(n·chi²), but B or chi can grow with entanglement and circuit structure. This is a representation change, not a proof that arbitrary states become cheap.

**Implementation.** SOP, line 14: Product branches and cap-controlled gate updates. MPS, line 48: Two-site contraction followed by twice-reorthogonalized QR; omitted residual norms recorded. BRIDGE, line 1: The reviewed bridge limits its selected scenarios to at most 60 indexed qubits.

**Retained result.** Dense sizes 1–21 completed in 25 trials. At 21, 2,097,152 complex amplitudes occupy 33,554,432 state bytes; three validation times have median 766.6211 ms. The structured source provides product/GHZ paths with SOP branch cap 64, bridge MPS bond cap 32 and local QR omission threshold 1e-13. This source selection establishes implementation, not every historical 60-qubit timing claim.

**Teaching example.** GHZ_n = (|0...0> + |1...1>)/sqrt(2) has a two-term SOP and a bond-dimension-two MPS for n>=2, although its dense vector has 2^n entries. This standard example explains the compact representation; it is not a newly executed trial.

**Failure or limit.** Dense 22 was not admitted: free memory was below state-plus-reserve requirement. SOP overflow and MPS rank overflow refuse a state update. A local QR residual threshold is not a certified global-state error bound. Three amplitude witnesses plus norm are not exhaustive state verification.

**What kind of contribution?** Tensor factorizations and GHZ structure are established mathematics. The local engineering choices and measured capacity are project evidence. No new representation theorem or physical-qubit result is claimed.

**Possible next mathematical question.** For the actual supported gates, can a project-specific global error bound and cost model be derived from recorded local omissions and representation growth? This is an unproved project task, not a claim that the subject is new to mathematics.

Sources: SOP, MPS, BRIDGE, DENSE, DENSE22, DENSECODE. Learning-history records: T026, T027, T028, T055.

## MB-T02 — Wannier material blocks → a Hermitian matrix → circuit energy

**Dates:** September 20, 2026 JARVIS pass 01; separately extended September 28.

**Starting mathematics.** The retained eight-orbital tight-binding input supplies H(R) over 1,041 lattice-vector blocks, with positive block degeneracies d_R. Construct H(k) = sum_R [H(R)/d_R] exp(2πi R·k), followed by (H+H†)/2. In this source, entries are in eV, original orbital ordering is preserved and Fermi shift is zero.

**Transformation.** Identify the eight orbital basis vectors with the eight computational basis labels of three simulated qubits. This is a dimension-preserving encoding, not a claim about eight physical particles. A normalized circuit state psi(theta) gives E(theta)=psi†H(k)psi. For Hermitian H, a normalized trial energy is an upper bound on its lowest eigenvalue.

**Implementation.** WANNIER, line 18: Validates dimensions, entry count and positive degeneracies. WANNIER, line 41: Builds the reciprocal-space Fourier phase. ADJOINT, line 22: Evaluates the fixed circuit expectation and its derivative.

**Retained result.** The saved pass-01 reconstruction differs from its 24-matrix fixture by at most 2.220446049250313e-16 eV. Ninety circuit/energy cases on 30 matrices passed their fixed criteria; maximum full complex-amplitude difference was 3.7238012298709097e-16 and energy-expectation difference 1.0658141036401503e-14 eV.

**Teaching example.** The translation is “same matrix, new basis labels, a chosen family of trial vectors.” It does not make the material model a full many-electron calculation or imply that a circuit optimizer beats direct diagonalization.

**Failure or limit.** The input is one material, aluminum JVASP-816. Extra k-points are more cases from that material. Model construction, variational search and conventional reference diagonalization must retain separate roles and timing.

**What kind of contribution?** Fourier interpolation, Hermitian expectation values and the variational bound are established. The contribution here is source-bound integration and checked calculations, not a new materials theorem.

**Possible next mathematical question.** Which classes of input matrices justify a circuit representation when accuracy, representation size and total computation are compared with strong classical solvers? New-material and larger-size evidence is not supplied by the current aluminum record.

Sources: WANNIER, J1, ADJOINT, VQDREPORT, LICENSEJARVIS. Learning-history records: T029, T030, T031, T039, T047.

## MB-T03 — Spectral gap → an energy/fidelity bound → better acceptance rules

**Dates:** September 20, 2026 passes 02–03.

**Starting mathematics.** Let H have ground energy E0 and ground-space projector P0. Let Delta>0 be the gap from that entire ground space to the next distinct eigenvalue. For normalized psi, F=⟨psi,P0 psi⟩. Spectral expansion gives E-E0 >= Delta·(1-F), hence 1-F <= (E-E0)/Delta.

**Transformation.** An energy criterion is not automatically a state criterion. At a tiny gap, the bound may be weak or vacuous even when energy error is small. Evaluate energy, ground-space fidelity, norm, residual and circuit agreement separately. For degeneracy, compare with the whole ground subspace rather than one arbitrarily chosen eigenvector.

**Implementation.** J2, line 31: Saved small-gap counterexamples to energy-only acceptance. J3STUDY, line 50: Matched energy and full-acceptance populations are explicitly separate. FAST, line 64: The hybrid uses a conventional target calculation plus circuit fitting; this is not target-free discovery.

**Retained result.** At gap 1e-6 eV, energy error 5.61226507949274e-8 eV passed the energy target but fidelity 0.9438801949621364 missed 0.9999. At gap 1e-8 eV, fidelity was 0.7237052008836223 despite energy and gradient acceptance. The 720-case study had baseline full acceptance 424, first repair 681 and bracketed revision 720. Removing the identified already-solved seed-collision control gives 423/719, 680/719 and 719/719; the original counts remain retained.

**Teaching example.** In H=diag(0,Delta), psi=sqrt(F)|0>+sqrt(1-F)|1> has energy Delta·(1-F). If Delta is very small, a state with substantial excited-state weight can still have a very small absolute energy error. This is a pure state and an exact teaching identity, not a new measurement.

**Failure or limit.** Energy-target successes did not remove two fidelity misses, 39 first-repair acceptance misses, wrong zero-gradient starts or the reused seed. Floating-point gap estimates are not interval certificates; finite acceptance does not prove universal convergence.

**What kind of contribution?** The spectral inequality is established and follows directly from the eigenbasis expansion. Separating metrics and repairing the target iteration are engineering lessons supported by retained results. No new inequality or quantum advantage is claimed.

**Possible next mathematical question.** Can certified spectral bounds yield a conservative, computable fidelity certificate for the project’s chosen matrix class? The present diagnostics do not supply that certificate.

Sources: J2, J3, J3STUDY, J3SEED, FAST. Learning-history records: T032, T033, T035, T036, T037, T038, T039.

## MB-T04 — Overlap penalties → successive variational states → a spectrum

**Dates:** September 28, 2026 original and additional aluminum assessments.

**Starting mathematics.** After fitting states psi_0,...,psi_(j-1), use J_j(theta)=⟨psi(theta),H_normalized psi(theta)⟩+beta·sum_(k<j)|⟨psi_k,psi(theta)⟩|². Equivalently, optimize H_j=H_normalized+beta·sum_(k<j)|psi_k><psi_k|. The implementation uses beta=4 after centering and positive row-sum scaling.

**Transformation.** The rank-one terms penalize returning to earlier fitted states, allowing sequential searches for different low-energy states. The final reported energy is evaluated against the original H, not the penalized objective. Source passes the penalized matrix directly to refineBFGS; it does not call the classical-target fastRefine path.

**Implementation.** VQD, line 55: Centers/scales H, builds overlap projectors, uses two seeded starts per state and retains diagnostics. VQD, line 73: Direct BFGS call on the penalized Hamiltonian. VQD, line 77: Restores scoring to the original physical-model Hamiltonian.

**Retained result.** The original path has 24 ordered points × 8 energies = 192 scalar predictions, with MAE 3.4501989767139057e-6 eV and largest scalar error 2.424081433360925e-4 eV. The separately frozen additional set has another 192 predictions at 24 same-material points, with MAE 1.2888900558943352e-6 eV. These are separate populations, not 384 independent materials.

**Teaching example.** With exact normalized, mutually orthogonal prior eigenstates covering the earlier energy levels, and a sufficiently large positive penalty, those eigenvalues shift upward while the orthogonal eigenstates are unchanged. Approximate fitted states and finite optimization complicate that clean argument; the implementation must therefore check overlaps and residuals.

**Failure or limit.** The original run had 187/384 starts hit the iteration limit; the additional run had 239/384. The conventional control was faster and more accurate on the original small problem. Previously seen references prevent a blind-test claim. No official rank or matched public-Qiskit runtime comparison was established.

**What kind of contribution?** The source explicitly credits Higgott, Wang and Brierley’s variational quantum deflation method. This is a local implementation and assessment, not a claim that VQD was invented here. A new contribution would require its own precisely stated and independently assessed result.

**Possible next mathematical question.** How should penalty choice, ansatz restrictions and near-degeneracy be combined with rigorous or empirical stopping criteria? Current low mean error does not settle full eigenstate convergence.

Sources: VQD, VQDREPORT, FAST. Learning-history records: T044, T045, T046, T047, T048.

## MB-T05 — The chain rule and reversible gates → adjoint gradients → less repeated work

**Dates:** September 20 adjoint work. Later benchmark receipts: September 29 UTC at 02:12:31.070 (negative first version), 02:20:03.206 (selected v4) and 02:45:43.686 (audit), all September 28 Eastern. These are receipt times, not interchangeable run start/end times.

**Starting mathematics.** For real parameters theta, psi(theta)=U(theta)|0> and a parameter-independent Hermitian H, dE/dtheta_j=2 Re⟨dpsi/dtheta_j,H psi⟩. A backward sweep moves states and the adjoint vector through inverse unitary gates, evaluating each parameter derivative without separately preparing a shifted state for every parameter. For the retained RY/RZ gates, the code also supplies the standard ±π/2 parameter-shift comparison.

**Transformation.** Reuse intermediate state vectors and reverse gate operations instead of repeated whole-circuit evaluations. A constant number of state vectors with respect to parameter traversal is still exponential storage in qubit count for a dense representation. The later implementation calculates sin(theta_j/2) and cos(theta_j/2) once per new parameter vector, changes the sine sign for inverse rotation, and removes unused optimizer-history retention. It keeps the same circuit, BFGS update arithmetic, seeds and stopping budgets.

**Implementation.** ADJOINT, line 29: Reverse traversal and parameter-shift mode are explicit in the retained source. CACHED, line 19: Eighteen sine/cosine pairs per new 18-angle vector; reuse on reverse gates. COMPACT, line 37: Final diagnostics remain although per-iteration history is no longer retained.

**Retained result.** The adjoint receipt has 64 angle sets, 512 state-comparison evaluations and 1,152 derivative-component checks; maximum parameter-shift discrepancy is 1.7763568394002505e-15. Two four-process old/new/new/old batches of the 24-point/192-energy VQD workload reduced median calculation time by 17.142% and 13.344%, with exact fitted outputs within each batch. These are the combined implementation changes, not a measured isolation of each change’s individual contribution.

**Teaching example.** A repeated trigonometric value can be reused without changing its mathematical meaning. That does not imply every memory-saving rewrite is faster: the retained first allocation rewrite was 52.1% slower despite lower process memory.

**Failure or limit.** Both accepted batches missed their 20% time target; two intermediate probes also remained slower. Timings exclude startup and concern a particular process workload, not Windows globally. Saved-answer cache reuse is another operation and must not be counted as fresh optimization speed.

**What kind of contribution?** The adjoint source credits Jones and Gacon’s published method. Trigonometric reuse and unused-history removal are implementation optimizations. The exact local measured gains are empirical evidence; no new derivative identity or universal speedup is asserted.

**Possible next mathematical question.** A future controlled decomposition could estimate which change helps under which workload and runtime. That is a project experiment to design, not evidence already present or a novelty claim.

Sources: ADJOINT, ADJOINTCHECK, CACHED, COMPACT, PERF1, PERF4, PERFAUDIT. Learning-history records: T042, T049, T050, T051, T052, T053, T057.

## MB-T06 — Scale invariance and projective geometry → robust normalization and distance

**Dates:** September 4–5, 2026 report/package interval; the precision-results file has no execution timestamp.

**Starting mathematics.** For any nonzero vector z and any positive scale s, z/||z|| = (z/s)/||z/s|| in exact arithmetic. For normalized a,b, the ray distance sqrt(1-|a†b|²) equals the norm of b projected perpendicular to a. For nonzero a,b, r=b-a(a†b)/(a†a) and ||r||/||b|| expresses the same scale-invariant geometry.

**Transformation.** Choose s as the largest absolute real or imaginary component, scale those components separately, then normalize the bounded vector. Avoid forming an overflowing or underflowing original norm. Compute the projection residual and its robust norm instead of subtracting a near-one fidelity from one. This changes finite-precision behavior while preserving the intended exact formula.

**Implementation.** NORMOLD, line 111: Earlier direct-norm implementation, preserved as a complete historical exhibit. NORMOLD, line 247: Earlier near-one subtraction. NORMNEW, line 113: Corrected normalization entry point. NORMNEW, line 255: Corrected projective-distance entry point.

**Retained result.** The parent failed 13 of 22 new precision methods. The successor passed all 22 plus 108 inherited and 12 earlier boundary methods: 142 methods in those suites. Saved examples correct rejection of [1e300,1e300] and [1e-300,1e-300], remove a roughly 2.10734e-8 spurious self-distance, and preserve structured basis perturbations of 1e-12 and 1e-300 that the parent rounded to zero.

**Teaching example.** Two algebraically equivalent expressions can have different intermediate magnitudes. The lesson is to preserve the invariant in a representable range, not to claim that ordinary floating-point arithmetic becomes arbitrary precision.

**Failure or limit.** Tiny components relative to enormous ones can still disappear. General near-collinear vectors incur projection/representation error; special basis examples at 1e-300 do not prove universal sensitivity. A direct raw squared-distance result can still overflow and must be rejected.

**What kind of contribution?** The scale and projection identities are established mathematics. The contribution is the explicit correction, counterexamples and preservation of earlier behavior. Novelty of a new numerical method has not been assessed.

**Possible next mathematical question.** Can the implementation receive a useful forward/backward error analysis over its declared input domain, including subnormal components and nearly collinear states? The present tests are evidence, not a full error theorem.

Sources: C002, NORMOLD, NORMNEW, PRECISION. Learning-history records: T012, T013, T014, T016, T017, T018, T022.

## MB-T07 — An affine quantum channel → fixed-point algebra → stable convex weights

**Dates:** C002 standalone successor; result receipt timestamp is September 5, 2026, 00:56:01.683802 UTC (September 4 Eastern). This identifies the receipt, not the first historical occurrence of the equation.

**Starting mathematics.** D_p(rho)=(1-p)rho+pI/2 and C_eta(rho)=(1-eta)rho+eta tau, with p,eta in [0,1] and a fixed valid qubit density tau. Their composition is F(rho)=a rho+bI/2+c tau, where a=(1-eta)(1-p), b=(1-eta)p, c=eta and a+b+c=1.

**Transformation.** For p or eta positive, a<1 and rho*=(bI/2+c tau)/(b+c). At p=eta=0 the channel is identity and every density is fixed. Use s=max(p,eta), u=(p/s)(1-eta), v=eta/s, then rho*=(uI/2+v tau)/(u+v). Scale before multiplication and avoid subtracting a from one. Differences contract by a in exact arithmetic.

**Implementation.** ENTROPY, line 80: Validates probabilities and target density; rejects only the exact double-zero identity case. ENTROPY, line 98: Stable weight calculation.

**Retained result.** Thirteen saved methods passed, including a 760-digit Decimal reference over ten difficult parameter pairs, 72 channel-invariance subcases and 100 seeded density subcases. The subcases are not added as independent test methods. With both probabilities equal to the smallest positive binary64 subnormal and tau=|0><0|, the reference gives diagonal (0.75,0.25).

**Teaching example.** Very small p or eta still gives a unique fixed point, but a≈1 means slow contraction. One floating-point update may round to the identity. Existence, convergence rate and numerical visibility are different questions.

**Failure or limit.** The original threshold 1-a<=1e-10 incorrectly rejected some mathematically unique channels. The new file is a standalone successor, not recovery of the full 662-line historical module. Target replacement is a specified channel, not cost-free thermodynamic entropy reduction.

**What kind of contribution?** The fixed-point derivation is elementary affine algebra under explicit density/channel assumptions. The numerical correction and boundary checks are supported; no new physical law or globally novel theorem is claimed.

**Possible next mathematical question.** What finite-precision convergence/stopping guarantee can be proved for repeated channel application when parameters are tiny? The fixed-point formula alone does not provide a rapid iterative algorithm.

Sources: ENTROPY, ENTROPYRESULTS, C002. Learning-history records: T019, T020.

## MB-T08 — Boolean clause violations → diagonal energy → product-state expectation

**Dates:** Documentary Study 003 row: September 19, 2026, 06:03 UTC. Contract row: 04:53 UTC.

**Starting mathematics.** For Boolean assignment x, let v_C(x)=1 if clause C is unsatisfied and 0 otherwise. Then E(x)=sum_C v_C(x). Define the diagonal operator H=sum_x E(x)|x><x|. Its zero-energy computational basis states are exactly the satisfying assignments. This statement is a representation equivalence, not a search algorithm.

**Transformation.** For a product state with independent bit probabilities p_j, ⟨H⟩=sum_C Pr(C unsatisfied). For a canonical clause with distinct, consistent literals, that probability is the product of the appropriate p_j or (1-p_j) factors. Repeated copies of a literal refer to the same random variable and must not be multiplied as independent events. A clause containing x and not-x is a tautology with zero violation. The empty clause has violation one.

**Implementation.** SATDOC, QEL-PW-0402: Located documentary summary of Study 003 and its repeated-literal correction; original code/proof/receipt package not acquired. SATDOC, QEL-PW-0399: Research contract identifies correctness, worst-case bit cost, precision, readout and UNSAT obligations; logarithmic-branch bound remains unproved.

**Retained result.** The prior-work summary reports 384 formulas, 4,096 assignments and 4,608 expectation checks, followed by a repeated-literal correction. These are inherited reported populations, not newly inspected raw executions. No actual original Study 003 code or complete proof ledger has been inspected in this bounded map. The equations here are a fresh editorial explanation of the standard identity, not reconstructed historical source.

**Teaching example.** For clause (x OR x), the unsatisfied probability is 1-p, not (1-p)^2. Boolean idempotence exposes why canonicalization matters. For (x OR NOT x), the probability is zero, not p(1-p). These examples explain the correction class without claiming to reproduce the missing source bug line.

**Failure or limit.** The explicit diagonal has 2^n entries if materialized. A compact clause formula or a continuous expected-energy objective does not establish efficient global minimization, rounding to a satisfying assignment, an UNSAT certificate or a worst-case polynomial solver. Local minima and precision/readout costs must remain separate obligations.

**What kind of contribution?** The Boolean/diagonal-energy expectation identity is standard. The reported study may contain project-specific work, but complete original artifacts and a proof/novelty assessment are unavailable here. The conditional resource bound remains unproved; no solution to P versus NP is claimed.

**Possible next mathematical question.** Recover the original code, repeated-literal correction, full proof obligations and counterexamples before assessing any stronger algorithmic claim. A new theorem would require a precise statement, assumptions and proof with bit-cost and certificate analysis.

Sources: SATDOC.

## Teaching and proof discipline

Teach the representation identity first, including its assumptions. Then show the implementation choice and the counterexample that motivated a correction. A passing finite test set is evidence about those cases; a proof must state and cover its domain. A faster implementation needs comparable workload measurements; a fast algorithm needs an analysis of total cost and scaling. A novelty claim needs literature comparison and independent assessment. These are separate forms of support.

The clearest Q8 lesson is that mathematical correctness, numerical stability, state fidelity, execution cost and source custody are connected but distinct. The retained failures are part of that lesson: energy can be accurate while fidelity is poor; a smaller allocation can run slower; an algebraic identity can fail through intermediate overflow; and a compact representation can cease to be compact as its rank grows.

The proposed research questions identify work not established by this collection. They are not assertions that these questions are globally open or that their answers would necessarily be novel. The present map supports responsible teaching and a more precise future research specification.

Source attribution: the retained adjoint implementation names Jones and Gacon (2020); the VQD adapter names Higgott, Wang and Brierley (2019). JARVIS source notices remain separate preserved evidence. This map creates no licensing grant, publication authorization or external endorsement.

## Public source labels and identities

- **SOP** — structured-state-research-implementation / original/engine/qel60_sop.mjs; 4537 bytes; SHA-256 `68d4f51bada186064abef80cb1dba8f5a41a546aae6ead1c8add819583ce5964`.
- **MPS** — structured-state-research-implementation / original/engine/qel60_mps.mjs; 11952 bytes; SHA-256 `b006ec5c202b629b6ba42eb058f4a752d63faa18bf0ce702dc3855d4fe1b4fac`.
- **BRIDGE** — structured-state-research-implementation / original/engine/quantum_bridge.mjs; 3087 bytes; SHA-256 `c1c39f2306776bf4617794faaaa0d8d6a7098055fd97b47bd933c0edc0a99c5d`.
- **DENSE** — live-dense-qubit-scaling-20260918 / READ_ME_RESULTS.md; 5988 bytes; SHA-256 `50d10d20e091ecbf1e29b0dde632d05bafb347fc5a82a8a06ac9699955b67fc5`.
- **DENSE22** — live-dense-qubit-scaling-20260918 / QEL_Live_Qubit_Scaling_20260918_03/result_22_1.json; 470 bytes; SHA-256 `c800127fbc923f968d04a391cb3527a48aa8e004f57a54aebedaaf8e84543edc`.
- **WANNIER** — jarvis-private-01 / compute.mjs; 11107 bytes; SHA-256 `3dbea0f76e31a96d26ac412ce8dfdc2f7b331c378e4438db53fe16a23c4a3832`.
- **J1** — jarvis-private-01 / REPORT.md; 11924 bytes; SHA-256 `9ecf896cf7900919d9947f4421deee6dd11f8c4db8e3176e9af98f988f7bce24`.
- **J2** — jarvis-private-02 / REPORT.md; 7114 bytes; SHA-256 `ed138923edbea3500a08ae6231982b81841e7d1e1dd253eea811c02d418703e3`.
- **J3** — jarvis-private-03 / reports/FINAL_CHAT_REPORT_01.json; 9098 bytes; SHA-256 `aa08eabcc32cb4dbd3d3ca39f21e67d93942e4b4e8462ba4211c9a47a3e06527`.
- **J3STUDY** — jarvis-private-03 / runs/study_aggregation_01/summary.json; 9885 bytes; SHA-256 `aac879734ad57ced31ffe4abf64d37e4515e49833cd89035bcae9edd40c570d4`.
- **J3SEED** — jarvis-private-03 / runs/initialization_independence_confirmation_01/initialization_review.json; 831 bytes; SHA-256 `4411c49d84d3b9713fcd885e45a283f33adf014c0c8ee1072a410029df36344f`.
- **FAST** — jarvis-private-04 / numerics/q8-fast.mjs; 7211 bytes; SHA-256 `139f8a995cecdb270b533f08c6dd15f8d07b8e9b91bc19e440296f206a12d8a9`.
- **VQD** — full-jarvis-aluminum / run-assessment.mjs; 8906 bytes; SHA-256 `ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622`.
- **VQDREPORT** — full-jarvis-aluminum / README.md; 13318 bytes; SHA-256 `7915eb553905ec4431ae0226e411ec90d78f5717282bfdf0134bbdbfc870d7e1`.
- **CACHED** — full-qel-performance / cached-adjoint.mjs; 3424 bytes; SHA-256 `4b792d890394c11f6889f2aa40e26bf69aec205d7b3bcac3b6e157624fcce9bb`.
- **COMPACT** — full-qel-performance / compact-bfgs.mjs; 3177 bytes; SHA-256 `ffc7c28235dc400f769e9f52a1e55fb665477b753d51aba808e71efb266790e1`.
- **PERF1** — full-qel-performance / benchmark-results.json; 2899 bytes; SHA-256 `4769edf19fc6f589651751f8c92fbd6dbe56c54e6dfd334fa53c0538f8eca43f`.
- **PERF4** — full-qel-performance / benchmark-results-v4.json; 2880 bytes; SHA-256 `f0ace89d30c04318c2e3341d66de87153fea552a07242728c0e31dc26ebb3a12`.
- **PERFAUDIT** — full-qel-performance / benchmark-results-audit-v1.json; 2880 bytes; SHA-256 `3f8f40903338f2b79341aef0432a318dc5a8d1e47e2ced22807df590baab0e5a`.
- **C002** — full-recovered-math / members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/REPORT.md; 16746 bytes; SHA-256 `d5129f3ffc3bfae4d9be47dc2ade51fb7b83db1c3efb85806d071d5c5ed2a373`.
- **NORMOLD** — full-recovered-math / members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py; 23082 bytes; SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`.
- **NORMNEW** — full-recovered-math / members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/source/qel_lqcp_reference_v2_2.py; 24478 bytes; SHA-256 `77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3`.
- **PRECISION** — full-recovered-math / members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/evidence/precision_results.json; 1857 bytes; SHA-256 `bc5018cdcc6d47c545e7c8799e2ff2e0884bf0ec246834a345da2dd1cef6b115`.
- **ENTROPY** — full-recovered-math / members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/fixed_point_reference.py; 4950 bytes; SHA-256 `9023f7346018aa481baa63d8d808ae5812ae3ae3ae61d778260b63f80d692457`.
- **ENTROPYRESULTS** — full-recovered-math / members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/entropy_results.json; 3583 bytes; SHA-256 `fb35c80197105e34588962f3e8d4011f082e6a846a081bf0ba96a49a4bbb4a2e`.
- **ADJOINT** — jarvis-private-04 / numerics/q8-adjoint.mjs; 4623 bytes; SHA-256 `ca60743a3d8ea3f3d4e7a1aeb909a6bf2468e07c5be1d9f46af75b1f9cc5750a`.
- **ADJOINTCHECK** — jarvis-private-04 / runs/adjoint_validation_02/summary.json; 422 bytes; SHA-256 `e8226a485bd859334499e76ec0290633512e1e0097115c55d506fdf6a5dbfe3c`.
- **DENSECODE** — live-dense-qubit-scaling-20260918 / QEL_Live_Qubit_Scaling_20260918_03/kernel_functions.js; 942 bytes; SHA-256 `dccfdcc7cc0e1ac6242000d923a832afcda44a529a3a41d33218e9e68c0d8dd6`.
- **LICENSEJARVIS** — jarvis-private-01 / provenance/CC_BY_4_0_NOTICE.md; 1503 bytes; SHA-256 `3895187bd8b8866810624b01af472ed749603f361556b7d51e9d578e1a945e02`.
- **SATDOC** — Public research-series prior-work summaries / QEL-PW-0399 and QEL-PW-0402; 289580 bytes; SHA-256 `b3094f255109ade62560608a409e58f1ccf16895c3efffe07c20db23eec49f2f`.
