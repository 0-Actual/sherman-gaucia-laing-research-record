# Hebrew development history and screened receipts

These are historical source versions and receipts, retained to show mistakes,
corrections and the evidence for earlier checks. Use the current H04.1 build
and commands under `../reproduce/REPRODUCE.md` for reproduction. The H03/H04
converters and old test files here are historical exhibits, not the recommended
current build. No historical scientific benchmark or full-corpus export was
rerun while assembling this repository.

Four JSON receipts are new public derivatives. Only laptop/device invocation
and input-file locators were replaced with per-file aliases; dates, verdicts,
counts, source hashes and every non-locator value are unchanged. Source and
derivative identities are in the root SOURCE_MAP.json. The reversible locator
mapping and exact originals remain private. The old path-dependent corpus
harness and original ZIP are excluded. The original archive's README/manifest
are superseded for this selection by the new guides and manifests.

The current reproduction folder contains the full 40-file XML corpus, both
reference exports, notices, original Jeremiah source and correction patches.
The historical audit's 35-issue/two-PR inventory is dated review evidence,
not a total of confirmed defects or current monitoring. Editorial inference
does not establish upstream approval or exhaustive linguistic certification.
