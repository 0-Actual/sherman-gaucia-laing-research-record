# Preserved quantum source collections

All counts are selected file occurrences, not papers, studies, algorithms or independent experiments. Byte-identical objects are stored once while original logical records remain separate. The private register restores these collections.

| Collection | Files | Bytes | Scope |
|---|---:|---:|---|
| live-dense-qubit-scaling-20260918 | 75 | 311411 | Saved dense-state H/CX scaling study; distinct from three-qubit material studies. |
| improvement-audit-20260918 | 71 | 4689480 | Mixed research audit retained whole for provenance; quantum-specific guarded-input and matched-energy comparisons, plus checkpoint inventory. Ancillary Bible/reliability material is not a separate quantum study. |
| jarvis-private-01 | 130 | 9927879 | Initial circuit-energy comparison and classical material baseline; unresolved point-4 variational error retained. |
| jarvis-private-02 | 419 | 29271556 | Coupled BFGS successor, invariance/stress/fidelity checks; two synthetic fidelity misses retained. |
| jarvis-private-02-portable-replay | 43 | 5335238 | Historical fresh-folder diagnostic replay; aliases with parent source preserved as replay provenance, not an independent new study. |
| jarvis-private-03 | 8932 | 113794665 | Rayleigh/bracketed classical-target circuit fitting, acceptance revisions and saved negative/control results; seed-reuse correction retained. |
| jarvis-private-04 | 1913 | 25971807 | Adjoint-gradient/hybrid performance and application experiments; solver timings distinct from full-request timings and Windows-wide effects. |
| jarvis-private-05 | 86 | 4235580 | Target-free study protocol stopped before new solver execution; saved security/redirection material is provenance, not completed numerical results. |
| august21-successor-integration | 137 | 4104231 | Actual Generation A successor code, RC1 source archive, integration/correction receipts, B–D behavioral reconstruction registries. Distinct from the separate three-qubit Task Alpha workload. |
| structured-state-research-implementation | 8 | 44993 | Recovered implementation subset: low-bond MPS and capped sum-of-products plus integration wrappers. Historical benchmark review is available, but this subset does not independently establish its quoted benchmark runs. No new benchmark run. |
| full-task-alpha | 24 | 1478685 | Task Alpha classical three-qubit GHZ emulator |
| full-jarvis-aluminum | 110 | 2133546 | Aluminum VQD assessment and additional points |
| full-qel-performance | 93 | 6831037 | QEL compact optimizer performance comparison |
| full-recovered-math | 51 | 750183 | LQCP, entropy and three-qubit corrections |
| full-historical-core | 23 | 79098 | Recovered historical core function semantics |
| original-source-archives | 2 | 417699 | Exact named supporting sources, not a recursive parent-folder capture. |
| selected-provenance-reviews | 3 | 14604 | Exact named supporting sources, not a recursive parent-folder capture. |
| retained-jarvis-dependency-layout | 23 | 250884 | Earlier preserved portable dependency layout; aliases of source files may be repeated as provenance. |
| jarvis-dft-2d-public-evidence | 10 | 123467 | Existing public JARVIS-DFT 2D dataset analysis and notices; distinct from aluminum variational studies. The ten-file public selection does not include the complete analysis code/raw archive. |
