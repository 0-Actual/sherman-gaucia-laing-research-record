# Source, attribution and retained license notices

Owner/project attribution: **Sherman Gaucia Laing / Quantum.Earth.Laing**. The current primary project agent is **GAUCIA Actual**; Codex is the supporting reviewer and implementer. Historical sources retain the names and roles actually recorded at their dates. An attribution label does not prove a live runtime, independently hosted reviewer, legal ownership, scientific priority or external endorsement.

This consolidated edition is a newly prepared documentary synthesis of preserved source, historical execution evidence, corrections and teaching material. It is not a newly discovered original manuscript, a blanket software license or a new grant of rights. Exact private originals remain mapped in `SOURCE_REGISTER.private.json`. Public derivatives must be identified as derivatives; their redactions or path adaptations do not replace the original identities.

## Exact notices retained

Four notice files accompany the source analysis:

| Notice | Source scope | What is preserved |
|---|---|---|
| `quantum-core-LICENSE.txt` | Captured `quantum-core` repository snapshot | Sherman G. Laing Proprietary License, copyright 2024, attribution and usage terms, warranty disclaimer and original unresolved contact placeholder. |
| `quantum-earth-systems-architecture-LICENSE.txt` | Captured architecture repository snapshot | Its exact proprietary notice; identical wording does not merge repository provenance. |
| `JARVIS_LICENSE.rst` | Retained JARVIS upstream software provenance | NIST terms and full warranty disclaimer. |
| `LEADERBOARD_LICENSE.rst` | Retained JARVIS leaderboard software provenance | Its exact NIST terms and full warranty disclaimer. |

The notices are retained verbatim. The two repository snapshots have proprietary terms; an earlier repository history describing an MIT notice is a separate dated fact and is not assigned automatically to every later file. The placeholder contact text is preserved rather than replaced with an invented address.

The two retained NIST notices describe their own software terms and require retention of their notice and disclaimer. This summary does not extend those terms to every external dataset, notebook dependency, locally written QEL module or derived document. Keep the exact notices with material selected from their source scope. No current legal conclusion or additional permission requirement is asserted by this documentary note.

## Methods and data attribution

The aluminum assessment uses the JARVIS aluminum JVASP-816 Wannier model and the recorded leaderboard/scoring convention. Preserve the upstream source metadata, material identity, reference archive and scoring definitions. The local record pins the comparison repository to commit `b055e31bcd43a2da164a10df59198699297b53a9` and the benchmark ZIP blob to `a7440528cbd375d21aebaad183558f0830adc864`; those are historical source identities, not an assertion about the current leaderboard.

The retained code attributes variational quantum deflation to Higgott, Wang and Brierley, *Variational Quantum Computation of Excited States*, Quantum 3, 156 (2019), arXiv:1805.08138. It attributes the adjoint-gradient method to Jones and Gacon's 2020 work, arXiv:2009.02823. These references describe established methods used by the local implementation. The consolidated work claims its documented implementation, corrections and bounded measurements; it does not reassign authorship of those methods.

Task Alpha and the corrected mathematical sources retain Sherman G. Laing / Project Quantum.Earth.Laing credit. Some successor headers explicitly require visible credit. A standalone redistribution license for every local module was not located in the bounded review. That fact is a source-disclosure detail, not a claim that the owner's authorized preparation must stop. A future publication selection should preserve the exact applicable notice rather than infer a universal grant from a neighboring file.

The Generation A suite implements both established quantum-information models and classical field, phase and signal models. Model names and project branding do not establish novelty. Its source headers explicitly identify forensic or clean-room successors where applicable. Later numerical corrections must retain their own versions; they must not be silently relabeled as authenticated historical originals.

## Historical evidence and teaching material

Exact source bytes, saved test receipts, new documentary rebuilds and new numerical runs are different kinds of evidence. File integrity alone does not certify a theorem, a physical device, a security property, a research contribution or a complete interaction history. Preserve failed and stopped attempts together with corrected results and their dates.

Teaching passages are educational reconstructions of established results, not claims of novel proofs. External manuscripts are not republished merely because a private inventory mentions them. Chronology summaries, implementation files and later explanatory prose must retain their distinct dates and authorship context.

The private evidence archive is for owner review and preservation. This document contains no private absolute locator or credential and may accompany a public-review draft, but it does not authorize posting the private archive, original personal context or operational secrets. No public submission occurred during preparation.
