"""Verify a QEL collection's exact file set without executing research code."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath

def safe_path(value):
    if not isinstance(value,str) or not value or '\\' in value or ':' in value:
        raise ValueError('Invalid manifest path')
    p=PurePosixPath(value)
    if p.is_absolute() or '..' in p.parts or str(p)!=value:
        raise ValueError('Unsafe or noncanonical manifest path: '+value)
    return p

def verify(root):
    root=root.resolve()
    manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    if manifest.get('schema')!='qel-quantum-file-manifest/1':
        raise ValueError('Unexpected manifest schema')
    entries=manifest['files'];paths=set();total=0
    for item in entries:
        rel=safe_path(item['path'])
        if str(rel) in paths:raise ValueError('Duplicate manifest path: '+str(rel))
        paths.add(str(rel));target=root.joinpath(*rel.parts)
        if target.is_symlink() or not target.is_file():
            raise ValueError('Missing or linked payload: '+str(rel))
        if not target.resolve().is_relative_to(root):
            raise ValueError('Payload escapes collection')
        data=target.read_bytes()
        if len(data)!=item['bytes'] or hashlib.sha256(data).hexdigest()!=item['sha256']:
            raise ValueError('Content mismatch: '+str(rel))
        total+=len(data)
    # Only the root manifest is excluded; nested historical manifests remain payloads.
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p!=root/'MANIFEST.json'}
    if actual!=paths:
        raise ValueError('File set mismatch: missing='+str(sorted(paths-actual))+' extra='+str(sorted(actual-paths)))
    return {'state':'PASS','verified_payload_files':len(paths),'verified_bytes':total,
            'manifest_excluded_from_own_hash':True,'research_code_executed':False}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('folder',nargs='?',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args()
    try:result=verify(args.folder)
    except (ValueError,KeyError,TypeError,OSError,json.JSONDecodeError) as exc:
        parser.exit(1,'Verification failed: '+str(exc)+'\n')
    print(json.dumps(result))

if __name__=='__main__':main()
