# QEL consolidated quantum research

**Owner and directing researcher: Sherman Gaucia Laing / Quantum.Earth.Laing**  
**Primary project agent: GAUCIA Actual**  
**Consolidation and supporting review: Codex with delegated source reviewers**  
**Status: prepared for owner review; no publication or submission performed**

## Purpose and contribution of this collection

This collection brings the located quantum-related work into one research record.
It joins the original questions and algorithm history to actual source code,
mathematical models, datasets, execution receipts, corrections and later studies.
Earlier originals remain preserved alongside the successors that changed them.
The new contribution here is the consolidation, source map and explanation of how
the evidence fits together. No historical experiment was rerun for this edition.

The record describes computational quantum research performed or proposed on
classical computers: quantum state and circuit simulation, numerical descriptions
of channels and observables, variational materials calculations, exact-arithmetic
workloads, structured state representations and related mathematical methods.
It also preserves early concepts, negative results and classical methods that
were historically given quantum-related names. Each is identified by its actual
mechanism. Physical quantum-processor execution and a general quantum advantage
are not established by the located evidence.

The collection has several connected questions. What did the first implementations
actually compute? How were state normalization, coherence, entropy and measurement
defined? Which defects were reproduced and corrected? How did larger registers
change memory requirements? How did the materials solvers compare with ordinary
numerical controls? Which results have exact code, inputs and retained receipts,
and which remain documentary summaries awaiting their original artifacts?

The strongest links between these questions are visible in the source lineage.
The March algorithm series is retained as an early implementation record. The
August successor suite introduces distinct mechanisms and explicit contracts.
Task Alpha supplies a small exact reference workload. Later corrections address
specific floating-point and model-definition failures. Dense-state scaling records
what the laptop executed under a stated admission policy. The JARVIS sequence
preserves successive solver designs, numerical results, unfavorable comparisons,
performance observations and a later protocol stopped before new execution.

## How to read the research

Read the computational chapters for models, findings and reproduction conditions.
Then read the source chronology to trace requests, named concepts, source bodies
and corrections without assigning later implementations to earlier dates. The
source-collection catalogue identifies the preserved collections and their file
identities. The complete selected documentary rows are supplied separately so
the narrative can be checked against its actual source population.

Five distinctions control the interpretation. A mathematical proposition differs
from a floating-point implementation. A simulation of a state differs from a
measurement of hardware. A corrected or reconstructed successor differs from an
authenticated original. A retained execution receipt differs from a new replay.
A file, test method, check evaluation, trial, predicted energy and study are
different counting units. The tables and source maps preserve those units.

The complete original conversation export remains unavailable. Some original
source objects and study packages also remain missing. Their summaries and
partial evidence are retained with explicit limits. This edition does not infer
that missing records never existed, or that a recovered successor restores the
exact bytes of an unavailable original.

The private source archive preserves the selected code, input data and original
receipts with their provenance. Identical byte content can occupy one stored
object while every selected source location and version retains a separate
record. A provided restoration tool reconstructs a chosen collection in a new
folder without running its research code. This storage choice does not merge
experiments or turn duplicate receipts into independent observations.

The review edition contains a readable synthesis, documentary selection, source
identities, teaching context and a publication checklist. Raw private evidence
remains separate. Any scientific release should retain the inputs, source notices,
corrections and reproduction boundaries needed for its particular claims.

## Computational chapters



# Computational research: models, implementations and retained results

Prepared from the preserved source and execution evidence for consolidation. This is a new documentary synthesis, not a new experiment. The associated `WORK_INDEX.json` records exact selected files, their logical paths and SHA-256 values; private original locators remain in the source archive. All results below retain their original scope and dates. Review or recovery in October does not backdate a computational result.

The record initially selected six source groups: the historical core prototypes; Task Alpha's exact classical emulator; the C002 numerical correction family; the JARVIS aluminum assessment; its retained local numerical dependencies; and the subsequent solver-performance work. Two newly located collections expand this review to eight groups: the Generation A capability/kernel integration and the September dense-state scaling experiment. These are overlapping research/evidence groups, not eight independent physical quantum experiments. They mix small prototypes, exact arithmetic, floating-point simulation, reference corrections, benchmark development and measured software optimization. Test methods, repeated comparisons, numerical values, optimization starts and measured runs are different units and are not summed into one research score.

## 1. Historical core: what the early functions actually compute

The retained source capture contains 15 files totaling 8,767 bytes from two repository snapshots: `XvXvi4/quantum-core` at `9765fb94ed08ec7f3ab18153e3cecd9e1c104c98`, and `XvXvi4/quantum-earth-systems-architecture` at `34f4686c8d6c4c4aaa7f0c033d8701a8d626997d`. The initial December 19, 2024 commit described by the historical review contains a README and license. That date cannot be assigned to every body in the later snapshots. The preserved licenses identify Sherman G. Laing; source attribution, file identity and first-publication priority remain separate questions.

Three functions have enough retained implementation to examine precisely. The dynamics function successively applies supplied matrices, `psi_(k+1) = G_k psi_k`, computes the sum of squared component magnitudes, and retains states whose value is at least the caller's threshold. The quantity called energy is therefore `||psi||²`, not an expectation of a specified Hamiltonian. A filtered-out state still feeds the next matrix multiplication. The function neither enforces normalization nor validates that the matrices are unitary. For a normalized vector and unitary matrices, its squared norm remains one; the threshold is then largely an output-selection condition rather than a physical energy-selection mechanism.

The observer function is a predicate-based list filter. It retains order, duplicates and references to the selected objects. It does not implement probabilistic measurement or state collapse. The guidance function sometimes adds a uniformly drawn perturbation between −0.1 and 0.1 to a numeric choice. The branch is selected by a random draw below a supplied parameter. It has no implemented ethical objective or physical observer model. Religious and project-specific names in these bodies are attribution labels, not measured properties of the algorithm.

The October 14 observation harness extracted these three actual function definitions rather than inventing missing components. One saved run made nine calls across eight fixed observations using NumPy 2.3.5. All eight agreed with the disclosed semantics: inclusive threshold behavior; propagation after an excluded step; a nonunitary scaling example returning squared norm four; preserved norm for a complex unitary example; the expected 2×2-on-four-entry shape error; omission of the initial state when no gates are supplied; reference/duplicate retention in the filter; and deterministic branching under explicit fixed random draws. The 3.8834-second supervisor interval includes startup and source checks and is not a performance benchmark.

These observations provide recoverable implementation evidence, including limitations. They do not establish a complete quantum application. The saved architecture imports missing `QuantumAI`, multi-agent and encryption components. The snapshots also contain inconsistent package-import conventions. Initialization asks for a four-dimensional state before passing a 2×2 operator, a conditional integration concern whose actual behavior cannot be established without the missing class. The available source is useful as a historical baseline, not as a substitute for absent later study manuscripts or integration archives.

Reproduction boundary: the retained `observe_core.py` accepts a new output path, for example `python -B observe_core.py --out new-observations.json`, in a reconstructed copy with the source tree and NumPy available. It writes a new observation record, rejects an existing result path and supervises its child with an eight-second timeout. The command was not run during this consolidation. Replaying these three functions cannot repair or validate the missing application dependencies.

## 2. Task Alpha: exact classical emulation of a three-qubit GHZ circuit

Task Alpha's August 25, 2026 checkpoint is a more explicit computational object. Its emulator represents each amplitude as a Gaussian-integer numerator divided by a shared integer power of the square root of two:

`a_j = (r_j + i s_j) / (sqrt(2))^k`.

The implemented gate subset is H, X, Z, S and CNOT. For that subset, integer numerator operations and the shared exponent allow exact state and probability arithmetic without a floating-point comparison tolerance. This is a bounded Clifford-subset implementation, not a claim that every arbitrary circuit or arbitrary rotation has this representation.

The declared workload starts in `|000>` and applies H on qubit 0, CNOT from 0 to 1, then CNOT from 1 to 2. Its separately declared known answer is

`(|000> + |111>) / sqrt(2)`,

with probabilities one half for each of those two basis states and zero elsewhere. The saved receipt reports exact state agreement, exact normalization and fidelity 1/1. The workload describes its source specification, environment, initial state, parameters/precision, transformations, expected failures, reference answer, output metrics and lifecycle axes in ten required fields. Invalid or unknown fields, invalid operators and state shapes, denied admission and oracle mismatches have explicit failure classes.

Before importing the recovered policy kernel, the emulator checks its source against a purpose-separated content witness. It then uses the kernel's strict gate and canonical JSON encoder. This binds the implementation to a declared source body; the unkeyed witness is not an owner signature. The five admission factors in the workload are fixed synthetic demonstration inputs and do not themselves prove real-world authorization. The code separates capability, evidence, custody, privacy and release state rather than letting a successful calculation automatically activate or release the project.

Historical evidence comprises 82 recovered policy-kernel test methods and 73 added workload methods, totaling 155 methods across those two suites. Eight paired deterministic replay comparisons cover the declared outputs and environment/input/seed/precision bindings. Those eight comparisons are not eight additional independent scientific studies. The saved primary-run observation is 257,708 nanoseconds with 1,440 peak traced bytes; these narrow measurements do not establish superiority or a total-process memory bound.

The strongest contribution is an exact, schema-bound, auditable reference workload with a declared answer and retained failures. It simulates the GHZ state on a classical processor. It is not an observation of physical entanglement, physical QPU execution or quantum advantage. The recovered sequence-52 source was described as a delta, not a standalone integrated source tree; that broader dependency must not be silently closed by the small emulator.

Reproduction boundary: reconstruct `src/` and `upstream/` in a disposable copy. The recorded test commands use `PYTHONPATH=src:upstream python3 -m unittest discover -s tests -p test_*.py -v` and `PYTHONPATH=upstream python3 -m unittest -v upstream/test_qel_alpha_omega_contract.py`. Those are POSIX-style environment assignments; Windows requires its platform-specific path separator and environment syntax. The modules use the Python standard library. The separate builder `tools/build_alpha_reference_workload.py` creates evidence and a QPRINT artifact and should not be confused with simply running tests. No command was executed here.

## 3. LQCP reference corrections: explicit physical definitions and numerical robustness

The retained LQCP v2.2 file identifies itself as a clean-room forensic correction of historical Quantum Emulation Algorithm #13, using recoverable historical Python and formulas. It is not the exact original historical text-document object. Its exact locally retained parent v2.1 is preserved separately. Project origin, assistant review roles, reference implementation and later correction therefore remain separately attributable.

The reference replaces ambiguous uses of coherence with declared density-matrix measures. In a chosen basis, the l1 coherence sums absolute off-diagonal entries; the relative entropy of coherence is the entropy of the diagonalized density matrix minus the entropy of the density matrix. It checks density validity, requires unitary state operators and Hermitian generators for `exp(-iHt)`, and distinguishes closed-system evolution from open-system channels. It includes explicit Kraus/dephasing behavior and separates raw vector difference, global phase, fidelity, entanglement, correlation and norm.

One central correction concerns a historical mean-squared-amplitude rescaling. For a normalized d-dimensional vector, division by the square root of the mean squared amplitude multiplies its norm by `sqrt(d)`. That is global norm inflation; it is not, by itself, coherence preservation. A second distinction is model dependence: spin-echo-style refocusing in a declared quasi-static detuning model is not reversal of irreversible Markov dephasing. These are deterministic classical models, not measured extensions of a physical qubit's coherence lifetime.

The C002 implementation addresses two concrete floating-point defects. First, direct sums of squared magnitudes can overflow on `[1e300, 1e300]` or underflow on `[1e-300, 1e-300]`, although each has the ordinary normalized direction `[1/sqrt(2), 1/sqrt(2)]`. The successor validates finite components, selects the largest absolute real or imaginary component as a scale, divides real and imaginary parts separately, then normalizes the bounded result. It avoids reconstructing the possibly unrepresentable original norm. Separate component division matters for subnormal complex values. Zero and invalid states remain errors, and caller data is preserved. Extremely unequal normalized ratios can still round to zero; the method does not recover unrepresentable information.

Second, the mathematically valid expression `sqrt(max(0, 1-fidelity))` is numerically fragile for nearly identical states. The successor computes the projection residual

`r = b - a * (<a,b>/<a,a>)`, then `d = ||r|| / ||b||`,

using robust norm evaluation. In exact arithmetic this is the sine distance between state rays. It avoids subtracting a near-one fidelity from one. Saved examples show a parent self-distance of approximately 2.10734e−8 for `[1+2i, 3−4i]` becoming zero, and structured basis perturbations of 1e−12 and 1e−300 remaining nonzero where the parent returned zero. These specially structured examples do not imply universal accuracy at 1e−300 for arbitrary nearly collinear inputs; ordinary representation and projection errors still apply.

The historical precision receipt records 108 inherited methods and 12 earlier boundary methods passing for both parent and candidate. Thirteen of 22 newly added precision methods failed for the parent; all 22 passed for the candidate. Thus the successor's 142 passing methods preserve the old tests while closing newly demonstrated cases. They are not 142 new discoveries. The receipt names Python 3.12.13 and NumPy 2.3.5; the source also imports SciPy's matrix exponential. A complete pinned SciPy/environment lock is not supplied by that receipt.

Reproduction boundary: restore the original logical C002 paths because several saved files use `_long` storage names. The private source register preserves the original source-to-copy mapping; `WORK_INDEX.json` identifies the reviewed files. `python run_precision_audit.py` is the retained runner and writes new result evidence; it must be used on a disposable copy after arranging NumPy/SciPy and preserving historical outputs. Neither it nor the historical module's executable demo was run in this consolidation.

## 4. Entropy-control fixed point: uniqueness is not convergence speed

The recovered entropy contract distinguishes von Neumann, measurement, subsystem and thermodynamic entropy. The complete original 662-line module is not recovered: the retained evidence includes the contract and particular source excerpts. The new `fixed_point_reference.py` is a standalone mathematical successor to that contract, not an asserted reconstruction or replacement of the entire original program.

Its qubit model applies depolarization followed by replacement toward a specified target density matrix:

`D_p(rho) = (1-p) rho + p I/2`,

`C_eta(rho) = (1-eta) rho + eta tau`,

so `F(rho) = (1-eta)(1-p) rho + (1-eta)p I/2 + eta tau`.

For probabilities in [0,1], the fixed point is unique precisely when p and eta are not both zero. If both vanish, the channel is the identity and every density is fixed. The original excerpt rejected `1-(1-eta)(1-p) <= 1e-10` as nonunique, conflating a numerical threshold with the mathematical condition. In particular, positive p with eta zero has fixed point I/2, and positive eta with p zero has fixed point tau even if the positive parameter is very small.

The successor evaluates the solution as a convex combination. Set `s=max(p,eta)`, `u=(p/s)(1-eta)` and `v=eta/s`; then

`rho_star = (u I/2 + v tau)/(u+v)`.

Scaling before multiplication avoids near-one subtraction and premature underflow. The source validates the target as a finite Hermitian, positive-semidefinite, trace-one 2×2 matrix within its explicit 1e−12 tolerance; it does not silently project or renormalize the caller's target. Boolean, nonfinite and out-of-range probability inputs are rejected.

The September 5 UTC receipt records 13 passing methods, with a 760-digit Decimal oracle over ten difficult parameter pairs, 72 channel-invariance subcases and 100 seeded density subcases. These subcases are subordinate to the 13 methods, not additional trial populations to add indiscriminately. For two equal smallest positive binary64 subnormals and a pure-zero target, the result has diagonal values 0.75 and 0.25. Extremely slow contraction or an individual floating-point update rounding to identity does not negate the exact model's unique fixed point. No physical thermodynamic efficiency or cost-free entropy reduction was measured.

Reproduction boundary: the retained runner is `python entropy/run_entropy_audit.py` from a reconstructed C002 root, or the focused test module in its proper directory. It requires NumPy and creates a new receipt; the historical run used Python 3.12.13/NumPy 2.3.5. This preparation did not run it. The incomplete original module remains an original-source gap, even though the bounded successor is complete.

## 5. Three semantic qubits, carrier scale and preserved model choices

The three-qubit source models a fixed semantic register in an eight-dimensional Hilbert space. GAUCIA, Leviathan and Nadine label the three roles; the labels do not demonstrate live agents or hardware qubits. For carrier dimensions N at least eight and divisible by eight, the construction is `C^8 tensor C^(N/8)`. Extra carrier modes are not extra semantic qubits. N=2 and N=4 are explicitly lossy projections.

The retained family uses a Hadamard-basis reference, declared local rotations and controlled coupling, reduced densities and nine Bloch-coordinate channels across carrier sizes 2 through 512. A degree-four Chebyshev remapping is a provisional chosen model and its residuals are in-sample fitting measures. The normalization correction did not alter role assignments, dimensions, coupling constants or that polynomial interpretation.

Its provenance is unusually important. The original object was reported as 16,249 bytes; authenticated source-text retrieval yielded a 16,248-byte reconstruction when original-byte retrieval failed. The retained source gate is `TEXT_RECONSTRUCTION_NOT_BYTE_VERIFIED`. The missing byte was not guessed. The corrected implementation and tests apply to that recovered text, not to an authenticated exact original object.

The original reconstructed normalization could divide a huge finite vector by infinity, return an all-zero state and proceed as if validation succeeded. Lifted-state reduction could then produce a zero-trace density. The candidate uses scaled normalization in both paths, rejects invalid tolerances and preserves the distinct cutoffs: default core threshold 1e−10; zero threshold for finite nonzero lifted-state normalization. The historical receipt records 22 passing methods. A separate comparison of 504 inherited numerical leaves has maximum absolute change 2.53681827024348e−14 against tolerance 1e−12. The output byte identities correctly change with last-bit differences; the old identity is not reassigned to new output.

The mathematical contribution is a bounded correction and a clarified carrier/semantic distinction. It does not prove physical multi-agent coupling, an increase in semantic qubits with matrix size or an out-of-sample approximation guarantee. Reproduction uses the preserved `three_qubit/run_validation.py` after reconstructing logical paths in a short workspace and installing NumPy; the receipt names Python 3.12.13/NumPy 2.3.5. Original-byte recovery remains unresolved.

## 6. C002 circuit API review: supporting integration evidence

The same retained C002 package also includes original/candidate circuit code, frozen configuration and a returned Windows review receipt. Its report records 16 focused test methods passing on the owner's laptop while 13 frozen circuits retained exact result bytes and 383 existing engine checks. Sixteen methods, thirteen circuits and 383 checks are three different populations. This is supporting circuit/API validation, not an additional physical quantum experiment or proof that all QEL modules ran on that laptop.

The preserved report retains two procedural failures: an initial resource-gate wrapper failed before Node execution, and an inline closure command failed after successful tests. Corrected wrappers did not relax the resource thresholds or rerun the passed tests to erase the history. Peak working-set measurement was unavailable and remains null. The 64 MiB V8 old-space setting was not a total-process RAM cap. The stated 166.2747 ms test duration is not a workload performance benchmark. Existing production source/profile was not replaced by this review candidate.

The report's assurance is exact returned-byte verification plus bounded test evidence. The complete independent body-level reassessment of every circuit engine method is outside this consolidation. The returned test/configuration files and receipts are nevertheless indexed so the main manuscript can cite the real integration evidence without upgrading it to a universal certification.

## 7. JARVIS aluminum: full-spectrum variational fitting and a strong classical control

The September 28 assessment targets the eight-orbital Wannier tight-binding model for aluminum, JVASP-816. The original benchmark contains 24 ordered reciprocal-space points, each an 8×8 complex Hamiltonian with eight required ascending energy values. The resulting population is 192 scalar predictions for one material; repeated path points remain in order and no Fermi-energy shift is applied.

The circuit ansatz is a fixed three-qubit state vector with 18 angles: three layers of RY and RZ rotations on each qubit, with declared CNOT links between the first two layer boundaries. The local adjoint implementation explicitly cites the published Jones–Gacon method. Its constant number of state-vector work buffers is constant with respect to parameter traversal in this fixed implementation; it is not constant memory in qubit number. A state vector still has `2^n` amplitudes.

For each Hamiltonian, the adapter subtracts its mean diagonal entry and divides the centered matrix by a row-sum scale. It then fits successive states against

`H_j = H_normalized + 4 * sum_(k<j) |psi_k><psi_k|`.

The overlap penalty discourages finding an already fitted state. This is an implementation of the published variational quantum deflation approach, not a new-invention claim. Each of eight states receives two seeded starts and at most 400 BFGS iterations per start, giving 384 starts for the original path. The gradient tolerance is 1e−9, maximum step norm two, up to thirty backtracking steps and Armijo coefficient 1e−4. Saved seed derivation, fitted angles, amplitudes, stopping reasons and per-point diagnostics make the execution inspectable.

No reference eigenvalues or precomputed target eigenvectors were passed into this VQD optimizer. This distinction matters because the retained dependency `q8-fast.mjs` also contains a different hybrid path that obtains a classical target; the assessment calls `refineBFGS` directly on the penalized Hamiltonian, not that hybrid routine. The final states are checked using the unchanged Q8 SOP circuit implementation and a separate dense implementation. Recovered historical Python emulator files were not the engine executed for this assessment.

The original path's saved MAE is 3.4501989767139057e−6 eV, with maximum scalar error 2.424081433360925e−4 eV and approximately 20.582 seconds after setup. A separate conventional Jacobi solver gives MAE 2.3408413332703937e−9 eV in approximately 0.911 seconds. The classical control was therefore both more accurate and faster on this small problem. The approximately 859-fold lower error than a displayed historical leaderboard entry is a source-pinned score comparison, not a matched runtime comparison, assigned rank or quantum advantage. The upstream comparison is pinned to `atomgptlab/jarvis_leaderboard` commit `b055e31bcd43a2da164a10df59198699297b53a9`; the historical benchmark ZIP blob is `a7440528cbd375d21aebaad183558f0830adc864`.

The result has substantive verification but meaningful residual error. The saved numerical receipt reconstructs the 24 matrices from 1,041 Wannier lattice blocks with maximum difference 2.220446049250313e−16 eV. Replay of 192 saved states finds maximum dense-energy discrepancy 3.907985046680551e−14 eV and amplitude discrepancy 6.206335383118183e−16. Maximum state residual is 0.005244191334342701 eV, maximum pairwise squared overlap is 2.559216981003536e−7, and 187 of 384 starts reach the iteration budget rather than gradient tolerance. Good mean energy error does not prove that all approximate eigenstates are fully converged.

An additional same-material assessment freezes 24 new reciprocal-space points and unchanged settings before prediction, excluding the original path entries and six historical additional points. It adds 192 energy predictions; references are generated afterward in a separate process. The saved MAE is 1.2888900558943352e−6 eV, maximum error 4.240288216550425e−5 eV, elapsed time 23.6091527 seconds and sampled maximum process memory approximately 91 MiB. Both declared engineering targets—MAE at most 1e−4 eV and maximum error at most 1e−3 eV—pass. They are local targets, not official JARVIS thresholds. Of 384 starts, 239 stop at the iteration budget. The largest residual is 0.009607193267454683 eV. The official-path scorer rejects the additional mode to prevent mixing the assessment sets.

Further error analysis attributes 94.93% of original-path total absolute error to zero-based points 11 and 3. Closely spaced upper levels provide a plausible target for future investigation, but the association does not prove a cause. No predictions were replaced by reference answers. Historical answers had already been inspected, so the original assessment is benchmark development, not a blind held-out trial. The additional set extends point coverage on aluminum, not generalization to another material.

Reproduction is not yet one-command portable from the selected dependency copy. The preserved 25-file local dependency selection contains the numerical kernels, hash helper, original 24×8×8 input fixture and two upstream notices. The unchanged scorer/verifier additionally reference `references/official_reference.json` and `inputs/wannier90_hr.dat`; rebuilding the additional-point selection also reads the earlier `CONTRACT.json`. Those three files are absent from that selected dependency directory but the broader inventory located them in the original laptop `JARVIS_Private_20260920_01` collection. The dependency-recovery receipt confirms the 2,260-byte reference and 3,336,536-byte Wannier file match retained archive members exactly; the 2,611-byte contract records the six earlier additional points. This consolidation independently checked those current bytes against the receipt's identities. Availability is resolved. The runner, scorer and verifier still contain literal D-drive roots. Remaining work is deliberate path/dependency assembly and versioned replay preparation, not a claim that the originals never existed or that the saved results failed.

Once exact dependencies are materialized and paths deliberately adapted in a separately versioned copy, the retained entry points are `node --experimental-vm-modules run-assessment.mjs full NEW_LABEL`, `node score-assessment.mjs NEW_LABEL`, and `node --experimental-vm-modules verify-assessment.mjs`. Full fitting is a new optimization run; verifier replay is a new verification attempt. Both write evidence and require new destinations. The existing verification receipt is not overwritten. Additional analysis uses `analyze-additional-data.mjs`; its fixed output names also require a disposable reconstructed tree. The Colab-exported upstream `reference-method.py` contains notebook shell syntax and is reference material, not a standalone program used for these results. None of these commands was run for this consolidation.

## 8. Performance work: less repeated computation, unchanged fitted answers

The subsequent performance change preserves the same circuit order, objective, initialization, BFGS update arithmetic and stopping budgets. `cached-adjoint.mjs` computes each angle's sine and cosine once per objective state and reuses them during reverse gate application. `compact-bfgs.mjs` stops retaining unused per-iteration history while continuing to report final parameters, iterations, reasons and diagnostics. This is an implementation optimization of the same workload, not a new physical algorithm or substitution of classical answer vectors.

Two retained controlled batches each use four fresh processes in old/new/new/old order, two observations per implementation. Each process computes the original 24-point, 192-energy set. The first accepted batch reduces median numerical time from 17.870 to 14.807 seconds (17.1%), CPU time from 18.852 to 15.852 seconds (15.9%), and largest observed process peak from 91.1 to 66.7 MiB (26.8%). A later audit batch reduces time from 18.522 to 16.050 seconds (13.3%), CPU time by 13.1% and largest observed process peak by 26.6%. All 192 energies and fitted parameters match exactly within each controlled batch, with attempts, stopping reasons and state diagnostics retained. The additional dataset also matches its previous outputs.

Both accepted batches miss the declared 20% time-reduction target. The first allocation rewrite is retained as a negative result: it reduced memory but increased time by 52%; two intermediate variants remained slower. These facts are part of the research result, not disposable preparation history. Only two observations per version per batch on a live laptop support bounded workload-specific improvement. The timings exclude process/module startup, process memory is not whole-computer RAM, and active background applications prevent turning this into a general Windows speed rating.

A separate result cache keys reuse to input, settings, runtime and relevant implementation identities and checks complete ordering and prior execution state. One launcher reuse takes 0.062 seconds after entry-point startup compared with a preceding 16.804-second fresh additional-data run. Reuse is retrieval of an existing answer, not fresh optimization hundreds of times faster. The saved cache test accepts a valid result and rejects six stale/corrupt/incomplete/invalid cases. The consistency checks do not protect against an adversary able to rewrite every record and do not supply an owner signature.

The launcher requests below-normal priority, limits V8 old space to 128 MiB, uses a single process, enforces one job per folder and checks the 180-second work budget between bounded optimization starts. An old-space setting is not a total process-memory cap or a hard deadline within an individual long start. Interruptions may leave an explicit lock rather than being silently discarded. Historical installation-pending prose in the performance README was superseded elsewhere by a later installation receipt; do not use the earlier prose to claim the upgrade was never installed, or use a later installation receipt as a new benchmark.

Reproduction boundary: `node --experimental-vm-modules benchmark.mjs NEW_BATCH_LABEL` is the retained four-run benchmark entry point after verifying runtime, source locks, exact fixture and path configuration. It spawns fresh numerical work and therefore would create a new measured batch, not merely restate saved performance. `load-numerics.mjs` retains D-drive roots and expects a sibling `jarvis-assessment` directory; the preserved folder is named `jarvis-aluminum`, so reassembly must restore that logical relationship or explicitly adapt it. Existing result folders and contracts must remain immutable. This consolidation reads the historical results and code only.

## 9. Generation A RC1: a 21-capability successor suite with distinct mathematical domains

The August 21 RC1 collection and August 22 kernel-integration report materially broaden the research beyond the later three-qubit Task Alpha workload. The locally recovered integration package retains the actual common suite, 21 capability implementations, helpers, B–D behavior reconstruction and registry, tests, checkpoint records, correction ledger and validation evidence. The full inventory is maintained separately by the inventory reviewer; this analysis selects the source modules and reports needed to describe the mechanisms. A capability is not necessarily one file, and the September 17 mechanism supplement's twenty rows are a different, overlapping editorial population.

These are explicitly corrected domain successors, not authenticated original March algorithms. The LQES and LQEO headers directly call themselves clean-room forensic/reference corrections and disclaim original historical bytes. The Generation B/C/D behavioral layer covers 31 generation-bound records, with exact historical source custody still open. Number-only matching therefore cannot identify an original algorithm or prove that the current implementation existed at its earliest historical date.

The common quantum-information substrate validates normalized complex states, positive unit-trace density matrices, unitary gates and Hermitian Hamiltonians. It supplies `U = exp(-iHt)`, Born probabilities, operator-sum channels `sum K rho K†`, partial traces, entropy, concurrence and negativity. These are established mathematical models implemented in classical numerical software. The suite deliberately distinguishes pure-state/unitary dynamics, open-system channels, feedback with assumed state information, statistical estimators and non-quantum models.

The substantive mechanism groups are:

| Capability family | Actual method and model | Main scientific boundary |
|---|---|---|
| State transition, numerical stability | Basis/uniform/custom preparation, Hamiltonian exponentiation, inverse-CDF measurement; conditioning, Hermiticity/unitarity defects, repeated-versus-direct evolution and SVD-backed least squares | A residual is not a universal forward-error bound; a simulated draw does not reveal an unknown state without measurement. |
| LQES entanglement synchronization, LQEO entanglement optimization, LQCP coherence | Validated evolution; reduced-state entropies and fidelity; explicit entangling XX operations with parameter-grid objectives; basis-dependent coherence and dephasing | Local rotations alone do not create entanglement; correlations, synchronization, coherence and entanglement are distinct. Later C002 numerical corrections must not silently replace the earlier RC1 source. |
| Error-correction stabilization | Ideal five-qubit [[5,1,3]] stabilizer code, syndrome projectors, Pauli recovery and Knill–Laflamme scalar-identity checks | Corrects the specified single-qubit Pauli set under ideal recovery, not an implemented fault-tolerant device with measured overhead. |
| Superposition protection | Three-qubit phase-flip repetition code, with logical error `q = 3p² - 2p³` for independent Z errors | Improves that model for `0 < p < 1/2`; does not correct arbitrary Pauli errors. |
| State regeneration | Coherent flagged leakage into a declared four-dimensional space and recovery; separate known-target replacement | Coherently retained phase can be recovered; erased unknown phase cannot be inferred by preparing a chosen target. |
| Wavefunction stabilization | Bloch-sphere state feedback using exact assumed estimates and bounded corrective rotations, `alpha = min(g theta, alpha_max, theta)` | Ideal feedback can contract the declared target error; it assumes information and control resources and cannot purify a mixed state by unitary rotation. |
| Energy optimization | Explicit variational finite-grid minimization of `⟨psi(theta), H psi(theta)⟩`, compared with `eigh(H)` | A normalized trial state's energy is an upper bound on the ground-state energy; the exact ground energy is a lower bound on the trial energies. The grid optimum is not proof of a globally accessible ground state for arbitrary ansatz or Hamiltonian. |
| Resonance amplification | Optical Bloch affine dynamics with relaxation, dephasing, detuning and drive | Saturation and power broadening are modeled; this is not Grover amplitude amplification or unrestricted gain. |
| Thermal regulation | Gibbs targets and generalized amplitude damping from specified bath excitation/relaxation rates | Temperature depends on Hamiltonian and units; multiple baths need not imply a single thermal equilibrium. |
| Entropy control and probability control | Depolarization followed by replacement; declared diagonal or coherent targets and contraction of state/probability differences | Target preparation consumes a known description. Equal probabilities need not imply equal phase or state. The weak-positive entropy-channel gate was later corrected in C002. |
| Entropic balancing | Partial-SWAP unitary, random-SWAP channel and separate open target replacement | Unitary partial SWAP is reversible; random SWAP approaches a symmetry average depending on the initial state, not a unique global target. |
| Noise reduction | Ornstein–Uhlenbeck detuning, Hahn/CPMG toggling filters, phase variance and pulse-error factors | More pulses can worsen coherence when pulse errors accumulate; the Markov factor is not reversed. |
| Error mitigation | Readout-matrix inversion, Richardson extrapolation, signed inverse-channel sampling and symmetry postselection | Returns an estimator, not a recovered density. Noise inversion can be singular and increases variance; calibration mismatch causes bias. |
| State reinforcement | GKSL evolution with fixed-target pumping and dephasing noise | Stabilizes a specified target under declared rates; it does not preserve every unknown input. Stationary-state uniqueness depends on rates, not merely an observed fidelity plateau. |
| Field stabilization | Classical one-dimensional lattice quadratures, discrete Klein–Gordon stiffness, proportional/derivative tracking and implicit midpoint integration | Classical field dynamics, not operator-valued quantum field theory or laboratory field control. |
| Phase synchronization | Classical coupled phase network with offsets, pinning and detuning; equatorial-state fidelity as a derived interpretation | Phase order is not necessarily lock to the required reference; finite noisy trajectories are not a global convergence proof. |
| Signal integrity | Classical OFDM/QPSK, cyclic prefix, multipath/AWGN/carrier offset, channel estimation and regularized equalization | Complex baseband symbols do not make the channel quantum; BER/EVM remain classical communication metrics. |

The RC1 report retains 1,665 original domain methods plus 57 integration methods, or 1,722 unique accepted unittest methods. It also records 21 capability paths, six cross-capability workflows and 26 release-gate checks. Those are separate populations and must not be summed as independent scientific experiments. Paired byte-identical receipts demonstrate deterministic replay of those records; the current consolidation has not rerun the suite or independently audited every proof and test.

The August 22 kernel adds validated preparation, stored-adjoint reversal, explicit selective measurement, controlled relative-phase kickback, CPTP dephasing and amplitude damping, bounded adaptive gate placement and generation-aware routing. Its correction ledger exposes a useful negative result: a one-step greedy search could not move `|00>` toward `|11>` because either first X gate leaves target fidelity zero. Bounded beam look-ahead finds the required two-step path. This is a finite search correction, not a general optimal circuit-synthesis guarantee.

The migration adapter routes 31 B–D records as eight corrected successors, twelve safe primitives, three cases requiring intent selection and eight non-quantum lanes. The kernel report records 87 preserved behavioral plus 59 new kernel/migration methods, 146 in total, and 21 replayed RC1 checkpoints with the prior suite identity. These overlap earlier mechanisms and should not be added to the RC1 count without a full unique-method reconciliation. The owner-review audit withdraws the unproven statement that the monolithic runner exceeded ten minutes: the hosted invocation ended at its effective single-call window before producing output. Resumable checkpoints later completed; no measured ten-minute algorithm-runtime limit is established. Type coercion, strict receipt serialization, Python Boolean literals, drawing syntax and validation-phase identity corrections are retained as procedural/source defects, not hidden.

Replay requires the recovered relative directory tree, Python, NumPy and SciPy; the numerical kernel imports the retained RC1 suite and its SGL Prime helper. `tools/qel_qpu_integration_validation_v1.py` validates saved source/evidence rather than independently recreating every numerical result. The original canonical unit runner and checkpoint scripts are retained for a separately scoped replay. The unsigned/pending-release fields describe the historical package state; they are not new permission gates for this authorized documentary review. No new acceptance, signature, physical experiment or original B–D source closure is implied.

## 10. September live scaling: workload capacity with an explicit memory boundary

The September 18 scaling collection preserves three attempts, their source copies, six exact extracted kernel functions, contracts, individual worker results, execution stdout/stderr and an independent review. Unlike the fixed semantic three-qubit carrier construction, this workload allocates a genuine dense state vector of `2^n` complex amplitudes for n simulated qubits. The source stores real and imaginary parts in two Float64 arrays, giving `16 * 2^n` state bytes. It implements Hadamard and controlled-X by index-pair updates; the GHZ routine applies H to qubit zero followed by controlled-X to every other qubit, and the inverse reverses those gates.

Each trial checks the analytical GHZ output and return to the zero basis state, then applies the same forward/inverse circuit to a deterministic full-support input whose phases cycle through `1, i, -1, -i`. Full-array scans check finite amplitudes, support, expected output, normalization and reversal. This is much stronger than allocating an array alone, but still a structured H/CX workload, not every arbitrary state or algorithm and not dense matrix simulation.

Across attempts 02 and 03, sizes one through twenty-one completed, with one trial below twenty and three each at twenty and twenty-one: 25 completed trials and 225 successful repeated evaluations of nine checks. At twenty-one, the 2,097,152 amplitudes occupy 32 MiB. Median complete validation time is 766.6211 ms across three samples, range 706.4625–772.9428 ms. Twenty-qubit median is 391.4782 ms. These timings include allocation, initialization, two forward/inverse workloads, numerical scans and included resource snapshots; they exclude process launch and initial kernel loading. They do not estimate arbitrary 21-qubit algorithm runtime.

The next size, twenty-two, was not admitted. It required 64 MiB state storage plus the unchanged 256 MiB reserve, while observed free memory was 307.7109375 MiB against the required 320 MiB. The 12.2890625 MiB shortfall is a workload admission-policy result under that laptop's then-current load, not numerical failure or a hard machine maximum. At twenty-one, the largest sampled RSS was 78,684,160 bytes; Node separately reported maximum RSS of 77,516 KiB. State storage and whole-process memory are different metrics, and samples may miss transient peaks.

Attempt 01 executed no circuit because prelaunch reserve was insufficient. Attempt 02 completed sizes 1–13 after fixing double reservation of runtime memory, then its parent admission threshold stopped before fourteen. Attempt 03 removed the resident Node controller using a PowerShell supervisor, retaining the same worker reserve, and completed fourteen through twenty-one. All 26 child records—25 PASS and one admission stop—match aggregate entries and saved stdout in the retained independent review, with no recorded child timeout or stderr. Original production bytes were reported unchanged; the third aggregate's null device field is preserved and corroborated by execution/review context, not silently repaired.

A portable replay uses exact `kernel_functions.js` plus `live_scale.mjs` in a new directory and the `trial n trial_number` worker mode under Node with a 64 MiB old-space setting. The original supervisor enforces a 30-second child timeout and serial execution; its literal production/backup paths must be adapted explicitly before reconstructing full evidence envelopes. The generic non-trial driver also reads the original USB source and writes exclusive evidence names, so it must not be run unchanged from a populated evidence directory. Changing free memory means a repeat might admit a different largest size. This consolidation reads the receipts and source; it creates no new capacity measurement.

## 11. Attribution, licensing and coherent claim boundary

The package's substantive progression is observable: loosely specified historical functions; an exact bounded emulator with a declared answer; explicit density/channel models and numerical corrections; same-material spectral fitting with controls and state replay; then measured implementation optimization without changing outputs. The unifying research issue is whether a declared mathematical object, actual executable method and measured claim remain aligned. That connection is stronger than a claim based on the word quantum in filenames, and it does not require claiming physical hardware or a novel primitive.

The two historical repository licenses are preserved verbatim in `source-notices/`. They are proprietary notices naming Sherman G. Laing, distinct from the initial MIT notice described by the historical source review. This consolidation does not infer that the initial notice licenses every later snapshot or establish legal ownership merely from a notice. The owner's authorization covers this preparation; downstream publication should retain the applicable exact notices and distinguish project expression from established mathematics.

The preserved JARVIS and leaderboard notices are also copied verbatim. They describe NIST software terms, including retention of the notice and warranty disclaimer. They should not be promoted into a blanket license for all third-party data, every upstream notebook dependency or all QEL source. The original data/scoring provenance and exact material-source receipts remain part of the attribution chain. The VQD and adjoint methods retain their literature attributions as recorded in the source. No independent novelty survey or current legal determination is made here.

Task Alpha and recovered mathematical source headers retain owner/project and assistant-role attribution. A standalone redistribution license for every privately retained QEL module was not located in this bounded selection; that is recorded as a disclosure detail, not a new permission barrier to the already authorized review. Original source, reconstructed text, successor implementation and newly written documentary synthesis must remain visibly separate.

No new scientific execution, physical QPU experiment, USB access, production replacement, publication, certification or external submission occurred during this consolidation. Historical PASS results remain specific to their stated sources, populations and environments. Outstanding exact-source and portability gaps are enumerated in `WORK_INDEX.json`; they are neither concealed nor inflated into a claim that all existing research is invalid.


# JARVIS development and structured-state research

Research history of Sherman Gaucia Laing / Quantum.Earth.Laing. The historical reports name GAUCIA as the implementation and review assistant. This derivative was prepared with GAUCIA Actual as the primary project agent and Codex as supporting reviewer.

These chapters reconstruct the problem, method, correction and result from preserved contracts, code and saved reports. They are not verbatim interaction transcripts. Quoted numerical outcomes are historical observations in those records; preparing this edition did not rerun the experiments. Logical collection names identify sources without exposing private machine locations. Claim identifiers connect the text to `CLAIM_SOURCE_MAP.json`. Publication remains subject to the owner's review.

## 1. Establishing the calculation and keeping a failed target visible

The first JARVIS private study asked whether the existing Q8 circuit engine could produce correct complex states and energy expectations for a real material input, and whether a small parameterized circuit could approach its lowest eigenvalue. The input was the preserved JVASP-816 aluminum Wannier model: 1,041 lattice-vector blocks containing 66,624 complex entries. At each reciprocal coordinate, the calculation combined the blocks with their phase factors and degeneracies to form an eight-by-eight Hamiltonian in electronvolts. The original 24-point order, repeated path endpoints and zero Fermi shift were retained. Eight orbital components were encoded as three simulated qubits. This is an orbital matrix model, not a full many-electron material ground-state calculation. [J01-SETUP]

The study separated three computational roles. The unchanged Q8 circuit modules prepared state amplitudes. An independent dense gate calculation checked every complex amplitude and energy expectation. A separately implemented classical Jacobi eigensolver supplied eigenvalues and reference ground energies. Archived Python code was preserved but was not executed in this stage. This separation matters: the full set of band eigenvalues came from the classical control, while the Q8 calculations supplied the circuit states being evaluated. [J01-METHOD]

The saved results record 90 passing circuit/energy cases: three state preparations for each of 30 matrices, consisting of the original 24 points and six additional points from the same material. The classical control produced 192 ordered eigenvalues for comparison with the published rounded reference and 48 additional eigenvalues outside that official comparison. Its mean absolute error against the 192 rounded targets was about 2.34084 × 10⁻⁹ eV. Negative controls rejected malformed, nonfinite and non-Hermitian inputs; a phase control distinguished states with equal probabilities but different complex amplitudes. These checks concern this calculation and its declared tolerances. The six new points were not new materials or an official competition holdout. Historical reference values had already been seen, so the work was not a blind prediction experiment. [J01-RESULTS]

The variational circuit had 18 RY/RZ parameters and intervening CNOT gates. Its first optimizer minimized one angle at a time: three energy evaluations determined that angle's sinusoidal energy dependence, after which the proposed coordinate update was checked. The initial budget was two seeded starts and at most 12 sweeps. Five of six selected optimization cases reached the fixed 10⁻⁴ eV energy-gap goal. Original point 4 did not. Its gap was 0.0004007142024144983 eV; separate follow-ups with four starts and 64, then 256 sweeps reduced that to 0.00014289359835650828 and 0.00012074495903213744 eV. The final value still missed the unchanged goal. More iteration improved the result without resolving the problem. Those adaptive follow-ups were neither new held-out cases nor separately replayed experiments. [J01-MISS]

Two subsequent executions reproduced the initial cycle's 17 deterministic result files, including its unresolved optimization outcome. Timing and resource records were separate. The two original complete cycles took approximately 7.25 and 7.07 seconds under the runner's timing boundary, which included numerical work and evidence operations but excluded process startup. Those timings cannot establish a speedup over a different historical Python workload. The contribution of this stage was a traceable execution of existing circuit code against material data, with independent controls and an honestly retained optimization miss. [J01-REPLAY]

## 2. Resolving the energy miss and discovering a state-accuracy limit

The next stage retained the same Q8 circuit engine and 18-parameter ansatz but replaced isolated coordinate refinement with coupled BFGS optimization after coordinate warmup. Parameter-shift derivatives guided simultaneous changes to the circuit angles. The optimizer received the Hamiltonian and seeded starting parameters, not reference eigenvalues or eigenvectors. Refining the four saved starts from the failed point brought their energies within approximately 3 × 10⁻¹⁵ eV of the reference; wrapping angles alone had not produced the improvement. The saved diagnosis therefore supports a correction in the optimization method for this case, without attributing it to a changed circuit representation. [J02-METHOD]

All 72 ordered cases met the 10⁻⁶ eV energy target. Their populations must remain separate:

| Population | Ordered cases | Distinct inputs or purpose |
| --- | ---: | --- |
| Expanded aluminum path and points | 42 | 28 unique reciprocal coordinates; repeated path points retained |
| Material stress set | 24 | 12 seeded random coordinates and 12 displacements around the original miss |
| Known-spectrum synthetic set | 6 | Deliberately representable ground states or ground spaces |

Together, the 66 ordered material cases comprised 52 distinct reciprocal coordinates from the same aluminum model. The worst absolute energy error across all 72 cases was approximately 3.41820 × 10⁻⁷ eV. The saved expanded validation also records 126 complex-circuit comparisons and 61 phase, basis, offset, derivative and perturbation checks. These are different checks on overlapping calculations and should not be summed as independent discoveries. [J02-RESULTS]

Energy accuracy exposed a second problem rather than settling state accuracy. Only four of six synthetic cases reached the 0.9999 ground-state or ground-space fidelity target. At excitation gaps of 10⁻⁶ and 10⁻⁸ eV, fidelity was approximately 0.943880 and 0.723705 even though the energy criterion passed. The smaller-gap case also met the gradient stopping tolerance. For a normalized state and a known positive gap Δ above the ground space, the bound 1 − F ≤ (E − E₀)/Δ explains why a small energy error can allow a large state error when Δ is very small. For exact degeneracy, fidelity must measure the full ground subspace rather than one chosen eigenvector. The saved finite-precision diagnostic estimates are not interval-arithmetic certificates. [J02-FIDELITY]

Passing the energy threshold also did not mean every optimizer start stopped by convergence: among 84 expanded-validation starts, 33 reached the gradient criterion and 51 consumed the iteration budget. Two validation executions matched 93 deterministic JSON files; two stress executions matched 67; a fresh-folder quick replay matched nine diagnostic files. The full portable wrapper was not separately executed end to end. This stage contributed a successful energy correction and a clearer acceptance policy: energy, state fidelity, numerical residuals and stopping reason answer different questions. [J02-REPLAY]

## 3. Repairing target construction while disclosing the classical solver

Stage 03 investigated the state-accuracy failures with a hybrid method that explicitly constructed a target conventionally and then fitted it through the unchanged Q8 circuit. A first Rayleigh-based repair improved acceptance but left cases in which target iteration stagnated. The subsequent method bracketed the lowest eigenvalue, selected a closer inverse-iteration shift, centered and positively scaled the Hamiltonian, and used bounded perturbed starts during circuit fitting. Its contribution was this implemented correction and the accompanying diagnostics; it was no longer a solver that used circuit energy alone. [J03-METHOD]

The saved matched comparison initially reported 720 cases. The baseline met the energy criterion in 696 and full acceptance in 424; the first repair reached full acceptance in 681; the bracketed revision reached 720. A later initialization review found one already-solved synthetic control caused by seed reuse. Removing it yields the corrected comparison below. The original population and its correction are both retained. [J03-POPULATION]

| Method | Full acceptance after excluding the reused solved control |
| --- | ---: |
| Earlier optimizer | 423 / 719 |
| First Rayleigh-based repair | 680 / 719 |
| Bracketed revision | 719 / 719 |

The revision resolved 296 baseline misses and 39 first-repair misses in that corrected comparison, without losing a previously passing case. These counts do not turn 719 finite constructed cases into a universal convergence result. Additional saved sets included 72 prior regressions, 138 fresh-parameter cases, 48 independent-basis cases, 120 centered-solver validations and 125 material-grid points. They have different purposes and share some matrices. Of the 125 grid coordinates, 124 periodic coordinates were absent from previous material cases; the grid's largest reported energy error was about 6.91244 × 10⁻⁷ eV and its lowest fidelity about 0.999999944. [J03-SUPPLEMENTAL]

The negative controls sharpen the interpretation. A flat-start experiment exposed 56 incorrect zero-gradient starts; perturbed fitting resolved the 64-case set. All 39 first-repair misses had fitted their supplied targets accurately, pointing instead to stalled target construction. Centering repaired the represented-matrix target cases in the 45-transformation study, but three input transformations had already lost information through rounding; their intended original states were not all recovered. A floating-point eigenvalue bracket is not an interval certificate. This remains an eight-amplitude simulation with an explicit classical target solver, not physical quantum execution or evidence that the quantum circuit independently discovered the target. [J03-LIMITS]

## 4. Measuring a faster implementation with the full comparison cost visible

Stage 04 addressed repeated computation in the three-qubit hybrid workflow. The implementation used dense typed arrays and an adjoint derivative calculation while preserving the circuit and independent result checks. For the recorded 18-angle circuit, the previous parameter-shift gradient required 36 complete forward evaluations. The revised calculation reused one forward state, one Hamiltonian-vector product and 44 reverse gate applications for the 22 gates. A validated binary model cache also reduced repeated parsing. The source study credits established reverse-mode differentiation and numerical measurement methods; this chapter claims an implementation and its measured behavior, not invention of those general methods. [J04-METHOD]

The saved derivative validation records 512 state comparisons and 1,152 derivative checks. Separate result sets report 72 fresh challenge cases, 72 preserved regressions and 149 material points under default application settings. These sets overlap and their totals should not be added as a count of independent scientific problems. [J04-VALIDATION]

The performance comparison has two different boundaries:

| Measurement | Comparison population | Earlier hybrid | Optimized hybrid | Recorded ratio |
| --- | --- | ---: | ---: | ---: |
| Aggregate solver time | 24 cases, three repetitions per method: 72 runs per method | 528.546 s | 8.027 s | approximately 65.85× |
| Mean complete fresh-process request | Three points, three repetitions per mode: nine requests per mode | 17.248 s | 3.679 s | approximately 4.69× |

Both hybrid solvers passed their 72 timed solver runs. The 27 total complete requests included the third, direct-solver comparison mode; they were not 27 requests per hybrid. The reported average peak numerical-worker memory fell from approximately 114.4 to 55.3 MiB. Operating-system caches were not cleared, so fresh process does not mean cold disk. Solver time and complete-request time must not be interchanged. [J04-PERFORMANCE]

The comparison retains two important limits. The energy-only baseline passed 54 of 72 timed runs. Direct classical solving remained cheaper when circuit parameters were unnecessary: approximately 22.8 ms mean solver time and 3.37 s mean complete-request time on their respective comparison populations. The optimized hybrid still calculated its target conventionally before fitting the circuit. Consequently, the measured improvement concerns this local application and workload, not quantum speed advantage, whole-Windows acceleration, a new operating system, or target-free discovery. The archived failures in profiling and audit setup remain separate from the completed numerical results. [J04-CONTROLS]

## 5. A target-free next experiment that remained a protocol

Stage 05 proposed returning to circuit energy and derivatives without physical-matrix diagonalization, old predictions or target-projector fitting in the solver process. It specified at most three candidate revisions using 16 development cases and a separate planned holdout of 24 matrices: 18 synthetic matrices from three independent bases across six gaps, plus six material matrices. Three independent starts per matrix would produce 72 trials per method. The proposed comparisons were single-start BFGS, multistart BFGS and a curvature method, with explicit computation budgets and separate energy, fidelity, normalization and circuit-consistency criteria. Candidate freezing before scoring and no post-holdout tuning were part of the protocol. [J05-PLAN]

The saved redirection receipt states that the study paused before new solver execution and records zero new numerical jobs. Therefore the 72-trial figures describe a design, not completed evidence, and this stage supplies no result for the proposed methods. Its contribution to the research history is a concrete response to the limitation exposed in stages 03–04: a protocol for testing whether acceptable state accuracy could be obtained without a precomputed classical target. [J05-STATUS]

## 6. Recovered inputs and the remaining portability work

Consolidation recovered the exact named stage-01 dependencies referenced by the later JARVIS scorer, verifier and additional-point selector: the 2,260-byte official-reference JSON, the 3,336,536-byte Wannier input, the 2,611-byte historical contract and the original ordered 24-matrix fixture. The reference JSON and Wannier file were each checked byte for byte against their preserved archive members. The contract retains the six previous extension coordinates used to exclude old points during later input selection. This resolves a missing-input omission in the earlier collected subset. [DEP-RECOVERY]

Recovery is distinct from a portable replay. Original scripts still refer to historical installation locations and some wrappers require paired storage destinations. A future replay needs an explicit path adapter, declared runtime/dependencies, fresh output locations and a check that the intended source identities remain unchanged. The recovered files were not silently substituted for different inputs, and no new scientific run was made for this chapter. Upstream dataset and software notices remain part of the preserved collection. [DEP-PORTABILITY]

## 7. Structured-state representations with a 60-qubit interface

The recovered structured-state implementation collection contains two different representations, MPS and SOP, plus their integration wrappers. They should be described by their storage and approximation rules, not only their qubit count. Their presence is source evidence; this chapter does not convert a recovered implementation into a new benchmark result. [STRUCT-SCOPE]

The matrix product state implementation stores a chain of complex site tensors. Its default bond limit is 32. Adjacent controlled operations contract local tensors and refactor them using twice-reorthogonalized modified Gram–Schmidt QR. Residual columns at or below the configured threshold are omitted and their norms are retained in diagnostics; the default threshold is 10⁻¹³. There is no singular-value truncation in this code, but that does not make its nonzero residual omission exact. The tolerance is local and absolute, not a certified bound on total state error. Exceeding the bond cap raises an error before the two replacement tensors are committed. These mechanisms support bounded structured-state computation while making a resource boundary visible. [STRUCT-MPS]

The sum-of-products implementation represents a state as a weighted sum of product branches. It permits 1–60 qubits and at most 64 branches. Its declared algebraic representation does not use tolerance-based pruning or approximate branch merging; arithmetic still uses floating-point values. A controlled operation can expand the branch list, and an over-cap result is rejected before replacing it. Its numeric-payload calculation excludes JavaScript array/object overhead, so it must not be presented as total process memory. A compact expression may have nonzero amplitude at every basis string while requiring few product branches. Full basis support therefore does not imply arbitrary dense-state complexity. [STRUCT-SOP]

The two representations are complementary engineering choices with different complexity limits. A state that fits one bounded representation need not fit another. Neither the 60-qubit interface nor a structured demonstration establishes storage or general manipulation of an arbitrary vector of 2⁶⁰ complex amplitudes. The preservation work found byte-equal aliases of these MPS/SOP sources at two additional local source-copy locations, while the JARVIS package retains its own separately identified SOP version. Version identity and source preservation are useful for reproducibility; they are not proof of correctness, novelty, ownership, certification or physical quantum execution. [STRUCT-BOUNDARY]

## 8. A separate JARVIS DFT 2D dataset review

The quantum-derived materials-data review concerns an acquired JARVIS density-functional-theory snapshot, not the aluminum circuit benchmark above. The public follow-up dated September 18, 2026 UTC describes 1,103 records, all 65 top-level fields and traversal of their nested values. It retains the original 355 missing exfoliation-energy values and 42 differences between the `nat` field and supplied atom-array length. Those observations were flags requiring interpretation, not 42 established corrupt structures. [DFT-SCOPE]

At a 0.001 Å tolerance, a periodic-translation diagnostic supported a repeated-cell interpretation for 40 of those 42 records. The dated update left JVASP-60484 and JVASP-6751 unresolved. Failure of that particular diagnostic did not prove that no smaller representation existed, and the diagnostic did not establish the historical exporter's behavior. The catalog's 1,109 listed records versus the acquired archive's 1,103 was also unexplained in that update. These are the update's dated findings, not a claim that later evidence could never resolve them. [DFT-INTERPRETATION]

The expanded inspection supplied useful boundaries for subsequent modeling: 15 entirely empty fields remained unknown rather than zero; four formula strings disagreed with atom-list composition; 34 exact descriptor pairs needed to stay together in any later train/test partition; and constant stored energy-above-hull values could not rank stability. Unit conventions, slab vacuum and normalization remained essential to interpreting response and transport fields. The 4,666 raw-file pointers were inspected as metadata; their linked calculation archives were not downloaded for that census. [DFT-COVERAGE]

The public companion preserves the follow-up interpretation, machine-readable observations, missing-value and atom-count lists, replay evidence and attribution/license notices. Its report records exact replay of the full-field profile and structure evidence. It explicitly says that the public selection does not include the full analysis code and source archives as a self-contained executable package. Those availability limits must remain visible. This was a review of calculated dataset properties: it performed no new DFT calculation, physical experiment or quantum-circuit simulation and did not benchmark the owner's emulator. Its contribution is a fuller, more reproducible documentary assessment of the acquired snapshot and its unresolved interpretations. [DFT-REPRODUCTION]


## Additional retained comparison: guarded inputs without measured accuracy gain

The separate September 18 improvement audit retains five known invalid inputs rejected by an existing guard, with the same 36 valid samples preserved. Its 24 matched ground-energy values have exactly zero before/after output difference and zero measured accuracy gain against the same reference. This supports that bounded validation behavior and output preservation; it does not establish projectwide reliability, improved intelligence or new physical accuracy. The report and its supporting records are preserved in collection `improvement-audit-20260918`, beginning with `QEL_Improvement_Audit_20260918.md`. The complete folder retains ancillary Bible and error-ledger context for provenance; those files are not counted as separate quantum studies. The authority review in `selected-provenance-reviews` also preserves the later driver exit-status correction accompanying the dense-scaling source. These saved comparisons and corrections were not rerun for consolidation.

