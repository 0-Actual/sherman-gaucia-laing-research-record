"""Independent read-only reconciliation and replay check for this documentary selection."""
import argparse, collections, hashlib, json, re
from pathlib import Path

p=argparse.ArgumentParser()
for arg in ('bundle','selection','replay'): p.add_argument('--'+arg,required=True,type=Path)
a=p.parse_args()
load=lambda p:json.loads(p.read_text(encoding='utf-8-sig'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
doc=load(a.selection/'quantum-selected-records.json'); receipt=load(a.selection/'selection-verification.json')
names=list(receipt['generated_sha256'])+['selection-verification.json','teaching-navigation.json','TEACHING_QUANTUM_EXCERPTS.md']
comparisons={n:(a.selection/n).read_bytes()==(a.replay/n).read_bytes() for n in names}
assert all(comparisons.values()),comparisons
all_rows={}; inputs=doc['input_files']
for pop,source in zip(['chronology','timeline','prior_work','portfolio','receipts','mechanisms'],inputs):
 path=a.bundle/source['path']; original=load(path)
 assert sha(path)==source['sha256'] and path.stat().st_size==source['bytes']
 for row in original.get('rows',original.get('entries',[])):
  all_rows[pop+':'+row['id']]=row
decisions=load(a.selection/'selection-decisions.json')['decisions']
assert {d['key'] for d in decisions}==set(all_rows) and len(decisions)==1154
included={d['key'] for d in decisions if d['decision']=='include'}
assert included=={r['key'] for r in doc['rows']}
for row in doc['rows']: assert row['source_entry']==all_rows[row['key']]
counts=collections.Counter(r['source_population'] for r in doc['rows'])
assert dict(counts)=={'chronology':71,'timeline':38,'prior_work':51,'portfolio':10,'receipts':5,'mechanisms':20}
teaching=load(a.selection/'teaching-navigation.json')
tp=a.bundle/teaching['source_path']; assert sha(tp)==teaching['source_sha256']
original=tp.read_bytes().decode('utf-8').splitlines(keepends=True); excerpts=(a.selection/'TEACHING_QUANTUM_EXCERPTS.md').read_bytes().decode('utf-8')
for passage in teaching['selected_passages']:
 text=''.join(original[passage['source_line_start']-1:passage['source_line_end']]).rstrip()
 assert hashlib.sha256(text.encode('utf-8')).hexdigest()==passage['excerpt_sha256']
 assert text in excerpts
ids={r['original_id'] for r in doc['rows']}
for gap in load(a.selection/'source-gaps.json')['gaps']:
 assert set(gap.get('summary_ids',[]))<=ids
public_names=names+['QUANTUM_SOURCE_CHRONOLOGY.md','SOURCE_LIMITS_AND_GAPS.md','source-gaps.json','README.md']
for name in public_names:
 text=(a.selection/name).read_text(encoding='utf-8')
 assert not re.search(r'\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b',text,re.I),name
 assert not re.search(r'(?<![A-Za-z])[A-Za-z]:[\\/]|/(?:Users|home|mnt)/',text),name
 assert not re.search(r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----|\bsk-(?:proj-)?[A-Za-z0-9_-]{20,}',text),name
result={'status':'PASS','replay_bytes_match':comparisons,'source_rows_accounted':len(all_rows),'selected_original_entries_exactly_preserved':len(doc['rows']),'population_counts':dict(counts),'teaching_exact_passages':len(teaching['selected_passages']),'all_source_inputs_unchanged':True,'gap_summary_references_resolve':True,'public_artifact_screen':'No private absolute path, conversation UUID or tested credential pattern in selected public outputs; contextual source limitations remain necessary.','scientific_experiments_executed':False,'public_posting_performed':False,'limits':'File and documentary reconciliation only; not physical quantum validation, complete source recovery, proof audit or independent study counting.'}
(a.selection/'independent-verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
