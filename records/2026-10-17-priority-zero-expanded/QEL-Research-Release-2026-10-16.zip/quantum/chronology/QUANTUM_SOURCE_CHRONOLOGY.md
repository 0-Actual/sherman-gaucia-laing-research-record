# Quantum research: documented origins, corrections and later studies

This chronology consolidates the quantum-related portion of the existing public-safe record. It preserves the distinction between a request, a named concept, source code, a reported software result and a physical measurement. The reviewed inputs establish a documentary history of concepts, classical simulation, mathematical code, corrections and teaching. They do not establish physical quantum hardware, general quantum advantage or a solution to the named open mathematical problems.

The source is a collection of later reviews and public summaries, rather than a new reading of every original conversation or experimental artifact. “Earliest” below means earliest located within the specified reviewed records. No historical experiment was rerun. Exact dates, offsets, inherited date warnings and complete selected source entries are in `quantum-selected-records.json`.

## 2023–2024: concepts and instruction

The earliest selected quantum-labelled concept is the October 19, 2023 “Quantum Waste Harmonization” record. The source itself says the quantum terminology and extraordinary performance lack a mechanism, code or tests. The nearby suit material likewise does not demonstrate quantum materials or simulations. These are retained as capability-correction history, not treated as inventions or experimental results. [Chronology C069, C071]

On October 21, 2023, the record describes a quantum-dot solar-absorber concept and a three-layer proposal. It supplies neither a validated material recipe nor bandgaps, a measured efficiency or a physical specimen. The same morning's quantum-mechanics, wave-particle and measurement teaching request is separate from the later emulator source. The exact teaching timestamp is `2023-10-21T08:15:32.668064-04:00`. [C094–C096; prior-work 0035]

The July 8, 2024 material contains conventional sine-wave/Bloch-sphere-style plotting and lesson requirements. The review reports a PDF-generation failure and does not establish a running quantum emulator. VR/access-lens and ERC-721 material includes a quantum-security placeholder that returns true; that is evidence of a draft placeholder, not quantum security or deployment. [C116, C117, C121; timeline PR-E10, PR-E11; prior-work 0046, 0050]

## February–March 2025: early code and the recovered algorithm series

February node and GAUCIA code uses conventional records, status strings, encryption and metadata. Calling a class or command “Quantum” or “Superposition” does not demonstrate the named physical behavior. The March 4 EnhancedNode material has actual matrices, normalization and matrix-exponential operations, but its real random matrix is not guaranteed to generate a unitary transformation. Its syntax failures, simpler tool result and limits remain in the record. [C148, C151, C152, C161, C163; prior-work 0139]

The explicit emulator-construction/mathematical-evidence requirement is recorded on March 10, 2025 at `05:50:01.264392-04:00`. The five March 11 precursors cover segmentation, redistribution, a Bell/CHSH-style scalar expression, an uncertainty comparison and FFT magnitude. Their names do not establish entanglement, a quantum neural network or a physical experiment. [C166, C168; timeline PR-M01; CODE-DATE-01–05]

The earliest recovered complex-state Algorithm 1 source is dated March 13, 2025 at `10:48:15.685403-04:00`. It describes a complex state of dimension 2ⁿ, normalization, matrix application, Born-probability sampling/collapse, Hamiltonian exponentiation and a three-qubit example. The original record is source evidence, not an original run receipt, and shape checks alone do not prove the required operator properties. A later copy does not replace the original source date. [C169, C172; CODE-DATE-06, CODE-DATE-27]

The historical correction is substantive. Algorithm 2's local X⊗I evolution does not by itself entangle a product state. Algorithm 3's threshold-and-renormalize operation is not general syndrome-based quantum error correction. The 18 labels for Algorithms 4–21 share a radial-rescaling/local-evolution family: changing the norm while preserving the ray does not demonstrate the separately named thermal, noise, entropy or correction mechanisms. The phrase “of 15,000” in historical titles is not evidence of 15,000 implementations. [C170, C171]

The catalogues represent 27 recovered source-body slots: five precursors, Algorithms 1–21 and one Algorithm 1 revision. The chronology's C322–C348 and public timeline's CODE-DATE-01–27 overlap. They are not 54 independent code bodies. The September recovery review reports 19 syntax passes and two failures among the original 21, and 25 passes/two failures among all 27. Syntax parsing is separate from execution and scientific validation. [C317; prior-work 0384; `overlap-map.json`]

## May 2025: placeholders and a corrected arithmetic conflation

The May 9 public-safe stub package assigns a hardcoded fidelity value of 0.9973. That value is not measured fidelity. The May 12 records separately preserve an informal 0=1 proposition and the assistant's erroneous adoption of it as a statement about superposition. Superposition does not make the distinct basis states equal, and the record does not establish a new arithmetic identity or implemented algorithm. The older portfolio's October 2023 anchor for this proposition is explicitly unsupported; the located proposition belongs to May 2025. [C201, C209–C211; prior-work 0150, 0196; portfolio P001]

## August 2026: successor mechanisms and explicit scope

Later successor sources must be judged by their own code and contracts, rather than inheriting either the validity or defects of the March originals merely because a label is shared. The prior-work record describes an Algorithm 14 correction using an XX interaction/reduced-state entropy example; a common kernel with state, operator, density-matrix and channel checks; idealized five-qubit error correction; a thermal model; and an entropy-control result that retains a target-versus-achieved discrepancy. [Prior-work 0321–0325]

The separate 20-row mechanism appendix describes the successor families and their limitations. It covers state preparation and transition, Hamiltonian/energy calculations, open-channel replacement and entropy control, idealized error correction/mitigation, noise and feedback models, plus numerical utilities. Some included families are explicitly classical: field dynamics, phase synchronization and QPSK/OFDM signal processing. Their retention prevents a quantum-sounding historical title from disguising a classical mechanism. The appendix is a later static analysis principally associated with the August 21 successor package, not an execution log or proof that all those mechanisms were in the March originals. [Mechanisms M001–M020]

The August 21 RC1 report records 1,665 domain methods plus 57 integration methods within that suite, alongside six workflows and 21 benchmark paths. Repeated receipts and successor suites must not be added into a project-wide success percentage. Emulated-QPU migration, QMath operator-role separation and three-semantic-qubit coupling are separately versioned reports; unresolved source-byte custody and absence of physical-QPU evidence remain explicit. [C272–C275; prior-work 0326–0331; receipt R002]

The August 27 owner correction requires a classical baseline, units, scaling, an oracle and measurable benefit for proposed quantum features. This is a research requirement, not evidence that every comparison was completed. [C280; prior-work 0337]

## September 2026: retained failures, bounded numerical results and scaling

The September records preserve a circuit path that skipped an unknown operation while reporting PASS, floating-point normalization/projective-distance defects, and a failed parent precision test population. They distinguish the corrected candidate's reported methods from inherited or overlapping checks. The three-qubit reconstruction remains one byte short of reported source metadata; the entropy uniqueness correction is a standalone successor and does not establish fast convergence. [C287, C288, C300, C301; receipts R003–R005]

Physical-laptop execution in these records means classical host execution. Logical paging and circuit-run counts do not add physical RAM or establish arbitrary-access performance; the corrected DNS-warning account does not establish emulator causation. A physical Windows laptop is not physical quantum hardware. [C289, C292, C295, C303; prior-work 0360, 0362, 0368]

The September 15 numerical replay reports 223 selected methods: 108 LQCP, 75 entropy-control and 40 state-transition methods, with no reported failures, errors or skips. This is a bounded recovered-source replay, not a rerun of all 1,722 RC1 methods or a system-wide error-rate estimate. [C318; prior-work 0385; receipt R008]

The September 18–19 public summaries add a dense workload that completed sizes 1–21 and refused a 22-qubit allocation under its memory reserve, and a sparse 60-qubit GHZ candidate with only two populated amplitudes and 66 recorded tests. Neither statement supports arbitrary dense 60-qubit simulation or a general hardware capacity limit. Complete workload sources and receipts are separate evidence requirements; they were not replayed here. [Prior-work 0392, 0393]

## Studies 001–004 and SAT: summaries retained, full evidence gap explicit

The public record contains the study summaries; the studies must not be described as wholly missing. What is missing from this reviewed public input set is their complete original paper/code/oracle/receipt package.

- **Study 001:** an eight-clause, four-variable satisfiable counterexample to greedy one-bit repair; a decreasing-potential theorem remains conditional. [Prior-work 0400]
- **Study 002:** bounded false-clause branching, O(3ᵏ poly(N)), with a reported 18,590-query population. Unrestricted polynomial-time coverage remains open. [0401]
- **Study 003:** Boolean violations, a diagonal clause Hamiltonian and canonical product-state expected energy are related in a bounded representation study. The record reports 384 formulas, 4,096 assignments and 4,608 expectation checks, followed by a repeated-literal correction. Representation equivalence is not a quantum speedup or complete SAT solver. [0402]
- **Study 004:** a five-track session includes SAT rounding and conditional mathematical exercises. The later generator record keeps 370 SAT witnesses, UNKNOWN on 14 UNSAT inputs and a connected 12-variable counterexample after 379 starts. It does not establish a complete decision procedure or solve the named open problems. [0403, 0404]

The associated contract requires arbitrary encoded 3-SAT, correctness, worst-case bit cost, precision, readout and UNSAT obligations. A conditional logarithmic-branch resource argument does not discharge its unproved bound. The Yang–Mills exercise likewise assumes an operator and does not construct the required theory. [Prior-work 0395, 0399]

## Teaching and governance companions

The September 20 advanced-mathematics manuscript's section 8 covers quantum state spaces, measurement, interference, entanglement, reduced states and a no-cloning argument; exercises 9 and 10 apply these ideas. Exercise 11 explains why a verified SAT witness is not a general polynomial-time decision algorithm. The excerpts preserve the manuscript's attribution as assistant-written teaching of established mathematics. They are neither new QEL discoveries nor substitutes for missing original research studies. Full proof audit and historical bibliography refresh remain outside this consolidation. [See `teaching-navigation.json` and `TEACHING_QUANTUM_EXCERPTS.md`]

The architecture and verified-state papers provide supporting rules for reporting simulations, source custody and claim maturity. They are not quantum experiments or independent validation of the selected results. The remaining broad QEL history, branding, carriers, scripture and ordinary software work is not silently relabeled quantum research.

## Reading the selection

The selection accounts for every row in six fixed input populations: 348 chronology rows, 175 public timeline rows, 504 public prior-work entries, 98 portfolio rows, nine receipt rows and 20 mechanism rows. It selects respectively **71, 38, 51, 10, 5 and 20**. Those 195 retained documentary rows overlap; they are not 195 distinct studies. Roles are 142 core rows, 43 supporting correction/context rows and ten inventory leads. The inventory leads preserve their inherited-date warnings and do not imply completed implementation.

`selection-decisions.json` records the inclusion or exclusion of all 1,154 source rows and binds each decision to exact canonical source-entry bytes. `population-accounting.json` keeps denominators separate. `overlap-map.json` explicitly maps repeated March metadata and same-title correspondences without pretending to deduplicate every event. No source files or frozen publication packages were changed, and nothing was submitted or published by this work.
