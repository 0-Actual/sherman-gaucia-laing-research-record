# Quantum documentary consolidation

Start with `QUANTUM_SOURCE_CHRONOLOGY.md`. The full selected source wording and evidence boundaries are retained in `quantum-selected-records.json` and readable `QUANTUM_RECORDS.md`. `SOURCE_LIMITS_AND_GAPS.md` and `source-gaps.json` distinguish available study summaries from missing full originals. The teaching excerpts and navigation are separate from the research record.

Selection covers six public-safe source populations, with every row accounted for: 71/348 chronology, 38/175 timeline, 51/504 prior-work, 10/98 portfolio, 5/9 receipts and 20/20 mechanisms. These overlapping 195 documentary rows are not a count of unique studies or experiments. There are 142 core rows, 43 supporting correction/context rows and ten unresolved inventory leads.

The lexical scan was only a candidate aid. Explicit reviewed decisions select quantum concepts, state/operator/measurement/algorithm work, successor mechanisms, bounded simulator results and necessary corrections. Non-keyword additions preserve relevant code recovery, suite, tensor-scaling and SAT records. Quantum.Earth.Laing naming, QPRINT branding, unrelated game emulation, scriptural text normalization and generic governance are insufficient for inclusion. The whole mechanism table is retained because its classical families explicitly correct misleading quantum labels.

`selection-decisions.json` records all 1,154 include/exclude decisions and canonical source-entry hashes. Included records receive an editorial role and evidence-stage label; these do not replace source classes or certify correctness. The overlap map identifies the duplicated 27 March metadata slots and same-title correspondences without silently deduplicating events.

To reproduce the exact machine-readable selection from the frozen public-safe series:

```text
python build_selection.py --bundle PUBLIC_SERIES_ROOT --review selection-decisions.json --output OUT
python extract_teaching_navigation.py --bundle PUBLIC_SERIES_ROOT --output OUT
```

The builder verifies each reviewed entry against its recorded hash before selection and records exact input-file identities. It copies no private originals and executes no historical source programs. `scan_candidates.py` and `prepare_review_decisions.py` are editorial preparation helpers, not required for the reviewed rebuild. Source and output inputs are kept separate; do not point the output at a frozen source package.

The public-safe deliverable set consists of this README; the chronology, record and source-gap Markdown documents; `TEACHING_QUANTUM_EXCERPTS.md`; the selected-records, decisions, population, overlap, input-identity, source-gap, teaching-navigation and verification JSON files; the two portable rebuild scripts; and `verify_quantum_selection.py`. The separate public-file list records exact intended filenames and hashes. Working `all-source-rows.json`, the candidate review text and annotation preparation helper need not be included in the consolidated edition.

Independent reconciliation reproduced nine generated files byte for byte, matched all 195 selected original source entries, accounted for all 1,154 source rows, verified four exact teaching passages and checked that gap-summary references resolve. All seven input source files remained unchanged. This is preservation and documentary verification, not scientific test execution.

No source package was rewritten, no quantum or mathematical experiment was run, and no publication was performed. Later recovery of original studies should be added with its own evidence, dates and verification scope rather than rewriting a summary into an invented original manuscript.
