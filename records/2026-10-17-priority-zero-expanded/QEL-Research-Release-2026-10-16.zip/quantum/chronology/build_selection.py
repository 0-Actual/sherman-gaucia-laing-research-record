"""Reproduce a reviewed quantum documentary selection using only stdlib Python.

python build_selection.py --bundle PUBLIC_SERIES_ROOT --review review-decisions.json --output OUT
Reads public-safe inputs only. No source code or historical experiment is executed.
"""
import argparse, collections, hashlib, json, re
from pathlib import Path

SPECS = [
 ('chronology','reproduction/inputs/chronology-projection.json','rows'),
 ('timeline','reproduction/inputs/timeline.json','entries'),
 ('prior_work','reproduction/inputs/prior-work.json','entries'),
 ('portfolio','supplements/historical-portfolio.json','rows'),
 ('receipts','supplements/retained-receipts.json','rows'),
 ('mechanisms','supplements/mathematical-mechanisms.json','rows'),
]

def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def hash_bytes(b): return hashlib.sha256(b).hexdigest()
def encode(obj): return (json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8')
def canonical(obj): return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def date_of(r): return r.get('recorded_date') or r.get('timestamp') or r.get('recorded_date_label')
def summary_of(r): return r.get('display_summary') or r.get('summary') or r.get('description') or ''

def main():
 p=argparse.ArgumentParser(description=__doc__)
 for arg in ('bundle','review','output'): p.add_argument('--'+arg,required=True,type=Path)
 a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=True)
 review=load(a.review); decisions={r['key']:r for r in review['decisions']}
 assert len(decisions)==len(review['decisions'])
 selected=[]; all_decisions=[]; counts={}; identities=[]
 for pop,name,field in SPECS:
  path=a.bundle/name; before=path.read_bytes(); records=load(path)[field]
  counts[pop]={'available_rows':len(records),'selected_rows':0,'excluded_rows':0,'roles':{}}
  identities.append({'path':name,'bytes':len(before),'sha256':hash_bytes(before)})
  for r in records:
   key=pop+':'+r['id']; d=decisions[key]
   assert hash_bytes(canonical(r))==d['source_entry_sha256'], ('reviewed row changed',key)
   assert d['title_as_reviewed']==r.get('title','')
   all_decisions.append(d)
   if d['decision']=='exclude': counts[pop]['excluded_rows']+=1; continue
   counts[pop]['selected_rows']+=1
   counts[pop]['roles'][d['role']]=counts[pop]['roles'].get(d['role'],0)+1
   selected.append({'key':key,'source_population':pop,'original_id':r['id'],'recorded_date_label':date_of(r),'title':r.get('title',''),'display_summary':summary_of(r),'source_limitation':r.get('limitation',''),'selection_role':d['role'],'editorial_evidence_stage':d['evidence_stage'],'selection_reason':d['reason'],'source_entry':r})
  assert path.read_bytes()==before
 assert set(decisions)=={d['key'] for d in all_decisions}
 notice='Counts refer to overlapping documentary rows in separate source populations, not independent studies, inventions, papers, experiments, measurements or implementations. Original wording, timestamp precision and source limitations remain in source_entry. Selection roles and evidence-stage labels are editorial. No historical experiment, code execution, hardware measurement or source authentication was performed in this consolidation.'
 bykey={r['key']:r for r in selected}
 overlaps=[]
 for n in range(1,28):
  keys=[f'chronology:QEL-SER-C{321+n:03d}',f'timeline:CODE-DATE-{n:02d}']
  assert all(k in bykey for k in keys)
  assert bykey[keys[0]]['recorded_date_label']==bykey[keys[1]]['recorded_date_label']
  overlaps.append({'kind':'explicit_same_historical_metadata_slot','keys':keys,'basis':'Same source-order March code-body slot and exact recorded timestamp; two catalogues describe the same metadata, not two experiments.'})
 titles=collections.defaultdict(list)
 for r in selected:
  title=' '.join(r['title'].casefold().split())
  if title: titles[title].append(r)
 for title,rs in titles.items():
  if len({r['source_population'] for r in rs})>1:
   overlaps.append({'kind':'normalized_title_correspondence','keys':[r['key'] for r in rs],'basis':'Same normalized title across source populations; dates and scopes retained, not automatic event identity or deduplication.'})
 data={'schema':'qel-quantum-documentary-selection/1','notice':notice,'input_files':identities,'review_decisions_canonical_sha256':hash_bytes(canonical(review)),'review_hash_basis':'Parsed JSON serialized as UTF-8, sorted keys and compact separators; input line-ending differences do not change the reviewed decisions.','population_counts':counts,'selected_row_count':len(selected),'rows':selected}
 accounting={'schema':'qel-quantum-population-accounting/1','notice':notice,'populations':counts,'all_source_rows_accounted':len(all_decisions),'selected_documentary_rows':len(selected),'role_counts':dict(collections.Counter(r['selection_role'] for r in selected)),'evidence_stage_counts':dict(collections.Counter(r['editorial_evidence_stage'] for r in selected))}
 outputs={'quantum-selected-records.json':data,'population-accounting.json':accounting,'overlap-map.json':{'schema':'qel-quantum-overlaps/1','automatic_deduplication':False,'groups':overlaps},'selection-decisions.json':review,'INPUT_IDENTITIES.json':{'schema':'qel-quantum-input-identities/1','inputs':identities}}
 lines=['# Quantum-related documentary records','',notice,'','Every source row was screened. The explicit review file controls selection; lexical hits alone do not include a record. Named inventory leads remain separate from source descriptions, historical runs and teaching.','']
 for pop,_,_ in SPECS:
  rs=[r for r in selected if r['source_population']==pop]
  lines += ['## '+pop+' — '+str(len(rs))+' selected rows','']
  for r in rs:
   lines += ['### '+r['original_id']+' — '+(r['title'] or '[source title empty]'),'','Recorded date: '+str(r['recorded_date_label'])+'. Role: '+r['selection_role']+'. Editorial stage: '+r['editorial_evidence_stage']+'.','',r['display_summary'],'']
   if r['source_limitation']: lines += ['Source limitation: '+r['source_limitation'],'']
   lines += ['Selection basis: '+r['selection_reason'],'']
 artifacts={n:encode(v) for n,v in outputs.items()}
 artifacts['QUANTUM_RECORDS.md']=('\n'.join(lines)+'\n').encode('utf-8')
 for name,b in artifacts.items():
  text=b.decode('utf-8')
  assert not re.search(r'\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b',text,re.I), name
  assert not re.search(r'(?<![A-Za-z])[A-Za-z]:[\\/]|/(?:Users|home|mnt)/',text), name
  (a.output/name).write_bytes(b); assert (a.output/name).read_bytes()==b
 receipt={'status':'PASS_FOR_REVIEWED_SELECTION_AND_SAVE_READBACK','all_source_rows_accounted':len(all_decisions),'selected_rows':len(selected),'all_inputs_unchanged':True,'no_source_code_or_experiments_executed':True,'generated_sha256':{n:hash_bytes(b) for n,b in artifacts.items()},'limits':notice}
 (a.output/'selection-verification.json').write_bytes(encode(receipt))
 print(json.dumps({'source_rows':len(all_decisions),'selected_rows':len(selected),'counts':counts,'status':receipt['status']},indent=2))

if __name__=='__main__': main()
