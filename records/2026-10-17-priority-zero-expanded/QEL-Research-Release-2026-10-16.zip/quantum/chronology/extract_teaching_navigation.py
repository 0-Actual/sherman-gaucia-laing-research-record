"""Preserve exact selected passages from the already prepared public teaching copy."""
import argparse, hashlib, json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--bundle',required=True,type=Path)
p.add_argument('--output',required=True,type=Path)
a=p.parse_args(); a.output.mkdir(parents=True,exist_ok=True)
relative='research/papers/teaching-advanced-mathematics-frontiers.md'
source=a.bundle/relative; original=source.read_bytes(); text=original.decode('utf-8'); lines=text.splitlines()
headers=[(i+1,l) for i,l in enumerate(lines) if l.startswith('#')]
sections=[
 ('quantum-information','## 8. The mathematics of quantum information','## 9. Reaching a frontier without inventing a result','core teaching','Pure states, Born probabilities, unitaries/interference, tensor products, entanglement, density/reduced states and no-cloning.'),
 ('phase-exercise','### Exercise 9 — a phase-sensitive measurement','### Exercise 10 — product or entangled?','core teaching','Worked phase/interference exercise.'),
 ('entanglement-exercise','### Exercise 10 — product or entangled?','### Exercise 11 — a certificate is not a universal algorithm','core teaching','Worked product-state/rank and measurement-distribution exercise.'),
 ('complexity-boundary','### Exercise 11 — a certificate is not a universal algorithm','### Exercise 12 — an integral norm is not a pointwise bound','supporting teaching','A checked SAT witness is not a universal polynomial-time algorithm.'),
]
navigation=[]; excerpts=['# Quantum teaching passages from the existing manuscript','','These are exact excerpts of the already prepared teaching derivative. The historical manuscript is dated September 20, 2026; its public-review wrapper is dated October 15, 2026. The exposition is assistant-authored reconstruction of established mathematics for the owner, not a claim of novel theorems or independent learner mastery. No full proof audit or external bibliography refresh is performed here. Source: '+relative+'.','']
for ident,start,end,role,topic in sections:
 aidx=text.index(start); bidx=text.index(end,aidx+len(start)); excerpt=text[aidx:bidx].rstrip()
 startline=text[:aidx].count('\n')+1; endline=text[:bidx].count('\n')
 navigation.append({'id':ident,'source_path':relative,'heading':start,'source_line_start':startline,'source_line_end':endline,'role':role,'topic':topic,'excerpt_sha256':hashlib.sha256(excerpt.encode('utf-8')).hexdigest(),'historical_manuscript_date':'2026-09-20','derivative_date':'2026-10-15','evidence_stage':'established-mathematics teaching, not project experiment'})
 excerpts += ['---','',excerpt,'']
support=[
 {'source_path':relative,'section':'1 Information begins with distinguishable possibilities','role':'supporting prerequisite','boundary':'Classical information and counting; not quantum memory compression.'},
 {'source_path':relative,'section':'2 Recovering information after errors','role':'supporting prerequisite','boundary':'Classical coding material; not a quantum error-correction experiment.'},
 {'source_path':relative,'section':'4.4 Feasible computation and P versus NP','role':'supporting prerequisite','boundary':'Computability/complexity instruction; not a solution to an open problem.'},
 {'source_path':relative,'section':'6 Hilbert spaces and Fourier analysis','role':'supporting prerequisite','boundary':'Mathematical background, not device validation.'},
 {'source_path':relative,'section':'9 Reaching a frontier without inventing a result','role':'dated historical teaching context','boundary':'Open-problem labels are retained as the September 20 manuscript reports them; not newly verified current status. Conditional Yang–Mills material is not theory construction.'},
 {'source_path':'research/papers/WP-001-governed-local-first-human-ai-systems.md','section':'3.5 Computation, emulator, and model lanes','role':'supporting governance','boundary':'Classical emulator/simulated circuit must not be called physical-QPU execution. This paper is not a quantum result.'},
 {'source_path':'research/papers/verified-state.md','section':'Verified-State Ladder / Evidence Gates by State','role':'supporting governance','boundary':'Claim-state discipline is a method proposal, not independent validation of selected quantum work.'},
]
doc={'schema':'qel-quantum-teaching-navigation/1','source_sha256':hashlib.sha256(original).hexdigest(),'source_path':relative,'selected_passages':navigation,'supporting_navigation':support,'complex_analysis_manuscript_disposition':'Not quantum-specific; may serve as broader mathematics background but is not included as a quantum study.','limit':'No full proof audit, historical bibliography refresh, physical quantum claim or novel-result attribution.'}
(a.output/'teaching-navigation.json').write_text(json.dumps(doc,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(a.output/'TEACHING_QUANTUM_EXCERPTS.md').write_bytes(('\n'.join(excerpts)+'\n').encode('utf-8'))
assert source.read_bytes()==original
print(json.dumps({'passages':len(navigation),'source_unchanged':True,'source_sha256':doc['source_sha256']},indent=2))
