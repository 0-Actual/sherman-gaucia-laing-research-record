# Proposed GitHub quantum chronology links

Read-only comparison against saved commit `f56f010386cb5d08c2c1f0168f7627fe81186463` of `0-Actual/sherman-gaucia-laing-research-record`. This is a proposal for owner review, not a repository mutation. The exact saved repo paths and Git blob identities are retained in the JSON companion.

- Main human-readable timeline: `TIMELINE.md`
- Machine-readable timeline: `timeline.json`
- Existing detailed appendix: `records/2026-10-01-prior-work/prior-work.json`

The 175-entry timeline ends September 17, 2026. The 504-row appendix already supplies several later studies and finer corrections. Do not label every missing main-timeline link as absent from the repository.

## QEL-CHAIN-01 — From an explicit emulator request to differentiated successor mechanisms

Enrich existing PR-M01 and CODE-DATE-01–27 entries with links to correction, successor and recovery records. Do not create duplicate March origins or assign August code to March dates.

Source coverage: The complete original conversation export is unavailable in this review. Historical B/C/D exact-source closure remains open; corrected successors are not original byte recovery.

## QEL-CHAIN-02 — Coherence terminology to robust normalized-state computation

Link CODE-DATE-18 and the existing targeted-numerical-corrections entry to the C002 result with its September 4–5 timing ambiguity; avoid silently turning the package date into an exact execution timestamp.

Source coverage: The corrected reference is a forensic successor; exact unavailable historical document-object bytes and precision-run start/end remain unresolved.

## QEL-CHAIN-03 — Entropy-control definitions to the tiny-positive fixed-point repair

Add a specific fixed-point correction link beneath the generic September 4 numerical-corrections milestone. The detailed result already exists in prior-work QEL-PW-0366, so this is cross-linking public evidence rather than claiming a newly discovered event.

Source coverage: The full 662-line historical module was not executed by that standalone reference test; excerpts and contracts do not close original-module coverage.

## QEL-CHAIN-04 — Three named roles to tensor semantics and normalization repair

Enrich the existing normalization-candidate entry with the August semantic distinction and the unchanged one-byte custody gate, using QEL-PW-0330 and QEL-PW-0365 as already public bridges.

Source coverage: The exact original byte object remains unverified; source-text reconstruction and numerical regression are separate evidence.

## QEL-CHAIN-05 — Unknown circuit operations to validated execution boundaries

Link the existing targeted-corrections milestone to its candidate-test receipt rather than treating 16 methods, 13 circuits and 383 checks as three independent studies.

Source coverage: The full original interaction and whole-application proof are not supplied by the focused candidate receipt; no signed promotion is established.

## QEL-CHAIN-06 — A declared exact workload to the Task Alpha GHZ reference

Candidate new August 25 entry: Task Alpha is absent from the pinned 175-entry timeline and the inspected 504-entry prior-work catalogue by reviewed title/summary search. Link the declared creation time and saved receipts to the new work/source index; do not use consolidation time as execution time.

Source coverage: No original conversational request is included in this chain. The sequence-52 source was a delta, not a complete recovered integrated tree.

## QEL-CHAIN-07 — State-space growth to a measured workload-specific dense limit

Candidate dated links after the pinned timeline’s September 17 endpoint: QEL-PW-0392 and QEL-PW-0393 already disclose separate dense and sparse claims in the prior-work appendix. Add the dense preserved source collection and retain the sparse summary boundary.

Source coverage: The full sparse 60-qubit assessment package is not supplied by these reviewed chronology inputs. Structured input families do not establish arbitrary-state capacity.

## QEL-CHAIN-08 — SAT correctness obligations to counterexamples, bounded repair and exact rounding

Add links to already public QEL-PW-0399–0404 after the pinned timeline endpoint. Keep the exact recorded UTC sequence and distinguish the mixed five-problem Study004 session from its later rounding correction.

Source coverage: The complete original Study001–004/SAT packages and original conversations were not acquired by this documentary selection; do not invent transcripts, source filenames or fresh verification.

## QEL-CHAIN-09 — Aluminum energy targets to variational predictions and unfavorable controls

Candidate September 28 assessment and September 29 UTC verification links are absent from the pinned 175-entry timeline; add from the preserved work/source index. Do not confuse this one-material variational study with the already public JARVIS-DFT 2D dataset evidence.

Source coverage: The complete original conversation is unavailable. Independent source/receipt inspection supports this summary; the consolidation did not rerun the optimizer or establish broad material generalization.

## QEL-CHAIN-10 — Retained optimizer cost to bounded software-performance improvement

Candidate performance follow-on links should preserve the September 28/29 local-versus-UTC reporting distinction, the slower attempts, the missed target and the separate cache pathway.

Source coverage: The complete original interaction is unavailable; two observations per version per batch cannot establish a universal speedup, Windows-wide improvement or a complete adversarial cache audit.

Private-source omissions and intentional public redactions are distinct. This proposal uses scientific scope, relative code identities, public source URLs and hashes; it excludes private locators and controller configuration. No external write or experiment occurred.
