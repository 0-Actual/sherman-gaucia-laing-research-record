# Source limits and remaining evidence gaps

This selection reads the existing public-safe series inputs and appendices only. It does not claim to contain every original quantum-related message, script, paper or raw receipt. A gap here means that evidence is absent from this reviewed public input set; it does not prove that the owner never created it or that it is unavailable elsewhere.

| Subject | What is retained here | What is not supplied or newly verified here |
| --- | --- | --- |
| Studies 001–004 | Public prior-work 0400–0404, including the failed generator and repeated-literal correction | Complete manuscripts, exact programs, all formula/oracle/expectation data and full dated execution receipts |
| SAT contract | Prior-work 0399 and bounded Study 001–004 summaries | A complete general SAT decision proof, unrestricted polynomial-time bound or missing theorem assumptions |
| Dense/sparse scaling | Prior-work 0392/0393 with workload limits and sparse two-amplitude description | Complete exact workload artifacts, environment/allocation receipts or a new benchmark |
| March 2025 sources | 27 metadata slots, summary descriptions and retained syntax findings | The withheld original implementation bodies or original execution for every source |
| Historical integrated generations | Kernel/migration and suite summaries | Exact closure for every historical generation; source reports explicitly retain gaps |
| Three-qubit normalization | Reported 22 regressions and 504 inherited numerical values | Resolution of the one-byte source reconstruction discrepancy or a signed canonical replacement |
| Successor mechanism table | 20 static mechanism/limit rows | Independent revalidation of every formula, full code execution or proof that each mechanism existed in March originals |
| Quantum-dot and early applied concepts | Dated concepts and explicit absence-of-evidence findings | Measured materials, physical specimens, engineering validation or demonstrated novelty |
| Teaching | Exact selected section/exercises and dated attribution | Complete independent proof audit or refreshed external-reference/open-problem status |
| Physical quantum claim | No physical-QPU result established by these selected documentary records | Physical hardware execution, general quantum advantage or experimental certification |

The public record itself is available evidence and must not be replaced by an invented reconstruction of the missing original studies. Preserve negative and uncertain outcomes: original syntax failures; unsupported mechanisms; hardcoded fidelity; incomplete generation custody; the parent precision failures; the target/achieved entropy difference; the 22-qubit allocation refusal; the SAT UNKNOWN cases and counterexample. Successful later subsets do not erase them.

Time scope remains source-specific. Fractional timestamps retain their offsets. Day-only values are not invented execution instants. English receipt date ranges and inventory anchors remain unnormalized strings with their original warnings. September review dates are not inception dates. Published summaries, later source reviews, source metadata and historical execution reports remain separate evidence levels.

No new experiments, software tests, USB operations, source modifications or publication occurred during this documentary consolidation. File comparison verifies preservation, not correctness, scientific priority, ownership, independent trusted time or certification.
