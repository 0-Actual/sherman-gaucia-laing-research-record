# Quantum teaching passages from the existing manuscript

These are exact excerpts of the already prepared teaching derivative. The historical manuscript is dated September 20, 2026; its public-review wrapper is dated October 15, 2026. The exposition is assistant-authored reconstruction of established mathematics for the owner, not a claim of novel theorems or independent learner mastery. No full proof audit or external bibliography refresh is performed here. Source: research/papers/teaching-advanced-mathematics-frontiers.md.

---

## 8. The mathematics of quantum information

### 8.1 State spaces and measurement rules

For a finite isolated quantum system, a pure state is represented by a unit vector in a complex Hilbert space, with vectors differing only by a global complex phase representing the same physical pure state. A qubit uses $\mathbb C^2$:

$$|\psi\rangle=\alpha|0\rangle+\beta|1\rangle,
\qquad |\alpha|^2+|\beta|^2=1.$$

The notation is linear algebra: $|0\rangle=(1,0)^T$ and $|1\rangle=(0,1)^T$. The Born rule assigns computational-basis measurement probabilities $|\alpha|^2$ and $|\beta|^2$. More generally, a projective measurement with orthogonal projections $P_j$ summing to the identity gives probability $\langle\psi,P_j\psi\rangle$. For an observed outcome of positive probability, the corresponding normalized post-measurement state is $P_j\psi/\sqrt{\langle\psi,P_j\psi\rangle}$.

These are modeling postulates connecting mathematics to physical predictions; they are not derivable merely by changing the notation for binary digits. A contemporary primary instructional source is [Watrous, IBM Quantum Learning: single systems](https://quantum.cloud.ibm.com/learning/en/courses/basics-of-quantum-information/single-systems/introduction). The calculations below study the model without claiming that a general-purpose laptop becomes quantum hardware.

**Worked example 18 — amplitudes and probabilities.** Let $|\psi\rangle=(\sqrt3/2)|0\rangle+(i/2)|1\rangle$. Its squared norm is $3/4+1/4=1$. Measurement yields $0$ with probability $3/4$ and $1$ with probability $1/4$. The expected value of the observable $Z=\operatorname{diag}(1,-1)$ is $3/4-1/4=1/2$. The imaginary phase in the second amplitude does not affect these particular probabilities, but it can affect probabilities after an operation that mixes the basis states.

### 8.2 Unitaries and interference

A matrix $U$ is unitary if $U^\dagger U=I$, where the dagger means conjugate transpose. Then $\|U\psi\|^2=\psi^\dagger U^\dagger U\psi=\|\psi\|^2$. Unitary transformations preserve inner products as well as lengths. Their inverse is $U^\dagger$.

Consider the Hadamard matrix

$$H=\frac1{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix}.$$

It is real symmetric and $H^2=I$, so it is unitary. Define $|+\rangle=(|0\rangle+|1\rangle)/\sqrt2$ and $|-\rangle=(|0\rangle-|1\rangle)/\sqrt2$.

**Worked example 19 — equal initial probabilities, different outcomes.** Both $|+\rangle$ and $|-\rangle$ have probabilities $1/2,1/2$ in the computational basis. Yet $H|+\rangle=|0\rangle$ while $H|-\rangle=|1\rangle$. Adding amplitudes before squaring permits constructive and destructive interference. By contrast, multiplying every amplitude by one common factor $e^{i\theta}$ changes no projective-measurement probability, since the phase cancels in the inner product.

### 8.3 Tensor products and entanglement

Two systems with spaces $\mathbb C^m$ and $\mathbb C^n$ have joint space $\mathbb C^m\otimes\mathbb C^n$, of dimension $mn$. For two qubits, a basis is $|00\rangle,|01\rangle,|10\rangle,|11\rangle$. A product state expands as

$$(a|0\rangle+b|1\rangle)\otimes(c|0\rangle+d|1\rangle)
=ac|00\rangle+ad|01\rangle+bc|10\rangle+bd|11\rangle.$$

A pure state that cannot be written as such a product is entangled. This is a precise algebraic property, not a synonym for complicated correlation.

**Worked example 20 — proving a Bell state is entangled.** Suppose $(|00\rangle+|11\rangle)/\sqrt2$ were a product. Comparing coefficients would give $ac=1/\sqrt2$, $ad=0$, $bc=0$, $bd=1/\sqrt2$. The first and last equations imply all four numbers $a,b,c,d$ are nonzero, contradicting the middle equations. Thus the state is not a product. Equivalently its coefficient matrix has rank two, whereas a product state's coefficient matrix is an outer product of rank one.

Measuring both qubits in this basis gives $00$ or $11$, each with probability $1/2$. Each individual result is uniformly random. Correlation does not allow an observer to choose the other observer's random outcome.

For mixed states, use a density matrix $\rho$, a positive semidefinite operator with trace one. An ensemble of pure states with probabilities $p_i$ gives $\rho=\sum_i p_i|\psi_i\rangle\langle\psi_i|$. Measurement probability is $\operatorname{tr}(P_j\rho)$. The Bell state's reduced density matrix for either qubit is $I/2$, found by taking the partial trace over the other basis. The joint state is pure even though each reduced state is mixed.

### 8.4 A limit proved from linearity

Assume a unitary operation could clone every unknown pure state with a fixed blank state $|b\rangle$:

$$U(|\psi\rangle|b\rangle)=|\psi\rangle|\psi\rangle.$$

Apply this to states $\psi,\phi$. Preservation of inner products would require $\langle\psi|\phi\rangle=(\langle\psi|\phi\rangle)^2$. This equation forces their overlap to be zero or one. Choosing, for example, $|0\rangle$ and $|+\rangle$, whose overlap is $1/\sqrt2$, gives a contradiction. Even if the output representatives are allowed state-dependent global phases, taking absolute values gives $r=r^2$ for $r=|\langle\psi|\phi\rangle|$, and the same counterexample applies. Therefore no such universal unitary cloner exists. Orthogonal states can be copied by an appropriate operation, so the word “unknown” and the unrestricted choice of state are essential to the theorem.

An $n$-qubit vector has $2^n$ complex amplitudes, but one measurement does not print all those amplitudes. State preparation, repeated measurement, noise and the desired output all matter. The mathematical existence of a large vector space is not a theorem that arbitrary classical data can be recovered from a tiny physical memory with no further resources.

---

### Exercise 9 — a phase-sensitive measurement

**Problem.** Apply the Hadamard matrix to $(|0\rangle+i|1\rangle)/\sqrt2$. Compute both measurement probabilities. Compare with input $|+\rangle$.

**Solution.** Matrix multiplication gives

$$H\frac{|0\rangle+i|1\rangle}{\sqrt2}
=\frac{1+i}{2}|0\rangle+\frac{1-i}{2}|1\rangle.$$

Each amplitude has squared magnitude $(1^2+1^2)/4=1/2$. Thus both outcomes remain equally likely. For $|+\rangle$, the amplitudes after $H$ are $(1+1)/2=1$ and $(1-1)/2=0$, giving outcome zero with certainty. Equal probabilities before an operation do not imply equal states; their relative phases can change subsequent predictions.

---

### Exercise 10 — product or entangled?

**Problem.** Decide whether

$$|\psi\rangle=\tfrac12(|00\rangle+|01\rangle+|10\rangle-|11\rangle)$$

is a product state. Verify normalization and compute its computational-basis probabilities.

**Solution.** Four coefficients have magnitude $1/2$, so their squared magnitudes sum to one. The coefficient matrix is $\tfrac12\begin{pmatrix}1&1\\1&-1\end{pmatrix}$, with determinant $-1/2\ne0$. It has rank two, whereas a product-state coefficient matrix has rank one. Hence this pure state is entangled. Every computational-basis outcome has probability $1/4$. These probabilities alone match those of the product state $|+\rangle\otimes|+\rangle$, but the minus sign creates a different quantum state. A single chosen measurement distribution cannot fully specify the state.

---

### Exercise 11 — a certificate is not a universal algorithm

**Problem.** A program solves one Boolean formula with one thousand variables and supplies a satisfying assignment. What mathematical claim has been established after the assignment is checked? What additional work would be needed to establish P=NP?

**Solution.** Verification establishes that this particular formula is satisfiable. The number of variables does not turn a single instance into a theorem about all instances. To establish P=NP by satisfiability, one would need an algorithm deciding satisfiability for every permitted input formula, a proof of correctness on both satisfiable and unsatisfiable inputs, and a polynomial worst-case running-time bound in the formula's encoded length. The known NP-completeness reduction would then transfer the bound to all NP decision problems. A fast run on one instance supplies none of those universal quantifiers by itself.

