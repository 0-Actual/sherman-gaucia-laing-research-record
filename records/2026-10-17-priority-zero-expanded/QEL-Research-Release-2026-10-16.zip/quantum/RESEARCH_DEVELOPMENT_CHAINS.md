# Research development chains

Prepared for owner review. GAUCIA Actual is the primary project agent; Codex supports the source review. These ten editorial chains join documented problem, correction, code and result stages. They reuse overlapping evidence and are not a count of ten new studies. No original interaction transcript has been reconstructed and no experiment was run.

The comparison uses the saved [`0-Actual/sherman-gaucia-laing-research-record` timeline](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/TIMELINE.md) at commit `f56f010386cb5d08c2c1f0168f7627fe81186463`, with 175 timeline entries and a [504-entry prior-work catalogue](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/records/2026-10-01-prior-work/prior-work.json). It does not assert the current remote HEAD. The pinned timeline reaches September 17, 2026; later prior-work summaries are not therefore absent from the whole repository.

## QEL-CHAIN-01 — From an explicit emulator request to differentiated successor mechanisms

**Problem.** March 10, 2025: the owner requests construction and mathematical evidence, distinguishing source display from execution.

**Discussion and correction.** March 11 precursors and March 13 Algorithms 1–21 are recoverable source descriptions. Algorithm 1 uses a complex state; local evolution is not by itself entanglement, and the radial rescaling shared by many later labels changes norm rather than normalized physical state. August 18–19 records distinguish those failures from corrected mechanisms.

**Solution and code.** The August successor common kernel uses normalized states, declared operators, densities, partial traces and channels. Separate domain implementations and migration routes replace undifferentiated labels.

**Algorithm and result.** August 21 RC1 reports 1,665 domain plus 57 integration methods, six workflows and 21 benchmark paths. August 22 kernel/migration work routes historical records; September 15 recovery reports 27 distinct historical source bodies, with 25 syntax passes and two failures. These are different populations and dates.

Source rows: `timeline:PR-M01` (2025-03-10T05:50:01.264392-04:00); `chronology:QEL-SER-C166` (2025-03-10T05:50:01.264392-04:00); `chronology:QEL-SER-C168` (2025-03-11T13:26:09.003380-04:00); `chronology:QEL-SER-C169` (2025-03-13T10:48:15.685403-04:00); `chronology:QEL-SER-C170` (2025-03-13T11:06:34.234184-04:00); `chronology:QEL-SER-C171` (2025-03-13T12:46:24.934789-04:00); `prior_work:QEL-PW-0321` (2026-08-18); `prior_work:QEL-PW-0322` (2026-08-19); `prior_work:QEL-PW-0326` (2026-08-21); `chronology:QEL-SER-C273` (2026-08-22); `prior_work:QEL-PW-0384` (2026-09-15).

Preserved collections: `august21-successor-integration`.

Code identity examples: `code/qel_bcd_migration_adapter_v1.py` — SHA-256 `1400f387c5cae06821668332bd8bd546b581afdafa25211d1971b04cbeade95a`; `vendor/rc1/vendor/qel_quantum_common_kernel_v1.py` — SHA-256 `9a772c84520a71f9e24c1c7c5038969786911fcae70d94d87769d34d8fb5a194`; `vendor/rc1/vendor/qel_quantum_state_transition_v1.py` — SHA-256 `129d146427408aa4792b071854defaa782d984d8196a8c209da6bb3920605d32`.

**Proposed timeline link.** Enrich existing PR-M01 and CODE-DATE-01–27 entries with links to correction, successor and recovery records. Do not create duplicate March origins or assign August code to March dates.

**Remaining evidence boundary.** The complete original conversation export is unavailable in this review. Historical B/C/D exact-source closure remains open; corrected successors are not original byte recovery.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-02 — Coherence terminology to robust normalized-state computation

**Problem.** The March 13, 2025 coherence-labelled family contains global amplitude rescaling, which does not establish coherence preservation.

**Discussion and correction.** Recovered reviews separate basis-dependent coherence, normalization, fidelity and projective distance. The C002 parent has overflow/underflow and near-parallel-state distance failures.

**Solution and code.** The v2.2 successor scales real/imaginary components before normalization and uses a projection residual for a phase-invariant distance. It retains the original v2.1 body separately.

**Algorithm and result.** September 4–5, 2026 is the retained reporting interval: 108 inherited, 12 earlier boundary and 22 precision methods pass the candidate; the parent fails 13 of the 22 new cases. Structured 1e-300 fixtures are not a universal accuracy guarantee.

Source rows: `timeline:CODE-DATE-18` (2025-03-13T13:06:56.253697-04:00); `chronology:QEL-SER-C171` (2025-03-13T12:46:24.934789-04:00); `chronology:QEL-SER-C278` (2026-08-26); `chronology:QEL-SER-C288` (2026-09-04); `prior_work:QEL-PW-0350` (2026-09-04); `receipts:QEL-SER-R003` (September 4–5, 2026).

Preserved collections: `full-recovered-math`.

Code identity examples: `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/original/qel_lqcp_reference_v2_1.py` — SHA-256 `d1c8769302c93fd36de92a4ef0f6485ce4e81ee1bdb7623bcdf5335d844cf1dd`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/run_precision_audit.py` — SHA-256 `8874f96f64f5c3323cc741ca544bf090fc19738265219d42d27364f020350880`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/source/qel_lqcp_reference_v2_2.py` — SHA-256 `77499b6a81aa68f77149015b1a8b31f343dcebd184272f8eabf1396dcb31c8e3`.

**Proposed timeline link.** Link CODE-DATE-18 and the existing targeted-numerical-corrections entry to the C002 result with its September 4–5 timing ambiguity; avoid silently turning the package date into an exact execution timestamp.

**Remaining evidence boundary.** The corrected reference is a forensic successor; exact unavailable historical document-object bytes and precision-run start/end remain unresolved.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-03 — Entropy-control definitions to the tiny-positive fixed-point repair

**Problem.** The historical entropy label does not specify a physical entropy-control mechanism. August 20 separates von Neumann, measurement and subsystem entropy and retains the achieved-versus-target discrepancy.

**Discussion and correction.** For depolarization followed by target replacement, uniqueness fails only when both channel parameters are zero; a numerical small-parameter cutoff incorrectly classified weak positive channels.

**Solution and code.** A standalone fixed-point reference computes scaled coefficients before division, preserving representable tiny-positive parameter ratios.

**Algorithm and result.** The September 5 UTC receipt reports 13 methods, a 760-digit reference over ten parameter pairs, 72 invariance subcases and 100 seeded density subcases. Equal smallest positive binary64 parameters yield diagonal entries 0.75 and 0.25 for the specified pure-zero target. Uniqueness does not prove fast convergence or measured thermodynamic efficiency.

Source rows: `timeline:CODE-DATE-17` (2025-03-13T13:05:51.660937-04:00); `prior_work:QEL-PW-0325` (2026-08-20); `mechanisms:QEL-SER-M005` (None); `chronology:QEL-SER-C301` (2026-09-05); `prior_work:QEL-PW-0366` (2026-09-05); `receipts:QEL-SER-R005` (September 4 Eastern / September 5 UTC, 2026).

Preserved collections: `full-recovered-math`, `august21-successor-integration`.

Code identity examples: `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/fixed_point_reference.py` — SHA-256 `9023f7346018aa481baa63d8d808ae5812ae3ae3ae61d778260b63f80d692457`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/run_entropy_audit.py` — SHA-256 `8720f6834382d8e7af5c490958c617609181ea3ebc97725bd78f9e4e594d60f2`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/entropy/test_fixed_point_reference.py` — SHA-256 `224cc556ff097842b339460921a27e6cb461cbbd4b55d97f78d5e30f6ede34ce`.

**Proposed timeline link.** Add a specific fixed-point correction link beneath the generic September 4 numerical-corrections milestone. The detailed result already exists in prior-work QEL-PW-0366, so this is cross-linking public evidence rather than claiming a newly discovered event.

**Remaining evidence boundary.** The full 662-line historical module was not executed by that standalone reference test; excerpts and contracts do not close original-module coverage.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-04 — Three named roles to tensor semantics and normalization repair

**Problem.** August 22–23 describes three semantic roles and asks how larger matrix spaces should represent them.

**Discussion and correction.** The eight-dimensional role factor remains three semantic qubits while the auxiliary factor grows; 512 = 8 × 64 does not create 512 semantic qubits. Smaller views are lossy.

**Solution and code.** The corrected normalization avoids infinity-to-zero collapse for extreme finite components, while role order, reduced-state interpretation and fallback remain explicit.

**Algorithm and result.** The September 4 Eastern / September 5 UTC receipt reports 22 regression methods and 504 inherited numerical values within 1e-12. The largest reported difference is approximately 2.537e-14. The retained text reconstruction is 16,248 bytes against 16,249-byte historical metadata; that one-byte gap is not repaired by numerical agreement.

Source rows: `prior_work:QEL-PW-0330` (2026-08-22); `chronology:QEL-SER-C275` (2026-08-23); `chronology:QEL-SER-C300` (2026-09-05); `prior_work:QEL-PW-0365` (2026-09-05); `receipts:QEL-SER-R004` (September 4 Eastern / September 5 UTC, 2026).

Preserved collections: `full-recovered-math`.

Code identity examples: `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/fixed_three_qubit_scale.py` — SHA-256 `e7d4bd4416d3540d501ff58938a853327a6c2b798afc0ef68bb2e14999682c22`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/fixed_three_qubit_scale_source_text_reconstruction.py` — SHA-256 `e7b1b2e34c8edbaaab4c6a59cb60ae2680cc6b12bfb2eb08f19db94dcd456584`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/three_qubit/test_three_qubit_normalization.py` — SHA-256 `679077d52f21f6dfd8587e74d2afb17fbdf580d7d018c781ec01d621bc8b32e8`.

**Proposed timeline link.** Enrich the existing normalization-candidate entry with the August semantic distinction and the unchanged one-byte custody gate, using QEL-PW-0330 and QEL-PW-0365 as already public bridges.

**Remaining evidence boundary.** The exact original byte object remains unverified; source-text reconstruction and numerical regression are separate evidence.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-05 — Unknown circuit operations to validated execution boundaries

**Problem.** The retained September 4 report describes a path that skipped an unknown operation while reporting PASS.

**Discussion and correction.** The correction requires validation of the actual supplied circuit before execution, with invalid operation and input boundaries retained.

**Solution and code.** The original and candidate WF020 modules and focused boundary-test source remain distinct.

**Algorithm and result.** September 5 physical-laptop receipt reports 16 focused methods, 13 frozen circuits and 383 checks in their separate populations. Zero external API invocations are reported for that test source. Production remained unchanged and peak working set was unavailable.

Source rows: `chronology:QEL-SER-C287` (2026-09-04); `prior_work:QEL-PW-0349` (2026-09-04); `chronology:QEL-SER-C303` (2026-09-05); `prior_work:QEL-PW-0368` (2026-09-05).

Preserved collections: `full-recovered-math`.

Code identity examples: `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/test_wf020_api_boundary.mjs` — SHA-256 `cd12f2bca44621115cc9cad17d1d4b5ac19e80721b10222d71f0339063aed658`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/test_wf020_api_boundary.mjs.b64` — SHA-256 `c913c20445aa5a889489a9a2d4708771fc14263cefb2789ee13b68f9f62083e5`; `members/QEL_INTERNAL_MATH_AUDIT_20260904_C002/laptop_review/wf020_core_candidate.mjs` — SHA-256 `26f721cbe0c56213d7f0a119c0cf371de1aa18fdf98b9cdae9686b8543e96145`.

**Proposed timeline link.** Link the existing targeted-corrections milestone to its candidate-test receipt rather than treating 16 methods, 13 circuits and 383 checks as three independent studies.

**Remaining evidence boundary.** The full original interaction and whole-application proof are not supplied by the focused candidate receipt; no signed promotion is established.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-06 — A declared exact workload to the Task Alpha GHZ reference

**Problem.** The August 25, 2026 checkpoint defines a bounded exact reference workload with a separately declared known answer and explicit input/error contract.

**Discussion and correction.** Policy admission, capability, custody, privacy and release state remain separate from numerical success. Synthetic demonstration factors do not establish live authorization.

**Solution and code.** The emulator represents Gaussian-integer amplitudes over powers of sqrt(2), implements H/X/Z/S/CNOT and applies H0, CNOT0→1, CNOT1→2 to |000>.

**Algorithm and result.** The saved receipt reports exact GHZ state agreement, normalization and fidelity 1/1; 82 policy plus 73 workload methods total 155, with eight separate paired replay comparisons. This is classical exact emulation, not physical entanglement or quantum advantage.

Source rows: No matching historical summary row is asserted; this chain uses the preserved computational work records below..

Preserved collections: `full-task-alpha`.

Code identity examples: `nested_package_extracted_readonly/src/alpha_reference_emulator.py` — SHA-256 `46775afe200314adaf075005c586856d94165f9cf4fae0f38127e09ffe1f5b90`; `nested_package_extracted_readonly/tests/test_alpha_reference_emulator.py` — SHA-256 `9889e4499abb70b9bb1d80ba147d90d39d9167ce8fd86f6bd124326645b5a262`; `nested_package_extracted_readonly/upstream/qel_alpha_omega_contract.py` — SHA-256 `f429c9454736344d7cc56de88bc176e04e9cfd819f497f66bcb7e238656c4acf`.

**Proposed timeline link.** Candidate new August 25 entry: Task Alpha is absent from the pinned 175-entry timeline and the inspected 504-entry prior-work catalogue by reviewed title/summary search. Link the declared creation time and saved receipts to the new work/source index; do not use consolidation time as execution time.

**Remaining evidence boundary.** No original conversational request is included in this chain. The sequence-52 source was a delta, not a complete recovered integrated tree.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-07 — State-space growth to a measured workload-specific dense limit

**Problem.** The September 18 workload asks which dense state-vector sizes fit a stated memory reserve on the laptop.

**Discussion and correction.** An initial attempt did not complete; a double-reserve issue and supervisor overhead were recorded before later admitted trials. The implementation allocates two Float64 arrays, 16 × 2^n bytes.

**Solution and code.** The live_scale source runs GHZ forward/inverse checks and a structured full-support phase pattern under explicit admission and supervision.

**Algorithm and result.** Sizes 1–21 completed across 25 admitted trials, with 225 check evaluations. The 22-qubit request was refused before allocation: 64 MiB plus the 256 MiB reserve exceeded observed free space by 12.2890625 MiB. The separate September 19 60-qubit sparse GHZ summary uses only two populated amplitudes and does not extend dense capacity.

Source rows: `prior_work:QEL-PW-0392` (2026-09-18); `prior_work:QEL-PW-0393` (2026-09-19).

Preserved collections: `live-dense-qubit-scaling-20260918`.

Code identity examples: `QEL_Live_Qubit_Scaling_20260918_03/live_scale.mjs` — SHA-256 `1e40043c78e9bcd8772203e9b3bbd1b22117ecb452c314254f15390aceddd734`; `QEL_Live_Qubit_Scaling_20260918_03/review_fresh_results.mjs` — SHA-256 `28fb1591f15555bcbed3881177a25b2b80ceadf401762f563cb89dd5794aca80`.

**Proposed timeline link.** Candidate dated links after the pinned timeline’s September 17 endpoint: QEL-PW-0392 and QEL-PW-0393 already disclose separate dense and sparse claims in the prior-work appendix. Add the dense preserved source collection and retain the sparse summary boundary.

**Remaining evidence boundary.** The full sparse 60-qubit assessment package is not supplied by these reviewed chronology inputs. Structured input families do not establish arbitrary-state capacity.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-08 — SAT correctness obligations to counterexamples, bounded repair and exact rounding

**Problem.** September 19, 2026 04:53 UTC: the research contract requires arbitrary encoded 3-SAT, correctness, worst-case bit cost, precision, readout and UNSAT obligations.

**Discussion and correction.** 05:24 UTC Study001 records a satisfiable four-variable, eight-clause local minimum defeating greedy one-bit repair. 05:54 UTC Study002 records bounded false-clause branching with O(3^k poly(N)) cost, not unrestricted polynomial-time coverage.

**Solution and code.** 06:03 UTC Study003 links Boolean violations to a diagonal clause Hamiltonian and canonical product-state expected energy. The 06:25–06:26 UTC Study004 summaries retain repeated-literal and exact-rounding corrections. These are summary-described algorithms; their full original code is not supplied here.

**Algorithm and result.** The summaries retain 18,590 oracle queries, and separately 384 formulas, 4,096 assignments and 4,608 expectation checks. Later candidate output records 370 SAT witnesses, UNKNOWN on 14 UNSAT cases and a connected 12-variable counterexample after 379 starts. These populations are not combined and no general P-versus-NP result follows.

Source rows: `prior_work:QEL-PW-0399` (2026-09-19T04:53:00Z); `prior_work:QEL-PW-0400` (2026-09-19T05:24:00Z); `prior_work:QEL-PW-0401` (2026-09-19T05:54:00Z); `prior_work:QEL-PW-0402` (2026-09-19T06:03:00Z); `prior_work:QEL-PW-0403` (2026-09-19T06:25:00Z); `prior_work:QEL-PW-0404` (2026-09-19T06:26:00Z).

Preserved collections: Full study packages unavailable in this reviewed selection.

Code identity examples: No full original code identity supplied by these documentary summaries..

**Proposed timeline link.** Add links to already public QEL-PW-0399–0404 after the pinned timeline endpoint. Keep the exact recorded UTC sequence and distinguish the mixed five-problem Study004 session from its later rounding correction.

**Remaining evidence boundary.** The complete original Study001–004/SAT packages and original conversations were not acquired by this documentary selection; do not invent transcripts, source filenames or fresh verification.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-09 — Aluminum energy targets to variational predictions and unfavorable controls

**Problem.** The September 28 local assessment uses 24 ordered aluminum k-points, eight orbitals and retained Wannier inputs to obtain 192 energy predictions.

**Discussion and correction.** The source must distinguish a target-free variational path from classical-target fitting elsewhere in the lineage, preserve repeat k-points, and compare against an ordinary eigensolver.

**Solution and code.** The 18-angle, three-qubit variational circuit uses adjoint gradients and penalized sequential state optimization; 24 × 8 × 2 = 384 starts. Independent reconstruction/scoring checks the saved state and energy outputs.

**Algorithm and result.** The retained original MAE is about 3.4502e-6 eV and elapsed solve time 20.582 seconds; the conventional Jacobi control is more accurate (about 2.34084e-9 eV) and faster (0.911 seconds). Twenty-four additional same-material points retain their own 192 predictions, residuals and budget-limit counts. These are classical numerical results, not official benchmark rank or physical QPU execution.

Source rows: No matching historical summary row is asserted; this chain uses the preserved computational work records below..

Preserved collections: `full-jarvis-aluminum`, `retained-jarvis-dependency-layout`, `jarvis-private-01`, `jarvis-private-04`.

Code identity examples: `run-assessment-original-v1.mjs` — SHA-256 `3e506bdf5a84082b00338a72bde498fe14892867d11b0fa8a5583954474bcb65`; `run-assessment.mjs` — SHA-256 `ede3964b91507a9ad830c3f806e71432b423bdf88c0e87f1cfdfa9df7626c622`; `score-assessment.mjs` — SHA-256 `3d178916380a35250f335879e5a256cff29cc582d713689c471ae40a5ffb831a`.

**Proposed timeline link.** Candidate September 28 assessment and September 29 UTC verification links are absent from the pinned 175-entry timeline; add from the preserved work/source index. Do not confuse this one-material variational study with the already public JARVIS-DFT 2D dataset evidence.

**Remaining evidence boundary.** The complete original conversation is unavailable. Independent source/receipt inspection supports this summary; the consolidation did not rerun the optimizer or establish broad material generalization.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## QEL-CHAIN-10 — Retained optimizer cost to bounded software-performance improvement

**Problem.** The September 28 local / September 29 UTC solver work seeks reduced runtime while retaining the existing optimization answers and diagnostic evidence.

**Discussion and correction.** A slower first rewrite and later unsuccessful intermediates remain in the record. Cache hits are separated from fresh solver work and process measurements from whole-system claims.

**Solution and code.** Cached trigonometric evaluations and a compact BFGS implementation retain the objective, updates and stopping rules; fresh-process paired ordering limits a simple ordering bias.

**Algorithm and result.** Two batches each contain four fresh processes ordered old/new/new/old, two observations per version per batch. First-batch median wall time changes 17.870→14.807 seconds (17.1%); the later batch changes 18.522→16.050 (13.3%). All 192 energy/parameter outputs agree exactly within each batch. Both miss the 20% target; sample size and live background load limit generalization.

Source rows: No matching historical summary row is asserted; this chain uses the preserved computational work records below..

Preserved collections: `full-jarvis-aluminum`, `full-qel-performance`.

Code identity examples: `benchmark.mjs` — SHA-256 `37c05d1cd3da24f13c8e8bf005a5907826dffc5edbab9fef6f51cbb72e3865b9`; `cached-adjoint.mjs` — SHA-256 `4b792d890394c11f6889f2aa40e26bf69aec205d7b3bcac3b6e157624fcce9bb`; `compact-bfgs.mjs` — SHA-256 `ffc7c28235dc400f769e9f52a1e55fb665477b753d51aba808e71efb266790e1`.

**Proposed timeline link.** Candidate performance follow-on links should preserve the September 28/29 local-versus-UTC reporting distinction, the slower attempts, the missed target and the separate cache pathway.

**Remaining evidence boundary.** The complete original interaction is unavailable; two observations per version per batch cannot establish a universal speedup, Windows-wide improvement or a complete adversarial cache audit.

Linkage status: Editorial cross-reference of source-supported stages; not a reconstructed transcript or proof that one particular conversation caused every later implementation.

## Coverage and redaction are separate

A missing original conversation or study package is a source-coverage gap. An event already in the prior-work catalogue but not linked in the main timeline is a navigation/detail gap. Private locators, conversation identifiers, extreme personal context and controller-sensitive content are intentional public exclusions; their omission does not erase the private provenance record. Source hashes remain in the JSON identities and preserved collection index. They establish byte identity, not correctness, ownership or endorsement.

No GitHub file was changed. Owner review remains pending.
