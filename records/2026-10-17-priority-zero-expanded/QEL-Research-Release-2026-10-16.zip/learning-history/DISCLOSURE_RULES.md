# Include the mistakes as part of the research history

Owner direction, October 16, 2026: “I don't want to avoid the mistakes, because
mistakes are how we learn. So I want all those also put forward.”

Earlier produced work belongs in the proposed public history even when a later
review found it incorrect. Keep the original proposal, draft, code or result;
identify its date and actual source; explain the observed problem; then link the
correction and its evidence. If no correction or exact original has been located,
say so. Do not invent a completed learning cycle.

This applies throughout the available chronology. Q8 and the USB remain the
central technical account. Early learning, abandoned approaches, unsuccessful
versions and assistant mistakes are eligible historical material. A polished
successor must not silently erase the work that preceded it.

## How each historical stage is presented

1. **What existed at the time:** actual produced artifact or the available
   documentary account, with original wording distinguished from editorial summary.
2. **What it claimed or attempted:** the objective, method or asserted capability.
3. **What the evidence showed:** the result and its measurement or review scope.
4. **What changed:** a named later version, correction or retraction, if located.
5. **What remains open:** limits, missing sources and unverified outcomes.

The classifications retain important differences:

| Classification | Meaning |
|---|---|
| Confirmed defect | Specific preserved evidence identifies incorrect behavior or implementation |
| Failed target / unfavorable result | Work ran but missed its declared criterion or compared poorly; this is not automatically a coding defect |
| Corrected or withdrawn assertion | Earlier wording overreached or was mistaken; retain both the assertion and correction with attribution |
| Superseded checkpoint | A partial or pending state later changed; the earlier receipt may have been entirely correct when written |
| Unexecuted or incomplete work | An artifact or plan exists without the required run/outcome; do not invent a result |
| Unresolved question or coverage gap | Evidence is insufficient; do not label it a proven error |

A historical statement may remain in an exhibit even if unsupported or false,
provided its source, date and current assessment are clear. It must not be
repeated in the abstract or findings as a currently established result. This
clarifies earlier checklists that asked for unsupported claims to be removed:
they should be removed from asserted current findings, not erased from the
documented learning history. The earlier frozen editions remain preserved.

## Preservation and privacy

Keep exact private originals and source hashes. Historical excerpts and public
derivatives receive their own identities and transformation notes. Preserve
authorship evidence as recorded; do not assign every historical error to the
owner, or backdate the current assistant/project identity. A later review's
description is not a recovered original transcript.

Exclude extreme personal context and sensitive controller information through
declared privacy edits. Incorrect scientific or technical content is not itself
a privacy reason for omission. Do not conceal an unfavorable result as a privacy
edit. Keep missing-source gaps distinct from deliberate redaction.

The addendum is an owner-review candidate. Review the exact files and final
manifest before publication. Existing private evidence archives remain private;
the new direction does not automatically authorize their wholesale upload.
