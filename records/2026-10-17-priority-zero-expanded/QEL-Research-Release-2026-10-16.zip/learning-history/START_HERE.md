# Mistakes, attempts and corrections — research learning history

Prepared for Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent:
GAUCIA Actual. Supporting review: Codex. October 16, 2026. Owner review pending.

This addendum makes earlier produced work part of the publication selection even
when it was wrong or unsuccessful. It retains historical claims, drafts, code,
results and corrections with their evidence. Q8 and the USB remain central within
the broader research chronology.

## Read the history

- [Read-aloud account](READ_ALOUD.md) explains the purpose and representative cases.
- [Documentary chronology](documentary/REVIEW.md) covers the early phases and later
  research through the available documentary collections; its [coverage record](documentary/coverage.json)
  accounts for the screening population and selection limits.
- [Technical learning history](technical/REVIEW.md) connects earlier numerical
  work, unsuccessful versions, source artifacts, results and later corrections.
- [Operational learning history](operational/REVIEW.md) connects Hebrew and GAUCIA
  defects, repairs, mistaken guidance and changing installation checkpoints.
- [Publication rules](DISCLOSURE_RULES.md) keep historical incorrect assertions
  visible without promoting them into current findings.
- [Owner checklist](OWNER_REVIEW_CHECKLIST.md) records the final review decisions.

Each chapter has a `records.json` file with its supporting source identities and
scope. Its IDs belong to that chapter. The chapters overlap: one code problem can
appear in a historical summary, a detailed technical account and an operational
receipt. Do not add those accounts into a count of unique mistakes or inventions.

## Actual produced work

The technical exhibits include complete earlier source artifacts and a clearly
labeled recovered text reconstruction. Their original comments remain attached;
the assessment is provided separately. The reconstruction is not substituted for
the unavailable original byte sequence.

The operational exhibits show preserved earlier and corrected code for H04
interruption recovery, library text loss, and shutdown saving. Other records
include exact report or source excerpts. Excerpt extraction, line ranges,
source hashes and display transformations are recorded. Missing original
misattribution headers and malformed console input are explicitly identified;
later accounts are not presented as those missing originals.

Full manuscript review bodies and broader source collections remain in the
previously delivered editions identified by `RELATED_EDITIONS.json`. This
addendum links and extends that evidence rather than replacing the frozen
editions. Exact private originals and local locators stay in private evidence.

## What the classifications mean

A confirmed defect, an unfavorable measurement, an unsupported assertion, an
accurate earlier pending state, an unexecuted plan and an unavailable result
are different kinds of evidence. All can help explain development, but only
some are demonstrated mistakes. Where the records do not establish a cause,
author or correction, the account preserves that uncertainty.

Dates retain their source precision and role. A later report or recovery date
does not become an original production date. The broad documentary chapter
provides historical ordering; detailed chapters group related versions while
preserving each recorded date. Date-only records do not acquire invented times.

This is an extensive review of located material, not a complete original
interaction archive or a claim that every historical error has been found.
No historical scientific program, installation or USB operation was rerun for
this addendum. Source/excerpt checks establish identity and traceability;
they do not provide independent experimental replication or certification.

The listed payloads can be checked with `python verify_manifest.py`. That utility
reads bytes and does not execute the historical code exhibits. The manifest
excludes itself. Owner review of the exact final selection still precedes any
public upload; no publication has occurred.
