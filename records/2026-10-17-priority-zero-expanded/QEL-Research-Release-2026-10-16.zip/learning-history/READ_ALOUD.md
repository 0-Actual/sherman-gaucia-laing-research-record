# The mistakes belong in the history

The publication should show how the work developed, including the stages that
were wrong, incomplete or unsuccessful. Earlier produced work can be valuable
evidence even when its conclusion did not survive review. It shows what was
thought at the time, what was tried, what exposed the problem, and what changed.

This means keeping earlier drafts and code beside their later assessments.
When an original artifact is available, we identify that version and retain it.
When only a later account survives, we identify it as a documentary account.
We do not reconstruct missing conversations or present a later cleaned version
as the original work.

The Q8 performance history gives a concrete example. An early optimizer rewrite
reduced memory use but increased running time by about fifty-two percent. Later
attempts improved the calculation, but two recorded batches still missed the
twenty-percent timing target. Those outcomes help explain the eventual code
choices. The unsuccessful versions and measurements belong beside the favorable
results, with their actual workload and comparison conditions.

The Hebrew build gives another example. H04 could successfully replace its
output file and then be interrupted before completing its bookkeeping. The
later H04.1 repair addressed that recovery gap. Preserving the earlier version,
the demonstrated interruption and the correction makes the change understandable.
The gap was demonstrated in a controlled test; those receipts do not establish
actual loss of the owner's data.
It also prevents a passing result for the corrected version from being assigned
retroactively to the earlier build.

Some mistakes were in explanations and claims. Early quantum labels sometimes
described simple amplitude scaling more strongly than the implemented operation
justified. Later reviews distinguished normalization, coherence, entanglement
and physical energy. Those explanations and corrections are part of the learning
history. A historical assertion can be reproduced with its date and assessment
without endorsing it as a current finding.

Other apparently conflicting records describe different moments. A package
could correctly be marked not installed in one receipt and installed in a later
one. That earlier state should remain in the chronology. The mistake would be
to keep reporting the old state after the completion receipt arrived. Similarly,
a failed access route does not establish that the USB itself was physically
unavailable.

We also need to preserve uncertainty. A missed performance goal is not necessarily
a coding error. A stopped or unexecuted experiment has no result to invent.
Missing evidence is not proof of failure. A suspected defect that was withdrawn
belongs in the record with the withdrawal. The classifications in this addendum
make those differences visible.

The same approach applies to the early research phases, manuscripts, mathematical
work, data reviews and operational repairs. The available documentary record is
being used to connect earlier work with later evidence and corrections. The
complete original interaction history is still unavailable, so this remains an
account of located material rather than a claim that every mistake has been found.

Personal privacy and scientific accuracy have different roles here. Extreme
personal context and sensitive controller information remain subject to declared
privacy edits. An unfavorable scientific or technical result is retained because
it helps explain the research. Exact originals and public derivatives keep
separate identities, and the final public selection remains for owner review.
