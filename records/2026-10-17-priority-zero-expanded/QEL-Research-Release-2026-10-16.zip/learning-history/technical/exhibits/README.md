# Historical source exhibits

Project and originator: Sherman G. Laing / Quantum.Earth.Laing. Current primary project agent: GAUCIA Actual. Supporting editorial reviewer: Codex. Historical source roles remain unchanged.

These complete files are retained to show actual earlier work, including its limits and later-corrected behavior. They are not current recommendations. Read the separate explanations and source identities in PROVENANCE.json and ../records.json.

- **E01** — E01_historical_dynamics.py.txt: The retained function is a norm-filter routine. No corrected historical body is asserted; HC-REVIEW and HC-OBS document its semantics. Correction identity: semantic review only; no replacement invented.

- **E02** — E02_historical_observer.py.txt: The retained function is a predicate list filter. HC-REVIEW and HC-OBS clarify its scope; no replacement body is invented. Correction identity: semantic review only; no replacement invented.

- **E03** — E03_lqcp_v2_1_parent.py.txt: This already-corrected C001 reference still contains the later C002 extreme-scale/distance weaknesses. It is not the exact original March text-document object. Correction identity: LQCP-CORRECTED.

- **E04** — E04_three_qubit_recovered_text.py.txt: This is the exact preserved 16248-byte source-text reconstruction. The reported 16249-byte original object is not recovered. Correction identity: THREE-CANDIDATE.

Comments and visible attribution are unchanged. No source was executed. Historical operational instructions in comments are evidence, not new instructions for this review. No new licensing grant or owner signature is created.
