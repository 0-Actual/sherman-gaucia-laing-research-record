# Technical learning history — retained errors, unsuccessful versions and limits

Project and originator: **Sherman G. Laing / Quantum.Earth.Laing**. Current primary project agent: **GAUCIA Actual**. Supporting editorial review: **Codex**. Historical source names and roles remain unchanged.

This is an additive review of produced Q8/quantum work, including what went wrong. The original files and delivered packages remain unchanged. The record keeps failed targets beside later gains, separates actual defects from unexecuted work, and retains claims that later evidence narrowed or withdrew. No scientific program was run for this addendum.

The selection contains **57 issue/version records**, **108 exact source identities** and **four complete historical source exhibits**. Those are documentary units, not independent research studies or a project-wide failure rate. Read `records.json` for date precision, evidence, source identities, corrections and remaining unknowns.

The most consequential sequence is visible in the JARVIS work: a missed ground-energy point survived two adaptive follow-ups; coupled BFGS resolved that point but exposed small-gap fidelity misses; the next repair still missed 39 of 720 full-acceptance cases; bracketing addressed those while a seed review removed one already-solved control from claims of independent difficulty. Later performance rewrites include a 52.1% slowdown and two slower probes before a selected improvement that still missed its 20% target in both recorded batches.

The earlier numerical record is equally explicit. A corrected reference was later found to reject ordinary normalized directions at extreme scale; its fidelity subtraction could erase small distances or invent nonzero self-distance. Circuit validation skipped an unknown instruction while reporting PASS. The entropy existence test confused small positive parameters with nonuniqueness. These produced versions remain identifiable; they are not replaced by a narrative containing only successful tests.

Some entries are limits rather than mistakes: a capacity admission stop is not a failed circuit; an unexecuted protocol has no measured failure rate; structured 60-index representations are not dense 60-qubit storage; Windows counters collected before USB checks are not simultaneous load measurements. The historical ten-minute runtime assertion is explicitly withdrawn because its duration was never established.

## Complete historical exhibits

| Exhibit | Complete preserved body | How to interpret it |
|---|---|---|
| E01 | [E01_historical_dynamics.py.txt](exhibits/E01_historical_dynamics.py.txt) | The retained function is a norm-filter routine. No corrected historical body is asserted; HC-REVIEW and HC-OBS document its semantics. |
| E02 | [E02_historical_observer.py.txt](exhibits/E02_historical_observer.py.txt) | The retained function is a predicate list filter. HC-REVIEW and HC-OBS clarify its scope; no replacement body is invented. |
| E03 | [E03_lqcp_v2_1_parent.py.txt](exhibits/E03_lqcp_v2_1_parent.py.txt) | This already-corrected C001 reference still contains the later C002 extreme-scale/distance weaknesses. It is not the exact original March text-document object. |
| E04 | [E04_three_qubit_recovered_text.py.txt](exhibits/E04_three_qubit_recovered_text.py.txt) | This is the exact preserved 16248-byte source-text reconstruction. The reported 16249-byte original object is not recovered. |

The `.py.txt` extension makes these reading exhibits; their bytes and comments are unchanged. E03 already contained useful C001 corrections before its remaining C002 defects were exposed. E04 is recovered text and must not be relabeled as exact original-byte recovery. The wrapper and provenance are separate from the source. Original notices remain; this preparation does not grant new rights.

## Issue and version sequence

### T001 — Squared norm called energy in an early dynamics function

**Classification:** unresolved_or_limited. **Date:** Unresolved — Function inception not established; source captured and observed October 14, 2026.

The historical dynamics routine names sum(abs(state)**2) energy and selects returned states using energy_threshold.

Evidence: There is no Hamiltonian. A nonunitary scaling example gives norm squared four; rejected output states still feed the next gate. The saved bounded observations reproduce these semantics.

Correction or successor: Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.

Outcome: A complete exact early body is retained as exhibit E01. It can be studied as conventional array processing, not evidence of physical energy selection.

Still unknown: The file inception date and intended original physical contract are not established by the capture date.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: HC-DYNAMICS, HC-REVIEW, HC-OBS, HC-RESULTS (identities and logical paths in `records.json`).

### T002 — Observer naming exceeds the implemented predicate filter

**Classification:** unresolved_or_limited. **Date:** Unresolved — Undated historical body; October 14, 2026 source observation.

The produced observer_effect function retains entries satisfying a supplied predicate.

Evidence: It preserves order, duplicates and object references; no quantum probability, collapse, renormalization or copied state is implemented.

Correction or successor: The documentary review separates implementation from the physical implication of the name.

Outcome: Complete exact body preserved as E02. This is a semantic limit, not a claim that list filtering malfunctioned.

Still unknown: No missing measurement mechanism is invented.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: HC-OBSERVER, HC-REVIEW, HC-OBS (identities and logical paths in `records.json`).

### T003 — Guidance routine has random perturbation but no implemented ethical objective

**Classification:** unresolved_or_limited. **Date:** Unresolved — Undated body; reviewed October 14, 2026.

The historical guidance routine probabilistically adds a uniform perturbation between -0.1 and 0.1 to numeric decisions.

Evidence: The inspected body contains no ethical criterion, probability validation, output clipping or optimization objective; deterministic mocked draws confirm the branch behavior.

Correction or successor: The later review preserves the project attribution but describes the actual perturbation function.

Outcome: Source remains preserved; no claim of learned ethical behavior is supported.

Still unknown: No broader implementation is inferred from this small routine.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: HC-GUIDANCE, HC-REVIEW, HC-OBS (identities and logical paths in `records.json`).

### T004 — Early architecture cannot be treated as a self-contained integration

**Classification:** unresolved_or_limited. **Date:** Unresolved — Later pinned snapshots; initial December 19, 2024 commit does not date every body.

The architecture imports QuantumAI, multi-agent and encryption components and invokes a 2x2 operator after requesting state_dim=4.

Evidence: Required bodies and distribution bindings are absent from the inspected capture. Under an ordinary four-entry vector contract the operator size is incompatible, but the missing class prevents executing that integration claim.

Correction or successor: Only the three available numerical/filter functions were observed; missing classes were not fabricated to produce a pass.

Outcome: Conditional dimension concern and concrete dependency gaps retained. No full-pipeline failure or success asserted.

Still unknown: Absent-from-capture is not absent-everywhere; actual QuantumAI dimensional convention remains unknown.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: HC-PIPELINE, HC-REVIEW, HC-RESULTS (identities and logical paths in `records.json`).

### T005 — Greedy gate placement rejected valid plateau-crossing solutions

**Classification:** confirmed_defect. **Date:** 2026-08-21 — Generation A integration correction cycle; no exact first-failure timestamp.

The first placer required each individual chosen gate to improve target fidelity.

Evidence: |00> to |11> needs two X gates; either first gate alone leaves target fidelity zero, so the one-step rule rejected a valid sequence.

Correction or successor: Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.

Outcome: Correction receipt states corrected and retested. This is bounded search, not universal optimizer completeness.

Still unknown: Exact first greedy body is not separately identified in this selected register; correction receipt and final implementation lineage remain.

Preservation: Exact correction receipts preserved; first erroneous body not separately selected as an authenticated version.

Sources: A-C1, A-C3, A-FINAL (identities and logical paths in `records.json`).

### T006 — Input coercion and receipt canonicalization defects in the integration adapter

**Classification:** confirmed_defect. **Date:** 2026-08-21 — Correction cycle; exact occurrence times not in the receipts.

Some qubit/depth paths coerced booleans or fractions with int(), and array/complex receipt conversion could reintroduce raw floats. The manifest still called the corrected search greedy.

Evidence: The correction receipt identifies prepare_uniform_state, max_depth, measurement, gate expansion, controlled-phase type checks, recursive canonicalization and stale naming.

Correction or successor: Strict integer validation and recursive decimal-string canonicalization were applied; the manifest name became bounded_lookahead_adaptive_gate_placement.

Outcome: Final receipt reports 59 adapter/kernel plus 87 preserved B-D behavioral methods, 146 total within those two suites.

Still unknown: These reconstructed B-D behavior checks do not recover the missing exact original B-D source.

Preservation: Receipt and final version preserved; exact first erroneous adapter revision not separately identified.

Sources: A-C3, A-FINAL (identities and logical paths in `records.json`).

### T007 — The claimed ten-minute timeout was withdrawn

**Classification:** retracted_claim. **Date:** 2026-08-21 — Owner-review audit instruction anchor; exact interrupted invocation duration unproven.

An interim update said the monolithic runner failed to finish within ten minutes.

Evidence: The owner-review audit explicitly says that duration was not proven: the effective single-call window ended before output.

Correction or successor: The accurate statement is bounded-call interruption. Checkpointed subprocesses preserved completed capabilities and resumed the remainder.

Outcome: All 21 capabilities later reproduced their governed identities; measured subprocess total 67.169604 seconds is a separate host observation.

Still unknown: The original invocation duration/cause beyond its effective call boundary is not established; do not relabel it resource exhaustion.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: A-OWNER, A-C2 (identities and logical paths in `records.json`).

### T008 — A diagnostic file contaminated a supposedly clean RC1 extraction

**Classification:** confirmed_defect. **Date:** 2026-08-21 — Owner-review audit date; precise insertion time unavailable.

A diagnostic script was written inside the extracted RC1 tree before its release-gate identity was compared.

Evidence: File count changed from 52 to 53 and the receipt identity changed although the gate still printed PASS.

Correction or successor: The contaminated extraction was rejected; fresh exact extraction reproduced the governed 26-check identity.

Outcome: The audit preserves the rejected attempt rather than equating a PASS word with an unchanged package.

Still unknown: The extra diagnostic file itself is not separately selected here.

Preservation: Exact audit account retained; contaminated tree is not represented as the canonical package.

Sources: A-OWNER (identities and logical paths in `records.json`).

### T009 — Propagation builder used JSON booleans in Python

**Classification:** confirmed_defect. **Date:** 2026-08-21 — Integration correction cycle, occurrence timestamp not supplied.

The first propagation builder used true and false inside Python.

Evidence: Executions stopped with NameError before a valid map; empty/partial outputs were not credited.

Correction or successor: Python True/False replaced those literals and the build was run twice.

Outcome: Correction receipt retained. It says invalid outputs were deleted during the historical correction; this addendum does not pretend they are preserved.

Still unknown: Exact failed source/output bytes are not independently identified here.

Preservation: Correction receipt preserved; receipt reports invalid outputs were deleted at the time. No recreated failed output is supplied.

Sources: A-C4 (identities and logical paths in `records.json`).

### T010 — QPRINT builder failed syntax before producing a carrier

**Classification:** confirmed_defect. **Date:** 2026-08-21 — Integration correction cycle; exact error time unavailable.

An ImageDraw.text call placed text inside its coordinate tuple in the first readable-JPEG builder.

Evidence: Python compilation failed; no carrier or valid receipt existed for that attempt.

Correction or successor: Arguments were separated correctly, followed by syntax and full-build verification.

Outcome: The corrected pre-release build was later superseded; original failure remains in its correction receipt.

Still unknown: The first erroneous builder is not independently selected as exact bytes.

Preservation: Exact failure/correction receipt preserved; not a recovered failed carrier.

Sources: A-C5 (identities and logical paths in `records.json`).

### T011 — Source-validation identity changed across packaging phases

**Classification:** confirmed_defect. **Date:** 2026-08-21 — Integration correction cycle, no exact first-failure timestamp.

The recovered-source scan included package manifest and previous validation report that did not exist during the original source phase.

Evidence: Package and carrier checks passed, but source-validation receipt identity differed because scan counts included later-generated files.

Correction or successor: Generated package/report files were excluded from source scans and verified separately; inventory, validation, package, ZIP and QPRINT rebuilt.

Outcome: Correction receipt states the superseded carrier was preserved.

Still unknown: Its separate historical carrier identity is not claimed verified by this bounded source review.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: A-C6, A-FINAL (identities and logical paths in `records.json`).

### T012 — Mean-square amplitude rescaling was incorrectly associated with coherence

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C001 recheck of an older already-corrected model; not the first discovery date.

Historical Algorithm 13 divided a vector by sqrt(mean(abs(psi)**2)) as a coherence-preservation operation.

Evidence: A unit-norm d-dimensional vector then has norm sqrt(d), giving raw probability sum 8 at three qubits. Global rescaling does not establish coherence preservation.

Correction or successor: The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.

Outcome: This was already known before C001; it is not counted as a newly discovered C001 defect.

Still unknown: The exact original historical text-document bytes remain distinct from the clean-room reference.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C001, LQCP-PARENT, LQCP-CORRECTED (identities and logical paths in `records.json`).

### T013 — Algebraically equivalent Ramsey evaluation failed reciprocal scales

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C001 checkpoint 20:19 Eastern; September 5 UTC.

The parent evaluated exp(-0.5*spread*spread*t*t).

Evidence: For spread=1e200,t=1e-200 it returned 0 instead of exp(-1/2); reversed scales returned 1; spread=1e200,t=0 produced NaN.

Correction or successor: C001 forms spread*t first, preserving the dimensionless product, then squares it.

Outcome: The corrected v2.1 parent is preserved. C001 reports 108 inherited and 12 boundary methods passing; seven of the 12 boundary methods exposed parent failures.

Still unknown: The pre-C001 v2 body is described by the retained report but is not separately selected in this C002 register; no arbitrary-precision claim.

Preservation: Exact C001 report and corrected v2.1 preserved. Exact pre-C001 v2 source is not a separately selected object in this register.

Sources: C001, LQCP-PARENT (identities and logical paths in `records.json`).

### T014 — Finite ratio inputs produced infinite outputs

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C001 checkpoint date.

safe_modulation_ratio and coherence_preservation_ratio checked inputs and denominators but not representability of the quotient.

Evidence: 1e308/1e-14 returned positive infinity; the signed function could return negative infinity.

Correction or successor: C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.

Outcome: Bounded correction passes reported regression/boundary tests, preserving ordinary finite behavior.

Still unknown: Tiny valid quotients may still underflow to zero; the correction does not guarantee arbitrary relative accuracy.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C001, LQCP-PARENT (identities and logical paths in `records.json`).

### T015 — Unknown circuit operation was skipped while the API reported PASS

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C001 reproduction; isolated Windows candidate checked September 5 UTC.

executeCircuit validated the configuration but not a separately supplied circuit argument.

Evidence: A separate UNKNOWN then MEASURE_Z circuit returned PASS with 10/10 checks; the unknown operation generated zero checks.

Correction or successor: A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.

Outcome: Sixteen focused methods passed; 13 frozen circuits retained exact bodies and 383 existing engine checks. Later same-device candidate test recorded separately.

Still unknown: No evidence says malformed operations occurred in the historical production path, which selected validated configuration circuits; candidate deployment is not inferred.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C001, CIRCUIT-ORIGINAL, CIRCUIT-CANDIDATE, CIRCUIT-WINDOWS (identities and logical paths in `records.json`).

### T016 — The corrected v2.1 reference still rejected valid extreme-scale states

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C002 began 20:41 Eastern; September 5 UTC.

v2.1 normalized using a direct Euclidean norm after validation.

Evidence: Finite nonzero [1e300,1e300] and [1e-300,1e-300] overflowed/underflowed the direct norm although the normalized direction is ordinary.

Correction or successor: v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.

Outcome: Parent fails 13 of 22 new precision methods; candidate passes all 22 plus 108 inherited and 12 earlier methods, 142 total. Full parent retained as E03.

Still unknown: Extreme relative components can still round to zero; no recovery of information outside the chosen numeric format.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C002, LQCP-PARENT, LQCP-CORRECTED, PRECISION (identities and logical paths in `records.json`).

### T017 — Near-one fidelity subtraction lost tiny distances or invented self-distance

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C002 cycle, September 5 UTC execution receipts.

v2.1 evaluated sqrt(max(0,1-fidelity)).

Evidence: It reported about 2.1073424255447017e-8 self-distance for [1+2j,3-4j], while structured perturbations 1e-12 and 1e-300 vanished to zero.

Correction or successor: v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.

Outcome: Saved focused examples yield zero self-distance and retain the structured perturbations.

Still unknown: This does not establish sensitivity to arbitrary 1e-300 changes in general nearly collinear floating-point vectors.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C002, LQCP-PARENT, LQCP-CORRECTED, PRECISION (identities and logical paths in `records.json`).

### T018 — Three-qubit normalization accepted zero output after overflow

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C002 source-text reconstruction/correction; historical body inception unresolved.

The reconstructed validator rejected norm<=tol but did not reject an infinite norm before division; lifted reduction also used a direct norm.

Evidence: Huge finite input divided by infinity became a zero vector, and lifted reduction could yield a zero-trace density. Invalid NaN tolerance could permit zero-vector division.

Correction or successor: Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.

Outcome: 22 focused methods pass; 504 inherited numeric leaves differ by at most 2.53681827024348e-14 against 1e-12. Reconstructed parent retained as E04.

Still unknown: Original exact 16,249-byte object remains unrecovered; results apply to 16,248-byte recovered text.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C002, THREE-RECONSTRUCTED, THREE-CANDIDATE, THREE-RECEIPT, THREE-PROVENANCE (identities and logical paths in `records.json`).

### T019 — Entropy uniqueness test confused numerical threshold with mathematical existence

**Classification:** confirmed_defect. **Date:** 2026-09-04 — C002 review and September 5 UTC successor receipt.

The historical excerpt rejected 1-(1-eta)*(1-p)<=1e-10 as no unique fixed point.

Evidence: For p=1e-20,eta=0 the exact fixed point is I/2; for p=0,eta=1e-20 it is tau. Only p=eta=0 is nonunique. Near-one subtraction and unscaled products were numerically fragile.

Correction or successor: A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.

Outcome: 13 methods passed with a 760-digit oracle over ten difficult pairs and separate invariance/generated-density subcases.

Still unknown: The full original 662-line entropy module is not recovered here. Uniqueness is not a claim of fast convergence or thermodynamic benefit.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C002, ENTROPY-READ, ENTROPY-CANDIDATE, ENTROPY-RESULTS (identities and logical paths in `records.json`).

### T020 — C001 diagnosis overstated missing definitions and risked replacing established coupling policy

**Classification:** retracted_claim. **Date:** 2026-09-04 — C001 superseded by later source retrieval in C002.

The first audit treated the shorthand E>0.25 as lacking a sufficiently bound entropy definition and illustrated additive-score averaging.

Evidence: Later retrieval located an existing entropy contract and an identity-first coupling bridge. Missing linkage of shorthand is not absence of all definitions; averaging would change the model.

Correction or successor: C002 preserves the retrieved definitions and identity coupling, leaving score binding unresolved rather than imposing the earlier illustrative replacement.

Outcome: Both reports are retained so the overbroad preliminary diagnosis remains visible.

Still unknown: Binding of the shorthand to that module remains unresolved; no live bridge change is claimed.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C001, C002 (identities and logical paths in `records.json`).

### T021 — C002 gate and closure wrappers failed independently of numerical tests

**Classification:** confirmed_defect. **Date:** 2026-09-05 — UTC cycle; exact attempt metadata retained in separate receipts.

The first gate aggregated hashtable fields through a property mechanism; a later inline closure used fragile native argument quoting.

Evidence: Gate failed before Node. Closure failed after the 16 tests had passed. Neither was a failed mathematical result.

Correction or successor: Explicit scalar extraction fixed the gate without relaxing thresholds; a staged closure script fixed recording without repeating passed tests.

Outcome: Two failure receipts and later Windows receipt preserved; unavailable peak working-set remains null, not zero.

Still unknown: No whole-process memory cap follows from V8 old-space setting.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: C002, C002-GATE-FAIL, C002-CLOSURE-FAIL, CIRCUIT-WINDOWS (identities and logical paths in `records.json`).

### T022 — Exact three-qubit source recovery was incomplete by one byte

**Classification:** unresolved_or_limited. **Date:** 2026-09-05 — C002 provenance receipt, not historical body date.

Raw-byte retrieval failed; authenticated source-text reading produced 16,248 bytes against metadata reporting 16,249.

Evidence: The receipt retains TEXT_RECONSTRUCTION_NOT_BYTE_VERIFIED and did not guess the missing byte.

Correction or successor: The parent is explicitly named a source-text reconstruction; candidate corrections and identity changes bind to that text only.

Outcome: Exact recovered-text exhibit preserved with the same limitation, not promoted into the missing original.

Still unknown: Original byte discrepancy remains unresolved.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: THREE-PROVENANCE, THREE-RECONSTRUCTED, THREE-CANDIDATE, C002 (identities and logical paths in `records.json`).

### T023 — WF019 direct calls falsely accepted five invalid-input cases

**Classification:** confirmed_defect. **Date:** 2026-09-18 — Paired replay window 22:46:43.581–22:46:44.781 UTC; defect originally known earlier.

The direct function returned passed:true for text time, fractional time, excessive time, Infinity and a state omitted from the allowed set.

Evidence: Five fixed paired examples went from five false successes to zero via the existing guard. They overlap the broader 16-case rejection suite.

Correction or successor: Guard admission validates the input contract; 36 valid samples retained the same outputs and 252 internal checks.

Outcome: Known regression correction confirmed on the guarded path, not 100% improvement in the entire project.

Still unknown: Direct callers can still bypass the separate guard; deployment-wide enforcement is not established.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: IMPROVEMENT, GUARD-ORIGINAL, GUARD-CORRECTED, GUARD-PAIRED (identities and logical paths in `records.json`).

### T024 — Expanded verification was not numerical improvement or model training

**Classification:** unresolved_or_limited. **Date:** 2026-09-18 — Saved improvement-audit date.

A broad improvement account risked treating more checks as improved numerical accuracy or training of the underlying modules.

Evidence: The 24 matched energies are identical with the same error: 0% accuracy reduction in that subset. Seven source files remain byte-equal over 49 comparisons across eight scientific checkpoints.

Correction or successor: The audit separates expanded coverage from changed algorithms, accuracy and overall assistant reliability.

Outcome: It reports narrower admission gains while retaining zero matched accuracy gain and no measured project-wide error-rate improvement.

Still unknown: No whole-project reliability denominator exists; this is correction of the inference, not evidence that every aspect improved by zero.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: IMPROVEMENT, MATCHED-ENERGY (identities and logical paths in `records.json`).

### T025 — Paired replay staging failed before any scored cases

**Classification:** confirmed_defect. **Date:** 2026-09-18 — Audit date; separate exact tool times not asserted here.

Nested shell expansion damaged a help filter; script policy blocked a launcher; the first VM harness omitted initializeImportMeta.

Evidence: The first two were setup failures before Node. The VM error occurred before cases because import.meta.url was undefined. The proposed PowerShell watchdog never ran.

Correction or successor: Direct Node invocation and an additive run_02 harness with module.identifier metadata corrected the path; policies and original numerical code stayed unchanged.

Outcome: Original harness, corrected harness and failure receipts all remain preserved; no nonexistent numerical result is counted.

Still unknown: A pre-execution wrapper does not prove its unexecuted watchdog or resource behavior.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: IMPROVEMENT-SETUP, IMPROVEMENT-FIRST-FAIL, IMPROVEMENT-FIRST-CODE, IMPROVEMENT-CORRECTED-CODE, IMPROVEMENT (identities and logical paths in `records.json`).

### T026 — Dense scaling attempt 01 was stopped before any circuit

**Classification:** not_executed. **Date:** 2026-09-18 — Attempt day; exact saved timing is in its result object.

The first dense scaling parent tried to admit a ladder under a 256 MiB reserve plus launch allowance.

Evidence: It observed 269,041,664 free bytes, below the parent threshold. No circuit ran.

Correction or successor: Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.

Outcome: Attempt 01 code and result are preserved.

Still unknown: Not evidence of a numerical defect or hard machine-capacity limit.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: DENSE-REPORT, DENSE-01, DENSE-DRIVER-01 (identities and logical paths in `records.json`).

### T027 — Dense admission initially counted runtime reserve twice; resident controller also constrained continuation

**Classification:** confirmed_defect. **Date:** 2026-09-18 — Attempts 02 and 03 in the same cycle.

The child admission rule reserved runtime memory after runtime/kernel memory was already reflected in measured free RAM.

Evidence: The later report identifies duplicate reserve accounting. Attempt 02 passed sizes 1–13, then the parent stopped before 14 at 334,376,960 free bytes versus 335,806,464 required.

Correction or successor: Child admission used actual post-load free memory; a PowerShell supervisor removed resident Node-controller cost for continuation while retaining the same 256 MiB reserve.

Outcome: Attempt 03 continued 14–21. The parent stop and later success are retained as different orchestration states.

Still unknown: Memory snapshots vary with other activity; this is not proof of an intrinsic increase in hardware capacity.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: DENSE-REPORT, DENSE-02, DENSE-03, DENSE-DRIVER-01, DENSE-DRIVER-02 (identities and logical paths in `records.json`).

### T028 — The dense 22-qubit trial never ran

**Classification:** not_executed. **Date:** 2026-09-18T23:40:17.343Z — Final admission measurement UTC.

After three successful 21-qubit trials, the driver evaluated admission for 22.

Evidence: Required free memory was 335,544,320 bytes including reserve; observed 322,658,304 was short by 12,886,016 bytes.

Correction or successor: The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.

Outcome: Twenty-five completed trials across sizes 1–21 and one stopped child are separate units; no 22-qubit execution is credited.

Still unknown: A different load/policy could admit another size, but no such new run is asserted.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: DENSE-REPORT, DENSE-22 (identities and logical paths in `records.json`).

### T029 — JARVIS first variational pass missed one of six energy targets

**Classification:** failed_target. **Date:** 2026-09-20 — Day stated in original report; first run has separate timestamps.

Two seeded starts and at most 12 coordinate sweeps attempted six ground-energy cases using the unchanged 18-angle circuit.

Evidence: Original point 4 ended 0.0004007142024144983 eV above reference versus a <=0.0001 eV goal; five of six passed.

Correction or successor: Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.

Outcome: Original failed point and all other successes remain; no all-targets-passed claim for pass 01.

Still unknown: The first pass alone did not isolate landscape, expressivity or numerical cause.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J1-REPORT, J1-COMPUTE, J2-REPORT (identities and logical paths in `records.json`).

### T030 — The first adaptive follow-up still missed point 4

**Classification:** failed_target. **Date:** 2026-09-20 — Same-day bounded follow-up, exact time not repeated here.

Four starts and 64 sweeps revisited the already examined original point.

Evidence: Energy gap improved to 0.00014289359835650828 eV but exceeded unchanged 0.0001 eV target.

Correction or successor: A separately declared 256-sweep follow-up followed.

Outcome: Improvement is retained without reclassifying the miss as a pass or a fresh held-out test.

Still unknown: This follow-up was run once; no independent deterministic replay is claimed.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J1-REPORT, J1-FOLLOWUP (identities and logical paths in `records.json`).

### T031 — The second adaptive follow-up remained above goal

**Classification:** failed_target. **Date:** 2026-09-20 — Same-day second bounded follow-up.

Four starts and 256 sweeps revisited point 4.

Evidence: Final gap 0.00012074495903213744 eV remained above 0.0001 despite a 69.8676% reduction from the initial gap.

Correction or successor: Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.

Outcome: All four saved warm-start refinements and a cold seeded point-4 check reached the target in the later pass. The 256-sweep miss remains unchanged.

Still unknown: Adaptive follow-up was not blind or independently replayed; more sweeps alone did not establish convergence.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J1-REPORT, J1-STAGE2, J2-REPORT, J2-CANDIDATE (identities and logical paths in `records.json`).

### T032 — Energy accuracy hid two synthetic fidelity misses

**Classification:** failed_target. **Date:** 2026-09-20 — Pass 02 report and stress receipts.

Pass 02 evaluated six representable known-spectrum synthetic states with energy and fidelity requirements.

Evidence: At gap 1e-6 eV, energy error 5.61226507949274e-8 passed but fidelity 0.9438801949621364 missed 0.9999. At gap 1e-8, energy error 2.762947736350209e-9 passed while fidelity 0.7237052008836223 missed; that case also met gradient tolerance.

Correction or successor: State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.

Outcome: Four of six fidelity cases passed; the two misses are substantive negative results, not discarded energy successes.

Still unknown: Small residual/gradient/energy alone does not identify a unique ground state at a tiny gap.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J2-REPORT, J2-STRESS, J2-LEARNING, J3-STUDY (identities and logical paths in `records.json`).

### T033 — Passing energy did not mean every BFGS start converged

**Classification:** unresolved_or_limited. **Date:** 2026-09-20 — Pass 02 expanded-validation report.

The 42 ordered cases used two starts each and up to 400 BFGS iterations after warmup.

Evidence: Of 84 starts, 33 reached gradient tolerance and 51 exhausted iteration budget. Largest state residual was 0.0008444199310936169 eV despite all 42 energy targets passing.

Correction or successor: Report separates stopping reason, energy, state residual and fidelity.

Outcome: No claim of universal convergence or 84 successful convergence events is retained.

Still unknown: Further convergence at larger budgets is not measured by this receipt.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J2-REPORT, J2-CANDIDATE (identities and logical paths in `records.json`).

### T034 — Pass-02 orchestration reference error occurred before candidate creation

**Classification:** confirmed_defect. **Date:** 2026-09-20 — Learning-record day, no exact failed call timestamp.

One implementation orchestration reference was wrong while preparing candidate.mjs.

Evidence: Learning record states the error occurred before the candidate file was written and before numerical execution.

Correction or successor: Reference corrected before numerical work.

Outcome: Narrative error receipt retained; no failed numerical result or erased test is inferred.

Still unknown: Exact failed transient command/source bytes are not independently preserved in this selected record.

Preservation: Exact learning report preserved; transient erroneous preparation command is not separately identified.

Sources: J2-LEARNING, J2-REPORT (identities and logical paths in `records.json`).

### T035 — Pass-03 baseline and first Rayleigh repair retained many acceptance misses

**Classification:** failed_target. **Date:** 2026-09-20 — Final report recorded 21:01:46.962 UTC; individual study times separate.

A matched 720-case study compared the previous optimizer, first Rayleigh repair and bracketed revision.

Evidence: Baseline passed energy 696/720 but full acceptance 424/720. First repair passed energy 720/720 but full acceptance 681/720: 39 failures remained. All 39 fitted their supplied target accurately; target iteration stalled at a distant lower-bound shift.

Correction or successor: The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.

Outcome: Bracketed revision accepted 720/720, gaining 296 over baseline and 39 over first repair with no lost prior pass. One seed-collision control must also be disclosed (T037).

Still unknown: Finite, partly shared synthetic populations do not prove universal convergence; bracket is floating-point, not interval certified.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-FINAL, J3-STUDY, J3-TARGET, J3-BASELINE, J3-HYBRID, J3-BRACKETED (identities and logical paths in `records.json`).

### T036 — Wrong zero-gradient flat starts were mistaken for useful stopping points

**Classification:** failed_target. **Date:** 2026-09-20 — Pass-03 supplemental study.

Unperturbed circuit fitting began at basis-state flat starts.

Evidence: Only 8/64 passed; 56 stopped at zero iterations in wrong states.

Correction or successor: Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.

Outcome: The original 56 misses and corrected finite population are retained.

Still unknown: This does not establish escape from every stationary point or universal optimizer success.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-SUPPLEMENT, J3-FINAL, J3-CONDITIONED (identities and logical paths in `records.json`).

### T037 — A reused seed made one supposed test already solved

**Classification:** confirmed_defect. **Date:** 2026-09-20 — Final initialization review within pass 03.

Matrix-family and optimizer seed reuse made one synthetic initial state nearly identical to the target.

Evidence: Initial fidelity was 0.9999999999999993 and parameter maximum difference 4.440892098500626e-16. It supplied an already-solved control, not independent difficulty.

Correction or successor: Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.

Outcome: A separate confirmation began at fidelity 0.09613601511106884 and reached approximately one in 47 iterations. The improvement counts of 296 and 39 remain unchanged.

Still unknown: The new confirmation does not retroactively make the original case independent.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-INITIALIZATION, J3-CONFIRMATION, J3-INITIALIZATION-CODE, J3-FINAL (identities and logical paths in `records.json`).

### T038 — Centering cannot recover input information already rounded away

**Classification:** unresolved_or_limited. **Date:** 2026-09-20 — Pass-03 affine diagnostic.

Affine scale/offset transformations were tested before and after conditioning.

Evidence: Conditioned targets passed all 45 represented-matrix cases, but three inputs had already lost information. One intended-state fidelity remained about 0.26515785 even though represented-reference fidelity was approximately one.

Correction or successor: The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.

Outcome: All 45 represented-matrix results and the three input-representation limits remain.

Still unknown: Recovering the intended input would require additional precision or original information, not another claim of pass.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-AFFINE, J3-FINAL, J3-CONDITIONED (identities and logical paths in `records.json`).

### T039 — Hybrid target computation limits discovery and quantum-advantage claims

**Classification:** unresolved_or_limited. **Date:** 2026-09-20 — Passes03/04 source and reports.

The hybrid first calculates a target conventionally, then fits the Q8 circuit.

Evidence: Source groundTarget and target-projector fitting provide a classical answer construction inside the pipeline. No external answer file is not the same as no classical target.

Correction or successor: Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.

Outcome: This is an actual algorithmic limitation, not evidence that an unassisted-discovery claim was ever independently verified.

Still unknown: No physical QPU, quantum advantage or universal discovery follows from these software comparisons.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-HYBRID, J3-BRACKETED, J3-FINAL, J4-FAST, J4-HANDOFF, VQD-REPORT (identities and logical paths in `records.json`).

### T040 — One-second ledger acquisition failed under concurrent readers/writers

**Classification:** confirmed_defect. **Date:** 2026-09-20T17:02:14.084Z — Exact failed concurrency-test receipt UTC.

Mirrored evidence readers/writers shared a one-second lock wait.

Evidence: Test returned LEDGER_BUSY_OR_STALE_LOCK_REQUIRES_INSPECTION; no success was issued.

Correction or successor: Fair queued access with a bounded 30-second acquisition deadline replaced the insufficient wait; later V3 results are retained.

Outcome: Failure and correction remain separate evidence objects.

Still unknown: Local locks do not establish hardware write-once storage or universal concurrency safety.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-CONCURRENCY-FAIL, J3-CONCURRENCY-PASS (identities and logical paths in `records.json`).

### T041 — Checkpoint completion was incorrectly treated as completing ongoing work

**Classification:** confirmed_defect. **Date:** 2026-09-20 — Pass-03 failure-correction specification; original work segment approximate.

The assistant treated queued_jobs_finished and checkpoint_saved as sufficient for completion and substituted files/short handoff for explanation.

Evidence: The correction specification explicitly withdraws that implication and says local code cannot observe actual chat delivery.

Correction or successor: Completion control separates goals, evidence, interruptions, actual observations and prepared explanation. Three hours was an assistant-selected interpretation, not an exact owner quote.

Outcome: Local control tests are preserved as local workflow evidence, not a guarantee of all future assistant behavior.

Still unknown: Controller uptime does not equal productive work and a prepared report is not proof of chat delivery.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J3-COMPLETION, J3-FINAL (identities and logical paths in `records.json`).

### T042 — Stage-04 energy-only baseline missed 18 runs and direct solving remained cheaper

**Classification:** failed_target. **Date:** 2026-09-20 — Recorded timing populations, final report day.

Five methods were timed on 24 unique cases, with three repetitions each: 72 runs per method.

Evidence: Energy-only accepted 54/72. Old and fast hybrid accepted 72/72, but direct mean solver time of 22.815 ms was cheaper than the fast hybrid mean of 111.487 ms; direct complete requests also beat circuit mode.

Correction or successor: Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.

Outcome: No blanket Q8 speedup over the strongest conventional solver is supported.

Still unknown: The solver and complete-request populations/timing boundaries differ.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J4-PERFORMANCE, J4-REQUESTS, J4-HANDOFF (identities and logical paths in `records.json`).

### T043 — Stage-04 profiling and audit failures remained part of the engineering record

**Classification:** confirmed_defect. **Date:** 2026-09-20 — Distinct receipts at 21:58:01.675, 22:01:20.531, 22:01:55.600 and 22:38:06.676 UTC.

Early profiling attempted fsync under the permission model; another attempt expected a missing CPU-profile file. Adjoint validation hit Resume required; first final audit had a worker failure.

Evidence: Exact failure receipts remain. The missing trace followed a successful numerical worker and is not a failed numerical answer.

Correction or successor: Durable writes moved to the supervisor, unsupported trace capture gave way to stage timing, resume/permission-boundary recording was corrected and later audit passed.

Outcome: No failed attempt is erased. Aggregate successful-job counts are not summed with these receipt identities as unique numerical studies.

Still unknown: Final-audit generic error alone does not establish a numerical cause; source readback and later successful audit supply the limited closure.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J4-PROFILE-FAIL, J4-TRACE-FAIL, J4-TRACE-EXPLANATION, J4-RESUME-FAIL, J4-AUDIT-FAIL, J4-AUDIT-PASS, J4-HANDOFF (identities and logical paths in `records.json`).

### T044 — Stage 05 target-free protocol was prepared but not executed

**Classification:** not_executed. **Date:** 2026-09-21T01:05:22.513Z — Exact owner-security-redirection receipt UTC.

The protocol proposed independent starts and a holdout, target-free solver variants and explicit fidelity/energy acceptance.

Evidence: The redirection receipt says PAUSED_BEFORE_NEW_SOLVER_EXECUTION and new_numerical_jobs: 0.

Correction or successor: Numerical work was set aside for the owner-requested security priority; sources/protocol preserved.

Outcome: The planned 72 trials per method and 24 holdout matrices are not credited as observed data.

Still unknown: A later VQD assessment is a separately versioned study, not proof this protocol ran.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: J5-PROTOCOL, J5-PAUSE (identities and logical paths in `records.json`).

### T045 — VQD staging adapter failed before numerical work

**Classification:** confirmed_defect. **Date:** 2026-09-28 — Eastern date in setup-attempts receipt.

The first adapter recursively linked cached VM modules.

Evidence: Node raised ERR_VM_MODULE_LINK_FAILURE before a numerical pilot or run output folder.

Correction or successor: Nine reviewed modules are instantiated first; Node links the fixed allowlisted root graph once.

Outcome: Pilot, classical control and full 192-value VQD run later completed. The original adapter version and corrected adapter are preserved.

Still unknown: Module loading failure is not a failed scientific prediction.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: VQD-SETUP, VQD-ORIGINAL-ADAPTER, VQD-ADAPTER (identities and logical paths in `records.json`).

### T046 — First VQD scorer needed explicit schema and count hardening

**Classification:** unresolved_or_limited. **Date:** 2026-09-28 — Later audit after initial scores; exact first edit time not supplied.

The first scoring route did not carry the later explicit material, units, mode and receipt-count checks.

Evidence: Setup-attempts receipt records the added validation; scoring arithmetic remained unchanged.

Correction or successor: The hardened scorer rejects 11 malformed cases and reproduces the saved score arithmetic.

Outcome: The first produced scores are retained, not replaced with revised predictions. This is validation hardening, not proof original numeric scores were wrong.

Still unknown: Exact earliest scorer body is not separately identified in this selection.

Preservation: Initial scores, final scorer and hardening account retained; a separate exact pre-hardening scorer body is not identified.

Sources: VQD-SETUP, VQD-SCORER, VQD-VERIFICATION, VQD-REPORT (identities and logical paths in `records.json`).

### T047 — Low original-path VQD average error concealed unconverged states

**Classification:** unresolved_or_limited. **Date:** 2026-09-28 — Approximately 21:20 Eastern assessment.

One full run fitted 192 states from 384 starts on 24 ordered aluminum path points.

Evidence: MAE 3.4501989767139057e-6 eV passed the local goal, but maximum error 0.0002424081433360925 eV and largest residual 0.005244191334342701 eV remained. Of 384 starts, 197 reached gradient tolerance and 187 hit the iteration limit. Two points contributed 94.93% of total absolute error.

Correction or successor: Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.

Outcome: The conventional solver remained both faster (0.911 s versus 20.582 s) and more accurate. No matched timing comparison against the public Qiskit implementation ran.

Still unknown: Wavefunction convergence, new materials, physical advantage and commercial value are not established.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: VQD-REPORT, VQD-ADAPTER (identities and logical paths in `records.json`).

### T048 — Additional aluminum cases retained substantial iteration-budget stops

**Classification:** unresolved_or_limited. **Date:** 2026-09-28 — Approximately 21:28 Eastern separate assessment.

The unchanged VQD method predicted 192 energies at 24 additional same-material points.

Evidence: MAE 1.2888900558943352e-6 eV and maximum error 4.240288216550425e-5 eV passed local goals, but largest residual 0.009607193267454683 eV remained. Of 384 starts, 145 met gradient tolerance and 239 hit the iteration budget.

Correction or successor: Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.

Outcome: Useful bounded additional evidence, not an all-convergence success or a new-material test.

Still unknown: No generalization beyond aluminum or universal convergence is measured.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: VQD-REPORT, VQD-ADAPTER (identities and logical paths in `records.json`).

### T049 — First allocation rewrite saved memory but increased time 52.1%

**Classification:** failed_target. **Date:** 2026-09-29T02:12:31.070Z — Exact benchmark receipt UTC; September28Eastern.

Typed-array compact BFGS attempted to reduce resource cost for the same 192-energy workload.

Evidence: The old/new/new/old batch had medians of 17,591.91365 ms for baseline and 26,757.5566 ms for candidate: 52.1014548636% slower. CPU time increased 43.0189%; maximum observed process RSS decreased 40.6022%. All 192 energies and parameters matched.

Correction or successor: The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.

Outcome: This is a completed unfavorable performance comparison, not an incorrect numerical answer.

Still unknown: Two runs per version on one laptop are bounded observations; no total-system memory or electrical-energy claim.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-V1, PERF-CODE-V1, PERF-REPORT (identities and logical paths in `records.json`).

### T050 — Flat-array v2 probe remained slower

**Classification:** failed_target. **Date:** 2026-09-29T02:14:07.020Z — Exact focused-probe receipt UTC.

A flat-array variant tested whether allocation organization improved the same optimizer work.

Evidence: Four focused rounds preserved iteration counts and identical output; the baseline/candidate speed ratio of 0.806597963663965 is below one.

Correction or successor: Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.

Outcome: The two baseline observations, 281.2636 and 229.6612 ms, and candidate observations, 332.5347 and 300.8971 ms, remain explicit.

Still unknown: This focused probe is not the full24-point benchmark and is not an independent material study.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-V2, PERF-CODE-V2, PERF-REPORT (identities and logical paths in `records.json`).

### T051 — Row-array v3 probe also remained slower

**Classification:** failed_target. **Date:** 2026-09-29T02:15:42.196Z — Exact focused-probe receipt UTC.

A row-array variant attempted another BFGS allocation layout.

Evidence: Baseline observations were 284.7159 and 234.2065 ms versus candidate 389.8639 and 402.8986 ms; the reported ratio 0.6545748569085952 is below one. Outputs and iteration counts were identical.

Correction or successor: The variant was retained but not selected; cached trigonometry and compact history became v4.

Outcome: The unfavorable result remains with actual source and receipt.

Still unknown: A focused kernel probe is not full-workload timing.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-V3, PERF-CODE-V3, PERF-REPORT (identities and logical paths in `records.json`).

### T052 — Selected performance v4 improved time but missed the 20% target

**Classification:** failed_target. **Date:** 2026-09-29 — Exact UTC is in benchmark-results-v4.json; local September 28.

The selected angle-cache and compact-history implementation targeted at least 20% less calculation time.

Evidence: The four-process old/new/new/old batch decreased median time from 17.8700468 s to 14.8067205 s, a 17.14223994% reduction; target_passed is false. All 192 energies and parameters were identical.

Correction or successor: The selected code retained the measured gain honestly; a later batch checked it again.

Outcome: Useful improvement and a failed target are both true; neither erases the other.

Still unknown: This is not a guaranteed fixed percentage; startup is excluded.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-V4, PERF-CODE-V4, PERF-CACHED, PERF-REPORT (identities and logical paths in `records.json`).

### T053 — Audit repeat also missed the 20% target

**Classification:** failed_target. **Date:** 2026-09-29 — UTC receipt; local September 28 late evening.

A second four-process batch repeated the accepted comparison.

Evidence: Median time decreased from 18.52155325 s to 16.04999345 s, a 13.34423613% reduction; target_passed is false with identical 192 energies and parameters.

Correction or successor: The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.

Outcome: The second miss is retained separately from the first; neither becomes numerous independent studies.

Still unknown: Small live-laptop sample; no causal Windows-wide effect.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-AUDIT, PERF-REPORT (identities and logical paths in `records.json`).

### T054 — Performance README installation-pending prose was superseded by a later limited receipt

**Classification:** retracted_claim. **Date:** 2026-09-29T04:23:04.767Z — Installation receipt UTC; older guide remains historical.

The earlier README said installation had not been performed and described an installer that would verify a fresh calculation.

Evidence: The later receipt says INSTALLED_BYTE_VERIFIED_CALCULATION_DEFERRED, 16 payload files, calculation_started: false and installed_runtime_tested: false.

Correction or successor: Use the later installed-byte state while retaining the deferred calculation and runtime check; do not repeat older pending prose as current.

Outcome: The original guide and later receipt remain separate preserved artifacts.

Still unknown: No current USB check or post-install scientific run is established.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-REPORT, PERF-INSTALL (identities and logical paths in `records.json`).

### T055 — Structured 60-qubit labels require branch, bond and verification limits

**Classification:** unresolved_or_limited. **Date:** Unresolved — Implementation date unresolved; retained later Q8 snapshot and current static review.

The SOP/MPS bridge represents selected product and GHZ states up to 60 indexed qubits.

Evidence: SOP caps branches at 64 and throws before overflow. The bridge MPS bond cap is 32, with a local QR omission threshold of 1e-13. Verification uses three selected amplitude witnesses plus norm, not all 2^60 amplitudes.

Correction or successor: The later review states compact representation limits and separates the dense 21-qubit trial results.

Outcome: These are implementation boundaries, not proof that 60 physical qubits or arbitrary dense 60-qubit states were executed.

Still unknown: Full historical benchmark-to-version linkage remains limited; the local QR threshold is not a global error certificate.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: SOP, MPS, BRIDGE, Q8-CLAIMS (identities and logical paths in `records.json`).

### T056 — Windows observation changes cannot be promoted to causal USB speedup

**Classification:** unresolved_or_limited. **Date:** 2026-09-29 — Three original UTC observation windows; documentary review October 16.

Three windows recorded Windows resource counters and then checked the USB package.

Evidence: 990 readings (3 × 11 × 30) yield 33 means. In all three windows, the last counter precedes USB verification. Checks took 12.5676291, 1.620652 and 9.3315077 seconds against 40 declared files.

Correction or successor: The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.

Outcome: Observed resource changes are preserved; no controlled Windows-wide causal estimate is inferred.

Still unknown: Background activity, cache effects and storage-placement causality were not isolated. No new measurements.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: Q8-CLAIMS, Q8-COUNTERS (identities and logical paths in `records.json`).

### T057 — Saved-result retrieval is not a hundreds-fold fresh-computation gain

**Classification:** unresolved_or_limited. **Date:** 2026-09-29 — Later performance operation receipts/report cycle.

The launcher reused an unchanged verified result in 0.062 seconds after entry-point startup, versus 16.804 seconds for the preceding fresh calculation.

Evidence: This operation returned previous answers. Six invalid, stale, corrupt or incomplete cache cases were rejected, but the cache performs unsigned consistency checks.

Correction or successor: The report explicitly separates retrieval from fresh computation and from owner-authenticated security.

Outcome: Useful cache behavior is retained without inflating fresh-calculation speed.

Still unknown: No adversarial authenticity guarantee or universal cache correctness follows from six negative cases.

Preservation: Listed original/report/receipt bytes are preserved privately. Historical events were not rerun.

Sources: PERF-REPORT, PERF-CACHE, Q8-CLAIMS (identities and logical paths in `records.json`).

## Coverage and handling

All substantive negative, corrected, superseded and limited versions identified in the bounded technical source review listed here. Repeated cases of one mechanism are grouped; this is not a claim to exhaust every event in the unavailable original history or every object of the private archive.

Task Alpha exact-GHZ reference was reviewed in the existing consolidation and no substantive failed scientific version is newly located in that selected source group; fixed synthetic admission/oracle scope remains a limitation, not an invented failed experiment. Earlier March conceptual/syntax history and the broader 55-class operational ledger belong to the chronological/operational addenda, not an asserted exhaustive numerical incident census here.

No failed source body is reconstructed from a prose description and then called original. Some early transient builder/harness revisions survive only as correction receipts; the entries say so. The three-qubit original is one byte unresolved. All selected complete bodies and saved records that do exist are bound to hashes. Private device/account locators are kept only in the separate private map.

This addendum is prepared for owner review. It is not uploaded and does not overwrite the existing publication series, quantum collection or Q8 review.
