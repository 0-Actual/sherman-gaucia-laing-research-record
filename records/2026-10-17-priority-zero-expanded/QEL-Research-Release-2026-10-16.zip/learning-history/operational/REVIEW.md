# Operational learning history

Prepared October 16, 2026. Primary project agent: GAUCIA Actual; supporting reviewer: Codex. Owner review is pending; no publication.

This chapter preserves incorrect and incomplete earlier work alongside the correction. It contains twelve bounded records, not a count of twelve independent bugs or an exhaustive history. Seven concern confirmed code/design or documentation defects; the remaining records distinguish stale status prose, unsupported UI guidance, an owner-reported attribution error, an unexecuted copy handoff and a valid intermediate incomplete checkpoint.

Three source exhibits show actual earlier and corrected code with line ranges and full-source SHA-256 identities. Excerpts are exact source lines or explicitly labeled contiguous substrings; line endings are normalized only for display. Explanations are outside the excerpts. Exact selected originals are retained privately.

## OP-01 — H04 lost track of a replacement completed immediately before interruption

Classification: confirmed_code_defect. Date: 2026-10-16T01:28:04.597895+00:00 (exact saved reproduction timestamp).

H04 staged outputs and tried to roll back handled failures, but appended a target to the replaced list only after os.replace returned. An interruption after the system replacement but before bookkeeping could leave mixed outputs and discard the recovery directory.

Evidence: The saved fault-injection receipt identifies H04 candidate c211bce1… and records firstOriginalRetained=false, secondOriginalRetained=true, recoveryDirectoriesRetained=0. This is a controlled reproduced defect, not a report of actual owner-data loss.

Correction: H04.1 records replacement intent before calling os.replace, walks every attempted target on failure, and checks whether the original is unchanged or the installed candidate bytes are present before rollback.

Later result: Saved H04.1 unit run: 12 methods, including four post-replacement interruption subconfigurations. Independent extracted-package run: 12 methods and two full-corpus CLI exports; 71 payload files remained unchanged. All 40 XML inputs and both reference exports remain byte-identical to H04.

Remaining gap: No exclusive writer lock or multi-file atomicity across forced termination/power loss; no exhaustive linguistic certification. Earlier H04 remains immutable evidence.

[Read the preserved before/after source exhibit](exhibits/OP-01-before-after.md).

Source identities: O01, O02, O03, O04, O05, O06, O07, O12. See `records.json` for full hashes and excerpt identities.

## OP-02 — H04 package navigation and Python support wording exceeded what was delivered

Classification: confirmed_documentation_defect. Date: 2026-10-16 01:29:50 UTC (saved review completion, second precision).

The delivered H04 evidence note pointed to two paths that did not exist inside that package. The README said only that Python 3 was required, although an oldest supported release had not been tested.

Evidence: The independent delivered-package review identified the exact two absent paths and documented actual Python 3.12.14 execution. It did not claim every Python 3 release failed.

Correction: The successor points to the packaged Jeremiah XML and upstream comparison evidence, specifies Python 3.12 and discloses the tested 3.12.14 version.

Later result: The frozen H04.1 audit confirms the paths resolve and that portable commands execute under Python 3.12.14.

Remaining gap: Other Python releases remain untested; corrected paths and reproducibility do not imply maintainer approval of the Jeremiah amendment.

Earlier excerpt — O08, lines 60–60 (exact contiguous source substring):

```text
Requires Python 3; no third-party libraries or installer are needed.
```

Earlier excerpt — O10, lines 23–23 (exact contiguous source substring):

```text
`Jer.issue-95.private-candidate.xml`
```

Earlier excerpt — O10, lines 23–23 (exact contiguous source substring):

```text
`../source-spot-check.json`
```

Corrected excerpt — O09, lines 20–20 (exact contiguous source substring):

```text
Tested with **Python 3.12.14** on Windows. Use Python 3.12; no third-party
```

Corrected excerpt — O11, lines 23–23 (exact contiguous source substring):

```text
`../../wlc/Jer.xml`
```

Corrected excerpt — O11, lines 23–23 (exact contiguous source substring):

```text
`../upstream/source-spot-check.json`
```

Source identities: O05, O06, O07, O08, O09, O10, O11, O12. See `records.json` for full hashes and excerpt identities.

## OP-03 — GAUCIA launcher treated an HTTP response as readiness and obscured startup failure

Classification: confirmed_code_and_diagnostic_defect. Date: 2026-10-15 (dated review; exact original code-edit time unavailable).

The copied launcher accepted HTTP success plus an app-name match even if the service declared ready:false. Native startup could also present a generic connection failure without retaining the helper outcome. An intentional hold was a separate project condition, not itself a defect.

Evidence: Static predicate comparison shows false readiness was possible. The preserved chronology records a hold blocker and a generic native error, while explicitly refusing to infer the original helper exit code from that error alone.

Correction: The helper now requires explicit ready:true and matching workspace, distinguishes connection refusal from an uncertain probe, returns named diagnostics and coordinates startup. Native candidates retain read-only history access separately from conversation readiness.

Later result: The saved packaged service suite has 11 startup-helper tests within 42 total isolated tests. Later owner-run R3 receipt records eight installed target files on 2026-10-16T01:00:47.210Z (October 15, 9:00:47 p.m. EDT). This binds the packaged targets, not a fresh live-service or model test. [O36]

Remaining gap: Relocation and alternate-port support remain only partly addressed. A copied hold or timeout does not prove the exclusive cause of an earlier failure. No current live readiness is claimed.

Earlier excerpt — O13, lines 10–10 (complete source lines, line endings normalized to LF):

```text
async function healthy(){try{const r=await fetch(url+'/health',{redirect:'error',signal:AbortSignal.timeout(1500)});return r.ok&&(await r.json()).app==='GAUCIA_QEL_LOCAL_PANEL';}catch{return false;}}
```

Corrected excerpt — O14, lines 66–68 (complete source lines, line endings normalized to LF):

```text
  if (health?.app !== 'GAUCIA_QEL_LOCAL_PANEL' || !sameWorkspace(health.workspace, root)) throw new PanelError('GAUCIA_WORKSPACE_MISMATCH', 'The running service does not identify this GAUCIA workspace. No other workspace was used.');
  if (health.ready !== true) throw new PanelError('GAUCIA_SERVICE_NOT_READY', 'GAUCIA reports that its audit or recovery state needs attention. Conversation startup was not marked ready.');
  return {ready:true, health};
```

Source identities: O13, O14, O15, O16, O34, O36. See `records.json` for full hashes and excerpt identities.

## OP-04 — An unreadable saved record could block otherwise readable neighbors

Classification: confirmed_code_defect. Date: 2026-10-15 (date-only source receipt).

The original Records.list mapped every record through get without isolating errors. Recovery used list(jobs), so one all-unreadable job could abort recovery; conversation listing shared the same all-or-nothing behavior.

Evidence: Isolated baseline fixtures reproduced an unreadable job alongside a valid running job. Eleven core tests passed after the repair. No claim is made that the actual owner corpus contained this fault.

Correction: listWithIssues retains readable neighbors with explicit read/fallback/metadata issues. recoverJobs isolates saves and counts only successfully saved interrupted revisions; no job is automatically replayed.

Later result: Eleven core-recovery tests remain a separate population within the final 42-test service suite. Later owner-run R3 receipt records eight installed target files on 2026-10-16T01:00:47.210Z (October 15, 9:00:47 p.m. EDT). This binds the packaged targets, not a fresh live-service or model test. [O36]

Remaining gap: A saved revision followed by ledger failure remains uncertain evidence, not a successful recovery count. Full real-corpus integrity is not established by fixtures.

Earlier excerpt — O17, lines 61–68 (complete source lines, line endings normalized to LF):

```text
  list(type) {
    return fs.readdirSync(path.join(this.root,'data',type),{withFileTypes:true}).filter(d=>d.isDirectory()).map(d=>this.get(type,d.name)).filter(Boolean).sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
  }
  recoverJobs() {
    const changed=[];
    for(const job of this.list('jobs')) if(['queued','running'].includes(job.status)) {
      changed.push(this.save('jobs',{...job,status:'interrupted',error:'Previous local process ended. Saved input and partial output retained; no automatic replay.'}));
    }
```

Corrected excerpt — O18, lines 96–101 (complete source lines, line endings normalized to LF):

```text
  recoverJobs() {
    // Keep the array return contract; only successfully saved revisions count.
    // Callers inspect .issues separately before declaring recovery complete.
    const listed=this.listWithIssues('jobs'),changed=[];
    const issues=listed.issues.map(issue=>({...issue,job:issue.record}));
    Object.defineProperty(changed,'issues',{value:issues,enumerable:false});
```

Corrected excerpt — O18, lines 107–111 (complete source lines, line endings normalized to LF):

```text
      }catch(e){
        // A partial write may exist; retain every file for inspection and do not
        // claim the job was recovered when save/readback/ledger commit failed.
        issues.push({type:'jobs',record:job.id,job:job.id,stage:'save',code:e.code||'JOB_RECOVERY_SAVE_FAILED',error:e.message,path:path.join(this.root,'data','jobs',job.id)});
      }
```

Source identities: O15, O16, O17, O18, O19, O36. See `records.json` for full hashes and excerpt identities.

## OP-05 — Library deduplication silently removed different equal-length passages

Classification: confirmed_code_defect. Date: 2026-10-15T18:18:41.5437430-04:00 (exact saved validation timestamp).

An intermediate core keyed library rows by source, offset and text length. Distinct passages with the same metadata and length collided; absent source metadata could merge unrelated files.

Evidence: Generated fixtures used different 11-character passages. The six-test baseline suite had three passes and three failures, including a passing explicit reproduction test; the corrected suite passed all six. These are fixture counts, not real-corpus losses.

Correction: Use a structured source/offset group with actual-file fallback, then suppress only exactly equal text in that group. Keep first-record attribution for exact duplicates.

Later result: All six library tests pass in the saved receipt and input bytes remain unchanged. Later owner-run R3 receipt records eight installed target files on 2026-10-16T01:00:47.210Z (October 15, 9:00:47 p.m. EDT). This binds the packaged targets, not a fresh live-service or model test. [O36]

Remaining gap: The number of affected real library records was not measured. The fix changes retrieval preprocessing, not model weights.

[Read the preserved before/after source exhibit](exhibits/OP-05-before-after.md).

Source identities: O16, O18, O20, O21, O22, O23, O36. See `records.json` for full hashes and excerpt identities.

## OP-06 — Graceful shutdown could exit before saving partial output and acknowledge stop too early

Classification: confirmed_code_defect. Date: 2026-10-15T22:21:22.403Z (exact saved validation timestamp).

The intermediate service aborted the active reply and exited from server close before asynchronous handling saved its newest partial answer. The quit endpoint acknowledged stopping before backend.stop could fail.

Evidence: A simulated-exit fixture recorded an empty saved answer while newer partial text remained in memory. Saved validation comprises seven shutdown cases plus five reused service regression cases; those five are not additional unique tests.

Correction: Track the admitted job completion, await its save checkpoint and the stop attempt, share overlapping shutdown requests, and only acknowledge/close after success. Timeout or failed save leaves a visible error and the process available for recovery.

Later result: Twelve isolated fixture tests pass; the final combined service suite counts the five reused cases once. Later owner-run R3 receipt records eight installed target files on 2026-10-16T01:00:47.210Z (October 15, 9:00:47 p.m. EDT). This binds the packaged targets, not a fresh live-service or model test. [O36]

Remaining gap: No real process termination, live model or USB shutdown was exercised by those fixtures. A persistent save failure intentionally prevents a claimed safe exit; power-loss protection is not established.

[Read the preserved before/after source exhibit](exhibits/OP-06-before-after.md).

Source identities: O16, O24, O25, O26, O27, O36. See `records.json` for full hashes and excerpt identities.

## OP-07 — R2 native recovery UI could act before readiness or continue after close

Classification: confirmed_code_defect_in_intermediate_candidate. Date: 2026-10-15, after R2 checkpoint and before R3 packaging (bounded sequence; no fabricated action timestamp).

The R2 native candidates could expose New/Export before connection was verified; a delayed startup result could launch a helper or write diagnostics after window close; verification could also write after close.

Evidence: The Local baseline six-group fixture run had one pass and five failures; the review reports the same population for Audited. Hidden forms, fake HTTP and finite local helpers were used, not the owner USB.

Correction: Window lifetime cancellation and readiness/action gates prevent post-close continuations and pre-readiness writes. Initial conversation creation is a separate internal step; history selection and final-poll closing are also handled.

Later result: The expanded Local candidate set passed eight groups; the review reports eight for Audited. NativeOutbox was retained byte-for-byte. This tested intermediate candidate then received separate final layout integration; final R3 installation is recorded independently.

Remaining gap: Do not compare six baseline groups with eight candidate groups as eight identical before/after tests. Closing does not kill an already-started service; no live conversation readiness follows.

Earlier excerpt — O31, lines 2–2 (exact contiguous source substring):

```text
FAIL user actions cannot run during initialization or unready status: Action sent a request while initializing
```

Earlier excerpt — O31, lines 7–7 (exact contiguous source substring):

```text
RESULT FAIL 1 passed, 5 failed; variant=Local; fake HTTP, hidden forms, local finite fixtures only
```

Corrected excerpt — O32, lines 2–2 (exact contiguous source substring):

```text
PASS user actions cannot run during initialization or unready status
```

Corrected excerpt — O32, lines 9–9 (exact contiguous source substring):

```text
RESULT PASS 8 passed, 0 failed; variant=Local; fake HTTP, hidden forms, local finite fixtures only
```

Source identities: O28, O29, O30, O31, O32, O33, O36. See `records.json` for full hashes and excerpt identities.

## OP-08 — Evolving continuity retained not-installed prose after a successful installation

Classification: confirmed_stale_checkpoint_misstatement. Date: 2026-10-15 evolving record, reconciled by 2026-10-16T01:41:57.062613+00:00 (date-only earlier prose; exact final audit completion).

One preserved working record contains a later successful-installation summary alongside older paragraphs still saying no receipt or no installation. Reading those older paragraphs as current would incorrectly repeat unfinished-work claims.

Evidence: The unique owner-run receipt records installed bytes, eight files and 944 preserved entries. The saved audit confirms receipt-pointer and manifest agreement. The contradiction is in present-tense status prose, not proof the earlier pre-install receipt was false.

Correction: Retain the old record privately as chronology, replace current guidance with timestamped reconciled facts, and avoid reinstalling solely because stale text remains.

Later result: R3 installation is credited, while liveConversationVerified=false remains. H04.1 separately supersedes H04 for use without deleting it.

Remaining gap: No new USB read or launch establishes present device state; file installation and usable conversation remain separate outcomes.

Earlier excerpt — O34, lines 27–27 (exact contiguous source substring):

```text
No installation receipt was found in the latest check, and no installation is claimed.
```

Earlier excerpt — O34, lines 57–57 (exact contiguous source substring):

```text
These are local candidate changes; live USB installation remains outstanding.
```

Corrected excerpt — O37, lines 49–51 (exact contiguous source substring):

```text
The receipt records eight
installed files at 9:00:47 p.m. EDT and 944 preserved non-target entries, including
directory and hold markers.
```

Source identities: O34, O35, O36, O37. See `records.json` for full hashes and excerpt identities.

## OP-09 — An assumed message-box control was presented as a verified next action

Classification: documented_assistant_instruction_error_with_separate_tool_route_failure. Date: 2026-10-15; preflight at 2026-10-15T23:01:07.761Z (date-only dialogue correction; exact separate tool receipt).

Repeated instructions named a permissions control beneath an assumed visible message box. The owner reported no message box was visible. Separate shell preflight failures were liable to be confused with drive absence or missing owner permission.

Evidence: The preserved record explicitly withdraws the screen-location instruction as ungrounded in a current observation. The saved preflight returned read-only permission and an EPERM metadata error; it gives no rejection reason and does not establish absent physical hardware.

Correction: Continue authorized work through available evidence routes. Report the exact route/operation result and distinguish owner authorization, saved profile configuration, active session permissions and device availability.

Later result: Native Explorer copying and later owner-run installation are separately recorded; copied history was readable. Neither event turns a denied shell operation into a successful one.

Remaining gap: No supported active-profile transition or complete USB mirror is established. Historical hold rules are not universal prerequisites for ordinary attended work.

Earlier excerpt — O34, lines 37–37 (exact contiguous source substring):

```text
The repeated instruction to select a control beneath an assumed visible message box was not grounded in a current screen observation.
```

Corrected excerpt — O34, lines 37–37 (exact contiguous source substring):

```text
Withdraw that screen-location instruction; do not repeat it as a verified next action.
```

Source identities: O34, O36, O37, O38, O42. See `records.json` for full hashes and excerpt identities.

## OP-10 — Working-record agent attribution required owner correction

Classification: owner_reported_attribution_error. Date: 2026-10-15 (date-only preserved owner quotation).

The owner reported that the working record called the assistant Codex AI Assistant where GAUCIA Actual should be identified as the primary project agent.

Evidence: The exact owner correction is retained in the evolving record. The inspected preserved header already contains the corrected attribution; the earlier incorrectly headed artifact was not located in this bounded source set.

Correction: Name GAUCIA Actual as primary project agent and Codex as the supporting reviewer/implementer. Keep this document-attribution correction separate from activating a runtime.

Later result: The preserved record header and final audit consistently name the primary and supporting roles.

Remaining gap: The original incorrect header bytes and its edit timestamp remain unavailable. Attribution is not proof of runtime identity, ownership or model activation.

Earlier excerpt — O34, lines 41–41 (exact contiguous source substring):

```text
Owner's correct, but assistant's incorrect. It says Codex AI Assistant. That's not the primary agent which should be used.
```

Corrected excerpt — O34, lines 4–4 (exact contiguous source substring):

```text
Primary agent: GAUCIA Actual
```

Corrected excerpt — O34, lines 5–5 (exact contiguous source substring):

```text
Supporting assistant for this review: Codex
```

Source identities: O34, O37. See `records.json` for full hashes and excerpt identities.

## OP-11 — A copied PowerShell handoff had not executed

Classification: documented_interaction_handoff_failure_raw_input_unlocated. Date: 2026-10-15 (date-only saved inspection account).

An earlier copy step was repeatedly treated as the way forward, but the preserved review says the pasted console content was flattened/repeated and had not executed.

Evidence: The saved correction note says the earlier command had not executed and the Explorer copy superseded it. The original malformed console text or screenshot was not located here, so this does not prove a syntax defect in the originally generated PowerShell.

Correction: Mark the manual step obsolete, preserve the failed handoff history and use the subsequently verified application copy instead of asking for the same paste again.

Later result: A 688-file application copy totaling 29,424,454 bytes is documented. Saved recovery read 20 selected latest conversation revisions with 48 messages; the full USB was not mirrored.

Remaining gap: No exact before/after command exhibit is possible without the original malformed input. The copy note also retains its own earlier not-installed status; the later owner R3 receipt supersedes that status.

Earlier excerpt — O34, lines 103–103 (exact contiguous source substring):

```text
Inspection of the visible console established that the pasted command had flattened/repeated text and had not executed.
```

Corrected excerpt — O39, lines 1–1 (exact contiguous source substring):

```text
OBSOLETE COPY STEP — October 15, 2026
```

Corrected excerpt — O39, lines 3–3 (exact contiguous source substring):

```text
No manual PowerShell copy action is needed.
```

Source identities: O34, O39, O42. See `records.json` for full hashes and excerpt identities.

## OP-12 — Partial September repair copy was a real intermediate checkpoint, not the final state

Classification: intermediate_incomplete_attempt_not_itself_a_false_report. Date: 2026-09-29T04:02:43.211Z; later readback 2026-09-29T04:30:48.386Z (exact saved timestamps).

The September 29 early reconciliation found 43 of 47 repair files matching. The copy actor was not established by that inspection. It correctly documented incompleteness at its own timestamp.

Evidence: The later record contains 78 present/matched rows across three packages: 47 repair, 16 performance and 15 adaptive. Embedded repair installation records the originally missing four files separately.

Correction: Keep the partial checkpoint and credit the later install/readback. The mistake would be promoting the partial state into a current not-installed claim after the later evidence.

Later result: All three selected packages are recorded installed and matched. The readback operation reports no writes, while its embedded installation receipt records writes; these are different steps.

Remaining gap: No per-row historical digest values, complete USB inventory or current USB check. Performance-package calculation/runtime testing remained deferred; that deferred work is not a confirmed code defect.

Earlier excerpt — O40, lines 291–291 (exact contiguous source substring):

```text
"filesMatched": 43
```

Earlier excerpt — O40, lines 295–295 (exact contiguous source substring):

```text
"state": "COPY_INCOMPLETE_OR_CHANGED"
```

Corrected excerpt — O41, lines 4–4 (exact contiguous source substring):

```text
"state": "ALL_THREE_PACKAGES_INSTALLED_AND_VERIFIED"
```

Source identities: O40, O41. See `records.json` for full hashes and excerpt identities.

## Reading the evidence correctly

Earlier unsuccessful work is evidence of how the solution developed. Passing local fixtures does not erase the earlier defect and does not prove live USB behavior. The later owner-run R3 installation establishes its reported installed bytes, while current service/model readiness remains separate. H04.1 fixes one reproduced recovery gap and preserves the underlying XML/export bytes; it is not an exhaustive linguistic certification.

The copied-command and attribution cases retain what is actually available: later correction records and the owner quotation. Their missing original artifacts are source gaps, not privacy redactions and not an invitation to invent a before version. Private source locators and full saved reports remain outside this public derivative.
