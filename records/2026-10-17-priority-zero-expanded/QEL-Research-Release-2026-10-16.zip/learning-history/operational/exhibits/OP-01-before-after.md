# OP-01 — H04 lost track of a replacement completed immediately before interruption

Historical learning exhibit; owner review pending. Original source bytes remain privately preserved.

H04 staged outputs and tried to roll back handled failures, but appended a target to the replaced list only after os.replace returned. An interruption after the system replacement but before bookkeeping could leave mixed outputs and discard the recovery directory.

## Earlier produced source

Source O01: H04 converter, original failed version; lines 361–365.
Full-source SHA-256: `c211bce157ddae20b7d8f4d5079188aa0a3423b9cf116a5bb845f9b4b7cfb00e`.

```python
            for index, target in enumerate(targets):
                if not unchanged(target):
                    raise RuntimeError('Output changed before replacement: ' + target)
                os.replace(os.path.join(staging, str(index) + '.new'), target)
                replaced.append(target)
```

Source O01: H04 converter, original failed version; lines 370–370.
Full-source SHA-256: `c211bce157ddae20b7d8f4d5079188aa0a3423b9cf116a5bb845f9b4b7cfb00e`.

```python
            for target in reversed(replaced):
```

## Corrected produced source

Source O02: H04.1 converter, corrected version; lines 361–367.
Full-source SHA-256: `a2f997e05f806d209877c8400d0e4dcab62b621c4c2e5a7fe1c9149a7d4ec387`.

```python
            for index, target in enumerate(targets):
                if not unchanged(target):
                    raise RuntimeError('Output changed before replacement: ' + target)
                # Record intent first: an interrupt can arrive after the system
                # replaces the file but before the next Python instruction.
                attempted.append(target)
                os.replace(os.path.join(staging, str(index) + '.new'), target)
```

Source O02: H04.1 converter, corrected version; lines 372–376.
Full-source SHA-256: `a2f997e05f806d209877c8400d0e4dcab62b621c4c2e5a7fe1c9149a7d4ec387`.

```python
            for target in reversed(attempted):
                try:
                    # A replacement can fail before changing the destination.
                    if unchanged(target):
                        continue
```

## Evidence and correction

The saved fault-injection receipt identifies H04 candidate c211bce1… and records firstOriginalRetained=false, secondOriginalRetained=true, recoveryDirectoriesRetained=0. This is a controlled reproduced defect, not a report of actual owner-data loss.

H04.1 records replacement intent before calling os.replace, walks every attempted target on failure, and checks whether the original is unchanged or the installed candidate bytes are present before rollback.

Saved H04.1 unit run: 12 methods, including four post-replacement interruption subconfigurations. Independent extracted-package run: 12 methods and two full-corpus CLI exports; 71 payload files remained unchanged. All 40 XML inputs and both reference exports remain byte-identical to H04.

Remaining boundary: No exclusive writer lock or multi-file atomicity across forced termination/power loss; no exhaustive linguistic certification. Earlier H04 remains immutable evidence.

This exhibit reads saved evidence only. No source test or experiment was rerun.
