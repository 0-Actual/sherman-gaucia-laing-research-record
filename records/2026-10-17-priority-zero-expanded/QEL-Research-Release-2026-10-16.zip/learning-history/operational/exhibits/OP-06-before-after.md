# OP-06 — Graceful shutdown could exit before saving partial output and acknowledge stop too early

Historical learning exhibit; owner review pending. Original source bytes remain privately preserved.

The intermediate service aborted the active reply and exited from server close before asynchronous handling saved its newest partial answer. The quit endpoint acknowledged stopping before backend.stop could fail.

## Earlier produced source

Source O24: Intermediate communication candidate before shutdown repair; lines 170–170.
Full-source SHA-256: `4909e0bb321ac574c19682978643b2fffe79fe2aeafb05e19c8e4d437c400a76`.

```javascript
      send(res,200,{stopping:true});backend.stop();setTimeout(()=>server.close(()=>process.exit(0)),150);return;
```

Source O24: Intermediate communication candidate before shutdown repair; lines 231–231.
Full-source SHA-256: `4909e0bb321ac574c19682978643b2fffe79fe2aeafb05e19c8e4d437c400a76`.

```javascript
for(const event of ['SIGINT','SIGTERM'])process.on(event,()=>{if(active)active.controller.abort();backend.stop();server.close(()=>process.exit(0));});
```

## Corrected produced source

Source O25: Communication candidate after shutdown repair; lines 116–121.
Full-source SHA-256: `990b40c7635e165abc1d9114a7efa621bf88403f888535e8e25ccf72077049c2`.

```javascript
      const saved=await Promise.race([pending.finished.then(()=>true),new Promise(resolve=>{timer=setTimeout(()=>resolve(false),shutdownCheckpointMs);})]);
      clearTimeout(timer);
      if(!saved){
        const error='Shutdown paused: the active response has not finished its save checkpoint. The service remains open with new work blocked.';
        noteRecoveryIssues([{stage:'shutdown-checkpoint-timeout',job:pending.id,error}]);
        return {ok:false,error};
```

Source O25: Communication candidate after shutdown repair; lines 208–210.
Full-source SHA-256: `990b40c7635e165abc1d9114a7efa621bf88403f888535e8e25ccf72077049c2`.

```javascript
      const shutdown=await prepareShutdown();
      if(!shutdown.ok)return send(res,503,{stopping:false,shuttingDown:true,error:shutdown.error,auditWarning:cleanup.warning});
      send(res,200,{stopping:true,auditWarning:cleanup.warning});setTimeout(finishShutdown,150);return;
```

Source O25: Communication candidate after shutdown repair; lines 271–271.
Full-source SHA-256: `990b40c7635e165abc1d9114a7efa621bf88403f888535e8e25ccf72077049c2`.

```javascript
for(const event of ['SIGINT','SIGTERM'])process.on(event,()=>prepareShutdown().then(result=>{if(result.ok)finishShutdown();else console.error(result.error);}).catch(error=>{noteRecoveryIssues([{stage:'shutdown',error:error.message}]);console.error('Shutdown paused:',error.message);}));
```

## Evidence and correction

A simulated-exit fixture recorded an empty saved answer while newer partial text remained in memory. Saved validation comprises seven shutdown cases plus five reused service regression cases; those five are not additional unique tests.

Track the admitted job completion, await its save checkpoint and the stop attempt, share overlapping shutdown requests, and only acknowledge/close after success. Timeout or failed save leaves a visible error and the process available for recovery.

Twelve isolated fixture tests pass; the final combined service suite counts the five reused cases once. Later owner-run R3 receipt records eight installed target files on 2026-10-16T01:00:47.210Z (October 15, 9:00:47 p.m. EDT). This binds the packaged targets, not a fresh live-service or model test. [O36]

Remaining boundary: No real process termination, live model or USB shutdown was exercised by those fixtures. A persistent save failure intentionally prevents a claimed safe exit; power-loss protection is not established.

This exhibit reads saved evidence only. No source test or experiment was rerun.
