# OP-05 — Library deduplication silently removed different equal-length passages

Historical learning exhibit; owner review pending. Original source bytes remain privately preserved.

An intermediate core keyed library rows by source, offset and text length. Distinct passages with the same metadata and length collided; absent source metadata could merge unrelated files.

## Earlier produced source

Source O20: Intermediate library core before exact-text repair; lines 127–127.
Full-source SHA-256: `eadb4a45259c2c4c900850ec0d3232fc5c5310aeb430b232830311b9365f240c`.

```javascript
          try{const r=JSON.parse(line);if(typeof r.text!=='string')throw Error('Missing text');const key=[r.origin_path,r.chunk_start_utf16,r.text.length].join('|');if(seen.has(key))continue;seen.add(key);
```

## Corrected produced source

Source O21: Library core after exact-text repair; lines 128–132.
Full-source SHA-256: `f232ba6418eb875716c0f8aa256a24b482c8c6a6aa705e62299a455fc0f1eb99`.

```javascript
            // A source offset can have different saved text; only exact text is a duplicate.
            // Keep text references in each bucket instead of copying whole passages into keys.
            const key=JSON.stringify([r.origin_path||file,r.chunk_start_utf16??null]),texts=seen.get(key);
            if(texts?.has(r.text))continue;
            if(texts)texts.add(r.text);else seen.set(key,new Set([r.text]));
```

## Evidence and correction

Generated fixtures used different 11-character passages. The six-test baseline suite had three passes and three failures, including a passing explicit reproduction test; the corrected suite passed all six. These are fixture counts, not real-corpus losses.

Use a structured source/offset group with actual-file fallback, then suppress only exactly equal text in that group. Keep first-record attribution for exact duplicates.

All six library tests pass in the saved receipt and input bytes remain unchanged. Later owner-run R3 receipt records eight installed target files on 2026-10-16T01:00:47.210Z (October 15, 9:00:47 p.m. EDT). This binds the packaged targets, not a fresh live-service or model test. [O36]

Remaining boundary: The number of affected real library records was not measured. The fix changes retrieval preprocessing, not model weights.

This exhibit reads saved evidence only. No source test or experiment was rerun.
