# Q8 and the USB: the evidence we can put before a reader

Q8 and the USB are the center of this publication account. The most useful story
is the development of a portable research environment: what problem arose,
what was attempted, what the code changed, what actually ran, and what evidence
was saved afterward. The record contains real implementation work, numerical
comparisons, unsuccessful attempts, installation receipts and later corrections.
Those parts belong together.

The USB's role is substantial and specific. It stores the environment, runtime,
code, inputs and records. A saved September 29 receipt identifies a runtime and
working folder on the USB. That run verified fourteen package files and ten source
files, loaded four library records, returned three retrieval results and reproduced
twenty-two averages from six hundred and sixty previously saved readings. It
records no model launch, network call, background service or USB write during that
operation. This supports an actual bounded interaction with the installed
environment. It does not demonstrate a ready conversational service today.

The numerical processing happens in software using the laptop's processor and
memory. Q8 includes concrete algorithms. The reviewed material-study code builds
small complex Hamiltonian matrices, evaluates a three-qubit circuit, calculates
energies and residuals, and optimizes eighteen circuit angles. One improvement
uses an adjoint derivative method to avoid repeated derivative work. Another
validates and reuses a packed input representation. A later calculation revision
caches trigonometric values and avoids retaining unused optimizer history.
These are identifiable changes that a technical reader can inspect.

One recorded comparison found that the faster hybrid used about one sixty-sixth
of the older hybrid's aggregate solver time. The precise ratio was approximately
sixty-five point eight five. That comparison covered twenty-four cases, with three
repetitions per method. A separate complete-request comparison showed approximately
four point six nine times the speed of the older mode. We must keep those results
separate because they use different populations and measure different portions of
the work. A conventional direct solver remained faster when circuit parameters
were unnecessary. The faster hybrid itself computes a conventional target before
fitting its circuit, which also belongs in the explanation.

Later revisions improved their own calculation batches by about seventeen point
one percent and thirteen point three percent. Both fell short of the stated
twenty-percent time target. An earlier rewrite saved memory but increased time,
and intermediate attempts were slower. Preserving these results shows how the
solution developed and lets readers judge the final change against the actual
alternatives. It also prevents combining separate gains into a performance claim
that no single experiment measured.

The capacity results need the same care. Dense simulations completed trials
through twenty-one qubits in the recorded workloads. A proposed twenty-two-qubit
trial was not admitted because the required memory reserve was unavailable;
it was not a failed numerical trial. Separate structured representations handle
selected states and circuits with up to sixty indexed qubits while imposing
branch, bond and numerical limits. That is a different capability from storing
and checking every amplitude of an arbitrary sixty-qubit state.

The installation history also has concrete completion points. The September 29
readback records seventy-eight matching payload files: forty-seven repair files,
sixteen performance files and fifteen adaptive files. Older partial-copy and
pending notes are earlier stages of that sequence. The performance receipt still
defers its installed calculation and runtime test. The October GAUCIA repair is
a separate transaction: eight files installed and verified, with preserved
non-target entries. Its installer did not launch the app. Earlier functioning
receipts, later holds and later installations should each keep their own dates.

For the laptop observations, this review includes nine hundred and ninety saved
counter readings across three windows. Every selected value, status and timestamp
has been retained, while machine identifiers and unrelated process details are
removed in a documented derivative. The included offline calculation reproduces
all thirty-three means. CPU load and available memory looked better in later
windows, but background work changed and not every indicator improved steadily.
The USB package checks ran after the sampling windows. These data therefore do
not isolate a general Windows acceleration caused by Q8 or the USB.

The source hashes connect the account to exact saved bytes. They are useful for
detecting change and identifying versions, but they do not independently prove
an event date, authorship, certification or endorsement. We also retain the
coverage gaps: the full original interaction export is still unavailable, current
USB contents and live readiness were not checked in this review, and later
publication-package copies on USB remain unverified.

The prepared edition now puts the algorithms, measured gains, setbacks and dated
operational evidence together for review. The owner can examine precisely what
would be shared, including the privacy transformations, before deciding on the
final public selection. No upload or submission has occurred.
