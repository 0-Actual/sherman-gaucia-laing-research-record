# Q8 and the USB — publication evidence review

Prepared for Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent:
GAUCIA Actual. Supporting review and preparation: Codex. October 16, 2026.

**Q8 and the USB are the central technical account in the proposed public research
history.** This focused edition brings the numerical claims, dated operational
receipts, corrections and outstanding source gaps together for owner review.
It supplements the existing research series and quantum collection; their
delivered archives remain unchanged.

The supported account is of a portable research software environment stored and
operated from USB, using the laptop's processor and memory. The evidence includes
substantive numerical algorithms, measured workload-specific improvements,
installed-file verification and a saved direct USB interaction receipt. The
publication should trace those achievements through their actual versions and
recorded conditions.

## Reading order

1. [Read-aloud account](READ_ALOUD.md): the main findings in connected prose.
2. [Technical claims](TECHNICAL_REVIEW.md): algorithms, benchmarks, adverse results
   and the boundaries of each claim. The matching [claim matrix](claims.json)
   provides exact source identities.
3. [Chronology](CHRONOLOGY.md): selected developments and later corrections,
   with [structured events](events.json).
4. [Custody and operation](CUSTODY_AND_OPERATION.md): recorded USB installation,
   execution locations and the difference between installation and usable service.
5. [Historical observations](observations/README.md): 990 selected counter readings
   and an offline replay of their 33 means, with explicit privacy transformations.
6. [Owner checklist](OWNER_REVIEW_CHECKLIST.md): decisions to make against this
   exact edition before any upload.

## Principal distinctions

| Evidence | What it establishes | Boundary retained in this edition |
|---|---|---|
| Stage-04 hybrid solver comparison | Approximately 65.85× as fast as the older hybrid by aggregate solver time in its fixed case/repetition set | A direct conventional solution remained cheaper; complete requests used another population and improved approximately 4.69× |
| Later VQD calculation revisions | Approximately 17.1% and 13.3% time reductions in two separately recorded batches, with matched outputs | Both missed the 20% goal; process memory is not total laptop memory |
| Dense and structured simulation | Dense trials through 21 qubits; separate compact structured implementations for selected states/circuits up to 60 indexed qubits | These are different representations and limits; size 22 was declined by memory admission rather than numerically tested |
| September 29 installation verification | 78 payload files: 47 repair, 16 performance and 15 adaptive | The later performance calculation and installed-runtime test remained explicitly deferred |
| September 29 direct interaction receipt | A recorded USB runtime and working directory, file checks, library retrieval and recalculation of saved observations | No model inference, network call or background service in that run; it is historical evidence, not a current-device check |
| Three laptop observation windows | 990 saved counter readings and 33 reproducible arithmetic means | Changing background activity and sequential checks do not isolate a causal Windows-wide speedup |
| October 15 GAUCIA R3 receipt | Eight installed repair files with preserved non-target entries | Separate installation from the September Q8 packages; that installer did not launch the service |

## Review status and remaining gaps

This edition is prepared for review, not publicly released. It does not certify
complete interaction coverage or current live USB state. The identified original
conversation export remains unavailable through this task's established access;
timeline summaries are not original transcripts. New archive copies on USB remain
unverified. The three previously screened controller/governance candidates remain
distinct until the owner identifies the intended master controller.

Numerical source objects and earlier research inputs remain in the existing
private quantum source archive. The separate private companion for this focused
review preserves local source locators and newly selected operational receipts.
Those private archives are not upload candidates. The public candidate deliberately
uses source IDs, relative logical names, hashes and screened numeric fields.

`MANIFEST.json` binds this edition's payload bytes. Its verification checks file
identity and the included arithmetic replay; it does not confer ownership,
authorship, scientific certification, approval by Microsoft or another party, or
proof of an original event date. Owner review and a later exact public selection
remain required before publication.
