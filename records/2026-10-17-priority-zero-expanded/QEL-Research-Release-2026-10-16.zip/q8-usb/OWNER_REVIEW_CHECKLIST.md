# Owner review — Q8 and USB publication candidate

Review this edition against its final MANIFEST.json and the external package
verification receipt. No box is pre-approved. If any selected content changes,
refresh its identities and review the changed edition before release.

- [ ] Confirm Q8 and USB as the central technical publication account, with the
  broader chronology supplying its origins and surrounding work.
- [ ] Review the wording that describes USB-hosted software computing in the
  laptop's host process. Keep component names distinct from hardware claims.
- [ ] Approve each proposed numerical claim with its version, input population,
  metric, comparison and limits. Keep solver, complete-request, retrieval,
  process-memory and system-counter measurements distinct.
- [ ] Retain adverse results, missed targets, direct-solver comparisons and
  corrections alongside favorable results.
- [ ] Confirm dates and transitions in the selected chronology. Do not replace
  earlier evidence with later summaries or treat file-copy dates as event dates.
- [ ] Review the 78-file September Q8 installation separately from the eight-file
  October GAUCIA repair. Keep each receipt's deferred runtime work explicit.
- [ ] Review the direct USB interaction's actual scope: file verification,
  library retrieval and arithmetic on saved observations. It does not establish
  a model conversation or currently running service.
- [ ] Approve the selected 990 counter readings, exact timestamps and redaction
  ledger. Device names, detailed process inventory and private paths remain in
  preserved originals. Disclosed source gaps are not hidden by redaction.
- [ ] Review the source registers and original/derivative hashes. Understand that
  they identify bytes and do not themselves establish authorship or certification.
- [ ] Accept the stated coverage gaps or supply additional readable original
  sources for a later revision: full interactions, current USB state, unresolved
  original-source links and any intended controller beyond the three candidates.
- [ ] Select the specific public files and destination, confirm attribution and
  applicable source permissions, and retain the private companion separately.
- [ ] Authorize the final upload only after reviewing the selected files and their
  final hashes. Preparation has not posted, pushed, submitted or contacted anyone.

An owner decision can accept a carefully bounded historical claim while leaving
other work open. A missing result is not recorded as a failure; a successful
integrity check is not recorded as successful live operation.
