"""Recalculate the included historical means offline using Python 3 standard library."""
from pathlib import Path
from collections import defaultdict
import json
import math
import sys

root = Path(__file__).resolve().parent
data = json.loads((root / 'counter-readings.json').read_text(encoding='utf-8'))
results = []
for window in data['windows']:
    groups = defaultdict(list)
    for row in window['rawCounters']:
        if row['status'] != 0 or not math.isfinite(row['value']):
            raise ValueError('This projection must contain only the original valid readings')
        groups[row['counter']].append(row['value'])
    if len(groups) != 11 or any(len(values) != 30 for values in groups.values()):
        raise ValueError('Unexpected counter/sample population')
    if len(window['saved_means']) != 11:
        raise ValueError('Missing saved means')
    for saved in window['saved_means']:
        values = groups[saved['counter']]
        mean = sum(values) / len(values)
        if not math.isclose(mean, saved['mean'], rel_tol=1e-12, abs_tol=1e-12):
            raise ValueError('Saved mean differs from included readings')
        results.append({'phase': window['phase'], 'counter': saved['counter'], 'samples': len(values), 'mean': mean})
if len(results) != 33:
    raise ValueError('Unexpected window population')
report = {'status': 'PASS', 'readings': 990, 'means': 33, 'new_observations': 0, 'results': results}
text = json.dumps(report, indent=2, ensure_ascii=False, allow_nan=False) + '\n'
if len(sys.argv) > 1:
    Path(sys.argv[1]).write_text(text, encoding='utf-8')
else:
    print(text, end='')
