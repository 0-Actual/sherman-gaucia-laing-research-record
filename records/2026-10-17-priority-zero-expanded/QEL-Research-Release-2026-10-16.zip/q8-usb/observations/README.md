# Historical laptop observations — reproducible review selection

These are selected, privacy-screened fields from three saved September 29 UTC
observation files. They are proposed publication material awaiting owner review.
The original files remain private and unchanged. No new measurements were made.

The first two observations occurred late September 28 in Eastern daylight time.
The third occurred shortly after midnight September 29 Eastern daylight time.
Exact source timestamp strings, including fractional-second precision, remain in
counter-readings.json. A recorded timestamp is not independent clock certification.

## Included population and calculation

There are **990 readings: three windows × eleven counters × thirty samples**.
The first pair supplies the previously reported 660 readings and 22 means; the
later window supplies 330 readings and eleven means. These are repeated readings
of eleven quantities, not 990 experiments. Each selected counter has thirty
finite values with recorded status zero. The scheduled interval was one second;
timestamps preserve actual sampling times. The complete observation command took
longer than its counter-sampling interval.

For each counter and window, the included replay sums its thirty values and
divides by thirty. It checks the result against the source's saved mean using
absolute and relative floating-point tolerances of 1e-12. The current preparation
checked all 33 means against the original private files; the standalone replay
also passes against the included derivative. This repeats arithmetic on saved
data; it is not an independent experimental replication.

Run `python reproduce_means.py` from this directory with Python 3. It uses only
the standard library and prints its result. An optional argument names a file
to receive the result. It does not access the USB, network, operating-system
counters or original private evidence. `reproduction-result.json` is the saved
output from preparation.

## Interpretation

The first observations surrounded closing completed browser pages and releasing
inspection tools. Background workload changed. Counter collection itself also
uses resources. The later window followed installation, but it is not a matched
causal experiment isolating installation's effect.

Mean CPU load was 40.955%, 16.633% and 12.058%, respectively. Mean available
physical memory was 301.967, 339.600 and 421.467 MiB. These observations support
lower measured resource pressure in those later windows. They do not quantify
a general Windows speed improvement attributable to Q8 or the USB.

Not every indicator improved monotonically. Mean pages output per second were
926.599, 0.521 and 370.687. The mean sampled disk-read latency was 0.562, 0.630
and 0.780 milliseconds. Disk latency here is the unweighted arithmetic mean of
sampled counters, including idle intervals; it is not a latency average weighted
by individual completed disk operations. Disk bytes per second describes observed
activity, not maximum storage throughput.

Each counter window **preceded** the associated 40-file USB package check. The
readings therefore do not measure the resource load of that subsequent check.
Recorded verification times were 12.5676291, 1.620652 and 9.3315077 seconds.
Different cache and background conditions prevent attributing the differences
to code acceleration or storage performance. Each check reported success against
an unsigned manifest; its signature field is null. This establishes the recorded
integrity check's scope, not authenticated authorship or release certification.

## Provenance and privacy

The projection preserves all selected counter values, status codes and exact
timestamp strings. Only the machine-name prefix is removed from each counter
path. Other private device/process inventories and unrelated context are omitted
through an explicit field selection. The redaction ledger lists those omissions
and gives each original file's name, byte length and SHA-256. Source hashes and
derivative hashes identify different byte sequences.

The selected data are complete for these thirty-sample counter groups. They are
not the complete USB, full operating-system telemetry or original interaction
history. Missing source coverage is a separate gap from these disclosed privacy
omissions. No missing values or unavailable conversations were invented.
