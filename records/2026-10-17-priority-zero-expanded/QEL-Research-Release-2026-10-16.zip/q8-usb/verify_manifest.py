"""Verify this edition's listed payload bytes without using the network or USB."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFEST.json').read_text(encoding='utf-8'))
failures = []
for record in manifest['files']:
    path = root / record['path']
    if not path.is_file():
        failures.append({'path':record['path'], 'error':'missing'})
        continue
    content = path.read_bytes()
    if len(content) != record['bytes'] or hashlib.sha256(content).hexdigest() != record['sha256']:
        failures.append({'path':record['path'], 'error':'identity mismatch'})
print(json.dumps({'status':'FAIL' if failures else 'PASS','listed_payloads':len(manifest['files']),'failures':failures}, indent=2))
raise SystemExit(1 if failures else 0)
