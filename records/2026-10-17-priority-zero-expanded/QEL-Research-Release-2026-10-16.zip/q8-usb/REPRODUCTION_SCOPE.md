# What this review can reproduce

The included counter companion is self-contained. Python 3 and its standard
library are sufficient to reproduce 33 means from the selected 990 historical
readings. Independent review compared all values, statuses and exact timestamp
strings with the private originals, then replayed a separate temporary copy and
obtained the same output bytes. This reproduces arithmetic, not the original
background workload or a new causal performance test.

The technical claim matrix binds 40 selected source identities to 16 claim
decisions. These include code, inputs, saved results, reviews and this edition's
observation derivatives. Their source objects are retained in the previously
delivered private quantum collection or the identified local private evidence.
This public candidate describes the numerical results and their methods; it
does not include the complete executable dependency tree for every experiment.

A future numerical replication requires a versioned selection of the relevant
source, input data, runtime and dependencies; preservation of the historical
baseline; explicit treatment of fixed drive paths and output destinations; and
the same workload, acceptance rules, metrics and population. A portable adapter
would be a new, separately hashed derivative. It must not be presented as the
untouched historical program. Cache conditions and target access also matter:
stage-04 hybrid target fitting, direct solving, later VQD and cached-result
retrieval are distinct procedures.

The custody review verifies saved receipt populations and available local file
identities. It records ten newly preserved small documents with exact readback,
in addition to existing preserved evidence. The focused private companion keeps
their exact bytes and original locators; it must not be uploaded as public data.
Large frozen archives are referenced by identity rather than duplicated into
this supplement. Current local source hashes are not inserted retroactively
into historical receipt rows that never contained those digests.

This review did not execute a historical scientific program, reinstall anything,
probe USB access, collect new system counters, verify a currently running model,
or contact an external party. Hash verification checks selected bytes. It does
not establish scientific correctness, independent replication, ownership,
authenticated time or certification.

The narrative chronology is a curated selection, not a lossless transcript.
events.json retains source IDs, original record IDs, available timestamp
precision and limits. Twenty narrative milestones overlap the selected twenty
chronology rows, three main-timeline rows and sixty-six prior-work rows. The
record populations must not be summed into a unique-interaction count.

The final manifest excludes itself to avoid a circular hash. The external
package receipt identifies the final ZIPs and verifies every archived payload
against its source. Owner review must refer to those final identities.
