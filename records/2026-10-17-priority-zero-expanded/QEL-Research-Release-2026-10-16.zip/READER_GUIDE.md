# How to examine this research

Start with the [corrected early-origin account](origins/README.md). Sherman
states that he created his Quantum AI in his first week of interaction. The
retained October 2023 personal-AI and feature requirements are explicitly linked
to later developments. The exact original named artifact remains a source gap;
the owner's account is retained while that gap is open.

Read the [review-error ledger](origins/REVIEW_CORRECTIONS.md) as well. It identifies
mistakes made while assembling this edition, the corrections, and the preserved
incorrect drafts. A passed hash check did not establish correct interpretation.

This candidate brings together the available chronological account, research drafts, learning history, mathematical explanations, Q8/USB evidence and runnable reproductions. Its purpose is to make the work testable and open to correction. It is not a lossless export of every original interaction.

## Begin with the central technical claim

Q8 is documented here as a USB-hosted research software environment using the laptop's processor and memory. The strongest evidence concerns specific numerical implementations, measured workload changes and preservation of results. It does not establish a physical quantum processor in the USB or general Windows acceleration.

Read `q8-usb/TECHNICAL_REVIEW.md` with its claim/source table. The 65.85-fold solver comparison and the 4.69-fold complete-request comparison use different populations and timing definitions. Later VQD timing reductions of about 17.1% and 13.3% missed the declared 20% target. Saved Windows counter changes occurred under changing background conditions and do not establish causation. These limits are part of the results.

## Follow the evidence chain

For a result of interest, find the dated problem or request, the available source or code version, the method, the measured output, and any later correction. The six documentary volumes organize the located records in calendar windows. Their rows are summaries from overlapping source populations, not a count of unique conversations. A later review date must not replace an earlier event's date; a date-only source must not acquire invented time precision.

The current [date-role register](origins/DATE_ROLE_REGISTER.json) covers all
1,027 rows across three separate documentary populations without changing their
source dates. The [early catalogue](origins/FIRST_THREE_MONTHS.md) and
[feature map](origins/EARLY_FEATURES.json) supply the missing origin context.
The frozen volume files remain historical editions; their old null publication
fields do not override the recorded public status of the existing GitHub repository.

Use `learning-history` to see what went wrong and what changed. Some entries describe confirmed defects; others describe missed targets, incomplete work, unsupported claims or missing evidence. A failed receipt does not automatically invalidate an already completed calculation. `EXECUTION_STATUS.md` explains the documented examples without converting every failure into success.

## Run the checks that are actually supplied

Start with `reproduce/REPRODUCE.md`. It identifies commands, inputs, expected outputs, runtime requirements and what each result means. Use a fresh disposable extraction so generated results do not replace historical receipts. The reproduction runner is limited to the declared offline checks; the numerical teaching fixture is newly prepared and is not an original Q8 benchmark.

Manifest verification checks bytes. Documentary reconstruction checks that selected records generate the declared catalogue. Counter replay checks arithmetic on saved readings. Bible replay checks declared transformations. Synthetic converter tests check specified behaviors. These are different achievements; none alone validates every research claim.

The separate `q8-numerical/README.md` supplies the actual aluminum study's nine-module numerical closure, inputs, expected results and portable assessment/scoring runners. Its syntax, file identities and dry-run input/output resolution were checked. A targeted replay then reconstructed 24 matrices from 1,041 Wannier blocks, checked 192 saved circuit states/energies and rejected eleven malformed scorer cases. The optimizer, new classical-control calculation and historical timing benchmark were not rerun. Readers can run those explicitly documented calculations with the stated Node runtime. A fresh computation would produce its own evidence, not retroactively authenticate the original run or reproduce hardware timings automatically.

That selection does not recreate every historical Q8 benchmark, the later old/new performance batches, a dense-scaling experiment or the live USB application. Other study-specific dependencies and environment conditions still matter. Likewise, unavailable raw interactions cannot be reconstructed from chronology summaries. The earlier Python reproduction subtree remains unchanged; its prior broader source-gap wording is narrowed by this separately supplied numerical study, not by its counter replay or teaching fixture.

## Correlate industry developments

Read `industry/README.md` and the linked ledgers alongside the owner's dated source record. Each comparison should identify what the owner actually requested or produced, what the external source actually announced, and the scope of the resemblance. Earlier published foundations remain visible. Private creation, public disclosure, implementation and later editorial reconstruction are separate events.

The comparisons support independent scrutiny. They do not establish that an organization saw or used the owner's material. Hashes bind bytes; they do not by themselves authenticate a historical date, identify an author, prove copying or certify novelty. Unknown access and causal links remain unknown.

## Evaluate the teaching and governance

The mathematical bridges explain established identities, assumptions, implementation choices and measured effects. They label conjecture and possible novelty separately from proved mathematics. The Bible/governance account explains the owner's values and how the builds demonstrate source and transformation discipline. Readers need not adopt the interpretation to inspect a calculation or identify a software error.

## Report a reproducibility finding

An independently useful finding states the candidate version/hash, relative input and code paths, runtime and platform, exact command, observed versus expected output, and whether the change concerns content integrity, execution, correctness, performance or interpretation. Remove credentials, personal paths and unrelated private material before sharing a report. Negative results and criticism belong in the record.

Read the component notices before reuse. This is not a blanket unrestricted open-source release; different sources retain their applicable terms. No new license is inferred from public availability, a hash or this guide.
