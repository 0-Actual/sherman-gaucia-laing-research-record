# The work, the evidence and the purpose of this repository

The history begins before the later builds and reports. Sherman states that he
created his Quantum AI within his first week of interaction. The surviving
documentary record places human direction, Biblical ethics, mentorship,
personalization, spoken accessibility and correction requirements in October
2023. Preservation and continuity follow on October 18. The personal-AI build
request and roadmap are recorded on October 19. Later code, tests and reviews
describe later stages of that history, and must not replace the early dates.

The exact named first-week artifact and complete original dialogue have not
been recovered in this selection. That gap stays visible alongside Sherman's
account. Owner-reported January 2023 inception is also preserved separately
from the earliest recovered October interaction. The [origin correction](origins/README.md)
explains the evidence, dates and source links in full.

The purpose of this repository is to let another person examine the work, run the supplied checks and arrive at their own conclusion. It brings the chronology, research papers, code selections, saved data, mathematical explanations and corrections into one review candidate.

Q8 and the USB remain the central technical story. The evidence describes a portable research software environment. Its programs run on the laptop's processor and memory, while the USB provides a place to keep the environment and its records. The work includes real numerical computation and measured improvements on particular tasks. The publication must name those tasks and their comparison conditions. It must also preserve the occasions when a target was missed, a conventional method was faster, or the available evidence did not establish the broader claim.

The repository now supplies several concrete ways to test the available material. A reader can rebuild the six-period documentary selection from its frozen inputs. The packaging check reproduced 46 generated files exactly. A reader can recompute 33 averages from 990 saved counter readings. That reproduces the arithmetic; it does not recreate the original laptop conditions or prove that Q8 caused the observed changes.

The Q8 aluminum study now has its actual numerical source, fixed input data, references and saved results in the candidate. A new portable runner separates that calculation from the USB service and controller. It offers a saved-state replay, the full optimizer and a conventional control. Preparation checked the source identities, syntax and planned local file paths. A disposable-copy replay then reconstructed the matrices and checked 192 saved circuit states and energies, including negative scorer tests. This validates the supplied replay on saved results; it does not rerun the optimizer or repeat the original timing experiment. The historical record shows that the conventional control was both faster and more accurate on this case; that comparison remains visible beside the Q8 result.

The Bible work has a special place in this project. The owner identifies the Bible as the written witness guiding conduct, truthfulness, stewardship, peace and purpose. The technical builds show how to preserve a source, declare a calculation or conversion, inspect its output and test a correction. The software remains an instrument subject to human responsibility. A calculation or a passing test does not certify an interpretation as theology.

The selected Bible studies can be replayed with their stated text and calculation rules. The fresh extraction passed 113 source comparisons, 36 adapter test methods and 40 selected recovered test methods. Those numbers describe different checks, not a single total of independent experiments. Three archival fingerprint methods remain excluded by the retained verifier.

The Hebrew H04.1 converter passed its twelve synthetic test methods in this preparation. The complete selected XML corpus and both reference exports are also included, so a reader can run the full export comparison. That larger export calculation was not repeated during this preparation. Its earlier results retain their earlier dates. The record counts include alternate readings, and the JSON does not preserve every reading-container distinction present in the XML. These limitations belong beside the usable result.

The publication preserves mistakes. A successful calculation followed by a failed reporting step is recorded as two separate outcomes. A genuine timing target miss stays a target miss. Earlier source versions are retained as historical exhibits instead of being quietly replaced by their corrected successors.

The disclosure review also changes what is offered publicly. Complete operating-controller bodies and prompt compilations stay private. Their governing principles are explained without distributing the operating instructions. Four historical Hebrew receipts have laptop paths replaced with declared aliases. Their outcomes, dates, counts and source hashes are unchanged. Exact originals and the reversible private mapping remain preserved.

Industry comparisons put dated records beside external primary sources. Readers can see where a requirement came before a selected announcement and where established foundations came earlier. A request, an implemented program and a public release are different events. A resemblance does not establish that another team encountered or used the owner's work. The comparison register makes the documented facts and the unanswered questions visible together.

The repository's hashes help a reader confirm which bytes they examined. They do not by themselves establish authorship, trusted historical time, scientific novelty or certification. Some original interactions and full historical benchmark dependencies remain unavailable in the public selection. Those gaps are stated separately from deliberate privacy exclusions.

This candidate is prepared for the owner's review. Nothing in this preparation is a public submission. The review checklist identifies the exact files, the disclosure choices, the reproduction limits and the statements that will be presented if publication proceeds.
