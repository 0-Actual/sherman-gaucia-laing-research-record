# Papers, categories and review order

All eight copies below contain the located manuscript body and disclosed editorial
notes. They are prepared for review; this is not a declaration of peer review,
scientific novelty or readiness for a particular journal. Historical claims are
qualified by their dated evidence addenda. Read these before choosing a venue.

| Manuscript | Category | What to review before release |
| --- | --- | --- |
| [QEL Sovereign Standalone Architecture](research/papers/architecture.md) | System architecture / methods | Separate the proposed architecture from the tested reference subset and live deployment. |
| [Signed Provenance and Software Supply Chain](research/papers/provenance.md) | Provenance / reproducible software | Confirm which signing and verification functions have execution evidence; hashes alone are not signatures. |
| [Verified State and Model Validation](research/papers/verified-state.md) | Evaluation / claim discipline | Retain the distinction between recorded tests, example models and demonstrated outcomes. |
| [Visual Authorization and Biometric Privacy Correction](research/papers/visual-authorization.md) | Privacy / authorization design | Retain the correction and the 5,000-record synthetic population; it is not a participant study. |
| [WP-001: Governed Local-First Human–AI Systems](research/papers/WP-001-governed-local-first-human-ai-systems.md) | Human–AI systems / governance | Source date remains unknown. The reported 15 Node tests have not been reproduced in this preparation. |
| [WP-002: Evidence Claims and Fail-Closed Release Gates](research/papers/WP-002-evidence-claims-and-fail-closed-release-gates.md) | Evidence methods / release controls | Numerical examples are illustrative. Check the source-index support for each intended claim. |
| [Complex Analysis Proofs](research/papers/teaching-complex-analysis-proofs.md) | Mathematics education | Assistant reconstruction of established results; full independent proof audit remains outstanding. |
| [Advanced Mathematics and Frontiers](research/papers/teaching-advanced-mathematics-frontiers.md) | Mathematics education / survey | Preserve source attribution and limits; this is not a claim to original solutions to open problems. |

The four August papers form a coordinated series sharing evidence, rather than
four independent experiments. New diagrams are disclosed reconstructions, and
their Mermaid text has not received a rendered layout audit. Original PDF/DOCX
versions are retained in the private evidence archive.

## Other research categories

- **Documentary interaction history:** six period narratives, full catalogues,
  correction notes and source selections. Begin at [the series overview](START_HERE.md).
- **Biblical study and text tooling:** six frozen study bodies, the public replay
  companion and the separately preserved Hebrew H04.1 corpus repair.
- **Computational materials:** JARVIS-DFT data review and aluminum numerical-model
  assessments. Dataset analysis, saved-state replay and new physical experiments
  remain distinct.
- **Software performance and laptop observations:** preserved comparison runs,
  counter samples and negative results. The record does not establish an isolated
  improvement to the whole Windows system.
- **Mathematical and quantum-inspired computation:** recovered algorithms,
  classical GHZ emulation and bounded arithmetic checks, with missing components
  identified. Simulated states are not physical quantum hardware results.
- **Preservation and continuity:** QPRINT, source custody, local conversation
  software and documented recovery/install receipts.

The [evidence and reproduction matrix](research/EVIDENCE-MATRIX.md) maps 19
workstreams to actual code, data, receipts and remaining gaps. Its entries overlap
with the papers and period lists. The [supplemental catalogue](supplements/SUPPLEMENTAL_CATALOGUE.md)
retains the historical portfolio and later mechanism descriptions without treating
unsupported dates or old maturity labels as confirmed results.

Review the documentary content and the desired public code/data selection together.
The public candidate contains the exact selected Bible and JARVIS source notices;
additional code, measurements and originals are retained privately. Any later move
of private material into the public candidate needs a fresh disclosure review and
an updated manifest before publication.
