# Source catalogue and evidence limits

## Frozen documentary sources

1. **Private September 17, 2026 full chronology report.** The source is *Quantum.Earth.Laing — full recovered chronology, prior-work evidence, and industry overlap*. The series selects 348 ISO-dated rows from two tables: 321 chronological evidence entries and 27 recovered-code metadata entries. It does not copy industry-overlap comparison tables, private source locators or original conversations. Exact raw rows and the transformation map remain private; the public projection and redaction ledger describe the selected fields.
2. **Existing public timeline.** All 175 rows from `timeline.json` at commit `f56f010386cb5d08c2c1f0168f7627fe81186463` of `0-Actual/sherman-gaucia-laing-research-record`. [Pinned source](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/timeline.json). Git blob identity was verified when acquired.
3. **Existing public prior-work appendix.** All 504 published rows from the October 1, 2026 edition at the same commit. [Pinned source](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/records/2026-10-01-prior-work/prior-work.json). The source edition itself excluded 23 personal-only items from a 527-item report and applied ten limited privacy edits. Those are that prior edition’s decisions, not a new claim to have reviewed all 527 originals here. Existing navigation-number gaps are preserved.
4. **Four current saved-receipt summaries.** New sanitized entries cover October 15 GAUCIA installation bytes, task preservation, Hebrew H04.1 audit and the first-period documentary package. Their precise saved times and evidence limits are retained. They are a separate population from the earlier published lists.

The old public timeline’s null publication fields are frozen historical metadata. They do not mean that the public repository is unpublished. The new series itself is prepared locally and remains unpublished. Original event dates, later review dates, preparation dates and any future release date are kept separate.

## Research manuscripts and companions

`research/EVIDENCE-MATRIX.md` inventories actual manuscripts, code, datasets, results and replay requirements. The four August papers form a coordinated design/methods series, not four independent experiments. Later undated drafts retain unknown source-document dates; filesystem dates do not become publication dates. New diagram reconstructions and evidence addenda are marked as current editorial work.

Existing public Bible and JARVIS material is preserved at exact pinned versions with source notices. Later local numerical/performance work remains bounded to its actual model, input, workload and sample population. A result summary or filename does not establish that every needed reproduction artifact is included.

## Private preserved source population

The retained concern-capture file supplies 606 duplicate-inclusive user-message occurrences, 522 distinct message IDs and 107 conversation IDs. Of the 522 messages, 165 have at least one complete captured textual field; 357 have only partial captures. No assistant replies are present. This is a keyword-selected audit source. It is not the full conversation corpus and cannot support a project-wide error rate.

Per-volume distinct capture IDs are 10, 22, 213, 104, 0 and 173. The zero in volume five describes this capture source, while public documentary summaries provide entries for that period. Absence in one source must not be reported as absence of interaction.

The identified original export archive remains unread. Focused local discovery, previous archive-index review and the unchanged empty intake folder did not supply it. The exact private location and recovery instructions remain outside the public package. The owner’s observation that the USB exists is separate from this session’s access to that file.

## Attribution and publication scope

Sherman Gaucia Laing / Quantum.Earth.Laing is the owner, principal researcher and directing author. The early historical assistant is Thunder where documented. GAUCIA Actual is the current primary project agent. Codex and delegated reviewers prepared this documentary series. Assistant-generated ideas, explanations and code are attributed as such; current attribution does not backdate names or prove a running autonomous service.

The record preserves untested concepts, failures, corrected claims and unresolved findings. It does not establish novelty, complete ownership, third-party access or derivation, compensation entitlement, institutional endorsement or certification. Statements about model-training settings remain the owner’s account unless directly supported by per-event evidence.

The public payload contains selected source summaries, paper derivatives, proposed companion files, build instructions and manifests. The separate private bundle contains sensitive original excerpts and locators and is not for posting. Every new publication selection remains subject to the owner’s review.
