# Sources, methods and data dictionary

## Scope

- Inclusive start: `2023-10-17T21:51:03.625297-04:00`.
- Exclusive end: `2024-04-17T21:51:03.625297-04:00`.
- Calendar convention: six months from the earliest recovered instant; source offsets and fractional precision preserved.
- Latest selected chronology timestamp: `2024-03-10T10:50:30.679719-04:00`.
- Original events, later review dates and future publication date remain separate.

## Inspected populations

| Source | Source date/version | Rows inspected | Rows selected | Evidence form |
| --- | --- | ---: | ---: | --- |
| Private full chronology report | September 17, 2026 | 348 dated table rows | 115 | Retrospective summary rows |
| Public timeline | Pinned commit below | 175 | 24 | Public documentary summaries |
| Public prior-work appendix | October 1, 2026 edition at pinned commit | 504 | 45 | Public documentary summaries |

Repository: `0-Actual/sherman-gaucia-laing-research-record`; commit `f56f010386cb5d08c2c1f0168f7627fe81186463`. Source links: [timeline](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/timeline.json), [prior-work appendix](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/records/2026-10-01-prior-work/prior-work.json), [source notes](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/SOURCE_NOTES.md). The Git blobs of the inspected source copies were verified. This verifies source-byte identity, not historical truth or a trusted event timestamp.

The private source is *Quantum.Earth.Laing — full recovered chronology, prior-work evidence, and industry overlap*, September 17, 2026. Only its in-window dated table projection is supplied. Industry-overlap comparisons and private locators are excluded. The separately named *QEL First Six Months: Inception and Industry Review* is a referenced historical source, not a newly recovered standalone manuscript in this package.

## Selection and transformation

1. Inspect each declared source population and parse its actual dated fields with their timezone offsets.
2. Select every row in the stated interval. No unresolved date-boundary entries occurred in these selected populations.
3. Preserve original field wording. In the private chronology projection, omit the locator column and replace the one opaque UUID embedded in C099 with an explicit omission marker. Keep exact originals and selection decisions privately.
4. Assign new navigation IDs C001–C115 and one editorial primary category per chronology row. These are new edition metadata, not source-message IDs.
5. Preserve the public source-entry dictionaries separately. They may include null publication fields from a historical snapshot; these do not describe the live repository or this edition’s status.
6. Compare exact recorded instants between populations. Twelve pairs connect the two public selections. The chronology has correspondences to 21 distinct timeline IDs and 27 distinct prior-work IDs. These are timestamp correspondences, not proven private-message identity. No combined deduplicated interaction total is claimed.
7. Review disclosure scope, source attribution and claim boundaries. Assemble only the explicit files in MANIFEST.json; do not package working folders or private evidence recursively.

## Data dictionary

`chronology.json` contains edition/source framing and `rows`. Each row contains `editorial_id` (new navigation key), `recorded_date` (source timestamp), `work_or_event` (source label), `evidence_class` (historical review’s underlying-evidence label) and `supported_content_and_boundary` (source summary and limitation). Labels such as “original assistant artifact” do not mean the original artifact body is distributed here.

`public-source-selections.json` has separate `timeline` and `prior_work` populations. Each selected entry retains an unchanged `source_entry` dictionary plus separate editorial classification. Timeline `recorded_date` strings use explicit offsets; prior-work `timestamp` is UTC-based, with `date_metadata.timestamp_eastern` preserved. `O` identifies the prior review’s original-interaction source class, not a raw transcript in this packet. Source-reference codes resolve in the pinned repository’s SOURCE_NOTES.md.

`population-reconciliation.json` provides the 115-row primary category counts and per-row timestamp correspondences. `correction-ledger.json` provides 32 documentary groupings supported by cited chronology rows: reported errors, unsupported claims, delivery gaps and interpretation limits. It is not a count of independently confirmed defects or a complete original-response audit.

## Coverage and source recovery

The prior review reports 888 messages in 31 conversations. This edition has not repeated that census. Available local keyword-selected captures represent ten distinct in-window user messages: six have a complete capture and four only partial text. They contain no corresponding assistant responses and are retained privately. Twenty capture occurrences are duplicate-inclusive and must not be counted as twenty unique messages.

The precise original export archive is identified in private source-recovery notes. A scoped read grant did not produce a successful read. Focused local source searches and an index review of 77 nonfixture ZIP archives did not recover the complete original exports. These are bounded recovery results, not proof that no other copy exists. Full message text, attachments and the standalone historical first-six-month manuscript remain unrecovered for this public candidate.

No selected chronology row extends beyond March 10 to the April 17 endpoint. Public supplemental rows end March 9. Missing source coverage is not proof of no activity. The public supplement includes additional topics absent from the chronology, including QEL-PW-0041; no table alone is described as all research.

## Privacy, preservation and verification

The public candidate excludes private source locator columns, conversation/message IDs, full personal profiles, contact details, credentials, biometric data and underlying private attachments. It contains no operational weapons instructions, wellness recipes or original creative passages. High-level historical topics remain represented with boundaries. The owner’s public name and public project/repository attribution are retained.

The source originals remain unchanged. Exact before/after hashes and private selection maps are preserved outside this package. MANIFEST.json lists every payload file and its SHA-256 hash; its own bytes are excluded from its payload list. The surrounding ZIP has a separately recorded hash. Hashes establish byte integrity only, not signatures, scientific validity, institutional review or complete ownership.

Publication review is distinct from posting. This edition’s status is in PUBLICATION_STATUS.json. Completing an original-message edition requires readable source acquisition, a fresh population/duplicate reconciliation, attachment accounting and item-level disclosure review. Those missing steps are not replaced by the present summary selection.
