# First Six Months of Recorded Human–AI Research

**Sherman Gaucia Laing / Quantum.Earth.Laing**  
Edition 2026.10.15-documentary-review.1 — prepared for publication review; not posted.

Start with [the manuscript](FIRST_SIX_MONTHS.md). The defined window is October 17, 2023–April 17, 2024, measured from the earliest recovered timestamp. Located chronology entries reach March 10, 2024; full original-message coverage has not been recovered for this edition.

## Included material

| File | Purpose |
| --- | --- |
| FIRST_SIX_MONTHS.md | Documentary research manuscript and abstract |
| CHRONOLOGY.md / chronology.json | 115 dated summaries from the September 17 retrospective report |
| CATEGORIES.md | Eight primary editorial categories and row navigation |
| PUBLIC_SOURCE_SUPPLEMENT.md / public-source-selections.json | Separate 24-row timeline and 45-row prior-work selections, including supplementary topics |
| population-reconciliation.json | Category assignments and exact-timestamp correspondences |
| CORRECTIONS.md / correction-ledger.json | 32 editorial groupings of reported problems and claim boundaries |
| SOURCES_AND_METHODS.md | Source versions, selection rules, data fields and reproducibility limits |
| ATTRIBUTION.md / CITATION.cff | Contribution disclosure and suggested edition citation |
| LICENSE.md | Unchanged existing repository license |
| PUBLICATION_STATUS.json | Prepared status and remaining source gap |
| MANIFEST.json | Exact file list, byte sizes and SHA-256 integrity values |

The three row populations overlap. Do not total them as messages, papers, inventions or independent findings. The historical 888-message/31-conversation figure is a prior review statement, not this packet’s raw-message coverage. Technical corrections are attributed to the retrospective review, not newly performed experiments or a comprehensive scientific audit.

The public candidate excludes complete private conversations, personal questionnaire answers, local paths, private source identifiers, credentials and biometric records. Exact private evidence and selection decisions remain separately preserved. One opaque identifier inside chronology row C099 is explicitly omitted; other row wording is retained.

The package is prepared for review as a documentary edition. The complete original-message/data edition still needs the identified export archive to be readable and reconciled. No public upload, release, DOI, external verification or owner signature was created during preparation. File hashes identify bytes; they do not certify scientific claims or authorship.
