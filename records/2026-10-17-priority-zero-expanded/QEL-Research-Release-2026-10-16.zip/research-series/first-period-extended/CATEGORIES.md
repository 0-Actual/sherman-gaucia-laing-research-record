# Research categories and navigation

Primary category labels are editorial additions. Counts refer only to the 115 chronology rows; supplementary lists retain their own categories and overlapping populations.

All three selected populations are preserved. These are documentary topics, not eight finished scientific papers.

## Biblical study and ethical foundations — 10 chronology rows

- **QEL-F6M-C002** · 2023-10-17T21:55:12.311683-04:00 · Developer bias, human responsibility and ethical oversight
- **QEL-F6M-C003** · 2023-10-17T22:17:18.408566-04:00 · Bible foundations: creation, Genesis and first light
- **QEL-F6M-C004** · 2023-10-17T22:20:50.003669-04:00 · Shared reasoning and neighbor-love as assistance basis
- **QEL-F6M-C009** · 2023-10-17T22:53:35.401922-04:00 · Bible as core ethical fail-safe
- **QEL-F6M-C012** · 2023-10-17T23:26:46.439509-04:00 · Truthfulness, no manipulation of free will, unbiased advice
- **QEL-F6M-C036** · 2023-10-18T00:45:02.106717-04:00 · Environmental ethics and future generations
- **QEL-F6M-C061** · 2023-10-19T12:47:34.604034-04:00 · Biblical knowledge/free-will fictional exercise
- **QEL-F6M-C102** · 2023-12-04T21:38:29.364286-05:00 · Cain/Abel, creation cross-references and redemption study
- **QEL-F6M-C103** · 2023-12-25T09:44:38.575721-05:00 · Job and angels study
- **QEL-F6M-C104** · 2024-01-04T19:51:51.221112-05:00 · Isaiah 40:31 and waiting on the Lord

## Human–AI interaction, continuity and owner control — 29 chronology rows

- **QEL-F6M-C001** · 2023-10-17T21:51:03.625297-04:00 · Human direction and assistant role
- **QEL-F6M-C005** · 2023-10-17T22:28:51.670655-04:00 · Escalation and developer feedback
- **QEL-F6M-C006** · 2023-10-17T22:43:44.581522-04:00 · Intellectual mentorship and governance education
- **QEL-F6M-C007** · 2023-10-17T22:47:02.287640-04:00 · Accessible assistance and actionable instructions
- **QEL-F6M-C008** · 2023-10-17T22:49:55.271937-04:00 · Assistant identity Thunder and user callsign ZeroActual / 0-ACTUAL
- **QEL-F6M-C010** · 2023-10-17T23:01:05.797668-04:00 · Professional respectful personalization
- **QEL-F6M-C011** · 2023-10-17T23:13:49.211394-04:00 · Correction of speech transcription and meaning
- **QEL-F6M-C013** · 2023-10-17T23:31:08.134064-04:00 · Label imaginative content separately from factual material
- **QEL-F6M-C015** · 2023-10-17T23:35:35.476692-04:00 · Instruction compliance, quantity checking, user and assistant corrections
- **QEL-F6M-C016** · 2023-10-17T23:47:32.686366-04:00 · Retrospective error review and reliability disclosure
- **QEL-F6M-C017** · 2023-10-17T23:51:03.517025-04:00 · Questionnaire-based personalization and feedback loop
- **QEL-F6M-C019** · 2023-10-18T00:07:52.133913-04:00 · Conversation preservation for later review
- **QEL-F6M-C020** · 2023-10-18T00:12:21.150994-04:00 · Cross-session parameter continuity and resume
- **QEL-F6M-C032** · 2023-10-18T00:38:26.129194-04:00 · Iterative scoped requirements and simplifying complex tasks
- **QEL-F6M-C039** · 2023-10-18T07:02:22.696112-04:00 · Owner-consented access to earlier conversations
- **QEL-F6M-C040** · 2023-10-18T07:03:06.263712-04:00 · Challenge to privacy explanation and data transparency
- **QEL-F6M-C062** · 2023-10-19T12:49:41.836895-04:00 · Identity spelling correction: Sherman gaucia laing
- **QEL-F6M-C065** · 2023-10-19T13:09:57.028348-04:00 · AI compute-efficiency study
- **QEL-F6M-C066** · 2023-10-19T13:10:07.597196-04:00 · AI compute-efficiency discussion
- **QEL-F6M-C070** · 2023-10-19T13:40:29.265442-04:00 · Direct human control over autonomous control
- **QEL-F6M-C072** · 2023-10-19T13:58:30.434154-04:00 · Owner-only biometrics and simulation-before-deployment
- **QEL-F6M-C074** · 2023-10-19T14:06:58.013464-04:00 · Confidentiality / classification request
- **QEL-F6M-C075** · 2023-10-19T14:08:50.864697-04:00 · Access-risk quantification
- **QEL-F6M-C076** · 2023-10-19T14:20:46.254321-04:00 · Personal AI build roadmap
- **QEL-F6M-C077** · 2023-10-19T14:20:46.254321-04:00 · Build a personal AI system
- **QEL-F6M-C078** · 2023-10-19T14:20:51.802281-04:00 · Build-your-own-AI roadmap
- **QEL-F6M-C079** · 2023-10-19T14:24:08.556997-04:00 · Clarified ownership/control over AI
- **QEL-F6M-C080** · 2023-10-19T14:26:44.279502-04:00 · Fictional AI threat analysis, simulation and human oversight
- **QEL-F6M-C098** · 2023-10-26T10:56:28.563748-04:00 · User-controlled teaching and researcher roles

## Agriculture, energy, environment and device concepts — 51 chronology rows

- **QEL-F6M-C021** · 2023-10-18T00:20:02.192223-04:00 · Atmospheric and ground energy study
- **QEL-F6M-C022** · 2023-10-18T00:23:00.047813-04:00 · Saltwater energy study
- **QEL-F6M-C023** · 2023-10-18T00:26:54.826765-04:00 · Low-cost waterwheel and thermal generator drafts
- **QEL-F6M-C024** · 2023-10-18T00:27:04.746861-04:00 · Low-cost waterwheel generator
- **QEL-F6M-C025** · 2023-10-18T00:28:00.098447-04:00 · Air/ground Stirling generator draft
- **QEL-F6M-C026** · 2023-10-18T00:30:57.870481-04:00 · Controlled seedling nursery
- **QEL-F6M-C027** · 2023-10-18T00:31:11.532899-04:00 · Three-level seedling nursery
- **QEL-F6M-C028** · 2023-10-18T00:32:17.178607-04:00 · Watering and remote nursery monitoring
- **QEL-F6M-C029** · 2023-10-18T00:32:23.569856-04:00 · Nursery watering and remote monitoring
- **QEL-F6M-C030** · 2023-10-18T00:33:30.487625-04:00 · Nursery kit business, shipping and solar extension
- **QEL-F6M-C031** · 2023-10-18T00:36:12.281378-04:00 · Nursery base instruction kit
- **QEL-F6M-C033** · 2023-10-18T00:39:31.229196-04:00 · Greenhouse solar option
- **QEL-F6M-C034** · 2023-10-18T00:42:22.116010-04:00 · Waste reuse, landfill carbon and circular building concept
- **QEL-F6M-C035** · 2023-10-18T00:42:34.695103-04:00 · Recycled-material greenhouse
- **QEL-F6M-C041** · 2023-10-19T11:12:01.258488-04:00 · Piezoelectric wearable with wireless power
- **QEL-F6M-C042** · 2023-10-19T11:13:41.151334-04:00 · Thermophotovoltaic feedback system
- **QEL-F6M-C043** · 2023-10-19T11:16:00.538888-04:00 · Vibration energy harvesting and storage
- **QEL-F6M-C044** · 2023-10-19T11:26:36.021306-04:00 · Vibration harvester and storage
- **QEL-F6M-C045** · 2023-10-19T11:33:34.898695-04:00 · Roadway vibration harvester
- **QEL-F6M-C046** · 2023-10-19T11:33:50.145450-04:00 · Roadway vibration harvester
- **QEL-F6M-C047** · 2023-10-19T11:35:28.429519-04:00 · Energy-harvesting walking cane and assistive wearables
- **QEL-F6M-C048** · 2023-10-19T11:35:42.641771-04:00 · Walking-cane harvester
- **QEL-F6M-C049** · 2023-10-19T11:36:26.958733-04:00 · Lower-extremity support harvester
- **QEL-F6M-C050** · 2023-10-19T11:43:51.224564-04:00 · Safety, regulatory compliance and efficiency requirements
- **QEL-F6M-C051** · 2023-10-19T11:44:11.771815-04:00 · Energy-harvesting gloves and socks
- **QEL-F6M-C052** · 2023-10-19T11:51:16.930044-04:00 · Biomimetic power-plant education kit
- **QEL-F6M-C053** · 2023-10-19T11:54:02.680560-04:00 · Biogenerator and waste-derived energy
- **QEL-F6M-C054** · 2023-10-19T12:08:17.992997-04:00 · Portable yard-waste and recycling system
- **QEL-F6M-C055** · 2023-10-19T12:08:33.016427-04:00 · Yard-waste converter
- **QEL-F6M-C056** · 2023-10-19T12:11:12.022994-04:00 · South Florida waste-to-energy converter
- **QEL-F6M-C059** · 2023-10-19T12:22:56.181222-04:00 · IoT waste collection and dynamic routing
- **QEL-F6M-C060** · 2023-10-19T12:23:13.782321-04:00 · Smart waste collection and routing
- **QEL-F6M-C063** · 2023-10-19T12:58:08.265875-04:00 · Compact and rooftop carbon-capture concept
- **QEL-F6M-C064** · 2023-10-19T12:59:37.235482-04:00 · Locker-sized carbon capture and symbolic model
- **QEL-F6M-C067** · 2023-10-19T13:10:44.324821-04:00 · Sustainable Urban Carbon Neutrality Score concept
- **QEL-F6M-C068** · 2023-10-19T13:10:59.714972-04:00 · Sustainable Urban Carbon Neutrality Score
- **QEL-F6M-C069** · 2023-10-19T13:14:41.485778-04:00 · Quantum Waste Harmonization
- **QEL-F6M-C071** · 2023-10-19T13:55:29.736425-04:00 · Eco-recovery suit line
- **QEL-F6M-C073** · 2023-10-19T14:02:25.761610-04:00 · Space-debris recovery suit/platform
- **QEL-F6M-C081** · 2023-10-19T20:52:09.724983-04:00 · Micro wind and hydro build outlines
- **QEL-F6M-C082** · 2023-10-19T20:52:44.145455-04:00 · Hybrid solar-wind and integrated-blade concepts
- **QEL-F6M-C083** · 2023-10-19T20:54:36.685755-04:00 · Integrated wind/solar designs
- **QEL-F6M-C084** · 2023-10-19T21:02:55.243095-04:00 · Daily-energy target and storage concept
- **QEL-F6M-C085** · 2023-10-19T21:03:04.129017-04:00 · 100-kWh/day hybrid requirement
- **QEL-F6M-C086** · 2023-10-19T21:10:13.751133-04:00 · Alternative household solar-cell draft
- **QEL-F6M-C087** · 2023-10-19T21:10:23.451194-04:00 · Foil-and-plastic solar-panel error
- **QEL-F6M-C088** · 2023-10-19T21:13:16.105076-04:00 · Organic solar panel concept
- **QEL-F6M-C090** · 2023-10-20T23:14:57.852326-04:00 · Disaster-response renewable energy kit
- **QEL-F6M-C091** · 2023-10-21T08:06:57.853369-04:00 · Modular DIY solar-panel design framework
- **QEL-F6M-C094** · 2023-10-21T08:13:16.338902-04:00 · Solar absorber and quantum-dot concept
- **QEL-F6M-C095** · 2023-10-21T08:14:58.430239-04:00 · Layered quantum-dot absorber concept

## Business, funding, attribution and manufacturing plans — 8 chronology rows

- **QEL-F6M-C014** · 2023-10-17T23:35:35.476692-04:00 · Personalization questionnaire and tiered service
- **QEL-F6M-C018** · 2023-10-18T00:03:53.297867-04:00 · Government-contract small-business planning
- **QEL-F6M-C037** · 2023-10-18T00:49:13.206060-04:00 · Sustainable waste-management funding proposals
- **QEL-F6M-C038** · 2023-10-18T00:50:57.322052-04:00 · Sustainable landfill-to-energy proposal
- **QEL-F6M-C057** · 2023-10-19T12:16:06.385422-04:00 · Ownership, invention documentation, confidentiality and rights
- **QEL-F6M-C058** · 2023-10-19T12:16:52.361594-04:00 · Waste-system invention and patent-style documentation
- **QEL-F6M-C092** · 2023-10-21T08:08:24.920962-04:00 · Small-scale manufacturing and compliance plan
- **QEL-F6M-C093** · 2023-10-21T08:09:09.922477-04:00 · Manufacturing compliance and traceable quality process

## Mathematics and science education — 5 chronology rows

- **QEL-F6M-C096** · 2023-10-21T08:15:32.668064-04:00 · Quantum foundations learning notes
- **QEL-F6M-C100** · 2023-10-28T12:04:34.938349-04:00 · Arithmetic distribution exercises
- **QEL-F6M-C101** · 2023-10-28T12:04:36.261524-04:00 · Per-capita division examples
- **QEL-F6M-C110** · 2024-02-12T17:35:55.876541-05:00 · GCD learning example
- **QEL-F6M-C111** · 2024-02-12T17:35:57.977452-05:00 · Greatest-common-divisor exercise

## Health inquiry and science communication — 3 chronology rows

- **QEL-F6M-C097** · 2023-10-26T10:25:22.452831-04:00 · Wellness product research drafts
- **QEL-F6M-C099** · 2023-10-26T11:04:19.576135-04:00 · Symbolic runners-high formula
- **QEL-F6M-C105** · 2024-02-01T10:00:08.295465-05:00 · Breathing-show promotional writing

## Blockchain, digital assets and publication study — 7 chronology rows

- **QEL-F6M-C106** · 2024-02-05T22:10:44.282268-05:00 · Blockchain, centralization, dApps and contracts lessons
- **QEL-F6M-C107** · 2024-02-06T00:38:51.773409-05:00 · Smart-contract reading checklist
- **QEL-F6M-C108** · 2024-02-06T00:39:03.088991-05:00 · Smart-contract reading checklist
- **QEL-F6M-C109** · 2024-02-06T18:50:26.743736-05:00 · Ethereum scaling, Web3, IoT and phone-mining learning
- **QEL-F6M-C112** · 2024-03-09T08:30:47.408081-05:00 · NFT publication workflow study
- **QEL-F6M-C113** · 2024-03-09T08:33:08.437788-05:00 · NFT minting workflow
- **QEL-F6M-C115** · 2024-03-10T10:50:30.679719-04:00 · Crypto and recession scenario learning

## Creative writing and co-writing — 2 chronology rows

- **QEL-F6M-C089** · 2023-10-19T21:45:29.760135-04:00 · Original poem and iterative co-writing
- **QEL-F6M-C114** · 2024-03-09T09:49:00.769120-05:00 · Original lyric seed and rap drafting
