"""Independent catalogue comparison and reconciliation. Private inputs stay private."""
import argparse
import hashlib
import json
from pathlib import Path


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--catalogue', type=Path, required=True)
    p.add_argument('--replay', type=Path, required=True)
    p.add_argument('--f6m-private', type=Path, required=True)
    a = p.parse_args()
    names = ['full-chronology-public.json', 'redaction-ledger.json', 'selection-decisions.json', 'private/private-source-map.json']
    matches = {n: (a.catalogue / n).read_bytes() == (a.replay / n).read_bytes() for n in names}
    assert all(matches.values()), matches
    public = read(a.catalogue / names[0])
    private = read(a.catalogue / names[3])
    prior = read(a.f6m_private)
    ledger = read(a.catalogue / names[1])
    public_rows = public['rows']
    assert len(public_rows) == len(private['rows']) == 348
    assert len(prior['rows']) == 115
    crosswalk = []
    for n, (old, new, pub) in enumerate(zip(prior['rows'], private['rows'], public_rows), 1):
        assert old['original_full_table_row'] == new['raw_row']
        assert old['source_line'] == new['source_line']
        assert pub['id'] == f'QEL-SER-C{n:03d}'
        assert pub['f6m_crosswalk'] == old['editorial_id']
        crosswalk.append({'id': pub['id'], 'f6m_id': old['editorial_id']})
    changed = []
    change_keys = {(r['id'], r['field']) for r in ledger['changes']}
    for n, (pub, original) in enumerate(zip(public_rows, private['rows']), 1):
        assert pub['id'] == original['id'] == f'QEL-SER-C{n:03d}'
        headers = original['source_headers']
        values = original['raw_cells']
        assert len(headers) == len(values) == 5
        assert list(pub['source_fields_first_four']) == headers[:4]
        assert (pub['id'], headers[4]) in change_keys
        for header, value in zip(headers[:4], values[:4]):
            if pub['source_fields_first_four'][header] != value:
                assert (pub['id'], header) in change_keys
                changed.append({'id': pub['id'], 'field': header})
        assert headers[4] not in pub['source_fields_first_four']
    source = Path(private['source_absolute_path'])
    assert sha(source) == private['source_sha256']
    receipt = {
        'status': 'PASS',
        'reproduced_bytes_match': matches,
        'source_sha256_unchanged': True,
        'rows_reconciled': 348,
        'first_six_month_rows_and_exact_private_originals_matched': 115,
        'first_four_changed_fields_explained_by_redaction_ledger': len(changed),
        'all_fifth_fields_omitted_and_ledger_accounted': True,
        'public_projection_sha256': sha(a.catalogue / names[0]),
        'scope': 'Documentary extraction, byte reproduction, crosswalk and recorded redaction reconciliation only; no new verification of original messages, technical assertions, execution or comprehensive coverage.',
    }
    output = a.catalogue / 'independent-replay-verification.json'
    output.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    assert read(output) == receipt
    print(json.dumps(receipt, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
