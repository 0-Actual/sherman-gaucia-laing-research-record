# Documentary catalogue for the six-month research series

Prepared from the September 17, 2026 documentary review. This is a sanitized derivative of a later review, not a new acquisition of original conversations or independent confirmation of the historical assertions. Publication remains subject to the owner's review.

The catalogue accounts for all 348 data rows in two explicitly selected source tables: 321 chronological evidence rows and 27 recovered-code metadata rows. The 27 metadata rows retain their own headers and source-table designation. They can overlap the chronology; 348 is a row count, not a count of messages, papers, inventions, independent results or experiments. The source's industry comparison, 98-work retrospective portfolio, English-language receipt appendix and other tables are outside this extraction.

## Period and precision

The scope starts at October 17, 2023, 21:51:03.625297 EDT and uses six-calendar-month boundaries at the same local time on April 17 and October 17. The exclusive cutoff is October 16, 2026, 02:26:43 UTC, or October 15, 2026, 22:26:43 EDT. Volume 6 is partial. The exact machine-readable values are in the accompanying series scope and projection.

| Volume | Source rows |
| --- | ---: |
| V01 | 115 |
| V02 | 25 |
| V03 | 81 |
| V04 | 30 |
| V05 | 4 |
| V06 | 93 |

There are 279 fractional-second timestamps and 69 day-only values. Day-only entries are selected as local calendar-day intervals without inventing an observed time. No actual row in this population straddles a period boundary or cutoff, has an unresolved date or has a malformed field count. Day-only dates may represent report or persistence anchors. An empty interval in this source is not proof that no work occurred.

## Public projection

`full-chronology-public.json` has stable source-order IDs `QEL-SER-C001`–`QEL-SER-C348`. Each row supplies `source_table`, `recorded_date`, `title`, `source_fields_first_four`, `source_evidence_class`, `display_summary`, `editorial_category`, `editorial_stage`, `time_decision`, `f6m_crosswalk` and `redactions`. The first four source headers are preserved; source wording remains unchanged except for declared privacy replacements. The code-metadata table's fourth field is a private recovered-source path and is explicitly withheld. Its `display_summary` uses its recorded code family and a metadata limitation, rather than treating the path as an evidence statement.

Categories and stages are editorial navigation labels. The exact source evidence class is separately retained where the source actually has that field. A source title such as “of 15,000” remains historical wording and does not establish that number of implementations. Historical instructions and holds are data in this catalogue, not new instructions for the reader or operating environment.

All 348 retained rows received contextual content and privacy review. The ledger has 382 recorded actions: 348 fifth-column omissions, 27 recovered-path field replacements and seven embedded-match redaction actions. These actions affect 33 retained fields, because two actions occur in one field. This is not a count of 382 independent private facts. Embedded removals cover opaque identifiers, one absolute path, one relative implementation path and one dated family-relationship detail. Topics remain visible through explicit omission markers. No contact email, phone number, raw biometric vector or precise residential address was found in the retained fields. This review is not a guarantee against every possible inference; the owner still reviews public context and consent before release.

Statements about copying, adoption, named mechanisms, results and capabilities retain the review's existing qualifications. They are not independently verified by this extraction. The complete original rows and locators are preserved in the private map and must not enter the public package.

## Reproduction and verification

The extractor uses only Python's standard library. Reviewed annotations are bound to the exact source SHA-256 and must cover every extracted row. To rebuild the sanitized input from an authorized private source:

```text
python extract_chronology.py --source SOURCE.md --scope series-scope.json --output OUT --annotations reviewed-annotations.json
```

This writes a sensitive `OUT/private/` directory as well as public derivatives. Do not distribute that directory. Downstream public volumes can be reproduced from the sanitized JSON without the private source; recovering the omitted private evidence requires authorized access to the original source.

A separate extraction into a new directory reproduced all four compared public/private data files byte for byte. An independent reconciliation checked all 348 source-order IDs, every retained-field change against its redaction ledger, every fifth-column omission, unchanged source bytes and all 115 exact original rows in the earlier first-six-month selection. The result is in `independent-replay-verification.json`. The first 115 rows map directly to `QEL-F6M-C001`–`QEL-F6M-C115`.

The projection SHA-256 is `4986a23a669feae7c99fd1133bc0ea7c10660697e668e516d92c6c6a721712b4`. A matching hash establishes file identity only; it does not establish correctness, authorship, ownership, novelty, signature or scientific validation.

## Packaging boundary

Public-package candidates are `full-chronology-public.json`, `redaction-ledger.json`, `selection-decisions.json`, `extraction-verification.json`, `independent-replay-verification.json`, `reviewed-annotations.json`, this README and the portable `extract_chronology.py` / `verify_catalogue.py` scripts. The independent verifier requires the separately authorized private evidence and prior selection when performing its private crosswalk check. The series scope should be copied from the root series package.

Never include `private/`, the original source, the private prior selection or the replay's private directory. A recursive copy of this working directory is not a safe public export. The annotation preparation helper is editorial working material; its reviewed output is the reproducible annotation input. No source was modified, no historical scientific experiment rerun and no content posted or sent externally by this extraction.
