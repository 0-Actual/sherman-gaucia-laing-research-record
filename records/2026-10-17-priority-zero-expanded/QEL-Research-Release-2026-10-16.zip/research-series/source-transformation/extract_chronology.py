"""Portable stdlib-only documentary projection; never execute source material.

Usage: python extract_chronology.py --source SOURCE.md --scope SCOPE.json --output OUT
Optional: --annotations reviewed-annotations.json
The output/private directory contains sensitive exact originals. Do not publish it.
"""
import argparse
import collections
import hashlib
import json
import re
from datetime import datetime, timedelta
from pathlib import Path

UUID = re.compile(r'\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b', re.I)
EMAIL = re.compile(r'(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}(?!\w)', re.I)
ABS_PATH = re.compile(r'(?i)(?:[A-Z]:[\\/]|/(?:mnt|home|Users|tmp)/)[^\s|;<>]*')
REL_PRIVATE_PATH = re.compile(r'\b(?:runtime|sources|work|works|private)/[A-Za-z0-9_.@+/-]+')
DATED_PERSONAL_REFERENCE = re.compile(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2}\s+\d{4}\s+(?:wife|husband|spouse|child|daughter|son)\s+reference\b', re.I)
TABLES = {
    'Chronological evidence entries': {
        'kind': 'chronological_evidence',
        'headers': ['Date / precision as recorded', 'Work or event', 'Evidence class', 'Supported content and boundary', 'Source locator'],
    },
    'All 27 recovered March2025 code bodies': {
        'kind': 'historical_code_metadata',
        'headers': ['Original timestamp (Eastern)', 'Historical title', 'Actual family in source analysis', 'Recovered source path', 'Original message IDs'],
    },
}

def split_row(line):
    return [x.strip() for x in re.split(r'(?<!\\)\|', line)[1:-1]]

def period_decision(value, scope):
    bounds = [datetime.fromisoformat(s) for s in scope['period_boundaries']]
    cutoff = datetime.fromisoformat(scope['cutoff_exclusive'])
    try:
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
            day_start = datetime.fromisoformat(value)
            day_end = day_start + timedelta(days=1)
            # Work in local calendar order, without converting a day into an observed instant.
            local_bounds = [x.replace(tzinfo=None) for x in bounds]
            local_cutoff = datetime.fromisoformat(scope['cutoff_eastern']).replace(tzinfo=None)
            volumes = [f'V{i+1:02d}' for i, (a, b) in enumerate(zip(local_bounds, local_bounds[1:])) if day_start < min(b, local_cutoff) and day_end > a]
            truncated = day_start < local_cutoff < day_end
            return {
                'precision': 'day', 'date_as_recorded': value,
                'possible_volumes': volumes,
                'assigned_volume': volumes[0] if len(volumes) == 1 and not truncated else None,
                'status': 'outside_cutoff' if not volumes else 'boundary_uncertain' if len(volumes) > 1 or truncated else 'assigned_by_day_interval',
                'interpretation': 'Whole America/New_York calendar day for selection; no observed hour or UTC timestamp invented. The source day can be a report/persistence anchor rather than event execution.',
            }
        instant = datetime.fromisoformat(value.replace('Z', '+00:00'))
        if instant.tzinfo is None:
            return {'precision': 'unresolved_timezone', 'date_as_recorded': value, 'assigned_volume': None, 'possible_volumes': [], 'status': 'unresolved'}
        volumes = [f'V{i+1:02d}' for i, (a, b) in enumerate(zip(bounds, bounds[1:])) if a <= instant < min(b, cutoff)]
        return {'precision': 'fractional_second' if '.' in value.split('T')[-1] else 'second', 'date_as_recorded': value, 'assigned_volume': volumes[0] if volumes else None, 'possible_volumes': volumes, 'status': 'assigned_exact_recorded_instant' if volumes else 'outside_cutoff', 'interpretation': 'Recorded timestamp, not independently authenticated execution or publication time.'}
    except (ValueError, TypeError):
        return {'precision': 'unresolved_date_or_interval', 'date_as_recorded': value, 'assigned_volume': None, 'possible_volumes': [], 'status': 'unresolved', 'interpretation': 'No automatic midpoint, boundary or timezone invented.'}

def default_category(title, body, kind):
    text = (title + ' ' + body).lower()
    if kind == 'historical_code_metadata':
        return 'Mathematical and computational research'
    rules = [
        ('Biblical study and source discipline', r'\bbible\b|\bbiblical\b|\bgenesis\b|\bscriptur|\bhebrew\b|word_core|creation week|\bisaiah\b|\bjob and|cain/abel|word.first'),
        ('QPRINT, integrity and archival methods', r'qprint|qpr2|cueprint|sgl.?prime|sglp3|cryptographic|carrier|fingerprint|content.verif|integrity profile|normalization candidate'),
        ('Mathematical and computational research', r'qubit|qpu|\bquantum\b|\bemulat|\bsimulat|matrix|tensor|entropy|numerical|ramsey|circuit|arithmetic|greatest.common|\bgcd\b|math|state.transition|coherence'),
        ('Operating environment and software reliability', r'\blaptop\b|\bphone\b|runtime|gateway|\bdevice\b|\bq7\b|\bq8\b|\busb\b|windows|watchdog|working environment|owner.controlled operating'),
        ('Research history, publication and evidence methods', r'chronolog|\barchive\b|\bpublication\b|prior.art|source.recovery|source.custody|evidence.register|artifact|audit|portfolio|inventory|lineage|source metadata'),
        ('Human–AI interaction, governance and continuity', r'\bassistant\b|\bagent\b|\bgaucia\b|\bthunder\b|continuity|governance|human|owner|personaliz|privacy|oversight|consent|truthful|authority|learning|feedback|interaction|cross.session'),
        ('Agriculture, energy, environment and device concepts', r'nursery|greenhouse|solar|waste|carbon|energy|harvest|garden|climate|wind|wearable|suit|exoskeleton|waterwheel|stirling|environmental'),
        ('Blockchain and digital-asset study', r'blockchain|ethereum|\bnft\b|\bcrypto\b|smart.contract|web3|dapps'),
        ('Business, policy and attribution', r'business|funding|grant|patent|veteran|policy|ownership|attribution|rights|manufactur'),
        ('Creative writing and explanatory work', r'poem|lyric|writing|rap |fiction|teaching|educat|lesson|show|wellness|physiol'),
    ]
    for name, pattern in rules:
        if re.search(pattern, text):
            return name
    return 'Other documented research or requirements'

def default_stage(evidence, kind):
    text = evidence.lower()
    if kind == 'historical_code_metadata':
        return 'Historical source metadata; source implementation withheld'
    if 'original assistant artifact' in text:
        return 'Historical assistant artifact described by later review'
    if 'original_visible_user_message' in text or 'user naming record' in text:
        return 'Research direction, inquiry, concept or draft'
    if 'source_review' in text or 'assistant_audit' in text:
        return 'Historical assistant source-review account; underlying results separate'
    if 'assistant_status' in text or 'delivery_report' in text or 'verification claims' in text or 'activation claim' in text:
        return 'Historical assistant status or capability claim; validation separate'
    if 'scheduled-message' in text:
        return 'Recorded scheduling or recurring prompt; continuous execution unverified'
    if any(s in text for s in ['tool', 'executed', 'execution record']):
        return 'Historical tool or execution record described by later review'
    if any(s in text for s in ['report', 'receipt', 'retained', 'register', 'current completed review']):
        return 'Retained report, artifact or test summary'
    if any(s in text for s in ['code', 'source', 'implementation']):
        return 'Source expression or implementation draft; execution separate'
    if any(s in text for s in ['failure', 'correction', 'observed-conversation']):
        return 'Recorded interaction or correction sequence'
    if any(s in text for s in ['request', 'directive', 'requirement', 'inquiry', 'concept', 'design', 'research/work', 'fiction']):
        return 'Research direction, inquiry, concept or draft'
    return 'Historical evidence summary; retain exact source class'

def run(args):
    source = Path(args.source)
    raw = source.read_bytes()
    lines = raw.decode('utf-8-sig').splitlines()
    scope = json.loads(Path(args.scope).read_text(encoding='utf-8-sig'))
    annotations = json.loads(Path(args.annotations).read_text(encoding='utf-8-sig')) if args.annotations else {'rows': {}}
    if annotations.get('source_sha256'):
        assert annotations['source_sha256'] == hashlib.sha256(raw).hexdigest(), 'Reviewed annotations belong to another source version'
    out = Path(args.output)
    private_dir = out / 'private'
    private_dir.mkdir(parents=True, exist_ok=True)
    public_rows, private_rows, redactions, decisions = [], [], [], []
    section = ''
    outside_table_counts = collections.Counter()
    malformed = []
    for lineno, line in enumerate(lines, 1):
        if line.startswith('## '):
            section = line[3:]
        if not line.startswith('| '):
            continue
        cells = split_row(line)
        if section not in TABLES:
            if cells and not all(re.fullmatch(r'[-: ]+', c) for c in cells):
                outside_table_counts[section] += 1
            continue
        if cells == TABLES[section]['headers'] or all(re.fullmatch(r'[-: ]+', c) for c in cells):
            continue
        # Include every data row in the two explicitly selected source tables, even malformed dates.
        rid = f'QEL-SER-C{len(private_rows)+1:03d}'
        table = TABLES[section]
        if len(cells) != 5:
            malformed.append({'id': rid, 'line': lineno, 'field_count': len(cells)})
            private_rows.append({'id': rid, 'source_line': lineno, 'source_section': section, 'raw_row': line, 'raw_cells': cells, 'raw_cells_with_padding': re.split(r'(?<!\\)\|', line)[1:-1], 'status': 'malformed'})
            decisions.append({'id': rid, 'status': 'malformed_field_count', 'assigned_volume': None})
            continue
        private_rows.append({'id': rid, 'source_line': lineno, 'source_section': section, 'source_headers': table['headers'], 'raw_row': line, 'raw_cells': cells, 'raw_cells_with_padding': re.split(r'(?<!\\)\|', line)[1:-1], 'source_locator_or_message_ids': cells[4]})
        first4 = cells[:4].copy()
        own_redactions = [{'id': rid, 'field': table['headers'][4], 'action': 'omit_column', 'reason': 'Private source locator or original-message identifiers withheld', 'replacement': None}]
        if table['kind'] == 'historical_code_metadata':
            first4[3] = '[private recovered-source path withheld]'
            own_redactions.append({'id': rid, 'field': table['headers'][3], 'action': 'replace_field', 'reason': 'Recovered development-source location withheld; source family remains represented', 'replacement': first4[3]})
        annotation = annotations.get('rows', {}).get(rid, {})
        for pos, value in enumerate(first4):
            for pattern, marker, reason in [
                (UUID, '[private identifier omitted]', 'Opaque or image-derived identifier withheld'),
                (EMAIL, '[contact address omitted]', 'Contact detail withheld'),
                (ABS_PATH, '[private filesystem path omitted]', 'Private absolute filesystem location withheld'),
                (REL_PRIVATE_PATH, '[private implementation path omitted]', 'Private relative implementation/source location withheld'),
                (DATED_PERSONAL_REFERENCE, '[private personal-reference detail omitted]', 'Dated family-relationship reference withheld; project-role distinction preserved'),
            ]:
                value, n = pattern.subn(marker, value)
                if n:
                    own_redactions.append({'id': rid, 'field': table['headers'][pos], 'action': 'replace_matches', 'reason': reason, 'replacement': marker, 'match_count': n})
            for change in annotation.get('redactions', []):
                if change['field_index'] == pos:
                    old = change['match']
                    assert old in value, (rid, pos, 'reviewed redaction match absent')
                    n = value.count(old)
                    value = value.replace(old, change['replacement'])
                    own_redactions.append({'id': rid, 'field': table['headers'][pos], 'action': 'reviewed_replacement', 'reason': change['reason'], 'replacement': change['replacement'], 'match_count': n})
            first4[pos] = value
        decision = period_decision(cells[0], scope)
        decision['id'] = rid
        decisions.append(decision)
        category = annotation.get('category', default_category(first4[1], first4[3], table['kind']))
        stage = annotation.get('stage', default_stage(first4[2], table['kind']))
        row = {
            'id': rid, 'source_table': table['kind'], 'recorded_date': first4[0], 'title': first4[1],
            'source_fields_first_four': dict(zip(table['headers'][:4], first4)),
            'source_evidence_class': first4[2] if table['kind'] == 'chronological_evidence' else None,
            'display_summary': first4[3] if table['kind'] == 'chronological_evidence' else 'Historical source family: ' + first4[2] + '. [Private recovered-source path withheld.] Metadata does not establish execution or named scientific behavior.',
            'editorial_category': category, 'editorial_stage': stage,
            'editorial_label_basis': 'Reviewer navigation labels; not original evidence classes, scientific certification or independent counts',
            'time_decision': decision,
            'f6m_crosswalk': f'QEL-F6M-C{len(public_rows)+1:03d}' if table['kind'] == 'chronological_evidence' and len(public_rows) < 115 else None,
            'redactions': own_redactions,
        }
        public_rows.append(row)
        redactions.extend(own_redactions)

    if annotations.get('rows'):
        assert set(annotations['rows']) == {r['id'] for r in public_rows}, 'Reviewed annotation IDs differ from extracted rows'
    document = {
        'schema': 'qel-research-series-full-chronology-projection/1',
        'source_report_title': lines[0].lstrip('# '), 'source_report_date': '2026-09-17',
        'source_sha256': hashlib.sha256(raw).hexdigest(),
        'scope': {k: scope[k] for k in ['start_inclusive', 'cutoff_exclusive', 'cutoff_eastern', 'calendar_timezone', 'period_boundaries']},
        'source_tables': [{'source_section': s, 'kind': t['kind'], 'original_headers': t['headers']} for s, t in TABLES.items()],
        'projection_disclaimer': 'Later documentary review, not newly recovered raw interactions or fresh scientific validation. First four source fields are retained with declared privacy redactions; the fifth private-locator column is omitted. The 27 code-metadata rows retain their distinct schema, and their recovered-source paths are also withheld. Editorial labels do not rewrite source classes. Source chronology and code-metadata rows may overlap; they are not additive invention, paper, message or independent-result counts.',
        'historical_title_warning': 'The phrase of 15,000 in original algorithm titles is retained historical wording, not evidence of 15,000 implementations. Named mechanisms require their own evidence. The 27 metadata rows are not 27 new experiments.',
        'annotation_review': annotations.get('review_scope', 'Automated navigation labels pending contextual review'),
        'selected_table_population': len(private_rows), 'public_row_count': len(public_rows),
        'source_table_counts': dict(collections.Counter(r['source_table'] for r in public_rows)),
        'period_counts': dict(collections.Counter(r['time_decision']['assigned_volume'] or r['time_decision']['status'] for r in public_rows)),
        'date_precision_counts': dict(collections.Counter(r['time_decision']['precision'] for r in public_rows)),
        'outside_table_scope': 'Industry comparisons, the 98-work retrospective portfolio, English-language receipt-date appendix and other tables are not silently treated as additional project events in this 348-row selection.',
        'rows': public_rows,
    }
    private = {'classification': 'PRIVATE: original source rows and locators; do not include in public package', 'source_absolute_path': str(source.resolve()), 'source_sha256': hashlib.sha256(raw).hexdigest(), 'rows': private_rows, 'excluded_table_line_counts_including_headers': dict(outside_table_counts), 'malformed_rows': malformed}
    artifacts = {
        out / 'full-chronology-public.json': document,
        private_dir / 'private-source-map.json': private,
        out / 'redaction-ledger.json': {'schema': 'qel-research-series-redactions/1', 'original_values_retained_privately': True, 'changes': redactions},
        out / 'selection-decisions.json': {'schema': 'qel-research-series-chronology-decisions/1', 'decisions': decisions},
    }
    for path, obj in artifacts.items():
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    assert source.read_bytes() == raw
    loaded = json.loads((out / 'full-chronology-public.json').read_text(encoding='utf-8'))
    assert loaded == document
    texts = json.dumps(document) + json.dumps(artifacts[out / 'redaction-ledger.json'])
    assert not UUID.search(texts)
    assert not EMAIL.search(texts)
    assert not ABS_PATH.search(texts)
    assert not REL_PRIVATE_PATH.search(texts)
    assert not DATED_PERSONAL_REFERENCE.search(texts)
    receipt = {'status': 'PASS_FOR_EXTRACTION_SAVE_READBACK_AND_AUTOMATED_LOCATOR_SCREEN', 'source_unchanged': True, 'source_rows_accounted': len(private_rows), 'public_rows': len(public_rows), 'decision_count': len(decisions), 'malformed_row_count': len(malformed), 'source_table_counts': document['source_table_counts'], 'period_counts': document['period_counts'], 'date_precision_counts': document['date_precision_counts'], 'redaction_actions': len(redactions), 'category_counts': dict(collections.Counter(r['editorial_category'] for r in public_rows)), 'public_artifact_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts if p.parent == out}, 'limit': 'Automated screen is not an exhaustive privacy review; reviewed annotations and human-context inspection are separate.'}
    (out / 'extraction-verification.json').write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(json.dumps({k: v for k, v in receipt.items() if k not in ['category_counts', 'public_artifact_sha256']}, ensure_ascii=True, indent=2))

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    parser.add_argument('--scope', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--annotations')
    run(parser.parse_args())
