# Prepared public source companions

Prepared October 15, 2026 for owner review. This preparation verifies source bytes, preserves existing receipts and performs an isolated Bible packaging replay. It does not execute a new scientific study or publish anything.

## Bible: executable offline replay subset

`bible-replay/` contains 35 exact public files from `0-Actual/sherman-gaucia-laing-bible-replay` at commit `f15f6127c3538b338d9462ad8b52e9d137ebab30`: the replay and verification programs, reference engine, tests, all six studies in both Markdown and JSON, notices, and selected historical receipts. `SOURCE-IDENTITY.json` binds each saved file to its Git blob, byte count and SHA-256.

The selected source paths required by `replay.py`, `test_replay.py` and `verify.py` are present. This is a subset of the repository, not its browser application or a complete Git clone. Some inherited README links describe files outside this subset; use the pinned upstream repository for that broader context. The code is unchanged. On a disposable copy, with Python 3.10 or later, the upstream entry points are:

```text
python replay.py
python test_replay.py
python verify.py
```

Run from the `bible-replay` directory. These commands write new replay/verification artifacts. Preserve the included historical `replay-output` receipts before a future run. The newly packaged selection was tested on a separate copy at 2026-10-16T02:42:45–02:42:59 UTC (October 15 local time): 113 source comparisons, 36 adapter test methods and 40 selected recovered WORD_CORE methods passed. All 35 shipped source files remain unchanged. See `BIBLE-PACKAGING-CHECK.json` for the new receipt, distinct from upstream historical receipts.

The first attempt passed the 113 source comparisons but failed while creating test fixtures in the Windows sandbox temporary directory. Its failure receipt remains private. The successful attempt used a writable workspace temporary folder scoped to the child process; no source patch was needed. Integrated verification selects 40 of the recovered 43 WORD_CORE methods; the three excluded methods concern archival fingerprints. The integration adapter was authored September 17 and repaired September 20; it is not the missing historical v1 implementation. This replays saved text and arithmetic, not original model inference or a theological proof. See the exact retained `LICENSE.md`, `ATTRIBUTION.md` and `THIRD_PARTY_NOTICES.md` for scope and attribution.

## JARVIS 2D: public evidence packet

`jarvis-2d/` contains ten exact public files from `0-Actual/sherman-gaucia-laing-research-record` at commit `f56f010386cb5d08c2c1f0168f7627fe81186463`, including all six published study/evidence files and four license/attribution/source/disclosure notices.

The September 18 study reviews 1,103 records in the declared JARVIS-DFT 2D source. It is separate from the September 28 aluminum VQD work. Its primary data citation is Kamal Choudhary, Figshare DOI `10.6084/m9.figshare.6815705.v8`, file `d2-12-12-2022.json.zip` (file ID 38521268), CC BY 4.0 as stated in the source. Retain the source attribution and distinguish derived analysis from the underlying data.

This public evidence packet is not a self-contained executable reproduction bundle: the private analysis programs and full input archive are not among these ten files. The earlier public receipt describes a successful deterministic replay; reading and preserving that receipt is not a fresh replay. The unresolved 1,103-versus-1,109 catalog population difference and the paper's individual ambiguity limits remain. No new DFT calculations, physical QPU use, universal materials conclusion or independent certification is established.

## Identity and scope

All 45 copied upstream files match their pinned Git blob IDs and byte lengths (1,095,844 bytes total). The count is files, not experiments. New wrapper documentation and manifests are clearly separate from unchanged upstream files. No private conversation corpus, biometric opening, credential, or raw laptop inventory is included in these public source companions.
