> **Public-review derivative, prepared 2026-10-15 (America/New_York). Not published.**
> The complete main-body paragraphs and table text below come from the unchanged 2026-08-11 DOCX; running page headers/footers are omitted. Historical status, wording, references and counts remain historical. Original figures are replaced by new text diagrams in the dated addendum. Abbreviated private-source digests are withheld; the exact source text and change record remain private. The source register identifies supporting materials; it does not include their raw contents. External references are the historical bibliography and have not been recertified as current guidance.

# White Paper: Signed Provenance, Trust Kernel, and Software Supply Chain

Canonical manifests, receipted execution, tamper-evident ledgers, and signed releases for QEL

| Project | Project Quantum.Earth.Laing / Q6.1 |
| --- | --- |
| Author / Root Source | Sherman G. Laing |
| Audit Date | 2026-08-11 |
| Artifact ID | QEL-WP-PROVENANCE-V1 |
| Status | UNSIGNED AUDIT BUILD - operator signature not present |
| Sovereignty Ruling | NOT ACHIEVED - reference remediation supplied |

Evidence first. Internal origin remains the starting point. Capability claims advance only when artifacts, tests, metrics, and signed release evidence exist.

## Contents

Abstract

Existing Q6 foundation

Audit gaps

Canonical object model

Release and update protocol

Legacy migration

Reference implementation and tests

Standards mapping

References

## Abstract

Q6 already defines the right primitives: ContributionReceipt, DataControlState, TrustGate, ProofPacket, ShellExecutionReceipt, QPRINT/AuthChain, claim grading, rollback, and source-first custody. The current weakness is not the absence of a governance idea; it is that hashes, ordinary files, demo secrets, mutable ledgers, and inconsistent manifests do not yet provide release authenticity or compromise-resilient custody. This paper turns the object model into a signed supply-chain protocol. [S08] [S09]

## Existing Q6 Foundation

| Object | Current value | Required production extension |
| --- | --- | --- |
| ContributionReceipt | Freezes contributor, artifact, hash, data-control state | Operator/platform signature, immutable anchor, license/consent version |
| DataControlState | Separates training/eval/product/human/external use | Enforced policy, explicit transitions, revocation and reason |
| TrustGate | Allow/pause/escalate/block decision | Mandatory pre-action hook, signed policy version, OS capability enforcement |
| ProofPacket | Source IDs, claim map, transform ledger, output hash | Canonical schema, signatures, false-positive exclusions, records-to-request, verifier results |
| ShellExecutionReceipt | Command/workspace/network/output/rollback intent | Host-collected network/process evidence and signed checkpoint |
| QPRINT/AuthChain | Creator/source/lifecycle/trace metadata | Public/private split, role keys, threshold signatures, update/revocation semantics |
| SimilarityReview | Grades external overlap and questions | Discovery-grade access/derivation records before legal conclusion |

## Audit Gaps

- SHA256SUMS verifies integrity only if the checksum file is already trusted; it does not authenticate the releaser.

- The Trust Kernel demo uses SHA256(secret + payload), not a standard public-verifiable signature.

- SQLite and JSONL ledgers are mutable; a valid truncated prefix cannot be detected without an external head.

- Manifest schemas differ, and the V0.2 manifest contains an invalid self-reference.

- The biometric manifest self-hash depends on undocumented pretty-JSON serialization rather than a declared canonical profile.

- Legacy loaders/builders do not safely handle paths, symlinks, bombs, limits, secrets, or reproducibility.

- Update clients do not prevent rollback, freeze, mix-and-match, or key-compromise scenarios.

[Original figure replaced by the newly prepared text diagram in the dated addendum.]

## Canonical Object Model

### Canonical JSON v1

Signed objects use UTF-8, sorted keys, compact separators, no NaN/Infinity, and no floating-point values. Decimal quantities are strings or scaled integers. This produces one digest across compliant implementations.

### Release Manifest

Contains release ID, source epoch, explicit sorted files, bytes, SHA-256, media type, gates, and provenance. It never lists itself. Its payload digest is computed after removing the digest field. The signature is detached.

### Signature Envelope

An Ed25519 signature covers a statement containing algorithm, key ID, payload SHA-256, purpose, and signing time. Verification requires the external trusted public key and expected purpose.

### Ledger Event

Contains ledger ID, sequence, prior event hash, timestamp, actor key ID, payload hash, payload, and event hash. A signed external head is required to detect truncation.

### ProofPacket

Binds source receipts, release manifest, human/AI separation, transform steps, claim grade, public comparator map, false-positive exclusions, rollback state, audit results, and signatures.

### Visual Authorization Commitment

Uses randomized salt so the same image produces different public commitments. Stable image/perceptual hashes remain in an encrypted private opening, not a public receipt.

## Release and Update Protocol

1. Select files from a human-reviewed relative-path allow-list. Reject secrets, unsupported licenses, links, paths outside root, and size/count limits.

1. Generate canonical manifest, test log, SBOM, build provenance, data-classification report, metrics, and rollback pointer.

1. Verify every file against the manifest and run deterministic double-build comparison using SOURCE_DATE_EPOCH. [R08]

1. Run TrustGate. audit_ok, manifest_ok, metrics_ok, rollback_available, authorized_signer, and zero unresolved critical findings are mandatory.

1. Sign the canonical manifest with operator-controlled Ed25519/hardware key; high-risk releases require threshold signatures. [R09]

1. Publish release, signatures, public keys, revocation metadata, SBOM, provenance, and human-readable ProofPacket.

1. Client validates archive safety, signatures, role thresholds, version monotonicity, expiration, consistent snapshot, file hashes, and policy before installation. TUF addresses rollback, freeze, mix-and-match, key compromise, and endless-data risks. [R07]

1. Append a release event and signed ledger head; copy the checkpoint and release to immutable/offline storage.

## Legacy Migration

| Legacy object | Treatment |
| --- | --- |
| V0.1/V0.2 packages | Preserve immutable; do not silently rewrite. Create a migration ProofPacket referencing original hash. |
| V0.2 self-referential manifest | Remove self row in migrated payload; record original mismatch; sign new detached manifest only after verification. |
| SHA256SUMS-only releases | Classify as CHECKSUM_ONLY_LEGACY; require new signed wrapper for future distribution. |
| Mutable SQLite/JSONL ledgers | Import as source evidence; append import event to new chain; anchor the new head. |
| Biometric tether receipts | Quarantine as restricted legacy evidence; stop publishing stable image hashes; issue revocation/correction note. |
| Missing Chat Set B | Do not infer content. Recover exact hash/size, index separately, and run conflict testing. |

## Reference Implementation and Tests

The supplied code includes canonicalization, encrypted key generation, detached Ed25519 signatures, explicit manifests, safe deterministic ZIPs, safe extraction, secret scanning, a hash-chain ledger, TrustGate, release verification, AES-256-GCM vault objects, randomized visual commitments, AF_UNIX-only model adapter, systemd hardening, and migration patches. Twenty-six unit tests pass, including tamper, wrong-key, traversal, symlink, archive, deterministic-build, ledger mutation/truncation, vault tamper, biometric privacy, release gate, and rollback tests. [S15]

## Standards Mapping

| QEL control | External reference |
| --- | --- |
| Resource-centric explicit authorization | NIST SP 800-207 zero trust [R01] |
| Secure development and AI lifecycle practices | NIST SP 800-218 / 800-218A [R02] [R03] |
| Build provenance levels and verification | SLSA v1.1 [R05] |
| Authorized signed steps and material/product links | in-toto [R06] |
| Role separation, thresholds, expiration, rollback/freeze defense | TUF [R07] |
| Reproducible timestamps | SOURCE_DATE_EPOCH [R08] |
| Blob signatures and hardware keys | Sigstore/Cosign [R09] |

| Boundary of this document<br>This document is an audit, architecture, and tested reference implementation package. It is not an operator-signed QEL release, does not establish that an external party copied or used QEL work, and does not claim that a standalone AI model is present. Legal conclusions and current regulatory facts require primary-source verification in the relevant jurisdiction. |
| --- |

## Source Register

### Internal and project sources

[S01] conversations-000.json. Recovered conversation export input; SHA-256 [private source digest withheld].

[S02] conversations-001.json. Recovered conversation export input; SHA-256 [private source digest withheld].

[S03] SGL_WORKS_INVENTORY_AND_PROOF_OF_WORK_REGISTER_V1. Formal 98-work seed register, 2026-05-21.

[S04] Q6_1_CONTINUATION_PACKAGE_V0_1.zip. Continuation state, correction log, source index, intake protocol, and revised paper scope.

[S05] Q6_1_CHAT_SET_B_CLEAN_HANDOFF_V1_EXTERNAL_RECEIPT.json. Receipt for absent raw Chat Set B ZIP: 208,209,215 bytes; SHA-256 [private source digest withheld].

[S06] SGL_QEL_SINGLE_SHELL_HANDOFF_20260524T044506Z.zip. Single-shell handoff; SHA-256 [private source digest withheld].

[S07] QEL_GAUCIA_TS2124_BIOMETRIC_TETHER_AUTH_PACKAGE.zip. Visual/biometric-related receipts and 5,000 synthetic tether records; SHA-256 [private source digest withheld].

[S08] Q6 Trust Kernel MVP v1. Runnable ContributionReceipt, DataControlState, TrustGate, ProofPacket, SimilarityReview, SQLite, JSON/PDF prototype.

[S09] Q6 Publication Packet - Three Paper Set. Contribution rights, TrustGate/ShellExecutionReceipt, and QPRINT/ProofPacket papers.

[S10] Q6_1_GLOBAL_WEATHER_MODEL_CHRONOLOGICAL_AUDIT_V1. Chronological ruling that the requested global weather model was not delivered.

[S11] Q6_1_PRESSURE_TWIN_ENGINE_V0_1_DETACHED_RECEIPT. 22-file, 7/7 tested replay/adaptive-pressure engine; not a validated global forecast.

[S12] Q6_1 United States Off-Grid Living and Build-Site Atlas v0.1.0. National schema/work queue with legacy geometry warning and parcel gates.

[S13] QEL Genesis Creation Week Clean Coherence Set v1. 51-page tested Genesis package; 20/20 tests; source/calculation/interpretation separation.

[S14] Q6_1 Logistics Knowledge Database V6. Florida expediting/courier/light-freight database with explicit operational gates.

[S15] QEL Sovereign Security Audit execution records. Package audit JSON, source hashes, hardened code, 26-test log, and registers in this delivery.

### External standards and primary references

[R01] NIST SP 800-207, Zero Trust Architecture. https://csrc.nist.gov/pubs/sp/800/207/final

[R02] NIST SP 800-218, Secure Software Development Framework v1.1. https://csrc.nist.gov/pubs/sp/800/218/final

[R03] NIST SP 800-218A, Secure Software Development Practices for Generative AI. https://csrc.nist.gov/pubs/sp/800/218/a/final

[R04] NIST SP 800-63B-4, Authentication and Authenticator Management. https://csrc.nist.gov/pubs/sp/800/63/b/4/final

[R05] SLSA Specification v1.1. https://slsa.dev/spec/v1.1/

[R06] in-toto Getting Started / signed layouts and links. https://in-toto.io/docs/getting-started/

[R07] The Update Framework roles, metadata, and security. https://theupdateframework.io/docs/metadata/ ; https://theupdateframework.io/docs/security/

[R08] Reproducible Builds SOURCE_DATE_EPOCH specification. https://reproducible-builds.org/specs/source-date-epoch/

[R09] Sigstore/Cosign blob signing and hardware token guidance. https://docs.sigstore.dev/cosign/signing/signing_with_blobs/ ; https://docs.sigstore.dev/cosign/key_management/hardware-based-tokens/


---

## Dated preparation and evidence addendum — 2026-10-15

This section was prepared by Codex as supporting reviewer for the owner, Sherman Gaucia Laing / Quantum.Earth.Laing. GAUCIA Actual is the primary project agent. This attribution does not assert that a particular runtime was active in the historical study. The historical author line is retained as printed.

A reproducible software companion exists in the retained audit source: `03_REFERENCE_IMPLEMENTATION/`, its `requirements.lock`, and `05_EVIDENCE/QEL_REFERENCE_IMPLEMENTATION_TEST_LOG.txt`. The lock pins `cryptography==46.0.4`; it does not pin a complete operating-system or Python environment. The saved August log names 26 unit tests, reports 26 passed in 0.210 seconds, and records static containment checks. It is a historical execution record; no tests were rerun for this preparation.

The implementation is a reference subset. A declared AF_UNIX/systemd restriction is not a negative network test. The paper does not establish compatibility with every canonical-JSON implementation, full TUF/SLSA conformance, adversarial security certification, or production key custody. The test count describes the 26 named methods in one saved run, not 26 deployments or independent studies. An executable companion should preserve the exact source, lock, named tests and original receipt, then report any future environment and execution separately.

### Newly prepared diagram equivalent

```mermaid
flowchart LR
  classify["Classify: explicit allowlist and license/privacy review"] --> build["Build: canonical manifest, SBOM and deterministic archive"]
  build --> verify["Verify: hashes, schemas, ledger and reproducibility"]
  verify --> authorize["Authorize: declared evidence gates and review"]
  authorize --> release["Release: offline signatures and version control"]
  verify --> stop["On failure: stop and preserve rollback evidence"]
  authorize --> stop
```

This diagram is an editorial reconstruction from the source figure and surrounding text. Boxes describe the design or evidence states, not a certification that every transition or operational control has been achieved. Evidence-state advances require their stated gates; a failed check or material change can return a claim to an earlier state. A visual commitment is supporting evidence, not an authenticator.

### Source identity and reproduction boundary

Original DOCX SHA-256: `0065189b7a5fb4eab6c37a9945d1d3afd990b4fc0729351dcb8aa1a6d32a29b7`.

Original PDF SHA-256: `d0fcbc265742c87ed558a12373be16b2827112160354dc8aa05c1e2da7e1aff8`.

The original PDF and DOCX remain immutable. The complete body was converted from DOCX structure, including tables; exact extracted PDF text and an unredacted body copy are retained privately. The original DOCX and conversion script are privately retained; this public selection supplies the frozen prepared text, not those regeneration inputs. Conversion checks count 145 nonempty source paragraph/cell units and 1 original drawing(s). These are document-coverage units, not tests or scientific observations.

The four August papers share a source register and reference implementation. They are a coordinated architecture/methods series, not four independent experiments. A working-paper publication does not require claiming an operator-signed software release. Actual publication, code licensing and any future execution are separate decisions.
