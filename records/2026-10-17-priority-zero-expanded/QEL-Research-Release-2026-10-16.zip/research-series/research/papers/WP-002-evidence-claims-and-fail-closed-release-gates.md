> **Public-review copy prepared 2026-10-15, after the historical collection cutoff. Not published.** The full existing draft follows unchanged. Its HOLD/UNSIGNED statements and proposed release gates describe its historical software-governance scope; they are not new requirements for this authorized editorial preparation or a universal signature prerequisite for publishing a working paper. The source draft does not declare a document date in its body. Do not infer one from this new review date or backdate its claims to a period named elsewhere.

# WP-002 — Evidence, Claims, and Fail-Closed Release Gates

**Status:** DRAFT / SOURCE-BOUNDED / HOLD / UNSIGNED  
**Release effect:** None

## Abstract

Technical systems frequently compress a long chain—request, command, observation, verification, authorization, and release—into one word: “success.” That compression creates avoidable errors. A command may succeed while the intended outcome fails; an outcome may verify while consent is absent; a signed artifact may still be unsafe or derived from the wrong source. This paper defines a non-transitive evidence model and a fail-closed release gate intended to keep those distinctions machine-readable.

*[Sources: WF003-REVIEW §§4, 7 and Correction 3; ARCH-C001 §§Separation rules, Required gates before any sovereign claim.]*

## 1. Evidence is typed

QEL uses explicit evidence classes rather than a single confidence score:

- **Requested:** a human or system asked for a bounded action.
- **Issued:** a named command or operation was attempted.
- **User-reported:** a human described a visible or experienced state.
- **System-observed:** a host, service, file, or sensor returned point-in-time state.
- **Independently evidenced:** a separate mechanism corroborated a specific observation.
- **Outcome verified:** a declared postcondition passed under a named method.
- **Inferred:** reasoning connects evidence to a provisional explanation.
- **Unresolved:** evidence is missing, denied, contradictory, or inadequately designed.
- **Owner-authorized:** the accountable owner approved the exact governed action.
- **Released:** every declared gate, including signature and authority, produced a retained release record.

These types form a partial order, not a ladder that automatically advances. An issued command does not become verified merely with time. A verified result does not become owner-authorized. Owner authorization does not make a defective result correct. Release requires separate evidence for every mandatory predicate.

*[Sources: WF003-REVIEW §§4, 7, 11 and Correction 3; LOCAL-HANDOFF-V1 §§Authority and operating model, Gate 5.]*

## 2. Claim records

A useful claim record answers six questions:

1. What exact statement is being made?
2. Which evidence items support it?
3. What population, environment, and time cutoff does it cover?
4. What method tested it?
5. What does it explicitly not establish?
6. What lifecycle or release effect follows?

For example, “Defender found zero detections during the 44-second quick scan completed at the recorded host time” is supportable by the scan completion and event evidence. “The laptop is clean” is not: it silently expands one scan, one tool, and one observation window into an unlimited claim.

Counts require the same discipline. If an aggregate counter reports 1,100 operations while a rolling detailed window contains 275 records, both numbers may be correct for their populations. Combining them into “all 1,100 commands were individually reviewed” would be false. The denominator and retention boundary belong in the claim, not in hidden notes.

*[Sources: WF003-REVIEW §§3, 5, 7 and Correction 2. The numbers are an explanatory example of the population rule, not a new repository measurement.]*

## 3. Content identity is not authority

Exact-byte witnesses answer a narrow question: whether the examined bytes match a declared value under a declared algorithm and purpose. QEL uses SGL Prime as a primary purpose-separated unkeyed content witness and SHA-256 as a secondary conventional digest. These can detect changes and bind a purpose label into the witness procedure.

They cannot establish a person's identity, consent, authorship, trusted time, moral validity, source lawfulness, or release authority. A detached owner signature may bind an owner key to exact content, but even that is only one release input. Security, privacy, consent, reproducibility, ledger continuity, and rollback may remain unsatisfied.

*[Sources: WF003-REVIEW §7 and Correction 8; ARCH-C001 §§Separation rules, Required gates before any sovereign claim; WF002-START §§Signing and activation, Integrity boundary.]*

## 4. Release as a logical AND gate

Let the release decision be:

```text
RELEASE = P ∧ A ∧ S ∧ B ∧ T ∧ V ∧ C ∧ L ∧ R ∧ O
```

where:

- `P`: peaceful and lawful purpose is accepted;
- `A`: exact action and scope are authorized;
- `S`: canonical source selection and custody verify;
- `B`: deterministic build and dependency closure verify;
- `T`: required technical/security tests pass;
- `V`: privacy, data rights, and necessary consent clear;
- `C`: exact artifact identities and claim language close;
- `L`: ledger continuity and external checkpoint verify;
- `R`: rollback protection and restoration verify;
- `O`: owner signature and release record verify for this exact package.

No average, majority vote, model score, or high test count replaces a false input. Unknown is treated as false for release. A later success does not retroactively authorize an earlier action.

*[Sources: ARCH-C001 §Required gates before any sovereign claim; WF003-REVIEW §§11, 12; LOCAL-HANDOFF-V1 §Gate 5.]*

## 5. Why fail-closed matters

Fail-open systems tend to turn missing information into implied permission. That is dangerous at precisely the points where evidence is weakest: stale timestamps, incomplete source recovery, ambiguous paths, inherited test claims, telemetry with undocumented destinations, model output presented as fact, or a release request carrying a caller-controlled `authorized=true` field.

A fail-closed gate produces structured refusal reasons. Refusal is then useful data: it names the missing predicate and the smallest lawful next step. This supports progress without allowing urgency, novelty, or eloquence to become authority.

*[Sources: ARCH-C001 §§Separation rules, Required gates before any sovereign claim; WF003-REVIEW §§7, 11, 12.]*

## 6. Verification design

A release gate should be tested in at least four ways:

1. **Positive fixture:** every required input is independently valid.
2. **Single-fault negatives:** each predicate is false or absent one at a time.
3. **Ambiguity and mutation:** duplicate keys, unsafe numbers, path collisions, byte changes, stale freshness, and external-head mismatches are rejected.
4. **Authority spoofing:** caller fields, model text, filenames, and forged active-state documents cannot unlock release.

Mutation testing is especially important. A gate that passes its hand-written test suite may still fail to reject a subtly changed manifest or branch condition. Deterministic fixtures make independent replay possible; open-set performance claims require a different prospective study design and cannot be inferred from fixed fixtures.

*[Sources: ARCH-C001 §Clean-successor construction checkpoint; LOCAL-HANDOFF-V1 §§Gates 0–5; TRUST-KERNEL-README-0.1.0; WF003-REVIEW §§6.3, 7.]*

## 7. Human review

Machine-readable models reduce ambiguity but do not replace judgment. A human review should present the exact package identity, purpose, sources, transformations, tests, failures, privacy effect, known gaps, rollback, and requested decision in plain language. The reviewer must be able to leave the package on HOLD without losing evidence or triggering hidden work.

Git history can show who a local tool identified as author or committer and which bytes changed. It is not equivalent to the offline owner-signature gate. Likewise, a rendered QPRINT may consolidate a bounded state for review, but the underlying manifest and witnesses still require verification.

*[Sources: LOCAL-HANDOFF-V1 §§Gate 5, Communication rule; WF003-REVIEW §§7, 8.3, 13; WF002-START §§Signing and activation, Integrity boundary.]*

## 8. Current application

The repository's first models encode the evidence classes and release predicates described here. The examples intentionally end in HOLD even when technical tests pass, because owner signature, offline reproduction, external ledger state, and other gates are absent. This is expected behavior.

*[Sources: ARCH-C001 §§Required gates before any sovereign claim, Current decision; TRUST-KERNEL-STATUS-0.1.0; repository derivatives `models/evidence-claim-lifecycle.v1.json` and `models/release-gate.v1.json`.]*

## Conclusion

The point of evidence discipline is not to make every statement hesitant. It is to make each “yes,” “no,” and “unknown” mean exactly what its evidence supports. Typed evidence and fail-closed release logic let a research system retain strong results without allowing them to cancel missing authority, privacy, consent, or source integrity.

## Source lineage

This draft is a declared synthesis of the evidence-classification and release-boundary material identified in `provenance/SOURCE_INDEX.json`. It does not replace WF002, WF003, Architecture Decision C001, or the Q6.1 reference papers.

### Source map

- `ARCH-C001` — governing separation rules, release predicates, current decision, and clean-successor checkpoint.
- `LOCAL-HANDOFF-V1` — authority boundary, staged execution gates, owner review, and communication rules.
- `WF002-START` — Word-first governance, peace boundary, signing, activation, and integrity limits.
- `WF003-REVIEW` — evidence classes, population discipline, requested/issued/observed/verified/authorized chain, corrections, and whole-system gate.
- `TRUST-KERNEL-README-0.1.0` and `TRUST-KERNEL-STATUS-0.1.0` — implementation boundary and bounded clean-successor status.
- `CUSTODY-INDEX-C001` and `CUSTODY-VALIDATION-C001` — source-custody context for the declared input set.

Exact locators, byte lengths, and SHA-256 identities for these IDs are in `provenance/SOURCE_INDEX.json`.


---

## Dated editorial and evidence addendum — 2026-10-15

Original saved draft SHA-256: `14ec21bf32bffac83c00bc615b4aab5c5895a6c349778f51703675fc6db1e854`. The complete original text above is preserved verbatim; this addendum and opening review label are new. The exact prior copy remains in the private source census. Preparation by Codex as supporting reviewer; owner Sherman Gaucia Laing / Quantum.Earth.Laing; primary project agent GAUCIA Actual.

This is a design/methods synthesis, not an independent empirical study. It overlaps the August 11 architecture, provenance and verified-state papers but is a distinct complete draft and is retained separately. Its first-person and present-tense system states are historical assertions from the source draft, not fresh laptop or runtime observations. No new experiment, source modification, signature, submission or publication occurred in this preparation.

The shorthand source map refers to `provenance/SOURCE_INDEX.json` in the draft's original repository. That index and the exact referenced source bodies must accompany a final scholarly edition, or the references must be replaced with stable accessible citations. Their mention alone does not verify a source claim. A local copy of the draft is not evidence that every cited artifact has been reviewed here.

The 1,100-operation/275-record example is explicitly illustrative and is not a measured population for this review. The Defender-scan example is a source-specific example, not a new security finding. The logical AND gate is a proposed software-release model. Its owner-signature and offline-checkpoint predicates do not become publication prerequisites for an honestly labeled research working paper. Reproduction would require the exact evidence-classification/release-gate JSON models, clean-successor code, fixtures, and dated execution receipt; these must be attached or precisely cited before describing a particular implementation as independently reproduced.
