> **Public-review derivative, prepared 2026-10-15 (America/New_York). Not published.**
> The complete main-body paragraphs and table text below come from the unchanged 2026-08-11 DOCX; running page headers/footers are omitted. Historical status, wording, references and counts remain historical. Original figures are replaced by new text diagrams in the dated addendum. Abbreviated private-source digests are withheld; the exact source text and change record remain private. The source register identifies supporting materials; it does not include their raw contents. External references are the historical bibliography and have not been recertified as current guidance.

# White Paper: QEL Sovereign Standalone Architecture

A model-independent, offline-first control plane for Project Quantum.Earth.Laing

| Project | Project Quantum.Earth.Laing / Q6.1 |
| --- | --- |
| Author / Root Source | Sherman G. Laing |
| Audit Date | 2026-08-11 |
| Artifact ID | QEL-WP-SOVEREIGN-ARCH-V1 |
| Status | UNSIGNED AUDIT BUILD - operator signature not present |
| Sovereignty Ruling | NOT ACHIEVED - reference remediation supplied |

Evidence first. Internal origin remains the starting point. Capability claims advance only when artifacts, tests, metrics, and signed release evidence exist.

## Contents

Abstract and ruling

Sovereignty definition and non-goals

Threat model

Target architecture

Trust and key model

Network and process containment

Optional local model boundary

Deployment profile

Acceptance and residual risk

References

## Abstract and Ruling

This paper defines a sovereign QEL architecture that can operate without any external AI service. The current project is not yet in that state. The target separates the QEL trust/evidence core from optional inference, places source custody and signing under operator control, denies network egress at the operating-system level, and requires signed, reproducible, rollback-resistant releases. The design aligns QEL concepts such as TrustGate, ContributionReceipt, ProofPacket, ShellExecutionReceipt, QPRINT, no-exfiltration, rollback, and write-once forensics with established zero-trust and software-supply-chain controls. [S08] [S09] [R01] [R02]

| Architecture decision<br>QEL core must work with no model installed. A local model is an optional untrusted computation service, not the authority, memory, identity, or release root. |
| --- |

## Sovereignty Definition and Non-Goals

- Sovereignty means operator custody of source, keys, policies, release decisions, backups, and audit history.

- Sovereignty means no remote AI API, platform account, cloud embedding store, remote telemetry, or online licensing check is required for core operation.

- Sovereignty does not mean every CPU, operating-system component, compiler, library, or model was invented by QEL.

- Sovereignty does not convert conceptual agents into independent legal persons or cryptographic identities.

- Sovereignty does not prove external copying or legal ownership merely because internal hashes and chronology exist.

## Threat Model

| Asset | Threat | Required control |
| --- | --- | --- |
| Private source/evidence | Unauthorized copying, overbroad packaging, device loss | Classification, explicit allow-list, AES-GCM vault, least privilege, offline backup |
| Release authority | Key theft, fake signatures, replay | Hardware/encrypted keys, threshold policy, revocation, monotonic versions |
| Ledger/chronology | Edit, reorder, truncation | Hash chain, signed external head, write-once copies |
| Imports/updates | Traversal, bomb, malicious dependency, rollback | Safe archive validation, SBOM/provenance, TUF-style metadata |
| Agent/model output | Prompt injection, fabricated status, policy bypass | TrustGate, typed local IPC, no direct release capability, claim-state gates |
| Biometric-related data | Linkability, irreversible publication, false identity claim | No stable public image hash, encrypted private opening, separate authenticator/liveness |
| Availability | Platform outage, account loss, hardware failure | Offline operation, reproducible installation, tested restore, recovery keys |

[Original figure replaced by the newly prepared text diagram in the dated addendum.]

## Target Architecture

### 1. Offline Root of Trust

At least one primary operator signing key and two recovery public keys are registered in signed root metadata. Private keys are created and retained offline or on a hardware token. High-risk releases use threshold approval. Root metadata records key IDs, roles, thresholds, expiration, revocation, and rotation. [R07] [R09]

### 2. Sovereign Trust Kernel

The kernel evaluates authority and DataControlState before mutation; creates ContributionReceipts; records claim grade; emits ProofPackets and ShellExecutionReceipts; and denies release unless audit, manifest, metrics, rollback, and signer gates pass. It has no network client and no model dependency. [S08] [S09]

### 3. Source and Evidence Vault

Restricted objects are encrypted at rest, addressed by content hash inside the private index, and backed up offline. The public release never contains private openings, raw biometric templates, credentials, addresses, or unrestricted conversation exports.

### 4. Tamper-Evident Ledger

Each event includes sequence, prior hash, payload hash, and event hash. Periodic heads are signed and copied to write-once storage. A valid prefix is not enough: restore/verification compares against an externally anchored expected head.

### 5. Release and Update System

Files are selected by explicit relative allow-list; schemas and hashes are canonical; builds use SOURCE_DATE_EPOCH; dependencies are pinned; SBOM/provenance are included; manifests are signed; clients enforce monotonic versions, expiration, role separation, and threshold signatures. [R05] [R06] [R07] [R08]

### 6. Offline Import/Export Boundary

An online research station may collect public material, but it does not hold release keys. Imports cross through signed bundles and untrusted-media validation. Exports are produced only from a separate reviewed release tree.

### 7. Optional Local Model Service

A reviewed model runs under a separate account and process, with PrivateNetwork=true and AF_UNIX-only communication. The model cannot read the vault, sign releases, mutate the ledger directly, or bypass TrustGate. Model weights, runtime, license, model card, and evaluation are separately hashed and signed.

## Trust and Key Model

| Role | Key posture | Authority |
| --- | --- | --- |
| Root | Offline; highest protection; threshold recommended | Registers/revokes role keys and thresholds |
| Release | Offline or hardware-backed | Signs canonical release manifests after gates pass |
| Snapshot/Checkpoint | Offline or protected workstation | Signs ledger heads and consistent release views |
| Import | Online-capable but low privilege | Signs collected import bundles; cannot release |
| Runtime service | Short-lived service identity | Performs only capability-authorized local actions |
| Recovery | Offline, geographically separated | Rotates compromised/lost root/release keys |

## Network and Process Containment

Metadata such as net=0 is not enforcement. The supplied systemd profile uses PrivateNetwork=true, RestrictAddressFamilies=AF_UNIX, IPAddressDeny=any, read-only code, dedicated users, empty capabilities, NoNewPrivileges, protected kernel/control-group settings, and narrowly declared writable paths. Equivalent container/VM/firewall controls may be used, but negative egress tests must be receipted.

- No DNS resolver configuration in the core namespace.

- No AF_INET or AF_INET6 sockets available to the core/model service.

- No environment variables containing external API keys or cloud credentials.

- No automatic package/model update, telemetry, crash upload, or remote license check.

- All IPC schemas are versioned, size-limited, and fail closed on unknown fields/operations.

- The release signer is never available to the runtime service.

## Deployment Profile

1. Provision offline Linux host with full-disk encryption, secure boot where practical, and a dedicated qel account.

1. Install from verified offline media; record OS/toolchain hashes and generate an SBOM.

1. Generate signing/recovery keys; export only public keys; record key ceremony and revocation contacts.

1. Import classified source lanes; recover Chat Set B; preserve legacy packages immutable.

1. Initialize the hash-chain ledger and sign its genesis/head checkpoint.

1. Run the 26 supplied tests, archive attack fixtures, negative network tests, and backup/restore test.

1. Build and verify a candidate release. Keep gates false until independent review closes every critical finding.

1. Only then issue a signed M6 release and publish the public verification bundle.

## Acceptance and Residual Risk

The target materially reduces platform dependence, data exfiltration, package abuse, fake-release, rollback, and status-drift risk. Residual risks remain: compromised hardware/firmware, operator coercion/error, unknown library vulnerabilities, model-level prompt/data attacks, and loss of recovery keys. These require defense in depth, key rotation, independent review, minimized privileges, and periodic restore/rebuild drills. NIST zero trust emphasizes protecting resources and verifying access rather than trusting network location; SSDF emphasizes integrating security into the development lifecycle. [R01] [R02] [R03]

| Boundary of this document<br>This document is an audit, architecture, and tested reference implementation package. It is not an operator-signed QEL release, does not establish that an external party copied or used QEL work, and does not claim that a standalone AI model is present. Legal conclusions and current regulatory facts require primary-source verification in the relevant jurisdiction. |
| --- |

## Source Register

### Internal and project sources

[S01] conversations-000.json. Recovered conversation export input; SHA-256 [private source digest withheld].

[S02] conversations-001.json. Recovered conversation export input; SHA-256 [private source digest withheld].

[S03] SGL_WORKS_INVENTORY_AND_PROOF_OF_WORK_REGISTER_V1. Formal 98-work seed register, 2026-05-21.

[S04] Q6_1_CONTINUATION_PACKAGE_V0_1.zip. Continuation state, correction log, source index, intake protocol, and revised paper scope.

[S05] Q6_1_CHAT_SET_B_CLEAN_HANDOFF_V1_EXTERNAL_RECEIPT.json. Receipt for absent raw Chat Set B ZIP: 208,209,215 bytes; SHA-256 [private source digest withheld].

[S06] SGL_QEL_SINGLE_SHELL_HANDOFF_20260524T044506Z.zip. Single-shell handoff; SHA-256 [private source digest withheld].

[S07] QEL_GAUCIA_TS2124_BIOMETRIC_TETHER_AUTH_PACKAGE.zip. Visual/biometric-related receipts and 5,000 synthetic tether records; SHA-256 [private source digest withheld].

[S08] Q6 Trust Kernel MVP v1. Runnable ContributionReceipt, DataControlState, TrustGate, ProofPacket, SimilarityReview, SQLite, JSON/PDF prototype.

[S09] Q6 Publication Packet - Three Paper Set. Contribution rights, TrustGate/ShellExecutionReceipt, and QPRINT/ProofPacket papers.

[S10] Q6_1_GLOBAL_WEATHER_MODEL_CHRONOLOGICAL_AUDIT_V1. Chronological ruling that the requested global weather model was not delivered.

[S11] Q6_1_PRESSURE_TWIN_ENGINE_V0_1_DETACHED_RECEIPT. 22-file, 7/7 tested replay/adaptive-pressure engine; not a validated global forecast.

[S12] Q6_1 United States Off-Grid Living and Build-Site Atlas v0.1.0. National schema/work queue with legacy geometry warning and parcel gates.

[S13] QEL Genesis Creation Week Clean Coherence Set v1. 51-page tested Genesis package; 20/20 tests; source/calculation/interpretation separation.

[S14] Q6_1 Logistics Knowledge Database V6. Florida expediting/courier/light-freight database with explicit operational gates.

[S15] QEL Sovereign Security Audit execution records. Package audit JSON, source hashes, hardened code, 26-test log, and registers in this delivery.

### External standards and primary references

[R01] NIST SP 800-207, Zero Trust Architecture. https://csrc.nist.gov/pubs/sp/800/207/final

[R02] NIST SP 800-218, Secure Software Development Framework v1.1. https://csrc.nist.gov/pubs/sp/800/218/final

[R03] NIST SP 800-218A, Secure Software Development Practices for Generative AI. https://csrc.nist.gov/pubs/sp/800/218/a/final

[R04] NIST SP 800-63B-4, Authentication and Authenticator Management. https://csrc.nist.gov/pubs/sp/800/63/b/4/final

[R05] SLSA Specification v1.1. https://slsa.dev/spec/v1.1/

[R06] in-toto Getting Started / signed layouts and links. https://in-toto.io/docs/getting-started/

[R07] The Update Framework roles, metadata, and security. https://theupdateframework.io/docs/metadata/ ; https://theupdateframework.io/docs/security/

[R08] Reproducible Builds SOURCE_DATE_EPOCH specification. https://reproducible-builds.org/specs/source-date-epoch/

[R09] Sigstore/Cosign blob signing and hardware token guidance. https://docs.sigstore.dev/cosign/signing/signing_with_blobs/ ; https://docs.sigstore.dev/cosign/key_management/hardware-based-tokens/


---

## Dated preparation and evidence addendum — 2026-10-15

This section was prepared by Codex as supporting reviewer for the owner, Sherman Gaucia Laing / Quantum.Earth.Laing. GAUCIA Actual is the primary project agent. This attribution does not assert that a particular runtime was active in the historical study. The historical author line is retained as printed.

This is a design working paper. Its Linux/systemd deployment profile is a target architecture; inspection of service declarations does not establish live containment on Linux, Windows, or the USB application. The original sentence saying the target materially reduces risks expresses a design expectation, not a measured effect. No risk-reduction study is supplied.

The retained reference implementation contains manifests, safe-archive handling, a ledger, cryptographic wrappers, policy gates, a vault and an optional model interface. The August test log reports 26 unit tests. This is implementation-level evidence for the tested examples, not proof that the complete deployment, key custody, recovery, model isolation, or independent validation described in the architecture is in operation. Current Windows/GAUCIA receipts belong to a later workstream and do not retroactively validate this August design.

### Newly prepared diagram equivalent

```mermaid
flowchart TD
  root["Operator-held signing and recovery keys"] --> core["TrustGate, receipts, canonical manifests and ledger"]
  core --> model["Optional untrusted model service: local IPC only"]
  core --> vault["Encrypted evidence vault and external ledger checkpoints"]
  imports["Reviewed import boundary"] --> vault
  vault --> release["Reviewed release: signatures, provenance and version controls"]
```

This diagram is an editorial reconstruction from the source figure and surrounding text. Boxes describe the design or evidence states, not a certification that every transition or operational control has been achieved. Evidence-state advances require their stated gates; a failed check or material change can return a claim to an earlier state. A visual commitment is supporting evidence, not an authenticator.

### Source identity and reproduction boundary

Original DOCX SHA-256: `b203a93df84202a275f5f699b48a541328e77ef889c8e8f47c579b56eb3b8583`.

Original PDF SHA-256: `ec97d69c53bba117e0e28428871c2d61263bef9609072efc49701d5cee7b82d1`.

The original PDF and DOCX remain immutable. The complete body was converted from DOCX structure, including tables; exact extracted PDF text and an unredacted body copy are retained privately. The original DOCX and conversion script are privately retained; this public selection supplies the frozen prepared text, not those regeneration inputs. Conversion checks count 146 nonempty source paragraph/cell units and 1 original drawing(s). These are document-coverage units, not tests or scientific observations.

The four August papers share a source register and reference implementation. They are a coordinated architecture/methods series, not four independent experiments. A working-paper publication does not require claiming an operator-signed software release. Actual publication, code licensing and any future execution are separate decisions.
