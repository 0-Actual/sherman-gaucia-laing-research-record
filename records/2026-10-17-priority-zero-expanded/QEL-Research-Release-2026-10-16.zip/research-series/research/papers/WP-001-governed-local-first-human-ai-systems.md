> **Public-review copy prepared 2026-10-15, after the historical collection cutoff. Not published.** The full existing draft follows unchanged. Its HOLD/UNSIGNED statements and proposed release gates describe its historical software-governance scope; they are not new requirements for this authorized editorial preparation or a universal signature prerequisite for publishing a working paper. The source draft does not declare a document date in its body. Do not infer one from this new review date or backdate its claims to a period named elsewhere.

# WP-001 — Governed Local-First Human–AI Research Systems

**Status:** DRAFT / SOURCE-BOUNDED / HOLD / UNSIGNED  
**Environment:** Windows staging; not sovereign  
**Release effect:** None

## Abstract

Human–AI systems often join powerful computation to weak authority boundaries. A model can generate convincing text, a workflow can run many successful tests, and a content hash can prove byte stability, yet none of those facts establishes who authorized a release, whether a source was lawfully obtained, whether a claim exceeds its evidence, or whether a later copy silently replaced the reviewed artifact. Quantum.Earth.Laing (QEL) treats these as separate problems.

This paper proposes a local-first architecture in which governance precedes computation, exact source custody precedes interpretation, models are replaceable untrusted tools, and release fails closed unless every declared gate is independently satisfied. The approach does not claim that software can manufacture moral authority, divine approval, owner identity, trusted time, or physical isolation. Its purpose is narrower: make technical work easier to inspect, reproduce, limit, and refuse when authority or evidence is missing.

*[Sources: ARCH-C001 §§Governing order, Separation rules, Required gates before any sovereign claim; LOCAL-HANDOFF-V1 §§Authority and operating model, Canonical project state; WF003-REVIEW §§4, 7, 12.]*

## 1. Problem statement

A conventional AI pipeline may blur at least six layers:

1. a human request;
2. the action a tool attempted;
3. the state a user or sensor observed;
4. evidence that independently verified an outcome;
5. permission to publish, mutate, or release;
6. the truth of the final claim.

The layers are related but not interchangeable. A successful command does not prove the intended effect. A verified effect does not supply consent. Consent does not make unsafe code safe. A model's confidence does not repair missing source bytes. A hash match proves a byte relationship under a declared algorithm; it does not prove authorship, lawfulness, theological correctness, or fitness for release.

QEL therefore starts from separation rather than automation. It is designed to make invalid transitions difficult and missing gates visible.

*[Sources: WF003-REVIEW §§4, 7, 11 and Correction 3; ARCH-C001 §Separation rules.]*

## 2. Declared governance boundary

For this project, the owner declares the Bible as the controlling written witness for conduct, truthfulness, stewardship, peace, and purpose, while retaining accountable human stewardship. The technical consequence is not that code interprets itself as spiritual authority. The consequence is that the system must remain an instrument: it may compare records, enforce declared constraints, and produce evidence, but it may not claim divine certification or replace owner judgment.

The corresponding technical order is:

> exact source → declared transform → declared profile → reproducible witness → bounded interpretation.

Work that cannot state its peaceful purpose, authority, source, transform, and verification remains on HOLD.

*[Sources: ARCH-C001 §§Governing order, Required gates before any sovereign claim; WF002-START §§Governing declaration, Peace and protection boundary; WF003-REVIEW §§2, 8.]*

## 3. Layered architecture

### 3.1 Offline owner root

The strongest authority functions belong on controlled offline hardware: owner-key creation and use, final manifest review, release signature, and preservation of an independently held ledger checkpoint. A networked Windows laptop is useful for staging, but it is not made sovereign by a filename, firewall rule, or local test pass.

*[Sources: ARCH-C001 §§Target architecture, Current node roles, Required gates before any sovereign claim; LOCAL-HANDOFF-V1 §§Canonical project state, Gates 0–5.]*

### 3.2 Source and evidence vault

Origin bytes are preserved separately from working copies. Each derivative records its source locator, exact byte length, conventional digest, purpose-separated content witness, declared transformation, tool/runtime, and status. Duplicate files are not silently collapsed when they carry different custody histories. Conversely, multiple filenames do not imply multiple independent sources.

*[Sources: ARCH-C001 §§Candidate-source disposition, Clean-successor construction checkpoint; WF003-REVIEW §§6.10, 7 and Corrections 8–10; CUSTODY-INDEX-C001; CUSTODY-VALIDATION-C001.]*

### 3.3 Sovereign Trust Kernel

The Trust Kernel is a small model-independent policy layer. Its portable semantics include strict canonical data, safe paths, manifest verification, deterministic ledger proposals, rollback checks, and a fail-closed release decision. Platform operations—atomic files, locks, local IPC, permissions, service isolation, and durable storage—sit behind explicit adapters. This keeps operating-system assumptions from masquerading as system governance.

*[Sources: ARCH-C001 §§Target architecture, Clean-successor construction checkpoint; TRUST-KERNEL-README-0.1.0; TRUST-KERNEL-STATUS-0.1.0.]*

### 3.4 Tamper-evident ledger

A ledger entry links to a prior entry and describes a bounded event. Local chaining can expose mutation, but it is not physical write-once storage. Rollback detection requires an external head preserved outside the mutable host. Trusted chronology requires more than a laptop clock. The Windows staging lane may propose and verify deterministic entries; it does not commit the sovereign ledger.

*[Sources: ARCH-C001 §§Target architecture, Current node roles, Required gates before any sovereign claim; LOCAL-HANDOFF-V1 §§Canonical project state, Gate 5.]*

### 3.5 Computation, emulator, and model lanes

Models and emulators consume bounded inputs and return data. They hold no owner key, policy authority, release capability, or canonical-ledger write access. A classical emulator result is labeled classical. A simulated circuit is not evidence of physical-QPU execution. Model independence means that replacing one model must not change the authority rules or the meaning of a verified state.

*[Sources: ARCH-C001 §§Separation rules, Candidate-source disposition; LOCAL-HANDOFF-V1 §Gate 4 — QEL emulator; WF003-REVIEW §§4, 8.3.]*

### 3.6 Transport and user interfaces

Browsers, remote connectors, command surfaces, and dashboards carry requests and display results. They are not trusted merely because authentication succeeded. Each adapter needs a documented data boundary, minimal permissions, explicit network behavior, and independently testable receipts. Telemetry that is merely “enabled” or “disabled” is not characterized until fields, destinations, retention, and control are known.

*[Sources: ARCH-C001 §WebMCP disposition; WF003-REVIEW §§8.2, 11 and Correction 6.]*

## 4. Governed operating cycle

A bounded QEL work cycle follows these stages:

1. **Purpose:** state the peaceful lawful objective and exclusions.
2. **Authority:** record who requested the work and what that request covers.
3. **Source:** resolve exact inputs and custody roles before interpretation.
4. **Risk:** identify failure modes, privacy effects, resource limits, and rollback.
5. **Action:** make the smallest reversible change against exact targets.
6. **Observation:** record what the host or user actually returned.
7. **Verification:** test the defined postcondition, including negative and ambiguity cases.
8. **Identity:** witness the exact output bytes under a declared purpose.
9. **Claim:** state population, environment, cutoff, and limitations.
10. **Release:** require every release predicate; otherwise retain HOLD.

This cycle favors refusal over plausible overstatement. “Unresolved” is not an engineering embarrassment; it is a truthful state that prevents an unsupported transition.

*[Sources: WF003-REVIEW §§7, 11, 12 and Corrections 1–3; LOCAL-HANDOFF-V1 §§Execution order, Communication rule.]*

## 5. Security properties sought

The architecture seeks properties that can be tested rather than slogans:

- a caller-supplied authority flag never unlocks release;
- ambiguous canonical inputs are rejected;
- unsafe paths and case-fold collisions are rejected;
- source identities fail on byte mutation;
- ledger verification fails on mutation or external-head mismatch;
- production policy code cannot silently gain network, process, dynamic-code, or filesystem-write imports;
- model/emulator output cannot alter governance or release state;
- a forged active state cannot bypass a fixed staging block;
- missing, false, stale, or unknown release inputs all produce HOLD.

The current clean successor demonstrates these properties in 15 bounded Node.js tests. That is implementation evidence for the tested source and environment, not a whole-system certification.

*[Sources: TRUST-KERNEL-README-0.1.0; TRUST-KERNEL-STATUS-0.1.0; ARCH-C001 §Clean-successor construction checkpoint.]*

## 6. Research questions

The next research cycles should make falsifiable comparisons:

- Can two independently implemented canonicalizers produce identical bytes for every accepted fixture and reject the same ambiguity corpus?
- Can a clean offline build reproduce exact artifacts from pinned, hashed dependencies?
- Does an externally preserved ledger head reliably expose rollback across host restoration scenarios?
- Can multiple model adapters produce useful proposals while remaining unable to affect authority or release state?
- Do human reviewers distinguish requested, observed, verified, and authorized statements more accurately when records use the explicit evidence model?
- Can emulator workloads remain deterministic and resource-bounded on low-memory hardware without mislabeling simulation as hardware execution?

Each question requires a declared dataset, denominator, environment, cutoff, negative cases, and precommitted claim language.

## 7. Present limitations

Canonical source selection is incomplete. Owner signing and trusted time are absent. Privacy and telemetry are not fully characterized. No independent offline Linux reproduction, external write-once head, or rollback-restoration demonstration has been completed. The Windows laptop lacks an independently verified backup and remains an online staging host. No physical QPU result is claimed.

*[Sources: ARCH-C001 §Current decision; LOCAL-HANDOFF-V1 §§Start condition, Canonical project state; WF003-REVIEW §§10, 12; TRUST-KERNEL-STATUS-0.1.0.]*

## Conclusion

The central proposition is simple: intelligence should not imply authority, and successful computation should not imply release. A useful human–AI research system can be ambitious in analysis while remaining conservative in power. QEL's present contribution is therefore a governed staging pattern—source before interpretation, evidence before claim, and explicit HOLD whenever the chain is incomplete.

## Source lineage

This draft synthesizes, without replacing, the records listed in `provenance/SOURCE_INDEX.json`, especially Architecture Decision C001, the Q7 Local Codex Handoff, WF002, WF003, and the clean Trust Kernel v0.1.0 documentation. It is a new declared derivative, not an exact copy or canonical selection of the Q6.1 publications.

### Source map

- `ARCH-C001` — governing architecture, separation rules, gates, candidate-source disposition, and clean-successor checkpoint.
- `LOCAL-HANDOFF-V1` — local operating model, canonical project state, execution gates, and communication boundary.
- `WF002-START` — Word-first governance, peace boundary, signing, activation, and integrity boundary.
- `WF003-REVIEW` — evidence classification, command review, corrective protocol, gap ledger, and whole-system gate.
- `CUSTODY-INDEX-C001` and `CUSTODY-VALIDATION-C001` — bounded source-custody inventory and validation context.
- `TRUST-KERNEL-README-0.1.0` and `TRUST-KERNEL-STATUS-0.1.0` — clean-successor implementation boundary and recorded status.

Exact locators, byte lengths, and SHA-256 identities for these IDs are in `provenance/SOURCE_INDEX.json`.


---

## Dated editorial and evidence addendum — 2026-10-15

Original saved draft SHA-256: `d7e088b101defad299e9b36f0c1b1abba5f553ebb316d279a73f1cbdee7eb3e9`. The complete original text above is preserved verbatim; this addendum and opening review label are new. The exact prior copy remains in the private source census. Preparation by Codex as supporting reviewer; owner Sherman Gaucia Laing / Quantum.Earth.Laing; primary project agent GAUCIA Actual.

This is a design/methods synthesis, not an independent empirical study. It overlaps the August 11 architecture, provenance and verified-state papers but is a distinct complete draft and is retained separately. Its first-person and present-tense system states are historical assertions from the source draft, not fresh laptop or runtime observations. No new experiment, source modification, signature, submission or publication occurred in this preparation.

The shorthand source map refers to `provenance/SOURCE_INDEX.json` in the draft's original repository. That index and the exact referenced source bodies must accompany a final scholarly edition, or the references must be replaced with stable accessible citations. Their mention alone does not verify a source claim. A local copy of the draft is not evidence that every cited artifact has been reviewed here.

The statement about 15 bounded Node.js tests is retained as a source-reported implementation result; this particular source/receipt pairing has not yet been independently reconciled in this paper-preparation step. Do not merge it with the August Python reference implementation's 26 named unit tests. The proposed properties and research questions remain separate from measured outcomes. The architecture's religious governance declaration is the owner's project-specific framing, not a demonstrated property of code or a policy imposed on other projects.
