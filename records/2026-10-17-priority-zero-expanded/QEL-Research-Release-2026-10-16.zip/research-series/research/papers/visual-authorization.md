> **Public-review derivative, prepared 2026-10-15 (America/New_York). Not published.**
> The complete main-body paragraphs and table text below come from the unchanged 2026-08-11 DOCX; running page headers/footers are omitted. Historical status, wording, references and counts remain historical. Original figures are replaced by new text diagrams in the dated addendum. Abbreviated private-source digests are withheld; the exact source text and change record remain private. The source register identifies supporting materials; it does not include their raw contents. External references are the historical bibliography and have not been recertified as current guidance.

# White Paper: Visual Authorization Commitment and Biometric Privacy Correction

Correcting the TS2124 tether boundary without destroying its evidentiary value

| Project | Project Quantum.Earth.Laing / Q6.1 |
| --- | --- |
| Author / Root Source | Sherman G. Laing |
| Audit Date | 2026-08-11 |
| Artifact ID | QEL-WP-VISUAL-AUTH-V1 |
| Status | UNSIGNED AUDIT BUILD - operator signature not present |
| Sovereignty Ruling | NOT ACHIEVED - reference remediation supplied |

Evidence first. Internal origin remains the starting point. Capability claims advance only when artifacts, tests, metrics, and signed release evidence exist.

## Contents

Abstract

Verified TS2124 facts

Security and privacy findings

Corrected architecture

Public/private receipt schemas

Legacy migration and revocation

Authentication requirements

Acceptance tests

References

## Abstract

The TS2124 package is a hash-verified evidence package, but it is not a biometric authenticator. It contains two visual anchor receipts and 5,000 synthetic tether records; it performs no face recognition, liveness certification, palm template creation, raw template storage, hidden capture, or external transfer. The correction is to preserve it as visual evidence while removing authentication overstatement, stable public image hashes, and unclear non-reversible/revocable language. [S07]

## Verified TS2124 Facts

| Fact | Audit result |
| --- | --- |
| Declared package files | 8; all SHA-256 and BLAKE2 values pass |
| Synthetic analysis records | 5,000 present |
| Visual receipts | 2 |
| Raw images embedded | No |
| Face recognition performed | No |
| Liveness certified | No |
| Palmprint template created | No |
| Raw biometric template stored | No |
| External transfer / hidden capture | False in records |
| Stable image hashes in visual receipts | Yes - privacy correction required |
| Operator status versus record revocability | Contradictory |

## Security and Privacy Findings

- A static image file and its hash do not prove that the present operator is the person shown or that the image is live.

- Publishing a stable SHA-256/perceptual hash can correlate the same image across datasets and releases.

- ACTIVE_NONREVERSIBLE_COMMITMENT_LAYER conflicts with revocable=true and lacks a signed revocation mechanism.

- Synthetic validation points increase record count but do not increase identity assurance.

- A file-integrity receipt may be valuable evidence, but calling it authentication can lead a TrustGate to grant authority incorrectly.

- Absolute private paths and legacy image-derived commitments should not appear in public releases.

[Original figure replaced by the newly prepared text diagram in the dated addendum.]

## Corrected Architecture

### Identity proofing

An enrollment process establishes the operator-to-account binding. It is a separate event with its own evidence and privacy notice.

### Cryptographic authenticator

A hardware/private key proves possession. The private key requires an activation factor. Authentication is bound to the verifier/session and protects against phishing where required. NIST treats biometrics as an activation factor within an authenticator context rather than a standalone secret. [R04]

### Optional liveness

If risk requires it, use a local, consented, challenge-based liveness process with published performance/error limits. Do not claim liveness when none was performed.

### Visual Authorization Commitment

The image is hashed privately, combined with a random salt, event ID, purpose, and challenge. Only the randomized commitment is public. The opening record is encrypted in the local vault.

### TrustGate

Authority requires a valid cryptographic authenticator and policy. The visual commitment may support intent/evidence but cannot independently authorize structural change or release.

### Revocation and rotation

Every commitment is explicitly revocable. A signed revocation record identifies event ID, time, reason, and operator key. A new commitment never silently replaces the old one.

## Public and Private Receipt Schemas

| Public receipt | Private encrypted opening |
| --- | --- |
| event_id | event_id |
| purpose and challenge | purpose and challenge |
| randomized commitment SHA-256 | image SHA-256 and random salt |
| operator public key ID | local source reference |
| NOT_IDENTITY_AUTHENTICATION classification | custody/classification record |
| face recognition=false; liveness=false | optional separately verified liveness reference |
| revocable=true | revocation/rotation linkage |
| detached signature | vault object authentication tag |

## Legacy Migration and Revocation

1. Freeze the original TS2124 ZIP and record its current hash as restricted legacy evidence.

1. Issue a signed correction statement: FILE/IMAGE INTEGRITY AND OPERATOR-ASSERTED VISUAL EVIDENCE; NOT BIOMETRIC AUTHENTICATION OR LIVENESS.

1. Stop including stable file/perceptual hashes in public-facing receipts. Move them to encrypted private custody or retain only inside the immutable legacy package.

1. Revoke the NONREVERSIBLE label. Create a signed revocation/rotation record for each visual event where continued use is not desired.

1. Enroll a cryptographic authenticator on controlled hardware. Bind high-risk actions to its signature and activation factor.

1. Only implement face/liveness processing after purpose, consent, error rates, demographic performance, retention, revocation, and local-only processing are documented.

## Acceptance Tests

- Two commitments generated from the same image must differ.

- The public receipt must contain no image SHA-256, perceptual hash, template, salt, or private path.

- A wrong key or modified receipt must fail signature verification.

- A signed revocation must block later TrustGate reliance on that event ID.

- A static image with no cryptographic authenticator must never authorize release or structural change.

- Private opening tamper or wrong passphrase must fail authenticated decryption.

- Deletion/retention and backup behavior must be tested and receipted.

| Boundary of this document<br>This document is an audit, architecture, and tested reference implementation package. It is not an operator-signed QEL release, does not establish that an external party copied or used QEL work, and does not claim that a standalone AI model is present. Legal conclusions and current regulatory facts require primary-source verification in the relevant jurisdiction. |
| --- |

## Source Register

### Internal and project sources

[S01] conversations-000.json. Recovered conversation export input; SHA-256 [private source digest withheld].

[S02] conversations-001.json. Recovered conversation export input; SHA-256 [private source digest withheld].

[S03] SGL_WORKS_INVENTORY_AND_PROOF_OF_WORK_REGISTER_V1. Formal 98-work seed register, 2026-05-21.

[S04] Q6_1_CONTINUATION_PACKAGE_V0_1.zip. Continuation state, correction log, source index, intake protocol, and revised paper scope.

[S05] Q6_1_CHAT_SET_B_CLEAN_HANDOFF_V1_EXTERNAL_RECEIPT.json. Receipt for absent raw Chat Set B ZIP: 208,209,215 bytes; SHA-256 [private source digest withheld].

[S06] SGL_QEL_SINGLE_SHELL_HANDOFF_20260524T044506Z.zip. Single-shell handoff; SHA-256 [private source digest withheld].

[S07] QEL_GAUCIA_TS2124_BIOMETRIC_TETHER_AUTH_PACKAGE.zip. Visual/biometric-related receipts and 5,000 synthetic tether records; SHA-256 [private source digest withheld].

[S08] Q6 Trust Kernel MVP v1. Runnable ContributionReceipt, DataControlState, TrustGate, ProofPacket, SimilarityReview, SQLite, JSON/PDF prototype.

[S09] Q6 Publication Packet - Three Paper Set. Contribution rights, TrustGate/ShellExecutionReceipt, and QPRINT/ProofPacket papers.

[S10] Q6_1_GLOBAL_WEATHER_MODEL_CHRONOLOGICAL_AUDIT_V1. Chronological ruling that the requested global weather model was not delivered.

[S11] Q6_1_PRESSURE_TWIN_ENGINE_V0_1_DETACHED_RECEIPT. 22-file, 7/7 tested replay/adaptive-pressure engine; not a validated global forecast.

[S12] Q6_1 United States Off-Grid Living and Build-Site Atlas v0.1.0. National schema/work queue with legacy geometry warning and parcel gates.

[S13] QEL Genesis Creation Week Clean Coherence Set v1. 51-page tested Genesis package; 20/20 tests; source/calculation/interpretation separation.

[S14] Q6_1 Logistics Knowledge Database V6. Florida expediting/courier/light-freight database with explicit operational gates.

[S15] QEL Sovereign Security Audit execution records. Package audit JSON, source hashes, hardened code, 26-test log, and registers in this delivery.

### External standards and primary references

[R01] NIST SP 800-207, Zero Trust Architecture. https://csrc.nist.gov/pubs/sp/800/207/final

[R02] NIST SP 800-218, Secure Software Development Framework v1.1. https://csrc.nist.gov/pubs/sp/800/218/final

[R03] NIST SP 800-218A, Secure Software Development Practices for Generative AI. https://csrc.nist.gov/pubs/sp/800/218/a/final

[R04] NIST SP 800-63B-4, Authentication and Authenticator Management. https://csrc.nist.gov/pubs/sp/800/63/b/4/final

[R05] SLSA Specification v1.1. https://slsa.dev/spec/v1.1/

[R06] in-toto Getting Started / signed layouts and links. https://in-toto.io/docs/getting-started/

[R07] The Update Framework roles, metadata, and security. https://theupdateframework.io/docs/metadata/ ; https://theupdateframework.io/docs/security/

[R08] Reproducible Builds SOURCE_DATE_EPOCH specification. https://reproducible-builds.org/specs/source-date-epoch/

[R09] Sigstore/Cosign blob signing and hardware token guidance. https://docs.sigstore.dev/cosign/signing/signing_with_blobs/ ; https://docs.sigstore.dev/cosign/key_management/hardware-based-tokens/


---

## Dated preparation and evidence addendum — 2026-10-15

This section was prepared by Codex as supporting reviewer for the owner, Sherman Gaucia Laing / Quantum.Earth.Laing. GAUCIA Actual is the primary project agent. This attribution does not assert that a particular runtime was active in the historical study. The historical author line is retained as printed.

This is a privacy and authentication-boundary correction note, not a biometric performance study. The source audit describes eight declared files, two visual receipts and 5,000 synthetic tether records. The 5,000 records are neither 5,000 people nor 5,000 authentication trials. A file digest does not prove identity, liveness, consent or control of a private key.

The retained reference implementation includes `visual_commitment.py` and a named randomized/revocable-commitment unit test in the saved 26-test run. That test does not measure false acceptance/rejection, presentation-attack resistance, human usability or cross-device behavior. No visual images, stable image-derived digests, biometric templates, private openings or credentials are included in this review copy. The new diagram separates proofing, key possession, optional liveness and authorization; it repairs the original label overflow without altering the historical findings.

### Newly prepared diagram equivalent

```mermaid
flowchart TD
  proof["Identity proofing: enrollment evidence"] --> commitment["Visual authorization commitment: randomized public value; encrypted private opening"]
  key["Cryptographic authenticator: key possession and activation"] --> commitment
  commitment -->|Supporting evidence only| gate["TrustGate: purpose, data class and authority checks"]
  key -->|Authenticator result checked separately| gate
  liveness["Optional local liveness: separate consent and risk decision"] --> gate
```

This diagram is an editorial reconstruction from the source figure and surrounding text. Boxes describe the design or evidence states, not a certification that every transition or operational control has been achieved. Evidence-state advances require their stated gates; a failed check or material change can return a claim to an earlier state. A visual commitment is supporting evidence, not an authenticator.

### Source identity and reproduction boundary

Original DOCX SHA-256: `229a34d9050b5a8f48b71724b5b38a786e6c22273eff1be758e3a9da0cf1e499`.

Original PDF SHA-256: `eecc5abdf396e9ac4368b784a0512cd210d4d2354bc0594250c3717f78dd7a3f`.

The original PDF and DOCX remain immutable. The complete body was converted from DOCX structure, including tables; exact extracted PDF text and an unredacted body copy are retained privately. The original DOCX and conversion script are privately retained; this public selection supplies the frozen prepared text, not those regeneration inputs. Conversion checks count 135 nonempty source paragraph/cell units and 1 original drawing(s). These are document-coverage units, not tests or scientific observations.

The four August papers share a source register and reference implementation. They are a coordinated architecture/methods series, not four independent experiments. A working-paper publication does not require claiming an operator-signed software release. Actual publication, code licensing and any future execution are separate decisions.
