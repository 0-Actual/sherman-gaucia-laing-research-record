# Attribution and edition changes

**Sherman Gaucia Laing / Quantum.Earth.Laing** — founder, principal researcher and directing author. The record attributes the research questions, objectives, constraints, corrections and owner-supplied creative seeds to him where the sources support that attribution.

**Historical assistant:** Thunder in the reviewed early interactions. Generated explanations, suggestions, concepts and drafts remain attributed to the assistant. A 2023 spelling correction concerning the owner’s name does not date the later GAUCIA assistant name to that period.

**Current primary project agent:** GAUCIA Actual. **Documentary preparation:** Codex, with delegated source discovery, chronology selection and independent editorial review. This edition’s new narrative, categories and correction groupings were prepared with AI assistance at the owner’s direction. This attribution does not establish a running autonomous system or credentialed researchers.

**Changes from sources:** interval selection; private locator-column omission; one explicit opaque-identifier omission in C099; new editorial IDs and categories; new manuscript, methods and correction ledger; separate overlapping public-source selections and timestamp correspondence. The 24 and 45 source-entry dictionaries retain their original fields and wording. They are later documentary summaries, not transcripts.

The source report and public record were prepared in 2026; original interaction dates remain 2023–2024. Later names, code, tests and releases are not backdated. No institutional affiliation, endorsement, certification or owner signature is invented. The owner’s account of data-sharing settings does not establish per-message settings or subsequent model-training use.

Existing source notices: [attribution](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/ATTRIBUTION.md), [source notes](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/SOURCE_NOTES.md), and [license](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/LICENSE.md). The existing license is preserved unchanged in LICENSE.md; the draft introduces no new licensing terms. Its scope remains limited to rights the licensor controls, with third-party and independently applicable rights retained.
