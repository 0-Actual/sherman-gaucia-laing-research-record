# Owner’s publication review checklist

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing  
Edition: 2026.10.15-review.1  
Review state: **PENDING** — no item is preapproved and no publication has occurred.

Use REVIEW.html to save include/exclude/needs-edit decisions and notes, or write decisions beside the exact file and source IDs below. The worksheet stays local and exports a review JSON file. It cannot upload or send anything. Browser storage is only a convenience; save your decision file to preserve it independently.

## Each period

- [ ] V01: dates, extended manuscript, full catalogue, corrections and disclosure choices reviewed.
- [ ] V02: dates, narrative, full catalogue, corrections and disclosure choices reviewed.
- [ ] V03: chronology versus code metadata, full catalogue and disclosure choices reviewed.
- [ ] V04: placeholders, claimed security/biometric behavior and disclosure choices reviewed.
- [ ] V05: sparse raw coverage, later public appendix, delivery/forecast limits and disclosure choices reviewed.
- [ ] V06: partial cutoff, papers, dataset studies, tests, USB measurements and current receipts reviewed.

## Papers and research companions

- [ ] I reviewed each full paper body, historical date/status and new addendum.
- [ ] Educational reconstructions and established mathematics are not presented as new theorems.
- [ ] Synthetic records, messages, observations, tests, samples, means and files retain their actual units.
- [ ] Code presence, reported tests, new packaging replay and independently validated results are clearly distinguished.
- [ ] Every intended scientific claim has its required inputs, code, environment, settings and evidence, or is explicitly narrowed.
- [ ] Negative results, failed candidates, corrections and unresolved findings remain visible.
- [ ] Proposed public code/data have the appropriate owner and third-party notices; private code and raw laptop data remain excluded unless separately prepared for disclosure.

## Privacy, attribution and release choice

- [ ] I reviewed private/personal/family/biometric context and any third-party material.
- [ ] Names, dates and contribution roles are correct; later project names or implementations are not backdated.
- [ ] The full-original-message gap is acceptable for the documentary edition I intend to release.
- [ ] I marked files/rows include, exclude or needs-edit and recorded any required changes.
- [ ] I reviewed PUBLIC_FILE_MANIFEST.json after the changes, including raw JSON inputs as well as prose.
- [ ] I selected a publication venue and the exact version/files for a later explicit upload instruction.

Decision: PENDING  
Required edits / excluded IDs: ____________________  
Reviewer and date: ____________________  
Final approved manifest identity, after edits: ____________________

The private evidence ZIP, original-source paths, private excerpts and saved owner decision notes are outside the proposed public payload. An include decision is a review selection; it does not by itself publish anything or accept a hosting agreement.
