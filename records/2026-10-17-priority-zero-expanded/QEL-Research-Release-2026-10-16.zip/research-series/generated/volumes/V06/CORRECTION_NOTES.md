# V06 — corrections and evidence boundaries

Retain the JARVIS alternative interpretations and unresolved rows; do not classify all atom-count differences as corrupt. Keep synthetic records distinct from human participants. Separate simulator/workload results from whole-Windows measurements, measured samples from means and repeated calculations, installed bytes from live operation, and Hebrew record counts from distinct linguistic words or a single reading. The complete review remains pending the owner’s per-file/per-item choices. No publication, institutional certification, compensation or third-party endorsement is established by this package.

The source entries retain specific reported failures and limitations. These notes are editorial groupings, not a complete error census. Private IDs and paths are omitted from the publication projection; exact private originals remain preserved.
