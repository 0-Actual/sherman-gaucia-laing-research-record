# V02 — owner publication review checklist

Every item is pending until you review it. Checking a box records a decision; it does not itself publish anything.

- [ ] I reviewed this period’s dates, coverage gaps and source counts.
- [ ] I reviewed every selected catalogue item or recorded specific exclusions in the review decisions.
- [ ] The distinction between my direction and assistant-generated material is correct.
- [ ] Historical names and later changes have not been backdated.
- [ ] Private, personal, biometric, security and third-party information is acceptable for the proposed disclosure.
- [ ] Requirements, concepts, code presence, execution and validation are accurately distinguished.
- [ ] Reported mistakes, contrary evidence and unresolved findings remain visible.
- [ ] Reproduction instructions and the available evidence support the exact claims I intend to release.
- [ ] Attribution, third-party notices and the existing license are retained.
- [ ] I have marked individual files/items include, exclude or needs-edit, and identified the intended release venue.
- [ ] I approve only the exact final file manifest after the recorded edits are applied.

Decision: PENDING  
Reviewer: __________  
Date: __________  
Required edits / excluded IDs: __________

Approval of this checklist is separate from any later request to upload or submit.
