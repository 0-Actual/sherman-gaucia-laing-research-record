# V02 — corrections and evidence boundaries

Retain the distinction between reported minting and a verified mint; between architecture prose and a working lens or quantum bridge; between one successful command and a functioning environment; and between a requested security property and a tested control. Preserve original date offsets and the September project-name anchor. An NFT or C2PA attribution request alone does not establish ownership of all described methods or validate the associated research.

The source entries retain specific reported failures and limitations. These notes are editorial groupings, not a complete error census. Private IDs and paths are omitted from the publication projection; exact private originals remain preserved.
