# V05 — corrections and evidence boundaries

Preserve reported delivery failures and later repairs. A requested forecast or continuous overlay does not establish an executed service or measured accuracy. Distinguish educational examples from original mathematical results, source packages from verified use, and QPRINT carrier creation from successful cross-device reconstruction. Hebrew metadata and translation choices need their own evidence; later corpus-count and mapping corrections must not be projected backward as already verified here.

The source entries retain specific reported failures and limitations. These notes are editorial groupings, not a complete error census. Private IDs and paths are omitted from the publication projection; exact private originals remain preserved.
