# V04 — corrections and evidence boundaries

Placeholder gate names and biometric hash stand-ins are not deployed identity proofing. Character/XOR/shift/modulo examples do not establish cryptographic security. The informal 0=1 proposition, where referenced, is not treated as a validated mathematical theorem or an independent physical measurement. Distinguish signed bytes, a signature claim, user authorization and verified identity. Keep requested scheduler/autonomy behavior separate from observed execution.

The source entries retain specific reported failures and limitations. These notes are editorial groupings, not a complete error census. Private IDs and paths are omitted from the publication projection; exact private originals remain preserved.
