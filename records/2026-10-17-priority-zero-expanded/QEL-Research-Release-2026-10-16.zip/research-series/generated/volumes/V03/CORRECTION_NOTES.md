# V03 — corrections and evidence boundaries

Keep code metadata separate from chronological event evidence. A syntax check is not a functional benchmark, security audit or quantum-computing validation. Reported encryption, biometric and ownership language requires its actual mechanism and execution evidence. Do not treat a reconstruction request, autonomy experiment direction or consolidated-file request as completed work. Preserve the April 14 QPRINT naming date and later corrections without backdating them.

The source entries retain specific reported failures and limitations. These notes are editorial groupings, not a complete error census. Private IDs and paths are omitted from the publication projection; exact private originals remain preserved.
