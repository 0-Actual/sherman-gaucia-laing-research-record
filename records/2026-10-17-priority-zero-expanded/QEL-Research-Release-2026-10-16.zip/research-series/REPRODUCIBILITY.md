# Reproducing the prepared research series

This package distinguishes three reproducibility questions. A successful reconstruction of a catalogue is not a rerun of every historical experiment.

| Question | Supplied basis | Limit |
| --- | --- | --- |
| Can the six documentary selections be rebuilt? | Frozen public-safe source inputs, exact manifests, a portable Python selector and generated reference files | Recreates the derivative; does not recover absent original conversations |
| Can a supplied study or software companion be replayed? | Per-work code/data/notices and its exact replay instructions, where available | Only the named input, workload and outputs; see the evidence matrix |
| Can all historical claims be independently validated? | Source reports, limitations, correction records and explicit gaps | Not established; some original code, datasets, attachments or execution environments remain unavailable |

## Rebuild the six documentary volumes

Use Python 3.10 or later. The documentary builder uses only the standard library, makes no network calls and does not execute any historical project code.

From the extracted package folder:

```text
python reproduction/rebuild.py --output rebuilt-series
python reproduction/rebuild.py --verify generated
```

The first command creates a new empty folder with 46 generated files. It refuses to overwrite a nonempty output folder. The second compares the supplied generated folder against a fresh in-memory reconstruction, including its exact file list and every byte. It exits with an error on an input hash mismatch, malformed/offset-free timed date, missing/extra generated file or content mismatch.

The six frozen inputs are the sanitized full-report projection, exact pinned public timeline, exact pinned public prior-work appendix, new saved-receipt summaries, declared scope and editorial narrative source. `reproduction/inputs/INPUTS_MANIFEST.json` identifies their exact byte lengths and hashes. Public Git source identity is separately recorded in `SOURCES.md`.

New editorial narratives are supplied as frozen text, not presented as machine-derived conclusions. Source labels and exact wording remain distinct from new category/stage labels. Two private-report tables are represented separately: 321 chronological entries and 27 code-body metadata rows. Metadata describing source code does not distribute the code itself.

## Dates, boundaries and overlap

The start is October 17, 2023 at 21:51:03.625297 EDT. Period boundaries advance by six calendar months at that local time. Each start is inclusive and end exclusive. The final period ends early at October 15, 2026, 22:26:43 EDT / October 16, 02:26:43 UTC. Its future remainder is excluded.

Exact timestamps retain source offsets and precision. Date-only records keep their day labels. Interior day labels are assigned to the corresponding Eastern-calendar period as an explicit editorial convention, without inventing an event time or original timezone. A date-only record on a period-boundary day or the cutoff day goes to `UNASSIGNED_RECORDS.json` for review. The inspected inputs happen to have no such unresolved records; the selector still handles them.

Every source row receives a recorded selection decision. The 348 report-projection rows, 175 public timeline rows, 504 prior-work rows and four current receipt summaries remain distinct populations. They overlap. Their arithmetic sum is not a unique message, invention, paper or result count. Equal instants are documented as correspondences, not private-message identity or independent corroboration.

## Original-source transformation

The private report’s fifth-column locators are omitted. The 27 code-metadata rows also omit their recovered-source paths. Additional embedded identifiers are explicitly redacted. The public redaction ledger lists affected fields and reasons without restoring private values. Exact originals, the private map, reviewed annotations and a portable extractor remain in the separately labeled private evidence bundle. Reproducing the initial transformation from the full private report requires that private bundle; the public documentary rebuild begins at the frozen sanitized projection.

The original conversation export remains unavailable through the current access route. A local keyword-capture source has 606 occurrences representing 522 distinct user messages, of which 165 have a complete captured textual field and 357 are partial-only. It contains no matching assistant responses. These numbers describe that capture source alone, not the project’s complete history. The captures are preserved privately, not included in the public payload.

## Computational companions

Consult `research/EVIDENCE-MATRIX.md` and each companion’s own instructions. Replay records must identify the executed program, frozen inputs, output comparison and environment. Reported past tests remain historical unless this preparation records a new replay separately. Public JARVIS documentary evidence does not automatically provide the full analysis code or source archive. Private performance and numerical-model artifacts are separately mapped; missing inputs cannot be replaced by filenames or reported scores.

The current series does not reinstall GAUCIA, change device permissions, run public submissions, retrain models, repeat physical measurements or claim Windows-wide improvement. Existing Hebrew and GAUCIA receipts retain their exact version and scope. Any newly run companion verification is documented by its own dated receipt.

## Integrity and rights

`PUBLIC_FILE_MANIFEST.json` lists the proposed public payload. The separately saved ZIP hashes identify the distributed archives. Hashes are not signatures, ownership proof, scientific validation or certification. Root licensing retains the owner’s existing documentary terms; third-party data and software retain their own notices. No new platform or hosting agreement is accepted by this preparation.

The owner’s review decisions are pending. Rebuilding or checking a package does not publish it. Use the review worksheet to identify changes/exclusions and then review the exact final file manifest before a separate publication action.
