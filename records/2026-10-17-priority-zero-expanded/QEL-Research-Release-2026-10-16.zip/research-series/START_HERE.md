# Your research publication series

**Sherman Gaucia Laing / Quantum.Earth.Laing** · Edition 2026.10.15-review.1 · Prepared for your review; not posted.

The series organizes the located history into six periods. Each contains a narrative, full selected catalogue, structured data, category navigation, correction notes and its own review checklist. The last period is partial, ending October 15, 2026 at 22:26:43 EDT.

**Start with [the review worksheet](REVIEW.html)** or the [printable checklist](OWNER_REVIEW_CHECKLIST.md). Then read the relevant volume and its exact file list.

| Volume and period | Report rows | Public timeline rows | Public prior-work rows | New receipt summaries |
| --- | ---: | ---: | ---: | ---: |
| [V01 · Oct 17, 2023–Apr 17, 2024](generated/volumes/V01/MANUSCRIPT.md) | 115 | 24 | 45 | 0 |
| [V02 · Apr 17–Oct 17, 2024](generated/volumes/V02/MANUSCRIPT.md) | 25 | 18 | 31 | 0 |
| [V03 · Oct 17, 2024–Apr 17, 2025](generated/volumes/V03/MANUSCRIPT.md) | 81 | 64 | 60 | 0 |
| [V04 · Apr 17–Oct 17, 2025](generated/volumes/V04/MANUSCRIPT.md) | 30 | 14 | 18 | 0 |
| [V05 · Oct 17, 2025–Apr 17, 2026](generated/volumes/V05/MANUSCRIPT.md) | 4 | 3 | 98 | 0 |
| [V06 · Apr 17–Oct 15, 2026 (partial)](generated/volumes/V06/MANUSCRIPT.md) | 93 | 52 | 252 | 4 |

The populations overlap. The 348 report rows consist of 321 chronology entries and 27 code-metadata entries, not 348 independent works. The 175 and 504 public-source rows remain separate. No combined unique-interaction total is claimed.

## Papers and substantive evidence

Use the [paper and category index](PAPERS_AND_CATEGORIES.md) to open all eight complete manuscript review copies.

The [research evidence matrix](research/EVIDENCE-MATRIX.md) identifies actual manuscripts, source code, datasets, results and replay requirements across the located workstreams. Paper review copies preserve full source bodies with disclosed changes and dated addenda. The public Bible replay and JARVIS evidence companions retain their exact source notices. Additional private source, numerical/performance inputs and receipts are packaged separately for the owner.

The [extended first-period manuscript](first-period-extended/FIRST_SIX_MONTHS.md) and its correction ledger remain preserved. Supplemental portfolio/receipt tables retain their separate dates and counting units; see `supplements/` if listed in the public manifest.

## Reproducibility and gaps

Read [reproduction instructions](REPRODUCIBILITY.md) and [source notes](SOURCES.md). The offline builder recreates 46 documentary files from frozen inputs. This does not claim that every historical experiment has been rerun. Per-work replay limits remain explicit.

**Complete original conversations remain unrecovered.** The private capture source contains 522 distinct user-message captures, many partial, and no matching assistant replies. It is not the full history. The identified USB export could not be read; no repeat access probe or bypass was attempted in this series preparation.

## Your review sequence

1. Review the volume narratives and the full catalogue entries.
2. Review the actual papers, companion inputs and correction notes.
3. Mark each proposed file/item include, exclude or needs-edit; record changes in the worksheet.
4. Review the source gaps, attribution, licenses and exact final file manifest.
5. After edits and your review, give a separate instruction for the specific public upload or submission.

Everything in this folder is a proposed public-review payload. The separately labeled private evidence bundle contains original excerpts and private locators and must not be posted. Nothing has been uploaded by this preparation.
