"""Read-only supplemental replay and original-field reconciliation."""
import argparse
import hashlib
import json
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--catalogue', required=True, type=Path)
p.add_argument('--replay', required=True, type=Path)
a = p.parse_args()
load = lambda path: json.loads(path.read_text(encoding='utf-8'))
receipt = load(a.catalogue / 'supplemental-verification.json')
names = list(receipt['public_artifact_sha256']) + ['supplemental-verification.json', 'private/private-source-map.json']
comparisons = {n: (a.catalogue/n).read_bytes() == (a.replay/n).read_bytes() for n in names}
assert all(comparisons.values()), comparisons
private = load(a.catalogue / 'private/private-source-map.json')
assert hashlib.sha256(Path(private['source_path']).read_bytes()).hexdigest() == private['source_sha256']
public = {}
for name in ('historical-portfolio', 'retained-receipts', 'mathematical-mechanisms'):
    rows = load(a.catalogue / (name + '.json'))['rows']
    public.update({r['id']: r for r in rows})
assert len(public) == len(private['rows']) == 127
changes = {(r['id'], r['field']) for r in load(a.catalogue / 'supplemental-redactions.json')['changes']}
modified = 0
for original in private['rows']:
    row = public[original['id']]
    for key, value in zip(original['source_headers'], original['raw_cells']):
        if key not in row['source_fields'] or row['source_fields'][key] != value:
            assert (row['id'], key) in changes
            modified += 1
result = {'status': 'PASS', 'bytes_reproduced': comparisons, 'source_unchanged': True, 'source_rows_reconciled': 127, 'modified_or_omitted_fields_accounted_in_ledger': modified, 'historical_date_labels_retained': True, 'period_assignment': 'None; three separate appendices', 'limit': 'Reproduction and source-field custody only; not new scientific verification or independent-work counting.'}
out = a.catalogue / 'independent-replay-verification.json'
out.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
assert load(out) == result
print(json.dumps(result, ensure_ascii=False, indent=2))
