"""Portable, stdlib extraction of three separate documentary appendix populations.

Usage: python extract_supplemental_tables.py --source REPORT.md --timeline timeline.json
       --prior-work prior-work.json --output OUT
OUT/private contains exact sensitive source rows and must not be distributed.
"""
import argparse
import collections
import hashlib
import json
import re
from pathlib import Path

TABLES = {
    'Retained test and artifact evidence': ('retained-receipts', 'R', ['Date', 'Artifact/test family', 'Recorded result', 'Limit', 'Member in recovered preparation archive']),
    'Historical 98-work portfolio with date dispositions': ('historical-portfolio', 'P', ['Historical work name', 'Family', 'Inherited anchor', 'Current date/evidence disposition']),
    'Mathematical mechanisms in recovered successor sources': ('mathematical-mechanisms', 'M', ['Source family', 'Actual mathematical content', 'Boundary']),
}
EXPECTED = {'retained-receipts': 9, 'historical-portfolio': 98, 'mathematical-mechanisms': 20}
UUID = re.compile(r'\b[0-9a-f]{8}-(?:[0-9a-f]{4}-){3}[0-9a-f]{12}\b', re.I)
ABS_PATH = re.compile(r'(?:(?<![A-Za-z])[A-Za-z]:[\\/]|/(?:Users|home|mnt|tmp)/)[^\s|<>;]*')
EMAIL = re.compile(r'(?<![\w.+-])[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}', re.I)
SOURCE_SHA = 'a4f50610182810819207a8da3293b7daf984614f0c1f9009872f2f3de4c4d02f'


def norm(s):
    return ' '.join(s.casefold().split())


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    assert json.loads(path.read_text(encoding='utf-8')) == value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for arg in ('source', 'timeline', 'prior-work', 'output'):
        parser.add_argument('--' + arg, required=True, type=Path)
    a = parser.parse_args()
    raw = a.source.read_bytes()
    digest = hashlib.sha256(raw).hexdigest()
    assert digest == SOURCE_SHA, 'Manual table/privacy review and crosswalk belong to a different source version'
    public_sources = {'public_timeline': json.loads(a.timeline.read_text(encoding='utf-8-sig'))['entries'], 'public_prior_work': json.loads(a.prior_work.read_text(encoding='utf-8-sig'))['entries']}
    public_ids = {pop: {r['id'] for r in rows} for pop, rows in public_sources.items()}
    topics = {
        'QEL-SER-P002': ['QEL-2025-02-28-gaucia-exact-name', 'QEL-2025-02-28-gaucia-named-source', 'QEL-2025-03-02-gaucia-activation-request'],
        'QEL-SER-P004': ['PR-E17'],
        'QEL-SER-P018': ['PR-M12', 'PR-M13'],
        'QEL-SER-R001': ['QEL-2026-08-16-sgl-prime-forward-package-qpr2'],
        'QEL-SER-R008': ['QEL-2026-09-15-bounded-numerical-replay-report'],
    }
    populations = {kind: [] for kind, _, _ in TABLES.values()}
    private, ledger, crosswalk = [], [], []
    section = ''
    for line_number, line in enumerate(raw.decode('utf-8-sig').splitlines(), 1):
        if line.startswith('## '):
            section = line[3:]
        if section not in TABLES or not line.startswith('| '):
            continue
        kind, prefix, headers = TABLES[section]
        padded = re.split(r'(?<!\\)\|', line)[1:-1]
        cells = [c.strip() for c in padded]
        if cells == headers or all(re.fullmatch(r'[-: ]+', c) for c in cells):
            continue
        assert len(cells) == len(headers), (section, line_number, len(cells))
        rid = f'QEL-SER-{prefix}{len(populations[kind])+1:03d}'
        private.append({'id': rid, 'source_line': line_number, 'source_section': section, 'source_headers': headers, 'raw_row': line, 'raw_cells': cells, 'raw_cells_with_padding': padded})
        values = cells[:4] if kind == 'retained-receipts' else cells.copy()
        changes = []
        if kind == 'retained-receipts':
            changes.append({'id': rid, 'field': headers[4], 'action': 'omit_column', 'reason': 'Private preparation-archive member location withheld'})
        for n, value in enumerate(values):
            for pattern, marker, reason in [(UUID, '[private message identifier omitted]', 'Private original-message identifier withheld'), (ABS_PATH, '[private filesystem location withheld]', 'Private filesystem location withheld'), (EMAIL, '[contact address withheld]', 'Contact detail withheld')]:
                value, matches = pattern.subn(marker, value)
                if matches:
                    changes.append({'id': rid, 'field': headers[n], 'action': 'replace_matches', 'replacement': marker, 'match_count': matches, 'reason': reason})
            values[n] = value
        fields = dict(zip(headers, values))
        if kind == 'retained-receipts':
            title, date, summary = values[1], values[0], values[2] + ' Boundary: ' + values[3]
            time = {'date_label_as_recorded': date, 'precision': 'source prose; day, range or offset-qualified description', 'assigned_volume': None, 'selection': 'separate historical-receipt appendix', 'date_interpretation': 'Historical receipt/package date exactly as printed; not a new execution timestamp. No interval midpoint, local time or timezone conversion invented.'}
            stage = 'Historical receipt summarized by the September 17 review; no new execution'
        elif kind == 'historical-portfolio':
            title, date, summary = values[0], values[2], values[3]
            time = {'inherited_anchor_as_recorded': date, 'precision': 'day label inherited from earlier inventory', 'assigned_volume': None, 'selection': 'separate retrospective-portfolio appendix', 'date_interpretation': 'The source disposition controls; an inherited anchor is not an established inception, completion or implementation date.'}
            stage = 'Historical inventory entry; maturity omitted and not newly validated'
        else:
            title, date, summary = values[0], None, values[1] + ' Boundary: ' + values[2]
            time = {'date_label_as_recorded': None, 'precision': 'undated row', 'assigned_volume': None, 'selection': 'separate successor-mechanism appendix', 'date_interpretation': 'Section associates mechanisms principally with an August 21, 2026 successor package; no row-specific event date assigned and no backdating to March 2025.'}
            stage = 'Later static source-analysis summary; no execution during chronology review'
        links = []
        for pop, entries in public_sources.items():
            for record in entries:
                if record.get('title') and norm(title) == norm(record['title']):
                    links.append({'population': pop, 'id': record['id'], 'relationship': 'same normalized title; no event identity or independence inferred'})
        for ident in topics.get(rid, []):
            assert ident in public_ids['public_timeline']
            links.append({'population': 'public_timeline', 'id': ident, 'relationship': 'explicit project/topic or receipt-family correspondence; different record scope and dates retained'})
        if kind == 'mathematical-mechanisms':
            number = re.search(r'\(#(\d+)\)', title)
            if number:
                ident = f"CODE-DATE-{int(number.group(1))+5:02d}"
                assert ident in public_ids['public_timeline']
                links.append({'population': 'public_timeline', 'id': ident, 'relationship': 'same numbered historical algorithm family; this later successor mechanism is not asserted to be the March original implementation'})
        row = {'id': rid, 'source_table': kind, 'title': title, 'source_fields': fields, 'recorded_date_label': date, 'review_report_date': '2026-09-17', 'display_summary': summary, 'editorial_stage': stage, 'time_decision': time, 'public_correspondence': links, 'redactions': changes}
        populations[kind].append(row)
        ledger.extend(changes)
        crosswalk.extend({'supplemental_id': rid, **link} for link in links)
    counts = {k: len(v) for k, v in populations.items()}
    assert counts == EXPECTED, counts
    notice = 'These are three overlapping retrospective table populations. They do not add to the fixed 348-row chronology or measure independent works, papers, completed implementations or newly executed tests. All statements are attributed to the September 17, 2026 review. No external scientific verification is supplied by this extraction.'
    for kind, rows in populations.items():
        write(a.output / (kind + '.json'), {'schema': 'qel-research-series-supplement/1', 'source_report_date': '2026-09-17', 'source_sha256': digest, 'population': kind, 'row_count': len(rows), 'selection_note': notice, 'rows': rows})
    write(a.output / 'supplemental-redactions.json', {'schema': 'qel-supplemental-redactions/1', 'changes': ledger})
    write(a.output / 'public-correspondence.json', {'schema': 'qel-supplemental-public-correspondence/1', 'not_deduplication': True, 'entries': crosswalk})
    write(a.output / 'private/private-source-map.json', {'classification': 'PRIVATE; do not publish', 'source_path': str(a.source.resolve()), 'source_sha256': digest, 'rows': private})
    for path in a.output.glob('*.json'):
        text = path.read_text(encoding='utf-8')
        assert not UUID.search(text) and not ABS_PATH.search(text) and not EMAIL.search(text), path.name
    assert raw == a.source.read_bytes()
    lines = ['# Supplemental project catalogues', '', notice, '', 'Inherited dates and unresolved status stay visible. Every row remains in a separate appendix; no new event timestamp or volume assignment is manufactured. Cross-references indicate documentary correspondence, not a proof of distinct work, source identity or independent validation. Framework names mentioning theft, copying or misattribution are historical names, not findings against an external party.', '']
    for kind, rows in populations.items():
        lines.extend(['## ' + kind + ' — ' + str(len(rows)) + ' source rows', ''])
        for row in rows:
            lines.extend(['### ' + row['id'] + ' — ' + row['title'], ''])
            for key, value in row['source_fields'].items():
                lines.extend(['**' + key + ':** ' + value, ''])
            if row['public_correspondence']:
                lines.extend(['Public correspondence: ' + '; '.join(x['population'] + '/' + x['id'] + ' (' + x['relationship'] + ')' for x in row['public_correspondence']), ''])
    (a.output / 'SUPPLEMENTAL_CATALOGUE.md').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    public_names = [kind + '.json' for kind in populations] + ['supplemental-redactions.json', 'public-correspondence.json', 'SUPPLEMENTAL_CATALOGUE.md']
    receipt = {'status': 'PASS_FOR_EXTRACTION_AND_SAVE_READBACK', 'source_unchanged': True, 'populations': counts, 'total_source_rows_accounted': len(private), 'redaction_actions': len(ledger), 'public_correspondence_links': len(crosswalk), 'period_counts_changed': False, 'source_sha256': digest, 'privacy_context_review': 'All 127 retained rows inspected; one private message identifier and nine archive locators withheld. No contact details, image-derived values, credentials or private absolute paths found in retained content. Historical work names are not findings of theft or copying.', 'public_artifact_sha256': {name: hashlib.sha256((a.output / name).read_bytes()).hexdigest() for name in sorted(public_names)}}
    write(a.output / 'supplemental-verification.json', receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k != 'public_artifact_sha256'}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
