# Additional project tables from the September 17 review

These appendices preserve additional project material in the same report without changing the fixed 348-row chronology, its six-period counts, or the separate public 175/504 populations.

| Appendix | Source rows | Date meaning |
| --- | ---: | --- |
| Historical portfolio | 98 | Inherited inventory anchors; the original disposition states which are unsupported, corrected or unresolved |
| Retained receipts | 9 | Historical report/package/receipt descriptions, including day ranges and Eastern/UTC wording |
| Mathematical mechanisms | 20 | Undated source-family rows; section associates them principally with the August 21, 2026 successor package |

All three are attributed to the September 17, 2026 documentary review. They are overlapping populations and are not 127 additional independent works or completed implementations. None receives an invented inception timestamp or forced volume assignment. The 98 portfolio rows do not reintroduce inherited maturity grades. Mechanism descriptions are later static analyses and are not backdated to the original March 2025 algorithm series. No historical test suite or numerical code was executed for this extraction.

The complete readable version is `SUPPLEMENTAL_CATALOGUE.md`; the three JSON files retain original headers and wording, except for declared privacy omissions. Nine archive-member locators and one embedded message identifier are withheld and recorded in `supplemental-redactions.json`. Exact raw rows, fields, spacing and locators remain in the private map. No raw biometric values, credentials or contact details were located in retained content. Historical framework names mentioning theft or misattribution do not establish wrongdoing by an external party.

`public-correspondence.json` provides 26 explicit links to the pinned public timeline. These identify either the same project/topic or a historical algorithm family. They are not deduplication, independence, original-event identity or identical-code assertions. No exact normalized-title matches were found in the inspected public prior-work list; that does not establish that related work is absent there. Industry-overlap and inherited-comparator tables remain outside these project appendices.

The portable extractor accepts `--source`, `--timeline`, `--prior-work` and `--output`. It is bound to the reviewed report's exact source hash so a changed report cannot silently reuse the manual interpretation. The public input snapshots are used only for documentary cross-references. `verify_supplements.py` compares an independent extraction against all eight generated evidence/data files and checks every source field against the private map and redaction ledger. No private source path is hardcoded in either script.

## Explicit public-file whitelist

- `historical-portfolio.json`
- `retained-receipts.json`
- `mathematical-mechanisms.json`
- `SUPPLEMENTAL_CATALOGUE.md`
- `supplemental-redactions.json`
- `public-correspondence.json`
- `supplemental-verification.json`
- `independent-replay-verification.json`
- this `README.md`

The separately located portable `extract_supplemental_tables.py` and `verify_supplements.py` scripts may also accompany the edition. Do not recursively copy this working directory: `private/private-source-map.json` contains sensitive original locators. Neither the original report nor private replay output is part of the public whitelist. Publication still requires the owner's review of the final selected files.
