# Prepared package: checks and reading aids

This edition is prepared for owner review. Nothing has been posted. The six
volumes contain 348 report-projection rows, 175 public timeline rows, 504 public
prior-work rows and four saved-receipt summaries. These populations overlap.
Three supplemental retrospective tables preserve 98 portfolio, nine receipt and
20 mechanism rows separately, without inventing inception dates or adding them
to a unique-work total.

Eight full manuscript derivatives are in `research/papers/`: four August design
papers, two later undated drafts and two teaching manuscripts. Teaching material
reconstructs established mathematics and has not received a complete proof audit.
The research evidence matrix covers 19 workstreams, including negative results
and missing reproduction inputs. Six paper bodies were independently reconciled
against their originals; the two teaching bodies were fully preserved and scanned
for disclosure concerns, with a narrower editorial review. New Mermaid diagrams
are text reconstructions; they have not received a rendered visual-layout audit.

The documentary builder reproduces 46 files exactly. Boundary checks cover
inclusive/exclusive selection, fractional seconds, equivalent offsets, the partial
cutoff, ambiguous day labels and invalid timed dates. An independent replay also
verified refusal to overwrite a nonempty output folder. The private-report
extraction and supplemental-table extraction each reproduced their frozen public
outputs; original source bytes remained unchanged.

The isolated Bible packaging check completed 113 source comparisons, 36 adapter
test methods and 40 selected WORD_CORE test methods. These are separate units,
not 189 experiments. Three archival fingerprint tests were outside the selected
WORD_CORE check. This is frozen-case software verification, not a new model run,
theological validation or a full-Bible result. Its dated receipt is inside the
companion folder. Other saved numerical/performance results remain historical
unless the evidence matrix explicitly identifies a new run.

The review worksheet lists source rows, supplemental rows and proposed files as
separate review entries. All decisions begin pending. Series-wide files appear in
every period filter. Save the downloaded decision JSON to preserve your choices.
Decisions bind to the review payload's file-hash set, excluding the worksheet and
its own manifest to avoid circular hashing. `REVIEW_SOURCE_SET.json` records that
set; `PUBLIC_FILE_MANIFEST.json` separately includes the final worksheet. Hashes
identify bytes and do not establish ownership, signatures or scientific validity.

Some exact upstream README files refer to files outside the selected companion
subset. They are preserved as source evidence. Consult the companion wrapper and
the pinned repository links in its identity register for their original context.
The JARVIS companion is documentary evidence, not a complete analysis workspace.
Portable Python scripts and JSON are intended to be read or run from an extracted
folder. Markdown and Mermaid display depend on the reader's viewer.

Original conversation coverage remains incomplete. The private evidence bundle
preserves the located source captures, originals, maps, code, inputs and receipts;
it must not be included in a public upload. Only the owner can select what to
release after reviewing the exact proposed files and requested corrections.
