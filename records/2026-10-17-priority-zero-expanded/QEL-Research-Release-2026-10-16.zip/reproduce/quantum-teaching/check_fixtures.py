"""New teaching derivative, October 16, 2026. Standard-library deterministic examples.

These do not execute historical QEL simulation, VQD, optimization, hardware or
performance code. Prepared by Codex as supporting reviewer under owner direction.
"""
from pathlib import Path
import json
import math

def close(a, b):
    if not math.isclose(a, b, rel_tol=1e-12, abs_tol=1e-12):
        raise ValueError(f'Fixture mismatch: {a} != {b}')

def tensor(left, right):
    return [x*y for x in left for y in right]

def main():
    source = json.loads((Path(__file__).parent/'fixtures.json').read_text(encoding='utf-8'))
    # |GHZ> = (|0> tensor |0> tensor |0> + |1> tensor |1> tensor |1>)/sqrt(2).
    zero, one = [1.,0.], [0.,1.]
    a = tensor(tensor(zero,zero),zero)
    b = tensor(tensor(one,one),one)
    state = [(x+y)/math.sqrt(2) for x,y in zip(a,b)]
    indices = [i for i,v in enumerate(state) if v != 0]
    if indices != source['ghz_expected_nonzero_indices']: raise ValueError('Basis ordering mismatch')
    close(sum(v*v for v in state),1)
    row = source['norm_energy']; norm = sum(abs(x)**2 for x in row['state'])
    energy = sum(h*abs(x)**2 for h,x in zip(row['hamiltonian_diagonal'],row['state']))/norm
    close(norm,row['expected_norm_squared']); close(energy,row['expected_energy'])
    row = source['ray_distance']
    overlap = abs(sum(x*y for x,y in zip(row['left'],row['right'])))
    distance = math.sqrt(max(0,2-2*overlap))
    close(distance,row['expected_projective_distance'])
    row = source['spectral_gap']; gap = row['excited_energy']-row['ground_energy']
    error = (1-row['ground_weight'])*gap
    close(error,row['expected_energy_error']);close(error/gap,row['expected_infidelity_bound'])
    print(json.dumps({'status':'PASS','fixture_groups':4,'historical_benchmark_rerun':False,
                      'ghz_nonzero_indices':indices,'norm_squared':norm,'energy':energy,
                      'projective_distance':distance,'energy_error':error,'infidelity_bound':error/gap},indent=2))

if __name__ == '__main__': main()
