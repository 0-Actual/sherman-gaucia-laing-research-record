#!/usr/bin/env python3
"""Offline documentary rebuild. Python 3.10+, standard library only.

Reconstructs selections and catalogues from the frozen public-safe inputs.
It does not rerun historical experiments or recover absent private transcripts.
"""
import argparse
import collections
from datetime import datetime, date
import hashlib
import json
from pathlib import Path
import tempfile

def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')
def h(data):
    return hashlib.sha256(data).hexdigest()
def iso(value):
    return datetime.fromisoformat(value.replace('Z', '+00:00'))

def classify(value, scope):
    """Retain source precision. Day-only records on a boundary are unresolved.

    For day-only records the source calendar label, not an invented timezone or
    time, is compared to the explicitly declared Eastern calendar boundaries.
    Boundary-day entries remain in a separate queue rather than duplicated.
    """
    boundaries=scope['period_boundaries']
    cutoff=iso(scope['cutoff_exclusive'])
    if len(value)==10:
        day=date.fromisoformat(value)
        cutoff_day=date.fromisoformat(scope['cutoff_eastern'][:10])
        if day < date.fromisoformat(boundaries[0][:10]):
            return {'decision':'before_window','precision':'day','period':None}
        if day > cutoff_day:
            return {'decision':'after_cutoff','precision':'day','period':None}
        touching=[f'V{i+1:02}' for i in range(6)
                  if date.fromisoformat(boundaries[i][:10])<=day<=min(date.fromisoformat(boundaries[i+1][:10]),cutoff_day)]
        boundary_days={date.fromisoformat(v[:10]) for v in boundaries}
        if day in boundary_days or day==cutoff_day:
            return {'decision':'boundary_day_unresolved','precision':'day','period':None,'candidate_periods':touching}
        if len(touching)!=1:
            raise ValueError('Day assignment did not resolve: '+value)
        return {'decision':'included_calendar_day','precision':'day','period':touching[0],
                'time_basis':'Source day label retained; Eastern calendar binning is editorial, not an inferred source instant.'}
    stamp=iso(value)
    if stamp.tzinfo is None:
        raise ValueError('Timed date without offset: '+value)
    if stamp<iso(boundaries[0]):
        return {'decision':'before_window','precision':'timestamp','period':None}
    if stamp>=cutoff:
        return {'decision':'at_or_after_cutoff','precision':'timestamp','period':None}
    for i in range(6):
        if iso(boundaries[i])<=stamp<min(iso(boundaries[i+1]),cutoff):
            return {'decision':'included_exact_time','precision':'timestamp','period':f'V{i+1:02}'}
    raise ValueError('Unassigned timestamp '+value)

def public_category(text):
    """Deterministic editorial navigation for the two public source populations.
    Ordered keyword classification is disclosed, not a scientific taxonomy.
    """
    text=text.lower()
    rules=[
      ('Biblical study, language and ethics',('bible','biblical','genesis','hebrew','scriptur','gospel','matthew','jesus','sabbath','theolog','neighbor-love')),
      ('Privacy, provenance and security',('biometric','cryptograph','encryption','encrypted','hash','cipher','signature','signed','privacy','security','provenance','lockout','lockdown')),
      ('Mathematics, simulation and measurement',('math','matrix','matrices','quantum','simulation','simulator','emulator','benchmark','jarvis','calibration','algorithm','numeric','gcd')),
      ('Software, agents and research environment',('code','python','agent','gaucia','termux','runtime','workbench','qprint','q print','scroll','operating system','qel-os','build','browser','interface','launcher','tool','usb','device','offline')),
      ('Agriculture, energy and environmental concepts',('nursery','hydropon','seedling','energy','solar','wind','waste','carbon','wearable','lens','harvest','water','greenhouse')),
      ('Health, life-science inquiry and communication',('health','nutrition','diet','migraine','physiolog','wellness','breathing','skin-care')),
      ('Finance, digital assets and publication',('nft','crypto','blockchain','contract','wallet','bitcoin','ethereum','futures','gold','market','publication','publish','mint','econom')),
      ('Business, rights and funding',('business','grant','company','fund','ownership','attribution','license','legal','patent','rights','attorney')),
      ('Creative, educational and recreational work',('poem','lyric','rap','game','skyrim','runescape','lesson','tutor','teaching','learn')),
    ]
    for category,words in rules:
        if any(w in text for w in words): return category
    return 'Interaction, continuity and other documented work'

def records(inputs):
    chronology=read(inputs/'chronology-projection.json')
    for r in chronology['rows']:
        yield {'source_population':'private_report_projection','id':r['id'],
               'recorded_date':r['recorded_date'],'title':r['title'],
               'description':r.get('display_summary',''),
               'category':r['editorial_category'],'source_table':r['source_table'],
               'stage':r.get('editorial_stage','Reported retrospective evidence'),
               'source_entry':r}
    for population,filename,date_field in [('public_timeline','timeline.json','recorded_date'),('public_prior_work','prior-work.json','timestamp')]:
        for r in read(inputs/filename)['entries']:
            title=r.get('title') or r.get('description','')
            description=r.get('summary',r.get('description',''))
            if r.get('limitation'): description+=' Boundary: '+r['limitation']
            yield {'source_population':population,'id':r['id'],'recorded_date':r[date_field],
                   'title':title,'description':description,'category':public_category(title+' '+description),
                   'source_table':population,'stage':r.get('source_evidence_class',r.get('evidence_class','Historical metadata')),
                   'source_entry':r}
    for r in read(inputs/'current-checkpoints.json')['entries']:
        yield {'source_population':'current_saved_receipts','id':r['id'],'recorded_date':r['recorded_date'],
               'title':r['title'],'description':r['description'],'category':r['category'],
               'source_table':'October 15 saved receipt summaries','stage':'Inspected saved execution/packaging receipt',
               'source_entry':r}

def build(inputs):
    scope=read(inputs/'scope.json')
    editorial=read(inputs/'editorial.json')
    rows=list(records(inputs))
    keys=[(r['source_population'],r['id']) for r in rows]
    assert len(keys)==len(set(keys)), 'Duplicate navigation IDs within population'
    for r in rows: r['selection']=classify(r['recorded_date'],scope)
    files={}
    def jput(name,value):files[name]=encoded(value)
    def put(name,text):files[name]=(text.rstrip()+'\n').encode('utf-8')
    nonadditive=('Source populations overlap and remain separate. Row counts are not unique messages, '
                'papers, inventions, independent results or confirmed defects. Evidence classes are attributed '
                'to their source reviews; summaries do not become original message bodies.')
    counts=collections.Counter(r['source_population'] for r in rows)
    jput('selection-decisions.json',{'schema':'qel-series-selection-decisions/1','scope':scope,
        'population_counts':dict(counts),'count_limit':nonadditive,
        'entries':[{'source_population':r['source_population'],'id':r['id'],'recorded_date':r['recorded_date'],**r['selection']} for r in rows]})
    unmatched=[r for r in rows if r['selection']['period'] is None]
    jput('UNASSIGNED_RECORDS.json',{'purpose':'Explicit boundary/outside/unknown queue; never silently dropped or duplicated','entries':unmatched})
    index=[]
    review_items=[]
    for i in range(6):
        vid=f'V{i+1:02}'
        selected=[r for r in rows if r['selection']['period']==vid]
        selected.sort(key=lambda r:(r['recorded_date'][:10],r['source_population'],r['id']))
        populations={p:[r for r in selected if r['source_population']==p] for p in counts}
        period={'id':vid,'start_inclusive':scope['period_boundaries'][i],
                'end_exclusive':scope['period_boundaries'][i+1] if i<5 else scope['cutoff_exclusive'],
                'scheduled_calendar_end':scope['period_boundaries'][i+1],'partial_final_period':i==5}
        stats={p:len(v) for p,v in populations.items()}
        cats={p:dict(collections.Counter(r['category'] for r in v)) for p,v in populations.items()}
        latest={p:{'latest_exact_timestamp':max((r['recorded_date'] for r in v if len(r['recorded_date'])>10),key=iso,default=None),
                   'latest_day_precision_label':max((r['recorded_date'] for r in v if len(r['recorded_date'])==10),default=None)} for p,v in populations.items()}
        # Exact instants only; day-only strings deliberately excluded from correspondence.
        times=collections.defaultdict(list)
        for r in selected:
            if r['selection']['precision']=='timestamp': times[iso(r['recorded_date'])].append({'population':r['source_population'],'id':r['id']})
        correspond=[{'recorded_instant':stamp.isoformat(),'entries':items} for stamp,items in sorted(times.items()) if len({r['population'] for r in items})>1]
        coverage={'schema':'qel-series-volume-coverage/1','period':period,'population_counts':stats,
                  'category_counts_by_population':cats,'latest_source_date_by_population':latest,
                  'count_limit':nonadditive,'original_corpus_complete':False,
                  'same_instant_correspondences':correspond,
                  'correspondence_limit':'Exact instants across source populations, not verified private-message identity or independent corroboration.',
                  'unassigned_boundary_records_for_review':[{'population':r['source_population'],'id':r['id']} for r in unmatched if vid in r['selection'].get('candidate_periods',[])]}
        prefix='volumes/'+vid+'/'
        jput(prefix+'COVERAGE.json',coverage)
        jput(prefix+'records.json',{'schema':'qel-series-volume-records/1','period':period,
             'count_limit':nonadditive,'populations':{p:[r['source_entry'] for r in v] for p,v in populations.items()}})
        jput(prefix+'navigation.json',{'period':vid,'entries':[{'population':r['source_population'],'id':r['id'],
             'title':r['title'],'category':r['category'],'stage':r['stage']} for r in selected]})
        catlines=[f'# {vid} — complete selected documentary catalogue','',f"Window: `{period['start_inclusive']}` inclusive to `{period['end_exclusive']}` exclusive.",'',nonadditive,'',
                  'This catalogue includes every assigned row from the declared frozen inputs. It does not claim all original interactions or attachments. Technical claims and corrections remain attributed to the retrospective source.', '']
        for p,items in populations.items():
            catlines.extend([f'## {p.replace("_"," ")} — {len(items)} rows',''])
            for r in items:
                catlines.extend([f"### {r['id']} — {r['title']}",'',f"Recorded: `{r['recorded_date']}` · Source table: {r['source_table']}",
                    f"Editorial category: {r['category']} · Evidence label: {r['stage']}",'',r['description'] or '(See preserved source fields in records.json.)',''])
                review_items.append({'key':p+':'+r['id'],'period':vid,'population':p,'id':r['id'],'date':r['recorded_date'],
                    'title':r['title'],'summary':r['description'],'category':r['category'],'decision':'pending','owner_notes':''})
        put(prefix+'CATALOGUE.md','\n'.join(catlines))
        narrative=editorial['volumes'][vid]
        body=[f"# {vid} — {narrative['title']}",'','**Sherman Gaucia Laing / Quantum.Earth.Laing**  ',
              '**Prepared documentary review edition; awaiting owner review.**','',
              f"Window: `{period['start_inclusive']}` to `{period['end_exclusive']}` (end exclusive).",'',
              '| Source population | Selected rows |','| --- | ---: |']
        body += [f'| {p.replace("_"," ")} | {n} |' for p,n in stats.items()]
        body += ['',nonadditive,'',narrative['narrative'],'','## Coverage and reproducibility','',narrative['coverage'],'',
                 'The accompanying CATALOGUE.md and records.json contain the complete period selection from the frozen input populations. COVERAGE.json contains counts, category distributions and exact-instant correspondences. The portable rebuild program recreates these files byte-for-byte. That is documentary reproducibility; historical computational claims require their separately identified code, data, settings and execution receipts.','',
                 'Private original-message recovery is incomplete. A source entry labeled original interaction is a later summary unless the actual original body is separately supplied. No live software capability, legal priority or scientific validation follows merely from a label or saved filename.','',
                 '## Reading and owner review','',
                 'Read CATALOGUE.md for each retained item, CORRECTION_NOTES.md for interpretation limits, and REVIEW_CHECKLIST.md before selecting material for release. The series source notes identify the pinned public inputs and private-report projection. Later corrections retain their dates. No posting is performed by this package.']
        put(prefix+'MANUSCRIPT.md','\n'.join(body))
        put(prefix+'CORRECTION_NOTES.md',f"# {vid} — corrections and evidence boundaries\n\n"+narrative['corrections']+'\n\nThe source entries retain specific reported failures and limitations. These notes are editorial groupings, not a complete error census. Private IDs and paths are omitted from the publication projection; exact private originals remain preserved.\n')
        checks=[f'# {vid} — owner publication review checklist','',
                'Every item is pending until you review it. Checking a box records a decision; it does not itself publish anything.','',
                '- [ ] I reviewed this period’s dates, coverage gaps and source counts.',
                '- [ ] I reviewed every selected catalogue item or recorded specific exclusions in the review decisions.',
                '- [ ] The distinction between my direction and assistant-generated material is correct.',
                '- [ ] Historical names and later changes have not been backdated.',
                '- [ ] Private, personal, biometric, security and third-party information is acceptable for the proposed disclosure.',
                '- [ ] Requirements, concepts, code presence, execution and validation are accurately distinguished.',
                '- [ ] Reported mistakes, contrary evidence and unresolved findings remain visible.',
                '- [ ] Reproduction instructions and the available evidence support the exact claims I intend to release.',
                '- [ ] Attribution, third-party notices and the existing license are retained.',
                '- [ ] I have marked individual files/items include, exclude or needs-edit, and identified the intended release venue.',
                '- [ ] I approve only the exact final file manifest after the recorded edits are applied.','',
                'Decision: PENDING  \nReviewer: __________  \nDate: __________  \nRequired edits / excluded IDs: __________','',
                'Approval of this checklist is separate from any later request to upload or submit.']
        put(prefix+'REVIEW_CHECKLIST.md','\n'.join(checks))
        index.append({'period':period,'population_counts':stats,'title':narrative['title'],'files':[prefix+n for n in ['MANUSCRIPT.md','CATALOGUE.md','records.json','COVERAGE.json','navigation.json','CORRECTION_NOTES.md','REVIEW_CHECKLIST.md']]})
    jput('SERIES_INDEX.json',{'edition':scope['edition'],'cutoff_exclusive':scope['cutoff_exclusive'],
         'volumes':index,'source_population_counts':dict(counts),'count_limit':nonadditive,
         'unassigned_count':len(unmatched),'unassigned_decisions':dict(collections.Counter(r['selection']['decision'] for r in unmatched)),
         'owner_review_status':'PENDING','publication_performed':False})
    jput('REVIEW_DECISIONS.template.json',{'schema':'qel-owner-review-decisions/1','edition':scope['edition'],
         'review_status':'PENDING','publication_authorization':False,'items':review_items,
         'unassigned_items':[{'key':r['source_population']+':'+r['id'],'recorded_date':r['recorded_date'],'decision':'pending','reason':r['selection']} for r in unmatched]})
    return files

def validate_inputs(inputs):
    m=read(inputs/'INPUTS_MANIFEST.json')
    for item in m['files']:
        p=inputs/item['path']
        if p.resolve().parent!=inputs.resolve(): raise ValueError('Unexpected nested input path')
        b=p.read_bytes()
        if len(b)!=item['bytes'] or h(b)!=item['sha256']:raise ValueError('Input integrity mismatch: '+item['path'])
    return m

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--inputs',type=Path,default=Path(__file__).resolve().parent/'inputs')
    group=ap.add_mutually_exclusive_group(required=True)
    group.add_argument('--output',type=Path,help='New empty output folder')
    group.add_argument('--verify',type=Path,help='Existing generated folder to compare without modifying it')
    args=ap.parse_args()
    validate_inputs(args.inputs)
    files=build(args.inputs)
    if args.verify:
        actual={p.relative_to(args.verify).as_posix() for p in args.verify.rglob('*') if p.is_file()}
        expected=set(files)
        assert actual==expected, 'Generated file list differs: '+str(sorted(actual^expected))
        for name,b in files.items():
            assert (args.verify/name).read_bytes()==b, 'Reproduction mismatch: '+name
        print(json.dumps({'state':'PASS','generated_files_compared':len(files),'comparison':'byte-for-byte','network_used':False}))
    else:
        if args.output.exists() and any(args.output.iterdir()): raise ValueError('Output folder must be empty; nothing overwritten.')
        args.output.mkdir(parents=True,exist_ok=True)
        for name,b in files.items():
            dest=args.output/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
        print(json.dumps({'state':'BUILT','generated_files':len(files),'output':str(args.output)}))
if __name__=='__main__':main()
