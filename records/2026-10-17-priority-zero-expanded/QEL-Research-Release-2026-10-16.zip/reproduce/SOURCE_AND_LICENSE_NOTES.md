# Source, modifications and retained notices

Project direction and attribution: **Sherman G. Laing / Quantum.Earth.Laing**. GAUCIA Actual is the current primary project agent. Codex is the supporting reviewer and author of the new October 16, 2026 packaging wrapper, source selection and quantum teaching fixtures. Historical assistant identities are not changed or backdated.

The exact existing documentary research/evaluation license and attribution are retained at `notices/LICENSE.md` and `notices/ATTRIBUTION.md`. They describe noncommercial evaluation, code execution and research reproduction within their scope. They are not an unrestricted open-source grant and do not replace independently applicable licenses. This preparation does not grant new rights to withheld sources or third-party material. It does not publish the candidate or accept a hosting agreement.

## Bible source

The 24 selected source files are exact bytes from the previously acquired public repository `0-Actual/sherman-gaucia-laing-bible-replay`, commit `f15f6127c3538b338d9462ad8b52e9d137ebab30`. `SOURCE_MAP.json` records pinned URLs, Git blob IDs and SHA-256 identities. The executable subset includes the adapter, tests, recovered engine and all six selected studies. Existing `LICENSE.md`, `ATTRIBUTION.md`, `THIRD_PARTY_NOTICES.md`, `CITATION.cff`, `REPLAY.md` and `HISTORICAL_SOURCE_NOTES.md` are preserved in `bible-replay/`.

This is not a complete clone. The browser app, broader historical verifier, policy documents and earlier output receipts are omitted from the minimal runnable selection. Inherited documentation may reference those omitted files. Use this candidate's `REPRODUCE.md` for current commands. KJV quotations, source-language spellings and the separately discussed WEB material retain their source distinctions; the repository does not claim ownership of Scripture. No missing images, full Greek corpus or model assets are supplied.

## Hebrew H04.1

Fifty-two selected members are copied exactly from the preserved H04.1 build archive, whose SHA-256 is recorded in the source map. The original work is the **Open Scriptures Hebrew Bible**, available at <https://github.com/openscriptures/morphhb>, source commit `3d15126fb1ef74867fc1434be1942e837932691f`. Unchanged upstream `LICENSE.md` and `README.md` are included. The upstream notice states CC BY 4.0 and requires attribution; those terms remain in force and are not restricted by the documentary license.

The converter is a modified upstream tool prepared for the owner's review; its H04-to-H04.1 patch is included. H04.1 records replacement intent before mutation and reconciles bytes during rollback. The exact test suite has synthetic fixtures. All 40 XML inputs, both expected exports and the portable full-export checker are included. Earlier private receipts and the obsolete path-dependent corpus harness are omitted. The exact original Jeremiah XML, four-attribute correction patch, review and supporting lexicon evidence are retained; their references may point to broader evidence outside this selection. No upstream endorsement or exhaustive linguistic validation is claimed. Inclusion and byte verification of corpus files are not new corpus execution.

## Documentary and Q8 selections

The series builder, six frozen input files and input manifest are unchanged selected bytes from the existing Research-Publication-Series. The expected output manifest is a new list of byte identities for its 46 already-frozen generated files. It does not reconstruct inaccessible original messages.

Counter data, replay code, expected output, redaction ledger and historical scope note are unchanged from the Q8-USB-Publication-Review selection. The redaction ledger describes the projection from private observations. No USB drive root, live counter collector, account profile, credentials or operational controller is supplied. New evidence about the packaging check is kept separate from September observations.

## Quantum scope and remaining credit/license gaps

`quantum-teaching/` is a new, small implementation of standard identities using explicit deterministic fixtures. It is not copied from withheld simulation or optimization programs. It is intended to clarify the reviewed distinctions, not claim authorship of established mathematics or replace the historical benchmark dependencies.

The legacy quantum-core notice is retained separately at `notices/historical-quantum-core-LICENSE.txt` as evidence of the older source terms. It restricts copying/modification/distribution and does not itself provide the desired public reproduction grant. This candidate does not silently resolve that mismatch or relicense the old code. A future selection of those historical files needs a component-specific, owner-resolved rights/provenance statement; this does not block the already authorized reversible preparation of the current subset.

JARVIS 2D, aluminum/VQD, Q8 performance and larger simulation collections remain outside this runnable subset. Publishing their full reproduction inputs would require selecting their actual code/data and preserving each upstream dataset/software notice, including JARVIS/leaderboard notices where applicable. No complete dependency, operational privacy or rights review for those broader collections is implied here.
