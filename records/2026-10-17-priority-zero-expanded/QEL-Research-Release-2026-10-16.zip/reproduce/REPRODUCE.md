# Reproduce the selected data and deterministic checks

This is a separate public-review candidate prepared October 16, 2026. It contains actual inputs, source programs, expected results, source identities and notices. It does not operate the owner's USB environment. No installation, account, API key, model, privileged controller or network request is required by the commands below.

Use **Python 3.12** and its standard library. The packaging check records the precise runtime used; earlier companion guidance accepts Python 3.10+, but this complete selection is checked with Python 3.12. No third-party packages are required. Use a new writable folder for results. On Windows, `py -3.12` may replace `python` if that launcher is installed.

From the extracted candidate directory:

```text
python -B verify_manifest.py
python -B run_checks.py --output ../reproduction-results-01
```

The result directory must not already exist and must be outside the candidate. The wrapper copies the Bible and Hebrew test selections there, records each child exit code and saves `verification.json` plus logs. It checks expected populations and output values before returning success. A failed or interrupted run is not a pass. Pick a fresh output name for another run; no cleanup command or overwrite is required.

## What an independent reader can reproduce now

| Selection | Included input and program | Expected result | What this establishes |
|---|---|---|---|
| Documentary series | Six frozen JSON input files, input manifest and unchanged `documentary/rebuild.py` | 46 generated files match the included expected byte hashes | Deterministic selection, narrative assembly and navigation from the supplied summaries; not recovery of original conversations |
| Q8 observation arithmetic | 990 saved, screened counter readings and unchanged mean calculator | 33 means match the included expected output byte-for-byte | Arithmetic on 3 windows × 11 counters × 30 readings; zero new observations |
| Bible study replay | Six saved studies in Markdown and JSON, recovered reference engine, unchanged adapter and tests | 113 source comparisons; 36 adapter test methods; 40 selected recovered test methods | Saved text/arithmetic replay and declared input/error handling; not historical model inference or theological proof |
| Hebrew H04.1 bounded check | Exact converter and 12-method test suite with inline synthetic fixtures | 12 test methods pass, including 32 metadata-option combinations and four post-replacement interruption cases | These fixture behaviors of the exact H04.1 converter; not a whole-corpus linguistic or remapping certification |
| Hebrew H04.1 optional full replay | All 40 XML inputs, both reference exports and portable export checker | Reader-run exports match the two included reference files byte-for-byte | The complete saved export calculation is reproducible from the included inputs; this preparation verifies their bytes but does not rerun the corpus |
| Quantum teaching | New standard-library implementation and explicit small fixtures | Four fixture groups pass | Tensor representation of a 3-qubit GHZ example, squared norm versus Hamiltonian energy, global-phase equivalence, and a two-level spectral-gap bound; not historical Q8 benchmark replication |

Counts describe different populations and must not be added into a single number of independent experiments. The quantum fixtures and package wrapper are **new editorial teaching/packaging derivatives**, not recovered historical programs or new discoveries. Historical originals and immutable editions are untouched.

## Run each selection separately

```text
python -B documentary/rebuild.py --output ../documentary-results-01
python -B q8-observations/reproduce_means.py ../counter-means-01.json
python -B quantum-teaching/check_fixtures.py
```

The documentary output is compared with `documentary/expected-output-manifest.json` by the combined wrapper. Its input manifest validates the exact six JSON inputs before rebuilding. The counter output should equal `q8-observations/reproduction-result.json`. The teaching fixture program checks the values declared in its `fixtures.json`.

For the Bible and Hebrew selections, use the combined wrapper or copy their whole folders to a disposable writable directory, then run these commands from the respective copied folder:

```text
python -B verify.py
```

```text
python -B verification/test_converter.py
```

Bible verification writes new artifacts and fresh attempt IDs. It checks saved source comparisons and its selected tests; those attempt IDs are not expected to match a prior run. Three archival fingerprint methods are deliberately excluded by the retained verifier. H04.1 tests generate their own small XML/JSON fixtures.

## Optional complete Hebrew export reproduction

The folder `hebrew-h041/` contains all 40 XML files (39 books plus VerseMap), the current converter, both expected reference exports and the portable comparison program. There is no missing corpus dependency. From a writable copy of that folder, an independent reader can run:

```text
python -B verification/verify_exports.py
```

This writes only to its own temporary folder and compares both resulting exports to `corpus-results/issue95-unremapped-with-ids.json` and `corpus-results/issue95-remapped-with-ids.json`. It verifies 43 inputs before and after: converter, 40 XML files and two reference files. The reference byte lengths and SHA-256 values are in `SOURCE_MAP.json` and `MANIFEST.json`. Expected population per export: 39 books and 306,785 selected records, comprising 305,507 direct verse words plus 1,278 alternate-reading records. This is not a single chosen reading or a count of distinct linguistic words; the JSON omits the XML reading-container metadata.

To keep generated exports for inspection, run from that same disposable folder:

```text
python -B candidate/morphhbXML-to-JSON.py --includeIds
python -B candidate/morphhbXML-to-JSON.py --includeIds --remapVerses
```

Those commands write `hebrew.json` and `remapped.json` and may replace existing outputs in the working folder. The combined `run_checks.py` deliberately runs only the synthetic H04.1 suite. **Neither full-corpus command was rerun for this preparation.** Two successful H04.1 full exports are earlier historical evidence; this candidate adds exact-source packaging validation and a newly executed synthetic check, not two new corpus runs.

## Important limits

The counter sampling windows ended before their corresponding USB file-verification operations began. Recalculated means do not measure simultaneous USB load or prove that Q8 caused a system-wide Windows improvement. The historical operation times and their different capture scopes remain in the supplied data; no new timing experiment is performed.

The documentary source populations overlap. Summary rows are not unique interactions, independent studies or raw-message coverage. Original conversation acquisition is incomplete. The included source notices preserve preparation and historical-role distinctions.

The Bible adapter is a later reconstruction using a recovered clean-room reference, not missing historical version 1. It does not reproduce original model weights, inference or unavailable services. H04.1's full corpus and expected exports are included, while the private historical receipts and obsolete path-dependent corpus harness are omitted. Its newly run synthetic tests do not establish 306,785 records were exported in this check. The Jeremiah amendment remains an independent editorial inference affecting four attributes on two words; upstream approval is not claimed. The original Jeremiah XML and patch are included for comparison.

The JARVIS 2D public evidence packet lacks its complete input archive and analysis programs. It is not included as a runnable study. Private aluminum/VQD, optimization, dense scaling and MPS/SOP collections require a separately reviewed portable source/data/dependency selection. Their historical performance, physical hardware and cache conditions are not reproduced here. No historical benchmark has been rerun during this preparation.

Previously prepared historical quantum code exhibits remain outside this minimal executable selection. They retain separate restrictive notices and, in some cases, original-custody or dependency limits. The new teaching fixture does not cure those gaps or establish the old experimental claims. Read `SOURCE_AND_LICENSE_NOTES.md` before redistribution; this package does not create a new blanket license for withheld code.

`SOURCE_MAP.json` identifies exact selected source bytes. `MANIFEST.json` binds this candidate's files, excluding itself to avoid a circular hash. The external packaging verification records the archive identity and the fresh-extraction check. Hashes establish byte identity, not correctness, ownership, certification or endorsement.
