# !/usr/bin/python3
# encoding=utf8

import re
import copy
import sys
import getopt
import json
import os
import tempfile
import shutil
import hashlib
from xml.etree import ElementTree as ET

bookNameData = {}

bookNameData['Gen'] = 'Genesis'
bookNameData['Exod'] = 'Exodus'
bookNameData['Lev'] = 'Leviticus'
bookNameData['Num'] = 'Numbers'
bookNameData['Deut'] = 'Deuteronomy'
bookNameData['Josh'] = 'Joshua'
bookNameData['Judg'] = 'Judges'
bookNameData['Ruth'] = 'Ruth'
bookNameData['1Sam'] = 'I Samuel'
bookNameData['2Sam'] = 'II Samuel'
bookNameData['1Kgs'] = 'I Kings'
bookNameData['2Kgs'] = 'II Kings'
bookNameData['1Chr'] = 'I Chronicles'
bookNameData['2Chr'] = 'II Chronicles'
bookNameData['Ezra'] = 'Ezra'
bookNameData['Neh'] = 'Nehemiah'
bookNameData['Esth'] = 'Esther'
bookNameData['Job'] = 'Job'
bookNameData['Ps'] = 'Psalms'
bookNameData['Prov'] = 'Proverbs'
bookNameData['Eccl'] = 'Ecclesiastes'
bookNameData['Song'] = 'Song of Solomon'
bookNameData['Isa'] = 'Isaiah'
bookNameData['Jer'] = 'Jeremiah'
bookNameData['Lam'] = 'Lamentations'
bookNameData['Ezek'] = 'Ezekiel'
bookNameData['Dan'] = 'Daniel'
bookNameData['Hos'] = 'Hosea'
bookNameData['Joel'] = 'Joel'
bookNameData['Amos'] = 'Amos'
bookNameData['Obad'] = 'Obadiah'
bookNameData['Jonah'] = 'Jonah'
bookNameData['Mic'] = 'Micah'
bookNameData['Nah'] = 'Nahum'
bookNameData['Hab'] = 'Habakkuk'
bookNameData['Zeph'] = 'Zephaniah'
bookNameData['Hag'] = 'Haggai'
bookNameData['Zech'] = 'Zechariah'
bookNameData['Mal'] = 'Malachi'

stripPointing = False
removeLemmaTypes = False
stripHFromMorph = False
prefixLemmasWithH = False
remapVerses = False
splitByBook = False
includeIds = False


def getBookData(filename):
    tree = ET.parse(filename)
    namespaces = {
        'osis': 'http://www.bibletechnologies.net/2003/OSIS/namespace'}

    chapters = tree.getroot().findall('.//osis:chapter', namespaces)

    bookData = []

    for chapter in chapters:
        verses = chapter.findall('.//osis:verse', namespaces)
        verseArray = []

        for verse in verses:
            words = verse.findall('.//osis:w', namespaces)
            wordArray = []

            for word in words:
                singleWordArray = []

                lemma = word.attrib.get('lemma')

                if lemma is not None and removeLemmaTypes:
                    lemma = removeLemmaTypesFunc(lemma)
                if lemma is not None and prefixLemmasWithH:
                    # print(lemma)
                    lemma = prefixLemmasWithHFunc(lemma)
                    # print(lemma)

                morph = word.attrib.get('morph')

                if morph and stripHFromMorph:
                    morph = stripHFromMorphFunc(morph)

                wordText = ''.join(word.itertext()) if len(word) else word.text
                if stripPointing and wordText is not None:
                    wordText = stripPointingFunc(wordText)
                singleWordArray.append(wordText)
                singleWordArray.append(lemma)
                singleWordArray.append(morph)
                if includeIds:
                    singleWordArray.append(word.attrib.get('id'))

                wordArray.append(singleWordArray)

            verseArray.append(wordArray)

        bookData.append(verseArray)

    return bookData


def prefixLemmasWithHFunc(lemmaString):
    lemmaArray = lemmaString.split('/')
    returnArray = []
    for lemma in lemmaArray:
        returnArray.append('H' + lemma)
    returnString = '/'.join(returnArray)
    return returnString


def stripHFromMorphFunc(string):
    if string.find('H') == 0:
        return string[1:]

    return string


def removeLemmaTypesFunc(string):
    return re.sub(r" [abcdef]|\+", "", string)


def stripPointingFunc(string):
    return re.sub(r"[\u0591-\u05c7]", "", string)


def printUsage(file=sys.stdout):
    print('Usage: python3 ' + os.path.basename(__file__) +
          ' [-h|--help] [--stripPointing] [--removeLemmaTypes]'
          ' [--stripHFromMorph] [--prefixLemmasWithH] [--remapVerses]'
          ' [--splitByBook] [--includeIds]', file=file)


def getCommandOptions(argv):
    global stripPointing
    global removeLemmaTypes
    global stripHFromMorph
    global prefixLemmasWithH
    global remapVerses
    global splitByBook
    global includeIds

    try:
        opts, args = getopt.getopt(argv, "h",
                                   [
                                       "help",
                                       "stripPointing",
                                       "removeLemmaTypes",
                                       "stripHFromMorph",
                                       "prefixLemmasWithH",
                                       "remapVerses",
                                       "splitByBook",
                                       "includeIds"
                                   ])
    except getopt.GetoptError as error:
        print(str(error), file=sys.stderr)
        printUsage(file=sys.stderr)
        sys.exit(2)
    if args:
        print('Unexpected positional arguments: ' + ' '.join(args), file=sys.stderr)
        printUsage(file=sys.stderr)
        sys.exit(2)
    for opt, arg in opts:
        if opt in ('-h', '--help'):
            printUsage()
            sys.exit()
        elif opt in ("--stripPointing"):
            print('stripPointing')
            stripPointing = True
        elif opt in ("--removeLemmaTypes"):
            print('removeLemmaTypes')
            removeLemmaTypes = True
        elif opt in ("--stripHFromMorph"):
            print('stripHFromMorph')
            stripHFromMorph = True
        elif opt in ("--prefixLemmasWithH"):
            print('prefixLemmasWithH')
            prefixLemmasWithH = True
        elif opt in ("--remapVerses"):
            print('remapVerses')
            remapVerses = True
        elif opt in ("--splitByBook"):
            print('splitByBook')
            splitByBook = True
        elif opt in ("--includeIds"):
            print('includeIds')
            includeIds = True


def remapBookData(hebrew):
    # map hebrew to english verses
    filename = 'wlc/VerseMap.xml'
    tree = ET.parse(filename)
    namespaces = {'vm': 'http://www.APTBibleTools.com/namespace'}
    books = tree.getroot().findall('.//vm:book', namespaces)

    # must use deep copy here
    remapped = copy.deepcopy(hebrew)

    for book in books:
        verses = book.findall('.//vm:verse', namespaces)

        for verse in verses:
            if verse.attrib['type'] == 'full':
                # take the wlc verse and move it to the kjv position
                wlcRef = verse.attrib['wlc']
                wlcVerseArray = wlcRef.split('.')
                kjvRef = verse.attrib['kjv']
                kjvVerseArray = kjvRef.split('.')

                kjvBook = bookNameData[kjvVerseArray[0]]
                kjvChapter = int(kjvVerseArray[1]) - 1
                kjvVerse = int(kjvVerseArray[2]) - 1

                wlcBook = bookNameData[wlcVerseArray[0]]
                wlcChapter = int(wlcVerseArray[1]) - 1
                wlcVerse = int(wlcVerseArray[2]) - 1

                wlcData = hebrew[wlcBook][wlcChapter][wlcVerse]

                if kjvBook == 'Psalms' and kjvVerse == 0:
                    remapped[kjvBook][kjvChapter][kjvVerse] = hebrew[wlcBook][wlcChapter][wlcVerse - 1] + wlcData
                    remapped[wlcBook][wlcChapter][wlcVerse] = []
                else:
                    if kjvChapter >= len(remapped[kjvBook]):
                        remapped[kjvBook].append([])
                    if kjvVerse >= len(remapped[kjvBook][kjvChapter]):
                        remapped[kjvBook][kjvChapter].append([])
                    remapped[kjvBook][kjvChapter][kjvVerse] = wlcData.copy()
                    if wlcChapter < kjvChapter or (wlcChapter == kjvChapter and wlcVerse > kjvVerse) or wlcChapter > kjvChapter:
                        remapped[wlcBook][wlcChapter][wlcVerse] = []

        # delete those empty entries now
        verses.reverse()
        for verse in verses:
            if verse.attrib['type'] == 'full':
                wlcRef = verse.attrib['wlc']
                wlcVerseArray = wlcRef.split('.')

                wlcBook = bookNameData[wlcVerseArray[0]]
                wlcChapter = int(wlcVerseArray[1]) - 1
                wlcVerse = int(wlcVerseArray[2]) - 1

                if len(remapped[wlcBook][wlcChapter][wlcVerse]) == 0:
                    del remapped[wlcBook][wlcChapter][wlcVerse]

    # Preserve both source bodies at the three reviewed occupied targets.
    # Read the immutable WLC arrays: the old source slots may now be valid
    # destinations for subsequent verses and must not be cleared again.
    remapped['Numbers'][25][0] = hebrew['Numbers'][24][18] + hebrew['Numbers'][25][0]
    remapped['I Samuel'][19][41] = hebrew['I Samuel'][19][41] + hebrew['I Samuel'][20][0]
    remapped['I Chronicles'][11][3] = hebrew['I Chronicles'][11][3] + hebrew['I Chronicles'][11][4]

    # Keep the existing title-with-first-verse convention, including both
    # title segments when VerseMap has two sources targeting verse 1.
    for psalm in (51, 52, 54, 60):
        source = hebrew['Psalms'][psalm - 1]
        remapped['Psalms'][psalm - 1][0] = source[0] + source[1] + source[2]

    # This WLC population has no separate body for KJV Nehemiah 7:68.
    # Preserve the empty address after cleanup; 7:69-73 retain their shifts.
    remapped['Nehemiah'][6][67] = []

    # Fix partial verses manually
    remapped['I Kings'][17][32] = hebrew['I Kings'][17][32] + \
        hebrew['I Kings'][17][33]
    remapped['I Kings'][17][32][19:43] = []
    remapped['I Kings'][17][33][0:10] = []
    remapped['I Kings'][19][1] = hebrew['I Kings'][19][1] + \
        hebrew['I Kings'][19][2]
    remapped['I Kings'][19][1][13:34] = []
    remapped['I Kings'][19][2][0:6] = []

    remapped['I Kings'][21][20][8:19] = []
    remapped['I Kings'][21][21] = hebrew['I Kings'][21][20] + \
        hebrew['I Kings'][21][21]
    remapped['I Kings'][21][21][0:8] = []

    remapped['I Kings'][21][42] = hebrew['I Kings'][21][42] + \
        hebrew['I Kings'][21][43]

    remapped['Isaiah'][63][0] = hebrew['Isaiah'][62][18].copy()
    remapped['Isaiah'][62][18][8:23] = []
    remapped['Isaiah'][63][0][0:8] = []

    # VerseMap splits WLC Psalm 13:6 after its sixth word.
    remapped['Psalms'][12][4] = hebrew['Psalms'][12][5][:6]
    remapped['Psalms'][12].append(hebrew['Psalms'][12][5][6:])

    return remapped


def writeOutputs(outputs):
    """Stage all JSON before replacement; roll back handled replacement failures.

    Each file replacement is atomic. The multi-file set is not atomic across
    a forced process termination or power loss. Keep recovery files if rollback
    cannot complete; never silently discard the last good copies.
    """
    if not outputs:
        raise ValueError('No output files')
    targets = [os.path.abspath(name) for name, _ in outputs]
    if len(set(os.path.normcase(name) for name in targets)) != len(targets):
        raise ValueError('Duplicate output path')
    parent = os.path.dirname(targets[0])
    if any(os.path.dirname(target) != parent for target in targets):
        raise ValueError('Output files must share one directory')
    os.makedirs(parent, exist_ok=True)
    for target in targets:
        if os.path.lexists(target) and (os.path.islink(target) or not os.path.isfile(target)):
            raise ValueError('Output is not a regular file: ' + target)
    staging = tempfile.mkdtemp(prefix='.hebrew-export-', dir=parent)
    attempted = []
    backups = {}
    installed_hashes = {}
    cleanup = True
    def digest(filename):
        result = hashlib.sha256()
        with open(filename, 'rb') as stream:
            for block in iter(lambda: stream.read(1024 * 1024), b''):
                result.update(block)
        return result.digest()
    def unchanged(target):
        backup = backups.get(target)
        if backup:
            return (not os.path.islink(target) and os.path.isfile(target) and
                    digest(target) == digest(backup))
        return not os.path.lexists(target)
    try:
        for index, ((_, value), target) in enumerate(zip(outputs, targets)):
            staged = os.path.join(staging, str(index) + '.new')
            with open(staged, 'x', encoding='utf8') as stream:
                json.dump(value, stream, ensure_ascii=False)
                stream.flush()
                os.fsync(stream.fileno())
            installed_hashes[target] = digest(staged)
            if os.path.exists(target):
                backup = os.path.join(staging, str(index) + '.old')
                shutil.copyfile(target, backup)
                backups[target] = backup
        # These checks detect observed changes, not an exclusive writer lock.
        for target in targets:
            if not unchanged(target):
                raise RuntimeError('Output changed during preparation: ' + target)
        try:
            for index, target in enumerate(targets):
                if not unchanged(target):
                    raise RuntimeError('Output changed before replacement: ' + target)
                # Record intent first: an interrupt can arrive after the system
                # replaces the file but before the next Python instruction.
                attempted.append(target)
                os.replace(os.path.join(staging, str(index) + '.new'), target)
        except BaseException:
            # Preserve recovery data even if rollback is itself interrupted.
            cleanup = False
            recovery_errors = []
            for target in reversed(attempted):
                try:
                    # A replacement can fail before changing the destination.
                    if unchanged(target):
                        continue
                    if (os.path.islink(target) or not os.path.isfile(target) or
                            digest(target) != installed_hashes[target]):
                        raise OSError('Output changed after replacement; retained: ' + target)
                    if target in backups:
                        os.replace(backups[target], target)
                    else:
                        os.unlink(target)
                except OSError as error:
                    recovery_errors.append(str(error))
            if recovery_errors:
                raise RuntimeError('Output rollback incomplete; recovery files retained at ' +
                                   staging + ': ' + '; '.join(recovery_errors))
            cleanup = True
            raise
    finally:
        if cleanup:
            # This directory was created by mkdtemp directly beneath parent.
            if os.path.dirname(os.path.abspath(staging)) != parent or os.path.islink(staging):
                raise RuntimeError('Unexpected staging directory; cleanup refused')
            shutil.rmtree(staging)


def main():

    hebrew = {}
    for bookNameShort in bookNameData.keys():
        hebrew[bookNameData[bookNameShort]] = getBookData(
            'wlc/' + bookNameShort + '.xml')

    if remapVerses:
        final = remapBookData(hebrew)
    else:
        final = hebrew

    name = 'remapped' if remapVerses else 'hebrew'

    if splitByBook:
        output_dir = os.path.join('./json', name)
        outputs = [(os.path.join(output_dir, book.replace(" ", "").lower()) + '.json', final[book])
                   for book in final]
    else:
        outputs = [(name + '.json', final)]
    writeOutputs(outputs)


if __name__ == "__main__":
    getCommandOptions(sys.argv[1:])
    main()
