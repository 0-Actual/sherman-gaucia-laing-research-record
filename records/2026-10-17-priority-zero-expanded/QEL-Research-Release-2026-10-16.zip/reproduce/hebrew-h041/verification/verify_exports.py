"""Reproduce the two packaged exports in a disposable local directory."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    paths = [ROOT/'candidate/morphhbXML-to-JSON.py', *sorted((ROOT/'wlc').glob('*.xml')),
             *sorted((ROOT/'corpus-results').glob('*.json'))]
    if len(paths) != 43:
        raise RuntimeError('Expected converter, 40 XML files, and two reference exports')
    before = {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}
    runs = []
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with tempfile.TemporaryDirectory(prefix='verify-exports-', dir=ROOT) as folder:
        scratch = Path(folder)
        shutil.copytree(ROOT/'wlc', scratch/'wlc')
        for remap in (False, True):
            flags = ['--includeIds'] + (['--remapVerses'] if remap else [])
            result = subprocess.run([sys.executable, '-B', str(paths[0]), *flags], cwd=scratch,
                                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            if result.returncode:
                raise RuntimeError('Converter failed: '+result.stderr.decode('utf-8', errors='replace'))
            name = 'issue95-'+('remapped' if remap else 'unremapped')+'-with-ids.json'
            actual = scratch/('remapped.json' if remap else 'hebrew.json')
            expected = ROOT/'corpus-results'/name
            if actual.read_bytes() != expected.read_bytes():
                raise RuntimeError('Export differs: '+name)
            data = json.loads(actual.read_text(encoding='utf-8'))
            records = [word for book in data.values() for chapter in book for verse in chapter for word in verse]
            if len(data) != 39 or len(records) != 306785 or len({word[3] for word in records}) != 306785:
                raise RuntimeError('Unexpected book, record, or unique-ID population')
            runs.append({'flags':flags, 'exitCode':result.returncode, 'reference':name,
                         'sha256':sha(actual), 'bytes':actual.stat().st_size, 'books':len(data),
                         'records':len(records), 'uniqueIds':306785, 'exactBytesMatch':True})
    after = {p.relative_to(ROOT).as_posix(): sha(p) for p in paths}
    if before != after:
        raise RuntimeError('Packaged input changed during verification')
    print(json.dumps({'schema':'QEL_PORTABLE_EXPORT_VERIFICATION_V1', 'state':'PASS',
                      'startedUtc':started, 'finishedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                      'pythonVersion':sys.version, 'runs':runs, 'inputSha256':before,
                      'inputFiles':len(paths), 'inputsUnchanged':True}, indent=2))

if __name__ == '__main__':
    main()
