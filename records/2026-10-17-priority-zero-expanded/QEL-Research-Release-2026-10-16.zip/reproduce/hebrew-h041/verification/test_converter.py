import contextlib
import importlib.util
import io
import itertools
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
CANDIDATE = ROOT/'candidate/morphhbXML-to-JSON.py'

def module():
    spec = importlib.util.spec_from_file_location('candidate', CANDIDATE)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded

class ConverterTests(unittest.TestCase):
    def setUp(self):
        self.converter = module()
        self.temp = tempfile.TemporaryDirectory(dir=ROOT)
        self.root = Path(self.temp.name)
    def tearDown(self):
        self.temp.cleanup()

    def test_missing_optional_metadata_all_transform_combinations(self):
        fixture = self.root/'fixture.xml'
        fixture.write_text('<osis xmlns="http://www.bibletechnologies.net/2003/OSIS/namespace"><chapter><verse>'
                           '<w id="T1">אָ<seg>ב</seg>ג</w><w id="T2" lemma="b/7225 a" morph="HNcfsa">בְּ/רֵאשִׁית</w>'
                           '</verse></chapter></osis>', encoding='utf-8')
        keys = ['removeLemmaTypes','prefixLemmasWithH','stripHFromMorph','stripPointing','includeIds']
        for values in itertools.product([False, True], repeat=len(keys)):
            with self.subTest(flags=values):
                for key, value in zip(keys, values):
                    setattr(self.converter, key, value)
                words = self.converter.getBookData(fixture)[0][0]
                self.assertEqual(words[0][0], 'אבג' if values[3] else 'אָבג')
                self.assertEqual(words[0][1:3], [None,None])
                self.assertEqual(len(words[0]), 4 if values[4] else 3)
                lemma = 'b/7225' if values[0] else 'b/7225 a'
                if values[1]: lemma = '/'.join('H'+part for part in lemma.split('/'))
                self.assertEqual(words[1][1], lemma)
                self.assertEqual(words[1][2], 'Ncfsa' if values[2] else 'HNcfsa')

    def test_unremapped_export_never_reads_mapping(self):
        old_cwd = Path.cwd()
        try:
            os.chdir(self.root)
            self.converter.bookNameData = {'Gen':'Genesis'}
            self.converter.getBookData = lambda _: [[[['אב',None,None]]]]
            with patch.object(self.converter, 'remapBookData', side_effect=AssertionError('unused mapping')):
                self.converter.main()
            self.assertEqual(json.loads((self.root/'hebrew.json').read_text(encoding='utf-8')),
                             {'Genesis':[[[['אב',None,None]]]]})
        finally:
            os.chdir(old_cwd)

    def test_invalid_cli_is_rejected_before_mutation(self):
        for arguments in [['file','--includeIds'],['--includeIds','file'],['--wrong']]:
            new = module()
            with self.subTest(arguments=arguments), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit) as raised: new.getCommandOptions(arguments)
                self.assertEqual(raised.exception.code, 2)
                self.assertFalse(new.includeIds)

    def test_help_uses_actual_filename(self):
        for option in ['-h','--help']:
            with self.subTest(option=option), patch.object(self.converter, 'printUsage') as usage:
                with self.assertRaises(SystemExit) as raised: self.converter.getCommandOptions([option])
                self.assertIn(raised.exception.code, [None,0])
                usage.assert_called_once()
        output = io.StringIO()
        self.converter.printUsage(file=output)
        self.assertIn(CANDIDATE.name, output.getvalue())

    def test_partial_staged_write_preserves_old_export(self):
        target = self.root/'hebrew.json'
        target.write_bytes(b'previous valid bytes')
        def fail(value, stream, **kwargs):
            stream.write('{"partial":')
            raise OSError('simulated disk write failure')
        with patch.object(self.converter.json, 'dump', side_effect=fail), self.assertRaises(OSError):
            self.converter.writeOutputs([(str(target), {'new':1})])
        self.assertEqual(target.read_bytes(), b'previous valid bytes')
        self.assertFalse(list(self.root.glob('.hebrew-export-*')))

    def test_split_collision_preserves_every_existing_file(self):
        first = self.root/'genesis.json'; first.write_bytes(b'old genesis')
        blocked = self.root/'exodus.json'; blocked.mkdir()
        last = self.root/'leviticus.json'; last.write_bytes(b'old leviticus')
        with self.assertRaises(ValueError):
            self.converter.writeOutputs([(str(first),[]),(str(blocked),[]),(str(last),[])])
        self.assertEqual(first.read_bytes(), b'old genesis')
        self.assertEqual(last.read_bytes(), b'old leviticus')

    def test_later_replace_failure_rolls_back_existing_and_new(self):
        for prior in [False,True]:
            with self.subTest(existing=prior):
                first=self.root/('first'+str(prior)+'.json')
                second=self.root/('second'+str(prior)+'.json')
                if prior: first.write_bytes(b'old')
                actual = os.replace
                def fail(source,target):
                    if Path(source).name == '1.new': raise OSError('second replace failed')
                    return actual(source,target)
                with patch.object(self.converter.os, 'replace', side_effect=fail), self.assertRaises(OSError):
                    self.converter.writeOutputs([(str(first),['new']), (str(second),[])])
                if prior: self.assertEqual(first.read_bytes(), b'old')
                else: self.assertFalse(first.exists())
                self.assertFalse(second.exists())

    def test_newer_edit_during_rollback_is_retained(self):
        first=self.root/'first.json'; first.write_bytes(b'old')
        second=self.root/'second.json'
        actual=os.replace
        def fail(source,target):
            if Path(source).name == '1.new':
                first.write_bytes(b'newer owner edit')
                raise OSError('second replace failed')
            return actual(source,target)
        with patch.object(self.converter.os, 'replace', side_effect=fail), self.assertRaisesRegex(RuntimeError,'rollback incomplete'):
            self.converter.writeOutputs([(str(first),['new']), (str(second),[])])
        self.assertEqual(first.read_bytes(), b'newer owner edit')
        recovery=list(self.root.glob('.hebrew-export-*'))
        self.assertEqual(len(recovery),1)
        self.assertEqual((recovery[0]/'0.old').read_bytes(),b'old')

    def test_interrupted_rollback_retains_original_backup(self):
        first=self.root/'first.json'; first.write_bytes(b'old')
        second=self.root/'second.json'
        actual=os.replace
        def fail(source,target):
            if Path(source).name == '1.new': raise OSError('second replace failed')
            if Path(source).name == '0.old': raise KeyboardInterrupt('rollback interrupted')
            return actual(source,target)
        with patch.object(self.converter.os, 'replace', side_effect=fail), self.assertRaises(KeyboardInterrupt):
            self.converter.writeOutputs([(str(first),['new']), (str(second),[])])
        recovery=list(self.root.glob('.hebrew-export-*'))
        self.assertEqual(len(recovery),1)
        self.assertEqual((recovery[0]/'0.old').read_bytes(),b'old')

    def test_completed_outputs_match_json_and_cleanup(self):
        first=self.root/'first.json'; first.write_bytes(b'old')
        second=self.root/'second.json'
        self.converter.writeOutputs([(str(first),['אב']), (str(second),{'a':2})])
        self.assertEqual(first.read_text(encoding='utf-8'), json.dumps(['אב'],ensure_ascii=False))
        self.assertEqual(json.loads(second.read_text()),{'a':2})
        self.assertFalse(list(self.root.glob('.hebrew-export-*')))

    def test_interrupt_after_successful_replace_restores_entire_set(self):
        for prior, stop_index in itertools.product([False, True], [0, 1]):
            with self.subTest(existing=prior, afterReplacement=stop_index):
                directory=self.root/('case-'+str(prior)+'-'+str(stop_index))
                directory.mkdir()
                first=directory/'first.json'; second=directory/'second.json'
                if prior:
                    first.write_bytes(b'old first'); second.write_bytes(b'old second')
                actual=os.replace
                def interrupt_after_replace(source,target):
                    actual(source,target)
                    if Path(source).name == str(stop_index)+'.new':
                        raise KeyboardInterrupt('after successful replacement')
                with patch.object(self.converter.os,'replace',side_effect=interrupt_after_replace), self.assertRaises(KeyboardInterrupt):
                    self.converter.writeOutputs([(str(first),['new first']), (str(second),['new second'])])
                if prior:
                    self.assertEqual(first.read_bytes(),b'old first')
                    self.assertEqual(second.read_bytes(),b'old second')
                else:
                    self.assertFalse(first.exists()); self.assertFalse(second.exists())
                self.assertFalse(list(directory.glob('.hebrew-export-*')))

    def test_failure_before_first_replace_preserves_originals(self):
        first=self.root/'first.json'; first.write_bytes(b'old first')
        second=self.root/'second.json'; second.write_bytes(b'old second')
        with patch.object(self.converter.os,'replace',side_effect=OSError('before effect')), self.assertRaises(OSError):
            self.converter.writeOutputs([(str(first),[]),(str(second),[])])
        self.assertEqual(first.read_bytes(),b'old first')
        self.assertEqual(second.read_bytes(),b'old second')
        self.assertFalse(list(self.root.glob('.hebrew-export-*')))

if __name__ == '__main__': unittest.main(verbosity=2)
