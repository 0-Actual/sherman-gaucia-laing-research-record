"""New October 16, 2026 wrapper: check selected bytes, not scientific validity."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent

def verify(root=ROOT):
    manifest = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    expected = {r['path']:r for r in manifest['files']}
    if len(expected) != len(manifest['files']): raise ValueError('Duplicate manifest path')
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name != '__pycache__'}
    actual = {p for p in actual if '__pycache__' not in Path(p).parts}
    if actual != set(expected) | {'MANIFEST.json'}: raise ValueError('Candidate file list differs')
    for name, row in expected.items():
        p = root/name
        if p.is_symlink() or root.resolve() not in p.resolve().parents: raise ValueError('Unsafe source path')
        data = p.read_bytes()
        if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('Source mismatch: '+name)
    return len(expected)

if __name__ == '__main__':
    print(json.dumps({'status':'PASS','files':verify(),'scope':'Byte identity only'}))
