# Attribution and preparation

Sherman Gaucia Laing / Quantum.Earth.Laing is the owner, principal researcher and directing author. Contributions are attributed individually: owner requirements, questions, corrections and creative seeds remain distinct from assistant-generated explanations, proposals, source and prose. The historical assistant was Thunder where documented; GAUCIA Actual is the current primary project agent. Codex and delegated reviewers prepared this series.

The series adds six-calendar-month selection, separate source-table identities, privacy projections, editorial navigation, dated narrative/correction notes, source/replay manifests and an owner-review worksheet. Earlier prepared work and original records remain preserved. Each paper derivative identifies changes, source date and current addendum. Later names and capabilities are not backdated.

The existing documentary license is retained unchanged. Third-party software/data and previously applicable licenses remain in force; the root license does not replace companion notices. No publication venue agreement, external submission, owner signature, institutional endorsement or certification has been created. Current preparation does not establish that a named runtime was active in every historical event.

The first-period attribution record is preserved separately as historical edition context; its date and narrower scope remain its own. Source event, review, preparation and future publication dates are distinct.
