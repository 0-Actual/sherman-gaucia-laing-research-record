# Successful execution and a failed report are separate results

Prepared October 16, 2026 for owner review. Primary project agent: GAUCIA Actual.
Supporting reviewer: Codex. No new experiment or public change was performed.

The GitHub research record documents cases matching the owner's observation:
a program completed successfully, while a later verifier or recording step
failed. The publication should identify which stage failed, preserving the
successful execution and the reporting defect together.

## Closest match: WF018 V1

The September 4 entry `QEL-PW-0351` records successful classical benchmark work:
6/6 core checks, 39/39 Node verifier checks, and the stated 64¹–64³ workloads.
Its receipt profile then rejected a legitimate empty stderr stream and failed.
That is an error in receipt validation, not evidence that the benchmark payload
failed. An empty stderr stream alone would not prove success; the recorded
completed checks are the positive evidence here.

This entry was read from the current GitHub default-branch head at commit
`f56f010386cb5d08c2c1f0168f7627fe81186463`:
[WF018 V1 record](https://github.com/0-Actual/sherman-gaucia-laing-research-record/blob/f56f010386cb5d08c2c1f0168f7627fe81186463/records/2026-10-01-prior-work/prior-work.json#L4319).
It is a historical documentary summary; this review has not newly acquired
the original V1 validator line or complete execution logs.

The later `QEL-PW-0355` entry reports the V2 official transaction completed once,
returned PASS, ran three ordered steps and produced five artifacts. Keep that
later event separate from V1 rather than rewriting the first receipt as though
its reporting problem never happened. The existing learning-history entry
`QEL-LEARN-D072` already preserves this distinction.

## Two related cases

| Case | Execution evidence | Separate defect or limitation | Publication treatment |
|---|---|---|---|
| WF022 | `QEL-PW-0360` reports 30 GiB processed, 7,680 circuit runs and official exit zero | `QEL-SER-C293` records 277/278 verifier checks because array ordering was compared where path-keyed set agreement was required; the correction passed 278/278 | Describe a successful recorded workload and an ordering-dependent verifier error. These are different counting populations. |
| WF020/C002 closure | The retained report states all 16 tests passed with exit zero | The later inline recording command failed because of argument quoting; its receipt explicitly says `FAIL_RETAINED_POST_TEST_PASS` and `test_result_affected: false` | Preserve the test pass and the failed recording attempt. Here `false` means the earlier test result was **not affected**, not that the tests failed. |

For the C002 closure case, the failure receipt is explicitly a transcription of
tool-observed output; exact process stderr was not retained. The report and that
receipt are directly readable in the preserved collection. Their source identities
and locators are retained in the private review record. This review did not rerun
the tests or independently observe the original laptop event.

## How the publication will classify status

Record launch, payload execution, correctness checks, performance targets,
receipt validation and final reporting separately. A failed outer command does
not automatically negate completed inner work. Conversely, an exit-zero process
does not by itself prove mathematical correctness or that a performance target
was met. Interpret each Boolean flag by its field name and documented meaning.

Do not relabel every failure as success. The separate WF018 argument-collision
incident started no transaction; the C002 first resource gate failed before Node
execution. The later Q8 timing reductions of about 17.1% and 13.3% genuinely
missed their 20% goal even though those calculations ran successfully. Those
records retain their own correct classifications.

The existing GitHub entry and learning-history text already distinguish the
WF018 payload from its receipt failure. This clarification makes the distinction
explicit across future publication summaries; it does not claim a GitHub edit or
silently alter frozen evidence. The exact item the owner had in mind is not
uniquely identified without its link, but these matching cases are documented.

The complete original interaction history remains unavailable. Earlier review
archives remain unchanged, and owner review still precedes publication.
