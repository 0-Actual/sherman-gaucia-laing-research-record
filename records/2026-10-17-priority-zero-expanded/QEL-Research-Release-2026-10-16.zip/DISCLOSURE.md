# What is included, changed and withheld

The bounded review covered 286 files in six proposed documentary folders,
72 members of the H04.1 archive, and the archive container itself: **359
disclosure decisions**, not 359 independent studies. The decisions were 343
eligible for inclusion, six requiring a derivative, and ten held private.
All 278 files in the five non-controller documentary editions remain exact.

The complete eight-file master-controller/prompt review collection stays
private. No exposed credential or arbitrary remote-command API was identified
in that controller; its exclusion follows the owner's chosen boundary for
operational material. Its non-operational principles are explained in
GOVERNANCE_AND_BIBLE.md. This does not silently choose one of its three candidate
identities as the owner's single intended master controller.

One generic read-only manifest helper has identical bytes in both the withheld
controller collection and the allowed quantum edition. It remains in its quantum
verification role; it contains no controller or prompt capability. Exclusions
follow the content and role, rather than treating that shared hash as a secret.

The original H04.1 ZIP stays private, as does its obsolete path-dependent corpus
harness. All 65 otherwise eligible members are retained across the current
reproduction folder and Hebrew history. Four historical JSON receipts now have
locator-only public derivatives. Their dates, results, counts and hashes remain
unchanged; the source/derivative mapping is explicit. New guides and manifests
replace the original package-specific README and inventory for this selection.

Exact private originals, private interactions, environment/browser histories,
private evidence ZIPs and controller bodies are not part of this candidate.
Their absence is not classified as missing research source when the exclusion
is deliberate. Unavailable original conversations and benchmark dependencies
remain separate source-access gaps.

The review screened all listed bytes and examined flagged context and selected
script behavior. No live token/private-key block was identified by that bounded
screen. It is not a guarantee that no conceivable misuse is possible or an
independent security certification. Ordinary mathematics, scientific source,
historical failures and conceptual governance are not excluded merely because
they have more than one possible application.

The 359 decisions describe the original proposed selection. Newly prepared
guides, industry comparisons, portable wrappers and numerical-source selections
have separate review receipts and final manifest identities. They are not
silently counted as part of that earlier inventory.

The runnable selection uses offline source/data/fixture checks. It does not
operate the USB app, install a service or alter operating-system permissions.
Component rights and scientific limits remain separate from privacy findings.
In particular, retained historical quantum source exhibits carry their exact
restrictive notices and source limits; they are not silently relicensed under
the new wrapper. Applicable component notices accompany the material.

The later Q8 numerical selection preserves nine exact numerical modules and
one generic identity helper. Four assessment/verification/scoring runners are
explicit path/output derivatives. Five historical contracts have one device
locator replaced in each, with their other data unchanged. Service, mirroring,
controller and device-launch modules are excluded. Its separate verification
receipt records syntax/dry-run checks and a targeted saved-state numerical
replay. No new optimizer result or performance measurement is claimed. VM binding checks are not operating-system isolation. The component
notices and unresolved public reuse scope are stated in that selection's guide.

DISCLOSURE_REGISTER.json lists each reviewed identity, disposition and public-safe
reason. SOURCE_MAP.json identifies copies and derivatives. The new root manifest
binds the actual candidate; older nested manifests bind only their historical
edition. Approval must refer to the final candidate files, not merely this report.
