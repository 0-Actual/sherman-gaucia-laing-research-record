"""Repository integrity adapter: check selected bytes, not scientific validity.

Derived from the reproduction manifest helper. Ignore Git administrative data
so verification also works inside a clone, and ignore Python bytecode caches.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent

def verify(root=ROOT):
    manifest = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    expected = {r['path']:r for r in manifest['files']}
    if len(expected) != len(manifest['files']): raise ValueError('Duplicate manifest path')
    actual = {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    actual = {p for p in actual if not ({'__pycache__', '.git'} & set(Path(p).parts))}
    if actual != set(expected) | {'MANIFEST.json'}: raise ValueError('Candidate file list differs')
    for name, row in expected.items():
        p = root/name
        if p.is_symlink() or root.resolve() not in p.resolve().parents: raise ValueError('Unsafe source path')
        data = p.read_bytes()
        if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
            raise ValueError('Source mismatch: '+name)
    return len(expected)

if __name__ == '__main__':
    print(json.dumps({'status':'PASS','files':verify(),'scope':'Byte identity only'}))
