# Errors in this review, and their corrections

October 16, 2026. These are errors in the assistant's handling, interpretation
and reporting of evidence. They are not new failures attributed to Sherman's
historical research. They remain in the proposed publication record at the
owner's direction. The exact public-facing erroneous drafts are retained in
[evidence](evidence/README.md); private before/after evidence remains separate.

## Wrong feature links

The early feature map linked **F08, compute efficiency, to I06, VR/token rights**.
It also linked **F11, biometric control, to I10, C2PA image attribution**. Both
links were wrong. Both were removed. The early requirements, source dates and
descriptions remain. No replacement comparison was invented.

The initial review checked source hashes and source-row fidelity without checking
each proposed industry identifier against its actual subject. That was inadequate
for validating editorial relationships. All proposed links were subsequently
checked against the 28-row comparison table. Byte integrity and semantic accuracy
are separate results.

## Source-row timestamps assigned to the wrong stage

Several new stage maps inherited the timestamp of an aggregate source row and
presented it as the time of a later output or outcome. This introduced false
precision. The corrected maps retain the original row's date as its source anchor
and use a separately supported event time only when one exists.

| Affected row | Mistake and correction |
| --- | --- |
| I04 — continuity | The 00:12:21 source anchor was assigned to later failure. The source describes failures at **00:14 and 07:01**, at minute precision. Those outcomes are separate from the continuity request/promise. |
| I06 — contract sketch | The 15:58:58 request/summary anchor was assigned to the later source output. Public row **PR-E07** separately records that output at **16:01:15.385595 Eastern**. |
| I11 — image reconstruction | The 21:29:47 request anchor was assigned too broadly. **PR-E21** records source at 21:30:37.849380, **PR-E22** a tool result at 21:30:37.849477, and **PR-E25** a later failure at 21:31:32.315734 Eastern. |
| I13 — execution evidence | The 05:50:01 emulator-requirement anchor was applied to a later execution-evidence distinction. **PR-M02** records that later event at **05:55:42.948264 Eastern**. |
| I15 — QPRINT | The 11:05:09 naming/summary anchor was assigned to metadata reinspection. **PR-M12** separately dates the explicit definition at **11:07:21.489700**, while the report places metadata reinspection at **11:12**, at minute precision. |
| I16 — identity profile | The placeholder/source-summary anchor at 18:05:03 did not establish a separate source-output time. **C202** separately records packaging execution at **18:08:47.462664 Eastern**. The unresolved source-output time remains unresolved. |
| I08 and I20 — shared AI workspace | **C178** is a combined request/assistant-architecture summary. Its 06:40:28 anchor does not independently date the assistant output. The corrected fields explicitly retain that uncertainty. |

The complete dates, original precision and source identities are in the current
[industry ledgers](../industry/README.md). The shortened times above are reading
aids within each named event, not a new universal timestamp format. These are
eight affected comparison rows, not eight independent historical failures.
The [structured errata](INDUSTRY_DATE_ERRATA.json) retains the nine affected
stage fields, their erroneous values, corrected values or unresolved status,
and the source identities supporting the correction.

## Reporting and preservation corrections

Two comparison counts were stale after new source links were added: the first
ledger referenced **25** distinct chronology rows, not 10; supplement A referenced
**38**, not 28. These count source rows, not inventions or confirmed findings.
Historical open-queue wording is now identified as historical, rather than left
to imply the current review still has that earlier queue state.

The GitHub correction preserves all original fields across **679 entry objects**:
175 timeline entries and 504 prior-work entries. A review summary's shorthand
“679 original entry fields” was imprecise about the unit. It does not mean the
datasets contain only 679 fields or that each entry is a unique interaction.

The initial private feature ledger and summary were edited before exact previous
copies were saved. That was a preservation error. Their earlier bytes were later
reconstructed and matched against full hashes already recorded before the edits.
The private record labels them **verified byte reconstructions**. The incorrect
public feature map and later erroneous industry files were copied directly before
their correction. These preservation methods are not represented as identical.

Earlier progress wording about a completed early-source review referred to a
bounded selection and source-fidelity pass. It was not evidence that every new
cross-link or assigned stage time was correct. The later checks found the errors
above. Current receipts identify exactly what was checked and what remains open.

## What this correction does not settle

The owner's first-week Quantum AI account remains explicit. Missing named-artifact
or full-conversation evidence does not establish that the work did not exist.
The existing source chronology, later implementation dates, failed attempts and
unfavorable results remain preserved. This correction establishes neither a
complete original corpus nor legal priority, current feature activation, an
exhaustive prior-art search or readiness of the entire research release.

The retained errors and their corrected successors have separate file identities.
They are prepared for review. No public posting is performed by this document.
