# Preserved erroneous review drafts

These files are evidence of mistakes introduced during the October 16, 2026
editorial review. They are **superseded, known-incorrect drafts**, retained at
the owner's direction. Their errors must not be quoted as the current findings.

- `EARLY_FEATURES-ERRONEOUS-DRAFT.json` contains the wrong F08→I06 and F11→I10
  industry links. The corrected map is [EARLY_FEATURES.json](../EARLY_FEATURES.json).
- `industry-erroneous-draft/` contains eight exact public-facing files preserved
  before the corrections to stage timestamps, counts and old queue wording.
  The current eight files are under [industry](../../industry/README.md).
- `BASE_EDITION_VERIFICATION.json` is an unchanged, dated receipt for the earlier
  repository candidate. Its checks do not establish correctness of this later
  edition or of editorial relationships subsequently added.

The private preservation evidence also records an initial failure to keep two
private before-edit files. Their exact bytes were reconstructed and checked
against hashes recorded before their changes. They are labeled verified byte
reconstructions, rather than independently recovered original files. No private
message text, source paths or raw capture identifiers are added to this folder.

Read [the correction ledger](../REVIEW_CORRECTIONS.md) alongside these exhibits.
Keeping an erroneous file is not endorsing its claims. The current findings and
the preserved errors have separate paths and hashes.
