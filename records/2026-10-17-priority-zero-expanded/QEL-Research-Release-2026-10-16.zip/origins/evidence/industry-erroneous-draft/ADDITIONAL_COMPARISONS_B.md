# Additional industry comparisons — review B

This is the corrected release-copy draft. The [origin-date review](README.md#origin-dates-reviewed-before-publication) separates early requirements from later implementation/review dates and preserves the owner’s first-week Quantum AI account. Earlier frozen editions remain historical evidence. Fresh owner approval is required before posting.


Prepared 2026-10-16 for owner review. Owner: Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual; supporting reviewer: Codex.

This supplement reviews eleven retained table rows and 27 primary references. It complements the initial and review-A comparisons without changing them. Dates and feature descriptions are checked; exact equivalence, novelty, copying and implementation priority remain unestablished. Earlier foundations are included alongside later announcements.

Owner anchors below are attributed historical-review summaries, not newly acquired raw conversations. Recorded private milestones, a later retrospective review, the pinned public snapshot and first public disclosure are separate. The snapshot does not establish first publication. External announcement dates do not establish development starts.

The structured companion is [additional-comparisons-b.json](additional-comparisons-b.json); it retains exact recorded timestamps, source identities, row hashes and explicit excluded claims.

## I03 — Personalized intellectual assistant

**Origin-date correction (current draft):** October 17, 2023 includes naming, role direction, a questionnaire design and a textual feedback loop; keep these stages visible. Sources: QEL-SER-C006 (2023-10-17T22:43:44.581522-04:00), QEL-SER-C014 (2023-10-17T23:35:35.476692-04:00), QEL-SER-C017 (2023-10-17T23:51:03.517025-04:00), QEL-SER-C008 (2023-10-17T22:49:55.271937-04:00; contextual antecedent), QEL-SER-C010 (2023-10-17T23:01:05.797668-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** Dated role/preferences requests and observed conversational wording. Anchors: QEL-SER-C001, QEL-SER-C006, QEL-SER-C008, QEL-SER-C010.

The October 17, 2023 personalization records fall after Custom Instructions (July 20) and before GPTs (November 6). The shared feature is user-specified role and behavior.

The recorded naming and conversational adaptation do not establish a configurable GPT product, durable memory or a new personalization architecture.

Primary references: [Custom instructions for ChatGPT](https://openai.com/index/custom-instructions-for-chatgpt/) (2023-07-20; company announcement); [Introducing GPTs](https://openai.com/index/introducing-gpts/) (2023-11-06; company announcement).

**Excluded from present findings:** Invention or copying of GPTs; technical implementation priority.

## I05 — Device control, offline operation and local communication

**Origin-date correction (current draft):** Concrete device-assistance requirements occur October 17, 2023. The specific offline/old-laptop and later phone-connectivity requests retain their 2026 dates; neither date substitutes for the other. Sources: QEL-SER-C007 (2023-10-17T22:47:02.287640-04:00), QEL-SER-C245 (2026-05-21T16:10:06.724053-04:00), QEL-SER-C246 (2026-05-21T16:25:48.790409-04:00; contextual antecedent), QEL-SER-C320 (2026-09-16; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** Early concrete device-assistance request, later explicit offline/runtime requirements and separately dated phone context. Anchors: QEL-SER-C245, QEL-SER-C246, QEL-SER-C320.

The October 17, 2023 actionable accessibility request precedes the October 22, 2024 computer-use beta, but is narrower than general computer operation and is not a working tool implementation. The specific May 2026 offline/old-laptop and September phone requirements are later. Android’s 2011 connectivity announcement is earlier than all these owner records.

May's offline requirement does not date September's Bluetooth/Wi-Fi requests. Computer use via an API is not itself an offline runtime; no phone installation or hardware operation is proved by these rows.

Primary references: [Introducing computer use, a new Claude 3.5 Sonnet, and Claude 3.5 Haiku](https://www.anthropic.com/news/3-5-models-and-computer-use) (2024-10-22; company public-beta announcement); [Android 4.0 Platform and Updated SDK Tools](https://android-developers.googleblog.com/2011/10/android-40-platform-and-updated-sdk.html) (2011-10-18; official platform announcement).

**Excluded from present findings:** Working offline computer-use or phone implementation; all phone features backdated to May.

## I06 — VR Dimension Access Lenz; token ownership and delegated rights

**Origin-date correction (current draft):** General ownership documentation exists in October 2023, but the retained exact token/access-lens requirement and source sketch remain July 4, 2024. Sources: QEL-SER-C116 (2024-07-04T15:58:58.062017-04:00), QEL-SER-C117 (2024-07-04T15:58:58.062017-04:00), QEL-SER-C057 (2023-10-19T12:16:06.385422-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** July 4, 2024 request plus assistant Solidity draft. Anchors: QEL-SER-C116, QEL-SER-C117.

The draft uses the established ERC-721/OpenZeppelin family. Token ownership and authorization have a clear earlier standard reference.

No compiler, deployment, transaction or biometric integration is verified here. The draft's quantumSecurityMeasure returns true as a placeholder; its name does not establish quantum security.

Primary references: [ERC-721: Non-Fungible Token Standard](https://eips.ethereum.org/EIPS/eip-721) (2018-01-24; specification created field).

**Excluded from present findings:** Deployed QEL contract, security verification or real-world rights enforcement.

## I13 — Demand for executed and inspectable tool work

**Origin-date correction (current draft):** Actionability and review expectations occur in October 2023. The precise software-execution requirement is March 10, 2025; one-day adjacency to an external announcement applies only to that specific later request. Sources: QEL-SER-C007 (2023-10-17T22:47:02.287640-04:00), QEL-SER-C166 (2025-03-10T05:50:01.264392-04:00), QEL-SER-C169 (2025-03-13T10:48:15.685403-04:00), QEL-SER-C016 (2023-10-17T23:47:32.686366-04:00; contextual antecedent), QEL-SER-C072 (2023-10-19T13:58:30.434154-04:00; contextual antecedent), QEL-SER-C165 (2025-03-08T07:37:28.782335-05:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** First-week demand for concrete action and error review; later precise reconstruction/software-execution requirement. Anchors: QEL-SER-C165, QEL-SER-C166.

The demand for useful action has an October 17, 2023 antecedent. The March 10, 2025 explicit distinction between displayed code and executed implementation is a later, more specific requirement one calendar day before the March 11 agents-tool release; that adjacency does not date the project’s broader actionability principle.

A demand for inspectable work does not specify the Responses API or Agents SDK design. The release date is not a development-start date, and no external exposure or derivation evidence is supplied.

Primary references: [New tools for building agents](https://openai.com/index/new-tools-for-building-agents/) (2025-03-11; company release announcement).

**Excluded from present findings:** Priority in the agents architecture or a causal connection based on one-day adjacency.

## I14 — Agent-assisted software construction and test evidence

**Origin-date correction (current draft):** The personal-AI build roadmap is an October 2023 antecedent. The retained concrete emulator source is a March 2025 artifact, not the inception of all AI-development work. Sources: QEL-SER-C166 (2025-03-10T05:50:01.264392-04:00), QEL-SER-C169 (2025-03-13T10:48:15.685403-04:00), QEL-SER-C076 (2023-10-19T14:20:46.254321-04:00; contextual antecedent), QEL-SER-C078 (2023-10-19T14:20:51.802281-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** March 10 requirement; March 13, 2025 recovered emulator code. Anchors: QEL-SER-C166, QEL-SER-C169.

The owner request and generated emulator source follow the February Claude Code preview and precede the May cloud Codex announcement.

Algorithm1 contains computational source but no original execution receipt in this row. Code generation is not equivalent to an operating terminal/cloud agent. May 16 denotes this cloud product, not the first Codex name.

Primary references: [Claude 3.7 Sonnet and Claude Code](https://www.anthropic.com/news/claude-3-7-sonnet) (2025-02-24; company research-preview announcement); [Introducing Codex](https://openai.com/index/introducing-codex/) (2025-05-16; cloud-agent product announcement).

**Excluded from present findings:** Equivalent agent runtime, successful historical test execution or earliest coding-agent invention.

## I21 — Governed versioned workflows and conversational app surfaces

**Origin-date correction (current draft):** Governed correction and personalization workflows are documented October 17, 2023. The May 2026 Q6 catalog and detailed controls must be shown as later evidence, while equivalence to an Apps SDK or visual agent builder remains unestablished. Sources: QEL-SER-C015 (2023-10-17T23:35:35.476692-04:00), QEL-SER-C230 (2026-05-17T18:51:17.328558-04:00), QEL-PW-0261 (2026-05-04), QEL-SER-C016 (2023-10-17T23:47:32.686366-04:00; contextual antecedent), QEL-SER-C017 (2023-10-17T23:51:03.517025-04:00; contextual antecedent), QEL-SER-C231 (2026-05-17T19:07:56.736517-04:00; contextual antecedent), QEL-SER-C234 (2026-05-18T12:17:07.999512-04:00; contextual antecedent), QEL-SER-C237 (2026-05-18T12:55:10.834939-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** Early correction/personalization workflow, later source catalog and specific control instructions. Anchors: QEL-SER-C230, QEL-SER-C231, QEL-SER-C234, QEL-SER-C237, QEL-PW-0261.

The October 17, 2023 correction and personalization workflow precedes the October 6, 2025 AgentKit/Apps SDK announcements. The selected Q6 catalog and detailed controls are later checkpoints. Neither the early conversation workflow nor a later local web file proves implementation of those products’ exact architecture.

QEL-PW-0261 is a report/source date, not the inception of every Q6 module. A local app.js or manifest is not enough to establish an MCP app or the same visual workflow architecture; earlier exact implementation dates remain unresolved.

Primary references: [Introducing AgentKit](https://openai.com/index/introducing-agentkit/) (2025-10-06; company announcement); [Introducing apps in ChatGPT and the new Apps SDK](https://openai.com/index/introducing-apps-in-chatgpt/) (2025-10-06; company sdk-preview announcement).

**Excluded from present findings:** Backdating all modules to May 4, or equating local web files with AgentKit/Apps SDK.

## I24 — Mathematical successors: coherence, entanglement, channels, encoded correction and mitigation

**Origin-date correction (current draft):** Quantum learning is documented October 21, 2023, Algorithm1 source in March 2025, and successor evidence later. Established mathematical names, review dates and the owner project name cannot date all implementations. Sources: QEL-SER-C169 (2025-03-13T10:48:15.685403-04:00), QEL-SER-C096 (2023-10-21T08:15:32.668064-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** March 13, 2025 Algorithm1 source plus separately dated/undated successor review summaries. Anchors: QEL-SER-C169, QEL-SER-M001, QEL-SER-M003, QEL-SER-M006, QEL-SER-M007, QEL-SER-M009, QEL-SER-M015.

All eleven cited mathematical reference families predate the admitted QEL source/review dates. They supply foundations for identifiable successor mechanisms rather than evidence of eleven new mathematical inventions.

The later mechanism table associates much of the material with an August 21, 2026 successor package but gives no per-row event date. Its September 17 report date and retained September 15 review label are not original implementation dates. Mathematical names require formula-specific mapping and cannot inherit Algorithm1's March date.

Primary references: [Spin Echoes](https://journals.aps.org/pr/abstract/10.1103/PhysRev.80.580) (1950-11-15; publisher publication date); [Completely positive dynamical semigroups of N-level systems](https://pubs.aip.org/aip/jmp/article/17/5/821/225427/Completely-positive-dynamical-semigroups-of-N) (1976-05-01; publisher publication date); [On the generators of quantum dynamical semigroups](https://link.springer.com/article/10.1007/BF01608499) (1976-06; publisher publication month); [A Theory of Quantum Error-Correcting Codes](https://arxiv.org/abs/quant-ph/9604034v1) (1996-04-26; arxiv v1 submission); [Stabilizer Codes and Quantum Error Correction](https://arxiv.org/abs/quant-ph/9705052v1) (1997-05-28; arxiv v1 submission); [Entanglement of Formation of an Arbitrary State of Two Qubits](https://arxiv.org/abs/quant-ph/9709029v1) (1997-09-12; arxiv v1 submission); [A computable measure of entanglement](https://arxiv.org/abs/quant-ph/0102117v1) (2001-02-22; arxiv v1 submission); [A variational eigenvalue solver on a quantum processor](https://arxiv.org/abs/1304.3061v1) (2013-04-10; arxiv v1 submission); [Quantifying Coherence](https://arxiv.org/abs/1311.0275v1) (2013-11-01; arxiv v1 submission); [Error mitigation for short-depth quantum circuits](https://arxiv.org/abs/1612.02058v1) (2016-12-06; arxiv v1 submission); [The Theory of Quantum Information](https://cs.uwaterloo.ca/~watrous/TQI/) (2018-04; author-stated book publication month).

**Excluded from present findings:** Novelty, universal correctness, physical hardware execution, or a one-to-one validated implementation match to every cited paper.

## I25 — Provenance-security concerns and validation checks

**Origin-date correction (current draft):** Ownership and owner-only identity concerns predate the explicit October 2024 C2PA request. They must remain distinct from August/September 2026 carrier builds and from external formal security analyses. Sources: QEL-SER-C137 (2024-10-01T12:42:35.132653-04:00), QEL-SER-C138 (2024-10-01T12:42:55.948114-04:00), QEL-SER-C267 (2026-08-16), QEL-SER-C057 (2023-10-19T12:16:06.385422-04:00; contextual antecedent), QEL-SER-C072 (2023-10-19T13:58:30.434154-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** October 1, 2024 attribution objective; later carrier evidence separately dated in retained table. Anchors: QEL-SER-C137, QEL-SER-C138.

The attribution request precedes the April 2026 papers, while the retained table's specific August/September carrier builds follow them. The papers address provenance-verification security, a more specific problem.

The October request does not specify the papers' attacks or fixes, nor establish a signed compliant manifest. These two related publications are not two independent confirmations of the owner's work.

Primary references: [Verifying Provenance of Digital Media: Why the C2PA Specifications Fall Short](https://arxiv.org/abs/2604.24890v1) (2026-04-27; arxiv v1 submission); [Verifying Provenance of Digital Media: Security Analysis of C2PA and its Implementation](https://eprint.iacr.org/2026/804) (2026-04-23; iacr received date).

**Excluded from present findings:** Earlier discovery of the formal attacks, equivalence of fixes, or validated C2PA conformance.

## I26 — Three-tier nursery; timed irrigation and remote monitoring

**Origin-date correction (current draft):** The nursery requirements and drafts are October 18, 2023 work. No date change is needed; budget and implementation limits remain visible. Sources: QEL-SER-C026 (2023-10-18T00:30:57.870481-04:00), QEL-SER-C028 (2023-10-18T00:32:17.178607-04:00), QEL-SER-C027 (2023-10-18T00:31:11.532899-04:00), QEL-SER-C029 (2023-10-18T00:32:23.569856-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** October 18, 2023 requirements and assistant design prose. Anchors: QEL-SER-C026, QEL-SER-C027, QEL-SER-C028, QEL-SER-C029.

FarmBot's June/July 2016 sources precede the proposed three-tier nursery. Automated watering is a shared goal; the designs differ materially.

The owner response specifies shelving, timed drip and suggested sensors, not the comparator's CNC moving-tool robot. The quoted base materials total $60 against a $50 target. No controller code, integrated sensor readings or measured growth is shown.

Primary references: [FarmBot Now Available for Pre-Order](https://farm.bot/blogs/news/farmbot-now-available-for-pre-order) (2016-06-30; project launch announcement); [Scaling FarmBot to bigger farms — founder response](https://forum.farmbot.org/t/scaling-farmbot-to-bigger-farms/178) (2016-07-12; founder forum-post date).

**Excluded from present findings:** A working automated nursery, verified budget or exact feature equivalence with FarmBot.

## I27 — Hybrid wind/solar/storage and portable energy requirements

**Origin-date correction (current draft):** General energy inquiry begins October 18, 2023; the specific hybrid request is October 19, with portable/modular requirements on October 20–21. No later review date replaces these original recorded stages. Sources: QEL-SER-C082 (2023-10-19T20:52:44.145455-04:00), QEL-SER-C084 (2023-10-19T21:02:55.243095-04:00), QEL-SER-C083 (2023-10-19T20:54:36.685755-04:00), QEL-SER-C021 (2023-10-18T00:20:02.192223-04:00; contextual antecedent), QEL-SER-C081 (2023-10-19T20:52:09.724983-04:00; contextual antecedent), QEL-SER-C090 (2023-10-20T23:14:57.852326-04:00; contextual antecedent), QEL-SER-C091 (2023-10-21T08:06:57.853369-04:00; contextual antecedent). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** October 19–21, 2023 concept interval in retained table; directly selected rows are October 19. Anchors: QEL-SER-C082, QEL-SER-C083, QEL-SER-C085.

The June 1997 report already analyzes wind/PV/battery sizing, so combining these resources is an earlier established design family.

No feature-level match was established for the owner's portable packaging or solar cells on turbine blades. The 100 kWh/day statement is an unsupported target in the recovered response, without resource, area or storage calculations.

Primary references: [Sizing Wind/Photovoltaic Hybrids for Households in Inner Mongolia](https://www.nlr.gov/docs/legosti/fy97/23116.pdf) (1997-06; report cover month).

**Excluded from present findings:** Achieved daily energy output, validated blade design or equivalent portable device.

## I28 — Personal AI development roadmap

**Origin-date correction (current draft):** The personal-AI development direction is explicitly recorded October 19, 2023 and must remain part of the first-week history. Sources: QEL-SER-C076 (2023-10-19T14:20:46.254321-04:00), QEL-SER-C078 (2023-10-19T14:20:51.802281-04:00). First verified public disclosure of the original event/implementation remains unestablished.


**Owner evidence:** October 19, 2023 requirement and assistant seven-step roadmap. Anchors: QEL-SER-C076, QEL-SER-C078.

The May 2019 engineering study predates the owner's personal-AI roadmap. Data preparation, training, deployment and maintenance are common lifecycle themes.

A seven-step response and a nine-stage case-study workflow are not identical technical designs. The owner row contains no code, model weights, training run or deployed model.

Primary references: [Software Engineering for Machine Learning: A Case Study](https://www.microsoft.com/en-us/research/publication/software-engineering-for-machine-learning-a-case-study/) (2019-05; publication page month).

**Excluded from present findings:** A completed trained system or a new machine-learning lifecycle.

## Mathematical mapping and version corrections

These six links identify the relevant later source family; they do not assign that family a March 2025 implementation date. The retained mechanism summaries principally concern a later successor collection and are not a new proof audit.

| Owner summary | Mechanism | Prior foundation | Limit |
| --- | --- | --- | --- |
| QEL-SER-M009 | Pulse refocusing/noise model | Spin Echoes | Specific modeled noise and pulse costs; not arbitrary error removal. |
| QEL-SER-M015 | GKSL pumping and dephasing | Completely positive dynamical semigroups of N-level systems, On the generators of quantum dynamical semigroups | Specified generator and stationary-state conditions; not universal state reinforcement. |
| QEL-SER-M006 | Five-qubit stabilizer recovery and correctability blocks | A Theory of Quantum Error-Correcting Codes, Stabilizer Codes and Quantum Error Correction | Ideal encoded/noise/recovery simulation; not arbitrary threshold filtering or hardware fault tolerance. |
| QEL-SER-M001 | Two-qubit entanglement, partial-transpose and coherence-related diagnostics | Entanglement of Formation of an Arbitrary State of Two Qubits, A computable measure of entanglement, Quantifying Coherence, The Theory of Quantum Information | Conceptual foundation links; each estimator needs its own dimension, basis and formula checks. The textbook is a reference, not an invention date. |
| QEL-SER-M003 | Finite-grid variational energy minimization | A variational eigenvalue solver on a quantum processor | Ansatz/grid restriction and variational bound; no QEL quantum-processor inference. |
| QEL-SER-M007 | Richardson extrapolation and quasiprobability estimator mitigation | Error mitigation for short-depth quantum circuits | Estimator correction with cost and calibration limits, not encoded state recovery. |

The GKS May 1, 1976 date is now checked on the publisher page. The coherence citation now links to v1 (November 1, 2013); the retained v3 URL represents October 6, 2014. Watrous's April 2018 book date is a reference-publication date, not the inception of the mathematics it teaches.

The Android date and named connectivity features were read in the official page's search-indexed text; direct opening returned an error. The energy paper's cover, abstract and introduction were read as PDF text; screenshot requests failed. No successful visual inspection or byte-preserved external web archive is claimed.

No experiments, deployment or scientific source execution occurred. Missing implementation evidence remains unresolved rather than classified as a failed implementation. Public readers receive documentary anchors and references; private locators remain in a separate source receipt.
