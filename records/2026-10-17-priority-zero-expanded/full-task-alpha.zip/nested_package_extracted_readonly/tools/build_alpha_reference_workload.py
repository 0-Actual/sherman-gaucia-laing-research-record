#!/usr/bin/env python3
"""Build the additive Task Alpha classical QPU-emulator checkpoint."""

from __future__ import annotations

import hashlib
import io
import json
import os
import stat
import sys
import unittest
import unicodedata
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any

from PIL import Image, ImageDraw, ImageFont


CYCLE_ROOT = Path(__file__).resolve().parents[1]
WORK_ROOT = CYCLE_ROOT.parent
RECOVERED = WORK_ROOT / "recovered"
SRC = CYCLE_ROOT / "src"
TESTS = CYCLE_ROOT / "tests"
UPSTREAM = CYCLE_ROOT / "upstream"
ARTIFACTS = CYCLE_ROOT / "artifacts"

STAMP_ET = "2026-08-25T21:25:00-04:00"
STAMP_CLASS = "OWNER_PROVIDED_CONTINUATION_TIME_ANCHOR_NOT_EXTERNAL_TIMESTAMP_ATTESTATION"
PREFIX = "TASK_ALPHA_CLASSICAL_QPU_EMULATOR_20260825T2125ET_V1"

CHECKPOINT_STATES = {
    "capability": "TESTED",
    "evidence": "VERIFIED",
    "custody": "PRESENT",
    "privacy": "PROJECT-RESTRICTED",
    "release": "HOLD",
}

sys.path.insert(0, str(SRC))
sys.path.insert(0, str(UPSTREAM))

from alpha_reference_emulator import (  # noqa: E402
    WORKLOAD_FIELDS,
    default_workload,
    execute_workload,
)


DOMAIN = b"SGL-PRIME/v1/FINGERPRINT"
SUITE = b"SGL-PRIME-v1"
IDENTITY_PREFIX = "sglp1:shake256-512:"

SEQ52_ARCHIVE = RECOVERED / "TASK-ALPHA-CYCLE-20260825T0821ET-CUMULATIVE-V1.zip"
V10_PACKAGE = RECOVERED / "TASK_ALPHA_CONTAINED_GATE_HARNESS_20260825T1020ET_V10_PACKAGE.zip"
POLICY_CHECKPOINT = RECOVERED / "QEL_PHASE_III_ALPHA_OMEGA_PUBLIC_SPEC_CHECKPOINT_20260825T132200ET_V1.zip"
PUBLIC_SPEC = RECOVERED / "QEL_Phase_III_Alpha_Omega_Public_Operating_Specification_2026-08-25.pdf"

SEQ52_EXPECTED = {
    "purpose": "qel.alpha.cycle-checkpoint-archive.v1",
    "identity": "sglp1:shake256-512:1f581f29fa59ffdfe229c9568ef900087b5d31d7ab82ed101e948ac25c300a2f2e12c87a03d5863fb5fc95ddefc26ea46bb9d4d542bbf2341b63d222fbac07b3",
    "bytes": 96279099,
    "members": 2784,
    "library_file_id": "libfile_6b6ef6240cd08191919be418611b5c38",
    "file_id": "file_00000000a20c81fb98cc01ffa106754b",
}

V10_EXPECTED = {
    "purpose": "qel.alpha.contained-gate-package.v10",
    "identity": "sglp1:shake256-512:6c97d93ea75f912c277a3e6f4435bf8d03ffb1b8e4bdab536d6c13ccc9cf7907c6a8db256f335436034039ab446c0b4d31ce260eafbf1452a31d3dd4282ef8ca",
    "bytes": 45845,
    "members": 10,
    "library_file_id": "libfile_11501ea455308191a97202827e1dd67b",
    "file_id": "file_0000000091448230b5a515f5aee413d8",
}

POLICY_EXPECTED = {
    "purpose": "qel.alpha.phase-iii-public-spec-checkpoint.v1",
    "identity": "sglp1:shake256-512:b5ca9f79da76fb287cfb79f552db9c3d483057aa9eeda5fc1ef11a98073a8fe19240db6a43f6bfa8481bd1ca61c456973c7ba2a33e4c1e7203a38c8cf62e71ff",
    "bytes": 2287990,
    "members": 23,
    "library_file_id": "libfile_47a3714aa0b88191bf912a6c46ed2b1e",
    "file_id": "file_00000000e3b481fd9d9f1df4e2e3fde1",
}

SPEC_EXPECTED = {
    "purpose": "qel.alpha.phase-iii-public-operating-specification-pdf.v1",
    "identity": "sglp1:shake256-512:32d34f1e6960d6073718b312a76c998a60dba2122c8c17361c034846985bc8deed2dc33a0a8453d6ec17897bb0c9302428283a6dcede24631b7bb580b4e31dec",
    "bytes": 580955,
    "library_file_id": "libfile_1b0e393db0fc8191aaf55ebf67f828d8",
    "file_id": "file_00000000e1b881fb8adcf34c6bea483b",
}

WORKLOAD_RECORD = ARTIFACTS / f"{PREFIX}_WORKLOAD.sgl.json"
RUN_RECEIPT = ARTIFACTS / f"{PREFIX}_RUN_RECEIPT.sgl.json"
CUSTODY_RECEIPT = ARTIFACTS / f"{PREFIX}_SOURCE_CUSTODY_RECEIPT.sgl.json"
TEST_LOG = ARTIFACTS / f"{PREFIX}_TEST_LOG.txt"
REPORT = ARTIFACTS / f"{PREFIX}_REPORT.md"
PACKAGE_MANIFEST = ARTIFACTS / f"{PREFIX}_PACKAGE_MANIFEST.sgl.json"
PACKAGE = ARTIFACTS / f"{PREFIX}_PACKAGE.zip"
QPRINT_MODEL = ARTIFACTS / f"QPRINT_{PREFIX}_CONTENT_MODEL.sgl.json"
QPRINT = ARTIFACTS / f"QPRINT_{PREFIX}.jpg"
AGGREGATE = ARTIFACTS / f"{PREFIX}_AGGREGATE_RECEIPT.sgl.json"
DELIVERY_MANIFEST = ARTIFACTS / f"{PREFIX}_DELIVERY_MANIFEST.sgl.json"
DELIVERY = ARTIFACTS / f"{PREFIX}_DELIVERY.zip"
DETACHED = ARTIFACTS / f"{PREFIX}_DETACHED_RECEIPT.sgl.json"


class BuildError(RuntimeError):
    pass


def normalize(value: Any) -> Any:
    if value is None or isinstance(value, bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        if not -(2**63) <= value < 2**63:
            raise BuildError("integer outside signed 64-bit range")
        return value
    if isinstance(value, float):
        raise BuildError("floats are forbidden in SGL-bound evidence")
    if isinstance(value, str):
        return unicodedata.normalize("NFC", value)
    if isinstance(value, (list, tuple)):
        return [normalize(item) for item in value]
    if isinstance(value, dict):
        output: dict[str, Any] = {}
        for key, item in value.items():
            if not isinstance(key, str):
                raise BuildError("canonical keys must be strings")
            normalized_key = unicodedata.normalize("NFC", key)
            if normalized_key in output:
                raise BuildError("duplicate normalized canonical key")
            output[normalized_key] = normalize(item)
        return output
    raise BuildError(f"unsupported canonical type: {type(value).__name__}")


def canonical(value: Any) -> bytes:
    return json.dumps(
        normalize(value),
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")


def pretty(value: Any) -> bytes:
    return (
        json.dumps(
            normalize(value),
            ensure_ascii=False,
            sort_keys=True,
            indent=2,
            allow_nan=False,
        )
        + "\n"
    ).encode("utf-8")


def frame(*parts: bytes) -> bytes:
    return b"".join(len(part).to_bytes(8, "big") + part for part in parts)


def sgl_prime(purpose: str, subject: bytes) -> str:
    material = frame(DOMAIN, SUITE, purpose.encode("utf-8"), subject)
    return IDENTITY_PREFIX + hashlib.shake_256(material).hexdigest(64)


def identity_profile(purpose: str) -> dict[str, str]:
    return {
        "algorithm": "SHAKE256-512",
        "canonicalization": "SGL Prime canonical JSON v1 over self-excluded body",
        "purpose": purpose,
        "suite": "SGL-PRIME-v1",
        "authentication_class": "UNKEYED_CONTENT_IDENTITY_NOT_OWNER_SIGNATURE",
    }


def self_identified(body: dict[str, Any], purpose: str) -> dict[str, Any]:
    if "primary_identity" in body or "primary_identity_profile" in body:
        raise BuildError("identity fields must be self-excluded")
    return {
        **body,
        "primary_identity": sgl_prime(purpose, canonical(body)),
        "primary_identity_profile": identity_profile(purpose),
    }


def verify_self_identified(record: dict[str, Any]) -> bool:
    profile = record.get("primary_identity_profile")
    identity = record.get("primary_identity")
    if type(profile) is not dict or type(identity) is not str:
        return False
    purpose = profile.get("purpose")
    if type(purpose) is not str or profile != identity_profile(purpose):
        return False
    body = {
        key: value
        for key, value in record.items()
        if key not in {"primary_identity", "primary_identity_profile"}
    }
    return identity == sgl_prime(purpose, canonical(body))


def write_new(path: Path, data: bytes) -> None:
    if path.exists():
        raise BuildError(f"refusing overwrite: {path}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def write_json(path: Path, value: Any) -> None:
    write_new(path, pretty(value))


def suite_result(start_dir: Path, pattern: str, label: str) -> tuple[dict[str, Any], str]:
    loader = unittest.TestLoader()
    suite = loader.discover(str(start_dir), pattern=pattern, top_level_dir=str(start_dir))
    output = io.StringIO()
    result = unittest.TextTestRunner(stream=output, verbosity=2).run(suite)
    summary = {
        "label": label,
        "tests_run": result.testsRun,
        "passed": result.testsRun - len(result.failures) - len(result.errors) - len(result.skipped),
        "failures": len(result.failures),
        "errors": len(result.errors),
        "skipped": len(result.skipped),
        "ok": result.wasSuccessful() and not result.skipped,
    }
    return summary, output.getvalue()


def run_all_tests() -> tuple[dict[str, Any], str]:
    local, local_log = suite_result(TESTS, "test_*.py", "ALPHA_REFERENCE_WORKLOAD")
    upstream, upstream_log = suite_result(
        UPSTREAM,
        "test_qel_alpha_omega_contract.py",
        "RECOVERED_REFERENCE_POLICY_KERNEL",
    )
    total = {
        "local": local,
        "upstream_policy_kernel": upstream,
        "tests_run": local["tests_run"] + upstream["tests_run"],
        "passed": local["passed"] + upstream["passed"],
        "failures": local["failures"] + upstream["failures"],
        "errors": local["errors"] + upstream["errors"],
        "skipped": local["skipped"] + upstream["skipped"],
        "ok": local["ok"] and upstream["ok"],
    }
    log = (
        "[ALPHA_REFERENCE_WORKLOAD]\n"
        + local_log
        + "\n[RECOVERED_REFERENCE_POLICY_KERNEL]\n"
        + upstream_log
    )
    return total, log


def safe_zip_check(path: Path, expected_members: int | None = None) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        infos = archive.infolist()
        names = [info.filename for info in infos]
        unsafe = []
        special = []
        for info in infos:
            logical = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0o170000
            if (
                logical.is_absolute()
                or ".." in logical.parts
                or "\\" in info.filename
                or (logical.parts and ":" in logical.parts[0])
            ):
                unsafe.append(info.filename)
            if mode not in {0, stat.S_IFREG, stat.S_IFDIR}:
                special.append(info.filename)
        bad_crc = archive.testzip()
    return {
        "ok": (
            bad_crc is None
            and not unsafe
            and not special
            and len(names) == len(set(names))
            and (expected_members is None or len(names) == expected_members)
        ),
        "member_count": len(names),
        "member_count_expected": expected_members,
        "crc_pass": bad_crc is None,
        "unique_paths": len(names) == len(set(names)),
        "unsafe_paths": unsafe,
        "special_members": special,
    }


def verify_source_file(path: Path, expected: dict[str, Any]) -> dict[str, Any]:
    if not path.is_file() or path.is_symlink():
        raise BuildError(f"source missing or not regular: {path}")
    actual_identity = sgl_prime(expected["purpose"], path.read_bytes())
    result = {
        "name": path.name,
        "bytes": path.stat().st_size,
        "expected_bytes": expected["bytes"],
        "identity_purpose": expected["purpose"],
        "sgl_prime_identity": actual_identity,
        "expected_sgl_prime_identity": expected["identity"],
        "library_file_id": expected["library_file_id"],
        "file_id": expected["file_id"],
        "bytes_match": path.stat().st_size == expected["bytes"],
        "identity_match": actual_identity == expected["identity"],
    }
    if path.suffix == ".zip":
        result["archive_checks"] = safe_zip_check(path, expected["members"])
    result["ok"] = (
        result["bytes_match"]
        and result["identity_match"]
        and ("archive_checks" not in result or result["archive_checks"]["ok"])
    )
    return result


def source_custody() -> dict[str, Any]:
    sequence = verify_source_file(SEQ52_ARCHIVE, SEQ52_EXPECTED)
    v10 = verify_source_file(V10_PACKAGE, V10_EXPECTED)
    policy = verify_source_file(POLICY_CHECKPOINT, POLICY_EXPECTED)
    specification = verify_source_file(PUBLIC_SPEC, SPEC_EXPECTED)
    checks = {
        "sequence_52_archive_exact": sequence["ok"],
        "v10_contained_harness_exact": v10["ok"],
        "reference_policy_checkpoint_exact": policy["ok"],
        "governing_public_spec_exact": specification["ok"],
    }
    return {
        "checks": checks,
        "ok": all(checks.values()),
        "sequence_52": sequence,
        "v10_contained_harness": v10,
        "reference_policy_checkpoint": policy,
        "governing_public_specification": specification,
        "head_state": {
            "sequence": 52,
            "task": "ACTIVE",
            "release": "HOLD",
            "signature": "UNSIGNED",
            "activation": "INACTIVE",
            "all_16_control_gates": False,
            "runtime_sequence_advanced": False,
        },
        "head_reconstruction_boundary": (
            "SEQUENCE_52_IS_A_VERIFIED_DELTA_BUT_NOT_A_STANDALONE_RUNNABLE_SOURCE_TREE; "
            "SEQUENCE_36_BASE_AND_FULL_22_MEMBER_CANDIDATE_REMAIN_REQUIRED_FOR_REAL_SEQUENCE_APPEND"
        ),
        "omega_boundary": {
            "policy": "FROZEN_MECHANICS_PROVENANCE_ONLY_NO_MERGE_OR_RESUME",
            "later_omega_labelled_code_observed": "QEL_JUSTIFIED_IMPLEMENTATION_ALPHA_OMEGA_CODE_PATCH_V0_2.zip",
            "imported_into_this_alpha_cycle": False,
            "runtime_effect": "NONE",
        },
        "truncated_materialization_prefix": {
            "status": "IGNORED_NOT_A_VALID_ZIP_NOT_A_SOURCE",
            "runtime_effect": "NONE",
        },
    }


def deterministic_zip(paths: list[tuple[Path, str]], destination: Path) -> None:
    if destination.exists():
        raise BuildError(f"refusing overwrite: {destination}")
    with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for source, logical_name in sorted(paths, key=lambda item: item[1]):
            info = zipfile.ZipInfo(logical_name, (2026, 8, 25, 21, 25, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100444 << 16
            archive.writestr(info, source.read_bytes())


def verify_zip_roundtrip(
    path: Path,
    expected: dict[str, bytes],
) -> dict[str, Any]:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        recovered = {name: archive.read(name) for name in names}
        structural = safe_zip_check(path, len(expected))
    return {
        **structural,
        "member_bytes_roundtrip_exact": recovered == expected,
        "ok": structural["ok"] and recovered == expected,
    }


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    name = "DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"
    return ImageFont.truetype(f"/usr/share/fonts/truetype/dejavu/{name}", size)


def wrap_text(
    draw: ImageDraw.ImageDraw,
    text: str,
    selected_font: ImageFont.FreeTypeFont,
    width: int,
) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if not current or draw.textbbox((0, 0), candidate, font=selected_font)[2] <= width:
            current = candidate
        else:
            lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def render_qprint(model: dict[str, Any]) -> dict[str, Any]:
    image = Image.new("RGB", (2400, 3400), "#07111c")
    draw = ImageDraw.Draw(image)
    margin = 145
    width = 2110
    colors = {
        "white": "#f4f7fb",
        "muted": "#b7c4d3",
        "cyan": "#50d7ff",
        "gold": "#ffce65",
        "green": "#65e6a3",
        "red": "#ff7a7a",
        "panel": "#0d1c2b",
        "line": "#29445f",
    }
    title_font = font(67, True)
    sub_font = font(34)
    heading_font = font(40, True)
    body_font = font(31)
    mono_font = ImageFont.truetype(
        "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf", 25
    )
    y = 105
    draw.text((margin, y), "PROJECT QUANTUM.EARTH.LAING / Q6.1", font=sub_font, fill=colors["cyan"])
    y += 75
    draw.text((margin, y), "TASK ALPHA — CLASSICAL QPU EMULATOR", font=title_font, fill=colors["white"])
    y += 105
    draw.text((margin, y), f"Additive 9:25 p.m. ET checkpoint • {STAMP_ET}", font=sub_font, fill=colors["muted"])
    y += 80
    chips = [
        ("ACTIVE", colors["green"]),
        ("HOLD", colors["gold"]),
        ("UNSIGNED", colors["red"]),
        ("INACTIVE", colors["red"]),
        ("CLASSICAL CPU ONLY", colors["cyan"]),
    ]
    x = margin
    for label, color in chips:
        box = draw.textbbox((0, 0), label, font=body_font)
        chip_width = box[2] + 42
        draw.rounded_rectangle((x, y, x + chip_width, y + 58), radius=20, outline=color, width=3)
        draw.text((x + 21, y + 9), label, font=body_font, fill=color)
        x += chip_width + 18
    y += 100

    def section(label: str, color: str, items: list[str]) -> None:
        nonlocal y
        groups = [wrap_text(draw, item, body_font, width - 90) for item in items]
        line_count = sum(len(group) for group in groups)
        height = 108 + line_count * 45
        draw.rounded_rectangle(
            (margin, y, margin + width, y + height),
            radius=25,
            fill=colors["panel"],
            outline=colors["line"],
            width=3,
        )
        draw.text((margin + 36, y + 22), label, font=heading_font, fill=color)
        line_y = y + 82
        for group in groups:
            for index, line in enumerate(group):
                prefix = "• " if index == 0 else "  "
                draw.text((margin + 40, line_y), prefix + line, font=body_font, fill=colors["white"])
                line_y += 45
        y += height + 34

    for section_model in model["visible_sections"]:
        section(section_model["heading"], colors[section_model["color"]], section_model["items"])

    draw.text((margin, y + 4), "SGL Prime package identity", font=heading_font, fill=colors["cyan"])
    y += 57
    identity = model["package_identity"]
    for start in range(0, len(identity), 76):
        draw.text((margin, y), identity[start : start + 76], font=mono_font, fill=colors["muted"])
        y += 35
    draw.text(
        (margin, 3290),
        "Authority: local tested checkpoint only • owner ratification, acceptance, and release pending",
        font=body_font,
        fill=colors["gold"],
    )
    if y > 3250:
        raise BuildError(f"QPRINT content overflow: y={y}")
    exif = Image.Exif()
    exif[0x010E] = canonical(model).decode("utf-8")
    image.save(QPRINT, "JPEG", quality=94, subsampling=0, optimize=True, exif=exif)
    with Image.open(QPRINT) as recovered:
        return {
            "readable_dimensions": recovered.size == (2400, 3400),
            "format_is_jpeg": recovered.format == "JPEG",
            "content_model_roundtrip_exact": recovered.getexif().get(0x010E)
            == canonical(model).decode("utf-8"),
            "bytes": QPRINT.stat().st_size,
        }


def entry_for(path: Path, logical: str, ordinal: int, family: str) -> dict[str, Any]:
    purpose = f"qel.alpha.{family}-member.v1.{ordinal:08d}"
    return {
        "ordinal": ordinal,
        "path": logical,
        "bytes": path.stat().st_size,
        "identity_purpose": purpose,
        "sgl_prime_identity": sgl_prime(purpose, path.read_bytes()),
    }


def verify_manifest_entries(root: Path, entries: list[dict[str, Any]]) -> dict[str, Any]:
    errors: list[str] = []
    paths: list[str] = []
    purposes: list[str] = []
    resolved_root = root.resolve()
    for entry in entries:
        logical = PurePosixPath(entry["path"])
        if logical.is_absolute() or ".." in logical.parts or "\\" in entry["path"]:
            errors.append(f"unsafe_path:{entry['path']}")
            continue
        path = root.joinpath(*logical.parts)
        paths.append(entry["path"])
        purposes.append(entry["identity_purpose"])
        if not path.is_file() or path.is_symlink() or not path.resolve().is_relative_to(resolved_root):
            errors.append(f"missing_or_unsafe_file:{entry['path']}")
            continue
        if path.stat().st_size != entry["bytes"]:
            errors.append(f"size_mismatch:{entry['path']}")
        if sgl_prime(entry["identity_purpose"], path.read_bytes()) != entry["sgl_prime_identity"]:
            errors.append(f"identity_mismatch:{entry['path']}")
    if len(paths) != len(set(paths)):
        errors.append("duplicate_path")
    if len(purposes) != len(set(purposes)):
        errors.append("duplicate_purpose")
    return {"ok": not errors, "entries": len(entries), "errors": errors}


def verify_bound_manifest_entries(
    sources: list[tuple[Path, str]], entries: list[dict[str, Any]]
) -> dict[str, Any]:
    """Verify manifest entries against their exact pre-archive source paths."""

    errors: list[str] = []
    if len(sources) != len(entries):
        errors.append("source_entry_count_mismatch")
    seen_paths: list[str] = []
    seen_purposes: list[str] = []
    for ordinal, ((source, logical_name), entry) in enumerate(
        zip(sources, entries, strict=False), start=1
    ):
        logical = PurePosixPath(logical_name)
        if (
            logical.is_absolute()
            or ".." in logical.parts
            or "\\" in logical_name
            or not logical.parts
        ):
            errors.append(f"unsafe_path:{logical_name}")
        if entry.get("ordinal") != ordinal or entry.get("path") != logical_name:
            errors.append(f"entry_binding_mismatch:{logical_name}")
        if not source.is_file() or source.is_symlink():
            errors.append(f"missing_or_unsafe_source:{logical_name}")
            continue
        seen_paths.append(logical_name)
        purpose = entry.get("identity_purpose")
        if type(purpose) is not str:
            errors.append(f"invalid_purpose:{logical_name}")
            continue
        seen_purposes.append(purpose)
        if source.stat().st_size != entry.get("bytes"):
            errors.append(f"size_mismatch:{logical_name}")
        if sgl_prime(purpose, source.read_bytes()) != entry.get("sgl_prime_identity"):
            errors.append(f"identity_mismatch:{logical_name}")
    if len(seen_paths) != len(set(seen_paths)):
        errors.append("duplicate_path")
    if len(seen_purposes) != len(set(seen_purposes)):
        errors.append("duplicate_purpose")
    return {"ok": not errors, "entries": len(entries), "errors": errors}


def main() -> None:
    if ARTIFACTS.exists() and any(ARTIFACTS.iterdir()):
        raise BuildError("artifact directory is not empty; preserve prior candidate")
    ARTIFACTS.mkdir(parents=True, exist_ok=True)

    tests, test_log = run_all_tests()
    if not tests["ok"]:
        raise BuildError("test suites failed")
    write_new(TEST_LOG, test_log.encode("utf-8"))

    custody = source_custody()
    if not custody["ok"]:
        raise BuildError("source custody verification failed")
    custody_record = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-source-custody/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "source_custody": custody,
            "runtime_sequence_advanced": False,
            "owner_signature": "UNSIGNED",
            "release_gate": "HOLD",
        },
        "qel.alpha.classical-qpu-emulator-source-custody.v1",
    )
    write_json(CUSTODY_RECEIPT, custody_record)

    workload = default_workload()
    run_result = execute_workload(workload, replay_count=8)
    workload_record = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-workload-envelope/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "workload": workload,
            "ten_required_field_count": len(WORKLOAD_FIELDS),
            "ten_required_fields": list(WORKLOAD_FIELDS),
            "owner_direction_interpretation": "LOCAL_BOUNDED_CONTINUATION_ONLY_NOT_RATIFICATION_ACCEPTANCE_OR_RELEASE",
        },
        "qel.alpha.classical-qpu-emulator-workload.v1",
    )
    write_json(WORKLOAD_RECORD, workload_record)

    metric_checks = {
        "exact_ten_field_schema": len(workload) == 10 and set(workload) == set(WORKLOAD_FIELDS),
        "defense_only_admission": run_result["defense_admission"]["allowed"] is True,
        "exact_state_normalization": run_result["invariants"]["exact_normalization"] is True,
        "probability_sum_one": run_result["invariants"]["probability_sum_one"] is True,
        "supported_operator_inverse_checks": run_result["invariants"]["supported_operator_inverse_checks"] is True,
        "oracle_state_and_probability_match": run_result["oracle"]["state_match"] is True and run_result["oracle"]["probability_match"] is True,
        "oracle_fidelity_exact_one": run_result["oracle"]["fidelity"] == {"numerator": 1, "denominator": 1},
        "paired_replay_exact": run_result["paired_replay"]["fraction"] == {"numerator": 1, "denominator": 1},
        "local_workload_tests": tests["local"]["ok"],
        "recovered_policy_kernel_tests": tests["upstream_policy_kernel"]["ok"],
        "source_custody_exact": custody["ok"],
        "no_runtime_or_release_effect": run_result["runtime_sequence_advanced"] is False and run_result["release_eligible"] is False,
        "observational_time_recorded": type(run_result["resource_metrics"]["observed_wall_time_ns"]) is int and run_result["resource_metrics"]["observed_wall_time_ns"] > 0,
        "observational_memory_recorded": type(run_result["resource_metrics"]["peak_traced_memory_bytes"]) is int and run_result["resource_metrics"]["peak_traced_memory_bytes"] > 0,
        "five_state_axes_exact": set(run_result["states"]) == {"capability", "evidence", "custody", "privacy", "release"},
    }
    if not all(metric_checks.values()):
        raise BuildError("one or more technical checks failed")
    run_record = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-run-receipt/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "workload_primary_identity": workload_record["primary_identity"],
            "result": run_result,
            "technical_checks": metric_checks,
            "tests": tests,
            "test_log": {
                "name": TEST_LOG.name,
                "bytes": TEST_LOG.stat().st_size,
                "identity_purpose": "qel.alpha.classical-qpu-emulator-test-log.v1",
                "sgl_prime_identity": sgl_prime(
                    "qel.alpha.classical-qpu-emulator-test-log.v1",
                    TEST_LOG.read_bytes(),
                ),
            },
            "decision": {
                "result": "LOCAL_TECHNICAL_TEST_EVIDENCE_RECORDED_OWNER_RATIFICATION_PENDING",
                "states": CHECKPOINT_STATES,
                "task": "ACTIVE",
                "signature": "UNSIGNED",
                "activation": "INACTIVE",
                "runtime_sequence_advanced": False,
                "external_effect": "NONE",
            },
        },
        "qel.alpha.classical-qpu-emulator-run-receipt.v1",
    )
    write_json(RUN_RECEIPT, run_record)

    report_text = f"""# Task Alpha — classical QPU-emulator additive checkpoint V1

Created: {STAMP_ET}  
State: **ACTIVE / HOLD / UNSIGNED / INACTIVE**

## Result

- Recovered and reran the distinct Phase III reference policy kernel: {tests['upstream_policy_kernel']['passed']}/{tests['upstream_policy_kernel']['tests_run']} passed.
- Implemented one three-qubit GHZ circuit emulator on classical CPU compute using exact Gaussian-dyadic amplitudes.
- Enforced the recovered policy kernel's five-factor defense-only gate before the workload can run. Its factors are fixed synthetic demonstration inputs, not external-authorization evidence.
- Declared and validated all ten workload fields required by Task Alpha section 10.
- Matched the independent GHZ3 known answer exactly: state, probabilities, and fidelity 1/1.
- Paired replay: {run_result['paired_replay']['exact_matches']}/{run_result['paired_replay']['runs']} exact canonical matches over all deterministic declared outputs plus environment, input, seed, and precision bindings.
- Observational resources for the primary local run: {run_result['resource_metrics']['observed_wall_time_ns']} ns wall time and {run_result['resource_metrics']['peak_traced_memory_bytes']} peak traced bytes; no optimization or energy claim.
- New workload tests: {tests['local']['passed']}/{tests['local']['tests_run']} passed. Combined recovered-kernel plus workload tests: {tests['passed']}/{tests['tests_run']} passed.

## Source custody

Sequence 52 is now byte/SGL-exact at 96,279,099 bytes and 2,784 members, but it remains a delta rather than a standalone runnable source tree. V10 is preserved as a separate narrow containment harness. The public Phase III checkpoint is recovered and exact. Omega-labelled later code remains frozen and was not imported or merged.

## Boundaries and blockers

This local build does not advance runtime sequence 52. It performs no network, automation, external, scheduling, signing, biometric, release, or hardware action. Library persistence, when completed, is receipted separately and still does not imply acceptance or release. It does not claim physical-QPU execution, physical entanglement, quantum advantage, energy improvement, production deployment, owner ratification, owner acceptance, independent human certification, or release. A real sequence append still requires the exact sequence-36 base and full 22-member source candidate/no-loss runbook. Owner ratification, broader reference-cycle artifacts, separate role reviews, reconstruction/recovery evidence, acceptance, and release remain pending.
"""
    write_new(REPORT, report_text.encode("utf-8"))

    package_sources = [
        (SRC / "alpha_reference_emulator.py", "src/alpha_reference_emulator.py"),
        (TESTS / "test_alpha_reference_emulator.py", "tests/test_alpha_reference_emulator.py"),
        (UPSTREAM / "qel_alpha_omega_contract.py", "upstream/qel_alpha_omega_contract.py"),
        (UPSTREAM / "test_qel_alpha_omega_contract.py", "upstream/test_qel_alpha_omega_contract.py"),
        (Path(__file__), "tools/build_alpha_reference_workload.py"),
        (CYCLE_ROOT / "README.md", "README.md"),
        (WORKLOAD_RECORD, f"evidence/{WORKLOAD_RECORD.name}"),
        (RUN_RECEIPT, f"evidence/{RUN_RECEIPT.name}"),
        (CUSTODY_RECEIPT, f"evidence/{CUSTODY_RECEIPT.name}"),
        (TEST_LOG, f"evidence/{TEST_LOG.name}"),
        (REPORT, f"evidence/{REPORT.name}"),
    ]
    package_entries = [
        entry_for(path, logical, ordinal, "classical-qpu-emulator-package")
        for ordinal, (path, logical) in enumerate(package_sources, start=1)
    ]
    package_validation = verify_bound_manifest_entries(package_sources, package_entries)
    if not package_validation["ok"]:
        raise BuildError(f"package manifest validation failed: {package_validation}")
    package_manifest = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-package-manifest/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "identity_policy": "SGL_PRIME_ONLY_PURPOSE_SEPARATED_RUNTIME_PROFILE",
            "manifest_self_excluded": True,
            "member_count_excluding_manifest": len(package_entries),
            "archive_member_count": len(package_entries) + 1,
            "entries": package_entries,
            "validation": package_validation,
            "states": CHECKPOINT_STATES,
            "task_control_state": "ACTIVE",
            "signature_state": "UNSIGNED",
            "activation_state": "INACTIVE",
        },
        "qel.alpha.classical-qpu-emulator-package-manifest.v1",
    )
    write_json(PACKAGE_MANIFEST, package_manifest)
    deterministic_zip(
        [
            *package_sources,
            (PACKAGE_MANIFEST, f"manifest/{PACKAGE_MANIFEST.name}"),
        ],
        PACKAGE,
    )
    package_expected = {logical: path.read_bytes() for path, logical in package_sources}
    package_expected[f"manifest/{PACKAGE_MANIFEST.name}"] = PACKAGE_MANIFEST.read_bytes()
    package_zip_checks = verify_zip_roundtrip(PACKAGE, package_expected)
    if not package_zip_checks["ok"]:
        raise BuildError(f"package ZIP verification failed: {package_zip_checks}")
    package_purpose = "qel.alpha.classical-qpu-emulator-package.v1"
    package_identity = sgl_prime(package_purpose, PACKAGE.read_bytes())

    qprint_model = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-qprint-content/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "cycle": PREFIX,
            "states": CHECKPOINT_STATES,
            "task_control_state": "ACTIVE",
            "signature_state": "UNSIGNED",
            "activation_state": "INACTIVE",
            "tests": tests,
            "technical_checks": metric_checks,
            "workload_primary_identity": workload_record["primary_identity"],
            "run_primary_identity": run_record["primary_identity"],
            "custody_primary_identity": custody_record["primary_identity"],
            "package_identity_purpose": package_purpose,
            "package_sgl_prime_identity": package_identity,
            "package_checks": package_zip_checks,
            "source_head_sequence": 52,
            "runtime_sequence_advanced": False,
            "omega_imported_or_resumed": False,
            "release_eligible": False,
            "visible_sections": [
                {
                    "heading": "IMPLEMENTED BOUNDED SLICE",
                    "color": "green",
                    "items": [
                        "Three-qubit GHZ circuit emulation on classical CPU compute; exact Gaussian-dyadic amplitudes; no sampling.",
                        "Five fixed synthetic defense-gate factors are required before execution; false, missing, unknown, or non-Boolean values deny; they do not establish external authorization.",
                        "All ten Task Alpha workload fields are declared and locked; runtime sequence remains 52.",
                    ],
                },
                {
                    "heading": "VERIFICATION",
                    "color": "cyan",
                    "items": [
                        f"Recovered policy kernel: {tests['upstream_policy_kernel']['passed']}/{tests['upstream_policy_kernel']['tests_run']} tests passed; new emulator: {tests['local']['passed']}/{tests['local']['tests_run']} tests passed; combined: {tests['passed']}/{tests['tests_run']}.",
                        "GHZ3 oracle: exact state PASS; exact probability PASS; fidelity = 1/1; normalization and supported-operator inverse checks PASS.",
                        f"Paired replay: {run_result['paired_replay']['exact_matches']}/{run_result['paired_replay']['runs']} exact matches across declared deterministic outputs and run bindings; wall time and traced memory recorded; network operations = 0; external effects = 0.",
                    ],
                },
                {
                    "heading": "RECOVERED CUSTODY",
                    "color": "gold",
                    "items": [
                        "Sequence 52: exact 96,279,099 bytes / 2,784 safe members / CRC and SGL PASS; frozen ACTIVE / HOLD / UNSIGNED / INACTIVE.",
                        "V10 narrow containment package and the Phase III public policy-kernel checkpoint are exact and preserved separately.",
                        "Omega-labelled later code was observed for chronology only; imported = false; merged = false; resumed = false.",
                    ],
                },
                {
                    "heading": "NONCLAIMS AND OPEN GATES",
                    "color": "red",
                    "items": [
                        "No physical-QPU, advantage, entanglement, energy-improvement, deployment, biometric, signature, automation, or external-use claim.",
                        "Owner ratification, separate role reviews, clean reconstruction/recovery, owner acceptance, and release remain pending.",
                        "A real sequence append requires the exact sequence-36 base and full 22-member source candidate/no-loss runbook.",
                    ],
                },
            ],
            "package_identity": package_identity,
            "authority": "LOCAL_TESTED_ADDITIVE_CHECKPOINT_ONLY_NO_RELEASE_EFFECT",
        },
        "qel.alpha.classical-qpu-emulator-qprint-content.v1",
    )
    write_json(QPRINT_MODEL, qprint_model)
    qprint_checks = render_qprint(qprint_model)
    if not all(
        qprint_checks[key]
        for key in ("readable_dimensions", "format_is_jpeg", "content_model_roundtrip_exact")
    ):
        raise BuildError(f"QPRINT verification failed: {qprint_checks}")
    qprint_purpose = "qel.alpha.classical-qpu-emulator-qprint-jpeg.v1"
    qprint_identity = sgl_prime(qprint_purpose, QPRINT.read_bytes())

    aggregate = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-aggregate-receipt/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "cycle": PREFIX,
            "tests": tests,
            "technical_checks": metric_checks,
            "source_custody_primary_identity": custody_record["primary_identity"],
            "workload_primary_identity": workload_record["primary_identity"],
            "run_primary_identity": run_record["primary_identity"],
            "package": {
                "name": PACKAGE.name,
                "bytes": PACKAGE.stat().st_size,
                "members": len(package_expected),
                "identity_purpose": package_purpose,
                "sgl_prime_identity": package_identity,
                "checks": package_zip_checks,
            },
            "qprint": {
                "name": QPRINT.name,
                "bytes": QPRINT.stat().st_size,
                "identity_purpose": qprint_purpose,
                "sgl_prime_identity": qprint_identity,
                "content_model_primary_identity": qprint_model["primary_identity"],
                "checks": qprint_checks,
            },
            "decision": {
                "result": "LOCAL_TECHNICAL_TEST_EVIDENCE_RECORDED_OWNER_RATIFICATION_PENDING",
                "states": CHECKPOINT_STATES,
                "task": "ACTIVE",
                "signature": "UNSIGNED",
                "activation": "INACTIVE",
                "runtime_sequence_advanced": False,
                "release_eligible": False,
                "external_effect": "NONE",
            },
        },
        "qel.alpha.classical-qpu-emulator-aggregate-receipt.v1",
    )
    write_json(AGGREGATE, aggregate)

    delivery_sources = [
        (PACKAGE, PACKAGE.name),
        (PACKAGE_MANIFEST, PACKAGE_MANIFEST.name),
        (WORKLOAD_RECORD, WORKLOAD_RECORD.name),
        (RUN_RECEIPT, RUN_RECEIPT.name),
        (CUSTODY_RECEIPT, CUSTODY_RECEIPT.name),
        (TEST_LOG, TEST_LOG.name),
        (REPORT, REPORT.name),
        (QPRINT_MODEL, QPRINT_MODEL.name),
        (QPRINT, QPRINT.name),
        (AGGREGATE, AGGREGATE.name),
        (CYCLE_ROOT / "README.md", "README.md"),
    ]
    delivery_entries = [
        entry_for(path, logical, ordinal, "classical-qpu-emulator-delivery")
        for ordinal, (path, logical) in enumerate(delivery_sources, start=1)
    ]
    delivery_validation = verify_bound_manifest_entries(
        delivery_sources, delivery_entries
    )
    delivery_manifest = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-delivery-manifest/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "manifest_self_excluded": True,
            "member_count_excluding_manifest": len(delivery_entries),
            "archive_member_count": len(delivery_entries) + 1,
            "entries": delivery_entries,
            "validation": {
                "bound_entries_ok": delivery_validation["ok"],
                "ok": delivery_validation["ok"],
            },
            "states": CHECKPOINT_STATES,
            "task_control_state": "ACTIVE",
            "signature_state": "UNSIGNED",
            "activation_state": "INACTIVE",
        },
        "qel.alpha.classical-qpu-emulator-delivery-manifest.v1",
    )
    if not delivery_manifest["validation"]["ok"]:
        raise BuildError(f"delivery manifest validation failed: {delivery_manifest['validation']}")
    write_json(DELIVERY_MANIFEST, delivery_manifest)
    deterministic_zip(
        [*delivery_sources, (DELIVERY_MANIFEST, DELIVERY_MANIFEST.name)],
        DELIVERY,
    )
    delivery_expected = {logical: path.read_bytes() for path, logical in delivery_sources}
    delivery_expected[DELIVERY_MANIFEST.name] = DELIVERY_MANIFEST.read_bytes()
    delivery_checks = verify_zip_roundtrip(DELIVERY, delivery_expected)
    if not delivery_checks["ok"]:
        raise BuildError(f"delivery ZIP verification failed: {delivery_checks}")
    delivery_purpose = "qel.alpha.classical-qpu-emulator-delivery.v1"
    delivery_identity = sgl_prime(delivery_purpose, DELIVERY.read_bytes())

    detached = self_identified(
        {
            "schema": "qel.alpha.classical-qpu-emulator-detached-receipt/v1",
            "created_at_et": STAMP_ET,
            "timestamp_class": STAMP_CLASS,
            "cycle": PREFIX,
            "delivery": {
                "name": DELIVERY.name,
                "bytes": DELIVERY.stat().st_size,
                "members": len(delivery_expected),
                "identity_purpose": delivery_purpose,
                "sgl_prime_identity": delivery_identity,
                "checks": delivery_checks,
            },
            "qprint": {
                "name": QPRINT.name,
                "bytes": QPRINT.stat().st_size,
                "identity_purpose": qprint_purpose,
                "sgl_prime_identity": qprint_identity,
            },
            "aggregate_primary_identity": aggregate["primary_identity"],
            "owner_signature": "UNSIGNED",
            "release_gate": "HOLD",
            "activation": "INACTIVE",
            "runtime_sequence_advanced": False,
            "external_effect": "NONE",
        },
        "qel.alpha.classical-qpu-emulator-detached-receipt.v1",
    )
    write_json(DETACHED, detached)

    forward_paths = [
        path
        for path, _logical in package_sources
        if path.suffix.lower() in {".py", ".json", ".md", ".txt"}
    ] + [QPRINT_MODEL, AGGREGATE, DELIVERY_MANIFEST, DETACHED]
    forward_text = b"\n".join(path.read_bytes() for path in forward_paths).lower()
    forbidden_terms = [
        term.decode("ascii")
        for term in (b"sha" + b"256", b"sha" + b"-256", b"blake" + b"2", b"md" + b"5")
        if term in forward_text
    ]
    terminal_checks = {
        "tests_ok": tests["ok"],
        "source_custody_ok": custody["ok"],
        "workload_identity_ok": verify_self_identified(workload_record),
        "run_identity_ok": verify_self_identified(run_record),
        "custody_identity_ok": verify_self_identified(custody_record),
        "package_manifest_identity_ok": verify_self_identified(package_manifest),
        "package_zip_ok": package_zip_checks["ok"],
        "qprint_model_identity_ok": verify_self_identified(qprint_model),
        "qprint_ok": all(qprint_checks.values()),
        "aggregate_identity_ok": verify_self_identified(aggregate),
        "delivery_manifest_identity_ok": verify_self_identified(delivery_manifest),
        "delivery_zip_ok": delivery_checks["ok"],
        "detached_identity_ok": verify_self_identified(detached),
        "foreign_legacy_identity_terms_absent": not forbidden_terms,
        "release_hold": detached["release_gate"] == "HOLD",
        "runtime_sequence_not_advanced": detached["runtime_sequence_advanced"] is False,
    }
    if not all(terminal_checks.values()):
        raise BuildError(f"terminal checks failed: {terminal_checks}; forbidden={forbidden_terms}")

    print(
        json.dumps(
            {
                "cycle": PREFIX,
                "tests": tests,
                "technical_checks": metric_checks,
                "terminal_checks": terminal_checks,
                "states": CHECKPOINT_STATES,
                "task_control_state": "ACTIVE",
                "signature_state": "UNSIGNED",
                "activation_state": "INACTIVE",
                "runtime_sequence_advanced": False,
                "package": {
                    "path": str(PACKAGE),
                    "bytes": PACKAGE.stat().st_size,
                    "members": len(package_expected),
                    "identity_purpose": package_purpose,
                    "sgl_prime_identity": package_identity,
                },
                "qprint": {
                    "path": str(QPRINT),
                    "bytes": QPRINT.stat().st_size,
                    "identity_purpose": qprint_purpose,
                    "sgl_prime_identity": qprint_identity,
                },
                "delivery": {
                    "path": str(DELIVERY),
                    "bytes": DELIVERY.stat().st_size,
                    "members": len(delivery_expected),
                    "identity_purpose": delivery_purpose,
                    "sgl_prime_identity": delivery_identity,
                },
                "detached": {
                    "path": str(DETACHED),
                    "bytes": DETACHED.stat().st_size,
                    "primary_identity": detached["primary_identity"],
                },
            },
            ensure_ascii=False,
            indent=2,
            sort_keys=True,
        )
    )


if __name__ == "__main__":
    main()
