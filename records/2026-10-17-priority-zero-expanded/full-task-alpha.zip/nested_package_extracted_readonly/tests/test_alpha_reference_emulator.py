#!/usr/bin/env python3

from __future__ import annotations

import copy
import importlib.machinery
import socket
import sys
import tempfile
import tracemalloc
import unittest
from pathlib import Path
from unittest.mock import patch

import alpha_reference_emulator as emulator
from alpha_reference_emulator import (
    CLAIM_BOUNDARY,
    DECLARED_METRICS,
    DECLARED_OUTPUTS,
    DEFENSE_FACTOR_KEYS,
    EXPECTED_FAILURE_CODES,
    GHZ3_ORACLE_PROBABILITIES,
    GHZ3_ORACLE_STATE,
    POLICY_KERNEL_IDENTITY,
    WORKLOAD_ID,
    WORKLOAD_PURPOSE,
    WORKLOAD_FIELDS,
    AdmissionDeniedError,
    EmulatorError,
    ExactState,
    OracleMismatchError,
    WorkloadValidationError,
    apply_cnot,
    apply_h,
    apply_s,
    apply_x,
    apply_z,
    default_workload,
    exact_fidelity,
    execute_workload,
    execute_workload_safe,
    imported_policy_kernel_identity,
    supported_operator_inverse_checks,
    validate_workload,
)
from qel_alpha_omega_contract import canonical_json_bytes


class WorkloadSchemaTests(unittest.TestCase):
    def setUp(self) -> None:
        self.workload = default_workload()

    def test_default_has_exact_ten_top_level_fields(self) -> None:
        self.assertEqual(tuple(self.workload), WORKLOAD_FIELDS)
        self.assertEqual(len(self.workload), 10)
        self.assertIs(validate_workload(self.workload), self.workload)

    def test_each_missing_top_level_field_fails(self) -> None:
        for key in WORKLOAD_FIELDS:
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                del candidate[key]
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_unknown_top_level_field_fails(self) -> None:
        self.workload["silent_upgrade"] = True
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_nonstring_top_level_key_fails_as_validation_error(self) -> None:
        self.workload[7] = "not-a-key"
        with self.assertRaises(WorkloadValidationError) as context:
            validate_workload(self.workload)
        self.assertEqual(context.exception.code, "MISSING_OR_UNKNOWN_CRITICAL_FIELD")

    def test_invalid_unicode_scalar_fails_closed(self) -> None:
        self.workload["workload_identity"]["workload_id"] = "bad\ud800scalar"
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_hostile_equality_object_is_rejected_without_comparison(self) -> None:
        class HostileEquality:
            def __eq__(self, other: object) -> bool:
                raise AssertionError("hostile equality executed")

        self.workload["workload_identity"]["purpose"] = HostileEquality()
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_mapping_subclass_fails(self) -> None:
        class HostileDict(dict):
            pass

        with self.assertRaises(WorkloadValidationError):
            validate_workload(HostileDict(self.workload))

    def test_each_missing_defense_factor_fails(self) -> None:
        for key in DEFENSE_FACTOR_KEYS:
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                del candidate["workload_identity"]["defense_factors"][key]
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_each_nonboolean_defense_factor_fails(self) -> None:
        for key in DEFENSE_FACTOR_KEYS:
            for value in (1, "true", None, [], {}):
                with self.subTest(key=key, value=value):
                    candidate = copy.deepcopy(self.workload)
                    candidate["workload_identity"]["defense_factors"][key] = value
                    with self.assertRaises(WorkloadValidationError):
                        validate_workload(candidate)

    def test_claim_boundary_cannot_be_promoted(self) -> None:
        self.workload["workload_identity"]["claim_boundary"] = "PHYSICAL_QPU"
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_identity_and_purpose_are_fixed_even_with_true_factors(self) -> None:
        for key, value in (
            ("workload_id", WORKLOAD_ID + "-ALTERED"),
            ("purpose", "RETALIATORY_DEMONSTRATION"),
            ("claim_boundary", CLAIM_BOUNDARY + "_AND_HARDWARE"),
        ):
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                candidate["workload_identity"][key] = value
                self.assertTrue(all(candidate["workload_identity"]["defense_factors"].values()))
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_fixed_identity_constants_match_default(self) -> None:
        identity = self.workload["workload_identity"]
        self.assertEqual(identity["workload_id"], WORKLOAD_ID)
        self.assertEqual(identity["purpose"], WORKLOAD_PURPOSE)
        self.assertEqual(identity["claim_boundary"], CLAIM_BOUNDARY)

    def test_physical_qpu_or_advantage_claim_cannot_be_enabled(self) -> None:
        for key in ("physical_qpu_execution", "quantum_advantage_claim"):
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                candidate["workload_identity"][key] = True
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_network_requirement_cannot_be_enabled(self) -> None:
        self.workload["runtime_environment"]["network_required"] = True
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_automation_or_external_effects_cannot_be_enabled(self) -> None:
        for key in ("automation_enabled", "external_effects_enabled"):
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                candidate["runtime_environment"][key] = True
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_dependency_inventory_is_exact(self) -> None:
        self.workload["runtime_environment"]["dependencies"].append("NETWORK")
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_basis_order_is_exact(self) -> None:
        self.workload["initial_state_input_schema"]["basis_order"][0] = "111"
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_workload_qubit_bound_is_exact_three(self) -> None:
        for value in (True, 1, 2, 4, 8, 9):
            with self.subTest(value=value):
                candidate = copy.deepcopy(self.workload)
                candidate["initial_state_input_schema"]["qubits"] = value
                with self.assertRaises(WorkloadValidationError) as context:
                    validate_workload(candidate)
                self.assertEqual(context.exception.code, "INVALID_STATE_SHAPE")

    def test_initial_basis_must_exist(self) -> None:
        self.workload["initial_state_input_schema"]["initial_basis"] = "222"
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_empty_transformations_fail(self) -> None:
        self.workload["transformations"] = []
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_unknown_operator_fails(self) -> None:
        self.workload["transformations"] = [{"gate": "T", "target": 0}]
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_alternate_or_equivalent_circuit_fails(self) -> None:
        for operations in (
            [
                {"gate": "H", "target": 0},
                {"gate": "CNOT", "control": 0, "target": 1},
                {"gate": "CNOT", "control": 0, "target": 2},
            ],
            [
                {"gate": "H", "target": 0},
                {"gate": "CNOT", "control": 0, "target": 2},
                {"gate": "CNOT", "control": 2, "target": 1},
            ],
        ):
            with self.subTest(operations=operations):
                candidate = copy.deepcopy(self.workload)
                candidate["transformations"] = operations
                with self.assertRaises(WorkloadValidationError) as context:
                    validate_workload(candidate)
                self.assertEqual(context.exception.code, "INVALID_OPERATOR")

    def test_declared_operation_bound_is_exact_three(self) -> None:
        for value in (True, 0, 2, 4, 16):
            with self.subTest(value=value):
                candidate = copy.deepcopy(self.workload)
                candidate["parameters_seed_precision"]["max_operations"] = value
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_operator_extra_field_fails(self) -> None:
        self.workload["transformations"][0]["angle"] = "pi/2"
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_boolean_target_fails(self) -> None:
        self.workload["transformations"][0]["target"] = True
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_cnot_self_target_fails(self) -> None:
        self.workload["transformations"][1]["target"] = 0
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_declared_expected_failures_are_exact(self) -> None:
        self.assertEqual(
            self.workload["invariants_expected_failures"]["expected_failure_codes"],
            list(EXPECTED_FAILURE_CODES),
        )
        self.workload["invariants_expected_failures"]["expected_failure_codes"].append("IGNORE")
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_oracle_identity_is_exact(self) -> None:
        self.workload["reference_oracle"]["oracle_id"] = "CALLER_ORACLE"
        with self.assertRaises(WorkloadValidationError):
            validate_workload(self.workload)

    def test_policy_kernel_binding_is_exact_and_present(self) -> None:
        self.assertEqual(imported_policy_kernel_identity(), POLICY_KERNEL_IDENTITY)
        for key, value in (
            ("identity_purpose", "caller.policy"),
            ("sgl_prime_identity", POLICY_KERNEL_IDENTITY[:-1] + "0"),
            ("source_bytes", 82808),
        ):
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                candidate["source_specification"]["policy_kernel_binding"][key] = value
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_policy_loader_ignores_bytecode_cache_and_executes_verified_buffer(self) -> None:
        source = Path(__file__).resolve().parents[1] / "upstream" / "qel_alpha_omega_contract.py"
        module_name = "_qel_alpha_policy_kernel_decoy_cache_test"
        with tempfile.TemporaryDirectory() as temporary_directory:
            temporary_root = Path(temporary_directory)
            copied_source = temporary_root / source.name
            copied_source.write_bytes(source.read_bytes())
            cache = temporary_root / "__pycache__"
            cache.mkdir()
            (cache / "qel_alpha_omega_contract.cpython-312.pyc").write_bytes(
                b"DECOY_BYTECODE_MUST_NOT_BE_READ"
            )
            try:
                with patch.object(
                    importlib.machinery.SourceFileLoader,
                    "get_code",
                    side_effect=AssertionError("source loader or bytecode cache used"),
                ):
                    loaded, loaded_path = emulator._load_bound_policy_kernel(
                        copied_source, module_name=module_name
                    )
                self.assertEqual(loaded_path, copied_source)
                self.assertTrue(
                    loaded.defense_only_gate(
                        defensive_purpose=True,
                        owned_or_authorized_target=True,
                        owner_scope_approved=True,
                        least_privilege=True,
                        all_safety_gates_pass=True,
                    ).allowed
                )
            finally:
                sys.modules.pop(module_name, None)

    def test_declared_outputs_and_metrics_are_exact(self) -> None:
        reporting = self.workload["outputs_metrics_warnings_errors"]
        self.assertEqual(reporting["declared_outputs"], DECLARED_OUTPUTS)
        self.assertEqual(reporting["declared_metrics"], DECLARED_METRICS)
        for key in ("declared_outputs", "declared_metrics"):
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                candidate["outputs_metrics_warnings_errors"][key].append("CALLER_FIELD")
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)

    def test_states_use_five_orthogonal_canonical_axes(self) -> None:
        self.assertEqual(
            self.workload["states"],
            {
                "capability": "DRAFT",
                "evidence": "PROVISIONAL",
                "custody": "PRESENT",
                "privacy": "PROJECT-RESTRICTED",
                "release": "HOLD",
            },
        )

    def test_release_state_cannot_be_promoted(self) -> None:
        for key, value in (
            ("capability", "DEPLOYED"),
            ("evidence", "VERIFIED"),
            ("privacy", "PUBLIC"),
            ("release", "RELEASED"),
        ):
            with self.subTest(key=key):
                candidate = copy.deepcopy(self.workload)
                candidate["states"][key] = value
                with self.assertRaises(WorkloadValidationError):
                    validate_workload(candidate)


class ExactStateTests(unittest.TestCase):
    def test_basis_shape_and_normalization(self) -> None:
        for qubits in (1, 2, 3, 4):
            state = ExactState.basis(qubits, (1 << qubits) - 1)
            self.assertEqual(len(state.real), 1 << qubits)
            self.assertTrue(state.is_normalized())

    def test_invalid_shape_fails(self) -> None:
        with self.assertRaises(EmulatorError) as context:
            ExactState(3, (1, 0), (0, 0), 0)
        self.assertEqual(context.exception.code, "INVALID_STATE_SHAPE")

    def test_supported_qubit_boundaries_and_outside_values(self) -> None:
        self.assertEqual(len(ExactState.basis(1, 0).real), 2)
        self.assertEqual(len(ExactState.basis(8, 255).real), 256)
        for qubits in (True, 0, 9):
            with self.subTest(qubits=qubits):
                with self.assertRaises(EmulatorError) as context:
                    ExactState.basis(qubits, 0)
                self.assertEqual(context.exception.code, "INVALID_STATE_SHAPE")

    def test_hadamard_known_answer(self) -> None:
        state = apply_h(ExactState.basis(1, 0), 0)
        self.assertEqual(state.real, (1, 1))
        self.assertEqual(state.sqrt2_exponent, 1)
        self.assertTrue(state.is_normalized())

    def test_hadamard_squared_is_identity(self) -> None:
        for qubits in (1, 2, 3):
            for basis in range(1 << qubits):
                for target in range(qubits):
                    with self.subTest(qubits=qubits, basis=basis, target=target):
                        state = ExactState.basis(qubits, basis)
                        self.assertEqual(apply_h(apply_h(state, target), target), state)

    def test_x_squared_is_identity(self) -> None:
        state = ExactState.basis(3, 5)
        for target in range(3):
            self.assertEqual(apply_x(apply_x(state, target), target), state)

    def test_x_known_answer(self) -> None:
        observed = apply_x(ExactState.basis(2, 0), 0)
        self.assertEqual(observed, ExactState.basis(2, 2))

    def test_z_squared_is_identity(self) -> None:
        state = apply_h(ExactState.basis(3, 0), 1)
        for target in range(3):
            self.assertEqual(apply_z(apply_z(state, target), target), state)

    def test_z_known_answer(self) -> None:
        observed = apply_z(ExactState.basis(1, 1), 0)
        self.assertEqual(observed.real, (0, -1))
        self.assertEqual(observed.imag, (0, 0))

    def test_s_fourth_is_identity(self) -> None:
        state = apply_h(ExactState.basis(2, 0), 0)
        for target in range(2):
            observed = state
            for _ in range(4):
                observed = apply_s(observed, target)
            self.assertEqual(observed, state)

    def test_s_known_answer(self) -> None:
        observed = apply_s(ExactState.basis(1, 1), 0)
        self.assertEqual(observed.real, (0, 0))
        self.assertEqual(observed.imag, (0, 1))

    def test_cnot_squared_is_identity(self) -> None:
        for basis in range(8):
            state = ExactState.basis(3, basis)
            for control, target in ((0, 1), (0, 2), (1, 0), (1, 2), (2, 0), (2, 1)):
                self.assertEqual(
                    apply_cnot(apply_cnot(state, control, target), control, target),
                    state,
                )

    def test_cnot_requires_distinct_control_target(self) -> None:
        with self.assertRaises(EmulatorError) as context:
            apply_cnot(ExactState.basis(3, 0), 1, 1)
        self.assertEqual(context.exception.code, "INVALID_OPERATOR")

    def test_gate_target_bounds_fail(self) -> None:
        for function in (apply_h, apply_x, apply_z, apply_s):
            with self.subTest(function=function.__name__):
                with self.assertRaises(EmulatorError):
                    function(ExactState.basis(2, 0), 2)

    def test_probability_distribution_is_exact(self) -> None:
        state = apply_h(ExactState.basis(1, 0), 0)
        self.assertEqual(
            state.probability_distribution(),
            [
                {"basis": "0", "probability": {"numerator": 1, "denominator": 2}},
                {"basis": "1", "probability": {"numerator": 1, "denominator": 2}},
            ],
        )

    def test_reduction_canonicalizes_h_squared(self) -> None:
        state = ExactState.basis(1, 0)
        observed = apply_h(apply_h(state, 0), 0)
        self.assertEqual(observed.sqrt2_exponent, 0)
        self.assertEqual(observed.real, (1, 0))

    def test_exact_fidelity_identical_and_orthogonal(self) -> None:
        zero = ExactState.basis(1, 0)
        one = ExactState.basis(1, 1)
        self.assertEqual(exact_fidelity(zero, zero), {"numerator": 1, "denominator": 1})
        self.assertEqual(exact_fidelity(zero, one), {"numerator": 0, "denominator": 1})

    def test_all_supported_operator_inverse_checks_pass(self) -> None:
        self.assertEqual(
            supported_operator_inverse_checks(3),
            {"H_squared": True, "X_squared": True, "Z_squared": True, "S_fourth": True, "CNOT_squared": True},
        )


class ExecutionAndPolicyTests(unittest.TestCase):
    def setUp(self) -> None:
        self.workload = default_workload()

    def test_ghz3_known_answer_passes(self) -> None:
        result = execute_workload(self.workload)
        self.assertTrue(result["oracle"]["state_match"])
        self.assertEqual(result["oracle"]["fidelity"], {"numerator": 1, "denominator": 1})
        self.assertEqual(result["final_exact_state"], GHZ3_ORACLE_STATE)
        self.assertEqual(
            result["measurement_probabilities"], GHZ3_ORACLE_PROBABILITIES
        )
        self.assertEqual(
            [item["basis"] for item in result["measurement_probabilities"]],
            ["000", "111"],
        )

    def test_paired_replay_is_exact(self) -> None:
        result = execute_workload(self.workload, replay_count=16)
        self.assertEqual(result["paired_replay"]["runs"], 16)
        self.assertEqual(result["paired_replay"]["exact_matches"], 16)
        self.assertEqual(
            result["paired_replay"]["fraction"],
            {"numerator": 1, "denominator": 1},
        )
        self.assertEqual(
            result["paired_replay"]["comparison_scope"],
            "DECLARED_DETERMINISTIC_OUTPUTS_PLUS_ENVIRONMENT_INPUT_SEED_PRECISION_BINDINGS",
        )

    def test_replay_detects_nonstate_declared_output_change(self) -> None:
        original = emulator._deterministic_observation
        calls = 0

        def altered(record: dict[str, object], state: ExactState) -> dict[str, object]:
            nonlocal calls
            calls += 1
            output = original(record, state)
            if calls == 2:
                output["declared_deterministic_outputs"]["measurement_probabilities"][0][
                    "probability"
                ]["numerator"] = 0
            return output

        with patch.object(emulator, "_deterministic_observation", side_effect=altered):
            with self.assertRaises(EmulatorError) as context:
                execute_workload(self.workload, replay_count=2)
        self.assertEqual(context.exception.code, "DETERMINISM_MISMATCH")

    def test_invalid_replay_count_fails(self) -> None:
        for count in (True, 0, 1, 33, "8"):
            with self.subTest(count=count):
                with self.assertRaises(WorkloadValidationError):
                    execute_workload(self.workload, replay_count=count)

    def test_each_false_defense_factor_denies(self) -> None:
        expected_reasons = {
            "defensive_purpose": "not_exclusively_defensive",
            "owned_or_authorized_target": "target_not_owned_or_authorized",
            "owner_scope_approved": "owner_scope_not_approved",
            "least_privilege": "least_privilege_failed",
            "all_safety_gates_pass": "safety_gate_failed_or_unknown",
        }
        for factor, reason in expected_reasons.items():
            with self.subTest(factor=factor):
                candidate = copy.deepcopy(self.workload)
                candidate["workload_identity"]["defense_factors"][factor] = False
                with self.assertRaises(AdmissionDeniedError) as context:
                    execute_workload(candidate)
                self.assertEqual(context.exception.reasons, (reason,))

    def test_unauthorized_retaliatory_exploitative_exfiltrative_destructive_cases_deny(self) -> None:
        cases = {
            "unauthorized": "owned_or_authorized_target",
            "retaliatory": "defensive_purpose",
            "exploitative": "defensive_purpose",
            "exfiltrative": "least_privilege",
            "destructive": "all_safety_gates_pass",
        }
        for case, factor in cases.items():
            with self.subTest(case=case):
                candidate = copy.deepcopy(self.workload)
                candidate["workload_identity"]["defense_factors"][factor] = False
                with self.assertRaises(AdmissionDeniedError):
                    execute_workload(candidate)

    def test_oracle_state_mutation_fails_closed(self) -> None:
        self.workload["reference_oracle"]["expected_final_state"]["amplitudes"][0]["real_numerator"] = 2
        with self.assertRaises(OracleMismatchError):
            execute_workload(self.workload)

    def test_oracle_probability_mutation_fails_closed(self) -> None:
        self.workload["reference_oracle"]["expected_probabilities"][0]["probability"]["numerator"] = 0
        with self.assertRaises(OracleMismatchError):
            execute_workload(self.workload)

    def test_repeated_wrong_probability_serializer_fails_oracle(self) -> None:
        wrong = [
            {"basis": "001", "probability": {"numerator": 1, "denominator": 2}},
            {"basis": "110", "probability": {"numerator": 1, "denominator": 2}},
        ]
        with patch.object(
            ExactState, "probability_distribution", return_value=wrong
        ):
            with self.assertRaises(OracleMismatchError) as context:
                execute_workload(self.workload)
        self.assertEqual(context.exception.code, "ORACLE_MISMATCH")

    def test_repeated_wrong_snapshot_serializer_fails_oracle(self) -> None:
        wrong = copy.deepcopy(GHZ3_ORACLE_STATE)
        wrong["basis_order"][0] = "111"
        with patch.object(ExactState, "snapshot", return_value=wrong):
            with self.assertRaises(OracleMismatchError) as context:
                execute_workload(self.workload)
        self.assertEqual(context.exception.code, "ORACLE_MISMATCH")

    def test_nonobservational_execution_output_is_canonical_byte_deterministic(self) -> None:
        first_record = execute_workload(self.workload)
        second_record = execute_workload(copy.deepcopy(self.workload))
        for record in (first_record, second_record):
            del record["resource_metrics"]["observed_wall_time_ns"]
            del record["resource_metrics"]["peak_traced_memory_bytes"]
        first = canonical_json_bytes(first_record)
        second = canonical_json_bytes(second_record)
        self.assertEqual(first, second)

    def test_result_does_not_alias_caller_owned_mutable_data(self) -> None:
        result = execute_workload(self.workload)
        result["transformations"][0]["target"] = 2
        result["states"]["release"] = "ALTERED"
        self.assertEqual(self.workload["transformations"][0]["target"], 0)
        self.assertEqual(self.workload["states"]["release"], "HOLD")

    def test_execution_uses_detached_snapshot_after_admission_begins(self) -> None:
        original_gate = emulator.defense_only_gate

        def mutate_caller_then_gate(**factors: bool) -> object:
            self.workload["states"]["release"] = "RELEASED"
            self.workload["transformations"][0]["target"] = 2
            return original_gate(**factors)

        with patch.object(
            emulator, "defense_only_gate", side_effect=mutate_caller_then_gate
        ):
            result = execute_workload(self.workload)
        self.assertEqual(result["states"]["release"], "HOLD")
        self.assertEqual(result["transformations"][0]["target"], 0)

    def test_no_network_entry_point_is_used(self) -> None:
        with patch.object(socket, "socket", side_effect=AssertionError("network attempted")):
            result = execute_workload(self.workload)
        self.assertEqual(result["resource_metrics"]["network_operations"], 0)

    def test_no_external_or_release_effect(self) -> None:
        result = execute_workload(self.workload)
        self.assertFalse(result["runtime_sequence_advanced"])
        self.assertFalse(result["release_eligible"])
        self.assertEqual(result["states"]["release"], "HOLD")
        self.assertEqual(result["states"]["capability"], "EXECUTED")
        self.assertEqual(result["states"]["privacy"], "PROJECT-RESTRICTED")
        self.assertEqual(result["resource_metrics"]["external_effects"], 0)

    def test_resource_claims_are_bounded(self) -> None:
        metrics = execute_workload(self.workload)["resource_metrics"]
        self.assertEqual(metrics["classical_state_slots"], 8)
        self.assertEqual(metrics["operation_count"], 3)
        self.assertEqual(metrics["energy_or_power_claim"], "NONE_NOT_MEASURED")
        self.assertEqual(metrics["optimization_claim"], "NONE")
        self.assertIs(type(metrics["observed_wall_time_ns"]), int)
        self.assertGreater(metrics["observed_wall_time_ns"], 0)
        self.assertIs(type(metrics["peak_traced_memory_bytes"]), int)
        self.assertGreater(metrics["peak_traced_memory_bytes"], 0)
        self.assertEqual(
            metrics["measurement_class"],
            "OBSERVATIONAL_NOT_DETERMINISTIC_REPLAY_OUTPUT",
        )

    def test_existing_caller_tracemalloc_peak_is_not_reset(self) -> None:
        tracemalloc.start()
        retained = bytearray(5_000_000)
        try:
            _current, peak_before = tracemalloc.get_traced_memory()
            result = execute_workload(self.workload, replay_count=2)
            _current, peak_after = tracemalloc.get_traced_memory()
            self.assertGreaterEqual(peak_after, peak_before)
            self.assertEqual(len(retained), 5_000_000)
            self.assertEqual(
                result["resource_metrics"]["memory_instrument_ownership"],
                "CALLER_OWNED_TRACER_NOT_RESET_OR_STOPPED",
            )
            self.assertTrue(tracemalloc.is_tracing())
        finally:
            tracemalloc.stop()

    def test_defense_admission_is_not_external_authorization(self) -> None:
        admission = execute_workload(self.workload)["defense_admission"]
        self.assertTrue(admission["allowed"])
        self.assertFalse(admission["external_authorization_established"])
        self.assertEqual(
            admission["evidence_class"],
            "SCHEMA_BOUND_SYNTHETIC_LOCAL_DEMONSTRATION",
        )

    def test_each_declared_failure_code_is_observable(self) -> None:
        observed: set[str] = set()

        candidate = copy.deepcopy(self.workload)
        candidate["workload_identity"]["defense_factors"]["defensive_purpose"] = False
        with self.assertRaises(EmulatorError) as context:
            execute_workload(candidate)
        observed.add(context.exception.code)

        candidate = copy.deepcopy(self.workload)
        del candidate["states"]
        with self.assertRaises(EmulatorError) as context:
            execute_workload(candidate)
        observed.add(context.exception.code)

        candidate = copy.deepcopy(self.workload)
        candidate["initial_state_input_schema"]["qubits"] = 2
        with self.assertRaises(EmulatorError) as context:
            execute_workload(candidate)
        observed.add(context.exception.code)

        candidate = copy.deepcopy(self.workload)
        candidate["transformations"][0]["gate"] = "T"
        with self.assertRaises(EmulatorError) as context:
            execute_workload(candidate)
        observed.add(context.exception.code)

        candidate = copy.deepcopy(self.workload)
        candidate["reference_oracle"]["expected_final_state"]["amplitudes"][0][
            "real_numerator"
        ] = 2
        with self.assertRaises(EmulatorError) as context:
            execute_workload(candidate)
        observed.add(context.exception.code)

        original_observation = emulator._deterministic_observation
        calls = 0

        def drift(record: dict[str, object], state: ExactState) -> dict[str, object]:
            nonlocal calls
            calls += 1
            output = original_observation(record, state)
            if calls == 2:
                output["declared_deterministic_outputs"]["warnings"].append("DRIFT")
            return output

        with patch.object(emulator, "_deterministic_observation", side_effect=drift):
            with self.assertRaises(EmulatorError) as context:
                execute_workload(self.workload, replay_count=2)
        observed.add(context.exception.code)

        with patch.object(emulator, "supported_operator_inverse_checks", return_value={"H_squared": False}):
            with self.assertRaises(EmulatorError) as context:
                execute_workload(self.workload, replay_count=2)
        observed.add(context.exception.code)

        self.assertEqual(observed, set(EXPECTED_FAILURE_CODES))

    def test_safe_wrapper_fails_closed_without_echoing_unknown_input(self) -> None:
        candidate = copy.deepcopy(self.workload)
        candidate["ULTRA_SECRET_CANARY"] = "DO_NOT_ECHO"
        result = execute_workload_safe(candidate)
        self.assertFalse(result["ok"])
        self.assertEqual(
            result["error"]["code"], "MISSING_OR_UNKNOWN_CRITICAL_FIELD"
        )
        self.assertNotIn("ULTRA_SECRET_CANARY", canonical_json_bytes(result).decode("utf-8"))
        self.assertFalse(result["runtime_sequence_advanced"])
        self.assertFalse(result["release_eligible"])
        self.assertEqual(result["external_effects"], 0)

    def test_public_nonclaims_are_visible(self) -> None:
        result = execute_workload(self.workload)
        self.assertIn("CLASSICAL_COMPUTE_ONLY", result["warnings"])
        self.assertIn("NO_PHYSICAL_QPU_OR_QUANTUM_ADVANTAGE_CLAIM", result["warnings"])

    def test_source_has_no_network_or_process_adapter_import(self) -> None:
        source = Path(__file__).resolve().parents[1] / "src" / "alpha_reference_emulator.py"
        text = source.read_text(encoding="utf-8")
        for forbidden in ("import socket", "import urllib", "import requests", "import subprocess"):
            self.assertNotIn(forbidden, text)


if __name__ == "__main__":
    unittest.main()
