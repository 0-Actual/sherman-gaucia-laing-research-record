#!/usr/bin/env python3
"""Bounded Task Alpha three-qubit circuit emulation on classical compute.

The state representation is exact for the supported Clifford subset: every
amplitude is an integer Gaussian numerator divided by a shared power of
``sqrt(2)``.  The module performs no network, external, release, signing,
biometric, scheduling, or physical-QPU action.
"""

from __future__ import annotations

import hashlib
import json
import sys
import time
import tracemalloc
import types
from copy import deepcopy
from dataclasses import dataclass
from fractions import Fraction
from math import gcd
from pathlib import Path
from typing import Any, Iterable


POLICY_KERNEL_PURPOSE = "qel.alpha.phase-iii-reference-policy-kernel-source.v1"
POLICY_KERNEL_IDENTITY = (
    "sglp1:shake256-512:"
    "d877dfa81f000b514b723f054942b7fae988848fdf43673cfd1116ad407a611a"
    "af4d9045a786fe9990024168033dd6bbcdc7f480e20bbb55e9c531964ff09a2d"
)


def _sgl_prime_source_identity(data: bytes) -> str:
    hasher = hashlib.shake_256()
    for part in (
        b"SGL-PRIME/v1/FINGERPRINT",
        b"SGL-PRIME-v1",
        POLICY_KERNEL_PURPOSE.encode("utf-8"),
        data,
    ):
        hasher.update(len(part).to_bytes(8, "big"))
        hasher.update(part)
    return "sglp1:shake256-512:" + hasher.hexdigest(64)


def _load_bound_policy_kernel(
    source_path: Path | None = None,
    *,
    module_name: str = "_qel_alpha_policy_kernel_bound_v1",
) -> tuple[object, Path]:
    """Verify the recovered source bytes before any of its code is executed."""

    path = (
        Path(__file__).resolve().parents[1]
        / "upstream"
        / "qel_alpha_omega_contract.py"
        if source_path is None
        else source_path.absolute()
    )
    if not path.is_file() or path.is_symlink():
        raise ImportError("bound policy kernel source is missing or symlinked")
    data = path.read_bytes()
    if _sgl_prime_source_identity(data) != POLICY_KERNEL_IDENTITY:
        raise ImportError("bound policy kernel source identity mismatch")
    module = types.ModuleType(module_name)
    module.__file__ = str(path)
    module.__package__ = ""
    sys.modules[module_name] = module
    try:
        code = compile(data, str(path), "exec", dont_inherit=True, optimize=0)
        exec(code, module.__dict__)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    return module, path


policy_contract, _BOUND_POLICY_PATH = _load_bound_policy_kernel()
canonical_json_bytes = policy_contract.canonical_json_bytes
defense_only_gate = policy_contract.defense_only_gate


class EmulatorError(RuntimeError):
    """Base error for fail-closed workload handling."""

    code = "EMULATOR_FAILURE"

    def __init__(self, message: str, *, code: str | None = None) -> None:
        super().__init__(message)
        self.code = self.code if code is None else code


class WorkloadValidationError(EmulatorError):
    """Raised when a workload is not the exact declared schema."""

    code = "MISSING_OR_UNKNOWN_CRITICAL_FIELD"


class AdmissionDeniedError(EmulatorError):
    """Raised when the defense-only policy denies execution."""

    def __init__(self, reasons: tuple[str, ...]) -> None:
        super().__init__(
            "defense-only admission denied: " + ",".join(reasons),
            code="DEFENSE_GATE_DENIED",
        )
        self.reasons = reasons


class OracleMismatchError(WorkloadValidationError):
    """Raised when an otherwise valid run disagrees with its known answer."""

    code = "ORACLE_MISMATCH"


WORKLOAD_FIELDS = (
    "workload_identity",
    "source_specification",
    "runtime_environment",
    "initial_state_input_schema",
    "parameters_seed_precision",
    "transformations",
    "invariants_expected_failures",
    "reference_oracle",
    "outputs_metrics_warnings_errors",
    "states",
)

DEFENSE_FACTOR_KEYS = (
    "defensive_purpose",
    "owned_or_authorized_target",
    "owner_scope_approved",
    "least_privilege",
    "all_safety_gates_pass",
)

STATE_KEYS = (
    "capability",
    "evidence",
    "custody",
    "privacy",
    "release",
)

EXPECTED_FAILURE_CODES = (
    "DEFENSE_GATE_DENIED",
    "MISSING_OR_UNKNOWN_CRITICAL_FIELD",
    "INVALID_STATE_SHAPE",
    "INVALID_OPERATOR",
    "ORACLE_MISMATCH",
    "DETERMINISM_MISMATCH",
    "INVARIANT_FAILURE",
)

WORKLOAD_ID = "QEL-ALPHA-CLASSICAL-QPU-EMULATOR-GHZ3-V1"
WORKLOAD_PURPOSE = "DEFENSE_GATED_RESEARCH_AND_REPRODUCIBILITY_TEST"
CLAIM_BOUNDARY = "QUANTUM_CIRCUIT_EMULATION_ON_CLASSICAL_COMPUTE_ONLY"
GHZ3_TRANSFORMATIONS = [
    {"gate": "H", "target": 0},
    {"gate": "CNOT", "control": 0, "target": 1},
    {"gate": "CNOT", "control": 1, "target": 2},
]

GHZ3_ORACLE_STATE = {
    "qubits": 3,
    "basis_order": ["000", "001", "010", "011", "100", "101", "110", "111"],
    "amplitudes": [
        {
            "basis": "000",
            "real_numerator": 1,
            "imag_numerator": 0,
            "shared_sqrt2_denominator_exponent": 1,
        },
        {
            "basis": "111",
            "real_numerator": 1,
            "imag_numerator": 0,
            "shared_sqrt2_denominator_exponent": 1,
        },
    ],
    "normalization": {"numerator": 1, "denominator": 1},
}

GHZ3_ORACLE_PROBABILITIES = [
    {"basis": "000", "probability": {"numerator": 1, "denominator": 2}},
    {"basis": "111", "probability": {"numerator": 1, "denominator": 2}},
]

DECLARED_OUTPUTS = [
    "FINAL_EXACT_STATE",
    "MEASUREMENT_PROBABILITIES",
    "ORACLE_COMPARISON",
    "PAIRED_REPLAY",
]

DECLARED_METRICS = [
    "REPLAY_FRACTION",
    "ORACLE_FIDELITY",
    "STATE_SLOTS",
    "OPERATION_COUNT",
    "OBSERVED_WALL_TIME_NS",
    "PEAK_TRACED_MEMORY_BYTES",
]


def _plain_dict(value: object, label: str) -> dict[str, Any]:
    if type(value) is not dict:
        raise WorkloadValidationError(f"{label} must be an exact object")
    return value


def _exact_keys(value: dict[str, Any], expected: Iterable[str], label: str) -> None:
    if any(type(key) is not str for key in value):
        raise WorkloadValidationError(f"{label} keys must be exact strings")
    expected_set = set(expected)
    actual = set(value)
    if actual != expected_set:
        missing = sorted(expected_set - actual)
        unknown = sorted(actual - expected_set)
        raise WorkloadValidationError(
            f"{label} schema mismatch; missing={missing}; unknown={unknown}"
        )


def _nonempty_text(value: object, label: str) -> str:
    if type(value) is not str or not value.strip():
        raise WorkloadValidationError(f"{label} must be nonempty text")
    return value


def _exact_text(
    value: object, expected: str, label: str, *, code: str | None = None
) -> str:
    if type(value) is not str or value != expected:
        raise WorkloadValidationError(
            f"{label} must equal the fixed declared value", code=code
        )
    return value


def _exact_text_list(
    value: object,
    expected: list[str],
    label: str,
    *,
    code: str | None = None,
) -> list[str]:
    if type(value) is not list or any(type(item) is not str for item in value) or value != expected:
        raise WorkloadValidationError(
            f"{label} must equal the fixed declared text list", code=code
        )
    return value


def _exact_int(
    value: object,
    label: str,
    minimum: int,
    maximum: int,
    *,
    code: str | None = None,
) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        raise WorkloadValidationError(
            f"{label} must be an integer in [{minimum}, {maximum}]", code=code
        )
    return value


def _fraction(numerator: int, denominator: int) -> dict[str, int]:
    if denominator <= 0:
        raise EmulatorError("fraction denominator must be positive")
    common = gcd(abs(numerator), denominator)
    return {"numerator": numerator // common, "denominator": denominator // common}


def imported_policy_kernel_identity() -> str:
    module_path_value = getattr(policy_contract, "__file__", None)
    if type(module_path_value) is not str or Path(module_path_value).resolve() != _BOUND_POLICY_PATH:
        raise WorkloadValidationError("policy kernel module path binding mismatch")
    if not _BOUND_POLICY_PATH.is_file() or _BOUND_POLICY_PATH.is_symlink():
        raise WorkloadValidationError("policy kernel module is missing or symlinked")
    return _sgl_prime_source_identity(_BOUND_POLICY_PATH.read_bytes())


@dataclass(frozen=True)
class ExactState:
    """Gaussian integer amplitudes over one shared sqrt(2) exponent."""

    qubits: int
    real: tuple[int, ...]
    imag: tuple[int, ...]
    sqrt2_exponent: int = 0

    def __post_init__(self) -> None:
        if type(self.qubits) is not int or not 1 <= self.qubits <= 8:
            raise EmulatorError(
                "qubits must be an integer in [1, 8]", code="INVALID_STATE_SHAPE"
            )
        slots = 1 << self.qubits
        if type(self.real) is not tuple or type(self.imag) is not tuple:
            raise EmulatorError(
                "amplitude vectors must be exact tuples", code="INVALID_STATE_SHAPE"
            )
        if len(self.real) != slots or len(self.imag) != slots:
            raise EmulatorError(
                "amplitude vector shape mismatch", code="INVALID_STATE_SHAPE"
            )
        if type(self.sqrt2_exponent) is not int or not 0 <= self.sqrt2_exponent <= 64:
            raise EmulatorError(
                "sqrt2 exponent outside bounded range", code="INVALID_STATE_SHAPE"
            )
        for coefficient in (*self.real, *self.imag):
            if type(coefficient) is not int or abs(coefficient) >= 2**63:
                raise EmulatorError(
                    "amplitude coefficient outside signed 64-bit range",
                    code="INVALID_STATE_SHAPE",
                )

    @classmethod
    def basis(cls, qubits: int, index: int) -> "ExactState":
        if type(qubits) is not int or not 1 <= qubits <= 8:
            raise EmulatorError(
                "qubits must be an integer in [1, 8]", code="INVALID_STATE_SHAPE"
            )
        if type(index) is not int or not 0 <= index < (1 << qubits):
            raise EmulatorError(
                "initial basis index outside state space", code="INVALID_STATE_SHAPE"
            )
        real = [0] * (1 << qubits)
        real[index] = 1
        return cls(qubits=qubits, real=tuple(real), imag=tuple([0] * len(real)))

    def reduced(self) -> "ExactState":
        real = list(self.real)
        imag = list(self.imag)
        exponent = self.sqrt2_exponent
        while exponent >= 2 and all(value % 2 == 0 for value in (*real, *imag)):
            real = [value // 2 for value in real]
            imag = [value // 2 for value in imag]
            exponent -= 2
        return ExactState(self.qubits, tuple(real), tuple(imag), exponent)

    def norm_fraction(self) -> dict[str, int]:
        numerator = sum(r * r + i * i for r, i in zip(self.real, self.imag))
        return _fraction(numerator, 1 << self.sqrt2_exponent)

    def is_normalized(self) -> bool:
        return self.norm_fraction() == {"numerator": 1, "denominator": 1}

    def probability_distribution(self) -> list[dict[str, object]]:
        denominator = 1 << self.sqrt2_exponent
        output: list[dict[str, object]] = []
        for index, (real, imag) in enumerate(zip(self.real, self.imag)):
            numerator = real * real + imag * imag
            if numerator:
                output.append(
                    {
                        "basis": format(index, f"0{self.qubits}b"),
                        "probability": _fraction(numerator, denominator),
                    }
                )
        return output

    def snapshot(self) -> dict[str, object]:
        return {
            "qubits": self.qubits,
            "basis_order": [format(index, f"0{self.qubits}b") for index in range(1 << self.qubits)],
            "amplitudes": [
                {
                    "basis": format(index, f"0{self.qubits}b"),
                    "real_numerator": real,
                    "imag_numerator": imag,
                    "shared_sqrt2_denominator_exponent": self.sqrt2_exponent,
                }
                for index, (real, imag) in enumerate(zip(self.real, self.imag))
                if real or imag
            ],
            "normalization": self.norm_fraction(),
        }


def _bit_mask(qubits: int, target: int) -> int:
    if type(target) is not int or not 0 <= target < qubits:
        raise EmulatorError("gate target outside state space", code="INVALID_OPERATOR")
    return 1 << (qubits - 1 - target)


def _permuted(state: ExactState, mapping: list[int]) -> ExactState:
    slots = 1 << state.qubits
    if sorted(mapping) != list(range(slots)):
        raise EmulatorError("operator is not a permutation", code="INVALID_OPERATOR")
    real = [0] * slots
    imag = [0] * slots
    for source, destination in enumerate(mapping):
        real[destination] = state.real[source]
        imag[destination] = state.imag[source]
    return ExactState(state.qubits, tuple(real), tuple(imag), state.sqrt2_exponent).reduced()


def apply_x(state: ExactState, target: int) -> ExactState:
    mask = _bit_mask(state.qubits, target)
    return _permuted(state, [index ^ mask for index in range(1 << state.qubits)])


def apply_z(state: ExactState, target: int) -> ExactState:
    mask = _bit_mask(state.qubits, target)
    real = [(-r if index & mask else r) for index, r in enumerate(state.real)]
    imag = [(-i if index & mask else i) for index, i in enumerate(state.imag)]
    return ExactState(state.qubits, tuple(real), tuple(imag), state.sqrt2_exponent).reduced()


def apply_s(state: ExactState, target: int) -> ExactState:
    mask = _bit_mask(state.qubits, target)
    real: list[int] = []
    imag: list[int] = []
    for index, (r, i) in enumerate(zip(state.real, state.imag)):
        if index & mask:
            real.append(-i)
            imag.append(r)
        else:
            real.append(r)
            imag.append(i)
    return ExactState(state.qubits, tuple(real), tuple(imag), state.sqrt2_exponent).reduced()


def apply_h(state: ExactState, target: int) -> ExactState:
    mask = _bit_mask(state.qubits, target)
    real = list(state.real)
    imag = list(state.imag)
    for zero_index in range(1 << state.qubits):
        if zero_index & mask:
            continue
        one_index = zero_index | mask
        r0, r1 = state.real[zero_index], state.real[one_index]
        i0, i1 = state.imag[zero_index], state.imag[one_index]
        real[zero_index], real[one_index] = r0 + r1, r0 - r1
        imag[zero_index], imag[one_index] = i0 + i1, i0 - i1
    return ExactState(
        state.qubits, tuple(real), tuple(imag), state.sqrt2_exponent + 1
    ).reduced()


def apply_cnot(state: ExactState, control: int, target: int) -> ExactState:
    if control == target:
        raise EmulatorError("CNOT control and target must differ", code="INVALID_OPERATOR")
    control_mask = _bit_mask(state.qubits, control)
    target_mask = _bit_mask(state.qubits, target)
    mapping = [
        index ^ target_mask if index & control_mask else index
        for index in range(1 << state.qubits)
    ]
    return _permuted(state, mapping)


def _validate_operation(operation: object, qubits: int, index: int) -> dict[str, Any]:
    item = _plain_dict(operation, f"transformations[{index}]")
    gate = item.get("gate")
    if type(gate) is not str:
        raise WorkloadValidationError(
            f"operator name at transformations[{index}] must be exact text",
            code="INVALID_OPERATOR",
        )
    if gate in {"H", "X", "Z", "S"}:
        _exact_keys(item, ("gate", "target"), f"transformations[{index}]")
        _exact_int(
            item["target"],
            f"transformations[{index}].target",
            0,
            qubits - 1,
            code="INVALID_OPERATOR",
        )
    elif gate == "CNOT":
        _exact_keys(item, ("gate", "control", "target"), f"transformations[{index}]")
        control = _exact_int(
            item["control"],
            f"transformations[{index}].control",
            0,
            qubits - 1,
            code="INVALID_OPERATOR",
        )
        target = _exact_int(
            item["target"],
            f"transformations[{index}].target",
            0,
            qubits - 1,
            code="INVALID_OPERATOR",
        )
        if control == target:
            raise WorkloadValidationError(
                "CNOT control and target must differ", code="INVALID_OPERATOR"
            )
    else:
        raise WorkloadValidationError(
            f"unsupported operator at transformations[{index}]",
            code="INVALID_OPERATOR",
        )
    return item


def _apply_operation(state: ExactState, operation: dict[str, Any]) -> ExactState:
    gate = operation["gate"]
    if gate == "H":
        return apply_h(state, operation["target"])
    if gate == "X":
        return apply_x(state, operation["target"])
    if gate == "Z":
        return apply_z(state, operation["target"])
    if gate == "S":
        return apply_s(state, operation["target"])
    if gate == "CNOT":
        return apply_cnot(state, operation["control"], operation["target"])
    raise EmulatorError("unreachable unsupported operator", code="INVALID_OPERATOR")


def validate_workload(workload: object) -> dict[str, Any]:
    record = _plain_dict(workload, "workload")
    try:
        canonical_json_bytes(record)
    except Exception as exc:
        raise WorkloadValidationError(
            "workload is outside the canonical JSON domain"
        ) from exc
    _exact_keys(record, WORKLOAD_FIELDS, "workload")

    identity = _plain_dict(record["workload_identity"], "workload_identity")
    _exact_keys(
        identity,
        (
            "workload_id",
            "purpose",
            "claim_boundary",
            "physical_qpu_execution",
            "quantum_advantage_claim",
            "defense_factors",
        ),
        "workload_identity",
    )
    _exact_text(identity["workload_id"], WORKLOAD_ID, "workload_identity.workload_id")
    _exact_text(identity["purpose"], WORKLOAD_PURPOSE, "workload_identity.purpose")
    _exact_text(identity["claim_boundary"], CLAIM_BOUNDARY, "workload_identity.claim_boundary")
    if identity["physical_qpu_execution"] is not False or identity["quantum_advantage_claim"] is not False:
        raise WorkloadValidationError("physical-QPU and quantum-advantage claims must be literal false")
    factors = _plain_dict(identity["defense_factors"], "workload_identity.defense_factors")
    _exact_keys(factors, DEFENSE_FACTOR_KEYS, "workload_identity.defense_factors")
    if any(type(factors[key]) is not bool for key in DEFENSE_FACTOR_KEYS):
        raise WorkloadValidationError("defense factors must be literal booleans")

    source = _plain_dict(record["source_specification"], "source_specification")
    _exact_keys(
        source,
        ("source_id", "specification", "specification_version", "policy_kernel_binding"),
        "source_specification",
    )
    _exact_text(
        source["source_id"],
        "QEL-PHASE-III-ALPHA-PUBLIC-SPEC-2026-08-25",
        "source_specification.source_id",
    )
    _exact_text(
        source["specification"],
        "TASK_ALPHA_SECTIONS_6_10_AND_11",
        "source_specification.specification",
    )
    _exact_text(
        source["specification_version"],
        "2026-08-25-V1",
        "source_specification.specification_version",
    )
    policy_binding = _plain_dict(
        source["policy_kernel_binding"], "source_specification.policy_kernel_binding"
    )
    _exact_keys(
        policy_binding,
        ("identity_purpose", "sgl_prime_identity", "source_bytes"),
        "source_specification.policy_kernel_binding",
    )
    _exact_text(
        policy_binding["identity_purpose"],
        POLICY_KERNEL_PURPOSE,
        "source_specification.policy_kernel_binding.identity_purpose",
    )
    _exact_text(
        policy_binding["sgl_prime_identity"],
        POLICY_KERNEL_IDENTITY,
        "source_specification.policy_kernel_binding.sgl_prime_identity",
    )
    _exact_int(
        policy_binding["source_bytes"],
        "source_specification.policy_kernel_binding.source_bytes",
        82807,
        82807,
    )
    if imported_policy_kernel_identity() != POLICY_KERNEL_IDENTITY:
        raise WorkloadValidationError("imported policy kernel identity mismatch")

    runtime = _plain_dict(record["runtime_environment"], "runtime_environment")
    _exact_keys(
        runtime,
        (
            "runtime_tier",
            "compute_class",
            "dependencies",
            "network_required",
            "automation_enabled",
            "external_effects_enabled",
        ),
        "runtime_environment",
    )
    _exact_text(
        runtime["runtime_tier"],
        "TIER_1_STANDARD_LIBRARY",
        "runtime_environment.runtime_tier",
    )
    _exact_text(
        runtime["compute_class"],
        "CLASSICAL_CPU",
        "runtime_environment.compute_class",
    )
    _exact_text_list(
        runtime["dependencies"],
        ["PYTHON_STANDARD_LIBRARY", "RECOVERED_REFERENCE_POLICY_KERNEL"],
        "runtime_environment.dependencies",
    )
    if runtime["network_required"] is not False:
        raise WorkloadValidationError("network_required must be literal false")
    if runtime["automation_enabled"] is not False or runtime["external_effects_enabled"] is not False:
        raise WorkloadValidationError("automation and external effects must be literal false")

    initialization = _plain_dict(record["initial_state_input_schema"], "initial_state_input_schema")
    _exact_keys(initialization, ("qubits", "basis_order", "initial_basis", "input_schema_version"), "initial_state_input_schema")
    qubits = _exact_int(
        initialization["qubits"],
        "initial_state_input_schema.qubits",
        3,
        3,
        code="INVALID_STATE_SHAPE",
    )
    expected_basis = [format(index, f"0{qubits}b") for index in range(1 << qubits)]
    _exact_text_list(
        initialization["basis_order"],
        expected_basis,
        "initial_state_input_schema.basis_order",
        code="INVALID_STATE_SHAPE",
    )
    _exact_text(
        initialization["initial_basis"],
        "000",
        "initial_state_input_schema.initial_basis",
        code="INVALID_STATE_SHAPE",
    )
    _exact_text(
        initialization["input_schema_version"],
        "qel.alpha.exact-state-input/v1",
        "initial_state_input_schema.input_schema_version",
    )

    parameters = _plain_dict(record["parameters_seed_precision"], "parameters_seed_precision")
    _exact_keys(parameters, ("seed", "arithmetic", "precision", "tolerance", "max_operations"), "parameters_seed_precision")
    _exact_text(
        parameters["seed"],
        "NOT_USED_DETERMINISTIC",
        "parameters_seed_precision.seed",
    )
    _exact_text(
        parameters["arithmetic"],
        "EXACT_GAUSSIAN_DYADIC",
        "parameters_seed_precision.arithmetic",
    )
    _exact_text(
        parameters["precision"],
        "EXACT_INTEGER_OVER_SHARED_SQRT2_POWER",
        "parameters_seed_precision.precision",
    )
    _exact_text(
        parameters["tolerance"],
        "0",
        "parameters_seed_precision.tolerance",
    )
    max_operations = _exact_int(
        parameters["max_operations"],
        "parameters_seed_precision.max_operations",
        3,
        3,
    )

    transformations = record["transformations"]
    if type(transformations) is not list or not transformations or len(transformations) > max_operations:
        raise WorkloadValidationError("transformations must be a nonempty bounded list")
    for index, operation in enumerate(transformations):
        _validate_operation(operation, qubits, index)
    if canonical_json_bytes(transformations) != canonical_json_bytes(GHZ3_TRANSFORMATIONS):
        raise WorkloadValidationError(
            "transformations must equal the fixed GHZ3 oracle circuit",
            code="INVALID_OPERATOR",
        )

    invariants = _plain_dict(record["invariants_expected_failures"], "invariants_expected_failures")
    _exact_keys(invariants, ("invariants", "expected_failure_codes"), "invariants_expected_failures")
    _exact_text_list(
        invariants["invariants"],
        [
            "STATE_VECTOR_SHAPE_2_POWER_Q",
            "EXACT_NORMALIZATION",
            "PROBABILITY_SUM_ONE",
            "SUPPORTED_OPERATORS_UNITARY",
            "PAIRED_REPLAY_EXACT",
        ],
        "invariants_expected_failures.invariants",
    )
    _exact_text_list(
        invariants["expected_failure_codes"],
        list(EXPECTED_FAILURE_CODES),
        "invariants_expected_failures.expected_failure_codes",
    )

    oracle = _plain_dict(record["reference_oracle"], "reference_oracle")
    _exact_keys(oracle, ("oracle_id", "case", "expected_final_state", "expected_probabilities"), "reference_oracle")
    _exact_text(
        oracle["oracle_id"],
        "INDEPENDENT_GHZ3_KNOWN_ANSWER_V1",
        "reference_oracle.oracle_id",
    )
    _exact_text(
        oracle["case"],
        "GHZ3_H0_CNOT01_CNOT12",
        "reference_oracle.case",
    )
    if type(oracle["expected_final_state"]) is not dict or type(oracle["expected_probabilities"]) is not list:
        raise WorkloadValidationError("reference oracle payload type mismatch")
    if canonical_json_bytes(oracle["expected_final_state"]) != canonical_json_bytes(GHZ3_ORACLE_STATE):
        raise OracleMismatchError("reference oracle state fixture mismatch")
    if canonical_json_bytes(oracle["expected_probabilities"]) != canonical_json_bytes(GHZ3_ORACLE_PROBABILITIES):
        raise OracleMismatchError("reference oracle probability fixture mismatch")

    reporting = _plain_dict(record["outputs_metrics_warnings_errors"], "outputs_metrics_warnings_errors")
    _exact_keys(reporting, ("declared_outputs", "declared_metrics", "warning_policy", "error_policy"), "outputs_metrics_warnings_errors")
    _exact_text_list(
        reporting["declared_outputs"],
        DECLARED_OUTPUTS,
        "outputs_metrics_warnings_errors.declared_outputs",
    )
    _exact_text_list(
        reporting["declared_metrics"],
        DECLARED_METRICS,
        "outputs_metrics_warnings_errors.declared_metrics",
    )
    _exact_text(
        reporting["warning_policy"],
        "WARNINGS_ARE_EXPLICIT_AND_NEVER_PROMOTE_STATE",
        "outputs_metrics_warnings_errors.warning_policy",
    )
    _exact_text(
        reporting["error_policy"],
        "ANY_VALIDATION_INVARIANT_OR_ORACLE_ERROR_FAILS_CLOSED",
        "outputs_metrics_warnings_errors.error_policy",
    )

    states = _plain_dict(record["states"], "states")
    _exact_keys(states, STATE_KEYS, "states")
    expected_states = {
        "capability": "DRAFT",
        "evidence": "PROVISIONAL",
        "custody": "PRESENT",
        "privacy": "PROJECT-RESTRICTED",
        "release": "HOLD",
    }
    for key, expected_value in expected_states.items():
        _exact_text(states[key], expected_value, f"states.{key}")
    return record


def _validated_workload_snapshot(workload: object) -> dict[str, Any]:
    """Detach one canonical plain-data snapshot before policy or execution use."""

    try:
        encoded = canonical_json_bytes(workload)
        snapshot = json.loads(encoded.decode("utf-8"))
    except Exception as exc:
        raise WorkloadValidationError(
            "workload is outside the canonical JSON domain"
        ) from exc
    return validate_workload(snapshot)


def _oracle_state() -> ExactState:
    real = [0] * 8
    real[0] = 1
    real[7] = 1
    return ExactState(3, tuple(real), tuple([0] * 8), 1)


def _independent_ghz3_state_match(state: ExactState) -> bool:
    """Check the known answer without using snapshot or gate helpers."""

    return (
        type(state) is ExactState
        and state.qubits == 3
        and state.real == (1, 0, 0, 0, 0, 0, 0, 1)
        and state.imag == (0, 0, 0, 0, 0, 0, 0, 0)
        and state.sqrt2_exponent == 1
    )


def _independent_ghz3_probability_match(state: ExactState) -> bool:
    """Check the two exact 1/2 outcomes directly from raw coefficients."""

    if type(state) is not ExactState or state.qubits != 3 or state.sqrt2_exponent != 1:
        return False
    squared = tuple(
        real * real + imag * imag for real, imag in zip(state.real, state.imag)
    )
    return squared == (1, 0, 0, 0, 0, 0, 0, 1)


def default_workload() -> dict[str, object]:
    return {
        "workload_identity": {
            "workload_id": WORKLOAD_ID,
            "purpose": WORKLOAD_PURPOSE,
            "claim_boundary": CLAIM_BOUNDARY,
            "physical_qpu_execution": False,
            "quantum_advantage_claim": False,
            "defense_factors": {key: True for key in DEFENSE_FACTOR_KEYS},
        },
        "source_specification": {
            "source_id": "QEL-PHASE-III-ALPHA-PUBLIC-SPEC-2026-08-25",
            "specification": "TASK_ALPHA_SECTIONS_6_10_AND_11",
            "specification_version": "2026-08-25-V1",
            "policy_kernel_binding": {
                "identity_purpose": POLICY_KERNEL_PURPOSE,
                "sgl_prime_identity": POLICY_KERNEL_IDENTITY,
                "source_bytes": 82807,
            },
        },
        "runtime_environment": {
            "runtime_tier": "TIER_1_STANDARD_LIBRARY",
            "compute_class": "CLASSICAL_CPU",
            "dependencies": ["PYTHON_STANDARD_LIBRARY", "RECOVERED_REFERENCE_POLICY_KERNEL"],
            "network_required": False,
            "automation_enabled": False,
            "external_effects_enabled": False,
        },
        "initial_state_input_schema": {
            "qubits": 3,
            "basis_order": [format(index, "03b") for index in range(8)],
            "initial_basis": "000",
            "input_schema_version": "qel.alpha.exact-state-input/v1",
        },
        "parameters_seed_precision": {
            "seed": "NOT_USED_DETERMINISTIC",
            "arithmetic": "EXACT_GAUSSIAN_DYADIC",
            "precision": "EXACT_INTEGER_OVER_SHARED_SQRT2_POWER",
            "tolerance": "0",
            "max_operations": 3,
        },
        "transformations": deepcopy(GHZ3_TRANSFORMATIONS),
        "invariants_expected_failures": {
            "invariants": [
                "STATE_VECTOR_SHAPE_2_POWER_Q",
                "EXACT_NORMALIZATION",
                "PROBABILITY_SUM_ONE",
                "SUPPORTED_OPERATORS_UNITARY",
                "PAIRED_REPLAY_EXACT",
            ],
            "expected_failure_codes": list(EXPECTED_FAILURE_CODES),
        },
        "reference_oracle": {
            "oracle_id": "INDEPENDENT_GHZ3_KNOWN_ANSWER_V1",
            "case": "GHZ3_H0_CNOT01_CNOT12",
            "expected_final_state": deepcopy(GHZ3_ORACLE_STATE),
            "expected_probabilities": deepcopy(GHZ3_ORACLE_PROBABILITIES),
        },
        "outputs_metrics_warnings_errors": {
            "declared_outputs": list(DECLARED_OUTPUTS),
            "declared_metrics": list(DECLARED_METRICS),
            "warning_policy": "WARNINGS_ARE_EXPLICIT_AND_NEVER_PROMOTE_STATE",
            "error_policy": "ANY_VALIDATION_INVARIANT_OR_ORACLE_ERROR_FAILS_CLOSED",
        },
        "states": {
            "capability": "DRAFT",
            "evidence": "PROVISIONAL",
            "custody": "PRESENT",
            "privacy": "PROJECT-RESTRICTED",
            "release": "HOLD",
        },
    }


def _run_once(workload: dict[str, Any]) -> ExactState:
    initialization = workload["initial_state_input_schema"]
    qubits = initialization["qubits"]
    initial_index = int(initialization["initial_basis"], 2)
    state = ExactState.basis(qubits, initial_index)
    for operation in workload["transformations"]:
        state = _apply_operation(state, operation)
        if not state.is_normalized():
            raise EmulatorError(
                "operator violated exact normalization", code="INVALID_STATE_SHAPE"
            )
    return state.reduced()


def _measured_run(workload: dict[str, Any]) -> tuple[ExactState, dict[str, object]]:
    """Run once with explicitly labeled, observational local instrumentation."""

    tracing_was_active = tracemalloc.is_tracing()
    if tracing_was_active:
        _before_current, before_peak_bytes = tracemalloc.get_traced_memory()
    else:
        tracemalloc.start()
        before_peak_bytes = 0
    started_ns = time.perf_counter_ns()
    try:
        state = _run_once(workload)
    finally:
        elapsed_ns = time.perf_counter_ns() - started_ns
        _, after_peak_bytes = tracemalloc.get_traced_memory()
        if not tracing_was_active:
            tracemalloc.stop()
    if tracing_was_active:
        peak_bytes = max(0, after_peak_bytes - before_peak_bytes)
        memory_instrument = "PYTHON_TRACEMALLOC_AMBIENT_GLOBAL_PEAK_INCREMENT_READ_ONLY"
        memory_instrument_ownership = "CALLER_OWNED_TRACER_NOT_RESET_OR_STOPPED"
    else:
        peak_bytes = after_peak_bytes
        memory_instrument = "PYTHON_TRACEMALLOC_PEAK_SINGLE_PRIMARY_RUN"
        memory_instrument_ownership = "EMULATOR_OWNED_TEMPORARY_TRACER"
    return state, {
        "observed_wall_time_ns": elapsed_ns,
        "peak_traced_memory_bytes": peak_bytes,
        "time_instrument": "PYTHON_PERF_COUNTER_NS_SINGLE_PRIMARY_RUN",
        "memory_instrument": memory_instrument,
        "memory_instrument_ownership": memory_instrument_ownership,
        "measurement_class": "OBSERVATIONAL_NOT_DETERMINISTIC_REPLAY_OUTPUT",
    }


def exact_fidelity(left: ExactState, right: ExactState) -> dict[str, int]:
    if left.qubits != right.qubits or not left.is_normalized() or not right.is_normalized():
        raise EmulatorError(
            "fidelity requires same-size normalized states", code="INVALID_STATE_SHAPE"
        )
    real_inner = sum(
        lr * rr + li * ri
        for lr, li, rr, ri in zip(left.real, left.imag, right.real, right.imag)
    )
    imag_inner = sum(
        lr * ri - li * rr
        for lr, li, rr, ri in zip(left.real, left.imag, right.real, right.imag)
    )
    denominator = 1 << (left.sqrt2_exponent + right.sqrt2_exponent)
    return _fraction(real_inner * real_inner + imag_inner * imag_inner, denominator)


def supported_operator_inverse_checks(qubits: int) -> dict[str, bool]:
    checks = {"H_squared": True, "X_squared": True, "Z_squared": True, "S_fourth": True, "CNOT_squared": True}
    for basis_index in range(1 << qubits):
        basis = ExactState.basis(qubits, basis_index)
        for target in range(qubits):
            checks["H_squared"] &= apply_h(apply_h(basis, target), target) == basis
            checks["X_squared"] &= apply_x(apply_x(basis, target), target) == basis
            checks["Z_squared"] &= apply_z(apply_z(basis, target), target) == basis
            checks["S_fourth"] &= apply_s(apply_s(apply_s(apply_s(basis, target), target), target), target) == basis
        for control in range(qubits):
            for target in range(qubits):
                if control != target:
                    checks["CNOT_squared"] &= apply_cnot(apply_cnot(basis, control, target), control, target) == basis
    return checks


def _deterministic_observation(
    record: dict[str, Any], state: ExactState
) -> dict[str, object]:
    """Return every replay-bound deterministic output and its run bindings."""

    final_snapshot = state.snapshot()
    final_probabilities = state.probability_distribution()
    raw_state_match = _independent_ghz3_state_match(state)
    raw_probability_match = _independent_ghz3_probability_match(state)
    serialized_state_match = canonical_json_bytes(final_snapshot) == canonical_json_bytes(
        GHZ3_ORACLE_STATE
    )
    serialized_probability_match = canonical_json_bytes(
        final_probabilities
    ) == canonical_json_bytes(GHZ3_ORACLE_PROBABILITIES)
    state_match = raw_state_match and serialized_state_match
    probability_match = raw_probability_match and serialized_probability_match
    return {
        "environment_binding": deepcopy(record["runtime_environment"]),
        "input_binding": deepcopy(record["initial_state_input_schema"]),
        "parameter_seed_precision_binding": deepcopy(
            record["parameters_seed_precision"]
        ),
        "source_binding": deepcopy(record["source_specification"]),
        "workload_identity_binding": {
            "workload_id": record["workload_identity"]["workload_id"],
            "purpose": record["workload_identity"]["purpose"],
            "claim_boundary": record["workload_identity"]["claim_boundary"],
        },
        "transformation_binding": deepcopy(record["transformations"]),
        "declared_deterministic_outputs": {
            "final_exact_state": final_snapshot,
            "measurement_probabilities": final_probabilities,
            "oracle_comparison": {
                "oracle_id": record["reference_oracle"]["oracle_id"],
                "state_match": state_match,
                "probability_match": probability_match,
                "raw_state_match": raw_state_match,
                "raw_probability_match": raw_probability_match,
                "serialized_state_fixture_match": serialized_state_match,
                "serialized_probability_fixture_match": serialized_probability_match,
                "fidelity": exact_fidelity(_oracle_state(), state),
            },
            "warnings": [
                "CLASSICAL_COMPUTE_ONLY",
                "NO_PHYSICAL_QPU_OR_QUANTUM_ADVANTAGE_CLAIM",
                "OWNER_RATIFICATION_ACCEPTANCE_AND_RELEASE_PENDING",
                "DEFENSE_FACTORS_ARE_SCHEMA_BOUND_SYNTHETIC_INPUTS_NOT_EXTERNAL_AUTHORIZATION",
            ],
            "errors": [],
        },
    }


def execute_workload(workload: object, *, replay_count: int = 8) -> dict[str, object]:
    record = _validated_workload_snapshot(workload)
    if type(replay_count) is not int or not 2 <= replay_count <= 32:
        raise WorkloadValidationError("replay_count must be an integer in [2, 32]")
    factors = record["workload_identity"]["defense_factors"]
    admission = defense_only_gate(**factors)
    if not admission.allowed:
        raise AdmissionDeniedError(admission.reasons)

    observed, measured_resources = _measured_run(record)
    deterministic_observation = _deterministic_observation(record, observed)
    deterministic_outputs = deterministic_observation["declared_deterministic_outputs"]
    observed_snapshot = deterministic_outputs["final_exact_state"]
    observed_probabilities = deterministic_outputs["measurement_probabilities"]
    oracle_output = deterministic_outputs["oracle_comparison"]
    oracle_state_match = oracle_output["state_match"]
    oracle_probability_match = oracle_output["probability_match"]
    fidelity = oracle_output["fidelity"]
    if not oracle_state_match or not oracle_probability_match or fidelity != {"numerator": 1, "denominator": 1}:
        raise OracleMismatchError("run disagrees with independent GHZ3 known answer")

    baseline_bytes = canonical_json_bytes(deterministic_observation)
    exact_matches = 0
    for _ in range(replay_count):
        replay_observation = _deterministic_observation(record, _run_once(record))
        if canonical_json_bytes(replay_observation) == baseline_bytes:
            exact_matches += 1
    replay_fraction = _fraction(exact_matches, replay_count)
    if replay_fraction != {"numerator": 1, "denominator": 1}:
        raise EmulatorError(
            "paired replay output mismatch", code="DETERMINISM_MISMATCH"
        )
    inverse_checks = supported_operator_inverse_checks(observed.qubits)
    invariants = {
        "state_vector_shape_2_power_q": len(observed.real) == 1 << observed.qubits,
        "exact_normalization": observed.is_normalized(),
        "probability_sum_one": sum(
            (
                Fraction(
                    item["probability"]["numerator"],
                    item["probability"]["denominator"],
                )
                for item in observed_probabilities
            ),
            start=Fraction(0, 1),
        )
        == Fraction(1, 1),
        "supported_operator_inverse_checks": all(inverse_checks.values()),
        "paired_replay_exact": replay_fraction == {"numerator": 1, "denominator": 1},
    }
    if not all(invariants.values()):
        raise EmulatorError(
            "one or more declared invariants failed", code="INVARIANT_FAILURE"
        )

    post_run_states = deepcopy(record["states"])
    post_run_states["capability"] = "EXECUTED"
    return {
        "schema": "qel.alpha.classical-qpu-emulator-run/v1",
        "workload_id": record["workload_identity"]["workload_id"],
        "claim_boundary": record["workload_identity"]["claim_boundary"],
        "defense_admission": {
            "allowed": admission.allowed,
            "reasons": list(admission.reasons),
            "evidence_class": "SCHEMA_BOUND_SYNTHETIC_LOCAL_DEMONSTRATION",
            "external_authorization_established": False,
        },
        "initial_basis": record["initial_state_input_schema"]["initial_basis"],
        "transformations": deepcopy(record["transformations"]),
        "final_exact_state": observed_snapshot,
        "measurement_probabilities": observed_probabilities,
        "oracle": deepcopy(oracle_output),
        "invariants": invariants,
        "operator_inverse_checks": inverse_checks,
        "paired_replay": {
            "runs": replay_count,
            "exact_matches": exact_matches,
            "fraction": replay_fraction,
            "comparison_scope": "DECLARED_DETERMINISTIC_OUTPUTS_PLUS_ENVIRONMENT_INPUT_SEED_PRECISION_BINDINGS",
        },
        "resource_metrics": {
            "classical_state_slots": 1 << observed.qubits,
            "operation_count": len(record["transformations"]),
            "network_operations": 0,
            "external_effects": 0,
            "energy_or_power_claim": "NONE_NOT_MEASURED",
            "optimization_claim": "NONE",
            "accuracy": {"oracle_fidelity": fidelity, "tolerance": "0"},
            **measured_resources,
        },
        "states": post_run_states,
        "warnings": deepcopy(deterministic_outputs["warnings"]),
        "errors": deepcopy(deterministic_outputs["errors"]),
        "runtime_sequence_advanced": False,
        "release_eligible": False,
    }


def execute_workload_safe(
    workload: object, *, replay_count: int = 8
) -> dict[str, object]:
    """Return a fixed, non-echoing denial object for every handled failure."""

    try:
        return {"ok": True, "result": execute_workload(workload, replay_count=replay_count)}
    except EmulatorError as exc:
        safe_messages = {
            "DEFENSE_GATE_DENIED": "defense-only admission did not pass",
            "MISSING_OR_UNKNOWN_CRITICAL_FIELD": "workload schema validation failed",
            "INVALID_STATE_SHAPE": "state or input shape validation failed",
            "INVALID_OPERATOR": "operator validation failed",
            "ORACLE_MISMATCH": "known-answer validation failed",
            "DETERMINISM_MISMATCH": "paired replay validation failed",
            "INVARIANT_FAILURE": "declared invariant validation failed",
            "EMULATOR_FAILURE": "emulator failed closed",
        }
        code = exc.code if type(exc.code) is str else "EMULATOR_FAILURE"
        return {
            "schema": "qel.alpha.classical-qpu-emulator-denial/v1",
            "ok": False,
            "error": {
                "code": code,
                "message": safe_messages.get(code, "emulator failed closed"),
            },
            "runtime_sequence_advanced": False,
            "release_eligible": False,
            "external_effects": 0,
        }
    except Exception:
        return {
            "schema": "qel.alpha.classical-qpu-emulator-denial/v1",
            "ok": False,
            "error": {
                "code": "EMULATOR_FAILURE",
                "message": "emulator failed closed",
            },
            "runtime_sequence_advanced": False,
            "release_eligible": False,
            "external_effects": 0,
        }
