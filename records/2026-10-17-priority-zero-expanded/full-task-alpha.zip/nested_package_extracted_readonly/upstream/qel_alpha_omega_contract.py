"""Executable public-review contract for Quantum.Earth.Laing Phase III.

This module models evidence-bound governance on classical compute. It is not
a cryptographic signature system, biometric authenticator, autonomous-agent
runtime, production safe-browser implementation, or physical quantum system.
No function performs an external effect.
"""

from __future__ import annotations

from dataclasses import dataclass, replace as dataclass_replace
from datetime import datetime, timedelta
from enum import Enum
import json
import math
from threading import Lock
from typing import Iterable, Mapping, Sequence
import unicodedata
from uuid import uuid4


class Workstream(str, Enum):
    ALPHA = "ALPHA"
    OMEGA = "OMEGA"
    SHARED_CORE = "SHARED_CORE"


class LifecycleState(str, Enum):
    UNSCOPED = "UNSCOPED"
    SCOPED = "SCOPED"
    INTAKE = "INTAKE"
    CLASSIFIED = "CLASSIFIED"
    AUTHORIZED = "AUTHORIZED"
    EXECUTING = "EXECUTING"
    REVIEWING = "REVIEWING"
    RECONCILING = "RECONCILING"
    CHECKPOINTED = "CHECKPOINTED"
    VALIDATING = "VALIDATING"
    VALIDATED = "VALIDATED"
    OWNER_REVIEW = "OWNER_REVIEW"
    ACCEPTED = "ACCEPTED"
    RELEASE_ELIGIBLE = "RELEASE_ELIGIBLE"
    RELEASED = "RELEASED"
    PAUSED = "PAUSED"
    BLOCKED = "BLOCKED"
    CONFLICT = "CONFLICT"
    REVISE = "REVISE"
    REJECTED = "REJECTED"
    CANCELLED = "CANCELLED"
    SUPERSEDED = "SUPERSEDED"
    QUARANTINED = "QUARANTINED"
    WITHDRAWN = "WITHDRAWN"


class EvidenceState(str, Enum):
    RAW = "RAW"
    PROVISIONAL = "PROVISIONAL"
    VERIFIED = "VERIFIED"
    CONFLICT = "CONFLICT"
    BLOCKED = "BLOCKED"
    QUARANTINED = "QUARANTINED"
    SUPERSEDED = "SUPERSEDED"
    RETIRED = "RETIRED"


class CustodyState(str, Enum):
    PRESENT = "PRESENT"
    REFERENCED = "REFERENCED"
    MISSING = "MISSING"
    SUPERSEDED = "SUPERSEDED"
    QUARANTINED = "QUARANTINED"


class PrivacyClass(str, Enum):
    PUBLIC = "PUBLIC"
    PUBLIC_REDACTED = "PUBLIC-REDACTED"
    PROJECT_RESTRICTED = "PROJECT-RESTRICTED"
    PRIVATE = "PRIVATE"
    QUARANTINED = "QUARANTINED"
    SUPERSEDED = "SUPERSEDED"


class CapabilityState(str, Enum):
    SPEC = "SPEC"
    DRAFT = "DRAFT"
    SIMULATED = "SIMULATED"
    EMULATED = "EMULATED"
    EXECUTED = "EXECUTED"
    TESTED = "TESTED"
    DEPLOYED = "DEPLOYED"
    PERSISTED = "PERSISTED"


ROLE_ACTIONS: Mapping[str, frozenset[str]] = {
    "SHERMAN_GAUCIA_LAING": frozenset(
        {"define_scope", "pause", "resume", "ratify", "accept", "release",
         "rollback", "resolve_conflict"}
    ),
    "GAUCIA": frozenset(
        {"intake", "classify", "propose_merge", "implement", "run_test", "report"}
    ),
    "LEVIATHAN": frozenset(
        {"challenge", "block_unsupported", "review_math", "review_security", "report"}
    ),
    "NADINE": frozenset(
        {"validate_provenance", "validate_continuity", "validate_reconstruction",
         "validate_restore", "validate_rollback", "report"}
    ),
}


# Ordinary earned-state progression. Control-state edges are overlaid from
# explicit inbound sets so the public graph is machine-checkable.
_BASE_TRANSITIONS: Mapping[LifecycleState, frozenset[LifecycleState]] = {
    LifecycleState.UNSCOPED: frozenset({LifecycleState.SCOPED, LifecycleState.CANCELLED}),
    LifecycleState.SCOPED: frozenset({LifecycleState.INTAKE, LifecycleState.CANCELLED}),
    LifecycleState.INTAKE: frozenset({LifecycleState.CLASSIFIED}),
    LifecycleState.CLASSIFIED: frozenset({LifecycleState.AUTHORIZED}),
    LifecycleState.AUTHORIZED: frozenset({LifecycleState.EXECUTING, LifecycleState.CANCELLED}),
    LifecycleState.EXECUTING: frozenset({LifecycleState.REVIEWING}),
    LifecycleState.REVIEWING: frozenset({LifecycleState.RECONCILING}),
    LifecycleState.RECONCILING: frozenset({LifecycleState.CHECKPOINTED}),
    LifecycleState.CHECKPOINTED: frozenset({LifecycleState.VALIDATING}),
    LifecycleState.VALIDATING: frozenset({LifecycleState.VALIDATED}),
    LifecycleState.VALIDATED: frozenset(
        {LifecycleState.OWNER_REVIEW, LifecycleState.SUPERSEDED}
    ),
    LifecycleState.OWNER_REVIEW: frozenset(
        {LifecycleState.ACCEPTED, LifecycleState.REVISE, LifecycleState.REJECTED}
    ),
    LifecycleState.ACCEPTED: frozenset(
        {LifecycleState.RELEASE_ELIGIBLE, LifecycleState.SUPERSEDED,
         LifecycleState.WITHDRAWN}
    ),
    LifecycleState.RELEASE_ELIGIBLE: frozenset(
        {LifecycleState.RELEASED, LifecycleState.WITHDRAWN}
    ),
    LifecycleState.RELEASED: frozenset(
        {LifecycleState.SUPERSEDED, LifecycleState.WITHDRAWN}
    ),
    LifecycleState.PAUSED: frozenset({LifecycleState.CANCELLED}),
    LifecycleState.BLOCKED: frozenset({LifecycleState.CANCELLED}),
    LifecycleState.CONFLICT: frozenset({LifecycleState.CANCELLED}),
    LifecycleState.REVISE: frozenset({LifecycleState.CANCELLED}),
    LifecycleState.REJECTED: frozenset({LifecycleState.REVISE, LifecycleState.WITHDRAWN}),
    LifecycleState.CANCELLED: frozenset({LifecycleState.SCOPED}),
    LifecycleState.SUPERSEDED: frozenset(),
    LifecycleState.QUARANTINED: frozenset(),
    LifecycleState.WITHDRAWN: frozenset(),
}

_PROCESS_STATES = (
    LifecycleState.SCOPED,
    LifecycleState.INTAKE,
    LifecycleState.CLASSIFIED,
    LifecycleState.AUTHORIZED,
    LifecycleState.EXECUTING,
    LifecycleState.REVIEWING,
    LifecycleState.RECONCILING,
    LifecycleState.CHECKPOINTED,
    LifecycleState.VALIDATING,
    LifecycleState.VALIDATED,
    LifecycleState.OWNER_REVIEW,
    LifecycleState.ACCEPTED,
    LifecycleState.RELEASE_ELIGIBLE,
)
_CONTROL_STATES = frozenset(
    {LifecycleState.PAUSED, LifecycleState.BLOCKED, LifecycleState.CONFLICT,
     LifecycleState.QUARANTINED}
)
_CONTROL_AND_REVISE = frozenset({*_CONTROL_STATES, LifecycleState.REVISE})

CONTROL_INBOUND_SOURCES: Mapping[LifecycleState, frozenset[LifecycleState]] = {
    LifecycleState.PAUSED: frozenset(_PROCESS_STATES) | _CONTROL_AND_REVISE,
    LifecycleState.BLOCKED: frozenset(_PROCESS_STATES[1:]) | _CONTROL_AND_REVISE,
    LifecycleState.CONFLICT: frozenset(_PROCESS_STATES[2:]) | _CONTROL_AND_REVISE,
    LifecycleState.QUARANTINED: frozenset(_PROCESS_STATES[1:])
    | frozenset({LifecycleState.PAUSED, LifecycleState.BLOCKED,
                 LifecycleState.CONFLICT, LifecycleState.REVISE}),
}


def _build_transition_graph() -> Mapping[LifecycleState, frozenset[LifecycleState]]:
    graph = {state: set(targets) for state, targets in _BASE_TRANSITIONS.items()}
    for destination, sources in CONTROL_INBOUND_SOURCES.items():
        for source in sources:
            graph[source].add(destination)
    # Recovery targets are candidates only. RecoveryEvidence below selects the
    # one stored prior state and prevents caller-selected advancement.
    for state in (LifecycleState.PAUSED, LifecycleState.BLOCKED, LifecycleState.CONFLICT):
        graph[state].update(
            source for source in CONTROL_INBOUND_SOURCES[state]
            if source not in _CONTROL_AND_REVISE
        )
        if LifecycleState.REVISE in CONTROL_INBOUND_SOURCES[state]:
            graph[state].add(LifecycleState.REVISE)
    graph[LifecycleState.REVISE].update(_PROCESS_STATES[:-1])
    graph[LifecycleState.REVISE].add(LifecycleState.REJECTED)
    graph[LifecycleState.QUARANTINED].add(LifecycleState.CLASSIFIED)
    return {state: frozenset(targets) for state, targets in graph.items()}


ALLOWED_TRANSITIONS = _build_transition_graph()


TRANSITION_REQUIRED_EVIDENCE: Mapping[
    tuple[LifecycleState, LifecycleState], frozenset[str]
] = {
    (LifecycleState.UNSCOPED, LifecycleState.SCOPED): frozenset({"scope_receipt"}),
    (LifecycleState.SCOPED, LifecycleState.INTAKE): frozenset({"source_registry"}),
    (LifecycleState.INTAKE, LifecycleState.CLASSIFIED): frozenset({"classification_record"}),
    (LifecycleState.CLASSIFIED, LifecycleState.AUTHORIZED): frozenset(
        {"defense_authorization_receipt"}
    ),
    (LifecycleState.AUTHORIZED, LifecycleState.EXECUTING): frozenset({"execution_record"}),
    (LifecycleState.EXECUTING, LifecycleState.REVIEWING): frozenset({"run_receipt"}),
    (LifecycleState.REVIEWING, LifecycleState.RECONCILING): frozenset({"role_reviews"}),
    (LifecycleState.RECONCILING, LifecycleState.CHECKPOINTED): frozenset({"checkpoint"}),
    (LifecycleState.CHECKPOINTED, LifecycleState.VALIDATING): frozenset({"validation_plan"}),
    (LifecycleState.VALIDATING, LifecycleState.VALIDATED): frozenset(
        {"validation_receipt"}
    ),
    (LifecycleState.VALIDATED, LifecycleState.OWNER_REVIEW): frozenset(
        {"owner_review_packet"}
    ),
    (LifecycleState.OWNER_REVIEW, LifecycleState.ACCEPTED): frozenset(
        {"owner_acceptance"}
    ),
    (LifecycleState.ACCEPTED, LifecycleState.RELEASE_ELIGIBLE): frozenset(
        {"release_eligibility_receipt"}
    ),
    (LifecycleState.RELEASE_ELIGIBLE, LifecycleState.RELEASED): frozenset(
        {"authorized_effect", "effect_receipt", "outcome_check"}
    ),
}

PROPOSED_STATE_REQUIRED_EVIDENCE: Mapping[LifecycleState, frozenset[str]] = {
    LifecycleState.REJECTED: frozenset({"owner_rejection"}),
    LifecycleState.CANCELLED: frozenset({"owner_cancel_receipt"}),
    LifecycleState.SUPERSEDED: frozenset({"supersession_receipt"}),
    LifecycleState.WITHDRAWN: frozenset({"owner_withdrawal"}),
}

CONTROL_REASON_CODES: Mapping[LifecycleState, frozenset[str]] = {
    LifecycleState.PAUSED: frozenset({"CONTROL_PAUSE"}),
    LifecycleState.BLOCKED: frozenset({"CONTROL_BLOCK"}),
    LifecycleState.CONFLICT: frozenset({"CONTROL_CONFLICT"}),
    LifecycleState.QUARANTINED: frozenset({"CONTROL_QUARANTINE"}),
}

# Closed, non-public custody policy for every fail-closed control entry.  The
# bounded reference kernel accepts this exact implementation-owned lane only;
# deployments may define additional lanes only by revising the public contract
# and its conformance tests first.
AUTHORIZED_CONTROL_CUSTODY_DESTINATIONS = frozenset(
    {"controlled-review-custody"}
)

RECOVERY_RESOLUTION_TYPES: Mapping[LifecycleState, str] = {
    LifecycleState.PAUSED: "OWNER_RESUME",
    LifecycleState.BLOCKED: "BLOCK_RESOLUTION",
    LifecycleState.CONFLICT: "CONFLICT_DISPOSITION",
    LifecycleState.REVISE: "REVISION_COMPLETE",
    LifecycleState.QUARANTINED: "QUARANTINE_RELEASE",
}

RECOVERY_TERMINALS = frozenset(
    {LifecycleState.PAUSED, LifecycleState.BLOCKED, LifecycleState.CONFLICT,
     LifecycleState.REVISE, LifecycleState.REJECTED, LifecycleState.CANCELLED,
     LifecycleState.SUPERSEDED, LifecycleState.QUARANTINED,
     LifecycleState.WITHDRAWN}
)


@dataclass(frozen=True)
class GateResult:
    allowed: bool
    reasons: tuple[str, ...]


@dataclass(frozen=True)
class RoleRecord:
    record_id: str
    workstream: Workstream
    source_role: str
    event_time_et: str
    statement: str
    evidence_state: EvidenceState
    custody_state: CustodyState
    privacy_class: PrivacyClass
    capability_state: CapabilityState
    material: bool = True
    task_authorized: bool = False
    source_scope_preserved: bool = False
    defense_gate_passed: bool = False
    tests_pass: bool = False
    merge_receipt_present: bool = False
    blocking_conflict: bool = False
    conflict_id: str | None = None
    supersedes: str | None = None
    public_summary: str | None = None
    exclusion_reason: str | None = None


ProjectionGateReceipt = dict[str, object]
# Retained as a source-compatible name; the runtime representation is an exact
# plain dict so schema keys such as JSON's reserved word ``pass`` are literal.
ProjectionReviewReceipt = ProjectionGateReceipt


@dataclass(frozen=True)
class ControlEntryRecord:
    exception_state: LifecycleState
    prior_state: LifecycleState
    prior_snapshot_id: str
    affected_scope: str
    trigger_evidence_ids: tuple[str, ...]
    reason_code: str
    custody_destination: str
    recorded_at: str
    recorder_role: str
    receipt_id: str
    no_advancement: bool


@dataclass(frozen=True)
class ControlObservationRecord:
    current_state: LifecycleState
    preserved_entry_receipt_id: str
    current_snapshot_id: str
    observed_at: str
    recorder_role: str
    receipt_id: str
    no_advancement: bool


@dataclass(frozen=True)
class RevisionEntryRecord:
    exception_state: LifecycleState
    prior_state: LifecycleState
    prior_snapshot_id: str
    affected_scope: str
    owner_direction_receipt_id: str
    recorded_at: str
    recorder_role: str
    receipt_id: str
    no_advancement: bool


@dataclass(frozen=True)
class StoredLifecycleSnapshot:
    store_receipt_id: str
    current_state: LifecycleState
    preserved_entry_record: ControlEntryRecord | RevisionEntryRecord
    checkpoint_id: str
    checkpoint_state: LifecycleState
    checkpoint_artifact_id: str
    checkpoint_artifact_version: str
    current_artifact_id: str
    current_artifact_version: str
    entry_receipt_present: bool
    checkpoint_verified: bool
    stored_at: str


@dataclass(frozen=True)
class ResolutionReceipt:
    receipt_id: str
    resolution_type: str
    entry_receipt_id: str
    checkpoint_id: str
    affected_scope: str
    artifact_id: str
    artifact_version: str
    resume_state: LifecycleState
    issued_at: str
    owner_action_receipt_id: str
    present: bool


@dataclass(frozen=True)
class OwnerActionReceipt:
    receipt_id: str
    action: str
    artifact_id: str
    artifact_version: str
    affected_scope: str
    issued_at: str
    expires_at: str
    present: bool


@dataclass(frozen=True)
class ClassificationRecord:
    record_id: str
    artifact_id: str
    artifact_version: str
    exact_projection_bytes: bytes
    destination: str
    projection_version: str
    classification: str
    classified_at: str
    present: bool


@dataclass(frozen=True)
class RecoveryEvidence:
    preserved_entry_record: ControlEntryRecord | RevisionEntryRecord
    store_receipt_id: str
    checkpoint_id: str
    checkpoint_state: LifecycleState
    checkpoint_artifact_id: str
    checkpoint_artifact_version: str
    current_artifact_id: str
    current_artifact_version: str
    resume_state: LifecycleState
    resolution_type: str
    resolution_receipt: ResolutionReceipt
    tests_pass: bool
    policy_pass: bool
    owner_action_receipt: OwnerActionReceipt | None
    classification_record: ClassificationRecord | None
    privacy_review_receipt: ProjectionGateReceipt | None
    secret_scan_receipt: ProjectionGateReceipt | None


@dataclass(frozen=True)
class ReleaseBinding:
    artifact_id: str
    artifact_version: str
    artifact_manifest: bytes
    destination: str
    target: str
    privacy_projection_version: str
    conflict_snapshot_id: str
    permission_scope_id: str
    test_set_id: str
    restore_receipt_id: str
    environment_id: str
    release_action_id: str
    authorized_action: str
    expected_outcome: str
    expected_visibility: str
    expected_retrieval: str
    direction_time_et: str
    expires_time_et: str
    max_effect_delay_seconds: int


@dataclass(frozen=True)
class ActionReservationReceipt:
    reservation_id: str
    release_action_id: str
    binding: ReleaseBinding
    evaluation_id: str
    evaluated_at: str
    reserved_at: str
    present: bool


@dataclass(frozen=True)
class PreEffectEvaluation:
    evaluation_id: str
    evaluated_at: str
    binding: ReleaseBinding
    current_state: LifecycleState
    owner_authorized: bool
    defensive_purpose: bool
    owned_or_authorized_target: bool
    owner_scope_approved: bool
    least_privilege: bool
    all_safety_gates_pass: bool
    present_artifacts_valid: bool
    completeness_ratio: float
    policy_pass: bool
    tests_pass: bool
    restore_pass: bool
    public_safe: bool
    owner_accept: bool
    privacy_classification_current: bool
    conflict_free: bool
    permission_current: bool
    environment_current: bool
    reservation_receipt: ActionReservationReceipt


@dataclass(frozen=True)
class ReleaseEffectReceipt:
    receipt_id: str
    binding: ReleaseBinding
    pre_effect_evaluation_id: str
    pre_effect_time_et: str
    action: str
    effect_time_et: str
    authorized_effect: bool
    effect_completed: bool
    observed_result: str
    error_code: str | None
    receipt_present: bool


@dataclass(frozen=True)
class ReleaseOutcomeReceipt:
    receipt_id: str
    binding: ReleaseBinding
    pre_effect_evaluation_id: str
    pre_effect_time_et: str
    action: str
    effect_receipt_id: str
    effect_time_et: str
    observed_at_et: str
    observed_outcome: str
    observed_visibility: str
    observed_retrieval: str
    outcome_check_pass: bool
    visibility_retrieval_check_pass: bool
    receipt_present: bool


@dataclass(frozen=True)
class MergeResult:
    accepted: tuple[RoleRecord, ...]
    held: tuple[RoleRecord, ...]
    conflicts: tuple[RoleRecord, ...]


def _normalize_json(value: object) -> object:
    if value is None or type(value) is bool or type(value) is int:
        return value
    if type(value) is float:
        if not math.isfinite(value):
            raise ValueError("non_finite_json_number")
        return value
    if type(value) is str:
        normalized = unicodedata.normalize("NFC", value)
        try:
            normalized.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise ValueError("invalid_unicode_scalar_value") from exc
        return normalized
    if type(value) in {list, tuple}:
        return [_normalize_json(item) for item in value]
    if type(value) is dict:
        normalized: dict[str, object] = {}
        for key, item in value.items():
            if type(key) is not str:
                raise TypeError("json_object_key_not_string")
            normalized_key = unicodedata.normalize("NFC", key)
            try:
                normalized_key.encode("utf-8")
            except UnicodeEncodeError as exc:
                raise ValueError("invalid_unicode_scalar_value") from exc
            if normalized_key in normalized:
                raise ValueError("normalized_json_key_collision")
            normalized[normalized_key] = _normalize_json(item)
        return normalized
    raise TypeError("unsupported_json_value")


def canonical_json(value: object) -> str:
    """Return NFC, finite-number, deterministic JSON text."""
    return json.dumps(
        _normalize_json(value), sort_keys=True, separators=(",", ":"),
        ensure_ascii=False, allow_nan=False,
    )


def canonical_json_bytes(value: object) -> bytes:
    """Return the literal canonical UTF-8 bytes used for review and emission."""
    return canonical_json(value).encode("utf-8")


def _canonical_json_object_bytes(
    candidate: object, expected_fields: tuple[str, ...]
) -> bool:
    """Accept only the exact canonical UTF-8 JSON object reviewed by field name."""
    if type(candidate) is not bytes or not candidate or len(candidate) > 1_000_000:
        return False

    def reject_constant(_: str) -> object:
        raise ValueError("non_finite_json_number")

    def reject_duplicate_keys(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate_json_key")
            result[key] = value
        return result

    try:
        decoded = candidate.decode("utf-8", errors="strict")
        parsed = json.loads(
            decoded,
            parse_constant=reject_constant,
            object_pairs_hook=reject_duplicate_keys,
        )
        if type(parsed) is not dict:
            return False
        if tuple(sorted(parsed)) != expected_fields:
            return False
        return canonical_json_bytes(parsed) == candidate
    except (
        UnicodeDecodeError, UnicodeEncodeError, TypeError, ValueError,
        json.JSONDecodeError, RecursionError,
    ):
        return False


def _strict_true(value: object) -> bool:
    return type(value) is bool and value is True


def _strict_bool(value: object) -> bool:
    return type(value) is bool


def _nonempty_text(value: object) -> bool:
    if type(value) is not str or not value.strip():
        return False
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return True


MAX_EVIDENCE_IDENTIFIERS = 10_000


def _evidence_identifier_set(values: object) -> set[str] | None:
    """Bound and validate an evidence iterable without trusting its elements."""
    if type(values) in {str, bytes}:
        return None
    try:
        iterator = iter(values)  # type: ignore[arg-type]
        result: set[str] = set()
        for index, value in enumerate(iterator):
            if index >= MAX_EVIDENCE_IDENTIFIERS or not _nonempty_text(value):
                return None
            result.add(value)
        return result
    except Exception:
        return None


def _valid_text(value: object) -> bool:
    if type(value) is not str:
        return False
    try:
        value.encode("utf-8")
    except UnicodeEncodeError:
        return False
    return True


def _aware_datetime(value: object) -> datetime | None:
    if type(value) is not str:
        return None
    try:
        parsed = datetime.fromisoformat(value)
    except ValueError:
        return None
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        return None
    return parsed


def _valid_text_tuple(value: object, *, nonempty: bool = False) -> bool:
    return (
        type(value) is tuple
        and (not nonempty or bool(value))
        and all(_nonempty_text(item) for item in value)
        and len(set(value)) == len(value)
    )


def role_can(role: str, action: str) -> bool:
    return action in ROLE_ACTIONS.get(role, frozenset())


def _valid_control_entry(
    record: object, current: LifecycleState, proposed: LifecycleState
) -> bool:
    if type(record) is not ControlEntryRecord:
        return False
    if type(current) is not LifecycleState or type(proposed) is not LifecycleState:
        return False
    if record.exception_state is not proposed or record.prior_state is not current:
        return False
    if proposed not in CONTROL_REASON_CODES:
        return False
    if not _nonempty_text(record.prior_snapshot_id):
        return False
    if not _nonempty_text(record.affected_scope):
        return False
    if not _valid_text_tuple(record.trigger_evidence_ids, nonempty=True):
        return False
    if not _nonempty_text(record.reason_code):
        return False
    if record.reason_code not in CONTROL_REASON_CODES[proposed]:
        return False
    if (
        not _nonempty_text(record.custody_destination)
        or record.custody_destination not in AUTHORIZED_CONTROL_CUSTODY_DESTINATIONS
    ):
        return False
    if _aware_datetime(record.recorded_at) is None:
        return False
    if not _nonempty_text(record.recorder_role):
        return False
    if record.recorder_role not in ROLE_ACTIONS:
        return False
    if not _nonempty_text(record.receipt_id):
        return False
    return _strict_true(record.no_advancement)


def _valid_revision_entry(
    record: object, current: LifecycleState, proposed: LifecycleState
) -> bool:
    if type(record) is not RevisionEntryRecord:
        return False
    if type(current) is not LifecycleState or proposed is not LifecycleState.REVISE:
        return False
    if record.exception_state is not LifecycleState.REVISE or record.prior_state is not current:
        return False
    if not all(_nonempty_text(value) for value in (
        record.prior_snapshot_id, record.affected_scope,
        record.owner_direction_receipt_id, record.recorder_role, record.receipt_id,
    )):
        return False
    if _aware_datetime(record.recorded_at) is None:
        return False
    if record.recorder_role not in ROLE_ACTIONS:
        return False
    return _strict_true(record.no_advancement)


def _valid_pause_observation(
    record: object, stored: StoredLifecycleSnapshot | None
) -> bool:
    if type(record) is not ControlObservationRecord:
        return False
    if stored is None or not _valid_stored_snapshot(stored):
        return False
    if record.current_state is not LifecycleState.PAUSED:
        return False
    if stored.current_state is not LifecycleState.PAUSED:
        return False
    if not all(_nonempty_text(value) for value in (
        record.preserved_entry_receipt_id, record.current_snapshot_id,
        record.recorder_role, record.receipt_id,
    )):
        return False
    observed_at = _aware_datetime(record.observed_at)
    stored_at = _aware_datetime(stored.stored_at)
    decision_time = datetime.now().astimezone()
    if observed_at is None or stored_at is None:
        return False
    if not (stored_at <= observed_at <= decision_time):
        return False
    if record.recorder_role not in ROLE_ACTIONS:
        return False
    if record.preserved_entry_receipt_id != _entry_receipt_id(
        stored.preserved_entry_record
    ):
        return False
    return _strict_true(record.no_advancement)


def _entry_receipt_id(record: ControlEntryRecord | RevisionEntryRecord) -> str:
    return record.receipt_id


def _entry_scope(record: ControlEntryRecord | RevisionEntryRecord) -> str:
    return record.affected_scope


def _valid_stored_snapshot(snapshot: object) -> bool:
    if type(snapshot) is not StoredLifecycleSnapshot:
        return False
    entry = snapshot.preserved_entry_record
    if type(entry) is ControlEntryRecord:
        if type(entry.prior_state) is not LifecycleState or type(
            entry.exception_state
        ) is not LifecycleState:
            return False
        entry_valid = _valid_control_entry(entry, entry.prior_state, entry.exception_state)
    elif type(entry) is RevisionEntryRecord:
        if type(entry.prior_state) is not LifecycleState or type(
            entry.exception_state
        ) is not LifecycleState:
            return False
        entry_valid = _valid_revision_entry(entry, entry.prior_state, entry.exception_state)
    else:
        return False
    if not entry_valid:
        return False
    if type(snapshot.current_state) is not LifecycleState or type(
        snapshot.checkpoint_state
    ) is not LifecycleState:
        return False
    if snapshot.current_state is not entry.exception_state:
        return False
    if snapshot.checkpoint_state is not entry.prior_state:
        return False
    if not all(_nonempty_text(value) for value in (
        snapshot.store_receipt_id, snapshot.checkpoint_id,
        snapshot.checkpoint_artifact_id, snapshot.checkpoint_artifact_version,
        snapshot.current_artifact_id, snapshot.current_artifact_version,
    )):
        return False
    if snapshot.checkpoint_id != entry.prior_snapshot_id:
        return False
    if snapshot.current_artifact_id != snapshot.checkpoint_artifact_id:
        return False
    if snapshot.current_artifact_version != snapshot.checkpoint_artifact_version:
        return False
    if not _strict_true(snapshot.entry_receipt_present):
        return False
    if not _strict_true(snapshot.checkpoint_verified):
        return False
    return _aware_datetime(snapshot.stored_at) is not None


class LifecycleLedger:
    """Append-only in-process reference store for preserved control snapshots."""

    def __init__(self) -> None:
        self._lock = Lock()
        self._snapshots: dict[str, StoredLifecycleSnapshot] = {}
        self._entry_receipts: dict[str, str] = {}
        self._observations: dict[str, ControlObservationRecord] = {}

    def store(
        self,
        snapshot: StoredLifecycleSnapshot,
    ) -> bool:
        """Public writes are never a trust source; transition_gate stores entries."""
        return False

    def read(self, store_receipt_id: str) -> StoredLifecycleSnapshot | None:
        if not _nonempty_text(store_receipt_id):
            return None
        with self._lock:
            return self._snapshots.get(store_receipt_id)

    def read_observation(
        self, receipt_id: str
    ) -> ControlObservationRecord | None:
        """Read an append-preserved PAUSED observation by exact receipt ID."""
        if not _nonempty_text(receipt_id):
            return None
        with self._lock:
            return self._observations.get(receipt_id)


# Host-owned reference store. Caller-created copies and direct writes are not
# trust sources; validated entry snapshots are appended inside transition_gate.
TRUSTED_LIFECYCLE_LEDGER = LifecycleLedger()
CLASSIFICATION_MAX_AGE = timedelta(minutes=10)


def _valid_preserved_entry(entry: object) -> bool:
    if type(entry) is ControlEntryRecord:
        if type(entry.prior_state) is not LifecycleState or type(
            entry.exception_state
        ) is not LifecycleState:
            return False
        return _valid_control_entry(entry, entry.prior_state, entry.exception_state)
    if type(entry) is RevisionEntryRecord:
        if type(entry.prior_state) is not LifecycleState or type(
            entry.exception_state
        ) is not LifecycleState:
            return False
        return _valid_revision_entry(entry, entry.prior_state, entry.exception_state)
    return False


def _entry_snapshot_matches(
    snapshot: object,
    entry: ControlEntryRecord | RevisionEntryRecord,
    decision_time: datetime,
) -> bool:
    if not _valid_stored_snapshot(snapshot):
        return False
    recorded_at = _aware_datetime(entry.recorded_at)
    stored_at = _aware_datetime(snapshot.stored_at)
    if recorded_at is None or stored_at is None:
        return False
    return (
        type(snapshot.preserved_entry_record) is type(entry)
        and snapshot.preserved_entry_record == entry
        and recorded_at <= stored_at <= decision_time
    )


def _valid_owner_action(
    receipt: object,
    *,
    action: str,
    artifact_id: str,
    artifact_version: str,
    affected_scope: str,
    decision_time: datetime,
    not_before: datetime,
) -> bool:
    if type(receipt) is not OwnerActionReceipt:
        return False
    if not all(
        _nonempty_text(value)
        for value in (receipt.receipt_id, receipt.action, receipt.artifact_id,
                      receipt.artifact_version, receipt.affected_scope,
                      action, artifact_id, artifact_version, affected_scope)
    ):
        return False
    issued = _aware_datetime(receipt.issued_at)
    expiry = _aware_datetime(receipt.expires_at)
    return all(
        (receipt.action == action,
         receipt.artifact_id == artifact_id,
         receipt.artifact_version == artifact_version,
         receipt.affected_scope == affected_scope,
         issued is not None, expiry is not None,
         issued is not None and expiry is not None
         and not_before <= issued <= decision_time <= expiry,
         _strict_true(receipt.present))
    )


def _valid_recovery_evidence(
    evidence: object,
    current: LifecycleState,
    proposed: LifecycleState,
    ledger: object,
) -> tuple[bool, tuple[str, ...]]:
    reasons: list[str] = []
    if type(evidence) is not RecoveryEvidence:
        return False, ("recovery_evidence_missing",)
    if ledger is not TRUSTED_LIFECYCLE_LEDGER:
        return False, ("trusted_lifecycle_ledger_missing",)
    recovery_text_fields = (
        evidence.store_receipt_id,
        evidence.checkpoint_id,
        evidence.checkpoint_artifact_id,
        evidence.checkpoint_artifact_version,
        evidence.current_artifact_id,
        evidence.current_artifact_version,
        evidence.resolution_type,
    )
    if not all(_nonempty_text(value) for value in recovery_text_fields):
        return False, ("recovery_binding_type_invalid",)
    if type(evidence.checkpoint_state) is not LifecycleState or type(
        evidence.resume_state
    ) is not LifecycleState:
        return False, ("recovery_state_type_invalid",)
    stored = ledger.read(evidence.store_receipt_id)
    if stored is None or not _valid_stored_snapshot(stored):
        return False, ("stored_lifecycle_snapshot_missing_or_invalid",)
    entry = evidence.preserved_entry_record
    if not _valid_preserved_entry(entry):
        return False, ("preserved_entry_type_invalid",)
    if type(entry) is not type(stored.preserved_entry_record) or (
        entry != stored.preserved_entry_record
    ):
        reasons.append("preserved_entry_not_equal_to_stored_record")
    if stored.current_state is not current:
        reasons.append("stored_current_state_mismatch")
    if entry.exception_state is not current:
        reasons.append("recovery_exception_state_mismatch")
    if evidence.resume_state is not proposed:
        reasons.append("recovery_resume_state_mismatch")
    for matches, reason in (
        (evidence.checkpoint_id == stored.checkpoint_id, "recovery_checkpoint_id_mismatch"),
        (evidence.checkpoint_state is stored.checkpoint_state,
         "recovery_checkpoint_state_mismatch"),
        (evidence.checkpoint_artifact_id == stored.checkpoint_artifact_id,
         "recovery_checkpoint_artifact_id_mismatch"),
        (evidence.checkpoint_artifact_version == stored.checkpoint_artifact_version,
         "recovery_checkpoint_artifact_version_mismatch"),
        (evidence.current_artifact_id == stored.current_artifact_id,
         "recovery_current_artifact_id_mismatch"),
        (evidence.current_artifact_version == stored.current_artifact_version,
         "recovery_current_artifact_version_mismatch"),
    ):
        if not matches:
            reasons.append(reason)
    if not _strict_true(evidence.tests_pass):
        reasons.append("recovery_tests_not_passed")
    if not _strict_true(evidence.policy_pass):
        reasons.append("recovery_policy_not_passed")
    expected_resolution = RECOVERY_RESOLUTION_TYPES.get(current)
    if evidence.resolution_type != expected_resolution:
        reasons.append("recovery_resolution_type_mismatch")

    decision_time = datetime.now().astimezone()
    stored_time = _aware_datetime(stored.stored_at)
    resolution = evidence.resolution_receipt
    resolution_binding_valid = False
    if type(resolution) is not ResolutionReceipt:
        reasons.append("resolution_receipt_missing_or_invalid")
    else:
        issued = _aware_datetime(resolution.issued_at)
        required_resolution_text = (
            resolution.receipt_id,
            resolution.resolution_type,
            resolution.entry_receipt_id,
            resolution.checkpoint_id,
            resolution.affected_scope,
            resolution.artifact_id,
            resolution.artifact_version,
        )
        resolution_text_valid = all(
            _nonempty_text(value) for value in required_resolution_text
        ) and _valid_text(resolution.owner_action_receipt_id)
        owner_binding_valid = (
            _nonempty_text(resolution.owner_action_receipt_id)
            if current in {
                LifecycleState.PAUSED,
                LifecycleState.CONFLICT,
                LifecycleState.REVISE,
                LifecycleState.QUARANTINED,
            }
            else type(resolution.owner_action_receipt_id) is str
            and resolution.owner_action_receipt_id == ""
        )
        if not resolution_text_valid:
            reasons.append("resolution_receipt_binding_invalid")
        elif not all((
            resolution.resolution_type == expected_resolution,
            resolution.entry_receipt_id == _entry_receipt_id(entry),
            resolution.checkpoint_id == stored.checkpoint_id,
            resolution.affected_scope == _entry_scope(entry),
            resolution.artifact_id == stored.current_artifact_id,
            resolution.artifact_version == stored.current_artifact_version,
            type(resolution.resume_state) is LifecycleState,
            resolution.resume_state is proposed,
            issued is not None,
            stored_time is not None,
            issued is not None and stored_time is not None
            and stored_time <= issued <= decision_time,
            owner_binding_valid,
            _strict_true(resolution.present),
        )):
            reasons.append("resolution_receipt_binding_invalid")
        else:
            resolution_binding_valid = True

    owner_actions = {
        LifecycleState.PAUSED: "RESUME",
        LifecycleState.CONFLICT: "RESOLVE_CONFLICT",
        LifecycleState.REVISE: "ACCEPT_REVISION",
        LifecycleState.QUARANTINED: "RELEASE_QUARANTINE_TO_CLASSIFICATION",
    }
    required_owner_action = owner_actions.get(current)
    if required_owner_action is not None:
        if not _valid_owner_action(
            evidence.owner_action_receipt,
            action=required_owner_action,
            artifact_id=stored.current_artifact_id,
            artifact_version=stored.current_artifact_version,
            affected_scope=_entry_scope(entry),
            decision_time=decision_time,
            not_before=stored_time,
        ):
            reasons.append("owner_action_receipt_missing_or_invalid")
        elif resolution_binding_valid and type(resolution) is ResolutionReceipt and (
            resolution.owner_action_receipt_id != evidence.owner_action_receipt.receipt_id
        ):
            reasons.append("resolution_owner_action_binding_mismatch")
    elif evidence.owner_action_receipt is not None:
        reasons.append("unexpected_owner_action_receipt")

    if current is LifecycleState.QUARANTINED:
        if proposed is not LifecycleState.CLASSIFIED:
            reasons.append("quarantine_may_exit_only_to_classified")
        classification = evidence.classification_record
        if type(classification) is not ClassificationRecord:
            reasons.append("classification_record_missing_or_invalid")
        else:
            classified_at = _aware_datetime(classification.classified_at)
            expected_fields = ("artifact_projection",)
            text_valid = all(_nonempty_text(value) for value in (
                classification.record_id,
                classification.artifact_id,
                classification.artifact_version,
                classification.destination,
                classification.projection_version,
                classification.classification,
            ))
            canonical_bytes_valid = _canonical_json_object_bytes(
                classification.exact_projection_bytes, expected_fields
            )
            fresh = (
                classified_at is not None
                and stored_time is not None
                and stored_time <= classified_at <= decision_time
                and decision_time - classified_at <= CLASSIFICATION_MAX_AGE
            )
            if not text_valid or not canonical_bytes_valid or not fresh:
                reasons.append("classification_record_binding_invalid")
            elif not all((
                classification.artifact_id == stored.current_artifact_id,
                classification.artifact_version == stored.current_artifact_version,
                classification.classification == "RECLASSIFIED_FOR_REVIEW",
                _strict_true(classification.present),
            )):
                reasons.append("classification_record_binding_invalid")
            else:
                privacy_valid = _valid_projection_receipt(
                    evidence.privacy_review_receipt,
                    expected_type="PRIVACY_REVIEW",
                    candidate_bytes=classification.exact_projection_bytes,
                    expected_fields=expected_fields,
                    destination=classification.destination,
                    projection_version=classification.projection_version,
                    artifact_id=classification.artifact_id,
                    artifact_version=classification.artifact_version,
                    decision_time=decision_time,
                    expected_scope=QUARANTINE_PRIVACY_REVIEW_SCOPE_V1,
                    not_before=classified_at,
                )
                scan_valid = _valid_projection_receipt(
                    evidence.secret_scan_receipt,
                    expected_type="SECRET_SCAN",
                    candidate_bytes=classification.exact_projection_bytes,
                    expected_fields=expected_fields,
                    destination=classification.destination,
                    projection_version=classification.projection_version,
                    artifact_id=classification.artifact_id,
                    artifact_version=classification.artifact_version,
                    decision_time=decision_time,
                    expected_scope=QUARANTINE_SECRET_SCAN_SCOPE_V1,
                    not_before=classified_at,
                )
                if not privacy_valid:
                    reasons.append("quarantine_privacy_receipt_missing_stale_or_mismatched")
                if not scan_valid:
                    reasons.append("quarantine_secret_scan_receipt_missing_stale_or_mismatched")
                if privacy_valid and scan_valid and (
                    evidence.privacy_review_receipt["receipt_id"]
                    == evidence.secret_scan_receipt["receipt_id"]
                ):
                    reasons.append("quarantine_review_receipt_ids_not_distinct")
    else:
        if proposed is not entry.prior_state or proposed is not stored.checkpoint_state:
            reasons.append("recovery_not_bound_to_stored_prior_state")
        if any(
            value is not None
            for value in (evidence.classification_record,
                          evidence.privacy_review_receipt,
                          evidence.secret_scan_receipt)
        ):
            reasons.append("unexpected_quarantine_recovery_evidence")
    return not reasons, tuple(dict.fromkeys(reasons))


def transition_gate(
    current: LifecycleState,
    proposed: LifecycleState,
    *,
    required_evidence: Iterable[str],
    present_evidence: Iterable[str],
    tests_pass: bool,
    policy_pass: bool,
    owner_action: bool = False,
    control_record: ControlEntryRecord | None = None,
    control_observation: ControlObservationRecord | None = None,
    revision_record: RevisionEntryRecord | None = None,
    entry_snapshot: StoredLifecycleSnapshot | None = None,
    lifecycle_ledger: LifecycleLedger | None = None,
    recovery_evidence: RecoveryEvidence | None = None,
) -> GateResult:
    """Evaluate one lifecycle transition against graph and structural evidence."""
    if type(current) is not LifecycleState or type(proposed) is not LifecycleState:
        return GateResult(False, ("lifecycle_state_type_invalid",))
    reasons: list[str] = []
    pending_snapshot: StoredLifecycleSnapshot | None = None
    pending_observation: ControlObservationRecord | None = None
    decision_time = datetime.now().astimezone()
    if proposed not in ALLOWED_TRANSITIONS.get(current, frozenset()):
        reasons.append("transition_not_allowed")
    if not _strict_bool(tests_pass):
        reasons.append("tests_result_not_boolean")
    if not _strict_bool(policy_pass):
        reasons.append("policy_result_not_boolean")
    if not _strict_bool(owner_action):
        reasons.append("owner_action_not_boolean")

    required = _evidence_identifier_set(required_evidence)
    present = _evidence_identifier_set(present_evidence)
    if required is None or present is None:
        required = set()
        present = set()
        reasons.append("evidence_collection_invalid")
    recovery_attempt = current in RECOVERY_RESOLUTION_TYPES and (
        recovery_evidence is not None
        or proposed not in RECOVERY_TERMINALS
        or (
            current is LifecycleState.REVISE
            and proposed is LifecycleState.REJECTED
        )
    )
    required.update(TRANSITION_REQUIRED_EVIDENCE.get((current, proposed), frozenset()))
    if not recovery_attempt:
        required.update(PROPOSED_STATE_REQUIRED_EVIDENCE.get(proposed, frozenset()))

    if proposed in CONTROL_REASON_CODES and not recovery_attempt:
        if current is LifecycleState.PAUSED and proposed is LifecycleState.PAUSED:
            if type(control_observation) is not ControlObservationRecord:
                reasons.append("pause_observation_record_missing_or_invalid")
            elif lifecycle_ledger is not TRUSTED_LIFECYCLE_LEDGER:
                reasons.append("trusted_lifecycle_ledger_missing")
            else:
                stored = lifecycle_ledger.read(control_observation.current_snapshot_id)
                if not _valid_pause_observation(control_observation, stored):
                    reasons.append("pause_observation_record_missing_or_invalid")
                else:
                    required.add(control_observation.receipt_id)
                    pending_observation = control_observation
            if control_record is not None:
                reasons.append("pause_self_edge_must_not_replace_preserved_entry")
        elif not _valid_control_entry(control_record, current, proposed):
            reasons.append("control_entry_record_missing_or_invalid")
        else:
            required.add(control_record.receipt_id)
            if lifecycle_ledger is not TRUSTED_LIFECYCLE_LEDGER:
                reasons.append("trusted_lifecycle_ledger_missing")
            if not _entry_snapshot_matches(
                entry_snapshot, control_record, decision_time
            ):
                reasons.append("entry_snapshot_missing_or_invalid")
            else:
                pending_snapshot = entry_snapshot
    elif proposed is LifecycleState.REVISE and not recovery_attempt:
        if not _valid_revision_entry(revision_record, current, proposed):
            reasons.append("revision_entry_record_missing_or_invalid")
        else:
            required.update(
                {revision_record.receipt_id, revision_record.owner_direction_receipt_id}
            )
            if lifecycle_ledger is not TRUSTED_LIFECYCLE_LEDGER:
                reasons.append("trusted_lifecycle_ledger_missing")
            if not _entry_snapshot_matches(
                entry_snapshot, revision_record, decision_time
            ):
                reasons.append("entry_snapshot_missing_or_invalid")
            else:
                pending_snapshot = entry_snapshot

    if recovery_attempt:
        valid_recovery, recovery_reasons = _valid_recovery_evidence(
            recovery_evidence, current, proposed, lifecycle_ledger
        )
        if not valid_recovery:
            reasons.extend(recovery_reasons)
        else:
            required.add(recovery_evidence.resolution_receipt.receipt_id)
            if recovery_evidence.owner_action_receipt is not None:
                required.add(recovery_evidence.owner_action_receipt.receipt_id)
            if recovery_evidence.classification_record is not None:
                required.add(recovery_evidence.classification_record.record_id)
            for receipt in (
                recovery_evidence.privacy_review_receipt,
                recovery_evidence.secret_scan_receipt,
            ):
                if type(receipt) is dict and _nonempty_text(receipt.get("receipt_id")):
                    required.add(receipt["receipt_id"])

    if current is LifecycleState.CANCELLED and proposed is LifecycleState.SCOPED:
        required.add("new_owner_direction")
    if not required and proposed not in CONTROL_REASON_CODES:
        required.add("transition_receipt")
    missing = sorted(required - present)
    if missing:
        reasons.append("missing_evidence:" + ",".join(missing))

    nonadvancing_entry = proposed in CONTROL_REASON_CODES or proposed is LifecycleState.REVISE
    if recovery_attempt or (
        not nonadvancing_entry and proposed not in PROPOSED_STATE_REQUIRED_EVIDENCE
    ):
        if not _strict_true(tests_pass):
            reasons.append("tests_not_passed")
        if not _strict_true(policy_pass):
            reasons.append("policy_not_passed")

    if recovery_attempt:
        owner_decision_required = current in {
            LifecycleState.PAUSED,
            LifecycleState.CONFLICT,
            LifecycleState.REVISE,
            LifecycleState.QUARANTINED,
        }
    else:
        owner_decision_required = proposed in {
            LifecycleState.ACCEPTED, LifecycleState.REVISE,
            LifecycleState.REJECTED, LifecycleState.RELEASED,
            LifecycleState.CANCELLED, LifecycleState.WITHDRAWN,
        }
    if owner_decision_required and not _strict_true(owner_action):
        reasons.append("owner_action_required")
    if entry_snapshot is not None and pending_snapshot is None:
        reasons.append("unexpected_or_invalid_entry_snapshot")
    if not reasons and pending_snapshot is not None:
        with TRUSTED_LIFECYCLE_LEDGER._lock:
            entry_receipt_id = _entry_receipt_id(
                pending_snapshot.preserved_entry_record
            )
            if pending_snapshot.store_receipt_id in TRUSTED_LIFECYCLE_LEDGER._snapshots:
                reasons.append("entry_snapshot_store_receipt_already_used")
            elif entry_receipt_id in TRUSTED_LIFECYCLE_LEDGER._entry_receipts:
                reasons.append("entry_receipt_already_used")
            elif (
                pending_snapshot.store_receipt_id == entry_receipt_id
                or pending_snapshot.store_receipt_id
                in TRUSTED_LIFECYCLE_LEDGER._entry_receipts
                or entry_receipt_id in TRUSTED_LIFECYCLE_LEDGER._snapshots
            ):
                reasons.append("lifecycle_receipt_identity_collision")
            else:
                TRUSTED_LIFECYCLE_LEDGER._snapshots[
                    pending_snapshot.store_receipt_id
                ] = pending_snapshot
                TRUSTED_LIFECYCLE_LEDGER._entry_receipts[
                    entry_receipt_id
                ] = pending_snapshot.store_receipt_id
    if not reasons and pending_observation is not None:
        with TRUSTED_LIFECYCLE_LEDGER._lock:
            existing = TRUSTED_LIFECYCLE_LEDGER._observations.get(
                pending_observation.receipt_id
            )
            if existing is None:
                TRUSTED_LIFECYCLE_LEDGER._observations[
                    pending_observation.receipt_id
                ] = pending_observation
            elif existing != pending_observation:
                reasons.append("observation_receipt_collision")
    return GateResult(allowed=not reasons, reasons=tuple(dict.fromkeys(reasons)))


def defense_only_gate(
    *, defensive_purpose: bool, owned_or_authorized_target: bool,
    owner_scope_approved: bool, least_privilege: bool,
    all_safety_gates_pass: bool,
) -> GateResult:
    checks = {
        "not_exclusively_defensive": defensive_purpose,
        "target_not_owned_or_authorized": owned_or_authorized_target,
        "owner_scope_not_approved": owner_scope_approved,
        "least_privilege_failed": least_privilege,
        "safety_gate_failed_or_unknown": all_safety_gates_pass,
    }
    reasons = tuple(name for name, passed in checks.items() if not _strict_true(passed))
    return GateResult(allowed=not reasons, reasons=reasons)


def route_for_publication(record: RoleRecord) -> str:
    if type(record) is not RoleRecord or type(record.privacy_class) is not PrivacyClass:
        return "QUARANTINE"
    if record.privacy_class is PrivacyClass.PUBLIC:
        return "PUBLIC_REVIEW"
    if record.privacy_class is PrivacyClass.PUBLIC_REDACTED:
        return "PUBLIC_REDACTED_REVIEW"
    if record.privacy_class is PrivacyClass.PROJECT_RESTRICTED:
        return "INTERNAL_ONLY"
    if record.privacy_class is PrivacyClass.PRIVATE:
        return "PRIVATE_ONLY"
    if record.privacy_class is PrivacyClass.SUPERSEDED:
        return "HISTORY_ONLY"
    return "QUARANTINE"


def merge_shared_core(
    current: Sequence[RoleRecord], incoming: Sequence[RoleRecord]
) -> MergeResult:
    """Append eligible records; never overwrite a prior record or hide conflict."""
    accepted = list(current)
    held: list[RoleRecord] = []
    conflicts: list[RoleRecord] = []
    known_ids = {record.record_id for record in current}
    for record in incoming:
        if type(record) is not RoleRecord:
            held.append(record)
            continue
        if record.record_id in known_ids:
            held.append(record)
            continue
        if record.conflict_id is not None or _strict_true(record.blocking_conflict):
            conflicts.append(record)
            held.append(record)
            continue
        if not all(
            _strict_true(value)
            for value in (record.material, record.task_authorized,
                          record.source_scope_preserved, record.defense_gate_passed,
                          record.tests_pass, record.merge_receipt_present)
        ):
            held.append(record)
            continue
        if record.evidence_state is not EvidenceState.VERIFIED:
            held.append(record)
            continue
        if record.custody_state is not CustodyState.PRESENT:
            held.append(record)
            continue
        if record.privacy_class in {PrivacyClass.PRIVATE, PrivacyClass.QUARANTINED,
                                    PrivacyClass.SUPERSEDED}:
            held.append(record)
            continue
        accepted.append(record)
        known_ids.add(record.record_id)
    return MergeResult(accepted=tuple(accepted), held=tuple(held),
                       conflicts=tuple(conflicts))


def completeness(required: Iterable[str], present: Iterable[str]) -> float:
    required_set = set(required)
    if not required_set:
        return 0.0
    return len(required_set & set(present)) / len(required_set)


def integrity(validations: Iterable[bool]) -> float:
    values = tuple(validations)
    if not values:
        return 0.0
    return sum(1 for value in values if _strict_true(value)) / len(values)


def release_gate(
    *, current_state: LifecycleState, present_artifacts_valid: bool,
    completeness_ratio: float, policy_pass: bool, tests_pass: bool,
    restore_pass: bool, public_safe: bool, owner_accept: bool,
) -> GateResult:
    checks = {
        "task_not_accepted": current_state is LifecycleState.ACCEPTED,
        "present_artifact_validation_failed": present_artifacts_valid,
        "required_set_incomplete": type(completeness_ratio) in {int, float}
        and type(completeness_ratio) is not bool and completeness_ratio == 1.0,
        "policy_not_passed": policy_pass,
        "tests_not_passed": tests_pass,
        "restore_not_passed": restore_pass,
        "public_safety_not_passed": public_safe,
        "owner_acceptance_missing": owner_accept,
    }
    reasons = tuple(name for name, passed in checks.items() if not _strict_true(passed))
    return GateResult(allowed=not reasons, reasons=reasons)


def _valid_release_binding(binding: object) -> bool:
    if type(binding) is not ReleaseBinding:
        return False
    text_values = (
        binding.artifact_id, binding.artifact_version, binding.destination,
        binding.target, binding.privacy_projection_version,
        binding.conflict_snapshot_id, binding.permission_scope_id,
        binding.test_set_id, binding.restore_receipt_id, binding.environment_id,
        binding.release_action_id, binding.authorized_action,
        binding.expected_outcome, binding.expected_visibility,
        binding.expected_retrieval,
    )
    direction = _aware_datetime(binding.direction_time_et)
    expiry = _aware_datetime(binding.expires_time_et)
    return all(
        (all(_nonempty_text(value) for value in text_values),
         type(binding.artifact_manifest) is bytes and bool(binding.artifact_manifest),
         direction is not None, expiry is not None,
         direction is not None and expiry is not None and direction <= expiry,
         type(binding.max_effect_delay_seconds) is int
         and type(binding.max_effect_delay_seconds) is not bool
         and binding.max_effect_delay_seconds > 0)
    )


def _same_release_binding(left: object, right: object) -> bool:
    if not _valid_release_binding(left) or not _valid_release_binding(right):
        return False
    return all(
        getattr(left, name) == getattr(right, name)
        for name in ReleaseBinding.__dataclass_fields__
    )


def _pre_effect_checks(evaluation: PreEffectEvaluation) -> dict[str, bool]:
    return {
        "task_not_release_eligible": evaluation.current_state
        is LifecycleState.RELEASE_ELIGIBLE,
        "owner_release_authorization_missing": evaluation.owner_authorized,
        "not_exclusively_defensive": evaluation.defensive_purpose,
        "target_not_owned_or_authorized": evaluation.owned_or_authorized_target,
        "owner_scope_not_approved": evaluation.owner_scope_approved,
        "least_privilege_failed": evaluation.least_privilege,
        "safety_gate_failed_or_unknown": evaluation.all_safety_gates_pass,
        "present_artifact_validation_failed": evaluation.present_artifacts_valid,
        "required_set_incomplete": type(evaluation.completeness_ratio) in {int, float}
        and type(evaluation.completeness_ratio) is not bool
        and evaluation.completeness_ratio == 1.0,
        "policy_not_passed": evaluation.policy_pass,
        "tests_not_passed": evaluation.tests_pass,
        "restore_not_passed": evaluation.restore_pass,
        "public_safety_not_passed": evaluation.public_safe,
        "owner_acceptance_missing": evaluation.owner_accept,
        "privacy_classification_stale": evaluation.privacy_classification_current,
        "blocking_conflict_present": evaluation.conflict_free,
        "permission_stale_or_revoked": evaluation.permission_current,
        "environment_changed": evaluation.environment_current,
    }


def _valid_action_reservation_receipt(receipt: object) -> bool:
    if type(receipt) is not ActionReservationReceipt:
        return False
    if not all(_nonempty_text(value) for value in (
        receipt.reservation_id, receipt.release_action_id, receipt.evaluation_id,
        receipt.evaluated_at, receipt.reserved_at,
    )):
        return False
    if not _valid_release_binding(receipt.binding):
        return False
    if receipt.release_action_id != receipt.binding.release_action_id:
        return False
    if _aware_datetime(receipt.evaluated_at) is None:
        return False
    if _aware_datetime(receipt.reserved_at) is None:
        return False
    if receipt.evaluated_at != receipt.reserved_at:
        return False
    return _strict_true(receipt.present)


class ReleaseActionLedger:
    """Atomic reservation and first-effect-attempt store for release actions."""

    def __init__(self) -> None:
        self._lock = Lock()
        self._reservations: dict[str, ActionReservationReceipt] = {}
        self._evaluation_ids: set[str] = set()
        self._attempted_release_action_ids: set[str] = set()

    @staticmethod
    def _matches(
        stored: object,
        receipt: object,
        evaluation: object | None = None,
    ) -> bool:
        if not _valid_action_reservation_receipt(stored):
            return False
        if not _valid_action_reservation_receipt(receipt):
            return False
        if not all((
            stored.reservation_id == receipt.reservation_id,
            stored.release_action_id == receipt.release_action_id,
            _same_release_binding(stored.binding, receipt.binding),
            stored.evaluation_id == receipt.evaluation_id,
            stored.evaluated_at == receipt.evaluated_at,
            stored.reserved_at == receipt.reserved_at,
        )):
            return False
        if evaluation is None:
            return True
        if type(evaluation) is not PreEffectEvaluation:
            return False
        if not _nonempty_text(evaluation.evaluation_id):
            return False
        if _aware_datetime(evaluation.evaluated_at) is None:
            return False
        if not _valid_release_binding(evaluation.binding):
            return False
        return all((
            receipt.evaluation_id == evaluation.evaluation_id,
            receipt.evaluated_at == evaluation.evaluated_at,
            _same_release_binding(receipt.binding, evaluation.binding),
        ))

    def evaluate_and_reserve(
        self,
        *,
        evaluation_id: str,
        authorized_binding: ReleaseBinding,
        current_binding: ReleaseBinding,
        current_state: LifecycleState,
        owner_authorized: bool,
        defensive_purpose: bool,
        owned_or_authorized_target: bool,
        owner_scope_approved: bool,
        least_privilege: bool,
        all_safety_gates_pass: bool,
        present_artifacts_valid: bool,
        completeness_ratio: float,
        policy_pass: bool,
        tests_pass: bool,
        restore_pass: bool,
        public_safe: bool,
        owner_accept: bool,
        privacy_classification_current: bool,
        conflict_free: bool,
        permission_current: bool,
        environment_current: bool,
    ) -> tuple[GateResult, PreEffectEvaluation | None]:
        if self is not TRUSTED_RELEASE_ACTION_LEDGER:
            return GateResult(False, ("trusted_release_action_ledger_required",)), None
        now = datetime.now().astimezone()
        evaluated_at = now.isoformat()
        provisional_reservation = ActionReservationReceipt(
            reservation_id="pending",
            release_action_id=authorized_binding.release_action_id
            if type(authorized_binding) is ReleaseBinding
            else "",
            binding=authorized_binding,
            evaluation_id=evaluation_id,
            evaluated_at=evaluated_at,
            reserved_at=evaluated_at,
            present=True,
        )
        evaluation = PreEffectEvaluation(
            evaluation_id=evaluation_id,
            evaluated_at=evaluated_at,
            binding=authorized_binding,
            current_state=current_state,
            owner_authorized=owner_authorized,
            defensive_purpose=defensive_purpose,
            owned_or_authorized_target=owned_or_authorized_target,
            owner_scope_approved=owner_scope_approved,
            least_privilege=least_privilege,
            all_safety_gates_pass=all_safety_gates_pass,
            present_artifacts_valid=present_artifacts_valid,
            completeness_ratio=completeness_ratio,
            policy_pass=policy_pass,
            tests_pass=tests_pass,
            restore_pass=restore_pass,
            public_safe=public_safe,
            owner_accept=owner_accept,
            privacy_classification_current=privacy_classification_current,
            conflict_free=conflict_free,
            permission_current=permission_current,
            environment_current=environment_current,
            reservation_receipt=provisional_reservation,
        )
        reasons = [
            name for name, passed in _pre_effect_checks(evaluation).items()
            if not _strict_true(passed)
        ]
        if not _nonempty_text(evaluation_id):
            reasons.append("pre_effect_evaluation_id_invalid")
        if not _valid_release_binding(authorized_binding):
            reasons.append("authorized_release_binding_invalid")
        if not _valid_release_binding(current_binding):
            reasons.append("current_release_binding_invalid")
        if not _same_release_binding(authorized_binding, current_binding):
            reasons.append("release_binding_changed")
        if _valid_release_binding(authorized_binding):
            direction = _aware_datetime(authorized_binding.direction_time_et)
            expiry = _aware_datetime(authorized_binding.expires_time_et)
            if direction is None or expiry is None or not (direction <= now <= expiry):
                reasons.append("pre_effect_time_outside_direction_window")
        if reasons:
            return GateResult(False, tuple(dict.fromkeys(reasons))), None

        with self._lock:
            if authorized_binding.release_action_id in self._reservations:
                return GateResult(False, ("release_action_already_reserved",)), None
            if evaluation_id in self._evaluation_ids:
                return GateResult(
                    False, ("pre_effect_evaluation_id_already_used",)
                ), None
            reservation = ActionReservationReceipt(
                reservation_id=f"reservation-{uuid4()}",
                release_action_id=authorized_binding.release_action_id,
                binding=authorized_binding,
                evaluation_id=evaluation_id,
                evaluated_at=evaluated_at,
                reserved_at=evaluated_at,
                present=True,
            )
            self._reservations[authorized_binding.release_action_id] = reservation
            self._evaluation_ids.add(evaluation_id)
        return GateResult(True, ()), dataclass_replace(
            evaluation, reservation_receipt=reservation
        )

    def verifies(
        self, receipt: object, evaluation: PreEffectEvaluation | None = None
    ) -> bool:
        if self is not TRUSTED_RELEASE_ACTION_LEDGER:
            return False
        if not _valid_action_reservation_receipt(receipt):
            return False
        release_action_id = receipt.release_action_id
        with self._lock:
            stored = self._reservations.get(release_action_id)
            return self._matches(stored, receipt, evaluation)

    def claim_effect_attempt(self, evaluation: object) -> str | None:
        """Atomically consume the first post-effect verification attempt."""
        if self is not TRUSTED_RELEASE_ACTION_LEDGER:
            return "action_reservation_missing_or_invalid"
        if type(evaluation) is not PreEffectEvaluation:
            return "action_reservation_missing_or_invalid"
        receipt = evaluation.reservation_receipt
        if not _valid_action_reservation_receipt(receipt):
            return "action_reservation_missing_or_invalid"
        release_action_id = receipt.release_action_id
        with self._lock:
            stored = self._reservations.get(release_action_id)
            if not self._matches(stored, receipt, evaluation):
                return "action_reservation_missing_or_invalid"
            if release_action_id in self._attempted_release_action_ids:
                return "release_effect_attempt_already_consumed"
            self._attempted_release_action_ids.add(release_action_id)
        return None


# One process-wide policy-kernel ledger enforces action and evaluation identity
# uniqueness. Caller-created ledger instances cannot reserve or verify actions.
TRUSTED_RELEASE_ACTION_LEDGER = ReleaseActionLedger()


def actual_release_gate(
    *,
    current_binding: ReleaseBinding,
    pre_effect_evaluation: PreEffectEvaluation,
    action_ledger: ReleaseActionLedger,
    effect_receipt: ReleaseEffectReceipt | None,
    outcome_receipt: ReleaseOutcomeReceipt | None,
) -> GateResult:
    """Verify a simulated post-effect record; this performs no release."""
    if type(pre_effect_evaluation) is not PreEffectEvaluation:
        return GateResult(False, ("pre_effect_evaluation_missing_or_invalid",))
    evaluation = pre_effect_evaluation
    reasons = [
        name for name, passed in _pre_effect_checks(evaluation).items()
        if not _strict_true(passed)
    ]
    if action_ledger is not TRUSTED_RELEASE_ACTION_LEDGER:
        reasons.append("trusted_release_action_ledger_missing")
    else:
        claim_reason = action_ledger.claim_effect_attempt(evaluation)
        if claim_reason is not None:
            reasons.append(claim_reason)
    if not _valid_release_binding(evaluation.binding):
        reasons.append("authorized_release_binding_invalid")
    if not _valid_release_binding(current_binding):
        reasons.append("current_release_binding_invalid")
    if not _same_release_binding(evaluation.binding, current_binding):
        reasons.append("release_binding_changed")
    if not _valid_release_binding(evaluation.binding) or not _valid_release_binding(
        current_binding
    ):
        return GateResult(False, tuple(dict.fromkeys(reasons)))

    evaluation_time = _aware_datetime(evaluation.evaluated_at)
    decision_now = datetime.now().astimezone()
    direction = _aware_datetime(evaluation.binding.direction_time_et)
    expiry = _aware_datetime(evaluation.binding.expires_time_et)
    if (
        not _nonempty_text(evaluation.evaluation_id)
        or evaluation_time is None
        or direction is None
        or expiry is None
        or not (direction <= evaluation_time <= expiry)
        or evaluation_time > decision_now
    ):
        reasons.append("pre_effect_evaluation_time_invalid")

    effect_time: datetime | None = None
    if type(effect_receipt) is not ReleaseEffectReceipt:
        reasons.append("effect_receipt_missing_or_invalid")
    else:
        effect_text_valid = all(_nonempty_text(value) for value in (
            effect_receipt.receipt_id,
            effect_receipt.pre_effect_evaluation_id,
            effect_receipt.pre_effect_time_et,
            effect_receipt.action,
            effect_receipt.effect_time_et,
            effect_receipt.observed_result,
        ))
        if not effect_text_valid:
            reasons.append("effect_receipt_field_type_invalid")
        else:
            if not _same_release_binding(effect_receipt.binding, evaluation.binding):
                reasons.append("effect_receipt_binding_mismatch")
            if effect_receipt.pre_effect_evaluation_id != evaluation.evaluation_id:
                reasons.append("effect_receipt_evaluation_id_mismatch")
            if effect_receipt.pre_effect_time_et != evaluation.evaluated_at:
                reasons.append("effect_receipt_evaluation_time_mismatch")
            if effect_receipt.action != evaluation.binding.authorized_action:
                reasons.append("effect_receipt_action_mismatch")
            effect_time = _aware_datetime(effect_receipt.effect_time_et)
            if effect_time is None:
                reasons.append("effect_time_invalid")
            if effect_receipt.observed_result != evaluation.binding.expected_outcome:
                reasons.append("effect_observed_result_mismatch")
        if not _strict_true(effect_receipt.authorized_effect):
            reasons.append("authorized_effect_missing")
        if not _strict_true(effect_receipt.effect_completed):
            reasons.append("effect_not_completed")
        if effect_receipt.error_code is not None:
            reasons.append("effect_error_present")
        if not _strict_true(effect_receipt.receipt_present):
            reasons.append("effect_receipt_missing")
        if evaluation_time is not None and effect_time is not None and expiry is not None:
            elapsed = (effect_time - evaluation_time).total_seconds()
            if (effect_time < evaluation_time or effect_time > expiry
                    or effect_time > decision_now
                    or elapsed > evaluation.binding.max_effect_delay_seconds):
                reasons.append("effect_time_outside_authorized_window")

    if type(outcome_receipt) is not ReleaseOutcomeReceipt:
        reasons.append("outcome_receipt_missing_or_invalid")
    else:
        outcome_text_valid = all(_nonempty_text(value) for value in (
            outcome_receipt.receipt_id,
            outcome_receipt.pre_effect_evaluation_id,
            outcome_receipt.pre_effect_time_et,
            outcome_receipt.action,
            outcome_receipt.effect_receipt_id,
            outcome_receipt.effect_time_et,
            outcome_receipt.observed_at_et,
            outcome_receipt.observed_outcome,
            outcome_receipt.observed_visibility,
            outcome_receipt.observed_retrieval,
        ))
        if not outcome_text_valid:
            reasons.append("outcome_receipt_field_type_invalid")
        else:
            if not _same_release_binding(outcome_receipt.binding, evaluation.binding):
                reasons.append("outcome_receipt_binding_mismatch")
            if outcome_receipt.pre_effect_evaluation_id != evaluation.evaluation_id:
                reasons.append("outcome_receipt_evaluation_id_mismatch")
            if outcome_receipt.pre_effect_time_et != evaluation.evaluated_at:
                reasons.append("outcome_receipt_evaluation_time_mismatch")
            if outcome_receipt.action != evaluation.binding.authorized_action:
                reasons.append("outcome_receipt_action_mismatch")
            if type(effect_receipt) is not ReleaseEffectReceipt or not _nonempty_text(
                effect_receipt.receipt_id
            ) or outcome_receipt.effect_receipt_id != effect_receipt.receipt_id:
                reasons.append("outcome_effect_receipt_mismatch")
            if type(effect_receipt) is ReleaseEffectReceipt and _nonempty_text(
                effect_receipt.effect_time_et
            ) and outcome_receipt.effect_time_et != effect_receipt.effect_time_et:
                reasons.append("outcome_effect_time_mismatch")
            observed = _aware_datetime(outcome_receipt.observed_at_et)
            if (observed is None or (effect_time is not None and observed < effect_time)
                    or observed is not None and observed > decision_now):
                reasons.append("outcome_observation_time_invalid")
            if outcome_receipt.observed_outcome != evaluation.binding.expected_outcome:
                reasons.append("observed_outcome_mismatch")
            if outcome_receipt.observed_visibility != evaluation.binding.expected_visibility:
                reasons.append("observed_visibility_mismatch")
            if outcome_receipt.observed_retrieval != evaluation.binding.expected_retrieval:
                reasons.append("observed_retrieval_mismatch")
        if not _strict_true(outcome_receipt.outcome_check_pass):
            reasons.append("outcome_check_missing")
        if not _strict_true(outcome_receipt.visibility_retrieval_check_pass):
            reasons.append("visibility_retrieval_check_missing")
        if not _strict_true(outcome_receipt.receipt_present):
            reasons.append("outcome_receipt_missing")
    return GateResult(allowed=not reasons, reasons=tuple(dict.fromkeys(reasons)))


PROTECTED_EXCLUSION_CODES: Mapping[PrivacyClass, str] = {
    PrivacyClass.PROJECT_RESTRICTED: "EXCLUDED_PROJECT_RESTRICTED",
    PrivacyClass.PRIVATE: "EXCLUDED_PRIVATE",
    PrivacyClass.QUARANTINED: "EXCLUDED_QUARANTINED",
    PrivacyClass.SUPERSEDED: "EXCLUDED_SUPERSEDED",
}
PUBLIC_SAFETY_EXCLUSION_CODE = "EXCLUDED_PUBLIC_SAFETY_NOT_PASSED"
UNCLASSIFIED_EXCLUSION_CODE = "EXCLUDED_UNCLASSIFIED"
PROJECTION_REVIEW_METHOD_V1 = "CANONICAL_ALLOWLIST_LITERAL_BYTE_REVIEW_V1"
PROJECTION_RULE_SET_V1 = "QEL_PUBLIC_PROJECTION_RULES_V1"
PUBLIC_PRIVACY_REVIEW_SCOPE_V1 = "PUBLIC_PROJECTION_PRIVACY_FULL_BYTES_V1"
PUBLIC_SECRET_SCAN_SCOPE_V1 = "PUBLIC_PROJECTION_SECRET_SCAN_FULL_BYTES_V1"
QUARANTINE_PRIVACY_REVIEW_SCOPE_V1 = "QUARANTINE_RECLASSIFICATION_PRIVACY_FULL_BYTES_V1"
QUARANTINE_SECRET_SCAN_SCOPE_V1 = "QUARANTINE_RECLASSIFICATION_SECRET_FULL_BYTES_V1"
PROJECTION_RECEIPT_FIELDS = frozenset(
    {"receipt_id", "review_type", "destination", "projection_version",
     "artifact_id", "artifact_version", "exact_projection_bytes", "method",
     "rule_set_version", "reviewed_fields", "review_scope", "reviewed_at",
     "expires_at", "pass"}
)


def projection_candidate_for_review(record: RoleRecord) -> dict[str, object]:
    """Build the one allowlisted object whose exact bytes may be reviewed."""
    if type(record) is not RoleRecord or type(record.privacy_class) is not PrivacyClass:
        return {"included": False, "exclusion_code": UNCLASSIFIED_EXCLUSION_CODE}
    if record.privacy_class in PROTECTED_EXCLUSION_CODES:
        return {"included": False,
                "exclusion_code": PROTECTED_EXCLUSION_CODES[record.privacy_class]}
    valid_common = all(
        (_nonempty_text(record.record_id), type(record.workstream) is Workstream,
         _nonempty_text(record.source_role),
         _aware_datetime(record.event_time_et) is not None,
         type(record.evidence_state) is EvidenceState,
         type(record.custody_state) is CustodyState,
         type(record.capability_state) is CapabilityState)
    )
    if not valid_common:
        return {"included": False, "exclusion_code": UNCLASSIFIED_EXCLUSION_CODE}
    status: dict[str, object] = {
        "record_id": record.record_id,
        "workstream": record.workstream.value,
        "source_role": record.source_role,
        "event_time_et": record.event_time_et,
        "evidence_state": record.evidence_state.value,
        "custody_state": record.custody_state.value,
        "privacy_state": record.privacy_class.value,
        "capability_state": record.capability_state.value,
        "publication_route": route_for_publication(record),
    }
    if record.privacy_class is PrivacyClass.PUBLIC:
        if not _valid_text(record.statement):
            return {"included": False, "exclusion_code": UNCLASSIFIED_EXCLUSION_CODE}
        return {**status, "statement": record.statement}
    if record.privacy_class is PrivacyClass.PUBLIC_REDACTED:
        if record.public_summary is not None and not _valid_text(record.public_summary):
            return {"included": False, "exclusion_code": UNCLASSIFIED_EXCLUSION_CODE}
        return {**status, "public_summary": record.public_summary
                or "[REDACTED: public summary unavailable]"}
    return {"included": False, "exclusion_code": UNCLASSIFIED_EXCLUSION_CODE}


def projection_bytes_for_review(record: RoleRecord) -> bytes:
    return canonical_json_bytes(projection_candidate_for_review(record))


def _valid_projection_receipt(
    receipt: object, *, expected_type: str, candidate_bytes: bytes,
    expected_fields: tuple[str, ...], destination: str, projection_version: str,
    artifact_id: str, artifact_version: str, decision_time: datetime,
    expected_scope: str, not_before: datetime | None = None,
) -> bool:
    if not all(
        _nonempty_text(value)
        for value in (destination, projection_version, artifact_id, artifact_version)
    ):
        return False
    if type(receipt) is not dict:
        return False
    if not all(type(key) is str for key in receipt):
        return False
    if set(receipt) != PROJECTION_RECEIPT_FIELDS:
        return False
    if type(receipt["reviewed_fields"]) is not list or not receipt["reviewed_fields"]:
        return False
    if not all(_nonempty_text(field) for field in receipt["reviewed_fields"]):
        return False
    if type(receipt["exact_projection_bytes"]) is not bytes:
        return False
    if receipt["exact_projection_bytes"] != candidate_bytes:
        return False
    exact_text_bindings = (
        (receipt["review_type"], expected_type),
        (receipt["destination"], destination),
        (receipt["projection_version"], projection_version),
        (receipt["artifact_id"], artifact_id),
        (receipt["artifact_version"], artifact_version),
        (receipt["method"], PROJECTION_REVIEW_METHOD_V1),
        (receipt["rule_set_version"], PROJECTION_RULE_SET_V1),
        (receipt["review_scope"], expected_scope),
    )
    if not all(type(value) is str and value == expected for value, expected in exact_text_bindings):
        return False
    reviewed = _aware_datetime(receipt["reviewed_at"])
    expiry = _aware_datetime(receipt["expires_at"])
    return all(
        (_nonempty_text(receipt["receipt_id"]), _strict_true(receipt["pass"]),
         _nonempty_text(destination), _nonempty_text(projection_version),
         _nonempty_text(artifact_id), _nonempty_text(artifact_version),
         tuple(receipt["reviewed_fields"]) == expected_fields,
         reviewed is not None, expiry is not None,
         reviewed is not None and expiry is not None
         and reviewed <= decision_time <= expiry,
         not_before is None or reviewed is not None and reviewed >= not_before)
    )


def record_to_public_bytes(
    record: RoleRecord, *, destination: str, projection_version: str,
    artifact_id: str, artifact_version: str,
    privacy_review_receipt: ProjectionGateReceipt | None,
    secret_scan_receipt: ProjectionGateReceipt | None,
) -> bytes:
    """Return exact reviewed canonical bytes, or a fixed denial object."""
    candidate = projection_candidate_for_review(record)
    candidate_bytes = canonical_json_bytes(candidate)
    if type(record) is not RoleRecord or type(record.privacy_class) is not PrivacyClass:
        return canonical_json_bytes(
            {"included": False, "exclusion_code": UNCLASSIFIED_EXCLUSION_CODE}
        )
    if record.privacy_class not in {PrivacyClass.PUBLIC, PrivacyClass.PUBLIC_REDACTED}:
        return candidate_bytes
    decision_time = datetime.now().astimezone()
    expected_fields = tuple(sorted(candidate))
    valid = _valid_projection_receipt(
        privacy_review_receipt, expected_type="PRIVACY_REVIEW",
        candidate_bytes=candidate_bytes, destination=destination,
        expected_fields=expected_fields,
        projection_version=projection_version, artifact_id=artifact_id,
        artifact_version=artifact_version, decision_time=decision_time,
        expected_scope=PUBLIC_PRIVACY_REVIEW_SCOPE_V1,
    ) and _valid_projection_receipt(
        secret_scan_receipt, expected_type="SECRET_SCAN",
        candidate_bytes=candidate_bytes, destination=destination,
        expected_fields=expected_fields,
        projection_version=projection_version, artifact_id=artifact_id,
        artifact_version=artifact_version, decision_time=decision_time,
        expected_scope=PUBLIC_SECRET_SCAN_SCOPE_V1,
    )
    if valid and (
        privacy_review_receipt["receipt_id"] == secret_scan_receipt["receipt_id"]
    ):
        valid = False
    if not valid:
        return canonical_json_bytes(
            {"included": False, "exclusion_code": PUBLIC_SAFETY_EXCLUSION_CODE}
        )
    return candidate_bytes


def current_public_status() -> dict[str, object]:
    return {
        "project": "Quantum.Earth.Laing",
        "author_root_source": "Sherman Gaucia Laing",
        "governance_designation": "SGL Prime",
        "sgl_prime_cryptographic_status": "NOT_APPLICABLE_GOVERNANCE_ONLY",
        "alpha_date_status": "UNRESOLVED_2026-08-22_OR_2026-08-23_AT_00:25_ET",
        "omega_effective_et": "2026-08-23T23:44:00-04:00",
        "phase_iii_state": "OWNER_RATIFICATION_PENDING",
        "physical_qpu_claim": False,
        "production_safe_browser_claim": False,
        "autonomous_runtime_claim": False,
        "release_state": "HOLD",
    }


if __name__ == "__main__":
    print(canonical_json(current_public_status()))
