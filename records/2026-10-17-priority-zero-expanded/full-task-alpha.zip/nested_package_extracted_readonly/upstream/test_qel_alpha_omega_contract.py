import json
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, replace
from datetime import datetime, timedelta
from uuid import uuid4

from qel_alpha_omega_contract import (
    ALLOWED_TRANSITIONS,
    AUTHORIZED_CONTROL_CUSTODY_DESTINATIONS,
    CONTROL_INBOUND_SOURCES,
    PROJECTION_RECEIPT_FIELDS,
    PROJECTION_REVIEW_METHOD_V1,
    PROJECTION_RULE_SET_V1,
    PUBLIC_PRIVACY_REVIEW_SCOPE_V1,
    PUBLIC_SECRET_SCAN_SCOPE_V1,
    QUARANTINE_PRIVACY_REVIEW_SCOPE_V1,
    QUARANTINE_SECRET_SCAN_SCOPE_V1,
    CapabilityState,
    ActionReservationReceipt,
    ClassificationRecord,
    ControlEntryRecord,
    ControlObservationRecord,
    CustodyState,
    EvidenceState,
    LifecycleLedger,
    LifecycleState,
    OwnerActionReceipt,
    PrivacyClass,
    RecoveryEvidence,
    ReleaseActionLedger,
    ReleaseBinding,
    ReleaseEffectReceipt,
    ReleaseOutcomeReceipt,
    RevisionEntryRecord,
    ResolutionReceipt,
    RoleRecord,
    StoredLifecycleSnapshot,
    TRUSTED_LIFECYCLE_LEDGER,
    TRUSTED_RELEASE_ACTION_LEDGER,
    Workstream,
    actual_release_gate,
    canonical_json,
    canonical_json_bytes,
    completeness,
    defense_only_gate,
    integrity,
    merge_shared_core,
    projection_bytes_for_review,
    projection_candidate_for_review,
    record_to_public_bytes,
    release_gate,
    role_can,
    route_for_publication,
    transition_gate,
)


ARTIFACT_ID = "QEL-PHASE-III-PUBLIC-SPEC"
ARTIFACT_VERSION = "20260825T132200ET-V1"
DESTINATION = "public-record-destination"
PROJECTION_VERSION = "public-projection-v1"


def now_et() -> datetime:
    return datetime.now().astimezone()


def record(
    record_id: str,
    *,
    privacy: PrivacyClass = PrivacyClass.PUBLIC,
    evidence: EvidenceState = EvidenceState.VERIFIED,
    custody: CustodyState = CustodyState.PRESENT,
    eligible: bool = True,
    conflict_id: str | None = None,
) -> RoleRecord:
    return RoleRecord(
        record_id=record_id,
        workstream=Workstream.ALPHA,
        source_role="GAUCIA",
        event_time_et=now_et().isoformat(),
        statement="bounded public test record",
        evidence_state=evidence,
        custody_state=custody,
        privacy_class=privacy,
        capability_state=CapabilityState.TESTED,
        task_authorized=eligible,
        source_scope_preserved=eligible,
        defense_gate_passed=eligible,
        tests_pass=eligible,
        merge_receipt_present=eligible,
        conflict_id=conflict_id,
    )


def projection_receipt(
    *,
    receipt_id: str,
    review_type: str,
    exact_bytes: bytes,
    fields: tuple[str, ...],
    scope: str,
    destination: str = DESTINATION,
    projection_version: str = PROJECTION_VERSION,
    artifact_id: str = ARTIFACT_ID,
    artifact_version: str = ARTIFACT_VERSION,
) -> dict[str, object]:
    current = now_et()
    return {
        "receipt_id": receipt_id,
        "review_type": review_type,
        "destination": destination,
        "projection_version": projection_version,
        "artifact_id": artifact_id,
        "artifact_version": artifact_version,
        "exact_projection_bytes": exact_bytes,
        "method": PROJECTION_REVIEW_METHOD_V1,
        "rule_set_version": PROJECTION_RULE_SET_V1,
        "reviewed_fields": list(fields),
        "review_scope": scope,
        "reviewed_at": current.isoformat(),
        "expires_at": (current + timedelta(minutes=5)).isoformat(),
        "pass": True,
    }


def projection_receipts(candidate: RoleRecord) -> tuple[dict[str, object], dict[str, object]]:
    exact_bytes = projection_bytes_for_review(candidate)
    fields = tuple(sorted(projection_candidate_for_review(candidate)))
    return (
        projection_receipt(
            receipt_id="privacy-receipt-1", review_type="PRIVACY_REVIEW",
            exact_bytes=exact_bytes, fields=fields,
            scope=PUBLIC_PRIVACY_REVIEW_SCOPE_V1,
        ),
        projection_receipt(
            receipt_id="scan-receipt-1", review_type="SECRET_SCAN",
            exact_bytes=exact_bytes, fields=fields,
            scope=PUBLIC_SECRET_SCAN_SCOPE_V1,
        ),
    )


def public_bytes(
    candidate: RoleRecord,
    privacy_receipt: dict[str, object] | None,
    scan_receipt: dict[str, object] | None,
    **overrides: object,
) -> bytes:
    values: dict[str, object] = {
        "destination": DESTINATION,
        "projection_version": PROJECTION_VERSION,
        "artifact_id": ARTIFACT_ID,
        "artifact_version": ARTIFACT_VERSION,
        "privacy_review_receipt": privacy_receipt,
        "secret_scan_receipt": scan_receipt,
    }
    values.update(overrides)
    return record_to_public_bytes(candidate, **values)  # type: ignore[arg-type]


CONTROL_REASONS = {
    LifecycleState.PAUSED: "CONTROL_PAUSE",
    LifecycleState.BLOCKED: "CONTROL_BLOCK",
    LifecycleState.CONFLICT: "CONTROL_CONFLICT",
    LifecycleState.QUARANTINED: "CONTROL_QUARANTINE",
}


def control_entry(
    current: LifecycleState,
    proposed: LifecycleState,
    **overrides: object,
) -> ControlEntryRecord:
    values: dict[str, object] = {
        "exception_state": proposed,
        "prior_state": current,
        "prior_snapshot_id": f"snapshot-{current.value.lower()}",
        "affected_scope": "phase-iii-public-spec",
        "trigger_evidence_ids": ("trigger-evidence-1",),
        "reason_code": CONTROL_REASONS[proposed],
        "custody_destination": "controlled-review-custody",
        "recorded_at": now_et().isoformat(),
        "recorder_role": "LEVIATHAN",
        "receipt_id": f"{proposed.value.lower()}-entry-receipt-{uuid4()}",
        "no_advancement": True,
    }
    values.update(overrides)
    return ControlEntryRecord(**values)  # type: ignore[arg-type]


def revision_entry(
    current: LifecycleState,
    **overrides: object,
) -> RevisionEntryRecord:
    values: dict[str, object] = {
        "exception_state": LifecycleState.REVISE,
        "prior_state": current,
        "prior_snapshot_id": f"snapshot-{current.value.lower()}",
        "affected_scope": "phase-iii-public-spec",
        "owner_direction_receipt_id": "owner-revision-direction-receipt",
        "recorded_at": now_et().isoformat(),
        "recorder_role": "GAUCIA",
        "receipt_id": f"revise-entry-receipt-{uuid4()}",
        "no_advancement": True,
    }
    values.update(overrides)
    return RevisionEntryRecord(**values)  # type: ignore[arg-type]


def snapshot_for_entry(
    entry: ControlEntryRecord | RevisionEntryRecord,
    **overrides: object,
) -> StoredLifecycleSnapshot:
    values: dict[str, object] = {
        "store_receipt_id": f"store-{entry.receipt_id}-{uuid4()}",
        "current_state": entry.exception_state,
        "preserved_entry_record": entry,
        "checkpoint_id": entry.prior_snapshot_id,
        "checkpoint_state": entry.prior_state,
        "checkpoint_artifact_id": ARTIFACT_ID,
        "checkpoint_artifact_version": ARTIFACT_VERSION,
        "current_artifact_id": ARTIFACT_ID,
        "current_artifact_version": ARTIFACT_VERSION,
        "entry_receipt_present": True,
        "checkpoint_verified": True,
        "stored_at": now_et().isoformat(),
    }
    values.update(overrides)
    return StoredLifecycleSnapshot(**values)  # type: ignore[arg-type]


def stored_context(
    entry: ControlEntryRecord | RevisionEntryRecord,
    **overrides: object,
) -> tuple[LifecycleLedger, StoredLifecycleSnapshot]:
    snapshot = snapshot_for_entry(entry, **overrides)
    ledger = TRUSTED_LIFECYCLE_LEDGER
    if type(entry) is ControlEntryRecord:
        entered = transition_gate(
            entry.prior_state, entry.exception_state,
            required_evidence=(), present_evidence={entry.receipt_id},
            tests_pass=False, policy_pass=False, control_record=entry,
            entry_snapshot=snapshot, lifecycle_ledger=ledger,
        )
    else:
        entered = transition_gate(
            entry.prior_state, entry.exception_state,
            required_evidence=(),
            present_evidence={entry.receipt_id, entry.owner_direction_receipt_id},
            tests_pass=False, policy_pass=False, owner_action=True,
            revision_record=entry, entry_snapshot=snapshot,
            lifecycle_ledger=ledger,
        )
    assert entered.allowed, entered.reasons
    return ledger, snapshot


def owner_action(
    entry: ControlEntryRecord | RevisionEntryRecord,
    action: str,
    **overrides: object,
) -> OwnerActionReceipt:
    current = now_et()
    values: dict[str, object] = {
        "receipt_id": f"owner-{action.lower()}-receipt",
        "action": action,
        "artifact_id": ARTIFACT_ID,
        "artifact_version": ARTIFACT_VERSION,
        "affected_scope": entry.affected_scope,
        "issued_at": current.isoformat(),
        "expires_at": (current + timedelta(minutes=5)).isoformat(),
        "present": True,
    }
    values.update(overrides)
    return OwnerActionReceipt(**values)  # type: ignore[arg-type]


def recovery_bundle(
    entry: ControlEntryRecord | RevisionEntryRecord,
    *,
    resume_state: LifecycleState | None = None,
    evidence_overrides: dict[str, object] | None = None,
    snapshot_overrides: dict[str, object] | None = None,
) -> tuple[LifecycleLedger, RecoveryEvidence, set[str]]:
    ledger, snapshot = stored_context(entry, **(snapshot_overrides or {}))
    current = entry.exception_state
    resume = resume_state or (
        LifecycleState.CLASSIFIED
        if current is LifecycleState.QUARANTINED
        else entry.prior_state
    )
    resolution_type = {
        LifecycleState.PAUSED: "OWNER_RESUME",
        LifecycleState.BLOCKED: "BLOCK_RESOLUTION",
        LifecycleState.CONFLICT: "CONFLICT_DISPOSITION",
        LifecycleState.REVISE: "REVISION_COMPLETE",
        LifecycleState.QUARANTINED: "QUARANTINE_RELEASE",
    }[current]
    owner = None
    if current in {LifecycleState.PAUSED, LifecycleState.CONFLICT,
                   LifecycleState.REVISE, LifecycleState.QUARANTINED}:
        action = {
            LifecycleState.PAUSED: "RESUME",
            LifecycleState.CONFLICT: "RESOLVE_CONFLICT",
            LifecycleState.REVISE: "ACCEPT_REVISION",
            LifecycleState.QUARANTINED: "RELEASE_QUARANTINE_TO_CLASSIFICATION",
        }[current]
        owner = owner_action(entry, action)
    resolution = ResolutionReceipt(
        receipt_id=f"{current.value.lower()}-resolution-receipt",
        resolution_type=resolution_type,
        entry_receipt_id=entry.receipt_id,
        checkpoint_id=snapshot.checkpoint_id,
        affected_scope=entry.affected_scope,
        artifact_id=snapshot.current_artifact_id,
        artifact_version=snapshot.current_artifact_version,
        resume_state=resume,
        issued_at=now_et().isoformat(),
        owner_action_receipt_id=owner.receipt_id if owner else "",
        present=True,
    )
    classification = None
    privacy = None
    scan = None
    if current is LifecycleState.QUARANTINED:
        exact_bytes = b'{"artifact_projection":"reclassified"}'
        classification = ClassificationRecord(
            record_id="fresh-classification-record",
            artifact_id=snapshot.current_artifact_id,
            artifact_version=snapshot.current_artifact_version,
            exact_projection_bytes=exact_bytes,
            destination=DESTINATION,
            projection_version=PROJECTION_VERSION,
            classification="RECLASSIFIED_FOR_REVIEW",
            classified_at=now_et().isoformat(),
            present=True,
        )
        privacy = projection_receipt(
            receipt_id="quarantine-privacy-receipt", review_type="PRIVACY_REVIEW",
            exact_bytes=exact_bytes, fields=("artifact_projection",),
            scope=QUARANTINE_PRIVACY_REVIEW_SCOPE_V1,
        )
        scan = projection_receipt(
            receipt_id="quarantine-scan-receipt", review_type="SECRET_SCAN",
            exact_bytes=exact_bytes, fields=("artifact_projection",),
            scope=QUARANTINE_SECRET_SCAN_SCOPE_V1,
        )
    values: dict[str, object] = {
        "preserved_entry_record": entry,
        "store_receipt_id": snapshot.store_receipt_id,
        "checkpoint_id": snapshot.checkpoint_id,
        "checkpoint_state": snapshot.checkpoint_state,
        "checkpoint_artifact_id": snapshot.checkpoint_artifact_id,
        "checkpoint_artifact_version": snapshot.checkpoint_artifact_version,
        "current_artifact_id": snapshot.current_artifact_id,
        "current_artifact_version": snapshot.current_artifact_version,
        "resume_state": resume,
        "resolution_type": resolution_type,
        "resolution_receipt": resolution,
        "tests_pass": True,
        "policy_pass": True,
        "owner_action_receipt": owner,
        "classification_record": classification,
        "privacy_review_receipt": privacy,
        "secret_scan_receipt": scan,
    }
    values.update(evidence_overrides or {})
    evidence = RecoveryEvidence(**values)  # type: ignore[arg-type]
    present = {resolution.receipt_id}
    if owner:
        present.add(owner.receipt_id)
    if classification:
        present.add(classification.record_id)
    if privacy:
        present.add(str(privacy["receipt_id"]))
    if scan:
        present.add(str(scan["receipt_id"]))
    return ledger, evidence, present


def release_binding(**overrides: object) -> ReleaseBinding:
    current = now_et()
    values: dict[str, object] = {
        "artifact_id": ARTIFACT_ID,
        "artifact_version": ARTIFACT_VERSION,
        "artifact_manifest": b'{"files":["public-spec.pdf"]}',
        "destination": DESTINATION,
        "target": "owned-public-record-object",
        "privacy_projection_version": PROJECTION_VERSION,
        "conflict_snapshot_id": "conflict-snapshot-clear-1",
        "permission_scope_id": "owner-release-scope-1",
        "test_set_id": "phase-iii-test-set-1",
        "restore_receipt_id": "restore-test-receipt-1",
        "environment_id": "simulated-public-record-environment-1",
        "release_action_id": f"single-use-release-action-{uuid4()}",
        "authorized_action": "publish-public-checkpoint",
        "expected_outcome": "public-checkpoint-visible",
        "expected_visibility": "public",
        "expected_retrieval": "retrievable",
        "direction_time_et": (current - timedelta(minutes=5)).isoformat(),
        "expires_time_et": (current + timedelta(minutes=5)).isoformat(),
        "max_effect_delay_seconds": 120,
    }
    values.update(overrides)
    return ReleaseBinding(**values)  # type: ignore[arg-type]


def reserve_release(
    *,
    binding: ReleaseBinding | None = None,
    current_binding: ReleaseBinding | None = None,
    ledger: ReleaseActionLedger | None = None,
    **overrides: object,
):
    authorized = binding or release_binding()
    current = current_binding or authorized
    action_ledger = ledger or TRUSTED_RELEASE_ACTION_LEDGER
    values: dict[str, object] = {
        "evaluation_id": f"pre-effect-evaluation-{uuid4()}",
        "authorized_binding": authorized,
        "current_binding": current,
        "current_state": LifecycleState.RELEASE_ELIGIBLE,
        "owner_authorized": True,
        "defensive_purpose": True,
        "owned_or_authorized_target": True,
        "owner_scope_approved": True,
        "least_privilege": True,
        "all_safety_gates_pass": True,
        "present_artifacts_valid": True,
        "completeness_ratio": 1.0,
        "policy_pass": True,
        "tests_pass": True,
        "restore_pass": True,
        "public_safe": True,
        "owner_accept": True,
        "privacy_classification_current": True,
        "conflict_free": True,
        "permission_current": True,
        "environment_current": True,
    }
    values.update(overrides)
    result, evaluation = action_ledger.evaluate_and_reserve(**values)  # type: ignore[arg-type]
    return action_ledger, result, evaluation


def release_bundle(**reserve_overrides: object):
    ledger, result, evaluation = reserve_release(**reserve_overrides)
    assert result.allowed and evaluation is not None, result.reasons
    binding = evaluation.binding
    effect = ReleaseEffectReceipt(
        receipt_id="effect-receipt-1",
        binding=binding,
        pre_effect_evaluation_id=evaluation.evaluation_id,
        pre_effect_time_et=evaluation.evaluated_at,
        action=binding.authorized_action,
        effect_time_et=evaluation.evaluated_at,
        authorized_effect=True,
        effect_completed=True,
        observed_result=binding.expected_outcome,
        error_code=None,
        receipt_present=True,
    )
    outcome = ReleaseOutcomeReceipt(
        receipt_id="outcome-receipt-1",
        binding=binding,
        pre_effect_evaluation_id=evaluation.evaluation_id,
        pre_effect_time_et=evaluation.evaluated_at,
        action=binding.authorized_action,
        effect_receipt_id=effect.receipt_id,
        effect_time_et=effect.effect_time_et,
        observed_at_et=effect.effect_time_et,
        observed_outcome=binding.expected_outcome,
        observed_visibility=binding.expected_visibility,
        observed_retrieval=binding.expected_retrieval,
        outcome_check_pass=True,
        visibility_retrieval_check_pass=True,
        receipt_present=True,
    )
    return ledger, evaluation, effect, outcome


class LifecycleAndAuthorityTests(unittest.TestCase):
    def test_01_role_authority_is_bounded(self) -> None:
        self.assertTrue(role_can("GAUCIA", "propose_merge"))
        self.assertFalse(role_can("GAUCIA", "release"))
        self.assertTrue(role_can("SHERMAN_GAUCIA_LAING", "release"))

    def test_02_exact_happy_path(self) -> None:
        steps = [
            (LifecycleState.UNSCOPED, LifecycleState.SCOPED, {"scope_receipt"}, False),
            (LifecycleState.SCOPED, LifecycleState.INTAKE, {"source_registry"}, False),
            (LifecycleState.INTAKE, LifecycleState.CLASSIFIED, {"classification_record"}, False),
            (LifecycleState.CLASSIFIED, LifecycleState.AUTHORIZED,
             {"defense_authorization_receipt"}, False),
            (LifecycleState.AUTHORIZED, LifecycleState.EXECUTING, {"execution_record"}, False),
            (LifecycleState.EXECUTING, LifecycleState.REVIEWING, {"run_receipt"}, False),
            (LifecycleState.REVIEWING, LifecycleState.RECONCILING, {"role_reviews"}, False),
            (LifecycleState.RECONCILING, LifecycleState.CHECKPOINTED, {"checkpoint"}, False),
            (LifecycleState.CHECKPOINTED, LifecycleState.VALIDATING, {"validation_plan"}, False),
            (LifecycleState.VALIDATING, LifecycleState.VALIDATED, {"validation_receipt"}, False),
            (LifecycleState.VALIDATED, LifecycleState.OWNER_REVIEW,
             {"owner_review_packet"}, False),
            (LifecycleState.OWNER_REVIEW, LifecycleState.ACCEPTED,
             {"owner_acceptance"}, True),
            (LifecycleState.ACCEPTED, LifecycleState.RELEASE_ELIGIBLE,
             {"release_eligibility_receipt"}, False),
            (LifecycleState.RELEASE_ELIGIBLE, LifecycleState.RELEASED,
             {"authorized_effect", "effect_receipt", "outcome_check"}, True),
        ]
        for current, proposed, evidence, owner in steps:
            result = transition_gate(
                current, proposed, required_evidence=(), present_evidence=evidence,
                tests_pass=True, policy_pass=True, owner_action=owner,
            )
            self.assertTrue(result.allowed, (current, proposed, result.reasons))

    def test_03_shortcuts_are_denied(self) -> None:
        for edge in (
            (LifecycleState.CHECKPOINTED, LifecycleState.OWNER_REVIEW),
            (LifecycleState.CHECKPOINTED, LifecycleState.ACCEPTED),
            (LifecycleState.ACCEPTED, LifecycleState.RELEASED),
        ):
            result = transition_gate(
                *edge, required_evidence=(), present_evidence=(), tests_pass=True,
                policy_pass=True, owner_action=True,
            )
            self.assertIn("transition_not_allowed", result.reasons)

    def test_04_control_inbound_sets_are_exact(self) -> None:
        expected_sets = {
            LifecycleState.PAUSED: {
                LifecycleState.SCOPED, LifecycleState.INTAKE,
                LifecycleState.CLASSIFIED, LifecycleState.AUTHORIZED,
                LifecycleState.EXECUTING, LifecycleState.REVIEWING,
                LifecycleState.RECONCILING, LifecycleState.CHECKPOINTED,
                LifecycleState.VALIDATING, LifecycleState.VALIDATED,
                LifecycleState.OWNER_REVIEW, LifecycleState.ACCEPTED,
                LifecycleState.RELEASE_ELIGIBLE, LifecycleState.PAUSED,
                LifecycleState.BLOCKED, LifecycleState.CONFLICT,
                LifecycleState.REVISE, LifecycleState.QUARANTINED,
            },
            LifecycleState.BLOCKED: {
                LifecycleState.INTAKE, LifecycleState.CLASSIFIED,
                LifecycleState.AUTHORIZED, LifecycleState.EXECUTING,
                LifecycleState.REVIEWING, LifecycleState.RECONCILING,
                LifecycleState.CHECKPOINTED, LifecycleState.VALIDATING,
                LifecycleState.VALIDATED, LifecycleState.OWNER_REVIEW,
                LifecycleState.ACCEPTED, LifecycleState.RELEASE_ELIGIBLE,
                LifecycleState.PAUSED, LifecycleState.BLOCKED,
                LifecycleState.CONFLICT, LifecycleState.REVISE,
                LifecycleState.QUARANTINED,
            },
            LifecycleState.CONFLICT: {
                LifecycleState.CLASSIFIED, LifecycleState.AUTHORIZED,
                LifecycleState.EXECUTING, LifecycleState.REVIEWING,
                LifecycleState.RECONCILING, LifecycleState.CHECKPOINTED,
                LifecycleState.VALIDATING, LifecycleState.VALIDATED,
                LifecycleState.OWNER_REVIEW, LifecycleState.ACCEPTED,
                LifecycleState.RELEASE_ELIGIBLE, LifecycleState.PAUSED,
                LifecycleState.BLOCKED, LifecycleState.CONFLICT,
                LifecycleState.REVISE, LifecycleState.QUARANTINED,
            },
            LifecycleState.QUARANTINED: {
                LifecycleState.INTAKE, LifecycleState.CLASSIFIED,
                LifecycleState.AUTHORIZED, LifecycleState.EXECUTING,
                LifecycleState.REVIEWING, LifecycleState.RECONCILING,
                LifecycleState.CHECKPOINTED, LifecycleState.VALIDATING,
                LifecycleState.VALIDATED, LifecycleState.OWNER_REVIEW,
                LifecycleState.ACCEPTED, LifecycleState.RELEASE_ELIGIBLE,
                LifecycleState.PAUSED, LifecycleState.BLOCKED,
                LifecycleState.CONFLICT, LifecycleState.REVISE,
            },
        }
        self.assertEqual(set(CONTROL_INBOUND_SOURCES), set(expected_sets))
        for destination, expected in expected_sets.items():
            self.assertEqual(set(CONTROL_INBOUND_SOURCES[destination]), expected)
            actual = {source for source, targets in ALLOWED_TRANSITIONS.items()
                      if destination in targets}
            self.assertEqual(actual, expected, destination)

    def test_05_every_control_inbound_edge_is_structurally_evidenced(self) -> None:
        for proposed, sources in CONTROL_INBOUND_SOURCES.items():
            for current in sources:
                if current is proposed is LifecycleState.PAUSED:
                    original = control_entry(LifecycleState.CHECKPOINTED,
                                             LifecycleState.PAUSED)
                    ledger, snapshot = stored_context(original)
                    observation = ControlObservationRecord(
                        current_state=LifecycleState.PAUSED,
                        preserved_entry_receipt_id=original.receipt_id,
                        current_snapshot_id=snapshot.store_receipt_id,
                        observed_at=now_et().isoformat(), recorder_role="LEVIATHAN",
                        receipt_id="pause-observation-receipt", no_advancement=True,
                    )
                    result = transition_gate(
                        current, proposed, required_evidence=(),
                        present_evidence={observation.receipt_id}, tests_pass=False,
                        policy_pass=False, lifecycle_ledger=ledger,
                        control_observation=observation,
                    )
                else:
                    entry = control_entry(current, proposed)
                    ledger, snapshot = stored_context(entry)
                    self.assertEqual(ledger.read(snapshot.store_receipt_id), snapshot)
                    continue
                self.assertTrue(result.allowed, (current, proposed, result.reasons))

    def test_06_control_record_fields_are_all_mandatory(self) -> None:
        base = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        for change in (
            {"prior_snapshot_id": ""}, {"affected_scope": ""},
            {"trigger_evidence_ids": ()}, {"reason_code": "OTHER"},
            {"custody_destination": ""}, {"recorded_at": "2026-08-25T12:00:00"},
            {"recorder_role": "OTHER"}, {"receipt_id": ""},
            {"no_advancement": "true"}, {"prior_state": LifecycleState.AUTHORIZED},
        ):
            entry = replace(base, **change)
            result = transition_gate(
                LifecycleState.REVIEWING, LifecycleState.BLOCKED,
                required_evidence=(), present_evidence={base.receipt_id},
                tests_pass=False, policy_pass=False, control_record=entry,
            )
            self.assertIn("control_entry_record_missing_or_invalid", result.reasons)

    def test_06a_control_custody_destination_is_closed_and_nonpublic(self) -> None:
        self.assertEqual(
            AUTHORIZED_CONTROL_CUSTODY_DESTINATIONS,
            frozenset({"controlled-review-custody"}),
        )
        base = control_entry(LifecycleState.REVIEWING, LifecycleState.QUARANTINED)
        for destination in (
            "PUBLIC",
            "public-record-destination",
            "controlled-review-custody ",
            "quarantine-vault",
        ):
            entry = replace(base, custody_destination=destination)
            result = transition_gate(
                LifecycleState.REVIEWING,
                LifecycleState.QUARANTINED,
                required_evidence=(),
                present_evidence={entry.receipt_id},
                tests_pass=False,
                policy_pass=False,
                control_record=entry,
            )
            self.assertFalse(result.allowed, destination)
            self.assertIn("control_entry_record_missing_or_invalid", result.reasons)

    def test_07_control_record_subclass_is_rejected(self) -> None:
        @dataclass(frozen=True)
        class ExtendedControlRecord(ControlEntryRecord):
            extra: str = "unexpected"

        base = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        extended = ExtendedControlRecord(**base.__dict__)
        result = transition_gate(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            required_evidence=(), present_evidence={base.receipt_id},
            tests_pass=False, policy_pass=False, control_record=extended,
        )
        self.assertIn("control_entry_record_missing_or_invalid", result.reasons)

    def test_08_pause_self_edge_preserves_ledger_entry(self) -> None:
        original = control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED)
        ledger, snapshot = stored_context(original)
        observation = ControlObservationRecord(
            current_state=LifecycleState.PAUSED,
            preserved_entry_receipt_id=original.receipt_id,
            current_snapshot_id=snapshot.store_receipt_id,
            observed_at=now_et().isoformat(), recorder_role="LEVIATHAN",
            receipt_id="pause-observation", no_advancement=True,
        )
        passed = transition_gate(
            LifecycleState.PAUSED, LifecycleState.PAUSED,
            required_evidence=(), present_evidence={observation.receipt_id},
            tests_pass=False, policy_pass=False, lifecycle_ledger=ledger,
            control_observation=observation,
        )
        forged = replace(observation, preserved_entry_receipt_id="different")
        denied = transition_gate(
            LifecycleState.PAUSED, LifecycleState.PAUSED,
            required_evidence=(), present_evidence={forged.receipt_id},
            tests_pass=False, policy_pass=False, lifecycle_ledger=ledger,
            control_observation=forged,
        )
        self.assertTrue(passed.allowed, passed.reasons)
        self.assertFalse(denied.allowed)

    def test_09_pause_self_edge_rejects_replacement_entry(self) -> None:
        replacement = control_entry(LifecycleState.PAUSED, LifecycleState.PAUSED)
        result = transition_gate(
            LifecycleState.PAUSED, LifecycleState.PAUSED,
            required_evidence=(), present_evidence={replacement.receipt_id},
            tests_pass=False, policy_pass=False, control_record=replacement,
        )
        self.assertIn("pause_self_edge_must_not_replace_preserved_entry", result.reasons)

    def test_10_paused_to_quarantine_needs_no_owner(self) -> None:
        entry = control_entry(LifecycleState.PAUSED, LifecycleState.QUARANTINED)
        ledger, snapshot = stored_context(entry)
        self.assertEqual(ledger.read(snapshot.store_receipt_id), snapshot)

    def test_11_normal_recovery_uses_stored_prior_state(self) -> None:
        for prior, exception in (
            (LifecycleState.CHECKPOINTED, LifecycleState.PAUSED),
            (LifecycleState.INTAKE, LifecycleState.BLOCKED),
            (LifecycleState.AUTHORIZED, LifecycleState.CONFLICT),
        ):
            entry = control_entry(prior, exception)
            ledger, evidence, present = recovery_bundle(entry)
            result = transition_gate(
                exception, prior, required_evidence=(), present_evidence=present,
                tests_pass=True, policy_pass=True,
                owner_action=exception in {LifecycleState.PAUSED, LifecycleState.CONFLICT},
                lifecycle_ledger=ledger, recovery_evidence=evidence,
            )
            self.assertTrue(result.allowed, (exception, result.reasons))

    def test_12_fabricated_recovery_record_does_not_match_ledger(self) -> None:
        entry = control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED)
        ledger, evidence, present = recovery_bundle(entry)
        forged_entry = replace(entry, prior_snapshot_id="fabricated-snapshot")
        forged = replace(evidence, preserved_entry_record=forged_entry,
                         checkpoint_id="fabricated-snapshot")
        result = transition_gate(
            LifecycleState.PAUSED, LifecycleState.CHECKPOINTED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=forged,
        )
        self.assertIn("preserved_entry_not_equal_to_stored_record", result.reasons)

    def test_13_caller_selected_recovery_state_is_denied(self) -> None:
        entry = control_entry(LifecycleState.SCOPED, LifecycleState.PAUSED)
        ledger, evidence, present = recovery_bundle(
            entry, resume_state=LifecycleState.RELEASE_ELIGIBLE
        )
        result = transition_gate(
            LifecycleState.PAUSED, LifecycleState.RELEASE_ELIGIBLE,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=evidence,
        )
        self.assertIn("recovery_not_bound_to_stored_prior_state", result.reasons)

    def test_14_recovery_artifact_checkpoint_and_store_bindings_are_exact(self) -> None:
        entry = control_entry(LifecycleState.INTAKE, LifecycleState.BLOCKED)
        ledger, evidence, present = recovery_bundle(entry)
        fields = {
            "store_receipt_id": "different",
            "checkpoint_id": "different",
            "checkpoint_state": LifecycleState.CLASSIFIED,
            "checkpoint_artifact_id": "different",
            "checkpoint_artifact_version": "different",
            "current_artifact_id": "different",
            "current_artifact_version": "different",
        }
        for field, changed in fields.items():
            altered = replace(evidence, **{field: changed})
            result = transition_gate(
                LifecycleState.BLOCKED, LifecycleState.INTAKE,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, lifecycle_ledger=ledger,
                recovery_evidence=altered,
            )
            self.assertFalse(result.allowed, field)

    def test_15_paused_and_conflict_recovery_require_owner_receipt_and_action(self) -> None:
        for prior, exception in (
            (LifecycleState.CHECKPOINTED, LifecycleState.PAUSED),
            (LifecycleState.AUTHORIZED, LifecycleState.CONFLICT),
        ):
            entry = control_entry(prior, exception)
            ledger, evidence, present = recovery_bundle(entry)
            no_receipt = replace(evidence, owner_action_receipt=None)
            denied_receipt = transition_gate(
                exception, prior, required_evidence=(), present_evidence=present,
                tests_pass=True, policy_pass=True, owner_action=True,
                lifecycle_ledger=ledger, recovery_evidence=no_receipt,
            )
            denied_action = transition_gate(
                exception, prior, required_evidence=(), present_evidence=present,
                tests_pass=True, policy_pass=True, owner_action=False,
                lifecycle_ledger=ledger, recovery_evidence=evidence,
            )
            self.assertFalse(denied_receipt.allowed)
            self.assertIn("owner_action_required", denied_action.reasons)

    def test_16_resolution_receipt_is_typed_and_fully_bound(self) -> None:
        entry = control_entry(LifecycleState.INTAKE, LifecycleState.BLOCKED)
        ledger, evidence, present = recovery_bundle(entry)
        for field, changed in (
            ("resolution_type", "OTHER"), ("entry_receipt_id", "other"),
            ("checkpoint_id", "other"), ("affected_scope", "other"),
            ("artifact_id", "other"), ("artifact_version", "other"),
            ("resume_state", LifecycleState.CLASSIFIED), ("present", "true"),
        ):
            altered_receipt = replace(evidence.resolution_receipt, **{field: changed})
            altered = replace(evidence, resolution_receipt=altered_receipt)
            result = transition_gate(
                LifecycleState.BLOCKED, LifecycleState.INTAKE,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, lifecycle_ledger=ledger,
                recovery_evidence=altered,
            )
            self.assertIn("resolution_receipt_binding_invalid", result.reasons)

    def test_17_quarantine_exit_requires_all_bound_objects(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.QUARANTINED)
        ledger, evidence, present = recovery_bundle(entry)
        result = transition_gate(
            LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=evidence,
        )
        self.assertTrue(result.allowed, result.reasons)
        for field in ("owner_action_receipt", "classification_record",
                      "privacy_review_receipt", "secret_scan_receipt"):
            altered = replace(evidence, **{field: None})
            denied = transition_gate(
                LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
                recovery_evidence=altered,
            )
            self.assertFalse(denied.allowed, field)

    def test_18_quarantine_reviews_are_distinct_fresh_and_byte_bound(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.QUARANTINED)
        ledger, evidence, present = recovery_bundle(entry)
        assert evidence.privacy_review_receipt is not None
        assert evidence.secret_scan_receipt is not None
        cases = (
            replace(evidence, secret_scan_receipt={
                **evidence.secret_scan_receipt,
                "receipt_id": evidence.privacy_review_receipt["receipt_id"],
            }),
            replace(evidence, secret_scan_receipt={
                **evidence.secret_scan_receipt,
                "exact_projection_bytes": b"changed",
            }),
            replace(evidence, privacy_review_receipt={
                **evidence.privacy_review_receipt,
                "expires_at": (now_et() - timedelta(seconds=1)).isoformat(),
            }),
        )
        for altered in cases:
            result = transition_gate(
                LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
                recovery_evidence=altered,
            )
            self.assertFalse(result.allowed)

    def test_19_every_allowed_edge_fails_without_evidence(self) -> None:
        for current, targets in ALLOWED_TRANSITIONS.items():
            for proposed in targets:
                result = transition_gate(
                    current, proposed, required_evidence=(), present_evidence=(),
                    tests_pass=True, policy_pass=True, owner_action=True,
                )
                self.assertFalse(result.allowed, (current, proposed))

    def test_20_transition_boolean_strings_fail_closed(self) -> None:
        result = transition_gate(
            LifecycleState.CHECKPOINTED, LifecycleState.VALIDATING,
            required_evidence=(), present_evidence={"validation_plan"},
            tests_pass="true", policy_pass="true", owner_action="true",  # type: ignore[arg-type]
        )
        self.assertIn("tests_result_not_boolean", result.reasons)
        self.assertIn("policy_result_not_boolean", result.reasons)
        self.assertIn("owner_action_not_boolean", result.reasons)

    def test_53_copied_or_caller_created_lifecycle_ledger_is_not_trusted(self) -> None:
        entry = control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED)
        trusted, evidence, present = recovery_bundle(entry)
        snapshot = trusted.read(evidence.store_receipt_id)
        assert snapshot is not None
        copied = LifecycleLedger()
        self.assertFalse(copied.store(snapshot))
        self.assertFalse(TRUSTED_LIFECYCLE_LEDGER.store(snapshot))
        result = transition_gate(
            LifecycleState.PAUSED, LifecycleState.CHECKPOINTED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=copied,
            recovery_evidence=evidence,
        )
        self.assertIn("trusted_lifecycle_ledger_missing", result.reasons)

    def test_54_nested_control_overlay_recovers_to_stored_control_prior(self) -> None:
        for prior in (LifecycleState.QUARANTINED, LifecycleState.REVISE):
            entry = control_entry(prior, LifecycleState.PAUSED)
            ledger, evidence, present = recovery_bundle(entry)
            recovered = transition_gate(
                LifecycleState.PAUSED, prior,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
                recovery_evidence=evidence,
            )
            self.assertTrue(recovered.allowed, (prior, recovered.reasons))

    def test_55_typed_owner_and_resolution_receipts_reject_hostile_fields(self) -> None:
        class ExplosiveEquality:
            def __eq__(self, other: object) -> bool:
                raise RuntimeError("must not compare malformed field")

        paused = control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED)
        ledger, evidence, present = recovery_bundle(paused)
        assert evidence.owner_action_receipt is not None
        hostile_owner = replace(
            evidence.owner_action_receipt, action=ExplosiveEquality()
        )
        denied_owner = transition_gate(
            LifecycleState.PAUSED, LifecycleState.CHECKPOINTED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=replace(evidence, owner_action_receipt=hostile_owner),
        )
        self.assertIn("owner_action_receipt_missing_or_invalid", denied_owner.reasons)

        blocked = control_entry(LifecycleState.INTAKE, LifecycleState.BLOCKED)
        ledger, evidence, present = recovery_bundle(blocked)
        hostile_resolution = replace(
            evidence.resolution_receipt,
            owner_action_receipt_id=ExplosiveEquality(),
        )
        denied_resolution = transition_gate(
            LifecycleState.BLOCKED, LifecycleState.INTAKE,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, lifecycle_ledger=ledger,
            recovery_evidence=replace(
                evidence, resolution_receipt=hostile_resolution
            ),
        )
        self.assertIn("resolution_receipt_binding_invalid", denied_resolution.reasons)

    def test_56_quarantine_classification_requires_fresh_canonical_bytes(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.QUARANTINED)
        ledger, evidence, present = recovery_bundle(entry)
        malformed = (
            b"\xff\x00not-json",
            b'{ "artifact_projection": "reclassified" }',
            b'{"artifact_projection":"a","artifact_projection":"b"}',
        )
        for exact_bytes in malformed:
            assert evidence.classification_record is not None
            assert evidence.privacy_review_receipt is not None
            assert evidence.secret_scan_receipt is not None
            altered = replace(
                evidence,
                classification_record=replace(
                    evidence.classification_record,
                    exact_projection_bytes=exact_bytes,
                ),
                privacy_review_receipt={
                    **evidence.privacy_review_receipt,
                    "exact_projection_bytes": exact_bytes,
                },
                secret_scan_receipt={
                    **evidence.secret_scan_receipt,
                    "exact_projection_bytes": exact_bytes,
                },
            )
            result = transition_gate(
                LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
                recovery_evidence=altered,
            )
            self.assertIn("classification_record_binding_invalid", result.reasons)

        assert evidence.classification_record is not None
        stale = replace(
            evidence,
            classification_record=replace(
                evidence.classification_record,
                classified_at=(now_et() - timedelta(minutes=20)).isoformat(),
            ),
        )
        result = transition_gate(
            LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=stale,
        )
        self.assertIn("classification_record_binding_invalid", result.reasons)

    def test_57_quarantine_review_must_follow_classification(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.QUARANTINED)
        ledger, evidence, present = recovery_bundle(entry)
        assert evidence.classification_record is not None
        assert evidence.privacy_review_receipt is not None
        before = (datetime.fromisoformat(
            evidence.classification_record.classified_at
        ) - timedelta(seconds=1)).isoformat()
        altered = replace(
            evidence,
            privacy_review_receipt={
                **evidence.privacy_review_receipt,
                "reviewed_at": before,
            },
        )
        result = transition_gate(
            LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=altered,
        )
        self.assertIn(
            "quarantine_privacy_receipt_missing_stale_or_mismatched",
            result.reasons,
        )

    def test_65_pause_observation_time_is_bound_to_storage_and_runtime(self) -> None:
        entry = control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED)
        ledger, snapshot = stored_context(entry)
        base = ControlObservationRecord(
            current_state=LifecycleState.PAUSED,
            preserved_entry_receipt_id=entry.receipt_id,
            current_snapshot_id=snapshot.store_receipt_id,
            observed_at=now_et().isoformat(), recorder_role="LEVIATHAN",
            receipt_id="pause-observation-time-bound", no_advancement=True,
        )
        for changed in (
            "2000-01-01T00:00:00-05:00",
            "2999-01-01T00:00:00-05:00",
        ):
            altered = replace(base, observed_at=changed)
            result = transition_gate(
                LifecycleState.PAUSED, LifecycleState.PAUSED,
                required_evidence=(), present_evidence={altered.receipt_id},
                tests_pass=False, policy_pass=False, lifecycle_ledger=ledger,
                control_observation=altered,
            )
            self.assertIn(
                "pause_observation_record_missing_or_invalid", result.reasons
            )

    def test_68_revision_recovery_returns_to_rejected_prior(self) -> None:
        entry = revision_entry(LifecycleState.REJECTED)
        ledger, evidence, present = recovery_bundle(entry)
        result = transition_gate(
            LifecycleState.REVISE, LifecycleState.REJECTED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=evidence,
        )
        self.assertTrue(result.allowed, result.reasons)

    def test_69_owner_recovery_action_must_follow_control_storage(self) -> None:
        cases = (
            (LifecycleState.CHECKPOINTED, LifecycleState.PAUSED),
            (LifecycleState.AUTHORIZED, LifecycleState.CONFLICT),
            (LifecycleState.REVIEWING, LifecycleState.QUARANTINED),
        )
        for prior, exception in cases:
            entry = control_entry(prior, exception)
            ledger, evidence, present = recovery_bundle(entry)
            assert evidence.owner_action_receipt is not None
            altered_owner = replace(
                evidence.owner_action_receipt,
                issued_at=(now_et() - timedelta(days=30)).isoformat(),
                expires_at=(now_et() + timedelta(minutes=5)).isoformat(),
            )
            proposed = (
                LifecycleState.CLASSIFIED
                if exception is LifecycleState.QUARANTINED
                else prior
            )
            result = transition_gate(
                exception, proposed,
                required_evidence=(), present_evidence=present, tests_pass=True,
                policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
                recovery_evidence=replace(
                    evidence, owner_action_receipt=altered_owner
                ),
            )
            self.assertIn(
                "owner_action_receipt_missing_or_invalid", result.reasons
            )

    def test_70_deep_quarantine_json_fails_closed_without_exception(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.QUARANTINED)
        ledger, evidence, present = recovery_bundle(entry)
        assert evidence.classification_record is not None
        assert evidence.privacy_review_receipt is not None
        assert evidence.secret_scan_receipt is not None
        deep = (
            b'{"artifact_projection":'
            + b"[" * 1200 + b"0" + b"]" * 1200
            + b"}"
        )
        altered = replace(
            evidence,
            classification_record=replace(
                evidence.classification_record, exact_projection_bytes=deep
            ),
            privacy_review_receipt={
                **evidence.privacy_review_receipt,
                "exact_projection_bytes": deep,
            },
            secret_scan_receipt={
                **evidence.secret_scan_receipt,
                "exact_projection_bytes": deep,
            },
        )
        result = transition_gate(
            LifecycleState.QUARANTINED, LifecycleState.CLASSIFIED,
            required_evidence=(), present_evidence=present, tests_pass=True,
            policy_pass=True, owner_action=True, lifecycle_ledger=ledger,
            recovery_evidence=altered,
        )
        self.assertIn("classification_record_binding_invalid", result.reasons)

    def test_71_nonself_control_and_revision_require_atomic_snapshot(self) -> None:
        control = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        denied_control = transition_gate(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            required_evidence=(), present_evidence={control.receipt_id},
            tests_pass=False, policy_pass=False, control_record=control,
        )
        self.assertIn("trusted_lifecycle_ledger_missing", denied_control.reasons)
        self.assertIn("entry_snapshot_missing_or_invalid", denied_control.reasons)

        revision = revision_entry(LifecycleState.REJECTED)
        denied_revision = transition_gate(
            LifecycleState.REJECTED, LifecycleState.REVISE,
            required_evidence=(),
            present_evidence={
                revision.receipt_id, revision.owner_direction_receipt_id
            },
            tests_pass=False, policy_pass=False, owner_action=True,
            revision_record=revision,
        )
        self.assertIn("trusted_lifecycle_ledger_missing", denied_revision.reasons)
        self.assertIn("entry_snapshot_missing_or_invalid", denied_revision.reasons)

    def test_72_control_entry_rejects_caller_created_ledger(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        snapshot = snapshot_for_entry(entry)
        result = transition_gate(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            required_evidence=(), present_evidence={entry.receipt_id},
            tests_pass=False, policy_pass=False, control_record=entry,
            entry_snapshot=snapshot, lifecycle_ledger=LifecycleLedger(),
        )
        self.assertIn("trusted_lifecycle_ledger_missing", result.reasons)
        self.assertIsNone(
            TRUSTED_LIFECYCLE_LEDGER.read(snapshot.store_receipt_id)
        )

    def test_73_store_and_entry_receipt_ids_are_single_use(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        ledger, first = stored_context(entry)

        duplicate_store = transition_gate(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            required_evidence=(), present_evidence={entry.receipt_id},
            tests_pass=False, policy_pass=False, control_record=entry,
            entry_snapshot=first, lifecycle_ledger=ledger,
        )
        self.assertIn(
            "entry_snapshot_store_receipt_already_used", duplicate_store.reasons
        )

        second = snapshot_for_entry(entry)
        duplicate_entry = transition_gate(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            required_evidence=(), present_evidence={entry.receipt_id},
            tests_pass=False, policy_pass=False, control_record=entry,
            entry_snapshot=second, lifecycle_ledger=ledger,
        )
        self.assertIn("entry_receipt_already_used", duplicate_entry.reasons)
        self.assertIsNone(ledger.read(second.store_receipt_id))

    def test_74_pause_observation_is_append_preserved_and_idempotent(self) -> None:
        entry = control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED)
        ledger, snapshot = stored_context(entry)
        observation = ControlObservationRecord(
            current_state=LifecycleState.PAUSED,
            preserved_entry_receipt_id=entry.receipt_id,
            current_snapshot_id=snapshot.store_receipt_id,
            observed_at=now_et().isoformat(), recorder_role="LEVIATHAN",
            receipt_id=f"pause-observation-{uuid4()}", no_advancement=True,
        )

        def observe(record: ControlObservationRecord):
            return transition_gate(
                LifecycleState.PAUSED, LifecycleState.PAUSED,
                required_evidence=(), present_evidence={record.receipt_id},
                tests_pass=False, policy_pass=False, lifecycle_ledger=ledger,
                control_observation=record,
            )

        self.assertTrue(observe(observation).allowed)
        self.assertEqual(
            ledger.read_observation(observation.receipt_id), observation
        )
        self.assertTrue(observe(observation).allowed)
        collision = observe(replace(observation, recorder_role="GAUCIA"))
        self.assertIn("observation_receipt_collision", collision.reasons)
        self.assertEqual(
            ledger.read_observation(observation.receipt_id), observation
        )

    def test_75_snapshot_time_is_between_entry_and_runtime(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        for stored_at in (
            "2000-01-01T00:00:00-05:00",
            "2999-01-01T00:00:00-05:00",
        ):
            snapshot = snapshot_for_entry(entry, stored_at=stored_at)
            result = transition_gate(
                LifecycleState.REVIEWING, LifecycleState.BLOCKED,
                required_evidence=(), present_evidence={entry.receipt_id},
                tests_pass=False, policy_pass=False, control_record=entry,
                entry_snapshot=snapshot,
                lifecycle_ledger=TRUSTED_LIFECYCLE_LEDGER,
            )
            self.assertIn("entry_snapshot_missing_or_invalid", result.reasons)

    def test_76_concurrent_entry_receipt_reservation_allows_one(self) -> None:
        entry = control_entry(LifecycleState.REVIEWING, LifecycleState.BLOCKED)
        snapshots = (snapshot_for_entry(entry), snapshot_for_entry(entry))

        def attempt(snapshot: StoredLifecycleSnapshot):
            return transition_gate(
                LifecycleState.REVIEWING, LifecycleState.BLOCKED,
                required_evidence=(), present_evidence={entry.receipt_id},
                tests_pass=False, policy_pass=False, control_record=entry,
                entry_snapshot=snapshot,
                lifecycle_ledger=TRUSTED_LIFECYCLE_LEDGER,
            )

        with ThreadPoolExecutor(max_workers=2) as pool:
            results = list(pool.map(attempt, snapshots))
        self.assertEqual(sum(result.allowed for result in results), 1)

    def test_77_malformed_evidence_collections_fail_closed(self) -> None:
        class ExplosiveHash:
            def __hash__(self) -> int:
                raise RuntimeError("must not escape")

        class ExplosiveIterable:
            def __iter__(self):
                raise RuntimeError("must not escape")

        malformed = ([1], [object()], [ExplosiveHash()], ExplosiveIterable())
        for required in malformed:
            result = transition_gate(
                LifecycleState.CHECKPOINTED, LifecycleState.VALIDATING,
                required_evidence=required, present_evidence=(),
                tests_pass=True, policy_pass=True,
            )
            self.assertFalse(result.allowed)
            self.assertIn("evidence_collection_invalid", result.reasons)

    def test_78_hostile_resolution_owner_link_fails_closed(self) -> None:
        class ExplosiveInequality:
            def __ne__(self, other: object) -> bool:
                raise RuntimeError("must not escape")

        cases: tuple[
            tuple[ControlEntryRecord | RevisionEntryRecord, LifecycleState], ...
        ] = (
            (control_entry(LifecycleState.CHECKPOINTED, LifecycleState.PAUSED),
             LifecycleState.CHECKPOINTED),
            (control_entry(LifecycleState.AUTHORIZED, LifecycleState.CONFLICT),
             LifecycleState.AUTHORIZED),
            (revision_entry(LifecycleState.REJECTED), LifecycleState.REJECTED),
            (control_entry(LifecycleState.REVIEWING,
                           LifecycleState.QUARANTINED),
             LifecycleState.CLASSIFIED),
        )
        for entry, proposed in cases:
            ledger, evidence, present = recovery_bundle(entry)
            hostile = replace(
                evidence.resolution_receipt,
                owner_action_receipt_id=ExplosiveInequality(),
            )
            result = transition_gate(
                entry.exception_state, proposed,
                required_evidence=(), present_evidence=present,
                tests_pass=True, policy_pass=True, owner_action=True,
                lifecycle_ledger=ledger,
                recovery_evidence=replace(
                    evidence, resolution_receipt=hostile
                ),
            )
            self.assertFalse(result.allowed)
            self.assertIn("resolution_receipt_binding_invalid", result.reasons)

    def test_79_revision_to_rejected_cannot_bypass_recovery(self) -> None:
        result = transition_gate(
            LifecycleState.REVISE, LifecycleState.REJECTED,
            required_evidence=(), present_evidence={"owner_rejection"},
            tests_pass=False, policy_pass=False, owner_action=True,
        )
        self.assertFalse(result.allowed)
        self.assertIn("recovery_evidence_missing", result.reasons)

    def test_80_lifecycle_receipt_identity_namespace_is_global(self) -> None:
        shared_id = f"shared-lifecycle-id-{uuid4()}"
        same_call = control_entry(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            receipt_id=shared_id,
        )
        same_snapshot = snapshot_for_entry(
            same_call, store_receipt_id=shared_id
        )
        denied_same = transition_gate(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED,
            required_evidence=(), present_evidence={same_call.receipt_id},
            tests_pass=False, policy_pass=False, control_record=same_call,
            entry_snapshot=same_snapshot,
            lifecycle_ledger=TRUSTED_LIFECYCLE_LEDGER,
        )
        self.assertIn(
            "lifecycle_receipt_identity_collision", denied_same.reasons
        )

        first_entry = control_entry(
            LifecycleState.REVIEWING, LifecycleState.BLOCKED
        )
        ledger, first_snapshot = stored_context(first_entry)

        store_as_entry = control_entry(
            LifecycleState.AUTHORIZED, LifecycleState.PAUSED,
            receipt_id=first_snapshot.store_receipt_id,
        )
        denied_store_as_entry = transition_gate(
            LifecycleState.AUTHORIZED, LifecycleState.PAUSED,
            required_evidence=(),
            present_evidence={store_as_entry.receipt_id},
            tests_pass=False, policy_pass=False,
            control_record=store_as_entry,
            entry_snapshot=snapshot_for_entry(store_as_entry),
            lifecycle_ledger=ledger,
        )
        self.assertIn(
            "lifecycle_receipt_identity_collision",
            denied_store_as_entry.reasons,
        )

        entry_as_store = control_entry(
            LifecycleState.AUTHORIZED, LifecycleState.PAUSED
        )
        denied_entry_as_store = transition_gate(
            LifecycleState.AUTHORIZED, LifecycleState.PAUSED,
            required_evidence=(), present_evidence={entry_as_store.receipt_id},
            tests_pass=False, policy_pass=False,
            control_record=entry_as_store,
            entry_snapshot=snapshot_for_entry(
                entry_as_store, store_receipt_id=first_entry.receipt_id
            ),
            lifecycle_ledger=ledger,
        )
        self.assertIn(
            "lifecycle_receipt_identity_collision",
            denied_entry_as_store.reasons,
        )

    def test_81_blocked_recovery_uses_exception_authority_rule(self) -> None:
        for prior in (LifecycleState.ACCEPTED, LifecycleState.REVISE):
            entry = control_entry(prior, LifecycleState.BLOCKED)
            ledger, evidence, present = recovery_bundle(entry)
            result = transition_gate(
                LifecycleState.BLOCKED, prior,
                required_evidence=(), present_evidence=present,
                tests_pass=True, policy_pass=True,
                lifecycle_ledger=ledger, recovery_evidence=evidence,
            )
            self.assertTrue(result.allowed, (prior, result.reasons))


class MergePrivacyAndFormulaTests(unittest.TestCase):
    def test_21_defense_gate_uses_strict_booleans(self) -> None:
        passed = defense_only_gate(
            defensive_purpose=True, owned_or_authorized_target=True,
            owner_scope_approved=True, least_privilege=True,
            all_safety_gates_pass=True,
        )
        denied = defense_only_gate(
            defensive_purpose="true", owned_or_authorized_target=True,  # type: ignore[arg-type]
            owner_scope_approved=True, least_privilege=True,
            all_safety_gates_pass=True,
        )
        self.assertTrue(passed.allowed)
        self.assertFalse(denied.allowed)

    def test_22_shared_core_is_append_only_and_conflict_preserving(self) -> None:
        existing = record("r1")
        result = merge_shared_core(
            [existing],
            [record("r2"), record("r1"), record("r3", conflict_id="c1"),
             record("r4", privacy=PrivacyClass.PRIVATE)],
        )
        self.assertEqual([item.record_id for item in result.accepted], ["r1", "r2"])
        self.assertEqual([item.record_id for item in result.held], ["r1", "r3", "r4"])
        self.assertEqual([item.record_id for item in result.conflicts], ["r3"])

    def test_23_merge_rejects_truthy_non_boolean_gate(self) -> None:
        candidate = replace(record("r"), tests_pass="true")  # type: ignore[arg-type]
        self.assertEqual(merge_shared_core([], [candidate]).accepted, ())

    def test_24_privacy_routes_cover_all_lanes(self) -> None:
        expected = {
            PrivacyClass.PUBLIC: "PUBLIC_REVIEW",
            PrivacyClass.PUBLIC_REDACTED: "PUBLIC_REDACTED_REVIEW",
            PrivacyClass.PROJECT_RESTRICTED: "INTERNAL_ONLY",
            PrivacyClass.PRIVATE: "PRIVATE_ONLY",
            PrivacyClass.QUARANTINED: "QUARANTINE",
            PrivacyClass.SUPERSEDED: "HISTORY_ONLY",
        }
        for privacy, route in expected.items():
            self.assertEqual(route_for_publication(record("p", privacy=privacy)), route)

    def test_25_protected_records_emit_only_four_fixed_objects(self) -> None:
        expected = {
            PrivacyClass.PROJECT_RESTRICTED: "EXCLUDED_PROJECT_RESTRICTED",
            PrivacyClass.PRIVATE: "EXCLUDED_PRIVATE",
            PrivacyClass.QUARANTINED: "EXCLUDED_QUARANTINED",
            PrivacyClass.SUPERSEDED: "EXCLUDED_SUPERSEDED",
        }
        secret = "synthetic-protected-marker"
        for privacy, code in expected.items():
            candidate = replace(record(secret, privacy=privacy), statement=secret,
                                source_role=secret)
            emitted = public_bytes(candidate, None, None)
            self.assertEqual(emitted, canonical_json_bytes(
                {"included": False, "exclusion_code": code}
            ))
            self.assertNotIn(secret.encode(), emitted)

    def test_26_unknown_privacy_value_emits_fixed_unclassified_object(self) -> None:
        candidate = replace(record("r"), privacy_class="UNKNOWN")  # type: ignore[arg-type]
        emitted = public_bytes(candidate, None, None)
        self.assertEqual(emitted, canonical_json_bytes(
            {"included": False, "exclusion_code": "EXCLUDED_UNCLASSIFIED"}
        ))

    def test_27_public_projection_requires_both_distinct_receipts(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)
        self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                      public_bytes(candidate, None, scan))
        self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                      public_bytes(candidate, privacy, None))
        same_id = {**scan, "receipt_id": privacy["receipt_id"]}
        self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                      public_bytes(candidate, privacy, same_id))

    def test_28_public_and_redacted_emit_the_exact_reviewed_bytes(self) -> None:
        public = record("public")
        redacted = replace(
            record("redacted", privacy=PrivacyClass.PUBLIC_REDACTED),
            statement="protected-source", public_summary="bounded summary",
        )
        for candidate in (public, redacted):
            privacy, scan = projection_receipts(candidate)
            emitted = public_bytes(candidate, privacy, scan)
            self.assertIs(type(emitted), bytes)
            self.assertEqual(emitted, privacy["exact_projection_bytes"])
            self.assertEqual(emitted, scan["exact_projection_bytes"])
        self.assertNotIn(b"protected-source", public_bytes(
            redacted, *projection_receipts(redacted)
        ))

    def test_29_projection_receipt_schema_is_exact(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)
        self.assertEqual(set(privacy), set(PROJECTION_RECEIPT_FIELDS))
        missing = dict(privacy)
        missing.pop("method")
        extra = {**privacy, "extra": "field"}
        for altered in (missing, extra):
            self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                          public_bytes(candidate, altered, scan))

    def test_30_projection_binding_method_rules_fields_scope_and_bytes_are_exact(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)
        receipt_changes = (
            {"destination": "other"}, {"projection_version": "other"},
            {"artifact_id": "other"}, {"artifact_version": "other"},
            {"exact_projection_bytes": b"other"}, {"method": "other"},
            {"rule_set_version": "other"}, {"reviewed_fields": ["record_id"]},
            {"review_scope": "other"},
        )
        for change in receipt_changes:
            altered = {**privacy, **change}
            self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                          public_bytes(candidate, altered, scan))

    def test_31_projection_receipt_boolean_and_type_substitutes_fail(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)
        for change in (
            {"pass": "true"}, {"pass": 1}, {"reviewed_fields": tuple(
                privacy["reviewed_fields"]  # type: ignore[arg-type]
            )}, {"review_type": 1}, {"exact_projection_bytes": bytearray(b"x")},
        ):
            altered = {**privacy, **change}
            self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                          public_bytes(candidate, altered, scan))

    def test_32_projection_uses_runtime_time_not_caller_backdating(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)
        expired = {**privacy,
                   "expires_at": (now_et() - timedelta(seconds=1)).isoformat()}
        future = {**privacy,
                  "reviewed_at": (now_et() + timedelta(minutes=1)).isoformat()}
        naive = {**privacy, "reviewed_at": "2026-08-25T12:00:00"}
        for altered in (expired, future, naive):
            self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED",
                          public_bytes(candidate, altered, scan))

    def test_33_canonical_json_is_nfc_finite_and_deterministic(self) -> None:
        decomposed = "e\u0301"
        composed = "é"
        self.assertEqual(canonical_json({"b": 2, "a": decomposed}),
                         canonical_json({"a": composed, "b": 2}))
        with self.assertRaises(ValueError):
            canonical_json({"bad": float("nan")})
        self.assertEqual(json.loads(canonical_json({"a": composed})), {"a": composed})

    def test_34_completeness_and_integrity_are_distinct_and_strict(self) -> None:
        self.assertEqual(completeness({"a", "b"}, {"a"}), 0.5)
        self.assertEqual(completeness(set(), set()), 0.0)
        self.assertEqual(integrity([True, "true", 1, False]), 0.25)

    def test_49_projection_rejects_alias_keys_and_hostile_values_without_exception(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)

        class AliasKey:
            def __hash__(self) -> int:
                return hash("receipt_id")

            def __eq__(self, other: object) -> bool:
                return other == "receipt_id"

        class ExplosiveEquality:
            def __eq__(self, other: object) -> bool:
                raise RuntimeError("must not be invoked")

        alias = dict(privacy)
        value = alias.pop("receipt_id")
        alias[AliasKey()] = value
        hostile = {**privacy, "exact_projection_bytes": ExplosiveEquality()}
        for malformed in (alias, hostile):
            emitted = public_bytes(candidate, malformed, scan)
            self.assertEqual(emitted, canonical_json_bytes(
                {"included": False,
                 "exclusion_code": "EXCLUDED_PUBLIC_SAFETY_NOT_PASSED"}
            ))

    def test_50_lone_surrogates_fail_closed_in_all_public_text_fields(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)
        malformed_records = (
            replace(candidate, record_id="\ud800"),
            replace(candidate, source_role="\ud800"),
            replace(candidate, statement="\ud800"),
            replace(record("redacted", privacy=PrivacyClass.PUBLIC_REDACTED),
                    public_summary="\ud800"),
        )
        for malformed in malformed_records:
            emitted = public_bytes(malformed, privacy, scan)
            self.assertIn(emitted, (
                canonical_json_bytes({"included": False,
                                      "exclusion_code": "EXCLUDED_UNCLASSIFIED"}),
                canonical_json_bytes({"included": False,
                                      "exclusion_code":
                                      "EXCLUDED_PUBLIC_SAFETY_NOT_PASSED"}),
            ))
        with self.assertRaises(ValueError):
            canonical_json({"\ud800": "value"})
        with self.assertRaises(ValueError):
            canonical_json({"key": "\ud800"})

    def test_51_canonical_json_rejects_infinities_collisions_and_nested_invalids(self) -> None:
        for value in (float("inf"), float("-inf"), [1, {"bad": float("nan")}], object()):
            with self.assertRaises((TypeError, ValueError)):
                canonical_json({"value": value})
        with self.assertRaises(ValueError):
            canonical_json({"é": 1, "e\u0301": 2})

    def test_52_projection_rejects_hostile_request_bindings_without_exception(self) -> None:
        candidate = record("r")
        privacy, scan = projection_receipts(candidate)

        class ExplosiveEquality:
            def __eq__(self, other: object) -> bool:
                raise RuntimeError("must not be invoked")

        for field in ("destination", "projection_version", "artifact_id",
                      "artifact_version"):
            emitted = public_bytes(
                candidate, privacy, scan, **{field: ExplosiveEquality()}
            )
            self.assertIn(b"EXCLUDED_PUBLIC_SAFETY_NOT_PASSED", emitted)


class ReleaseBindingTests(unittest.TestCase):
    def test_35_release_eligibility_requires_exact_state_gates_and_owner(self) -> None:
        wrong = release_gate(
            current_state=LifecycleState.VALIDATED, present_artifacts_valid=True,
            completeness_ratio=1.0, policy_pass=True, tests_pass=True,
            restore_pass=True, public_safe=True, owner_accept=True,
        )
        malformed = release_gate(
            current_state=LifecycleState.ACCEPTED,
            present_artifacts_valid="true", completeness_ratio=0.999,  # type: ignore[arg-type]
            policy_pass=True, tests_pass=True, restore_pass=True,
            public_safe=True, owner_accept=False,
        )
        self.assertIn("task_not_accepted", wrong.reasons)
        self.assertFalse(malformed.allowed)

    def test_36_atomic_reservation_and_complete_post_effect_record_pass(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=outcome,
        )
        self.assertTrue(result.allowed, result.reasons)

    def test_37_atomic_single_use_allows_exactly_one_concurrent_reservation(self) -> None:
        ledger = TRUSTED_RELEASE_ACTION_LEDGER
        binding = release_binding()

        def attempt(index: int) -> bool:
            _, result, _ = reserve_release(
                ledger=ledger, binding=binding,
                evaluation_id=f"evaluation-{index}",
            )
            return result.allowed

        with ThreadPoolExecutor(max_workers=8) as pool:
            outcomes = list(pool.map(attempt, range(8)))
        self.assertEqual(sum(outcomes), 1)

    def test_38_reserved_action_remains_consumed_after_failed_effect(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        failed_effect = replace(effect, effect_completed=False,
                                observed_result="failed", error_code="SIMULATED_ERROR")
        denied = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=failed_effect, outcome_receipt=outcome,
        )
        _, second, _ = reserve_release(
            ledger=ledger, binding=evaluation.binding,
            evaluation_id="second-evaluation",
        )
        self.assertFalse(denied.allowed)
        self.assertIn("release_action_already_reserved", second.reasons)

    def test_39_pre_effect_rejects_every_changed_binding_field(self) -> None:
        base = release_binding()
        changes = {
            "artifact_id": "different", "artifact_version": "different",
            "artifact_manifest": b"different", "destination": "different",
            "target": "different", "privacy_projection_version": "different",
            "conflict_snapshot_id": "different", "permission_scope_id": "different",
            "test_set_id": "different", "restore_receipt_id": "different",
            "environment_id": "different", "release_action_id": "different",
            "authorized_action": "different", "expected_outcome": "different",
            "expected_visibility": "different", "expected_retrieval": "different",
            "direction_time_et": (now_et() - timedelta(minutes=6)).isoformat(),
            "expires_time_et": (now_et() + timedelta(minutes=6)).isoformat(),
            "max_effect_delay_seconds": 121,
        }
        for field, value in changes.items():
            _, result, _ = reserve_release(
                binding=base, current_binding=replace(base, **{field: value})
            )
            self.assertIn("release_binding_changed", result.reasons, field)

    def test_40_release_binding_rejects_invalid_types_subclasses_and_windows(self) -> None:
        @dataclass(frozen=True)
        class ExtendedBinding(ReleaseBinding):
            extra: str = "unexpected"

        base = release_binding()
        subclass = ExtendedBinding(**base.__dict__)
        invalid = (
            replace(base, artifact_id=""),
            replace(base, artifact_manifest=bytearray(b"x")),  # type: ignore[arg-type]
            replace(base, direction_time_et="2026-08-25T12:00:00"),
            replace(base, expires_time_et=(now_et() - timedelta(minutes=6)).isoformat()),
            replace(base, max_effect_delay_seconds=True),
            subclass,
        )
        for binding in invalid:
            _, result, _ = reserve_release(binding=binding, current_binding=binding)
            self.assertFalse(result.allowed)

    def test_41_pre_effect_strict_booleans_and_complete_ratio(self) -> None:
        for field in (
            "owner_authorized", "defensive_purpose", "owned_or_authorized_target",
            "owner_scope_approved", "least_privilege", "all_safety_gates_pass",
            "present_artifacts_valid", "policy_pass", "tests_pass", "restore_pass",
            "public_safe", "owner_accept", "privacy_classification_current",
            "conflict_free", "permission_current", "environment_current",
        ):
            _, result, _ = reserve_release(**{field: "true"})
            self.assertFalse(result.allowed, field)
        _, result, _ = reserve_release(completeness_ratio=0.999)
        self.assertIn("required_set_incomplete", result.reasons)

    def test_42_pre_effect_rejects_future_and_expired_directions(self) -> None:
        future = release_binding(
            direction_time_et=(now_et() + timedelta(minutes=2)).isoformat(),
            expires_time_et=(now_et() + timedelta(minutes=5)).isoformat(),
        )
        expired = release_binding(
            direction_time_et=(now_et() - timedelta(minutes=5)).isoformat(),
            expires_time_et=(now_et() - timedelta(minutes=1)).isoformat(),
        )
        for binding in (future, expired):
            _, result, _ = reserve_release(binding=binding)
            self.assertIn("pre_effect_time_outside_direction_window", result.reasons)

    def test_43_effect_receipt_is_exactly_bound_and_strict(self) -> None:
        cases = (
            ("binding", "effect_receipt_binding_mismatch"),
            ("pre_effect_evaluation_id", "effect_receipt_evaluation_id_mismatch"),
            ("pre_effect_time_et", "effect_receipt_evaluation_time_mismatch"),
            ("action", "effect_receipt_action_mismatch"),
            ("authorized_effect", "authorized_effect_missing"),
            ("effect_completed", "effect_not_completed"),
            ("observed_result", "effect_observed_result_mismatch"),
            ("error_code", "effect_error_present"),
            ("receipt_present", "effect_receipt_missing"),
        )
        for field, reason in cases:
            ledger, evaluation, effect, outcome = release_bundle()
            if field == "binding":
                altered = replace(
                    effect, binding=replace(effect.binding, target="other")
                )
            elif field in {"authorized_effect", "effect_completed", "receipt_present"}:
                altered = replace(effect, **{field: "true"})
            elif field == "error_code":
                altered = replace(effect, error_code="ERROR")
            else:
                altered = replace(effect, **{field: "other"})
            result = actual_release_gate(
                current_binding=evaluation.binding,
                pre_effect_evaluation=evaluation, action_ledger=ledger,
                effect_receipt=altered, outcome_receipt=outcome,
            )
            self.assertIn(reason, result.reasons)

    def test_44_outcome_receipt_is_exactly_bound_to_effect_and_expected_values(self) -> None:
        cases = (
            ("binding", "outcome_receipt_binding_mismatch"),
            ("pre_effect_evaluation_id", "outcome_receipt_evaluation_id_mismatch"),
            ("pre_effect_time_et", "outcome_receipt_evaluation_time_mismatch"),
            ("action", "outcome_receipt_action_mismatch"),
            ("effect_receipt_id", "outcome_effect_receipt_mismatch"),
            ("effect_time_et", "outcome_effect_time_mismatch"),
            ("observed_outcome", "observed_outcome_mismatch"),
            ("observed_visibility", "observed_visibility_mismatch"),
            ("observed_retrieval", "observed_retrieval_mismatch"),
            ("outcome_check_pass", "outcome_check_missing"),
            ("visibility_retrieval_check_pass",
             "visibility_retrieval_check_missing"),
        )
        for field, reason in cases:
            ledger, evaluation, effect, outcome = release_bundle()
            if field == "binding":
                altered = replace(
                    outcome, binding=replace(outcome.binding, target="other")
                )
            elif field in {"outcome_check_pass", "visibility_retrieval_check_pass"}:
                altered = replace(outcome, **{field: "true"})
            else:
                altered = replace(outcome, **{field: "other"})
            result = actual_release_gate(
                current_binding=evaluation.binding,
                pre_effect_evaluation=evaluation, action_ledger=ledger,
                effect_receipt=effect, outcome_receipt=altered,
            )
            self.assertIn(reason, result.reasons)

    def test_45_future_effect_and_outcome_receipts_are_denied_by_runtime_clock(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        future = (now_et() + timedelta(days=1)).isoformat()
        future_effect = replace(effect, effect_time_et=future)
        future_outcome = replace(outcome, effect_time_et=future, observed_at_et=future)
        result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=future_effect, outcome_receipt=future_outcome,
        )
        self.assertIn("effect_time_outside_authorized_window", result.reasons)
        self.assertIn("outcome_observation_time_invalid", result.reasons)

    def test_46_fake_reservation_or_changed_current_binding_is_denied(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        fake_reservation = replace(
            evaluation.reservation_receipt, reservation_id="fake-reservation"
        )
        fake_evaluation = replace(evaluation, reservation_receipt=fake_reservation)
        fake = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=fake_evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=outcome,
        )
        changed = actual_release_gate(
            current_binding=replace(evaluation.binding, artifact_manifest=b"changed"),
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=outcome,
        )
        self.assertIn("action_reservation_missing_or_invalid", fake.reasons)
        self.assertIn("release_binding_changed", changed.reasons)

    def test_47_missing_or_subclass_receipts_are_denied(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        self.assertFalse(actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=None, outcome_receipt=None,
        ).allowed)

        @dataclass(frozen=True)
        class ExtendedEffect(ReleaseEffectReceipt):
            extra: str = "unexpected"

        extended = ExtendedEffect(**effect.__dict__)
        result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=extended, outcome_receipt=outcome,
        )
        self.assertIn("effect_receipt_missing_or_invalid", result.reasons)

    def test_48_release_transition_requires_effect_evidence_tokens(self) -> None:
        result = transition_gate(
            LifecycleState.RELEASE_ELIGIBLE, LifecycleState.RELEASED,
            required_evidence=(), present_evidence={"authorized_effect"},
            tests_pass=True, policy_pass=True, owner_action=True,
        )
        self.assertEqual(result.reasons,
                         ("missing_evidence:effect_receipt,outcome_check",))

    def test_58_reservation_binds_entire_evaluation_release_binding(self) -> None:
        for change in (
            {"destination": "rewritten-destination"},
            {
                "expected_outcome": "rewritten-outcome",
                "expected_visibility": "rewritten-visibility",
                "expected_retrieval": "rewritten-retrieval",
            },
        ):
            ledger, evaluation, effect, outcome = release_bundle()
            rewritten = replace(evaluation.binding, **change)
            rewritten_evaluation = replace(evaluation, binding=rewritten)
            rewritten_effect = replace(
                effect,
                binding=rewritten,
                observed_result=rewritten.expected_outcome,
            )
            rewritten_outcome = replace(
                outcome,
                binding=rewritten,
                observed_outcome=rewritten.expected_outcome,
                observed_visibility=rewritten.expected_visibility,
                observed_retrieval=rewritten.expected_retrieval,
            )
            result = actual_release_gate(
                current_binding=rewritten,
                pre_effect_evaluation=rewritten_evaluation,
                action_ledger=ledger,
                effect_receipt=rewritten_effect,
                outcome_receipt=rewritten_outcome,
            )
            self.assertIn("action_reservation_missing_or_invalid", result.reasons)

    def test_59_reservation_binds_evaluation_id_and_time(self) -> None:
        for field, changed in (
            ("evaluation_id", "rewritten-evaluation-id"),
            ("evaluated_at", (now_et() - timedelta(seconds=1)).isoformat()),
        ):
            ledger, evaluation, effect, outcome = release_bundle()
            rewritten_evaluation = replace(evaluation, **{field: changed})
            if field == "evaluation_id":
                rewritten_effect = replace(
                    effect, pre_effect_evaluation_id=changed
                )
                rewritten_outcome = replace(
                    outcome, pre_effect_evaluation_id=changed
                )
            else:
                rewritten_effect = replace(
                    effect, pre_effect_time_et=changed, effect_time_et=changed
                )
                rewritten_outcome = replace(
                    outcome, pre_effect_time_et=changed, effect_time_et=changed,
                    observed_at_et=changed,
                )
            result = actual_release_gate(
                current_binding=evaluation.binding,
                pre_effect_evaluation=rewritten_evaluation,
                action_ledger=ledger,
                effect_receipt=rewritten_effect,
                outcome_receipt=rewritten_outcome,
            )
            self.assertIn("action_reservation_missing_or_invalid", result.reasons)

    def test_60_post_effect_verification_is_single_attempt(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        first = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=outcome,
        )
        second = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=outcome,
        )
        self.assertTrue(first.allowed, first.reasons)
        self.assertFalse(second.allowed)
        self.assertIn("release_effect_attempt_already_consumed", second.reasons)

    def test_61_failed_effect_consumes_verification_attempt(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        failed = replace(
            effect, effect_completed=False, observed_result="failed",
            error_code="SIMULATED_ERROR",
        )
        first = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=failed, outcome_receipt=outcome,
        )
        retry = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=outcome,
        )
        self.assertFalse(first.allowed)
        self.assertFalse(retry.allowed)
        self.assertIn("release_effect_attempt_already_consumed", retry.reasons)

    def test_62_malformed_reservation_identifier_fails_without_exception(self) -> None:
        ledger, evaluation, effect, outcome = release_bundle()
        malformed = replace(
            evaluation.reservation_receipt,
            release_action_id=[],  # type: ignore[arg-type]
        )
        self.assertFalse(ledger.verifies(malformed, evaluation))
        result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=replace(
                evaluation, reservation_receipt=malformed
            ),
            action_ledger=ledger,
            effect_receipt=effect,
            outcome_receipt=outcome,
        )
        self.assertIn("action_reservation_missing_or_invalid", result.reasons)

    def test_63_subsecond_future_times_are_denied(self) -> None:
        future = (now_et() + timedelta(milliseconds=700)).isoformat()
        ledger, evaluation, effect, outcome = release_bundle()
        future_evaluation = replace(evaluation, evaluated_at=future)
        future_effect = replace(
            effect, pre_effect_time_et=future, effect_time_et=future
        )
        future_outcome = replace(
            outcome, pre_effect_time_et=future, effect_time_et=future,
            observed_at_et=future,
        )
        evaluation_result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=future_evaluation,
            action_ledger=ledger,
            effect_receipt=future_effect,
            outcome_receipt=future_outcome,
        )
        self.assertIn("pre_effect_evaluation_time_invalid", evaluation_result.reasons)

        ledger, evaluation, effect, outcome = release_bundle()
        future = (now_et() + timedelta(milliseconds=700)).isoformat()
        future_effect = replace(effect, effect_time_et=future)
        future_outcome = replace(
            outcome, effect_time_et=future, observed_at_et=future
        )
        effect_result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation,
            action_ledger=ledger,
            effect_receipt=future_effect,
            outcome_receipt=future_outcome,
        )
        self.assertIn("effect_time_outside_authorized_window", effect_result.reasons)
        self.assertIn("outcome_observation_time_invalid", effect_result.reasons)

    def test_64_release_receipts_reject_hostile_field_types_without_exception(self) -> None:
        class ExplosiveEquality:
            def __eq__(self, other: object) -> bool:
                raise RuntimeError("must not compare malformed field")

        ledger, evaluation, effect, outcome = release_bundle()
        malformed_effect = replace(
            effect, pre_effect_evaluation_id=ExplosiveEquality()
        )
        result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=malformed_effect, outcome_receipt=outcome,
        )
        self.assertIn("effect_receipt_field_type_invalid", result.reasons)

        ledger, evaluation, effect, outcome = release_bundle()
        malformed_outcome = replace(
            outcome, observed_outcome=ExplosiveEquality()
        )
        result = actual_release_gate(
            current_binding=evaluation.binding,
            pre_effect_evaluation=evaluation, action_ledger=ledger,
            effect_receipt=effect, outcome_receipt=malformed_outcome,
        )
        self.assertIn("outcome_receipt_field_type_invalid", result.reasons)

    def test_66_caller_created_release_ledger_cannot_reserve_or_verify(self) -> None:
        binding = release_binding()
        caller_ledger = ReleaseActionLedger()
        ledger, result, evaluation = reserve_release(
            binding=binding, ledger=caller_ledger
        )
        self.assertIs(ledger, caller_ledger)
        self.assertFalse(result.allowed)
        self.assertIsNone(evaluation)
        self.assertIn("trusted_release_action_ledger_required", result.reasons)

        trusted, result, evaluation = reserve_release(binding=binding)
        self.assertTrue(result.allowed, result.reasons)
        assert evaluation is not None
        self.assertFalse(caller_ledger.verifies(
            evaluation.reservation_receipt, evaluation
        ))
        self.assertTrue(trusted.verifies(
            evaluation.reservation_receipt, evaluation
        ))

    def test_67_evaluation_id_is_unique_across_release_actions(self) -> None:
        evaluation_id = f"globally-unique-evaluation-{uuid4()}"
        _, first, _ = reserve_release(
            binding=release_binding(), evaluation_id=evaluation_id
        )
        _, second, _ = reserve_release(
            binding=release_binding(), evaluation_id=evaluation_id
        )
        self.assertTrue(first.allowed, first.reasons)
        self.assertFalse(second.allowed)
        self.assertEqual(
            second.reasons, ("pre_effect_evaluation_id_already_used",)
        )


if __name__ == "__main__":
    unittest.main()
