# Task Alpha classical QPU-emulator workload V1

This additive checkpoint implements one bounded, defense-gated three-qubit
GHZ circuit emulator on classical CPU compute. It uses exact Gaussian-dyadic
state arithmetic, a separately declared known-answer oracle, and exact paired
replay over every deterministic declared output plus the environment, input,
seed, and precision bindings. It records observational wall-time and traced
memory metrics outside that deterministic comparison. It performs no network,
automation, external, scheduling, signing,
biometric, release, or physical-QPU action.

The recovered Phase III policy kernel is preserved byte-for-byte under
`upstream/`. The workload verifies the recovered source's SGL Prime binding
before executing its module and uses only its strict `defense_only_gate` and
canonical JSON encoder. The gate's five inputs are fixed, schema-bound synthetic
demonstration factors; they are not evidence of external authorization.
Omega-labelled later code was inspected for chronology but is not imported,
merged, or resumed.

Run the workload tests:

```text
PYTHONPATH=src:upstream python3 -m unittest discover -s tests -p test_*.py -v
```

Run the recovered policy-kernel tests:

```text
PYTHONPATH=upstream python3 -m unittest -v upstream/test_qel_alpha_omega_contract.py
```

Build the additive evidence package and JPEG QPRINT:

```text
PYTHONPATH=src:upstream python3 tools/build_alpha_reference_workload.py
```

The workload declares the five orthogonal Alpha state axes as
`DRAFT / PROVISIONAL / PRESENT / PROJECT-RESTRICTED / HOLD` before a run. A
successful local run reports capability `EXECUTED`; the build's separately
recorded technical-evidence candidate is `TESTED / VERIFIED / PRESENT /
PROJECT-RESTRICTED / HOLD`. The inherited task head remains
`ACTIVE / HOLD / UNSIGNED / INACTIVE`, records
`runtime_sequence_advanced=false`, and does not imply owner ratification,
acceptance, release, deployment, physical quantum execution, advantage, or
external custody.
