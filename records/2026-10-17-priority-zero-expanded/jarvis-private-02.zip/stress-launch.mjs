import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),mirror=root.startsWith('D:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_02':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_02';
const script=process.argv[2],label=process.argv[3];if(!['diagnose.mjs','validate.mjs','stress.mjs'].includes(script)||!/^[a-z0-9_-]{1,60}$/.test(label))throw Error('Invalid task or label');
for(const r of [root,mirror])if(fs.existsSync(path.join(r,label)))throw Error('Existing evidence may not be overwritten');
const args=['--max-old-space-size=128','--permission','--allow-fs-read='+root,'--allow-fs-read='+mirror,'--allow-fs-write='+root,'--allow-fs-write='+mirror,'--experimental-vm-modules',path.join(root,script),label,mirror];
const log=v=>{const b=JSON.stringify({at_utc:new Date().toISOString(),...v})+'\n';for(const r of [root,mirror])fs.appendFileSync(path.join(r,label+'_launcher.ndjson'),b);process.stdout.write(b);};
const child=spawn(process.execPath,args,{cwd:root,env:{SystemRoot:process.env.SystemRoot,WINDIR:process.env.WINDIR,PATH:path.dirname(process.execPath)},windowsHide:true,stdio:['ignore','pipe','pipe']});
try{os.setPriority(child.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);}catch(e){log({stage:'priority_unavailable',error:String(e)});}
log({stage:'launched',pid:child.pid,args,host:os.hostname(),free_memory_bytes:os.freemem()});
const timeout=setTimeout(()=>{log({stage:'timeout',budget_ms:1200000});child.kill();},1200000);
for(const [s,name] of [[child.stdout,'stdout'],[child.stderr,'stderr']])s.on('data',b=>{for(const r of [root,mirror])fs.appendFileSync(path.join(r,label+'_'+name+'.log'),b);process[name==='stdout'?'stdout':'stderr'].write(b);});
child.on('error',e=>{clearTimeout(timeout);log({stage:'launch_error',error:String(e)});process.exitCode=1;});
child.on('close',(code,signal)=>{clearTimeout(timeout);log({stage:'exit',code,signal,free_memory_bytes:os.freemem()});process.exitCode=code===0?0:1;});
