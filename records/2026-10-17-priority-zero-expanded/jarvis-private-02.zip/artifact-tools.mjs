// Private portable replay and read-only verification. Sherman G. Laing / GAUCIA.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
import {hashBytes} from './vendor/sgl-prime.mjs';
const root=path.dirname(fileURLToPath(import.meta.url)),usb='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_02',laptop='./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_02',mirror=root.toLowerCase().startsWith('d:')?laptop:usb;
const walk=(dir,prefix='')=>fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name)).flatMap(e=>{if(e.isSymbolicLink())throw Error('Symbolic link rejected');const rel=prefix+e.name;return e.isDirectory()?walk(path.join(dir,e.name),rel+'/'):[rel];});
function verify(){
 const manifest=JSON.parse(fs.readFileSync(path.join(root,'MANIFEST.sgl.json'),'utf8')),expected=manifest.files.map(r=>r.file).sort();
 for(const base of [root,mirror]){
  const actual=walk(base).filter(f=>!['MANIFEST.sgl.json','FINAL_VERIFY.json'].includes(f)).sort();if(JSON.stringify(actual)!==JSON.stringify(expected))throw Error('Snapshot file set differs: '+base);
  for(const row of manifest.files){const b=fs.readFileSync(path.join(base,row.file));if(b.length!==row.bytes||hashBytes(b,manifest.purpose)!==row.identity)throw Error('Fingerprint mismatch: '+row.file);}
 }
 for(const f of [...expected,'MANIFEST.sgl.json','FINAL_VERIFY.json'])if(!fs.readFileSync(path.join(root,f)).equals(fs.readFileSync(path.join(mirror,f))))throw Error('Mirror mismatch: '+f);
 const receipt=JSON.parse(fs.readFileSync(path.join(root,'FINAL_VERIFY.json'),'utf8'));if(receipt.manifest_identity!==hashBytes(fs.readFileSync(path.join(root,'MANIFEST.sgl.json')),'jarvis-pass2-manifest'))throw Error('Manifest receipt mismatch');
 console.log(JSON.stringify({verified:true,manifest_files:expected.length,mirrored_files:expected.length+2,signature:'UNSIGNED',meaning:'Local consistency check; no owner authentication.'}));return manifest;
}
async function replay(mode){
 if(!['quick','full'].includes(mode))throw Error('Use verify, quick, or full');
 if(fs.existsSync(path.join(root,'CONTINUATION.lock')))throw Error('Initial continuation is still running');
 const stamp=new Date().toISOString().replace(/[-:.TZ]/g,'')+'_'+process.pid,name='JARVIS_Private_20260920_02_Replay_'+stamp,bases=[path.join(path.dirname(root),name),path.join(path.dirname(mirror),name)];
 for(const b of bases)fs.mkdirSync(b);
 const include=['baseline.mjs','candidate.mjs','runtime.mjs','diagnose.mjs','validate.mjs','metamorphic.mjs','stress.mjs','CONTRACT.json','INVARIANCE_CONTRACT.json','STRESS_CONTRACT.json','vendor','inputs','references','prior','provenance'];
 for(const rel of include)for(const b of bases)fs.cpSync(path.join(root,rel),path.join(b,rel),{recursive:true,errorOnExist:true,force:false});
 const copied=walk(bases[0]);for(const f of copied)for(const b of bases)if(!fs.readFileSync(path.join(root,f)).equals(fs.readFileSync(path.join(b,f))))throw Error('Replay input copy mismatch');
 const save=(f,v)=>{const data=JSON.stringify(v,null,2)+'\n';for(const b of bases)fs.writeFileSync(path.join(b,f),data,{flag:'wx'});};
 save('REPLAY_START.json',{owner:'Sherman G. Laing',mode,started_utc:new Date().toISOString(),source:root,copied_files:copied,signature:'UNSIGNED'});
 const tasks=mode==='quick'?[['diagnose.mjs','diagnosis_01']]:[['diagnose.mjs','diagnosis_01'],['validate.mjs','validation_01'],['metamorphic.mjs','invariance_01'],['stress.mjs','stress_01']];
 try{
 for(const [script,label] of tasks){
  const args=['--max-old-space-size=128','--permission',...bases.map(b=>'--allow-fs-read='+b),...bases.map(b=>'--allow-fs-write='+b),'--experimental-vm-modules',path.join(bases[0],script),label,bases[1]];
  await new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{cwd:bases[0],env:{SystemRoot:process.env.SystemRoot,WINDIR:process.env.WINDIR,PATH:path.dirname(process.execPath)},windowsHide:true,stdio:['ignore','pipe','pipe']});
   try{os.setPriority(child.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);}catch(e){console.log('Priority could not be lowered: '+e);}
   const timer=setTimeout(()=>child.kill(),1200000);
   for(const [s,n] of [[child.stdout,'stdout'],[child.stderr,'stderr']])s.on('data',b=>{for(const dir of bases)fs.appendFileSync(path.join(dir,label+'_'+n+'.log'),b);process[n].write(b);});
   child.on('error',e=>{clearTimeout(timer);reject(e);});child.on('close',(code,signal)=>{clearTimeout(timer);code===0?resolve():reject(Error(label+' exited '+code+' '+signal));});
  });
 }
 const groups=tasks.map(([,label])=>{const expected=fs.readdirSync(path.join(root,label)).filter(f=>f.endsWith('.json')&&f!=='execution.json').sort(),actual=fs.readdirSync(path.join(bases[0],label)).filter(f=>f.endsWith('.json')&&f!=='execution.json').sort();if(JSON.stringify(expected)!==JSON.stringify(actual))throw Error('Replay result set differs');const files=expected.map(f=>({file:f,equal:fs.readFileSync(path.join(root,label,f)).equals(fs.readFileSync(path.join(bases[0],label,f)))}));return {label,files,exact:files.every(r=>r.equal)};});
 if(groups.some(g=>!g.exact))throw Error('Numerical replay differs');
 const files=walk(bases[0]);if(JSON.stringify(files)!==JSON.stringify(walk(bases[1])))throw Error('Replay mirror file set differs');for(const f of files)if(!fs.readFileSync(path.join(bases[0],f)).equals(fs.readFileSync(path.join(bases[1],f))))throw Error('Replay mirror differs');
 save('REPLAY_RESULT.json',{owner:'Sherman G. Laing',completed_utc:new Date().toISOString(),mode,groups,all_exact:true,mirror_bytes_equal:true,bases,signature:'UNSIGNED'});console.log('Replay complete: '+bases[0]);
 }catch(e){save('REPLAY_FAILURE.json',{error:String(e),stack:e.stack});throw e;}
}
try{const mode=process.argv[2]||'verify';if(mode==='verify')verify();else await replay(mode);}catch(e){console.error(e);process.exitCode=1;}

