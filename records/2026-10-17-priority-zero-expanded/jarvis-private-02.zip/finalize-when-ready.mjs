// Finish the private checkpoint after the existing sequential queue.
import fs from 'node:fs';import path from 'node:path';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),mirror=root.toLowerCase().startsWith('d:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_02':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_02';
async function execute(script,...args){return new Promise((resolve,reject)=>{const child=spawn(process.execPath,[path.join(root,script),...args],{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});child.stdout.on('data',b=>process.stdout.write(b));child.stderr.on('data',b=>process.stderr.write(b));child.on('error',reject);child.on('close',(code,signal)=>code===0?resolve():reject(Error(script+' exit '+code+' '+signal)));});}
try{
 console.log('Waiting for the existing sequential continuation.');
 const until=Date.now()+1200000;while(fs.existsSync(path.join(root,'CONTINUATION.lock'))){if(Date.now()>until)throw Error('Queue wait timed out');await new Promise(r=>setTimeout(r,3000));}
 const replay=JSON.parse(fs.readFileSync(path.join(root,'REPLAY_VERIFICATION.json'),'utf8'));if(!replay.all_exact)throw Error('Full replays are not exact');
 const parent=path.dirname(root),before=new Set(fs.readdirSync(parent));
 console.log('Full replays complete. Testing the fresh-folder quick replay.');
 await execute('artifact-tools.mjs','quick');
 const created=fs.readdirSync(parent).filter(n=>!before.has(n)&&n.startsWith('JARVIS_Private_20260920_02_Replay_'));if(created.length!==1)throw Error('Ambiguous portable replay output');
 const dir=path.join(parent,created[0]),record=JSON.parse(fs.readFileSync(path.join(dir,'REPLAY_RESULT.json'),'utf8'));
 if(!record.all_exact||!record.mirror_bytes_equal)throw Error('Portable replay check failed');
 const receipt={recorded_utc:new Date().toISOString(),owner:'Sherman G. Laing',signature:'UNSIGNED',all_exact:true,mode:record.mode,compared_json_files:record.groups.reduce((n,g)=>n+g.files.length,0),mirror_bytes_equal:true,bases:record.bases,groups:record.groups,note:'Fresh-folder quick mode executed and compared exactly. Full numerical suites were separately replayed in validation_02 and stress_02; the full portable wrapper was not run end to end.'};
 for(const r of [root,mirror])fs.writeFileSync(path.join(r,'PORTABLE_REPLAY_VERIFICATION.json'),JSON.stringify(receipt,null,2)+'\n',{flag:'wx'});
 console.log('Finalizing the checkpoint and checking the saved manifest.');
 await execute('evidence-finalize.mjs');await execute('artifact-tools.mjs','verify');
 console.log('PRIVATE_CHECKPOINT_COMPLETE');
}catch(e){console.error(e);process.exitCode=1;}
