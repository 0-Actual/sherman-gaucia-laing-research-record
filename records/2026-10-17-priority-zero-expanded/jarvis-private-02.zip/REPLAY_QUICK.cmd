@echo off
setlocal
"./REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe" "%~dp0artifact-tools.mjs" quick
if errorlevel 1 echo The operation failed. Review the message above; existing evidence was retained.
pause
