# Private JARVIS second-pass report

Owner: Sherman G. Laing. Assistant role: GAUCIA. PRIVATE. UNSIGNED.

The original failing case is resolved with the same Q8 circuit engine and the same 18-parameter ansatz. The correction is confined to this private test folder; the production engine is unchanged. The change is a coupled BFGS optimizer with parameter-shift gradients following the original coordinate warmup. The optimizer receives the Hamiltonian and seeded starting parameters; it does not receive reference eigenvalues or eigenvectors.

## Measured results

| Check | Result |
|---|---|
| Expanded JARVIS path and new points | 42/42 meet 1e-6 eV |
| Random and near-failure JARVIS stress cases | 24/24 meet 1e-6 eV |
| Synthetic known-spectrum energy cases | 6/6 meet 1e-6 eV |
| Worst absolute energy error across the 72 ordered cases | 3.418203515792584e-7 eV |
| Full complex circuit comparisons in expanded validation | 126 passed |
| Phase, basis, energy-offset, gradient and perturbation checks | 61/61 passed |
| Synthetic state or ground-subspace fidelity >= 0.9999 | 4/6; two documented misses |

The expanded 42 cases contain 28 unique k-points; repeated path points are retained deliberately. The 24 additional material stress cases test 12 seeded random points, including negative coordinates, and 12 small displacements around the original miss. Across the 66 ordered material cases there are 52 distinct k-points. These are still the same JARVIS aluminum material, JVASP-816. The six synthetic matrices have known spectra and known ground states or ground subspaces.

The independent classical control reconstructed the Wannier Hamiltonians from 1,041 blocks and 66,624 complex entries. Its 192 band predictions differ from the rounded official reference by MAE 2.3408413332703937e-9 eV; the largest difference from saved NumPy results is 1.7763568394002505e-14 eV. This classical control is JavaScript. Archived Python kernels were not executed in this pass.

## What changed and what the diagnosis supports

The best prior 256-sweep result missed the 1e-4 eV target by ending at a gap of 0.00012074495903213744 eV. Refining each of its four saved starts brought the energy to the reference within about 3e-15 eV. Wrapping angles alone changed energies by at most 5.33e-15 eV; the improvement came from coupled optimization. Gradient crosschecks agreed with central differences within 4.10e-11.

The cold seeded validation also resolved original index 4: signed energy error -9.769962616701378e-15 eV and residual 7.326559381043061e-9 eV. Tiny negative errors are floating-point rounding, not energies physically below the ground state.

Each cold case used two starts, 12 coordinate warmup sweeps, and at most 400 BFGS iterations per start. Of 84 expanded-validation starts, 33 stopped at the gradient tolerance and 51 used the iteration budget. Passing an energy target does not mean every optimizer stopping criterion converged. The largest expanded-validation state residual was 0.0008444199310936169 eV.

## Documented state-fidelity limits

| Synthetic first excitation gap | Absolute energy error | Ground fidelity | Fidelity target |
|---|---|---|---|
| 1 eV | 1.7309182045149725e-16 eV | 0.9999999999999996 | Pass |
| 0.01 eV | 2.867544230671934e-16 eV | 0.9999999999999996 | Pass |
| 0.0001 eV | 1.4615633666782124e-9 eV | 0.9999860801387452 | Pass |
| 0.000001 eV | 5.61226507949274e-8 eV | 0.9438801949621364 | Miss |
| 1e-8 eV | 2.762947736350209e-9 eV | 0.7237052008836223 | Miss |
| 0 eV | 2.3637152502432897e-16 eV | 0.999999999999999 | Pass (two-dimensional subspace) |

The synthetic ground states were deliberately representable by the unchanged ansatz. The 1e-6 and 1e-8 eV-gap cases passed energy accuracy but missed state fidelity under the fixed optimizer settings and budget. The 1e-8 eV-gap case met the gradient tolerance as well. An energy estimate and a small gradient or residual can therefore be insufficient to identify a unique ground state when the gap is tiny. For exactly degenerate ground states, the appropriate comparison is projection onto the full ground subspace.

STATE_QUALITY.json records a separate acceptance rule and a spectral-gap calculation for the 42 material cases. Its finite-precision, allowance-adjusted lower estimates all exceed 0.9999; these are diagnostic estimates, not interval-arithmetic certificates.

## Reproducibility and cost

- validation_01 versus validation_02: 93 deterministic JSON files agree byte for byte.
- stress_01 versus stress_02: 67 deterministic JSON files agree byte for byte.
- A fresh-folder quick replay reproduced all 9 diagnostic JSON files exactly.
- Timing, process IDs, event timestamps, and resource measurements are deliberately excluded from deterministic-result comparisons. The portable quick command was executed; the full portable wrapper was not separately run end to end, although its complete numerical stages were replayed.

| Run | Elapsed seconds | Sampled peak RSS MiB |
|---|---|---|
| diagnosis_01 | 11.93 | 81.1 |
| validation_01 | 473.70 | 194.4 |
| invariance_01 | 1.29 | 54.6 |
| stress_01 | 248.24 | 191.0 |
| validation_02 | 436.27 | 193.7 |
| stress_02 | 246.99 | 187.1 |

The expanded validation required 1011684 objective evaluations; the 30-case stress suite required 568630. All runs used native Node v24.20.0 on the connected Windows laptop, one numerical job at a time, below-normal priority where available, and a 128 MiB JavaScript heap limit. Total process RSS is larger than that heap limit. Each numerical child had a 20-minute timeout. No quantum hardware or speed advantage was measured.

## Local use and evidence

Open READ_FIRST.txt for the file map. VERIFY_PRIVATE.cmd checks fingerprints and laptop/USB byte equality. REPLAY_QUICK.cmd repeats the four saved-state diagnostic starts in new sibling folders. REPLAY_FULL.cmd repeats diagnosis, 42-case validation, invariance checks, and 30-case stress in new sibling folders; it can take about 13 minutes or longer depending on laptop load. Both drives must be available. Existing results are not overwritten.

The first pass remains unchanged. Its 128 manifest-covered files were reverified on both drives, and 19 copied source artifacts match their originals. MANIFEST.sgl.json uses SGL Prime profile 3 over BLAKE2b-512; FINAL_VERIFY.json records the mirror comparison and manifest identity. These are unsigned fingerprints, not an authenticated owner signature, hardware write protection, or proof of authorship.

The circuit modules execute inside a restricted JavaScript context without host or network bindings, with a fixed local module allowlist; numerical children have filesystem permission limits. This is not OS-wide network isolation. No GitHub publication, new downloads, or language-model weight training occurred. Source licenses and original evidence remain included.

One orchestration reference error was corrected before writing the candidate file or running numerical tests. No numerical result was discarded to hide a failed target. All measured limits above remain part of the checkpoint.
