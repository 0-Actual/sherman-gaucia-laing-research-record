// Sequential private continuation. Existing runs are preserved; only this task's child is supervised.
import fs from 'node:fs';import path from 'node:path';import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url)),mirror=root.startsWith('D:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_02':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_02';
const roots=[root,mirror],lock=path.join(root,'CONTINUATION.lock');
fs.writeFileSync(lock,JSON.stringify({pid:process.pid,started_utc:new Date().toISOString()}),{flag:'wx'});
function note(stage,detail={}){const event={at_utc:new Date().toISOString(),stage,...detail};for(const r of roots)fs.appendFileSync(path.join(r,'CONTINUATION.ndjson'),JSON.stringify(event)+'\n');console.log(JSON.stringify(event));}
function completed(label){const p=path.join(root,label+'_launcher.ndjson');if(!fs.existsSync(p))return false;const rows=fs.readFileSync(p,'utf8').trim().split('\n').map(JSON.parse);const last=rows.at(-1);if(last.stage==='exit'&&last.code!==0)throw Error('Run failed: '+label);return last.stage==='exit'&&last.code===0;}
async function execute(launcher,script,label){
 if(completed(label)){note('verified_prior_completion',{label});return;}
 if(fs.existsSync(path.join(root,label)))throw Error('Partial existing run requires inspection: '+label);
 note('starting',{label});
 await new Promise((resolve,reject)=>{
  const child=spawn(process.execPath,[path.join(root,launcher),script,label],{cwd:root,windowsHide:true,stdio:['ignore','pipe','pipe']});
  for(const [s,name] of [[child.stdout,'stdout'],[child.stderr,'stderr']])s.on('data',b=>{for(const r of roots)fs.appendFileSync(path.join(r,'CONTINUATION_'+name+'.log'),b);process[name==='stdout'?'stdout':'stderr'].write(b);});
  child.on('error',reject);child.on('close',(code,signal)=>code===0?resolve():reject(Error(label+' exit '+code+' '+signal)));
 });
 if(!completed(label))throw Error('Missing completion record: '+label);note('finished',{label});
}
try{
 note('continuation_started',{pid:process.pid});
 const until=Date.now()+1200000;while(!completed('validation_01')){if(Date.now()>until)throw Error('Initial validation timeout');await new Promise(r=>setTimeout(r,3000));}
 await execute('launch.mjs','metamorphic.mjs','invariance_01');
 await execute('stress-launch.mjs','stress.mjs','stress_01');
 await execute('launch.mjs','validate.mjs','validation_02');
 await execute('stress-launch.mjs','stress.mjs','stress_02');
 const groups=[];
 for(const [a,b] of [['validation_01','validation_02'],['stress_01','stress_02']]){
  const files=fs.readdirSync(path.join(root,a)).filter(f=>f.endsWith('.json')&&f!=='execution.json').sort(),other=fs.readdirSync(path.join(root,b)).filter(f=>f.endsWith('.json')&&f!=='execution.json').sort();
  if(JSON.stringify(files)!==JSON.stringify(other))throw Error('Replay file set differs');
  const rows=files.map(f=>({file:f,equal:fs.readFileSync(path.join(root,a,f)).equals(fs.readFileSync(path.join(root,b,f)))}));
  if(rows.some(r=>!r.equal))throw Error('Replay values differ');groups.push({original:a,replay:b,files:rows,compared:rows.length,exact:true});
 }
 const record={recorded_utc:new Date().toISOString(),groups,all_exact:true,signature:'UNSIGNED'};
 for(const r of roots)fs.writeFileSync(path.join(r,'REPLAY_VERIFICATION.json'),JSON.stringify(record,null,2),{flag:'wx'});
 note('continuation_complete',{groups:groups.map(g=>({original:g.original,replay:g.replay,compared:g.compared,exact:g.exact}))});
}catch(error){note('continuation_failed',{error:String(error),stack:error.stack});process.exitCode=1;}
finally{fs.unlinkSync(lock);}
