# Q8 research process: three selected accounts

**Prepared for owner review, October 16, 2026. Not published.**

Research history of Sherman Gaucia Laing / Quantum.Earth.Laing. GAUCIA Actual is the primary project agent; Codex supports this documentary review. Historical reports retain their own attribution to GAUCIA.

These accounts follow three connected parts of the September 20, 2026 Q8/JARVIS work. They overlap earlier development chains and are not three newly discovered or independently counted studies. They show how an initial result raised a question, how a revision addressed it, and what remained unresolved.

Source keys refer to exact retained identities in [SOURCE_INDEX.json](SOURCE_INDEX.json). Contracts, code, execution receipts and later explanations have different evidential roles. None supplies a complete original conversation. Reported runs were not repeated for this draft, and a precise saved timestamp is not independent authentication of when an idea first arose.

## 1. A missed energy target led to a controlled optimizer diagnosis

The initial material study asked whether an unchanged Q8 circuit could approach the lowest eigenvalue of an eight-orbital aluminum model. Its circuit had 18 RY/RZ parameters. The optimizer changed one angle at a time: three energy evaluations described that angle’s sinusoidal dependence, allowing a proposed coordinate update to be checked. The first budget allowed two seeded starts and at most 12 sweeps. Five of six selected cases met the fixed energy-gap goal of 0.0001 eV. Original point 4 did not: its gap was 0.0004007142024144983 eV. Sources: `J12-01`, `J12-02`.

The first response was to increase the budget. Four starts and 64 sweeps reduced the gap to 0.00014289359835650828 eV. A further 256-sweep attempt reached 0.00012074495903213744 eV. Both were improvements, and both still missed the unchanged target. They revisited an already inspected point; they were not fresh held-out tests. Saved receipts place the initial run at 15:32:58.629–15:33:05.770 UTC, followed by those attempts at approximately 15:35 and 15:36 UTC. Their separate elapsed-time fields are preserved without assuming they equal subtraction of wall-clock timestamps. Sources: `J12-01`, `J12-03`–`J12-05`.

The first report did not pretend to have isolated the cause. It explicitly left open whether the difficulty came from the optimization landscape, the circuit’s expressivity, or another numerical limitation. The next contract made that uncertainty testable: restart all four saved states with the same circuit and engine, and cross-check parameter-shift gradients against central differences. This is recorded diagnostic intent, rather than a reconstructed account of an original conversation. Sources: `J12-01`, `J12-10`.

The revision retained coordinate warmup, then added coupled BFGS updates across all 18 parameters, with bounded steps and guarded line-search and inverse-Hessian updates. The optimizer did not receive reference eigenvalues or eigenvectors. The diagnosis also checked whether merely wrapping angles explained the improvement; that changed energy by at most approximately 5.33 × 10⁻¹⁵ eV. Sources: `J12-07`–`J12-09`.

All four saved starts then reached energies within approximately 2.67 × 10⁻¹⁵ eV of the reference. The gradient cross-check’s largest difference was approximately 4.10 × 10⁻¹¹. The saved diagnosis explicitly interprets this as evidence that the unchanged ansatz could meet this target and that coupled optimization resolved the earlier miss for the tested starts. That supports a case-specific optimizer explanation, not universal expressivity or global convergence. Sources: `J12-09`, `J12-11`.

Expanded testing passed the 10⁻⁶ eV energy criterion in 72 ordered cases: 66 material cases representing 52 distinct coordinates, plus six synthetic cases. Yet two synthetic fidelity tests failed, and 51 of 84 expanded-validation starts exhausted their iteration budget. The next question therefore became whether accurate energy also meant an accurate state. Source: `J12-06`.

## 2. Energy success exposed state and target-construction problems

The two synthetic misses had fidelities approximately 0.943880 and 0.723705 against a 0.9999 requirement, despite passing the energy criterion. The later retained explanation uses the spectral-gap relationship to explain why a small energy error may give a weak state-accuracy guarantee when the gap is tiny. This was a reason to assess energy and state fidelity separately, rather than discard the successful energy results. Sources: `J12-06`, `J3-FINAL`.

An intermediate Newton/curvature diagnostic preserved six synthetic cases with 12 starting states. All 12 passed its circuit-correctness check, 11 passed energy, and only seven passed fidelity. A subsequent classical Rayleigh/inverse-refinement method followed by Q8 circuit fitting reached ten fidelity passes among 12 starts. The selected previous starts succeeded, but the remaining misses still mattered. These intermediate populations must remain visible beside the later larger comparison. Sources: `J3-NEWTON-DIAG`, `J3-HYBRID-DIAG`.

In the 720-case matched study, the previous optimizer achieved 424 full acceptances and the first Rayleigh repair achieved 681. A diagnostic separated target quality from fitting quality: all 39 first-repair misses fitted their supplied targets accurately, while target iteration had stalled using a distant lower-bound shift. A good fit to an inadequate target was still an inadequate answer. Sources: `J3-FINAL`, `J3-TARGET`.

The recorded mathematical explanation describes how, in an explanatory two-level model, a distant shift produces little progress when the spectral gap is very small. The applied correction brackets the lowest eigenvalue and chooses a nearby inverse-iteration shift. Centering and positive scaling address represented-matrix conditioning; bounded perturbed starts address unsuitable stationary starts. Separate acceptance gates retain finite-value, normalization, circuit-consistency, reference and fidelity requirements. Sources: `J3-BRACKETED`, `J3-CONDITIONED`, `J3-ACCEPTANCE`.

There is an important chronology limit. The bracketed diagnostic ran at 17:27:00.201 UTC; the saved target-stagnation explanatory analysis ran later, at 20:49:03.879 UTC. The later analysis documents and supports the explanation, but does not establish the original moment of insight or prove that its written reasoning preceded the code change. Sources: `J3-BRACKET-TIME`, `J3-TARGET-TIME`.

The bracketed revision initially recorded 720 full acceptances. A later initialization review found that seed reuse had made one synthetic control already solved: its initial fidelity was approximately 0.9999999999999993. Preserving the original record and excluding that control gives 423/719 baseline, 680/719 first-repair and 719/719 revised acceptances. The improvements of 296 and 39 remain unchanged. Separate random streams and rejection of already-solved starts supported a new confirmation, beginning at fidelity 0.09613601511106884 and reaching approximately one in 47 iterations. Sources: `J3-SEED`, `J3-SEED-CODE`, `J3-FINAL`.

This process established bounded corrections and a more careful test population. It did not prove universal convergence. The target was constructed classically before circuit fitting; the floating-point bracket was not an interval certificate. The final explanation is marked `PREPARED_NOT_DELIVERED`, so its preservation does not verify delivery of an original chat. Source: `J3-FINAL`.

## 3. Reusing computation improved a measured workload

The corrected hybrid still repeated circuit evaluations and material-file parsing. The next source-study record explicitly proposed applying published numerical and measurement methods while retaining the three-qubit circuit and independent checks. It credits reverse-mode differentiation work by Jones and Gacon and records lessons about profiling stages, repeated comparisons and small-gap scoring. These are historical citations and application notes, not sources newly revalidated for this draft. Source: `J4-METHOD`.

The implementation replaced repeated shifted-circuit evaluations with a dense typed-array adjoint calculation. For the declared 18-angle circuit, the recorded comparison is 36 complete forward evaluations versus one forward circuit, one Hamiltonian-vector product and 44 reverse gate applications for 22 gates. A validated binary model cache addressed repeated parsing. These were explicit implementation changes, not evidence that general reverse differentiation or caching had been invented here. Sources: `J4-METHOD`, `J4-ADJOINT`, `J4-FAST`, `J4-CACHE`.

Correctness was checked separately from speed. The saved validation passed 512 state comparisons and 1,152 derivative-component checks against separate calculations. The performance study compared five methods over 24 cases repeated three times, producing 360 timed method runs. Those are repeated comparisons on 24 cases, not 360 independent scientific problems. Sources: `J4-VALIDATION`, `J4-PERFORMANCE`, `J4-BENCH`.

Both old and optimized hybrids passed their 72 timed runs. Aggregate solver time changed from approximately 528.546 seconds to 8.027 seconds, a reported ratio of 65.85. Complete fresh-process requests used another boundary: three points, three repetitions and three modes, totaling 27 requests. Their old-versus-optimized means were approximately 17.248 and 3.679 seconds, a ratio of 4.69. Operating-system caches were not cleared. Sources: `J4-PERFORMANCE`, `J4-REQUESTS`, `J4-HANDOFF`.

The unfavorable comparisons remain part of the process. Energy-only optimization passed 54 of 72 timed runs. Direct classical solving remained cheaper when circuit parameters were unnecessary. The hybrid still constructed a classical target before fitting, so the measured improvement did not establish physical quantum advantage, target-free discovery or whole-Windows acceleration. Source: `J4-HANDOFF`.

A later static audit also found a descriptive mistake: `q8-fast.optimizeCandidate` retained a parameter-shift label although its default refinement path used adjoint gradients. That metadata issue is separate from the source mechanics and numerical comparisons; this draft does not claim it has been installed or corrected in historical code. Source: `J4-FAST`; linked deep-audit finding `Q8-DEEP-03`.

The prepared handoff’s next question was explicit: investigate solving without a precomputed target, then method selection and larger workloads. It remained a proposal at that checkpoint. The handoff and session closure do not verify chat delivery or establish that the proposed next study had been executed. Sources: `J4-HANDOFF`, `J4-CLOSURE`.
