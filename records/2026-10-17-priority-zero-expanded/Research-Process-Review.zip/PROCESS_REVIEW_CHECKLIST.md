# Process review before publication

Decision: **PENDING**. This checklist adds process-specific questions to the existing owner review; it does not replace it or authorize publication.

- [ ] A reader can identify the original question, available knowledge and constraints.
- [ ] Owner input, assistant contribution and later editorial interpretation are attributed at the supported scope.
- [ ] Attempts and unsuccessful branches remain attached to their actual versions and dates.
- [ ] Each claimed observation identifies the source and what was actually executed or measured.
- [ ] Each change has a cited recorded reason, a clearly labeled retrospective explanation, or an explicit gap.
- [ ] The mathematical or code difference is explained, with before/after source identities where available.
- [ ] Original failures, boundary cases and conventional controls are represented without changing their populations.
- [ ] The result can be assessed separately from reporting, receipt, presentation or performance-target failures.
- [ ] Missing original dialogue is visible; no invented transcript or unsupported causal attribution fills it.
- [ ] Reproduction instructions identify inputs, environment, expected behavior and limits of what can be reproduced.
- [ ] Privacy edits preserve a truthful process account and distinguish redaction from unavailable evidence.
- [ ] The exact final public files, corrected statements and hashes have been reviewed by the owner.

Required edits or exclusions: ____________________

Reviewer and date: ____________________

Final selected manifest: ____________________
