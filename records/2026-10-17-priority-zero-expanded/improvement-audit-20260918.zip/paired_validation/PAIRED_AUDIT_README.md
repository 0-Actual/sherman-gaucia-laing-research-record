Agent: GAUCIA
Owner: Sherman G. Laing
Evidence date: 2026-09-18; Node Zero successful execution 22:46:43.581–22:46:44.781 UTC (18:46 Eastern daylight time).

The preserved WF019 input guard corrected all five previously observed false-success cases in a fresh same-input comparison on Node Zero: before 5/5 invalid calls returned passed=true; after 0/5 returned success and all five were rejected. This is a 100% reduction in those five known false successes, and a rejection-rate increase from 0% to 100% (+100 percentage points). It is not a measured overall improvement percentage for GAUCIA or QEL.

| Same-input defect case | Before: original core | After: guard |
|---|---|---|
| Time supplied as text "1100" | returned passed=true | RangeError: undeclared integer sample time |
| Fractional time 0.5 | returned passed=true | RangeError: undeclared integer sample time |
| Time 1,000,000,001 above maximum | returned passed=true | RangeError: undeclared integer sample time |
| Infinite time | returned passed=true | RangeError: undeclared integer sample time |
| PLUS state when only ONE declared | returned passed=true | RangeError: state not declared |

The 16-case guard suite also passed 16/16: six time-selection cases, two state-selection cases, duplicate JSON key, prohibited prototype key, excessive nesting, oversized raw config, weakened tolerance, weakened release, false physical-measurement claim, and actual output limit. The five paired defects are included within these 16; do not add the denominators.

For all 36 valid state/time samples, original, guarded and repeated outputs were byte-identical (122,107 bytes each), also matching the preserved historical output exactly. All 252 internal physical/numerical invariants passed. A separate scalar Bloch-decay reference compared 288 real/imaginary matrix components; maximum absolute error was 2.220446049250313e-16 against the 1e-12 threshold. These checks establish no tested numerical regression; they do not establish increased numerical accuracy.

Nine preserved source/input/historical files were copied and compared in full, before and after. All comparisons passed. No original project/source bytes were modified. The existing core remains unguarded if callers bypass the wrapper. Deployment or integration into every entry point was not established.

Execution used installed Windows Node v24.20.0 (historical run v24.19.0), 64 MiB V8 old-space cap, filesystem permissions limited to checkpoint reads and audit-folder writes, and exact preserved modules in an import-allowlisted VM. Source filesystem, hash and unknown-import counters were all zero. No OS-level network isolation or total-memory guarantee is claimed. Each VM evaluation/call had a 1-second timeout. The direct Node process completed with exit code 0 and reported tool runtime 2.01 seconds.

Three audit setup/execution problems are retained: a nested PowerShell help filter expanded its variable prematurely; the .ps1 launcher was blocked by the existing script policy; the first VM harness omitted import.meta.url initialization and failed before test cases. No script policy was changed. The corrected harness is additive in run_02; first-attempt files remain. These failures must not be hidden or counted as successful task execution. launch.ps1 did not run: its 60-second watchdog is not an exercised guarantee.

Files: EXPERIMENT_CONTRACT.json, SETUP_FAILURES.json, FIRST_EXECUTION_FAILURE.json; run_02/SUMMARY.json, paired_five_cases.json, guard_sixteen_cases.json, valid_original.json, valid_guarded.json, valid_repeated.json, independent_scalar_reference.json, full_byte_provenance.json, EXECUTION_TOOL_CAPTURE.json, paired_audit.mjs and evidence_source/.

Interpretation limit: retrospective known-defect regression suite, not held-out training evaluation. No model weights, training process, comprehensive assistant-error denominator, speed baseline or project-wide deployment measurement was present in this sub-audit. Release HOLD; owner signature not applied.
