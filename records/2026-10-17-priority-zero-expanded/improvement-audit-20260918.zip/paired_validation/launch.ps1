$ErrorActionPreference='Stop'
$auditDir=Split-Path -Parent $MyInvocation.MyCommand.Path
if(Test-Path (Join-Path $auditDir 'execution.json')) { throw 'Refuse replay over existing execution receipt' }
$nodeInfo=New-Object System.Diagnostics.ProcessStartInfo
$nodeInfo.FileName='./REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe'
$nodeInfo.Arguments='--experimental-vm-modules --permission --max-old-space-size=64 --allow-fs-read="./REDACTED_LOCAL_ROOT/QEL_Q7\Owner_Backups\20260918\QEL_Two_Hour_Work\Checkpoint_02\Record\checkpoint_02" --allow-fs-read="'+$auditDir+'" --allow-fs-write="'+$auditDir+'" "'+$auditDir+'\paired_audit.mjs"'
$nodeInfo.WorkingDirectory=$auditDir
$nodeInfo.UseShellExecute=$false
$nodeInfo.RedirectStandardOutput=$true
$nodeInfo.RedirectStandardError=$true
$nodeInfo.EnvironmentVariables.Remove('NODE_OPTIONS')
$nodeInfo.EnvironmentVariables.Remove('NODE_V8_COVERAGE')
$auditProcess=New-Object System.Diagnostics.Process
$auditProcess.StartInfo=$nodeInfo
$start=[DateTime]::UtcNow.ToString('o')
$null=$auditProcess.Start()
$outTask=$auditProcess.StandardOutput.ReadToEndAsync()
$errTask=$auditProcess.StandardError.ReadToEndAsync()
$completed=$auditProcess.WaitForExit(60000)
if(-not $completed) { $auditProcess.Kill(); $auditProcess.WaitForExit() }
$utf8=New-Object System.Text.UTF8Encoding($false)
[IO.File]::WriteAllText((Join-Path $auditDir 'stdout.txt'),$outTask.Result,$utf8)
[IO.File]::WriteAllText((Join-Path $auditDir 'stderr.txt'),$errTask.Result,$utf8)
$receipt=@{start_utc=$start;end_utc=[DateTime]::UtcNow.ToString('o');pid=$auditProcess.Id;exit_code=$auditProcess.ExitCode;completed_within_60_seconds=$completed;executable=$nodeInfo.FileName;arguments=$nodeInfo.Arguments}
[IO.File]::WriteAllText((Join-Path $auditDir 'execution.json'),($receipt | ConvertTo-Json -Depth 4),$utf8)
$receipt | ConvertTo-Json -Depth 4
$outTask.Result
$errTask.Result
