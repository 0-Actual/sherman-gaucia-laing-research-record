/* GAUCIA: bounded retrospective paired validation. All source is unchanged. */
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {pathToFileURL,fileURLToPath} from 'node:url';
const started_utc=new Date().toISOString(), clock=performance.now();
const root=path.dirname(fileURLToPath(import.meta.url));
const original=String.raw`./REDACTED_LOCAL_ROOT/QEL_Q7\Owner_Backups\20260918\QEL_Two_Hour_Work\Checkpoint_02\Record\checkpoint_02`;
const write=(name,x)=>fs.writeFileSync(path.join(root,name),Buffer.isBuffer(x)?x:JSON.stringify(x,null,2)+'\n',{flag:'wx'});
const sourceDir=path.join(root,'evidence_source');fs.mkdirSync(sourceDir);
const names=['source/wf019_core.mjs','source/wf020_core.mjs','source/WF019_CALIBRATION_CONFIG_20260904_C001.json','wf019_guard.mjs','replay_wf019.mjs','results/original_api_witnesses.json','results/guard_rejections.json','results/metrics.json','results/original_results.json'];
const copies=new Map(),provenance=[];
for(const name of names){const raw=fs.readFileSync(path.join(original,name));const dst=path.join(sourceDir,name);fs.mkdirSync(path.dirname(dst),{recursive:true});fs.writeFileSync(dst,raw,{flag:'wx'});copies.set(name,raw);provenance.push({name,bytes:raw.length,copy_equal:fs.readFileSync(dst).equals(raw)});}
let hash_attempts=0,forbidden_io_attempts=0,unknown_import_attempts=0;
const denyIO=()=>{forbidden_io_attempts++;throw Error('Source filesystem access denied in numerical VM');};
const denyHash=()=>{hash_attempts++;throw Error('Hash generation prohibited');};
const context=vm.createContext({Buffer,TextDecoder},{codeGeneration:{strings:false,wasm:false}});
const sourceNames=['source/wf019_core.mjs','source/wf020_core.mjs','wf019_guard.mjs'];
const modules=new Map();
for(const name of sourceNames){const id=pathToFileURL(path.join(sourceDir,name)).href;modules.set(id,new vm.SourceTextModule(copies.get(name).toString('utf8'),{context,identifier:id,initializeImportMeta:(meta,module)=>{meta.url=module.identifier;}}));}
const fsNames=['closeSync','existsSync','fstatSync','fsyncSync','linkSync','lstatSync','mkdirSync','openSync','readFileSync','realpathSync','unlinkSync','writeSync'];
const builtinValues={'node:crypto':{createHash:denyHash},'node:fs':Object.fromEntries(fsNames.map(n=>[n,denyIO])),'node:path':{dirname:path.dirname,relative:path.relative,resolve:path.resolve,isAbsolute:path.isAbsolute},'node:url':{fileURLToPath}};
for(const [name,values] of Object.entries(builtinValues)){modules.set(name,new vm.SyntheticModule(Object.keys(values),function(){for(const [k,v] of Object.entries(values))this.setExport(k,v);},{context,identifier:name}));}
const linker=(spec,ref)=>{const id=spec.startsWith('node:')?spec:new URL(spec,ref.identifier).href;if(!modules.has(id)){unknown_import_attempts++;throw Error('Import denied: '+spec);}return modules.get(id);};
const guardModule=modules.get(pathToFileURL(path.join(sourceDir,'wf019_guard.mjs')).href);
await guardModule.link(linker);await guardModule.evaluate({timeout:1000});
context.core=modules.get(pathToFileURL(path.join(sourceDir,'source/wf019_core.mjs')).href).namespace;
context.guard=guardModule.namespace;context.raw=copies.get('source/WF019_CALIBRATION_CONFIG_20260904_C001.json');
const run=code=>vm.runInContext(code,context,{timeout:1000});
run('config=core.strictJsonParse(raw);core.validateConfig(config,raw.length)');
const raw=context.raw,config=context.config;
const sample=run('config.model.initial_states.flatMap(state=>config.model.time_points_ns.map(time=>core.computeSample(state,time,config)))');
const bytes=Buffer.from(JSON.stringify(sample,null,2)+'\n'),guarded=run('guard.encodedBatch(raw)'),repeated=run('guard.encodedBatch(raw)');
write('valid_original.json',bytes);write('valid_guarded.json',guarded);write('valid_repeated.json',repeated);
const encodeSpecial=(k,v)=>typeof v==='number'&&!Number.isFinite(v)?{nonfinite_number:String(v)}:Object.is(v,-0)?{negative_zero:true}:v;
function observe(code){try{const value=run(code);return {returned:true,passed:value?.passed===true,value:JSON.parse(JSON.stringify(value,encodeSpecial))};}catch(e){return {returned:false,error:{name:e.name,message:e.message}};}}
function changed(fn){const c=JSON.parse(raw);fn(c);return Buffer.from(JSON.stringify(c));}
const pairs=[];
for(const [name,state,time,caseRaw] of [['string_time','ONE','1100',raw],['fractional_time','ONE',0.5,raw],['time_above_limit','ONE',1000000001,raw],['nonfinite_time','ONE',Infinity,raw],['omitted_state','PLUS',1100,changed(c=>c.model.initial_states=['ONE'])]]){
context.caseRaw=caseRaw;context.caseState=state;context.caseTime=time;
const before=observe('core.computeSample(caseState,caseTime,core.strictJsonParse(caseRaw))'),after=observe('guard.selectedSample(caseRaw,caseState,caseTime)');
pairs.push({name,state,time_type:typeof time,time_text:String(time),expected:'reject',before,after,corrected:before.returned&&before.passed&&!after.returned});
}
write('paired_five_cases.json',pairs);
const rejections=[];
function reject(name,code,caseRaw=raw,time=1100,state='ONE'){context.caseRaw=caseRaw;context.caseTime=time;context.caseState=state;const result=observe(code);rejections.push({name,expected:'reject',rejected:!result.returned,result});}
const selected='guard.selectedSample(caseRaw,caseState,caseTime)',batch='guard.encodedBatch(caseRaw)';
for(const [name,time] of [['undeclared_time',3300],['string_time','1100'],['fractional_time',0.5],['nonfinite_time',Infinity],['above_limit',1000000001],['negative_zero',-0]])reject(name,selected,raw,time);
reject('omitted_state',selected,changed(c=>c.model.initial_states=['ONE']),1100,'PLUS');reject('unknown_state',selected,raw,1100,'ZERO');
reject('duplicate_json_key',batch,Buffer.from(raw.toString().replace('"schema":','"schema":"duplicate","schema":')));
reject('prototype_key',batch,Buffer.from(raw.toString().replace('{','{"__proto__":{},')));
reject('excessive_nesting',batch,Buffer.from('['.repeat(18)+'0'+']'.repeat(18)));reject('oversized_raw_config',batch,Buffer.alloc(65537,32));
reject('weakened_tolerance',batch,changed(c=>c.numeric_policy.absolute_tolerance_decimal='1e-9'));reject('weakened_release',batch,changed(c=>c.claim_boundary.release='RELEASE'));
reject('physical_measurement_claim',batch,changed(c=>c.claim_boundary.physical_coherence='MEASURED'));reject('actual_output_byte_limit',batch,changed(c=>c.resource_policy.max_output_bytes=1024));
write('guard_sixteen_cases.json',rejections);
const reference=[];
for(const s of sample){const initial=s.state==='ONE'?[0,0,-1]:s.state==='PLUS'?[1,0,0]:[0,1,0];const e1=Math.exp(-s.time_ns/config.model.t1_ns),e2=Math.exp(-s.time_ns/config.model.t2_ns);const x=initial[0]*e2,y=initial[1]*e2,z=1-(1-initial[2])*e1;const expected=[[(1+z)/2,0],[x/2,-y/2],[x/2,y/2],[(1-z)/2,0]];const actual=s.production_density_matrix.flat().map(c=>[Number(c.re_decimal),Number(c.im_decimal)]);for(let p=0;p<4;p++)for(let q=0;q<2;q++)reference.push({state:s.state,time_ns:s.time_ns,element:p,component:q===0?'real':'imaginary',expected:expected[p][q],actual:actual[p][q],absolute_error:Math.abs(expected[p][q]-actual[p][q])});}
write('independent_scalar_reference.json',reference);
for(const p of provenance){p.original_unchanged=fs.readFileSync(path.join(original,p.name)).equals(copies.get(p.name));p.copy_still_equal=fs.readFileSync(path.join(sourceDir,p.name)).equals(copies.get(p.name));}
write('full_byte_provenance.json',provenance);
const internal=sample.flatMap(s=>s.checks),primary=pairs.filter(p=>p.corrected).length,guards=rejections.filter(x=>x.rejected).length;
const summary={agent:'GAUCIA',owner:'Sherman G. Laing',started_utc,completed_utc:new Date().toISOString(),elapsed_ms:performance.now()-clock,node_version:process.version,platform:process.platform,device:'DESKTOP-EI6MFFI',original_invalid_successes:pairs.filter(p=>p.before.passed).length,guarded_invalid_successes:pairs.filter(p=>p.after.passed).length,paired_cases:5,corrected_cases:primary,rejection_rate_before:0,rejection_rate_after:primary/5,absolute_percentage_point_gain:100*primary/5,relative_false_success_reduction_percent:100*primary/5,guard_cases:16,guard_rejections:guards,valid_samples:sample.length,internal_checks:internal.length,internal_checks_passed:internal.filter(x=>x.passed).length,valid_output_bytes:bytes.length,guarded_equals_original_bytes:bytes.equals(guarded),repeated_equals_guarded_bytes:repeated.equals(guarded),current_equals_historical_bytes:copies.get('results/original_results.json').equals(bytes),independent_component_comparisons:reference.length,independent_max_absolute_error:Math.max(...reference.map(x=>x.absolute_error)),independent_passed:reference.every(x=>x.absolute_error<=1e-12),provenance_passed:provenance.every(x=>x.copy_equal&&x.original_unchanged&&x.copy_still_equal),hash_attempts,forbidden_io_attempts,unknown_import_attempts,source_imports:'Allowlisted VM modules; no source network import/global; OS network isolation NOT asserted',memory_limit:'V8 old-space 64 MiB; not total RSS',release:'HOLD',owner_signature:null};
summary.passed=primary===5&&guards===16&&summary.valid_samples===36&&summary.internal_checks_passed===252&&summary.guarded_equals_original_bytes&&summary.repeated_equals_guarded_bytes&&summary.independent_passed&&summary.provenance_passed&&hash_attempts===0&&forbidden_io_attempts===0&&unknown_import_attempts===0;
write('SUMMARY.json',summary);console.log(JSON.stringify(summary));if(!summary.passed)process.exitCode=1;
