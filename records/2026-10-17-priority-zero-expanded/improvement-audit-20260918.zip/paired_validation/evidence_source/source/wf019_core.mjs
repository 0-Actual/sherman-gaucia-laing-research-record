/* QEL WF019: dependency-free classical single-qubit channel calibration. */

import { createHash } from 'node:crypto';
import {
  closeSync, existsSync, fstatSync, fsyncSync, linkSync, lstatSync,
  mkdirSync, openSync, readFileSync, realpathSync, unlinkSync, writeSync,
} from 'node:fs';
import { dirname, relative, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
export const CONFIG_SCHEMA = 'qel.wf019.channel-calibration-config/v1';
export const RESULT_SCHEMA = 'qel.wf019.channel-calibration-result/v1';
export const WORKFLOW_ID = 'QEL-WF019-CLASSICAL-QPU-CHANNEL-CALIBRATION';
export const EXECUTION_CLASS = 'CLASSICAL_SINGLE_QUBIT_DENSITY_MATRIX_EMULATION';
export const PURPOSE = 'PEACEFUL_CALIBRATION_FOR_SCIENCE_EDUCATION_HEALING_AND_RESOURCE_STEWARDSHIP';
export const TOLERANCE = 1e-12;
export const SGL_DOMAIN = 'SGL-PRIME/v2/FINGERPRINT';
export const SGL_PROFILE = 'QEL-SGLP2-FRAME5-SHAKE256-512-v2';
export const SGL_ALGORITHM = 'SHAKE256-512';
export const SGL_PREFIX = 'sglp2:shake256-512:';
export const SGL_KAT_SUBJECT = Buffer.from('QEL-WF018-SGL-KAT-v1', 'utf8');
export const SGL_KAT_PURPOSE = 'qel.quantum-state-coherence/known-answer/v1';
export const SGL_KAT_EXPECTED = 'sglp2:shake256-512:18fca57bd5ef2bfa8ee851731094d2101d9c98efc1749384af70ec498737afd1f3c8b47cd3dad0a439010ed0fddff9363ecd39f7f26e2ffe0bbe480635d8760a';
export const IDENTITY_BOUNDARY = 'UNKEYED_EXACT_BYTE_IDENTITY_NOT_VALIDATION_SIGNATURE_AUTHORSHIP_AUTHORIZATION_TRUTH_OR_TRUSTED_TIME';

export class WF019Error extends Error {
  constructor(code, message) {
    super(`${code}: ${message}`);
    this.name = 'WF019Error';
    this.code = code;
    this.detail = message;
  }
}

function normalizedText(value, label) {
  if (typeof value !== 'string') throw new WF019Error('WF019-TEXT', `${label} must be text`);
  for (let i = 0; i < value.length; i += 1) {
    const unit = value.charCodeAt(i);
    if (unit >= 0xd800 && unit <= 0xdbff) {
      const next = value.charCodeAt(i + 1);
      if (!(next >= 0xdc00 && next <= 0xdfff)) throw new WF019Error('WF019-SURROGATE', `${label} has a lone high surrogate`);
      i += 1;
    } else if (unit >= 0xdc00 && unit <= 0xdfff) {
      throw new WF019Error('WF019-SURROGATE', `${label} has a lone low surrogate`);
    }
  }
  return value.normalize('NFC');
}

function length64(value) {
  const output = Buffer.alloc(8);
  output.writeBigUInt64BE(BigInt(value));
  return output;
}

function frame(value) {
  const raw = Buffer.from(normalizedText(value, 'SGL frame'), 'utf8');
  return Buffer.concat([length64(raw.length), raw]);
}

export function sglp2(raw, purpose) {
  if (!Buffer.isBuffer(raw)) throw new WF019Error('WF019-SGL-BYTES', 'subject must be a Buffer');
  purpose = normalizedText(purpose, 'SGL purpose');
  if (!purpose) throw new WF019Error('WF019-SGL-PURPOSE', 'purpose must be nonempty');
  const digest = createHash('shake256', { outputLength: 64 });
  for (const field of [SGL_DOMAIN, SGL_PROFILE, SGL_ALGORITHM, purpose]) digest.update(frame(field));
  digest.update(length64(raw.length));
  digest.update(raw);
  return SGL_PREFIX + digest.digest('hex');
}

export function sha256(raw) {
  if (!Buffer.isBuffer(raw)) throw new WF019Error('WF019-SHA-BYTES', 'subject must be a Buffer');
  return createHash('sha256').update(raw).digest('hex');
}

function canonicalValue(value) {
  if (value === null || typeof value === 'boolean') return JSON.stringify(value);
  if (typeof value === 'string') return JSON.stringify(normalizedText(value, 'JSON string'));
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value)) throw new WF019Error('WF019-JSON-NUMBER', 'control numbers must be safe integers');
    return JSON.stringify(value);
  }
  if (Array.isArray(value)) return `[${value.map(canonicalValue).join(',')}]`;
  if (typeof value === 'object') {
    const normalized = new Map();
    for (const [rawKey, item] of Object.entries(value)) {
      const key = normalizedText(rawKey, 'JSON key');
      if (normalized.has(key)) throw new WF019Error('WF019-JSON-DUPLICATE', `duplicate normalized key ${key}`);
      normalized.set(key, item);
    }
    const keys = [...normalized.keys()].sort();
    return `{${keys.map((key) => `${JSON.stringify(key)}:${canonicalValue(normalized.get(key))}`).join(',')}}`;
  }
  throw new WF019Error('WF019-JSON-TYPE', `unsupported JSON type ${typeof value}`);
}

export function canonicalJson(value) {
  return Buffer.from(canonicalValue(value), 'utf8');
}

function sortedObject(value) {
  if (value === null || typeof value !== 'object') {
    canonicalValue(value);
    return typeof value === 'string' ? normalizedText(value, 'JSON string') : value;
  }
  if (Array.isArray(value)) return value.map(sortedObject);
  const normalized = new Map();
  for (const [rawKey, item] of Object.entries(value)) {
    const key = normalizedText(rawKey, 'JSON key');
    if (normalized.has(key)) throw new WF019Error('WF019-JSON-DUPLICATE', `duplicate normalized key ${key}`);
    normalized.set(key, item);
  }
  const output = {};
  for (const key of [...normalized.keys()].sort()) output[key] = sortedObject(normalized.get(key));
  return output;
}

export function renderedJson(value) {
  return Buffer.from(`${JSON.stringify(sortedObject(value), null, 2)}\n`, 'utf8');
}

export function strictJsonParse(raw, label = 'JSON input') {
  if (!Buffer.isBuffer(raw)) throw new WF019Error('WF019-JSON-BYTES', `${label} must be bytes`);
  const source = new TextDecoder('utf-8', { fatal: true }).decode(raw);
  let position = 0;
  const whitespace = () => { while (/[ \t\r\n]/u.test(source[position] ?? '')) position += 1; };
  const fail = (detail) => { throw new WF019Error('WF019-JSON-MALFORMED', `${label} at ${position}: ${detail}`); };
  const parseString = () => {
    if (source[position] !== '"') fail('expected string');
    const start = position;
    position += 1;
    while (position < source.length) {
      const unit = source[position];
      if (unit === '"') {
        position += 1;
        let value;
        try { value = JSON.parse(source.slice(start, position)); } catch { fail('invalid string escape'); }
        return normalizedText(value, 'JSON string');
      }
      if (unit === '\\') { position += 2; continue; }
      if (unit.charCodeAt(0) < 0x20) fail('unescaped control character');
      position += 1;
    }
    fail('unterminated string');
  };
  const parseValue = () => {
    whitespace();
    const unit = source[position];
    if (unit === '"') return parseString();
    if (unit === '{') {
      position += 1; whitespace();
      const output = {}; const keys = new Set();
      if (source[position] === '}') { position += 1; return output; }
      while (true) {
        whitespace(); const key = parseString();
        if (keys.has(key)) fail(`duplicate normalized key ${key}`);
        keys.add(key); whitespace();
        if (source[position] !== ':') fail('expected colon');
        position += 1; output[key] = parseValue(); whitespace();
        if (source[position] === '}') { position += 1; return output; }
        if (source[position] !== ',') fail('expected comma');
        position += 1;
      }
    }
    if (unit === '[') {
      position += 1; whitespace();
      const output = [];
      if (source[position] === ']') { position += 1; return output; }
      while (true) {
        output.push(parseValue()); whitespace();
        if (source[position] === ']') { position += 1; return output; }
        if (source[position] !== ',') fail('expected comma');
        position += 1;
      }
    }
    for (const [token, value] of [['true', true], ['false', false], ['null', null]]) {
      if (source.startsWith(token, position)) { position += token.length; return value; }
    }
    const match = /^-?(?:0|[1-9][0-9]*)/.exec(source.slice(position));
    if (!match) fail('expected integer, literal, array, or object');
    position += match[0].length;
    if (/[.eE]/.test(source[position] ?? '')) fail('floating-point controls are prohibited; use decimal strings');
    const value = Number(match[0]);
    if (!Number.isSafeInteger(value)) fail('integer exceeds exact safe range');
    return value;
  };
  const value = parseValue(); whitespace();
  if (position !== source.length) fail('trailing content');
  return value;
}

function requireInteger(value, label, minimum, maximum) {
  if (!Number.isSafeInteger(value) || value < minimum || value > maximum) {
    throw new WF019Error('WF019-CONFIG-INTEGER', `${label} must be an integer in [${minimum}, ${maximum}]`);
  }
  return value;
}

export function validateConfig(config, rawBytes = null) {
  if (!config || typeof config !== 'object' || Array.isArray(config)) throw new WF019Error('WF019-CONFIG', 'configuration must be an object');
  if (config.schema !== CONFIG_SCHEMA) throw new WF019Error('WF019-SCHEMA-QUARANTINE', `unknown schema ${String(config.schema)}`);
  if (config.workflow_id !== WORKFLOW_ID || config.execution_class !== EXECUTION_CLASS || config.purpose !== PURPOSE) {
    throw new WF019Error('WF019-CONFIG-IDENTITY', 'workflow identity, class, or peaceful purpose mismatch');
  }
  const policy = config.resource_policy;
  const model = config.model;
  if (!policy || !model) throw new WF019Error('WF019-CONFIG', 'resource_policy and model are required');
  requireInteger(policy.max_config_bytes, 'max_config_bytes', 1024, 1048576);
  if (rawBytes !== null && rawBytes > policy.max_config_bytes) throw new WF019Error('WF019-CONFIG-SIZE', 'configuration exceeds byte limit');
  requireInteger(policy.max_time_points, 'max_time_points', 1, 4096);
  requireInteger(policy.max_time_ns, 'max_time_ns', 1, Number.MAX_SAFE_INTEGER);
  requireInteger(policy.max_output_bytes, 'max_output_bytes', 1024, 16777216);
  if (policy.max_matrix_dimension !== 2) throw new WF019Error('WF019-MATRIX-DIMENSION', 'this calibration admits only one-qubit 2x2 density matrices');
  const t1 = requireInteger(model.t1_ns, 't1_ns', 1, policy.max_time_ns);
  const t2 = requireInteger(model.t2_ns, 't2_ns', 1, policy.max_time_ns);
  requireInteger(model.cycle_ns, 'cycle_ns', 1, policy.max_time_ns);
  if (t2 > 2 * t1) throw new WF019Error('WF019-NONPHYSICAL-TIMES', 'T2 must not exceed 2*T1 for the declared Markovian decomposition');
  if (!Array.isArray(model.time_points_ns) || model.time_points_ns.length === 0 || model.time_points_ns.length > policy.max_time_points) {
    throw new WF019Error('WF019-TIME-POINTS', 'time-point count is outside the declared bound');
  }
  let previous = -1;
  for (const time of model.time_points_ns) {
    requireInteger(time, 'time point', 0, policy.max_time_ns);
    if (time <= previous) throw new WF019Error('WF019-TIME-ORDER', 'time points must be unique and strictly increasing');
    previous = time;
  }
  const allowedStates = new Set(['ONE', 'PLUS', 'PLUS_I']);
  if (!Array.isArray(model.initial_states) || model.initial_states.length === 0) throw new WF019Error('WF019-STATES', 'at least one initial state is required');
  const seen = new Set();
  for (const state of model.initial_states) {
    if (!allowedStates.has(state) || seen.has(state)) throw new WF019Error('WF019-STATES', `invalid or duplicate state ${String(state)}`);
    seen.add(state);
  }
  const external = config.external_example_input;
  if (!external || external.t1_ns !== t1 || external.t2_cpmg_ns !== t2 || external.cycle_ns !== model.cycle_ns) {
    throw new WF019Error('WF019-INPUT-PROVENANCE', 'model values must match the declared external example-input record');
  }
  if (config.claim_boundary?.physical_qpu !== 'NOT_RUN' || config.claim_boundary?.release !== 'HOLD' || config.claim_boundary?.owner_signature !== 'NOT_APPLIED') {
    throw new WF019Error('WF019-CLAIM-BOUNDARY', 'physical, release, or owner-signature boundary is weakened');
  }
  const tolerance = Number(config.numeric_policy?.absolute_tolerance_decimal);
  if (!Number.isFinite(tolerance) || tolerance <= 0 || tolerance > 1e-9) throw new WF019Error('WF019-TOLERANCE', 'invalid tolerance');
  return { t1, t2, tolerance };
}

export function loadConfig(path) {
  const info = lstatSync(path);
  if (!info.isFile() || info.isSymbolicLink()) throw new WF019Error('WF019-CONFIG-FILE', 'configuration must be a regular non-link file');
  if (info.size > 65536) throw new WF019Error('WF019-CONFIG-SIZE', 'configuration exceeds hard 64 KiB intake ceiling');
  const raw = readFileSync(path);
  const value = strictJsonParse(raw, path);
  validateConfig(value, raw.length);
  return { raw, value };
}

const c = (re = 0, im = 0) => ({ re, im });
const cadd = (a, b) => c(a.re + b.re, a.im + b.im);
const cmul = (a, b) => c(a.re * b.re - a.im * b.im, a.re * b.im + a.im * b.re);
const cscale = (a, scale) => c(a.re * scale, a.im * scale);
const cconj = (a) => c(a.re, -a.im);
const cabs = (a) => Math.hypot(a.re, a.im);

function zeroMatrix() {
  return [[c(), c()], [c(), c()]];
}

function dagger(matrix) {
  return [[cconj(matrix[0][0]), cconj(matrix[1][0])], [cconj(matrix[0][1]), cconj(matrix[1][1])]];
}

function multiply(left, right) {
  const output = zeroMatrix();
  for (let row = 0; row < 2; row += 1) {
    for (let col = 0; col < 2; col += 1) {
      output[row][col] = cadd(cmul(left[row][0], right[0][col]), cmul(left[row][1], right[1][col]));
    }
  }
  return output;
}

function addMatrix(left, right) {
  return left.map((row, i) => row.map((value, j) => cadd(value, right[i][j])));
}

function operatorTerm(operator, rho) {
  return multiply(multiply(operator, rho), dagger(operator));
}

function applyKraus(rho, operators) {
  return operators.reduce((sum, operator) => addMatrix(sum, operatorTerm(operator, rho)), zeroMatrix());
}

function identityMatrix() {
  return [[c(1), c()], [c(), c(1)]];
}

function matrixMaxError(left, right) {
  let maximum = 0;
  for (let row = 0; row < 2; row += 1) for (let col = 0; col < 2; col += 1) {
    maximum = Math.max(maximum, cabs(cadd(left[row][col], cscale(right[row][col], -1))));
  }
  return maximum;
}

function completenessError(operators) {
  const sum = operators.reduce((acc, operator) => addMatrix(acc, multiply(dagger(operator), operator)), zeroMatrix());
  return matrixMaxError(sum, identityMatrix());
}

export function initialDensity(name) {
  if (name === 'ONE') return [[c(), c()], [c(), c(1)]];
  if (name === 'PLUS') return [[c(0.5), c(0.5)], [c(0.5), c(0.5)]];
  if (name === 'PLUS_I') return [[c(0.5), c(0, -0.5)], [c(0, 0.5), c(0.5)]];
  throw new WF019Error('WF019-STATE', `unknown initial state ${String(name)}`);
}

function channelParameters(timeNs, t1Ns, t2Ns) {
  const inverseTphi = (1 / t2Ns) - (1 / (2 * t1Ns));
  if (!(inverseTphi >= 0) || !Number.isFinite(inverseTphi)) throw new WF019Error('WF019-NONPHYSICAL-TIMES', 'invalid pure-dephasing rate');
  const tphiNs = inverseTphi === 0 ? Number.POSITIVE_INFINITY : 1 / inverseTphi;
  const eta1 = Math.exp(-timeNs / t1Ns);
  const lambdaPhi = Number.isFinite(tphiNs) ? Math.exp(-timeNs / tphiNs) : 1;
  const coherence = Math.sqrt(eta1) * lambdaPhi;
  if (![eta1, lambdaPhi, coherence].every((value) => Number.isFinite(value) && value >= 0 && value <= 1 + Number.EPSILON)) {
    throw new WF019Error('WF019-CHANNEL-PARAMETER', 'nonfinite or out-of-range channel parameter');
  }
  return { inverseTphi, tphiNs, eta1, lambdaPhi, coherence };
}

function productionChannel(rho, parameters) {
  const sqrtEta = Math.sqrt(parameters.eta1);
  const sqrtGamma = Math.sqrt(Math.max(0, 1 - parameters.eta1));
  const amplitude = [
    [[c(1), c()], [c(), c(sqrtEta)]],
    [[c(), c(sqrtGamma)], [c(), c()]],
  ];
  const phaseProbability = (1 - parameters.lambdaPhi) / 2;
  const phase = [
    [[c(Math.sqrt(1 - phaseProbability)), c()], [c(), c(Math.sqrt(1 - phaseProbability))]],
    [[c(Math.sqrt(phaseProbability)), c()], [c(), c(-Math.sqrt(phaseProbability))]],
  ];
  return {
    rho: applyKraus(applyKraus(rho, amplitude), phase),
    amplitudeCompletenessError: completenessError(amplitude),
    phaseCompletenessError: completenessError(phase),
  };
}

function analyticChannel(rho, parameters) {
  const gamma = 1 - parameters.eta1;
  return [
    [cadd(rho[0][0], cscale(rho[1][1], gamma)), cscale(rho[0][1], parameters.coherence)],
    [cscale(rho[1][0], parameters.coherence), cscale(rho[1][1], parameters.eta1)],
  ];
}

function physicality(rho) {
  const trace = cadd(rho[0][0], rho[1][1]);
  const hermitianError = Math.max(
    Math.abs(rho[0][0].im), Math.abs(rho[1][1].im),
    cabs(cadd(rho[0][1], cscale(cconj(rho[1][0]), -1))),
  );
  const diagonalDifference = rho[0][0].re - rho[1][1].re;
  const discriminant = Math.sqrt(Math.max(0, diagonalDifference ** 2 + 4 * cabs(rho[0][1]) ** 2));
  const minimumEigenvalue = (trace.re - discriminant) / 2;
  return {
    traceError: Math.max(Math.abs(trace.re - 1), Math.abs(trace.im)),
    hermitianError,
    minimumEigenvalue,
    finite: rho.flat().every((value) => Number.isFinite(value.re) && Number.isFinite(value.im)),
  };
}

export function decimal(value) {
  if (!Number.isFinite(value)) return value === Number.POSITIVE_INFINITY ? 'INF' : value === Number.NEGATIVE_INFINITY ? '-INF' : 'NAN';
  if (Object.is(value, -0) || Math.abs(value) < 1e-300) value = 0;
  return value.toExponential(16);
}

function serializedMatrix(matrix) {
  return matrix.map((row) => row.map((value) => ({ re_decimal: decimal(value.re), im_decimal: decimal(value.im) })));
}

function makeCheck(name, passed, value, threshold, detail) {
  return { name, passed: passed === true, value_decimal: decimal(value), threshold_decimal: decimal(threshold), detail };
}

export function computeSample(stateName, timeNs, config) {
  const { t1, t2, tolerance } = validateConfig(config);
  const parameters = channelParameters(timeNs, t1, t2);
  const initial = initialDensity(stateName);
  const production = productionChannel(initial, parameters);
  const analytic = analyticChannel(initial, parameters);
  const physics = physicality(production.rho);
  const analyticError = matrixMaxError(production.rho, analytic);
  const checks = [
    makeCheck('production_analytic_max_error', analyticError <= tolerance, analyticError, tolerance, 'Kraus result agrees with closed-form channel.'),
    makeCheck('trace_preservation', physics.traceError <= tolerance, physics.traceError, tolerance, 'Density-matrix trace remains one.'),
    makeCheck('hermiticity', physics.hermitianError <= tolerance, physics.hermitianError, tolerance, 'Density matrix equals its conjugate transpose.'),
    makeCheck('positivity', physics.minimumEigenvalue >= -tolerance, Math.max(0, -physics.minimumEigenvalue), tolerance, 'Minimum eigenvalue is nonnegative within tolerance.'),
    makeCheck('amplitude_kraus_completeness', production.amplitudeCompletenessError <= tolerance, production.amplitudeCompletenessError, tolerance, 'Amplitude-damping Kraus sum equals identity.'),
    makeCheck('phase_kraus_completeness', production.phaseCompletenessError <= tolerance, production.phaseCompletenessError, tolerance, 'Phase-channel Kraus sum equals identity.'),
    { name: 'finite_values', passed: physics.finite, value_decimal: physics.finite ? '0' : '1', threshold_decimal: '0', detail: 'All matrix components are finite.' },
  ];
  return {
    state: stateName,
    time_ns: timeNs,
    cycle_ratio_decimal: decimal(timeNs / config.model.cycle_ns),
    channel_parameters: {
      eta1_decimal: decimal(parameters.eta1),
      lambda_phi_decimal: decimal(parameters.lambdaPhi),
      total_coherence_decimal: decimal(parameters.coherence),
    },
    production_density_matrix: serializedMatrix(production.rho),
    analytic_density_matrix: serializedMatrix(analytic),
    metrics: {
      production_analytic_max_error_decimal: decimal(analyticError),
      trace_error_decimal: decimal(physics.traceError),
      hermiticity_error_decimal: decimal(physics.hermitianError),
      minimum_eigenvalue_decimal: decimal(physics.minimumEigenvalue),
    },
    checks,
    passed: checks.every((item) => item.passed),
  };
}

function monotonicChecks(samples, config) {
  const output = [];
  const tolerance = Number(config.numeric_policy.absolute_tolerance_decimal);
  for (const state of config.model.initial_states) {
    const ordered = samples.filter((sample) => sample.state === state).sort((a, b) => a.time_ns - b.time_ns);
    let previous = Number.POSITIVE_INFINITY;
    let maximumIncrease = 0;
    for (const sample of ordered) {
      const rho = sample.production_density_matrix;
      const observed = state === 'ONE'
        ? Number(rho[1][1].re_decimal)
        : Math.hypot(Number(rho[0][1].re_decimal), Number(rho[0][1].im_decimal));
      maximumIncrease = Math.max(maximumIncrease, observed - previous);
      previous = observed;
    }
    output.push(makeCheck(`${state.toLowerCase()}_monotonic_decay`, maximumIncrease <= tolerance, Math.max(0, maximumIncrease), tolerance, 'Declared population or coherence does not increase with time.'));
  }
  return output;
}

export function runCalibration(config) {
  const { t1, t2 } = validateConfig(config);
  const samples = [];
  for (const state of config.model.initial_states) for (const time of config.model.time_points_ns) samples.push(computeSample(state, time, config));
  const monotonic = monotonicChecks(samples, config);
  const allChecks = samples.flatMap((sample) => sample.checks).concat(monotonic);
  const inverseTphi = (1 / t2) - (1 / (2 * t1));
  const resultBody = {
    schema: 'qel.wf019.channel-calibration-result-body/v1',
    workflow_id: config.workflow_id,
    cycle_id: config.cycle_id,
    execution_class: config.execution_class,
    purpose: config.purpose,
    method: 'PRODUCTION_KRAUS_CHANNEL_COMPARED_WITH_CLOSED_FORM_ANALYTIC_PATH',
    model: {
      t1_ns: t1,
      t2_ns: t2,
      tphi_ns_decimal: inverseTphi === 0 ? 'INF' : decimal(1 / inverseTphi),
      cycle_ns: config.model.cycle_ns,
      sample_count: samples.length,
    },
    samples,
    aggregate: {
      check_count: allChecks.length,
      passed_count: allChecks.filter((item) => item.passed).length,
      failed_count: allChecks.filter((item) => !item.passed).length,
      execution_exception_count: 0,
      monotonic_checks: monotonic,
      verdict: allChecks.every((item) => item.passed) ? 'PASS' : 'FAIL_RETAINED',
    },
    boundaries: {
      physical_qpu: 'NOT_RUN',
      physical_coherence: 'NOT_MEASURED',
      quantum_advantage: 'NOT_ESTABLISHED',
      external_values_are_measurements: false,
      owner_signature: 'NOT_APPLIED',
      release: 'HOLD',
    },
  };
  const bodyRaw = canonicalJson(resultBody);
  return {
    schema: RESULT_SCHEMA,
    result_body: resultBody,
    result_body_identity: {
      bytes: bodyRaw.length,
      purpose: 'qel.wf019.channel-calibration-result-body.v1',
      sgl_prime: sglp2(bodyRaw, 'qel.wf019.channel-calibration-result-body.v1'),
      sha256_secondary: sha256(bodyRaw),
      boundary: IDENTITY_BOUNDARY,
    },
    state: { release: 'HOLD', signature: 'UNSIGNED' },
  };
}

export function assertContained(path, boundary = ROOT) {
  const rel = relative(boundary, path).replaceAll('\\', '/');
  if (!rel || rel === '..' || rel.startsWith('../') || rel.startsWith('/') || rel.split('/').some((part) => !part || part === '.' || part === '..')) {
    throw new WF019Error('WF019-PATH', `path escapes or is not a contained file: ${path}`);
  }
  let cursor = boundary;
  for (const part of rel.split('/').slice(0, -1)) {
    cursor = resolve(cursor, part);
    if (!existsSync(cursor)) mkdirSync(cursor, { recursive: false });
    if (lstatSync(cursor).isSymbolicLink()) throw new WF019Error('WF019-PATH-LINK', `link parent rejected: ${cursor}`);
  }
  return rel;
}

export function atomicWriteNew(path, raw, boundary = ROOT) {
  if (!Buffer.isBuffer(raw)) throw new WF019Error('WF019-WRITE', 'output must be bytes');
  assertContained(path, boundary);
  const temporary = `${path}.partial`;
  if (existsSync(path) || existsSync(temporary)) throw new WF019Error('WF019-WRITE-EXISTS', `refusing existing path ${path}`);
  const parentReal = realpathSync(dirname(path));
  let descriptor;
  try {
    descriptor = openSync(temporary, 'wx', 0o600);
    let offset = 0;
    while (offset < raw.length) {
      const written = writeSync(descriptor, raw, offset, raw.length - offset);
      if (!Number.isSafeInteger(written) || written <= 0) throw new WF019Error('WF019-WRITE-PROGRESS', 'write made no progress');
      offset += written;
    }
    fsyncSync(descriptor); closeSync(descriptor); descriptor = undefined;
    if (realpathSync(dirname(path)) !== parentReal) throw new WF019Error('WF019-WRITE-RACE', 'output parent changed');
    linkSync(temporary, path); unlinkSync(temporary);
    if (!readFileSync(path).equals(raw)) throw new WF019Error('WF019-WRITE-VERIFY', 'exact reread mismatch');
    return { fsync_completed: true, exact_reread_verified: true };
  } catch (error) {
    if (descriptor !== undefined) closeSync(descriptor);
    if (existsSync(temporary)) unlinkSync(temporary);
    throw error;
  }
}

export function exactIdentity(raw, purpose) {
  return {
    bytes: raw.length,
    purpose,
    sgl_prime: sglp2(raw, purpose),
    sha256_secondary: sha256(raw),
    boundary: IDENTITY_BOUNDARY,
  };
}
