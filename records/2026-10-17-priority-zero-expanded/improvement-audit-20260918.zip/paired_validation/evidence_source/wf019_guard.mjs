/* Private admission wrapper; both preserved QEL source modules are unchanged. */
import {computeSample, validateConfig} from './source/wf019_core.mjs';
import {strictJsonParse} from './source/wf020_core.mjs';

function freeze(value) {
  if(value && typeof value==='object') {
    for(const child of Object.values(value)) freeze(child);
    Object.freeze(value);
  }
  return value;
}
function admit(raw) {
  if(!Buffer.isBuffer(raw) || raw.length>65536) throw new TypeError('Raw config must be a Buffer within 64 KiB');
  const config=strictJsonParse(raw,'WF019 admitted config',{maxDepth:16,maxNodes:8192});
  validateConfig(config,raw.length);
  if(config.resource_policy.max_time_points>128 || config.resource_policy.max_time_ns>1e9 ||
     config.resource_policy.max_config_bytes>65536 || config.resource_policy.max_output_bytes>1048576)
    throw new RangeError('Private adapter retains original configuration resource ceilings');
  const tolerance=config.numeric_policy.absolute_tolerance_decimal;
  if(typeof tolerance!=='string' || !(Number(tolerance)>0 && Number(tolerance)<=1e-12))
    throw new RangeError('Original numeric precision boundary must not be weakened');
  if(config.claim_boundary.physical_coherence!=='NOT_MEASURED' ||
     config.claim_boundary.quantum_advantage!=='NOT_ESTABLISHED')
    throw new RangeError('Example calibration cannot claim physical measurement or advantage');
  return freeze(config);
}
function selected(config,state,time) {
  if(typeof state!=='string' || !config.model.initial_states.includes(state))
    throw new RangeError('State is not declared in this configuration');
  if(!Number.isSafeInteger(time) || Object.is(time,-0) || !config.model.time_points_ns.includes(time))
    throw new RangeError('Time must be a declared integer sample time');
  return computeSample(state,time,config);
}
function encode(value,limit) {
  const raw=Buffer.from(JSON.stringify(value,null,2)+'\n');
  if(raw.length>limit) throw new RangeError('Actual serialized result exceeds declared output limit');
  return raw;
}
export function selectedSample(raw,state,time) {
  const config=admit(raw),result=selected(config,state,time);
  encode(result,config.resource_policy.max_output_bytes);
  return result;
}
export function encodedBatch(raw) {
  const config=admit(raw);
  const results=config.model.initial_states.flatMap(state=>config.model.time_points_ns.map(time=>selected(config,state,time)));
  return encode(results,config.resource_policy.max_output_bytes);
}
