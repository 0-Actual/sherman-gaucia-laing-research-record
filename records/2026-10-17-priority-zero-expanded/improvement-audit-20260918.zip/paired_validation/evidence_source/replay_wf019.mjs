/* Bounded original-component replay; no generated hash or signed envelope. */
import crypto from 'node:crypto';
import {syncBuiltinESMExports} from 'node:module';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
let hashAttempts=0;
crypto.createHash=()=>{hashAttempts++;throw Error('Hash generation prohibited in this numerical study');};
syncBuiltinESMExports();
const core=await import('./source/wf019_core.mjs');
const guard=await import('./wf019_guard.mjs');
const root=path.dirname(fileURLToPath(import.meta.url));
if(!process.argv[2])throw Error('Provide a new output directory');
const out=path.resolve(process.argv[2]);fs.mkdirSync(out,{recursive:false});
const raw=fs.readFileSync(path.join(root,'source/WF019_CALIBRATION_CONFIG_20260904_C001.json'));
const config=core.strictJsonParse(raw);core.validateConfig(config,raw.length);
const started=performance.now();
const original=config.model.initial_states.flatMap(state=>config.model.time_points_ns.map(time=>core.computeSample(state,time,config)));
const originalBytes=Buffer.from(JSON.stringify(original,null,2)+'\n');
const guarded=guard.encodedBatch(raw),replay=guard.encodedBatch(raw);
if(!originalBytes.equals(guarded)||!guarded.equals(replay))throw Error('Guard or repeat changed original outputs');
const write=(name,value)=>fs.writeFileSync(path.join(out,name),Buffer.isBuffer(value)?value:JSON.stringify(value,null,2)+'\n',{flag:'wx'});
write('original_results.json',originalBytes);write('guarded_results.json',guarded);write('replayed_results.json',replay);
function changed(fn){const x=JSON.parse(raw);fn(x);return Buffer.from(JSON.stringify(x));}
const witnesses=[];
for(const [name,state,time,cfg] of [
  ['string_time','ONE','1100',config],['fractional_time','ONE',0.5,config],
  ['time_above_limit','ONE',1000000001,config],['nonfinite_time','ONE',Infinity,config],
  ['omitted_state','PLUS',1100,JSON.parse(changed(x=>x.model.initial_states=['ONE']))]
]) {
  try {const result=core.computeSample(state,time,cfg);witnesses.push({name,state,time_type:typeof time,time_text:String(time),original_returned:true,original_passed:result.passed,output_time_type:typeof result.time_ns,output_time_finite:Number.isFinite(result.time_ns)});}
  catch(e){witnesses.push({name,state,time_type:typeof time,time_text:String(time),original_returned:false,error:e.message});}
}
write('original_api_witnesses.json',witnesses);
const rejections=[];
function reject(name,fn){let error=null;try{fn();}catch(e){error={name:e.name,message:e.message};}rejections.push({name,rejected:error!==null,error});if(!error)throw Error('Unexpected acceptance: '+name);}
for(const [name,time] of [['undeclared_time',3300],['string_time','1100'],['fractional_time',0.5],['nonfinite_time',Infinity],['above_limit',1000000001],['negative_zero',-0]])reject(name,()=>guard.selectedSample(raw,'ONE',time));
reject('omitted_state',()=>guard.selectedSample(changed(x=>x.model.initial_states=['ONE']),'PLUS',1100));
reject('unknown_state',()=>guard.selectedSample(raw,'ZERO',1100));
reject('duplicate_json_key',()=>guard.encodedBatch(Buffer.from(raw.toString().replace('"schema":','"schema":"duplicate","schema":'))));
reject('prototype_key',()=>guard.encodedBatch(Buffer.from(raw.toString().replace('{','{"__proto__":{},'))));
reject('excessive_nesting',()=>guard.encodedBatch(Buffer.from('['.repeat(18)+'0'+']'.repeat(18))));
reject('oversized_raw_config',()=>guard.encodedBatch(Buffer.alloc(65537,32)));
reject('weakened_tolerance',()=>guard.encodedBatch(changed(x=>x.numeric_policy.absolute_tolerance_decimal='1e-9')));
reject('weakened_release',()=>guard.encodedBatch(changed(x=>x.claim_boundary.release='RELEASE')));
reject('physical_measurement_claim',()=>guard.encodedBatch(changed(x=>x.claim_boundary.physical_coherence='MEASURED')));
reject('actual_output_byte_limit',()=>guard.encodedBatch(changed(x=>x.resource_policy.max_output_bytes=1024)));
write('guard_rejections.json',rejections);
const checks=original.flatMap(x=>x.checks);
const metrics={agent:'GAUCIA',owner:'Sherman Gaucia Laing',source_component:'Preserved WF019 computeSample; WF020 strict parser for admission only',original_samples:original.length,internal_checks:checks.length,internal_passed:checks.filter(x=>x.passed).length,guarded_equals_original_bytes:originalBytes.equals(guarded),replay_full_byte_equal:guarded.equals(replay),actual_output_bytes:guarded.length,guard_tests:rejections.length,guard_rejections:rejections.filter(x=>x.rejected).length,invalid_direct_api_passes:witnesses.filter(x=>x.original_passed===true).length,hash_attempts:hashAttempts,elapsed_ms:performance.now()-started,node_version:process.version,completed_utc:new Date().toISOString(),physical_qpu:false,hardware_parameters_measured:false,jarvis_eigensolver:false,public_release:false,owner_signature:null};
write('metrics.json',metrics);
if(!checks.every(x=>x.passed)||hashAttempts!==0)throw Error('Numerical or hash boundary failed');
console.log(JSON.stringify(metrics));
