# GAUCIA — independent improvement evidence review
Owner: Sherman G. Laing. September 18, 2026. Private research; unsigned.

The matched-energy comparison is valid for its stated 24 lowest-band targets. The reviewer independently linked all 24 result rows to the original 192-row CSV, baseline nested predictions, later QEL ground energies, and Hamiltonian k-point coordinates, then recomputed errors, means and maxima on DESKTOP-EI6MFFI. No eigensolver was rerun and no original source was edited.

Both runs have MAE 2.661986867047439e-9 eV against the same 24 rounded published targets. Both maximum errors are 4.715012380529515e-9 eV. All 24 outputs are numerically identical: measured MAE reduction is 0% for this subset. Repeated path coordinates remain included. These are not 24 materials or 24 independent experiments. See MATCHED_ENERGY_INDEPENDENT_REVIEW.json.

The baseline was a NumPy reference reproduction; the later outputs came from recovered QEL source, recorded as unchanged. Original executions occurred in managed Linux. This audit and its independent arithmetic occurred on the laptop. No model-weight change, intelligence percentage or speed improvement follows. The 1e-4 eV threshold was originally a private 192-value criterion; applying it to this subset does not rerun the full benchmark.

Before execution, independent review requested full flattened/nested agreement, finite three-coordinate k-points, explicit handling of a zero denominator, and a subset-threshold label. The final comparison script includes these corrections. The reviewed current inputs do not exhibit corruption.

The Q8 evidence supplies subsequent engineering work, with these limits:
- Candidate launcher fixtures preserved child exit 23 and 0. Legacy Q7 has a source-grounded stale-exit-code defect, but the original launcher was not run against these same fixtures and remains unchanged.
- The first checkpoint omitted three launchers. They were added; independent verification compared eight payload files plus manifest and receipt across laptop/USB.
- Candidate core tests passed 20/20. Two saved runs repeat the same scenarios. Independent review passed six checks; one USB-junction fixture could not run. These counts are finite checks, not percentage improvement.
- Early independent-review failures included two command-wrapper harness errors and unavailable USB fixture setup. Correcting/reclassifying them does not measure increased candidate accuracy.
- Selected baseline recovery restored 13 files with exact bytes into an isolated directory. Full operational rollback remains untested.
- The register contains 55 failure classes and 106 evidence references, derived from 57 entries consolidated into 53 historical classes plus two current findings. Saved report dates and a source-bounded class inventory cannot supply incident rates or all errors since JARVIS.
- A September 18 quoting SyntaxError explicitly recurs under earlier class FOUND-010. Guessed-schema TypeError and archive-path validation failure also remain preserved in Q8_BUILD_ATTEMPTS.json.
- The retained monitor holds 17 events and records zero substantive cycles, validation executions or deliveries in both its 72-hour and seven-day windows. Current comparable rate is null. Coverage flags do not establish ingestion of recent work.
- Its historical 17/467 (3.6403%) comparator measures candidate execution-language incidence in October-November 2024, not verified JARVIS-era error rate.
- Production remains Q7; release HOLD and unsigned. Owner signing, integrated replay/rollback and complete resource admission remain open. Content identities are not owner signatures.
- The Bible review corrected a source omission, a 109-word count overstatement, a weak text oracle and CLI coverage gaps. The stronger oracle exposed 11 truncated words; discovery did not repair the converter. Seven converter-defect classes RECENT-013 through RECENT-019 remain observed unresolved.

Nine Q8 source snapshots accompany this review. Q8_SOURCE_COPY_READBACK.json maps them to original locations and records exact byte equality. No new hashes or signatures were generated. No existing worker was interrupted; the review used its own temporary Node process.
