# GAUCIA Report — QEL Ground-State Stationarity Across JARVIS Hamiltonians

## New cross-capability result

Two independently governed recovered QEL capabilities now operate coherently
on the same JARVIS inputs:

- `QCAP-GEN-A-07 Energy Optimization` produced each exact lowest eigenpair.
- `QCAP-GEN-A-01 State Encoding and Transition` converted the same Hamiltonian
  into a unitary and evolved that ground state.

For a Hamiltonian eigenstate, evolution should change only its global phase:
`exp(-iHt)|psi> = exp(-iEt)|psi>`. The observable basis probabilities, state
norm, energy expectation, and state fidelity should therefore remain fixed.

The authentic top-level QEL emulator kernel independently checked the input
Hamiltonians and derived unitaries, applied each unitary, and calculated
fidelity. No new solver or simulator was substituted.

## Test design

All 24 preserved JVASP-816 8×8 Hamiltonians were evaluated at three explicit
natural-unit times: **0.01, 0.1, and 1.0 eV^-1**, with `hbar=1`. This produced
**72 cross-capability evolution cases**.

For every case the run compared:

1. QCAP-GEN-A-01 evolution against the analytic eigenstate phase.
2. QCAP-GEN-A-01 output against the top-level QPU kernel applying the same
   derived unitary.
3. Forward evolution against reverse-time recovery.
4. Initial and evolved probability distributions, norms, fidelities, and
   energy expectations.

Results:

- **72/72** derived unitaries accepted by the authentic QEL kernel.
- Maximum evolved-versus-analytic-phase difference:
  **9.312799602274192 × 10^-15**.
- Maximum top-level-QPU-versus-transition difference:
  **3.4781645049295745 × 10^-16**.
- Maximum state-norm drift: **8.881784197001252 × 10^-16**.
- Maximum basis-probability change: **1.5543122344752192 × 10^-15**.
- Maximum energy-expectation drift:
  **7.105427357601002 × 10^-15 eV**.
- Minimum initial/evolved fidelity: **0.9999999999999998**.
- Minimum forward/reverse recovery fidelity: **0.9999999999999998**.
- SciPy reproduction difference: **0.0** for the recorded evolution states.
- Independent verification passed **23/23 checks**.

This demonstrates that the recovered QEL energy and evolution components agree
on a central quantum-mechanical invariant: an eigenstate is stationary up to
global phase under its own Hamiltonian.

## Complementary-research boundary

QuTiP was checked for local availability and was not installed. No package was
installed and no license was accepted. SciPy, already present, was used only by
the independent verifier and by the preserved QEL transition component's own
existing matrix-exponential implementation.

These are deterministic classical simulations. They do not establish physical
QPU execution, quantum advantage, experimental material behavior, complete
band structure, a band gap, or owner acceptance.

## Preserved failure and correction

The first stationarity launcher failed with exit code 1 because the new harness
used keyword `t`, while the preserved QCAP-GEN-A-01 function names that
parameter `time`. The failure is retained. Only the additive harness was
corrected to use the authentic function signature; no recovered QEL source was
changed. The retry then succeeded.

## Execution and preservation

Exact Python:
`/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3`,
CPython 3.12.14.

Recorded launcher wall times:

- Failed first stationarity attempt: 0.365159 seconds.
- Successful 72-case stationarity run: 0.314878 seconds.
- Independent verification: 0.264752 seconds.
- Successful evidence path: **0.579630 seconds**.
- Total including preserved failure: **0.944789 seconds**.

All computation ran with direct networking blocked. No new SHA witness, SGL
receipt, owner signature, or release claim was generated. The laptop remained
offline, so checkpoints 02–08 still await additive USB preservation; earlier
verified USB archives were not changed. Nothing was published.

