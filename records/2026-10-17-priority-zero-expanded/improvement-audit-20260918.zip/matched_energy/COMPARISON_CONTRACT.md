# GAUCIA — matched energy comparison contract

Owner: Sherman G. Laing. Private research; unsigned.

This is a new laptop-side comparison of preserved numerical outputs, not a new eigensolver execution or a blinded experiment. The earlier source reports and their summary values have already been read.

Fixed comparison: JVASP-816, same task string, eV, zero Fermi shift, 24 k-points in unchanged path order. Select scalar 8*k from the baseline 192-value comparison and match it to the later QEL ground energy at kpoint_index k. Verify k-point coordinates against baseline predictions and the preserved Hamiltonian fixture. Retain duplicates.

Compute baseline MAE and later MAE against the SAME 24 published reference targets; maximum errors, count of identical outputs, maximum and mean before/after output differences; relative MAE reduction = 100*(baseline MAE-later MAE)/baseline MAE. Report exact observed quantities without attributing tiny floating-point differences to training. Use the original private 1e-4 eV MAE criterion only as a carried-forward criterion, not a NIST standard.

Reject missing/nonfinite/duplicate/out-of-order indices, task/material/unit/coordinate/shape differences, or a baseline prediction CSV/JSON mismatch. No input correction or imputation is permitted. Do not compare the baseline 192-value MAE to the later QEL-versus-SciPy error. Output per-case evidence and runtime provenance. No speed comparison or model-weight improvement follows from this analysis.

Only reviewed local input files are read; the script imports node:fs and node:assert/strict and makes no network requests. No OS-level network-containment claim is made. No hashes or signatures are generated; original input records remain unchanged.

Pre-execution independent review clarified that the carried-forward 1e-4 eV threshold applies to this 24-value subset only. It cannot certify the full 192-value task. Additional assertions require all192 flattened values, nested/flattened agreement, finite three-coordinate k-points, and an explicit undefined relative reduction if baseline MAE is zero. No source data defect was found by that review.
