# GAUCIA — Private JARVIS aluminum reference reproduction

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing. Review set:2026-09-18.

**Result: the private classical reference test passed the tolerance fixed before execution, and its replay reproduced all three prediction files byte-for-byte.**

This test used an independently written NumPy runner to reconstruct the aluminum Wannier Hamiltonian from NIST/JARVIS source data and calculate its eigenvalues. It did not run QEL's quantum simulator, train a model, use quantum hardware, submit to a leaderboard, or publish source code. It establishes reproducible classical reference calculation on this one specified material.

| Item | Measured result |
|---|---:|
| Material | Aluminum, JVASP-816 |
| Input | 8 orbitals; 1041 lattice-vector blocks; 66,624 complex entries |
| Output | 24 k-points ×8 ascending eigenvalues =192 values |
| Official task metric | MULTIMAE, equivalent here to mean absolute error over192 eigenvalues |
| Mean absolute error | **2.3408423741044793e-9 eV** |
| Maximum absolute error | **4.949907150830768e-9 eV** |
| Private predeclared tolerance | Mean absolute error<=1e-4eV |
| Private tolerance result | PASS, both executions |
| Maximum raw anti-Hermitian Frobenius norm | 1.959423540043073e-14eV |
| Maximum relative eigensolver residual | 1.0512733466535233e-15 |
| Maximum eigenvector orthonormality residual | 3.17772854863491e-15 |
| Finite outputs; ascending bands | Passed for all192 values |

The tiny discrepancy is consistent with comparison to the rounded published reference values. It does not measure accuracy against a new physical experiment. NIST provides no certification or pass/fail threshold for this private run; the1e-4eV condition is our stated engineering criterion.

| Execution | Actual completion UTC | Input parsing, prediction and scoring | Hamiltonian construction and eigensolver | Whole-process peak RSS |
|---|---|---:|---:|---:|
| First run | 2026-09-18T02:28:31.159851+00:00 | 0.2340385400s | 0.0118597960s | 35,512,320 bytes |
| Replay | 2026-09-18T02:28:44.457754+00:00 | 0.2104013160s | 0.0072856680s | 35,524,608 bytes |

These measurements are from Python3.12.14/NumPy2.3.5 in the managed Linux environment. They are not laptop performance measurements. Parsing/prediction/scoring time excludes downloads, interpreter startup, and library import time. Memory is process peak resident set measured by `getrusage`, including Python overhead.

The predictions were written and marked read-only **before reference answer values were opened in each run**. Targets had been inspected during the earlier preparation, which is disclosed in both execution logs: this is transparent reference reproduction, not a blind prediction test.

Replay verification used direct byte comparisons, with no newly generated hash:

| File | Bytes | Replay |
|---|---:|---|
| `predictions.json` | 11094 | EXACT |
| `predictions_192.csv` | 7995 | EXACT |
| `official_prediction_format.csv` | 3677 | EXACT |

Both runs preserve all192 predictions, all192 comparisons, numerical residuals, timings, environment details, and stage-by-stage logs. **There were no failed eigensolver runs.** One source-acquisition request failed: downloading the CC BY4.0 plain-text license returned HTTP403. The failed request remains in `source/acquisition_log.json`; the official legal code was subsequently reviewed through the web lookup and its URI/attribution preserved. Other recipe sources were recovered from successful public GitHub reads already completed during preparation.

Source attribution: Kamal Choudhary's [Figshare dataset](https://doi.org/10.6084/m9.figshare.12473168.v1), file23102645, CC BY4.0; NIST/JARVIS [aluminum benchmark](https://pages.nist.gov/jarvis_leaderboard/QC/EigenSolver/dft_3d_electron_bands_JVASP_816_Al_WTBH/) and [scoring source](https://github.com/usnistgov/jarvis_leaderboard/blob/main/jarvis_leaderboard/rebuild.py). Raw computational inputs, source notices, license references, and recipe/scorer text are preserved in `source/`.

This package is private and unsigned. No claim of NIST endorsement, novel materials discovery, quantum advantage, QEL quantum validation, or funding qualification follows from this baseline result.
