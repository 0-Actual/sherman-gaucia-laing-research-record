# Checkpoint 08 analysis contract

Owner: Sherman Gaucia Laing  
Agent: GAUCIA

This private bounded run tests one new cross-capability property using only
recovered QEL sources: a ground-state eigenvector produced by
`QCAP-GEN-A-07` should remain unchanged except for global phase when evolved
by `QCAP-GEN-A-01` under the same Hamiltonian.

All times must use the explicit natural-unit convention H in eV, t in eV^-1,
and hbar=1. The run must retain original k-point order and duplicates, identify
every exact module invoked, and keep direct networking blocked.

No source modification, installation, publication, outreach, signing, owner
acceptance, new identity witness, physical-QPU claim, or quantum-advantage
claim is authorized.

