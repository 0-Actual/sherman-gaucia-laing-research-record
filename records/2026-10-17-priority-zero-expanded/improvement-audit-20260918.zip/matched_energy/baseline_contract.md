# GAUCIA — Frozen private execution conditions

This note was written before the first eigensolver execution.

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing.

After completion and review of the acquired-material study, the root authorized one private classical reference reproduction and one replay. Original QEL quantum code is not used or disclosed. This is ordinary NumPy linear algebra using JARVIS's published single-material input and reference task.

- Official task: `QC-EigenSolver-electron_bands_JVASP_816_Al_WTBH-dft_3d-test-multimae`.
- Frozen output: 24 specified k-points × 8 ascending eigenvalues; C-order flattening; eV; no Fermi-level subtraction.
- **Private success tolerance: mean absolute error <= 0.0001 eV (1e-4 eV).** This is our engineering condition, not a NIST pass threshold.
- Input maximum: 1,200,000 archive bytes and 10,000,000 total expanded bytes.
- Reference maximum: 10,000 compressed bytes, one member, 50,000 expanded bytes.
- Prediction files must be written and marked read-only before opening reference answer values in each execution.
- Targets were inspected during preparation; this is not a blind evaluation.
- No installs, external submissions, source publication, model training, or network calls during computation.
- One bounded CPU process per execution; report measured runtime, memory, numerical residuals, all192 predictions, all192 errors, and any failures.
- Run once, replay once, then compare the three prediction files byte-for-byte. Timing/log files necessarily differ.
- Preserve source attribution, third-party license terms, unsigned status, and original input files. Do not fabricate a signature or generate a new SHA witness.

The complete input recipe and exact source locations are in `../TEST_CONTRACT.md` and `../TEST_SOURCE_URLS.json`.
