# GAUCIA — What the acquired JARVIS material teaches us

Prepared for Sherman Gaucia Laing / Quantum.Earth.Laing. Private study, 18 September 2026 UTC. This study concerns the acquired JARVIS snapshot; it does not reset the dates of the owner's earlier work. Original data and historical records remain unchanged.

## Study completed before testing

The review covers all **1,103 material records, all 65 top-level fields, all nested atomic arrays, and all 1,717,371 descriptor values** in the acquired 2D archive. The complete field traversal examined 1,861,469 scalar occurrences. The previous 44-file package was also inventoried in full, including its analysis code, provenance, license, logs, historical outputs, published selection, and preservation receipts. The scientific study is documented in three domain reports and a complete field guide; reading bytes alone is not treated as scientific understanding.

The archive represents calculated properties of candidate single-layer materials. A record joins several kinds of evidence: a periodic atomic model, calculation settings, selected calculated properties, compressed numerical features, and links to further calculations. Those kinds of evidence have different meanings and levels of completeness. We must preserve these distinctions when building or testing anything with them.

This is the acquired December-2022-named snapshot, not all of JARVIS. Its 4,666 raw-file links were studied as metadata; their linked archives were not part of the acquired package and were not downloaded during this census. A separate, small aluminum input used for the subsequent reference calculation is documented separately.

## 1. Atomic representation comes before interpreting a property

The explicit atom positions and lattice describe a repeating simulation cell. All stored coordinate flags are Cartesian, and every structure has finite, consistently shaped arrays. A chemical formula is only a composition label: it cannot distinguish two different arrangements or phases of the same elements. Use the JARVIS identifier and full structure when tracing a result.

The 42 differences between `nat` and the length of the atom list do not establish 42 damaged structures. A periodic-translation diagnostic at 0.001 Å supports a repeated-cell interpretation in **40 cases**. The remaining **JVASP-6751 and JVASP-60484** are unresolved. The diagnostic supports an explanation; it does not prove the historical export cause.

Four formula strings disagree with compositions counted from the supplied atom lists. Their pattern is consistent with a text-formatting loss of the digit 1, but that cause remains unverified. We retain both source representations and flag the disagreement. Silently correcting the formula would erase evidence of the distinction.

For a monolayer calculation, the cell also contains vacuum between repeated sheets. Reported cell density therefore depends on that simulation convention. It is not automatically a bulk density or a physical sheet thickness. The same issue affects dielectric and elastic normalization. A number detached from its geometry can be misleading even when it is finite.

## 2. Formation, separation, and stability are different questions

Formation energy compares a compound with chosen elemental references; exfoliation energy concerns separating a layer from its bulk counterpart. They are not interchangeable measures of usefulness or stability. There are **952 negative formation energies**, but negative formation energy alone does not rule out a more favorable mixture of competing compounds.

All 1,103 stored energy-above-hull values are zero. Without the phase-reference construction, this constant field cannot rank stability or certify all materials as stable. Exfoliation energy exists for **748 records** and is missing for **355**. Missing values are unknown, not zero-cost separation.

This teaches a practical rule for the project: keep the physical question, reference state, units, and missingness attached to each numerical target. A prediction system should not combine unlike targets merely because they are all described as energy.

## 3. Electronic behaviour depends on the calculation method

OptB88-vdW bandgaps exist for every record: **397 are zero and 706 positive**. These are calculated gaps under one workflow, not experimental classifications that settle every material's behaviour. The mBJ and HSE fields cover only 246 and 54 records respectively.

On the same 246 records, mBJ gives a larger gap than OptB88 in **160 cases**, an equal gap in **44**, and a smaller gap in **42**. The median paired difference is 0.2745 eV. All 54 available HSE gaps exceed their paired OptB88 gaps. These comparisons demonstrate method dependence, not that one method is proven correct by this archive. Comparing averages from different coverage subsets would mix a method effect with a selection effect.

Optical response and modeled solar efficiency build on additional assumptions. Only 184 records contain the modeled solar-efficiency field. Its maximum of 33.93 is a model result, not an achieved device efficiency. The dielectric fields are anisotropic components and require their frequency and slab conventions. Six negative mBJ dielectric components in five records deserve contextual review; a negative real optical response is not by itself evidence of corrupt data.

## 4. Transport and mechanics require unit and validity checks

The transport fields describe how modeled carriers carry charge and heat. They do not provide a ready-made device performance score. Current exporter code applies relaxation-time scaling to electrical conductivity while exporting electronic thermal transport differently. Consequently, the raw `nkappa` and `pkappa` values must not simply be labeled W/(m K). Historical per-record settings remain unverified, and lattice thermal conductivity is not supplied here for a complete thermoelectric figure of merit.

Effective-mass vectors are populated in 678 records and missing in 425. Their averages reproduce the component means, but extreme values and unverified historical unit conventions make a naive ranking unsafe. These are band-curvature model quantities, not masses of free particles.

Mechanics has comparable limits: 229 elastic tensors exist, **four contain 20 NaN components**, and another has an extreme finite component near 2.10 × 10^17. The current 2D parser treats tensor components differently during vacuum scaling. Mechanical stability must not be inferred by applying an ordinary 3D tensor test without reconciling those conventions.

The 187 available vibration lists all contain negative entries. Imaginary-mode notation can indicate a distortion tendency, but small negative modes and finite-cell effects need care. Current source also removes duplicate frequencies, so the list length need not retain all mode multiplicities. These lists are insufficient to certify full vibrational stability or reconstruct a complete phonon dispersion.

## 5. Descriptors are useful, but they can also conceal assumptions

Each 1,557-component CFID vector combines chemistry, cell quantities, and distributions of distances and angles. It is a compact input representation for statistical models. It is not a quantum state or 1,557 independent experimental measurements.

There are **77 constant-zero columns** and **34 pairs of exactly identical vectors**. Every duplicate pair also has equal OptB88 gap and formation energy. A random train/test split could put one member on each side, rewarding memorization. A future prediction experiment must keep duplicate groups together and disclose that these labels have already been examined during this study.

Numerical completeness is not enough: all descriptor values are finite, yet nine records contain enormous negative values in the position that current CFID code maps to packing fraction. The descriptor density also differs from the top-level density by more than 0.001 in **1,007 records**. The exact historical descriptor-generation revision is not established; these are flags for investigation, not permission to overwrite the source.

The descriptors include information derived from DFT-relaxed geometry and elemental property tables. A model using them cannot honestly be described as requiring only a chemical name or no prior calculation. Input availability must match the intended use case.

## 6. The source code explains both scientific and operational limits

The two `maxdiff` fields compare Wannier-interpolated and DFT electronic energies. They are not universal accuracy scores or energy-cutoff convergence settings. They appear in 431 records and are absent in 672. Some records with metrics have no corresponding Wannier archive link in their stored list.

The reviewed access module streams a ZIP download but then decompresses and parses the entire JSON in memory. That is not streaming analysis. Handling this 8.39 MB archive does not demonstrate an ability to process arbitrarily large datasets. The acquired data were studied in the available analysis runtime; the owner's nearly full laptop is used for USB preservation, not represented as the machine that performed these calculations.

## Consequences for our next work

We now have a defensible map of what the data can support and where further evidence is necessary. It supports learning about atomistic representation, calculated energy references, electronic methods, descriptor construction, and reproducible data validation. It does not currently support superconductivity prediction from its absent transition-temperature labels, blanket material-stability claims, or a quantum-advantage claim.

For the previously requested test, a small official aluminum eigenvalue task provides a transparent reference calculation with a specified input and score. It is separate from the acquired 2D census. Its classical reproduction can establish that the input interpretation and numerical comparison work. Testing the owner's actual simulator would additionally require that implementation and an agreed input/output interface; no substitute code is presented as the private project.

No new study, code, anomaly list, or test result was published. The earlier public documentary selection remains a historical part of the preserved package. Public contribution requirements were examined before choosing a private route. There is no submission, certification, funding endorsement, or claim that this study trains the assistant's underlying model weights.

## Evidence and replay

- `FIELD_GUIDE.md`: definition and coverage for all 65 fields.
- `STRUCTURE_ENERGY_MECHANICS.md`: structures, energies, tensors, vibrations, and exact exception IDs.
- `ELECTRONIC_OPTICAL_TRANSPORT.md`: bandgaps, optics, masses, transport, magnetism, and missing specialized properties.
- `DESCRIPTORS_AND_SOURCE_METHOD.md`: all descriptor blocks, duplicate groups, source links, and source-code behavior.
- `results/`: complete field profile, original-package inventory, execution measurement, and exact replay comparison.
- Companion Python files regenerate the measured results from the unchanged source archive. Domain reports cite the official methods and source files; current source interpretation is explicitly separated from unverified historical provenance.
- `private_reference_test/TEST_RESULT.md`: subsequent calculation result, once run; no test outcome is implied by this study report.

Primary dataset: Kamal Choudhary, [JARVIS-DFT 2D dataset, Figshare version 8](https://doi.org/10.6084/m9.figshare.6815705.v8), CC BY 4.0. The original archive and attribution are preserved. This record is unsigned; no owner signature, SGL Prime witness, or QPRINT encoding was fabricated.
