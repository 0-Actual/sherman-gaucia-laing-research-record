# GAUCIA — JARVIS private learning review

Owner: Sherman Gaucia Laing / Quantum.Earth.Laing.

User start timestamp, preserved verbatim: **9:06 p.m. EST**. Execution records use actual UTC timestamps on September 18, 2026. The user label is not silently converted to a different timezone. This is a new review of an existing December 2022 dataset; it does not change QEL's inception chronology.

## What was completed

Retrieved the complete selected JARVIS `dft_2d` archive, inspected all its records, checked selected values and structural metadata, and replayed the analysis offline. The archive is 8,394,653 bytes and contains one 24,758,679-byte JSON file. The analysis uses only Python's standard library and does not install or execute the JARVIS software.

**This is descriptive analysis of published density-functional-theory (DFT) calculations. No new quantum circuit simulation, DFT calculation, AI training, quantum advantage demonstration, or large-data benchmark was performed.**

## What the actual data shows

| Finding | Measured result |
|---|---:|
| Records in selected downloaded file | 1,103 |
| Distinct record IDs | 1,103 |
| Distinct chemical formulas | 879 |
| Fields per record | 65 |
| Records stated by the current NIST catalog | 1,109 |
| Catalog/file difference | 6 |
| Records with numeric bandgap and formation energy | 1,103 |
| Records with numeric exfoliation energy | 748 |
| Records with missing exfoliation energy (`na`) | 355 |
| Records where `nat` differs from the supplied structure's atom count | 42 |

The 1,109 figure in the earlier chat was explicitly a catalog value. Direct inspection now establishes **1,103 for this particular source file**. The reason for the catalog mismatch has not been established. We preserve both facts.

In 41 records, the supplied structure has twice the `nat` count; in one record it has three times the count. This is consistent with a possible difference in cell representation, but that explanation is not verified. These records are flagged, not silently repaired or described as corrupt. Their element and coordinate list lengths agree. The review does not establish complete chemical or crystallographic validity.

## A small lesson from three records

| Formula / record | Calculated bandgap (eV) | Formation energy (eV/atom) | Exfoliation energy (meV/atom) |
|---|---:|---:|---:|
| C / JVASP-60368 | 0.000 | 0.07195 | Missing |
| BN / JVASP-60594 | 4.384 | -1.31309 | 58.90 |
| MoS2 / JVASP-664 | 1.658 | -0.88454 | 76.99 |

These are illustrative records selected by a documented deterministic rule: the lexicographically first ID matching each formula. Different structures can share a formula. The examples are not a representative sample or a recommendation to build a device.

Bandgap is an energy separation relevant to a material's electronic behaviour. The value here is a model calculation, not a laboratory measurement. Formation energy compares a calculated structure with elemental reference energies; a negative value alone does not prove practical stability. Exfoliation energy describes a calculated energy difference associated with separating a layer. Missing information remains missing: it is never replaced with zero.

The 1,103 bandgaps range from 0 to 7.314 eV, with a median of 0.814 eV. There are 397 zero entries and 706 positive entries. These describe the selected source file and calculation method; they are not measurements of all known materials.

## Replay and verification

Extract the package on a computer with Python 3.9 or newer, then run:

```text
python analyze.py --output replay_check
```

No internet or additional Python packages are required for that command. It reads the included original archive and creates a separate output folder. Compare `analysis.json`, `record_index.json`, and `checks.json` with the delivered `results` copies. Actual independent-process replay results are in `logs/replay_verification.json`; timing/environment values are expected to differ between runs.

Checks deliberately retain two unresolved findings: the catalog-count mismatch and the `nat` metadata mismatches. A successful replay reproduces those findings rather than suppressing them. Initial-run output and its reconstructed exact script version are retained under `history`; the revision separated coordinate validation from `nat` metadata comparison and added the actual counts to each flagged record.

Execution timings and Python-tracked peak allocation are in `results/metrics.json` and `replay/metrics.json`. These are instrumented measurements in the analysis environment, not measurements of the Windows laptop. Python was not available through the laptop's `python` command during the read-only check; no installation was attempted. The laptop is used for USB preservation in this task, not for running this analysis.

## Source and permissions

Source: Kamal Choudhary, **JARVIS-DFT 2D dataset (jdft_2d.json), version 8**, https://doi.org/10.6084/m9.figshare.6815705.v8. File ID 38521268; selected file published December 12, 2022. Dataset license: CC BY 4.0. The original archive is preserved unchanged. Indexes and statistics are transformed outputs with attribution retained.

The terms review permits this private study and owner copy. No contribution of QEL work to NIST, GitHub, or another organization took place. Original QEL code and prose retain the owner's separate restrictions; those restrictions do not override the third-party dataset's license. See `TERMS_REVIEW.md`, `ORIGINAL_WORK_NOTICE.md`, and the copied source notices.

## Preservation and limits

The full package is intended for the USB and the owner's private file collection. It contains inputs, exact analysis code, configuration, results, initial findings, replay evidence, source notices, and an unsigned QPRINT review note. It is not an encoded QPRINT, a signed release, or a replacement for all historical QEL archives. The laptop's internal drive is not a destination for the dataset.

The meaningful next research step is to resolve the flagged metadata before using those records in structure-dependent calculations. This completed review establishes that we can retrieve, inspect, and replay analysis on a real published scientific dataset. It does not establish the performance of QEL's simulator.
