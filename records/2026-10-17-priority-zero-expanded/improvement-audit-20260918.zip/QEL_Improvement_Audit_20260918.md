Agent: GAUCIA

**Quantified improvement audit following the JARVIS study — September 18, 2026**

Owner: Sherman G. Laing / Quantum.Earth.Laing. Private research evidence; unsigned. The fresh comparisons in this audit ran through Node Zero, DESKTOP-EI6MFFI, on Windows with Node v24.20.0. The principal replay completed at 22:46:44 UTC; the matched-energy comparison completed at 22:46:49 UTC. Historical Linux computations are identified separately. This audit changes no production QEL source and makes no release or owner-authentication claim.

**The answer supported by the evidence**

There are two defensible numerical before-and-after results. First, the existing WF019 guard reduces false success on five specified invalid-input cases from five to zero: a 100% reduction on those five cases, or a 100-percentage-point gain in their correct rejection. Second, the earlier reference calculation and later recovered QEL component return exactly the same 24 matched ground energies: zero change in numerical outputs and 0% reduction in their error against the same published targets. These quantities measure different behaviors and must not be averaged into a single improvement score.

The larger research gain is expanded, traceable verification of existing capabilities. In eight later scientific checkpoints, seven recovered source files were unchanged across 49 direct byte comparisons. Consequently, those checkpoints demonstrate more about code that already existed; they do not demonstrate that those modules were trained or improved. The assistant's overall reliability and projectwide error-rate change remain unmeasured. Saved evidence shows continuing mistakes, including mistakes during this audit.

**1. What the starting point actually was**

The original JARVIS review examined a specific December-2022-named DFT 2D snapshot with 1,103 records and 65 fields. The full study already examined 1,717,371 descriptor values and 1,861,469 scalar occurrences. These are baseline coverage, not gains to credit again after the study. There were 355 missing exfoliation-energy values, 42 differences between the primitive-count metadata and serialized atom counts, and four formula/atom-composition discrepancies. The 2D corpus is separate from the aluminum eigenvalue fixture used for the numerical comparison.

The private aluminum reference experiment completed its first run at 2026-09-18T02:28:31.159851Z and replay at 02:28:44.457754Z. It reconstructed eight-orbital Hamiltonians at 24 k-points and produced 192 ascending eigenvalues. Its mean absolute error against the rounded published targets was 2.3408423741044793e-9 eV; maximum error was 4.949907150830768e-9 eV. Both runs met the private 1e-4 eV mean-error threshold, and three prediction files reproduced byte-for-byte.

That baseline was an independently written NumPy reference calculation in a managed Linux environment. It did not execute QEL's general simulator, train a model, or measure laptop performance. Targets had been inspected during preparation, so it was explicitly not a blind prediction experiment. Those qualifications remain part of the evidence.

Sources: matched_energy/baseline_report.md and baseline_contract.md; historical_context/original_jarvis_review.md and full_study_baseline.md.

**2. Fresh paired test of the concrete input-protection improvement**

The original numerical function was source/wf019_core.mjs::computeSample. The later protection was the separate, already-preserved wf019_guard.mjs. The audit copied both modules unchanged, along with their original configuration and historical results. Each original file and copy was compared by full bytes before and after the new execution; nine file comparisons passed. No new checksum, fingerprint, or signature was generated.

The fresh replay used the same inputs on the original direct-call path and the guarded path. Expected outcomes were recorded in the new experiment contract before the replay; these were already-known regression cases, not unseen test discoveries.

| Invalid case | Exact input condition | Original direct call | Guarded call |
|---|---|---|---|
| Wrong time type | Text "1100" | Returned passed:true | Rejected |
| Fractional time | Numeric 0.5 | Returned passed:true | Rejected |
| Above configured maximum | Numeric 1,000,000,001 | Returned passed:true | Rejected |
| Nonfinite time | Infinity | Returned passed:true | Rejected |
| Undeclared state | PLUS after allowed states restricted to ONE | Returned passed:true | Rejected |

False-success reduction = (5 - 0) / 5 × 100 = 100% for this fixed five-case set.
Correct-rejection gain = (5/5 - 0/5) × 100 = 100 percentage points.

This is a demonstrated change in input admission through the guard. It is not a 100% improvement in GAUCIA, the simulator, or every call path. Direct callers can still bypass the separate guard and reach the original function. Deployment-wide enforcement was not established.

The broader guard suite rejected all 16 specified cases: undeclared time, string time, fractional time, nonfinite time, above-limit time, negative zero, omitted state, unknown state, duplicate JSON key, prohibited prototype key, excessive nesting, oversized raw configuration, weakened numerical tolerance, weakened release boundary, an unsupported physical-measurement claim, and an actual serialized output exceeding its limit. The five paired cases overlap this suite; 5 + 16 must not be represented as 21 unique tests.

To check that improved rejection did not alter legitimate computation, the same three original states and twelve original times were evaluated: 36 valid samples. All 252 original internal checks passed. Original, guarded, repeated, and historical numerical outputs were identical across 122,107 serialized bytes. Thus the observed gain is stricter input handling with no numerical regression on these valid fixtures.

An independently implemented scalar Bloch reference compared 288 real/imaginary density-matrix components. Maximum absolute difference was 2.220446049250313e-16, below the carried 1e-12 criterion. This fresh 288-component count is distinct from the earlier report's 360-comparison design and is not added to it as a measure of improvement.

Runtime: Windows, Node v24.20.0. Recorded harness interval: 2026-09-18T22:46:43.581Z–22:46:44.781Z; approximately 1,195.66 milliseconds. Tool-observed elapsed time was 2.01 seconds. These are different timing boundaries; neither is a speedup measurement. The harness used allowlisted VM imports and host filesystem permissions. It recorded zero hash attempts, source filesystem attempts, and unknown imports. OS-level network isolation was not asserted.

Sources: paired_validation/EXPERIMENT_CONTRACT.json; paired_validation/run_02/SUMMARY.json, paired_five_cases.json, guard_sixteen_cases.json, independent_scalar_reference.json, full_byte_provenance.json, valid_original.json, valid_guarded.json and valid_repeated.json.

**3. Fresh matching of the numerical accuracy before and afterward**

The original experiment produced 192 energies, whereas the recovered QEL ground-state routine returns the lowest energy for each of 24 matrices. Comparing the original 192-value error with the later QEL-versus-SciPy difference would change both the output population and reference target. It would therefore be an invalid improvement calculation.

The new comparison fixed the common subset before execution: scalar index 8*k from the baseline, for k = 0 through 23, matched with the later ground energy at kpoint_index k. It required matching task, material, eV units, zero Fermi shift, original k-point order, coordinates, matrix dimensions and finite values. Duplicate path coordinates were retained. Every CSV prediction was cross-checked against the baseline JSON; all nested and flattened eigenvalues agreed. A separate reviewer inspected the method before execution and independently recalculated the final matching statistics.

For the same N = 24 target values, MAE = sum(abs(prediction - reference))/24.

| Quantity | Earlier reference output | Later recovered QEL output |
|---|---:|---:|
| Matched ground-energy values | 24 | 24 |
| Mean absolute error against the same targets | 2.661986867047439e-9 eV | 2.661986867047439e-9 eV |
| Maximum absolute error | 4.715012380529515e-9 eV | 4.715012380529515e-9 eV |
| Outputs identical across compared runs | 24 of 24 | 24 of 24 |

Maximum before/after output difference: 0 eV.
Mean-error reduction: 0 eV.
Relative mean-error reduction: 0%.

This is 0% measured accuracy improvement for this matched subset, not a statement that all aspects of QEL improved by zero. Both sets already reproduce the published values closely. The useful later achievement is recovery and verified use of QEL's existing component with these inputs. It does not establish a better numerical result than the earlier classical reference.

The laptop comparison took approximately 18.49 milliseconds of script time. It compared preserved outputs; it did not rerun an eigensolver and is not a solver benchmark. The historical mathematical computations occurred in Linux. The 1e-4 eV threshold is carried only as a subset comparison criterion here; this 24-value comparison cannot certify the entire 192-value task.

Sources: matched_energy/COMPARISON_CONTRACT.md, compare_matched_energy.mjs, MATCHED_ENERGY_RESULT.json, baseline_comparison_192.csv, baseline_predictions.json, qel_stationarity.json, hamiltonians.json; independent_review/MATCHED_ENERGY_INDEPENDENT_REVIEW.json.

**4. What expanded after the original study**

Earlier checkpoints recovered and exercised authentic QEL components: 27 selected top-level kernel tests; 40 state-transition tests; 16 energy-optimization tests; 24 Hamiltonian validations, evolutions and ground-state solutions; and 72 ground-state stationarity cases. These are different suites and overlapping uses of the same inputs. Their totals must not be presented as an intelligence score or a count of new algorithms.

The new archive audit then inspected checkpoints 09–17. Checkpoint 10 concerns preservation. The other eight cover distinct scientific questions, all using the same 24 preserved 8×8 Hamiltonians. An 8×8 state operator corresponds to a three-qubit state space; these counts do not demonstrate additional simulated qubits or additional independent materials.

| Checkpoint | Additional question tested | Saved case coverage | Final saved verifier |
|---|---|---|---:|
| 09 | Non-eigenstate energy conservation | 72 evolution records | 12/12 |
| 10 | Restore prior checkpoint to USB | Preservation only | No scientific suite |
| 11 | Sequential versus direct time evolution | 72 composition records | 11/11 |
| 12 | Measurement probabilities and state collapse | 120 full-register + 216 qubit cases; 6 invalid cases | 14/14 |
| 13 | Seeded sampling and repeatability | 196,608 measurements across 96 distributions | 18/18 |
| 14 | Reduced density matrices and noise channels | 48 reductions; 240 dephasing + 240 damping cases; 13 invalid cases | 20/20 |
| 15 | Complementary subsystem entropy and spectra | 96 states + 192 partitions; 5 invalid cases | 20/20 |
| 16 | Basis changes and interference | 120 basis + 72 interference cases; 5 invalid cases | 19/19 |
| 17 | Bounded adaptive gate placement | 24 target recoveries; 24 no-gain cases; 3 special fixtures; 8 invalid cases | 22/22 |

These verifier counts sum to 136, but include repeated count, schema, source-status, containment and claim-boundary checks. They are not 136 independent mathematical replications. Checkpoints 09 and 11 recompute limited SciPy references; 12–17 chiefly inspect saved results and summaries. This audit separately reaggregated recorded rows and reproduced key extrema, but did not rerun those scientific programs.

Sampling checkpoint 13 reported all 96 distributions within its six-standard-error-plus-one-count envelope. Maximum full-register category frequency discrepancy was 0.021079601187168867 and maximum per-qubit discrepancy was 0.022480383639097767. Those finite-sample errors are not zero, despite the passing acceptance result. The report says the threshold preceded inspection; this audit did not establish a signed preregistration.

Checkpoint 17 recovered all 24 constructed targets, with fidelity 1.0 and zero target/replay distance. Its no-gain fixtures applied zero gates, but maximum state difference was 2.355394223065532e-16: numerical preservation, not byte identity. The three-step plateau example demonstrates a specific bounded search behavior, not general optimization or learned intelligence.

Most decisively, seven recovered Python source entries were compared across the later archives against checkpoint 09. All 49 comparisons were byte-equal. These modules did not improve through those checkpoints; the tests and understanding of them expanded. New test harnesses and verifier fixes are separate work.

Sources: checkpoint_inventory/checkpoint_09_17_inventory.md; checkpoint_09_17_read_audit.json contains archive paths, complete report text, raw result rows, verifier summaries, execution metadata and each source comparison. record_level_aggregates.json contains the fresh saved-row calculations.

**5. Corrections in reasoning and evidence quality**

The initial JARVIS check mixed coordinate validity with the nat atom-count comparison. The preserved initial checks marked coordinate_and_atom_counts_consistent:false. The revised checks separated these concerns: coordinate_shapes_and_element_counts_consistent:true while nat_metadata_matches_supplied_structure remained false. This prevented one ambiguous diagnostic from standing for two different questions.

Later provenance work established that all 42 nat values matched the official primitive-cell counts, while all 40 available DFT-SCF archives matched the serialized computational-cell atom counts. This resolves the meaning of those differences; it does not mean 42 corrupted structures were repaired. The earlier README itself had explicitly called them flags, not proven corruption. The independent historical formula study separately traced four formula discrepancies to behavior consistent with deletion of the digit 1 in a historical exporter. The raw scientific source was preserved.

The later Bible review also exposed quality gaps: an incomplete source archive, a 109-count nested-word overstatement, missing full-converter execution coverage, and a test oracle that repeated the converter's incomplete text handling. More thorough review found 11 truncated words and identifier-remapping losses/duplications. Finding those defects is stronger detection evidence; it is not evidence that those converter defects have all been repaired.

The defensible research improvement is more precise classification, fuller tracing of dependencies and source representations, and broader end-to-end review. No numerical before-and-after false-discovery rate over a fixed representative research task set exists in the inspected records.

**6. Continuing errors and why an overall score would be unsupported**

The recent Q8 error ledger consolidates 55 distinct classes from selected September 8–18 records, with 106 evidence references. It is not a complete incident stream. Report dates often substitute for exact occurrence times. Therefore it cannot serve as the denominator for all errors since JARVIS or prove a percentage of errors eliminated.

The monitor retained 17 events, but its recent windows contained zero substantive cycles, zero validation executions and zero delivery attempts. Its comparable current rate is null. These zero observations indicate missing coverage of the current work, not perfect reliability. Its old 17/467 candidate-language incidence concerns a different 2024 period and is not a verified JARVIS error-rate baseline.

There is direct counterevidence to a claim that old mistakes stopped recurring: later transition work again suffered cross-shell quotation loss, a guessed-schema TypeError, and archive-path validation trouble. Candidate tests passing later do not erase those failures. The separate Q8 core test records contain the same 20 scenarios in two runs, not 40 distinct capabilities. A USB-junction fixture remained not run and cannot be counted as a pass.

This audit also retained three setup/harness problems in the paired replay: shell expansion in a help query, an existing PowerShell script-policy rejection before Node execution, and omitted import.meta.url initialization in the first VM harness. The corrected harness ran in a new directory. No execution policy or original QEL module was changed. The checkpoint inventory review additionally records an oversized display response and a pre-call orchestration parse failure. These are reasons to preserve exact receipts and avoid claiming an error-free process.

A valid overall assistant or project improvement percentage would require preserved comparable versions, the same scored tasks, stable definitions of success and error, enough representative attempts, and complete before/after recording. Those prerequisites are absent. The proper result for that metric is "not measured," not an invented percentage and not 0%.

Sources: historical_context/monitor_observation.json, later_build_failures.json, q8_audit_context.md; independent_review/; paired_validation/SETUP_FAILURES.json and FIRST_EXECUTION_FAILURE.json; checkpoint_inventory/checkpoint_09_17_inventory.md.

**7. Practical conclusion and evidence use**

The strongest actual software gain is the guarded-path correction of five known invalid-input false successes, reproduced on the laptop with no change to the 36 valid outputs. The matched numerical-accuracy gain is exactly zero on the 24 common ground-energy outputs. The later scientific work provides eight additional tested question families with unchanged recovered modules; it increases documented coverage rather than demonstrating training or a faster/better solver. Overall assistant reliability remains an open measurement, and continuing mistakes are recorded.

The packet contains the successful results, original and corrected audit harnesses, experiment conditions, source copies, failed-attempt evidence, independent review and exact source locations. It is designed so the narrow numerical conclusions can be inspected instead of accepted on my assertion. Raw private project source in this packet is for the owner; nothing in this audit authorizes publication or commercial use.

Original project files and prior archives remain unchanged. The audit is an additive research record. No owner signature was fabricated. No new SHA witness was generated. Content comparisons in this audit are direct byte comparisons, not claims of cryptographic authentication.

