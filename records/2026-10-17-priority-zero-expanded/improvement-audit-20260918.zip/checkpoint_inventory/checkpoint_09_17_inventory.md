Agent GAUCIA

# Checkpoints 09–17: source and evidence inventory

Owner: Sherman G. Laing / Quantum.Earth.Laing
Review: September 18, 2026. Device: DESKTOP-EI6MFFI.
Method: Read existing ZIP entries through PowerShell/.NET; compare archived source bytes; aggregate saved JSON rows. No scientific program or verifier was rerun. No existing artifact was modified. This report and its two JSON companions are additive audit outputs, unsigned, with no new fingerprints.

## Findings

Eight scientific study domains are represented: 09, 11, 12, 13, 14, 15, 16 and 17. Checkpoint 10 is preservation only. Embedded predecessor ZIPs were not opened or counted. All scientific domains reuse the same 24 preserved 8×8 Hamiltonians; case counts are repeated controlled transformations of those inputs, not independent materials or a representative workload sample.

The eight final verifiers report 136 passing checks in total: 12+11+14+18+20+20+19+22. These include repeated count, schema, source-status, containment and claim-limit checks. They are not 136 independent capabilities or a project-wide error rate.

Seven recovered Python source files were directly compared against checkpoint 09 in each later scientific archive. All 49 comparisons were byte-for-byte equal. Hence these checkpoints expanded evidence and experiment coverage; they did not change those recovered QEL modules. New harnesses and one verifier correction are separate from source improvements.

## Per-checkpoint inventory

| CP | Question / distinct coverage | Saved raw cases and outcomes | Principal maximum numerical error | Saved final verifier | Existing QEL sources |
|---|---|---|---|---|---|
| 09 | Non-eigenstate energy conservation while probabilities move | 72 records = 24 Hamiltonians × 3 times; 72 show basis-probability change | Energy drift 3.197442310920451e-14 eV; norm drift 5.551115123125783e-16 | 12/12 | Baseline for this comparison; archive reports unchanged from08 |
| 10 | Restore canonical08 to USB | 247,621,252 bytes;50 ZIP entries;248,111,024 uncompressed bytes read;354 transport parts | Not a scientific experiment | Length and entry-count fields true; no scientific verifier | No scientific study repeated |
| 11 | Sequential versus direct time evolution | 72 records = 24×3 time pairs; minimum fidelity1 | Unitary composition defect8.049200894839508e-15; top-level state L2 difference3.0846876067907084e-15 | 11/11 | 7/7 byte-equal to09 |
| 12 | Deterministic full-register and per-qubit measurement/collapse | 120 full-register +216 qubit records;6/6 invalid draws rejected | Full probability error0; qubit probability error4.440892098500626e-16; post probability-sum drift8.881784197001252e-16 | 14/14 | 7/7 byte-equal to09 |
| 13 | Seeded Born-frequency consistency and repeatability | 196,608 measurements across24 full +72 qubit distributions,2048 trials each;96/96 within envelope;768 full and2304 qubit repeats match;2304 seeded/draw comparisons match | Full category frequency error0.021079601187168867; full total variation0.02996718158267134; qubit frequency error0.022480383639097767 | 18/18 after verifier repair | 7/7 byte-equal to09 |
| 14 | Density-matrix dephasing and amplitude damping | 48 reduced states;240 dephasing +240 damping records;13/13 invalid cases rejected | Dephasing analytic difference0; damping analytic difference2.220446049250313e-16; trace drift4.441474310096328e-16; Hermitian defect5.551115123125783e-17 | 20/20 | 7/7 byte-equal to09 |
| 15 | Complementary subsystem entropy and spectra | 96 state +192 partition records;48 time-change comparisons;5/5 invalid cases rejected | Complement entropy difference2.4450927393893096e-15 bits; nonzero-spectrum difference6.661338147750939e-16 | 20/20 | 7/7 byte-equal to09 |
| 16 | Basis transformation and phase interference | 120 basis +72 interference records;72/72 visible phase effects in Hadamard basis;5/5 invalid inputs rejected | Basis path difference2.7755575615628914e-16; computational probability difference after phase1.6653345369377348e-16 | 19/19 | 7/7 byte-equal to09 |
| 17 | Bounded adaptive gate placement, no-gain behavior and depth limits | 24/24 known targets recovered;24 no-gain records;3 special fixtures;8/8 invalid cases rejected;360 recovery candidate evaluations | Recovery target and replay distance0; no-gain state distance up to2.355394223065532e-16 | 22/22 | 7/7 byte-equal to09 |

The no-gain records in17 show zero applied gates, but their states are unchanged only within floating-point tolerance: maximum recorded state distance is2.355394223065532e-16. Do not describe them as byte-identical.

## Acceptance criteria and independence

-09 and11: most numerical thresholds are<1e-10; fidelity>1−1e-12. Their verifier scripts recompute limited SciPy matrix-exponential references. This is stronger than checking only the report, but it is not proof of an independent underlying numerical library.
-12: probabilities/collapse support use1e-14; post-state norm/sum use1e-12. Its verifier checks saved result summaries rather than rerunning the physics.
-13: harness uses a six-binomial-standard-error envelope plus one-count resolution; the report says it was chosen before inspection. Maximum standardized category error3.1110318314615992 and qubit error2.1594067836756494. The verifier checks saved rows and flags; it does not rerun196,608 draws.
-14–17: predominant numerical threshold1e-12, plus exact expected case counts, parameter sets and categorical outcomes. Their final verifier scripts are structural checks of archived result JSON; many checks trust precomputed summary fields.
-The final archived scripts specify acceptance criteria, but this inspection found no signed pre-run commitment proving independent preregistration. Do not relabel final scripts as independently established advance criteria.
-Current record-level aggregation independently reproduces key extrema and boolean totals from saved rows, without regenerating scientific outputs. It cannot establish whether the original mathematical implementation was independently correct.
-All08-through17 evidence remains classical simulation. The sampled three-qubit fixtures do not demonstrate hardware quantum advantage, universal optimizer performance, new trained weights, or an across-workload speed/accuracy gain.

## Preserved failures and repairs

-09: generic browser launch denied; Edge/Firefox launches produced no download; incomplete Base64 staging not credited. Canonical08 USB synchronization remained pending at09.
-10: browser download failure and signed-transfer upload HTTP502/receive error retained.354 bounded segments subsequently restored08. This is an actual preservation recovery, not a new scientific capability.
-12: first USB verification failed from nested PowerShell variable expansion; corrected script then failed because the built-in ZIP assembly was not loaded. Explicit assembly loading enabled verification. QEL sources and scientific study were unchanged.
-13: original independent verifier exited1 with KeyError('containment') at2026-09-18T18:56:34.932516+00:00; it read execution['containment'] instead of execution['bootstrap']['containment']. The corrected verifier passed18/18. The failed0.064180-second and corrected0.064140-second launch receipts are retained. Only verifier code was corrected.
-17: single Base64 write produced invalid data and failed decoding; no successful archive credited. Eight bounded chunks produced an864,709-byte ZIP with44 entries and1,204,924 uncompressed bytes read. The recovery archive preserves this history.
-No additional failed scientific run was identified in the selected final archives11,14,15,16. This is a source-bounded observation, not proof no earlier failures occurred.

## Exact archive and entry mapping

Base: ./REDACTED_LOCAL_ROOT/QEL_Q7\Owner_Backups\20260918\QEL_Extended_Learning
For09,11,13,14,15,16 use Checkpoint_NN\QEL_Extended_Learning_Checkpoint_NN_20260918.zip.
For12 use Checkpoint_12_Finalized\QEL_Extended_Learning_Checkpoint_12_20260918.zip.
For17 use Checkpoint_17_Recovery_01\QEL_Extended_Learning_Checkpoint_17_Recovery_01_20260918.zip.
For10 use Checkpoint_10_USB_Restoration\QEL_Extended_Learning_USB_Restoration_Checkpoint_10_20260918.zip.
Scientific entry prefix: qel_extended_learning_NN_20260918/. Each contains REPORT.md and verification/verification.json.
10 entry prefix: qel_usb_restoration_10_20260918/; receipt QEL_Extended_Learning_08_USB_Restoration_Receipt_20260918.json.

| CP | Result entry under scientific prefix | Verifier source |
|---|---|---|
|09|results/qel_noneigenstate_energy_conservation.json|verify_qel_noneigenstate_conservation.py|
|11|results/qel_time_composition.json|verify_qel_time_composition.py|
|12|results/qel_measurement_semantics.json|verify_qel_measurement_semantics.py|
|13|results/qel_seeded_sampling.json|verify_qel_seeded_sampling.py|
|14|results/qel_density_noise_channels.json|verify_qel_noise_channels.py|
|15|results/qel_entanglement_entropy.json|verify_qel_entanglement_entropy.py|
|16|results/qel_basis_interference.json|verify_qel_basis_interference.py|
|17|results/qel_adaptive_gate_placement.json|verify_qel_adaptive_placement.py|

Compared source entries under each scientific prefix: source/qel_quantum_energy_optimization_v1.py(7637bytes),source/qel_qpu_emulator_kernel_v1.py(21384),source/qel_quantum_common_kernel_v1.py(16923),source/qel_quantum_suite_v1.py(13185),source/qel_quantum_state_transition_v1.py(9516),source/sgl_prime/__init__.py(70),source/sgl_prime/core.py(26152).

## Provenance and companion receipts

The original scientific execution receipts identify Linux CPython3.12.14 at /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3 with a seccomp networking filter. They do not identify the Windows laptop as the original computation host. This review and its saved-record aggregations executed through Node Zero.

checkpoint_09_17_read_audit.json contains all nine archive paths, full extracted report texts, raw scientific result JSON including all rows, saved verifications, selected verifier threshold lines, execution metadata, preservation records and the49 per-path source byte outcomes. It was written additively and parsed back successfully.
record_level_aggregates.json contains observed record counts and recomputed extrema/boolean totals. This is descriptive accounting over saved results, not a rerun of the scientific tests.
This review had one oversized display response and one orchestration string parse failure before a remote call; neither modified scientific files or executed a study. Bounded successful calls produced the preserved audit evidence.
