# Priority Zero — scientific corrections and proof review

Revision 2, October 16, 2026. Owner: Sherman G. Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting preparation and review: Codex and three task agents. This is a review edition; public release approval remains pending.

This revision corrects five known numerical/API boundaries, completes the mathematical review of the two selected educational manuscripts and their accompanying bridges, and extends reproducibility of selected materials findings. The earlier edition remains unchanged. Original mistakes, reviewer mistakes and later corrections have distinct identities; preparation dates do not replace research dates.

## What was corrected

| Item | Correction and evidence | Boundary of the result |
|---|---|---|
| Tiny angular error | Zero gain or a step inside the stated deadband now retains an unchanged-error ratio of one; the calculation avoids an unstable tiny squared denominator. | A scalar sampled ratio, not a physical stability theorem. |
| Temperature acceptance | Acceptance tests the error magnitude, including negative errors and the strict threshold. | One acceptance predicate, not proof of a completed scientific run. |
| Subspace projection | Disabling normalization preserves the projected support mass, including genuine zero support. Invalid overflowed input normalization is rejected. | Floating-point tolerances are explicit; this is not an exact positivity certificate. |
| Noise-scale labels | The first sampled scale is identified honestly. Scale-one bias is tied to its actual position or reported absent. | Callers must handle an absent scale-one observation. |
| Workflow membership | A declared one-to-one naming map compares actual memberships and rejects duplicates or unrelated names. | Equal set sizes alone are no longer accepted as agreement. |

The [correction module and instructions](reproduction/corrections/README.md) supply a separately authored teaching implementation with 16 passing focused test methods. Twelve private focused methods compare the retained original source versions and their corrections. The full original programs are not represented as having passed their complete dependency suites: an initial import stopped because SciPy was unavailable, and the scale test uses a deterministic sample fixture on the selected path. Historical nominal results have not been relabeled as failed experiments.

Review found an additional error in the new projection adapter: finite large diagonal entries could sum to an infinite trace and incorrectly return zero support. That version and observed result were preserved; the corrected adapter rejects the nonfinite trace. A too-strict floating-point assertion was also retained and corrected using an explicit tolerance. These are newly documented preparation mistakes, separate from the historical findings.

## What the complete selected proof review covers

| Selected material | Coverage | Result |
|---|---|---|
| [Complex analysis](mathematics/teaching-complex-analysis-proofs.md) | All 733 source lines, 55 original coverage units, nine worked examples and nine exercises; six added prerequisite units | Missing prerequisite arguments supplied, hypotheses and subsidiary steps clarified; 20 recorded change entries. |
| [Advanced mathematics](mathematics/teaching-advanced-mathematics-frontiers.md) | All 573 source lines, 122 coverage units, 21 worked examples and 12 exercises | Abbreviated derivations completed; measurement, complexity and zero-probability assumptions made explicit; 29 recorded change entries and 18 passing finite arithmetic/integrity checks. |
| [Mathematical bridges](mathematics/BRIDGES.md) and [proof appendix](review/proof-bridges/PROOF_APPENDIX.md) | Eight bridge records, five worked lessons and six foundation sections | Identities and examples checked, assumptions made explicit and one exact-versus-rounded fixed-point statement corrected. |

The 1,306 manuscript source lines, 30 examples and 21 exercises are coverage counts, not discovery counts. Change entries include exposition and review-status changes; they are not counts of false theorems. The original example answers were retained. Each manuscript received a full reading plus a separate agent cross-review. The bridge derivations also received cross-review. No mathematical blocker remains in this declared scope under the recorded assumptions.

For the equal positive channel probabilities q, the exact fixed-point diagonal is `(3/4 + q/(8-4q), 1/4 - q/(8-4q))`. At the smallest positive binary64 q, it rounds to `(0.75, 0.25)`. The earlier text omitted that rounding qualification. The revised argument states the channel order and the energy ordering and orthogonality assumptions used in the deflation proof.

The coverage and exact change records are in [complex-analysis review](review/proof-complex/REVIEW_REPORT.md), [advanced-mathematics review](review/proof-advanced/REVIEW_STATUS.md) and [bridge coverage](review/proof-bridges/COVERAGE.json). Each chapter identifies imported theorems separately from proofs supplied locally. Historical drafts inside the review folders retain their original wording and relative references as evidence; the current chapters are the two links above.

“Complete” refers to all content in these selected chapters and bridge materials. It does not mean every theorem in their cited literature was reconstructed from axioms, that a proof assistant verified the work, that outside scientific peer review occurred, or that an open problem was solved. The eight project research questions remain separate from the checked elementary derivations.

## Materials findings and reproduction

The original dated public JARVIS-DFT 2D download was reacquired from its recorded URL. It contains 1,103 records and matches the recorded ZIP/member sizes. Both ZIP and JSON member now have recorded SHA-256 identities. No historical private input digest was recovered, so matching URL/version and sizes do not alone establish identity with every byte used by the original run.

A new independently authored reader reproduces the selected descriptive findings against that pinned input: the 65-field union, 1,861,469 scalar leaves, 355 missing-value rows, 42 atom-count differences and their 42 species-total follow-up rows. The two adverse check flags remain false. The 40 supported classifications and two unresolved classifications retain their distinct status; the unresolved cases are not silently converted into successful results.

See [materials reproduction instructions](reproduction/corrections/materials/README.md) for the source URL, input pin, definitions, commands and limits. Eight focused materials test methods passed, separately from the actual source recount. The input is obtained separately from its source; the public packet does not redistribute the full third-party dataset. The retained original analysis program has not been recovered from the inspected records. Full geometric diagnostics, every field's scientific analysis, historical execution identity and physical calibration therefore remain outside this reproduced descriptive subset.

Previously checked Q8 and Bible evidence remains in the packet with its original scope and receipts. This revision does not turn saved calculations into fresh measurements or repeat unchanged optimizers, timing benchmarks, physical quantum-computer runs or whole-corpus exports.

## Preservation and publication

The prior research packet, exact originals and correction history are retained separately. Package verification compares file membership and bytes with a manifest, while a separate retained manifest identity detects replacement of both the package and its inventory. Hashes establish byte consistency relative to that reference; they are not authorship authentication, trusted timestamps, scientific certification or an indelible attribution mark.

USB preservation is a separate destination operation: verify sources, copy the explicit inventory, read the copied bytes back and compare every size and hash, then save a receipt. A tested copy program or a prepared inventory is not evidence that this destination copy has occurred. The private preservation record reports that operation separately from this research edition.

The exact [project license](LICENSE.md), [edition scope](LICENSE_SCOPE.md) and applicable upstream rights remain attached. Public posting requires the owner's fresh approval of this exact revised selection. Wider chronological integration, unavailable original sources and physical calibration remain clearly identified review work; none is concealed by successful local checks.
