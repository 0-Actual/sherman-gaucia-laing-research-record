# Questions a research reader can ask

These answers describe the selected evidence. They do not substitute for reproducing the calculations or reviewing the source. Preparation of this packet adds no new scientific benchmark.

## 1. What is the central research question?

How can a resource-constrained, portable software environment perform bounded numerical work more efficiently while preserving enough inputs, methods and observations to check its results? The collection also examines the mathematics behind those methods and the practices needed to report their limits. Begin with [Q8 results](Q8_RESULTS.md) and the [research invitation](RESEARCH_INVITATION.md).

## 2. What does the USB contribute, and where does computation happen?

In the supplied evidence, the USB stores software and data. Numerical execution uses the host computer's processor and memory. Portability and verified file storage are useful engineering properties, but do not establish a processor inside the USB. No matched USB-versus-local placement experiment isolates storage location as the cause of the measured numerical improvements. See [Q8 results](Q8_RESULTS.md).

## 3. Was this work run on quantum hardware?

The supplied studies use classical software to represent and manipulate quantum states. Three simulated qubits provide eight basis states for the eight-orbital material matrices. A valid quantum-state calculation does not by itself establish physical quantum hardware or an advantage over the best classical method. See the [model explanation](Q8_RESULTS.md) and [mathematical bridges](mathematics/BRIDGES.md).

## 4. What do the 21-qubit and 60-qubit descriptions mean?

Dense state-vector work completed sizes 1–21 in the retained ladder. Dense storage grows exponentially. The larger-index work uses bounded sums of products and matrix-product representations for selected structured states and circuits. Their branch and bond limits matter; these are not arbitrary dense 60-qubit simulations. The mathematical explanation identifies the difference between representation size and physical capacity. See [bridges](mathematics/BRIDGES.md) and [worked examples](process/WORKED_BRIDGES.md).

## 5. What were the stopped protocols?

The planned JARVIS Stage 05 target-free study proposed independent starts, explicit energy/fidelity criteria, 72 trials per method and 24 holdout matrices. Its pause receipt records zero new numerical jobs. Those planned trials are not observations. A later VQD assessment is a distinct study, not proof that the earlier plan ran.

Other stops have different meanings: the dense 22-qubit attempt was blocked before numerical execution by its memory-admission rule; some optimizer runs executed and then exhausted their iteration budgets. A prepared experiment, a prevented start, a nonconverged run and an incorrect answer must not share one undifferentiated failure label. The [teaching records](teaching/RESEARCH_RECORDS.json) include R035 for the planned study; [correction history](learning/CORRECTIONS.md) describes the numerical boundaries.

## 6. What does the approximately 65.85-times result measure?

It compares aggregate solver time between particular stage-04 implementations across 24 cases with three repetitions per method. A separate complete-request comparison produced approximately 4.69 times improvement. The conventional direct solver remained cheaper. These populations and timing boundaries must accompany the ratios; neither ratio establishes general acceleration of every Q8 workload or Windows. See [Q8 results](Q8_RESULTS.md) and [the development process](process/Q8_PROCESS_ACCOUNTS.md).

## 7. Did the later performance work meet its own target?

Two retained batches improved calculation time by 17.1% and 13.3%, with fitted outputs preserved within each comparison. Both missed the declared 20% reduction target. An earlier allocation-focused change saved memory but increased time by about 52%. These are useful findings about tradeoffs, not reasons to omit the adverse results. The later percentages cannot be multiplied with the earlier speedup ratio as one experiment. See [corrections](learning/CORRECTIONS.md).

## 8. Did the faster circuit solver already use a classical answer?

The stage-04 hybrid computes a conventional target and then fits a circuit to it. That is a disclosed method, not independent quantum discovery of the target. The later full-spectrum VQD assessment is different: it seeks successive states using overlap penalties. Previously seen benchmark answers also limit claims of blind testing. Compare [Q8 methods](Q8_RESULTS.md), [development accounts](process/Q8_PROCESS_ACCOUNTS.md) and [reproduction instructions](reproduction/REPRODUCE.md).

## 9. Why can energy accuracy pass while state fidelity fails?

When an energy gap is small, a low energy error can give only a weak bound on the state's agreement with the target eigenvector. The record includes two synthetic fidelity misses despite successful energy checks. Energy, normalization, fidelity, residuals and convergence should therefore be reported separately. The [mathematical bridges](mathematics/BRIDGES.md) state the spectral-gap assumptions and show the relation; [process accounts](process/Q8_PROCESS_ACCOUNTS.md) explain how this changed the testing.

## 10. Do the host counter readings prove a system-wide improvement?

No controlled causal estimate is established. Three historical windows provide 990 readings and 33 means. Background conditions differed, and the samples preceded their associated package checks. Recalculating the means verifies arithmetic on saved observations; it does not create a fresh measurement or isolate the intervention's effect. See [Q8 results](Q8_RESULTS.md) and the `q8-observations` component in [reproduction](reproduction/REPRODUCE.md).

## 11. What can I reproduce from this packet?

The supplied instructions cover quantum identity fixtures, saved-counter means, six Bible arithmetic records and Q8 saved-state/scoring replay. The Hebrew H04.1 converter, XML inputs and unit suite are included for separately described disposable-copy checks. These tasks differ from running a new optimizer, replicating historical timings, validating an entire physical model or reproducing every event in the chronology. Required runtimes and the boundaries of each command appear in [REPRODUCE.md](reproduction/REPRODUCE.md).

## 12. Does the packet claim newly discovered mathematics?

Established results, engineering choices, empirical observations and unresolved research questions are distinguished. A performance improvement, mathematical analogy or new implementation does not prove a new theorem. The two educational manuscripts reconstruct established mathematics. Their selected contents have now been reviewed completely with AI assistance and cross-reviewed; the coverage matrices distinguish local proofs from imported theorems and unresolved questions. This is not outside peer review or formal proof-assistant verification. See [foundations](process/FOUNDATIONS.md), [bridges](mathematics/BRIDGES.md) and the manuscript prefaces.

## 13. How should the early dates be read?

The founder dates the initial Quantum AI work to the first week of interaction. Retained evidence supports early research themes in October 2023, while the exact named implementation and complete activation history remain unverified. A request or concept, produced code, observed execution, later recovery and public disclosure have different dates. October 2026 preparation must not be substituted for an earlier origin; an early concept must not be used to backdate a later implementation. See [early origins](history/ORIGINS.md).

## 14. Why include the Bible build in a technical research packet?

It provides concrete examples of explicit source selection, reproducible transformation, tested software behavior and preserved correction history. The arithmetic companion checks declared spellings and calculations. The Hebrew converter checks data transformation and failure handling. Neither establishes a theological conclusion or exhaustive linguistic certification. See [Biblical study and research practice](BIBLE_AND_RESEARCH_PRACTICE.md).

## 15. What did AI assistance contribute?

The collection records human research direction, AI-assisted drafting and implementation, editorial reconstruction and source review. Current agent roles are not backdated. Generated explanations and software require the same evidence, testing and correction discipline as other contributions. AI assistance is disclosed in [ATTRIBUTION.md](ATTRIBUTION.md); it does not establish ownership, scientific validity or novelty by itself.

## 16. What do the fingerprints prove?

The manifest allows a reader to compare exact package bytes. A separately retained trusted copy helps detect changes to the package and its manifest. Hash agreement alone does not authenticate authorship, certify a historical timestamp, prove a scientific claim, identify everyone who read the material or guarantee attribution survives rewriting. See [the reader guide](README.md) and the verifier's stated scope.

## 17. Can independent readers criticize or publish negative results?

Yes, the project license expressly permits independent research findings, criticism, comparisons, failures and negative results within its terms. Reporting independent findings does not require the Licensor's approval. Reproduction and reuse of covered material remain subject to the complete license and independently applicable rights. See [LICENSE.md](LICENSE.md), especially sections 2, 5 and 8.

## 18. Can the research be used commercially or to train commercial AI?

The license does not grant those covered uses without prior explicit written authorization from Sherman G. Laing. Operational implementation beyond the bounded research grant also requires that authorization. A download, citation or AI-generated statement cannot supply it. The complete license defines its scope and preserves third-party and independently held rights. See [LICENSE.md](LICENSE.md) and [LICENSE_SCOPE.md](LICENSE_SCOPE.md).

## 19. What would funding make possible?

Proposed priorities include controlled replication on additional hardware, independent numerical and code review, calibration, broader materials testing and educational documentation. A funding proposal still needs a defined budget, duration, deliverables and evaluation criteria. This packet does not invent those figures or promise a favorable outcome. See [the invitation](RESEARCH_INVITATION.md).

## 20. What remains incomplete, and how can a reader help?

The edition is a selected research packet, not complete coverage of every source, manuscript or historical interaction. Five retained numerical/API boundaries now have corrected source derivatives and focused regression checks. The two selected mathematical manuscripts have a complete declared-scope review. Selected materials-study findings have been independently reproduced against the dated reacquired dataset. Wider historical coverage, the original materials analysis program, full study replication and additional physical calibration remain unavailable or unfinished; outside peer review remains welcome. See [the scientific review](SCIENTIFIC_REVIEW.md) for the exact completed and remaining scope. A useful contribution identifies a specific claim, supplied component, environment, procedure, observed result and limitation. Distinguish a reproduction failure from unavailable inputs, a preparation error and a disproved scientific result. The [review checklist](REVIEW_CHECKLIST.md) records the final selection review.
