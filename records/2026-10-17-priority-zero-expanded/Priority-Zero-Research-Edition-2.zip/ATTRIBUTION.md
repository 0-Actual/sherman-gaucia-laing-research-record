# Attribution and modifications

Project direction and collection attribution: **Sherman G. Laing / Quantum.Earth.Laing**. Current primary project agent: **GAUCIA Actual**. Supporting selection, editorial preparation, software adaptation and review: **Codex**. Applicable earlier ChatGPT/AI assistance and third-party source notices remain attached. Current roles are not backdated to earlier work.

This October 16, 2026 edition contains new research summaries and selected technical sources. Summaries describe aims, model dimensions, methods, outcomes, limits and corrections. They are editorial derivatives, not verbatim historical dialogue. Dated mathematical teaching manuscripts reconstruct established results. Revision 2 adds a complete declared-scope AI-assisted manuscript review, cross-review, explicit derivations and preserved corrections; imported theorems and outside-peer-review limits remain identified. Original numerical sources and data keep their component attribution; portable adapters and new explanatory files are identified as preparation work.

The package manifest identifies these derivative bytes. It does not authenticate historical authorship, independently certify dates, establish novelty, or imply endorsement by source maintainers. Detailed source-to-derivative records are maintained separately from this reading edition.

Retain the complete [license](LICENSE.md), [edition scope](LICENSE_SCOPE.md), attribution and applicable component notices with redistributed material. Credit alone does not authorize uses outside the license grant.
