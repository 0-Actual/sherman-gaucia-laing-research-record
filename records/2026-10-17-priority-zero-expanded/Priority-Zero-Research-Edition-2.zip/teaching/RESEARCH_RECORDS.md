# Priority Zero — research teaching records

Revision 2 navigation: these 94 records retain their earlier documentary scope and historical status wording. The later [scientific correction and proof-review addendum](../SCIENTIFIC_REVIEW.md) records the five completed numerical/API corrections, selected materials-source replay and manuscript review. Read that addendum for the current status; the earlier recorded observations are not rewritten as new executions.

Sherman Gaucia Laing / Quantum.Earth.Laing. Research direction; GAUCIA Actual, primary project agent. AI-assisted documentary preparation by Codex and delegated reviewers.

This edition contains 94 overlapping research summaries, learning cases and mechanism notes: 64 simulation and mathematics records, 18 JARVIS materials-data records and 12 Q8/USB records. They are not 94 independent studies or discoveries. No new experiment was run for this edition.

The account preserves the technical aim, method, dimensions, recorded result, controls and limits. Dates keep their documented roles; an execution date, a source review date and an original inception date are distinct. Each record uses research source references to support traceability.

The records do not themselves distribute every executable dependency or input needed for complete experimental replication. Numerical boundary corrections, dependency assembly and scientific calibration gaps remain visible in the relevant records.

## R001 — Recovered historical core function semantics

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** What do the historical function bodies actually do?

**Method.** Repeated matrix-vector transformation and squared-norm selection. Predicate list filter. Random scalar perturbation.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** Eight saved observations cover nine calls; all eight passed the stated behavior checks. Filtering does not normalize states; the value named energy is squared norm, not Hamiltonian expectation.

**Controls and calibration.** Saved deterministic semantic harness: eight observations/nine calls; no complete application or hardware calibration.

**Lesson and development.** Names must be matched to the implemented quantity: squared norm is not Hamiltonian energy, and a predicate filter is not quantum measurement.

**Limitations and attention.** Some dependencies are absent from the selected historical snapshot, so the complete earlier application cannot be reproduced from this selection. December 19, 2024 initial commit does not date later source to that day.

**Date and role.** Initial Git commit metadata December19 2024; latest snapshot source date separate; October14 2026 observations. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Exact pinned snapshots; later observation harness; incomplete overall pipeline. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0144, RS0079, RS0062, RS0005.

## R002 — Task Alpha classical three-qubit GHZ emulator

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Can a small circuit have an exact auditable known-answer reference?

**Method.** Gaussian-integer amplitudes over shared powers of sqrt(2). H, X, Z, S and CNOT. GHZ preparation with exact probabilities and fidelity. Typed workload validation and integrity checks.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** Saved 82 policy and 73 workload unit methods; 155 total, with eight paired canonical comparisons separately. GHZ exact fidelity one and probabilities one-half at 000 and 111.

**Controls and calibration.** Exact normalization/state/fidelity oracle; 155 test methods and eight separate paired comparisons. Fixed synthetic admission inputs, not hardware calibration.

**Lesson and development.** Exact arithmetic and a declared oracle make a bounded emulator testable; exact GHZ output on a classical computer is not physical entanglement.

**Limitations and attention.** Classical simulation of selected Clifford gates; no physical QPU or speedup. Unkeyed source fingerprints are not signatures. Task Alpha is distinct from the earlier 21-capability Generation A integration.

**Date and role.** 2026-08-25T21:25:00-04:00 declared creation; saved receipts. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Exact bounded classical three-qubit emulator and policy workload. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0150, RS0081, RS0033.

## R003 — LQCP, entropy and three-qubit corrections

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Can historical state, channel and circuit definitions remain valid near numerical boundaries?

**Method.** Scaled finite complex-vector normalization. Projection-residual projective distance. Depolarization/replacement fixed point with scaled parameter weights. Fixed three semantic qubits with extra carrier modes. Circuit API and frozen-result checks.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** LQCP: 108 inherited + 12 C001 + 22 C002 methods = 142; parent fails 13 of new 22, candidate passes all. Entropy: 13 methods, with subordinate 10 high-precision oracle pairs, 72 channel invariance and 100 seeded density subcases. Three-qubit: 22 methods and separate 504-leaf comparison, maximum change 2.53681827024348e-14. Windows review: 16 focused methods, 13 frozen circuits, 383 existing engine checks; distinct populations.

**Controls and calibration.** Parent/candidate regression and boundary comparisons; fixed-point high-precision oracle; three-qubit inherited-output comparison. Counts remain separate.

**Lesson and development.** Preserve mathematical meaning, floating-point representability and source identity as separate checks.

**Limitations and attention.** The independently reconstructed LQCP successor is not the exact original source artifact. Three-qubit reconstruction is 16,248 bytes versus reported original 16,249; original-byte gate remains open. Simulation only; convergence, entropy, phase and carrier size have distinct meanings. 

**Date and role.** Archive label2026-09-04; entropy/three-qubit receipts September5 UTC; recovered/reviewed October14. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Separately versioned numerical successors, partial original recovery and bounded Windows circuit review. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0149, RS0082, RS0067, RS0068, RS0066, RS0024, RS0060, RS0086.

## R004 — Aluminum VQD assessment and additional points

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Can a three-qubit variational circuit reproduce the specified aluminum spectrum?

**Method.** Eight-orbital 8x8 Hermitian Hamiltonians at 24 ordered points. Three-qubit 18-angle RY/RZ/CNOT ansatz. Sequential VQD H_j=H_normalized+4 sum_previous |psi><psi|. Two seeded BFGS starts per band, 400 iteration budget, direct adjoint gradients. Independent dense/SOP final-state replay and Jacobi control.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** Original 192 energies: MAE 3.4501989767139057e-6 eV; max error 2.424081433360925e-4 eV; ~20.582 s. Classical control MAE 2.3408413332703937e-9 eV; ~0.911 s; faster and more accurate. Additional 24 points/192 energies: MAE 1.2888900558943352e-6 eV; max error 4.240288216550425e-5 eV; 23.6091527 s. 187/384 original and 239/384 additional starts stop at iteration budget; largest residuals ~0.00524 and ~0.00961 eV.

**Controls and calibration.** Conventional Jacobi control and independent saved-state reconstruction; original answers previously seen; additional set is same material, not new-material validation.

**Lesson and development.** Mean energy accuracy, eigenstate convergence, runtime and generalization require separate comparisons.

**Limitations and attention.** One material, no physical QPU or quantum advantage; historical benchmark answers already seen. Approximately 859-fold score comparison is not rank or matched runtime comparison. Additional points freeze settings/input before fitting but remain same-material coverage. Saved state replay is not a new optimizer run.

**Date and role.** 2026-09-28 local; verification 2026-09-29T01:19:28Z. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Classical state-vector VQD assessment of one aluminum Wannier model plus classical control. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0145, RS0083, RS0010, RS0063.

## R005 — QEL compact optimizer performance comparison

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Can implementation cost be reduced without changing the saved answers?

**Method.** Reuse trigonometric gate values during adjoint traversal. Do not retain unused BFGS iteration history. Old/new/new/old fresh-process batches. Cache tied to input/settings/runtime/source identity.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** First controlled batch time -17.1%, CPU -15.9%, largest observed process peak -26.8%. Later audit batch time -13.3%, CPU -13.1%, process peak -26.6%. Both batches miss 20% time target; initial allocation rewrite was 52% slower. 192 energies, fitted parameters, attempts, stops and diagnostics match exactly within each batch. Cache valid case accepted and six invalid/stale/corrupt cases rejected; 0.062 s reuse is retrieval, not fresh optimization.

**Controls and calibration.** Two four-process old/new/new/old batches; two observations/version/batch. Live laptop, limited sample; output equivalence checked.

**Lesson and development.** A measured gain can coexist with a failed target; cache retrieval must be separated from new computation.

**Limitations and attention.** Two observations per implementation per batch; live laptop, workload-specific. Old-space limit is not total RSS cap; time budget checked between starts. No system-wide Windows performance or physical energy inference.

**Date and role.** 2026-09-28 local / September 29 UTC saved batch records. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Classical implementation optimization and cache controls on the same VQD workload. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0148, RS0084, RS0065, RS0064, RS0014.

## R006 — JARVIS original local numerical dependencies

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Can the saved solver, input and scoring dependencies be reconstructed?

**Method.** Fixed three-qubit adjoint and separate parameter-shift options. BFGS direct optimizer. SOP circuit kernel and helpers.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** Assessment calls direct refineBFGS, not the separate classical-target fastRefine hybrid. Three omitted required files are located in broader original laptop collection; two match exact retained archive members.

**Controls and calibration.** Source-identity and dependency recovery evidence; no new numerical execution or physical calibration.

**Lesson and development.** An available dependency and an executed dependency are different facts.

**Limitations and attention.** Twenty-five preserved files are not twenty-five executed modules. The selected numerical replay now has a portable adapter in this edition. Complete per-experiment dependency environments and fresh benchmark replication remain separate work.

**Date and role.** Original September 20, 2026 collections; used by the later September 28/29 assessment. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Exact local numerical dependencies; includes imported and unused alternative paths. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0146, RS0083.

## R007 — Generation A 21-capability successor simulation suite and B–D kernel integration

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Can similarly named historical capabilities be separated into explicit mathematical models?

**Method.** Quantum state/unitary/Kraus models, stabilizer codes, target channels, numerical dynamics and estimator mitigation. Distinct classical lattice-field, phase-network and OFDM/QPSK domains. Generation-aware dispatch and bounded beam gate look-ahead.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** RC1 report: 1665 domain + 57 integration = 1722 unique unit methods; 21 capability paths, six workflows, 26 gates separately. Kernel report: 87 behavioral + 59 new = 146 methods; 21 saved checkpoint replays. Migration: 8 corrected successors, 12 primitives, 3 intent choices, 8 non-quantum lanes = 31 generation-bound records.

**Controls and calibration.** Historical RC1 and kernel suites, declared oracles and separate workflow/gate populations; not independent hardware validation.

**Lesson and development.** Use domain-specific models and controls; maintain classical signal/field lanes as classical. Do not backdate corrected successors.

**Limitations and attention.** Counts are preserved report/receipt populations, not new execution or independent scientific trials. No new proof audit or physical QPU validation. Later C002 fixes do not silently rewrite RC1 source.

**Date and role.** August 21 RC1; August 22, 2026 01:01 ET integration report; not March original implementations. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Corrected domain successors and historical behavior reconstructions; exact B–D original bytes remain open. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0143, RS0085.

## R008 — September 18 dense state-vector workload scaling

**Research area and type.** Simulations and mathematics; overlapping work-group summary.

**Aim.** Which dense state-vector sizes completed the declared laptop workload?

**Method.** Two Float64 arrays, 16*2^n state bytes. H/CX GHZ forward/inverse and deterministic full-support four-phase state forward/inverse. Serial workers, 256 MiB reserve, 30 s child timeout.

**Dimensions and units.** Explicit units in each recorded result; overlapping methods, checks, predictions, starts and receipts must not be added as experiments.

**Recorded result.** 25 PASS trials across sizes 1–21 and one admission stop at 22. Nine checks each: 225 repeated check evaluations. 21 qubits: 2097152 amplitudes, 32 MiB state arrays; median 766.6211 ms for specified validation workload. 22 qubits not executed: 307.7109375 MiB free vs 320 required.

**Controls and calibration.** Analytic GHZ and structured full-support forward/inverse controls; 25 trials and 225 repeated checks; 22-qubit admission stopped before allocation.

**Lesson and development.** State storage, process memory, admission policy and algorithm capacity are different measurements.

**Limitations and attention.** Largest demonstrated size under current load, not hard maximum, arbitrary algorithm capacity or dense-matrix capacity. 64 MiB old-space setting is not process-memory cap. Attempt 03 null device field retained; other receipts corroborate context.

**Date and role.** 2026-09-18; final admission observation 23:40:17.343 UTC. source-described creation/execution/review dates; not automatic first-invention/public-disclosure dates.

**Evidence.** Historical laptop experiment in classical state-vector simulation. Existing synthesis and structured review read; selected exact original identity checks; no new experiment or complete repeated code audit.

**Research source references.** RS0147, RS0080, RS0056, RS0078.

## R009 — Squared norm called energy in an early dynamics function

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The historical dynamics routine names sum(abs(state)**2) energy and selects returned states using energy_threshold.

**Method.** Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** There is no Hamiltonian. A nonunitary scaling example gives norm squared four; rejected output states still feed the next gate. The saved bounded observations reproduce these semantics.

**Controls and calibration.** A complete exact early body is preserved in the source record. It can be studied as conventional array processing, not evidence of physical energy selection.

**Lesson and development.** Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.

**Limitations and attention.** The file inception date and intended original physical contract are not established by the capture date.

**Date and role.** Original date not established in this record. Function inception not established; source captured and observed October 14, 2026.

**Evidence.** retained source semantics/static implementation review; not physical measurement. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0087, RS0009, RS0006, RS0062, RS0005.

## R010 — Observer naming exceeds the implemented predicate filter

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The produced observer_effect function retains entries satisfying a supplied predicate.

**Method.** The documentary review separates implementation from the physical implication of the name.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** It preserves order, duplicates and object references; no quantum probability, collapse, renormalization or copied state is implemented.

**Controls and calibration.** Complete exact historical body is preserved in the source record. This is a semantic limit, not a claim that list filtering malfunctioned.

**Lesson and development.** The documentary review separates implementation from the physical implication of the name.

**Limitations and attention.** No missing measurement mechanism is invented.

**Date and role.** Original date not established in this record. Undated historical body; October 14, 2026 source observation.

**Evidence.** retained source semantics/static implementation review; not physical measurement. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0088, RS0008, RS0006, RS0062.

## R011 — Guidance routine has random perturbation but no implemented ethical objective

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The historical guidance routine probabilistically adds a uniform perturbation between -0.1 and 0.1 to numeric decisions.

**Method.** The later review preserves the project attribution but describes the actual perturbation function.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** The inspected body contains no ethical criterion, probability validation, output clipping or optimization objective; deterministic mocked draws confirm the branch behavior.

**Controls and calibration.** Source remains preserved; no claim of learned ethical behavior is supported.

**Lesson and development.** The later review preserves the project attribution but describes the actual perturbation function.

**Limitations and attention.** No broader implementation is inferred from this small routine.

**Date and role.** Original date not established in this record. Undated body; reviewed October 14, 2026.

**Evidence.** retained source semantics/static implementation review; not physical measurement. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0089, RS0007, RS0006, RS0062.

## R012 — Greedy gate placement rejected valid plateau-crossing solutions

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The first placer required each individual chosen gate to improve target fidelity.

**Method.** Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** |00> to |11> needs two X gates; either first gate alone leaves target fidelity zero, so the one-step rule rejected a valid sequence.

**Controls and calibration.** Correction receipt states corrected and retested. This is bounded search, not universal optimizer completeness.

**Lesson and development.** Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.

**Limitations and attention.** Exact first greedy body is not separately identified in this selected register; correction receipt and final implementation lineage remain.

**Date and role.** 2026-08-21. Generation A integration correction cycle; no exact first-failure timestamp.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0090, RS0001, RS0002, RS0003.

## R013 — Mean-square amplitude rescaling was incorrectly associated with coherence

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Historical Algorithm 13 divided a vector by sqrt(mean(abs(psi)**2)) as a coherence-preservation operation.

**Method.** The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** A unit-norm d-dimensional vector then has norm sqrt(d), giving raw probability sum 8 at three qubits. Global rescaling does not establish coherence preservation.

**Controls and calibration.** This was already known before C001; it is not counted as a newly discovered C001 defect.

**Lesson and development.** The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.

**Limitations and attention.** The exact original historical artifact remains distinct from the independently reconstructed reference.

**Date and role.** 2026-09-04. C001 recheck of an older already-corrected model; not the first discovery date.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0091, RS0027, RS0028, RS0029.

## R014 — Algebraically equivalent Ramsey evaluation failed reciprocal scales

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The parent evaluated exp(-0.5*spread*spread*t*t).

**Method.** C001 forms spread*t first, preserving the dimensionless product, then squares it.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** For spread=1e200,t=1e-200 it returned 0 instead of exp(-1/2); reversed scales returned 1; spread=1e200,t=0 produced NaN.

**Controls and calibration.** The corrected v2.1 parent is preserved. C001 reports 108 inherited and 12 boundary methods passing; seven of the 12 boundary methods exposed parent failures.

**Lesson and development.** C001 forms spread*t first, preserving the dimensionless product, then squares it.

**Limitations and attention.** The pre-C001 v2 body is described by the retained report but is not separately selected in this C002 register; no arbitrary-precision claim.

**Date and role.** 2026-09-04. C001 checkpoint 20:19 Eastern; September 5 UTC.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0092, RS0027, RS0028.

## R015 — Finite ratio inputs produced infinite outputs

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** safe_modulation_ratio and coherence_preservation_ratio checked inputs and denominators but not representability of the quotient.

**Method.** C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** 1e308/1e-14 returned positive infinity; the signed function could return negative infinity.

**Controls and calibration.** Bounded correction passes reported regression/boundary tests, preserving ordinary finite behavior.

**Lesson and development.** C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.

**Limitations and attention.** Tiny valid quotients may still underflow to zero; the correction does not guarantee arbitrary relative accuracy.

**Date and role.** 2026-09-04. C001 checkpoint date.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0093, RS0027, RS0028.

## R016 — Unknown circuit operation was skipped while the API reported PASS

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** executeCircuit validated the configuration but not a separately supplied circuit argument.

**Method.** A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** A separate UNKNOWN then MEASURE_Z circuit returned PASS with 10/10 checks; the unknown operation generated zero checks.

**Controls and calibration.** Sixteen focused methods passed; 13 frozen circuits retained exact bodies and 383 existing engine checks. Later same-device candidate test recorded separately.

**Lesson and development.** A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.

**Limitations and attention.** No evidence says malformed operations occurred in the historical production path, which selected validated configuration circuits; candidate deployment is not inferred.

**Date and role.** 2026-09-04. C001 reproduction; isolated Windows candidate checked September 5 UTC.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0094, RS0027, RS0026, RS0025, RS0024.

## R017 — The corrected v2.1 reference still rejected valid extreme-scale states

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** v2.1 normalized using a direct Euclidean norm after validation.

**Method.** v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Finite nonzero [1e300,1e300] and [1e-300,1e-300] overflowed/underflowed the direct norm although the normalized direction is ordinary.

**Controls and calibration.** Parent fails 13 of 22 new precision methods; candidate passes all 22 plus 108 inherited and 12 earlier methods, 142 total. The full parent implementation is preserved in the source record.

**Lesson and development.** v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.

**Limitations and attention.** Extreme relative components can still round to zero; no recovery of information outside the chosen numeric format.

**Date and role.** 2026-09-04. C002 began 20:41 Eastern; September 5 UTC.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0095, RS0021, RS0028, RS0029, RS0067.

## R018 — Near-one fidelity subtraction lost tiny distances or invented self-distance

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** v2.1 evaluated sqrt(max(0,1-fidelity)).

**Method.** v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** It reported about 2.1073424255447017e-8 self-distance for [1+2j,3-4j], while structured perturbations 1e-12 and 1e-300 vanished to zero.

**Controls and calibration.** Saved focused examples yield zero self-distance and retain the structured perturbations.

**Lesson and development.** v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.

**Limitations and attention.** This does not establish sensitivity to arbitrary 1e-300 changes in general nearly collinear floating-point vectors.

**Date and role.** 2026-09-04. C002 cycle, September 5 UTC execution receipts.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0096, RS0021, RS0028, RS0029, RS0067.

## R019 — Three-qubit normalization accepted zero output after overflow

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The reconstructed validator rejected norm<=tol but did not reject an infinite norm before division; lifted reduction also used a direct norm.

**Method.** Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Huge finite input divided by infinity became a zero vector, and lifted reduction could yield a zero-trace density. Invalid NaN tolerance could permit zero-vector division.

**Controls and calibration.** 22 focused methods pass; 504 inherited numeric leaves differ by at most 2.53681827024348e-14 against 1e-12. The reconstructed parent implementation is preserved in the source record.

**Lesson and development.** Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.

**Limitations and attention.** Original exact 16,249-byte object remains unrecovered; results apply to 16,248-byte recovered text.

**Date and role.** 2026-09-04. C002 source-text reconstruction/correction; historical body inception unresolved.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0097, RS0021, RS0031, RS0030, RS0068, RS0032.

## R020 — Entropy uniqueness test confused numerical threshold with mathematical existence

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The historical excerpt rejected 1-(1-eta)*(1-p)<=1e-10 as no unique fixed point.

**Method.** A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** For p=1e-20,eta=0 the exact fixed point is I/2; for p=0,eta=1e-20 it is tau. Only p=eta=0 is nonunique. Near-one subtraction and unscaled products were numerically fragile.

**Controls and calibration.** 13 methods passed with a 760-digit oracle over ten difficult pairs and separate invariance/generated-density subcases.

**Lesson and development.** A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.

**Limitations and attention.** The old missing-full-module statement applies to the narrower historical selection. Complete RC1 source is retained (662 lines, 26,285 bytes); no full Library-object digest is supplied. Mathematical uniqueness is not fast convergence or thermodynamic benefit.

**Date and role.** 2026-09-04. C002 review and September 5 UTC successor receipt.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0098, RS0021, RS0023, RS0022, RS0066, RS0060, RS0086.

## R021 — Dense scaling attempt 01 was stopped before any circuit

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The first dense scaling parent tried to admit a ladder under a 256 MiB reserve plus launch allowance.

**Method.** Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** It observed 269,041,664 free bytes, below the parent threshold. No circuit ran.

**Controls and calibration.** Attempt 01 code and result are preserved.

**Lesson and development.** Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.

**Limitations and attention.** Not evidence of a numerical defect or hard machine-capacity limit.

**Date and role.** 2026-09-18. Attempt day; exact saved timing is in its result object.

**Evidence.** unexecuted numerical stage / admission or pause record; not a failed numerical answer. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0099, RS0056, RS0051, RS0052.

## R022 — Dense admission initially counted runtime reserve twice; the resident supervisor also constrained continuation

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The child admission rule reserved runtime memory after runtime/kernel memory was already reflected in measured free RAM.

**Method.** Child admission used actual post-load free memory; a PowerShell supervisor removed the resident JavaScript supervisor cost for continuation while retaining the same 256 MiB reserve.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** The later report identifies duplicate reserve accounting. Attempt 02 passed sizes 1–13, then the parent stopped before 14 at 334,376,960 free bytes versus 335,806,464 required.

**Controls and calibration.** Attempt 03 continued 14–21. The parent stop and later success are retained as different orchestration states.

**Lesson and development.** Child admission used actual post-load free memory; a PowerShell supervisor removed the resident JavaScript supervisor cost for continuation while retaining the same 256 MiB reserve.

**Limitations and attention.** Memory snapshots vary with other activity; this is not proof of an intrinsic increase in hardware capacity.

**Date and role.** 2026-09-18. Attempts 02 and 03 in the same cycle.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0100, RS0056, RS0053, RS0055, RS0052, RS0054.

## R023 — The dense 22-qubit trial never ran

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** After three successful 21-qubit trials, the driver evaluated admission for 22.

**Method.** The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Required free memory was 335,544,320 bytes including reserve; observed 322,658,304 was short by 12,886,016 bytes.

**Controls and calibration.** Twenty-five completed trials across sizes 1–21 and one stopped child are separate units; no 22-qubit execution is credited.

**Lesson and development.** The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.

**Limitations and attention.** A different load/policy could admit another size, but no such new run is asserted.

**Date and role.** 2026-09-18T23:40:17.343Z. Final admission measurement UTC.

**Evidence.** unexecuted numerical stage / admission or pause record; not a failed numerical answer. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0101, RS0056, RS0078.

## R024 — JARVIS first variational pass missed one of six energy targets

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Two seeded starts and at most 12 coordinate sweeps attempted six ground-energy cases using the unchanged 18-angle circuit.

**Method.** Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Original point 4 ended 0.0004007142024144983 eV above reference versus a <=0.0001 eV goal; five of six passed.

**Controls and calibration.** Original failed point and all other successes remain; no all-targets-passed claim for pass 01.

**Lesson and development.** Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.

**Limitations and attention.** The first pass alone did not isolate landscape, expressivity or numerical cause.

**Date and role.** 2026-09-20. Day stated in original report; first run has separate timestamps.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0102, RS0036, RS0069, RS0038.

## R025 — The first adaptive follow-up still missed point 4

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Four starts and 64 sweeps revisited the already examined original point.

**Method.** A separately declared 256-sweep follow-up followed.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Energy gap improved to 0.00014289359835650828 eV but exceeded unchanged 0.0001 eV target.

**Controls and calibration.** Improvement is retained without reclassifying the miss as a pass or a fresh held-out test.

**Lesson and development.** A separately declared 256-sweep follow-up followed.

**Limitations and attention.** This follow-up was run once; no independent deterministic replay is claimed.

**Date and role.** 2026-09-20. Same-day bounded follow-up, exact time not repeated here.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0103, RS0036, RS0034.

## R026 — The second adaptive follow-up remained above goal

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Four starts and 256 sweeps revisited point 4.

**Method.** Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Final gap 0.00012074495903213744 eV remained above 0.0001 despite a 69.8676% reduction from the initial gap.

**Controls and calibration.** All four saved warm-start refinements and a cold seeded point-4 check reached the target in the later pass. The 256-sweep miss remains unchanged.

**Lesson and development.** Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.

**Limitations and attention.** Adaptive follow-up was not blind or independently replayed; more sweeps alone did not establish convergence.

**Date and role.** 2026-09-20. Same-day second bounded follow-up.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0104, RS0036, RS0035, RS0038, RS0039.

## R027 — Energy accuracy hid two synthetic fidelity misses

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Pass 02 evaluated six representable known-spectrum synthetic states with energy and fidelity requirements.

**Method.** State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** At gap 1e-6 eV, energy error 5.61226507949274e-8 passed but fidelity 0.9438801949621364 missed 0.9999. At gap 1e-8, energy error 2.762947736350209e-9 passed while fidelity 0.7237052008836223 missed; that case also met gradient tolerance.

**Controls and calibration.** Four of six fidelity cases passed; the two misses are substantive negative results, not discarded energy successes.

**Lesson and development.** State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.

**Limitations and attention.** Small residual/gradient/energy alone does not identify a unique ground state at a tiny gap.

**Date and role.** 2026-09-20. Pass 02 report and stress receipts.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0105, RS0038, RS0070, RS0037, RS0074.

## R028 — Passing energy did not mean every BFGS start converged

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The 42 ordered cases used two starts each and up to 400 BFGS iterations after warmup.

**Method.** Report separates stopping reason, energy, state residual and fidelity.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Of 84 starts, 33 reached gradient tolerance and 51 exhausted iteration budget. Largest state residual was 0.0008444199310936169 eV despite all 42 energy targets passing.

**Controls and calibration.** No claim of universal convergence or 84 successful convergence events is retained.

**Lesson and development.** Report separates stopping reason, energy, state residual and fidelity.

**Limitations and attention.** Further convergence at larger budgets is not measured by this receipt.

**Date and role.** 2026-09-20. Pass 02 expanded-validation report.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0106, RS0038, RS0039.

## R029 — Pass-03 baseline and first Rayleigh repair retained many acceptance misses

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** A matched 720-case study compared the previous optimizer, first Rayleigh repair and bracketed revision.

**Method.** The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Baseline passed energy 696/720 but full acceptance 424/720. First repair passed energy 720/720 but full acceptance 681/720: 39 failures remained. All 39 fitted their supplied target accurately; target iteration stalled at a distant lower-bound shift.

**Controls and calibration.** Bracketed revision accepted 720/720, gaining 296 over baseline and 39 over first repair with no lost prior pass. One seed-collision control must also be disclosed (R031).

**Lesson and development.** The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.

**Limitations and attention.** Finite, partly shared synthetic populations do not prove universal convergence; bracket is floating-point, not interval certified.

**Date and role.** 2026-09-20. Final report recorded 21:01:46.962 UTC; individual study times separate.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0107, RS0044, RS0074, RS0046, RS0071, RS0043, RS0041.

## R030 — Wrong zero-gradient flat starts were mistaken for useful stopping points

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Unperturbed circuit fitting began at basis-state flat starts.

**Method.** Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Only 8/64 passed; 56 stopped at zero iterations in wrong states.

**Controls and calibration.** The original 56 misses and corrected finite population are retained.

**Lesson and development.** Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.

**Limitations and attention.** This does not establish escape from every stationary point or universal optimizer success.

**Date and role.** 2026-09-20. Pass-03 supplemental study.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0108, RS0075, RS0044, RS0042.

## R031 — A reused seed made one supposed test already solved

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Matrix-family and optimizer seed reuse made one synthetic initial state nearly identical to the target.

**Method.** Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Initial fidelity was 0.9999999999999993 and parameter maximum difference 4.440892098500626e-16. It supplied an already-solved control, not independent difficulty.

**Controls and calibration.** A separate confirmation began at fidelity 0.09613601511106884 and reached approximately one in 47 iterations. The improvement counts of 296 and 39 remain unchanged.

**Lesson and development.** Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.

**Limitations and attention.** The new confirmation does not retroactively make the original case independent.

**Date and role.** 2026-09-20. Final initialization review within pass 03.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0109, RS0073, RS0045, RS0040, RS0044.

## R032 — Centering cannot recover input information already rounded away

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Affine scale/offset transformations were tested before and after conditioning.

**Method.** The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Conditioned targets passed all 45 represented-matrix cases, but three inputs had already lost information. One intended-state fidelity remained about 0.26515785 even though represented-reference fidelity was approximately one.

**Controls and calibration.** All 45 represented-matrix results and the three input-representation limits remain.

**Lesson and development.** The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.

**Limitations and attention.** Recovering the intended input would require additional precision or original information, not another claim of pass.

**Date and role.** 2026-09-20. Pass-03 affine diagnostic.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0110, RS0072, RS0044, RS0042.

## R033 — Hybrid target computation limits discovery and quantum-advantage claims

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The hybrid first calculates a target conventionally, then fits the Q8 circuit.

**Method.** Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Source groundTarget and target-projector fitting provide a classical answer construction inside the pipeline. No external answer file is not the same as no classical target.

**Controls and calibration.** This is an actual algorithmic limitation, not evidence that an unassisted-discovery claim was ever independently verified.

**Lesson and development.** Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.

**Limitations and attention.** No physical QPU, quantum advantage or universal discovery follows from these software comparisons.

**Date and role.** 2026-09-20. Passes03/04 source and reports.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0111, RS0043, RS0041, RS0044, RS0047, RS0049, RS0010.

## R034 — Stage-04 energy-only baseline missed 18 runs and direct solving remained cheaper

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Five methods were timed on 24 unique cases, with three repetitions each: 72 runs per method.

**Method.** Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Energy-only accepted 54/72. Old and fast hybrid accepted 72/72, but direct mean solver time of 22.815 ms was cheaper than the fast hybrid mean of 111.487 ms; direct complete requests also beat circuit mode.

**Controls and calibration.** No blanket Q8 speedup over the strongest conventional solver is supported.

**Lesson and development.** Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.

**Limitations and attention.** The solver and complete-request populations/timing boundaries differ.

**Date and role.** 2026-09-20. Recorded timing populations, final report day.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0112, RS0076, RS0048, RS0049.

## R035 — Stage 05 target-free protocol was prepared but not executed

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The protocol proposed independent starts and a holdout, target-free solver variants and explicit fidelity/energy acceptance.

**Method.** The numerical protocol was preserved, but no new solver execution began in this stage.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** The redirection receipt says PAUSED_BEFORE_NEW_SOLVER_EXECUTION and new_numerical_jobs: 0.

**Controls and calibration.** The planned 72 trials per method and 24 holdout matrices are not credited as observed data.

**Lesson and development.** A prepared protocol and a completed experiment are separate outcomes; planned populations do not count as observed data.

**Limitations and attention.** A later VQD assessment is a separately versioned study, not proof this protocol ran.

**Date and role.** 2026-09-21T01:05:22.513Z. Exact recorded pause receipt in UTC; not an execution timestamp.

**Evidence.** unexecuted numerical stage / admission or pause record; not a failed numerical answer. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0113, RS0050, RS0077.

## R036 — Low original-path VQD average error concealed unconverged states

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** One full run fitted 192 states from 384 starts on 24 ordered aluminum path points.

**Method.** Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** MAE 3.4501989767139057e-6 eV passed the local goal, but maximum error 0.0002424081433360925 eV and largest residual 0.005244191334342701 eV remained. Of 384 starts, 197 reached gradient tolerance and 187 hit the iteration limit. Two points contributed 94.93% of total absolute error.

**Controls and calibration.** The conventional solver remained both faster (0.911 s versus 20.582 s) and more accurate. No matched timing comparison against the public Qiskit implementation ran.

**Lesson and development.** Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.

**Limitations and attention.** Wavefunction convergence, new materials, physical advantage and commercial value are not established.

**Date and role.** 2026-09-28. Approximately 21:20 Eastern assessment.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0114, RS0010, RS0011.

## R037 — Additional aluminum cases retained substantial iteration-budget stops

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The unchanged VQD method predicted 192 energies at 24 additional same-material points.

**Method.** Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** MAE 1.2888900558943352e-6 eV and maximum error 4.240288216550425e-5 eV passed local goals, but largest residual 0.009607193267454683 eV remained. Of 384 starts, 145 met gradient tolerance and 239 hit the iteration budget.

**Controls and calibration.** Useful bounded additional evidence, not an all-convergence success or a new-material test.

**Lesson and development.** Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.

**Limitations and attention.** No generalization beyond aluminum or universal convergence is measured.

**Date and role.** 2026-09-28. Approximately 21:28 Eastern separate assessment.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0115, RS0010, RS0011.

## R038 — First allocation rewrite saved memory but increased time 52.1%

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Typed-array compact BFGS attempted to reduce resource cost for the same 192-energy workload.

**Method.** The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** The old/new/new/old batch had medians of 17,591.91365 ms for baseline and 26,757.5566 ms for candidate: 52.1014548636% slower. CPU time increased 43.0189%; maximum observed process RSS decreased 40.6022%. All 192 energies and parameters matched.

**Controls and calibration.** This is a completed unfavorable performance comparison, not an incorrect numerical answer.

**Lesson and development.** The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.

**Limitations and attention.** Two runs per version on one laptop are bounded observations; no total-system memory or electrical-energy claim.

**Date and role.** 2026-09-29T02:12:31.070Z. Exact benchmark receipt UTC; September28Eastern.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0116, RS0014, RS0018, RS0012.

## R039 — Flat-array v2 probe remained slower

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** A flat-array variant tested whether allocation organization improved the same optimizer work.

**Method.** Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Four focused rounds preserved iteration counts and identical output; the baseline/candidate speed ratio of 0.806597963663965 is below one.

**Controls and calibration.** The two baseline observations, 281.2636 and 229.6612 ms, and candidate observations, 332.5347 and 300.8971 ms, remain explicit.

**Lesson and development.** Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.

**Limitations and attention.** This focused probe is not the full24-point benchmark and is not an independent material study.

**Date and role.** 2026-09-29T02:14:07.020Z. Exact focused-probe receipt UTC.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0117, RS0013, RS0016, RS0012.

## R040 — Row-array v3 probe also remained slower

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** A row-array variant attempted another BFGS allocation layout.

**Method.** The variant was retained but not selected; cached trigonometry and compact history became v4.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Baseline observations were 284.7159 and 234.2065 ms versus candidate 389.8639 and 402.8986 ms; the reported ratio 0.6545748569085952 is below one. Outputs and iteration counts were identical.

**Controls and calibration.** The unfavorable result remains with actual source and receipt.

**Lesson and development.** The variant was retained but not selected; cached trigonometry and compact history became v4.

**Limitations and attention.** A focused kernel probe is not full-workload timing.

**Date and role.** 2026-09-29T02:15:42.196Z. Exact focused-probe receipt UTC.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0118, RS0020, RS0017, RS0012.

## R041 — Selected performance v4 improved time but missed the 20% target

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The selected angle-cache and compact-history implementation targeted at least 20% less calculation time.

**Method.** The selected code retained the measured gain honestly; a later batch checked it again.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** The four-process old/new/new/old batch decreased median time from 17.8700468 s to 14.8067205 s, a 17.14223994% reduction; target_passed is false. All 192 energies and parameters were identical.

**Controls and calibration.** Useful improvement and a failed target are both true; neither erases the other.

**Lesson and development.** The selected code retained the measured gain honestly; a later batch checked it again.

**Limitations and attention.** This is not a guaranteed fixed percentage; startup is excluded.

**Date and role.** 2026-09-29. Exact UTC is retained in the original benchmark receipt; local date September 28.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0119, RS0065, RS0019, RS0015, RS0012.

## R042 — Audit repeat also missed the 20% target

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** A second four-process batch repeated the accepted comparison.

**Method.** The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** Median time decreased from 18.52155325 s to 16.04999345 s, a 13.34423613% reduction; target_passed is false with identical 192 energies and parameters.

**Controls and calibration.** The second miss is retained separately from the first; neither becomes numerous independent studies.

**Lesson and development.** The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.

**Limitations and attention.** Small live-laptop sample; no causal Windows-wide effect.

**Date and role.** 2026-09-29. UTC receipt; local September 28 late evening.

**Evidence.** retained historical numerical/software result described by a source-linked review. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0120, RS0064, RS0012.

## R043 — Structured 60-qubit labels require branch, bond and verification limits

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** The SOP/MPS bridge represents selected product and GHZ states up to 60 indexed qubits.

**Method.** The later review states compact representation limits and separates the dense 21-qubit trial results.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** SOP caps branches at 64 and throws before overflow. The bridge MPS bond cap is 32, with a local QR omission threshold of 1e-13. Verification uses three selected amplitude witnesses plus norm, not all 2^60 amplitudes.

**Controls and calibration.** These are implementation boundaries, not proof that 60 physical qubits or arbitrary dense 60-qubit states were executed.

**Lesson and development.** The later review states compact representation limits and separates the dense 21-qubit trial results.

**Limitations and attention.** Full historical benchmark-to-version linkage remains limited; the local QR threshold is not a global error certificate.

**Date and role.** Original date not established in this record. Implementation date unresolved; retained later Q8 snapshot and current static review.

**Evidence.** retained source semantics/static implementation review; not physical measurement. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0121, RS0058, RS0057, RS0059, RS0004.

## R044 — Windows observation changes cannot be promoted to causal USB speedup

**Research area and type.** Simulations and mathematics; learning-history case; overlaps work summaries.

**Aim.** Three windows recorded Windows resource counters and then checked the USB package.

**Method.** The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.

**Dimensions and units.** As explicitly stated in recorded result; absence of a count is not replaced by an invented population.

**Recorded result.** 990 readings (3 × 11 × 30) yield 33 means. In all three windows, the last counter precedes USB verification. Checks took 12.5676291, 1.620652 and 9.3315077 seconds against 40 declared files.

**Controls and calibration.** Observed resource changes are preserved; no controlled Windows-wide causal estimate is inferred.

**Lesson and development.** The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.

**Limitations and attention.** Background activity, cache effects and storage-placement causality were not isolated. No new measurements.

**Date and role.** 2026-09-29. Three original UTC observation windows; documentary review October 16.

**Evidence.** historical host-counter observations; causal attribution not established. Complete structured case read; exact source identities linked; historical results not rerun.

**Research source references.** RS0122, RS0004, RS0061.

## R045 — common_kernel_v1

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Normalized ψ∈C^(2^n); density ρ≥0, Trρ=1; Uψ, U=e^(−iHt/ℏ); p_i=|ψ_i|²; Kraus maps ΣK_iρK_i†; partial trace; S(ρ)=−Trρlog₂ρ; concurrence2|ad−bc|; negativity from partial-transpose eigenvalues.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Unitary dynamics preserve norm, inner products, global density spectrum and entropy. Kraus closure ΣK_i†K_i=I gives trace preservation; operator-sum form gives complete positivity. Computational coherence is basis-dependent. Unitary motion does not generally converge or erase information.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0123.

## R046 — computational_stability_v1 (#20)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Matrix conditioningκ(A), Hermiticity/unitarity defects, repeated vs direct e^(−iHt), norm/probability conservation, SVD-backed least squares and normalized residual.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Numerical linear algebra: small residual and small forward error are distinct and linked through conditioning. Exact U hasκ2(U)=1 but floating point repetition accumulates defects. Passing a bounded run does not establish universal numerical stability.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0124.

## R047 — energy_optimization_v1 (#7)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Variational minimization E(θ)=⟨ψ(θ)|H|ψ(θ)⟩ over explicit finite grids, compared to `eigh(H)`. Product RY and Bell-family ansätze are explicit.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Rayleigh–Ritz E≥λmin(H). Grid optimum is only optimum among evaluated ansatz states; general ground state accessibility is not proved. For H=−(X⊗X+Z⊗Z), Bell-family E=−1−sinθ reaches−2 at θ=π/2. Ground-vector fidelity can depend on the arbitrary eigenvector selected within a degenerate ground eigenspace; energy gap is the invariant quantity.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0125.

## R048 — entropic_balancing_v1 (#18)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Partial SWAP Uθ=cosθ I−i sinθ SWAP; random-SWAP channel Tη=(1−η)Id+η Ad_SWAP; separate open replacement toward a declared bipartite target.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Partial SWAP preserves global spectrum and identical-local-H total energy, can create correlations, and is reversible rather than asymptotically mixing. Random SWAP marginal difference contracts by(1−2η), in trace distance by|1−2η|; for0<η<1 full state converges to(ρ+SWAPρSWAP)/2, depending on initialρ. It does not have a unique global fixed state. η=1 gives swap oscillation;η=1/2 gives one-step marginal equality.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0126.

## R049 — entropy_stabilization_control_v1 (#12)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Qubit depolarization D_p(ρ)=(1−p)ρ+pI/2, followed by replacement C_η(ρ)=(1−η)ρ+ητ. Target τ selected by binary entropy inversion plus Bloch axis.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** T(ρ)=aρ+bI/2+cτ, a=(1−η)(1−p), b=(1−η)p,c=η. Unique ρ*=(bI/2+cτ)/(b+c) iff p orη>0; differences contract exactly by a. Unitary transformations preserve entropy; nonunital replacement supplies purification resources. Entropy target does not specify orientation. Original numerical existence gate is incorrect for weak positive channels; C002 corrects it.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0127.

## R050 — error_correction_stabilization_v1 (#3)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Five-qubit [[5,1,3]] stabilizer code; projector P=Π_j(I+S_j)/2; encode one qubit; syndrome projection and Pauli recovery R(ρ)=Σ_s C_sP_sρP_sC_s†. Knill–Laflamme blocks V†E_a†E_bV are tested against scalar identity.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Exactly corrects identity plus all15 single-qubit Pauli errors under ideal recovery. Guaranteed correctable probability under independent error probability p is (1−p)^5+5p(1−p)^4. This is an ideal code/noise/recovery simulation, not a new universal correction theorem or an ancilla/latency/fault-tolerance demonstration.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0128.

## R051 — error_mitigation_v1 (#19)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Readout confusion-matrix inversion; Richardson extrapolation weights Σ_jc_j s_j^k=δ_k0; signed inverse-channel quasi-probabilities for bit/phase flips; symmetry postselection.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Estimator correction, not state recovery. For p<1/2, inverse coefficients((1−p)/(1−2p),−p/(1−2p)), normΓ=1/(1−2p); L-layer sampling overheadΓ^(2L). Atp=1/2 information is erased and inverse singular; calibration mismatch biases result. Richardson cancels polynomial terms to declared order, not all noise.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0129.

## R052 — field_stabilization_v1 (#6)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Classical lattice quadratures q,p∈R^N; K=m²I−c²Δ_d; qdot=p, pdot=−Kq+u+f; PD tracking u=kp(qt−q)+kd(pt−p); implicit midpoint step; optional zero-mode projection.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** E=Δx(pᵀp+qᵀKq)/2. Conservative midpoint preserves quadratic energy in exact arithmetic. Controlled energy accounts for work. Mode frequencies obey ω_k²=m²+4c² sin²(πk/N)/Δx²; leapfrog requires Δtωmax<2 for bounded nondegenerate stable oscillations. With positive damping and restoring stiffness, error modes decay. This is classical finite-difference dynamics, not operator-valued QFT.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static description of a classical model. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0130.

## R053 — noise_reduction_v1 (#17)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Gaussian Ornstein–Uhlenbeck detuning C(t,s)=σ²e^(−|t−s|/τc); toggling pulse function y(t); Varφ=∫∫y(t)y(s)C(t,s)dtds; coherence W=e^(−Varφ/2)e^(−γT)(1−4p_pulse/3)^N.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Models Hahn/CPMG dynamical decoupling and explicit pulse-error costs. Computational populations remain1/2 for the equatorial memory; coherence and fidelity change. More pulses need not improve W because pulse errors accumulate. Markovian factor is not reversed by this idealized sequence.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0131.

## R054 — phase_synchronization_v1 (#9)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Classical phase network θdot_i=ω_i+noise_i+(K/d_i)ΣAij sin[(θ_j−offset_j)−(θ_i−offset_i)]−g sin(θ_i−ω_ref t−offset_i). Equatorial states connect phase error to fidelity (1+cosδ)/2.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Local zero-detuning small-angle error dynamics involve gI+K L_rw; connectivity governs disagreement, pinning controls global reference mode. Adler equation δdot=Δ−Ksinδ locks for |Δ|<K; boundary |Δ|=K has zero linear contraction. Network order parameter1 does not by itself establish lock to the required reference/offsets. Finite noisy simulations are not global convergence proofs.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static description of a classical model. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0132.

## R055 — probability_distribution_control_v1 (#16)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** p∈simplex, amplitude preparation ψ_i=√p_i e^(iφ_i); known-target unitary completion; replacement Tη(ρ)=(1−η)ρ+ητ with diagonal or coherent τ.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** ρ_n−τ=(1−η)^n(ρ0−τ); TV(p_n,p_target)=(1−η)^n TV(p0,p_target). Unique fixed density τ iffη>0; η=0 identity. Same output probabilities need not mean same state, coherence, or phase. Target replacement requires target-description resources, and finite-shot frequencies have sampling error.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0133.

## R056 — resonance_amplification_v1 (#8)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Optical Bloch affine ODE rdot=Ar+b, Γ2=Γ1/2+Γφ. Driven population p_e=Ω²Γ2/[2(Γ1(Δ²+Γ2²)+Ω²Γ2)].

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Positive relaxation gives a stable affine equilibrium. p_e≤1/2 in the steady driven model; FWHM=2√(Γ2²+Ω²Γ2/Γ1). Increasing drive produces saturation and power broadening. Closed-system Rabi probability can reach1 but oscillates. This is driven two-level response, not amplitude amplification in Grover's algorithm or unrestricted gain.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0134.

## R057 — signal_integrity_v1 (#11)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Classical QPSK mapping, OFDM FFT/IFFT and cyclic prefix; multipath/AWGN/carrier-offset model; estimated channel equalization z_k=H*_k y_k/(|H_k|²+λ median|H|²).

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Regularized inverse estimation with BER/EVM and gain metrics. No density matrix or quantum channel is used in the core signal path. Complex numbers alone do not make baseband processing quantum. It is a classical signal-estimation mechanism.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static description of a classical model. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0135.

## R058 — state_regeneration_v1 (#4)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Logical qubit embedded in a 4D code/leakage space. Flagged leakage uses E0=√(1−p)P+Q, E1=√pV_leak V_code†. Recovery uses P and V_code V_leak†. Separate target replacement uses K_i=|ψ_target⟩⟨i|.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Relative logical phase survives inside each coherent flagged branch, allowing recovery. Environment-distinguishable leakage destroys it. Target replacement is state preparation using a known description, not inference of the erased unknown input.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0136.

## R059 — state_reinforcement_v1 (#21)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** GKSL generator Lρ=−i[H,ρ]+Σ(JρJ†−{J†J,ρ}/2), with Jpump=√κ|target⟩⟨orthogonal| and Jnoise=√γ Z.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** For target|+⟩, H=0, Fdot=(κ+γ)−(κ+2γ)F, so F*= (κ+γ)/(κ+2γ), with exponential observable convergence. Fixed-target pumping erases distinctions among input states. Withκ>0 the benchmark has a unique stationary density; κ=0,γ>0 pure dephasing retains all Z-diagonal populations and has many stationary densities despite F→1/2. Numerical tolerance gate and kernel multiplicity issues remain.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0137.

## R060 — state_stability_v1 (helper)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Tensor products, operator sequences/inverses, repeated U†U cycles, substep composition, perturbation distances.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Checks ordinary quantum unitary invariants and numerical drift. Under common U, ||Uψ−Uφ||=||ψ−φ|| and fidelity is invariant: closed unitary evolution alone cannot contract different states.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0138.

## R061 — state_transition_v1 (#1)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Explicit basis/custom/uniform state preparation, Hamiltonian exponentiation, unitary transition and inverse-CDF projective measurement.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Unitarity and normalization validated; measurement returns one basis state. A user-supplied draw makes simulation replayable; it does not change Born's rule or create measurement-free access to an unknown state. Eigenrays are fixed projectively under their Hamiltonian; generic superpositions oscillate.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0139.

## R062 — superposition_stability_v1 (#15)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Three-qubit phase-flip repetition code |0L⟩=|+++⟩, |1L⟩=|−−−⟩; ideal syndrome recovery. Logical error q=3p²−2p³ under independent physical Z-flips.

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** q<p for0<p<1/2; q>p for1/2<p<1. Corrects one Z error, not arbitrary single-qubit Pauli error. Parity accumulation p_n=[1−(1−2p)^n]/2. At logical level remaining errors act as a bit flip in the declared logical basis; encoded protection preserves a manifold of arbitrary logical states within the specified noise model.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0140.

## R063 — thermal_regulation_v1 (#10)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** Two-level Gibbs state e^(−H/kBT)/Z; bath rates Γup=γnbar, Γdown=γ(nbar+1), nbar=(e^(gap/kBT)−1)^−1. Generalized amplitude damping with λ=1−e^(−Γtotal t).

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Excited population p(t)=p_ss+(p0−p_ss)e^(−Γtotal t), coherence magnitude decays e^(−Γtotal t/2), Gibbs fixed point for one bath. Several baths give p_ss=ΣΓup/Σ(Γup+Γdown), not generally a single-bath equilibrium; nonzero heat currents may persist. Fixed-population effective temperature requires specified Hamiltonian/units and an energy-diagonal noninverted state.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0141.

## R064 — wavefunction_stabilization_v1 (#5)

**Research area and type.** Simulations and mathematics; overlapping mechanism teaching note; not an experiment.

**Aim.** Identify the actual mechanism and its domain/assumptions behind the historical capability label.

**Method.** One-qubit Bloch geometry with exact state estimate. Let θ be angular distance to target; apply α=min(gθ,αmax,θ) about the minimal correction axis. V=1−F=sin²(θ/2).

**Dimensions and units.** No independent experiment population or execution metric is asserted by this static mechanism row.

**Recorded result.** No separate measured result is asserted for this field.

**Controls and calibration.** Model assumptions and limits stated in the recorded boundary; row is not a hardware calibration receipt.

**Lesson and development.** Ideal correction gives θ'=θ−α and V'=sin²((θ−α)/2), strictly smaller for θ>0, g>0, αmax>0. Gain0 gives identity. Disturbance is followed by correction, so disturbance-driven tracking differs from autonomous convergence. State-dependent feedback assumes exact estimation and ideal rotations; mixed-state spectrum cannot be purified by it. Source's sampled margin is a sampled diagnostic, not a continuum proof.

**Limitations and attention.** Retain the declared model, parameter assumptions, and version; this summary does not establish fresh execution or novelty.

**Date and role.** Original date not established in this record. Undated mechanism row in 2026-09-17 static review; chiefly associated with August 21 successors, not backdated to March source.

**Evidence.** static mathematical/source-analysis description of a classical quantum simulation. Complete structured mechanism and boundary read; not a repeated proof or code audit.

**Research source references.** RS0142.

## R065 — Identify the dataset before interpreting results

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Keep the exact acquired data population distinct from the whole JARVIS program.

**Method.** The historical study inspected the selected Figshare version-8 archive and traversed the acquired snapshot.

**Dimensions and units.** Population: One acquired JARVIS-DFT 2D snapshot, not every JARVIS dataset or linked calculation. Units: records. top-level fields. scalar-leaf occurrences. downloaded archives.

**Recorded result.** 1,103 records, 65 top-level fields and 1,861,469 scalar-leaf occurrences; linked raw archives downloaded for this census: 0.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Fix the input version and population before comparing findings or describing coverage.

**Limitations and attention.** The raw input archive and analysis code are outside this public companion; no claim of new DFT, quantum-circuit simulation, discovery or hardware validation.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0184, RS0199.

## R066 — Preserve the roles of dates

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** An informal clock annotation could be mistaken for execution or publication time.

**Method.** Use the separately recorded UTC analysis, replay and comparison times, each with its own event role.

**Dimensions and units.** Population: One historical inspection and its replay. Units: timestamps.

**Recorded result.** Analysis: 2026-09-18T01:11:34.580384+00:00; replay: 2026-09-18T01:12:03.433950+00:00; byte-comparison verification: 2026-09-18T01:13:42.423869+00:00.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** A supplied label, recorded execution time, later review and public release are different chronological facts.

**Limitations and attention.** Do not backdate execution, public disclosure or early project origins from an informal annotation; none of these timestamps is presented as independently signed.

**Date and role.** Value: 2026-09-18T01:11:34.580384+00:00. Role: historical analysis execution timestamp as reported by the saved receipt. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0179.

## R067 — Catalog counts and downloaded counts

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** The catalog count and downloaded file population differ.

**Method.** Count source records and distinct identifiers, then compare the recorded catalog population.

**Dimensions and units.** Population: Selected archive and catalog count captured at the historical review. Units: records. distinct record IDs.

**Recorded result.** 1,103 records and 1,103 distinct IDs in the archive versus 1,109 catalog-listed records; catalog_count_matches_download is false.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** An unreconciled scope difference is a finding to retain, not evidence that the analysis failed to execute.

**Limitations and attention.** Cause of the catalog/file difference remains unresolved; do not invent six missing rows or merge a different dataset version.

**Date and role.** Value: 2026-09-18T01:11:34.580384+00:00. Role: historical analysis execution timestamp as reported by the saved receipt. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0158, RS0182.

## R068 — Treat missing data as unknown

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Absent targets and properties can distort summaries if silently filled.

**Method.** Classify missing exfoliation values separately from numeric values and profile all top-level fields.

**Dimensions and units.** Population: 1,103 source records; each missingness count belongs to its named property. Units: values. fields.

**Recorded result.** 748 numeric exfoliation-energy values and 355 missing values (na); 15 top-level fields entirely empty, including Tc_supercon.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Preserve the missingness mask; unknown values are not measured zeros.

**Limitations and attention.** No superconducting transition-temperature result can be inferred from an entirely empty field; keep target-imputation decisions explicit and absent here.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0183, RS0204.

## R069 — Separate count differences from corruption

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** The nat metadata and supplied atomic structure counts differ for selected records.

**Method.** Compare nat, atom-array length and coordinate count without changing source records.

**Dimensions and units.** Population: 42 flagged records within the 1,103-record snapshot. Units: records. atoms. dimensionless structure/nat ratio.

**Recorded result.** 42 records differ; 41 supplied structures have twice nat, one has three times nat; coordinate and element counts match.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** An inconsistency can reflect representation rather than data corruption; keep the original and test alternatives.

**Limitations and attention.** Do not delete, label corrupt or silently repair these records. Historical exporter cause remains unverified.

**Date and role.** Value: 2026-09-18T01:11:34.580384+00:00. Role: historical analysis execution timestamp as reported by the saved receipt. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0195, RS0203, RS0159.

## R070 — Add a geometric diagnostic without erasing the initial finding

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** A repeated-cell interpretation needed evidence beyond count ratios.

**Method.** Candidate periodic translations must map each site to a distinct same-species site within 0.001 angstrom.

**Dimensions and units.** Population: 42 atom-count-difference records. Units: records. angstrom tolerance.

**Recorded result.** 40 of 42 flagged records support the repeated-cell interpretation under the diagnostic; JVASP-60484 and JVASP-6751 remain unresolved.

**Controls and calibration.** Documented geometric tolerance: 0.001 angstrom. No tolerance-convergence study, reference-standard validation or hardware calibration is established in this companion.

**Lesson and development.** A stronger interpretation can be appended while retaining the original observation and unresolved cases.

**Limitations and attention.** This limited diagnostic is not full crystallographic standardization; failing this tolerance does not prove no smaller representation exists, and it does not establish the historical export cause.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0157, RS0200.

## R071 — Check formulas against atomic composition

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Formula strings and supplied atom lists may describe different compositions.

**Method.** Compare compositions implied by formula strings with species counts from atomic arrays.

**Dimensions and units.** Population: Four flagged formula/structure pairs in the selected snapshot. Units: records.

**Recorded result.** Four flagged records: JVASP-60545, JVASP-27866, JVASP-20042 and JVASP-28027.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Cross-field agreement is a separate check from array shape and finiteness.

**Limitations and attention.** A digit-formatting explanation remains plausible but unverified; retain source values and investigate exporter/raw-calculation evidence before correction.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0176, RS0187.

## R072 — A finite tensor is not automatically physically reliable

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Elastic tensors contain nonfinite and extreme values.

**Method.** Inspect tensor shapes/components and identify the affected record IDs.

**Dimensions and units.** Population: 229 available tensors in the selected 1,103-record snapshot. Units: tensors. nonfinite components. raw component value with physical units unresolved here.

**Recorded result.** 229 tensors are present; four tensors contain 20 nonfinite components in total. JVASP-28262 has an extreme finite component reported near 2.10 × 10^17.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Check finiteness, magnitude, units and slab normalization separately before drawing physical conclusions.

**Limitations and attention.** Review raw output, exporter conventions, component units and slab scaling; do not claim universal mechanical stability.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0174, RS0190.

## R073 — Do not infer stability from a constant field or one sign

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Stored energy and vibration fields can invite overbroad stability claims.

**Method.** Inspect stored ehull values, formation-energy signs and available mode lists as separate observables.

**Dimensions and units.** Population: 1,103 ehull/formation-energy rows and the separate 187-row available vibration subset. Units: records. mode lists. sign counts.

**Recorded result.** All 1,103 stored ehull values are zero; formation energy: 952 negative and 151 positive; 187 vibration mode lists each include a negative entry.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Constant values supply no ranking, and different physical observables answer different questions.

**Limitations and attention.** Formation energy alone does not establish phase stability; negative mode entries alone do not certify instability. Calculation settings and finite-cell/export handling remain relevant.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0173, RS0191.

## R074 — Compare methods on matched records

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Different subsets can create misleading method comparisons.

**Method.** Compare mBJ and OptB88 gaps on the same available rows.

**Dimensions and units.** Population: 1,103 OptB88 values; a separate 246-record matched-method subset. Units: records. matched-record direction counts.

**Recorded result.** OptB88 gaps: 397 zero and 706 positive. On 246 matched rows, mBJ is higher for 160, equal for 44 and lower for 42.

**Controls and calibration.** Descriptive matched-method comparison only; no experimental calibration or proficiency score established.

**Lesson and development.** A matched comparison controls the sample composition; higher predicted values do not establish greater accuracy.

**Limitations and attention.** Experimental reference values, convergence and a specified error metric are not established by this companion; do not label either method more accurate from these signs.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0192, RS0177.

## R075 — Validate descriptor dimensions and informative columns

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Numeric input arrays may contain finite but uninformative features.

**Method.** Check descriptor length, component finiteness and constant columns.

**Dimensions and units.** Population: 1,103 descriptor vectors in the selected snapshot. Units: components per vector. values. columns.

**Recorded result.** 1,557 components per vector; 1,717,371 values inspected and finite; 77 constant-zero columns and 1,480 variable columns.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Finiteness is a structural condition; it does not establish predictive value or physical validity.

**Limitations and attention.** Do not present this as trained-model accuracy. Any later feature selection needs to retain its source mapping and training/evaluation boundary.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0172.

## R076 — Keep duplicate inputs together during evaluation

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Exact descriptor duplicates could leak information between train and test sets.

**Method.** Group exact duplicate descriptor vectors and inspect the selected target agreement.

**Dimensions and units.** Population: 34 duplicate pairs among the source descriptor vectors, not 34 independent discoveries or model tests. Units: duplicate pairs.

**Recorded result.** 34 exact descriptor pairs, also equal in OptB88 gap and formation energy; missing targets were not imputed.

**Controls and calibration.** Leakage-risk diagnostic; no held-out prediction metric or calibration run is recorded here.

**Lesson and development.** Future splits should group duplicates so repeated inputs do not inflate apparent generalization.

**Limitations and attention.** This is a preserved evaluation-design lesson, not an already executed split, training run or accuracy correction.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0170, RS0189.

## R077 — Bind descriptor interpretation to its generation revision

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Current column names may not prove how older vectors were generated.

**Method.** Flag extreme entries and cross-check current mapped density against top-level density.

**Dimensions and units.** Population: Nine flagged entries and 1,007 flagged record comparisons within the snapshot. Units: entries. record comparisons. raw threshold 0.001; physical convention requires confirmation.

**Recorded result.** Nine extremely negative entries at the current packing-fraction position; 1,007 density differences above 0.001 under the current mapping.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** A column mapping and historical generator provenance are separate evidence requirements.

**Limitations and attention.** Historical descriptor-generation revision is unverified; do not assert a confirmed exporter bug or alter the original vectors from the current mapping alone.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0171, RS0188.

## R078 — Keep transport scaling attached to the quantity

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Raw thermal-transport exports can be mistaken for conductivity with interchangeable units.

**Method.** Interpret quantities using their source exporter conventions and periodic-slab context.

**Dimensions and units.** Population: Raw nkappa/pkappa and conductivity-related fields in the acquired snapshot. Units: units/scaling unresolved for physical reinterpretation.

**Recorded result.** The saved study explicitly separates raw thermal-transport export scaling from conductivity scaling; no device figure of merit is established.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** A correct arithmetic operation can still be scientifically wrong if applied to quantities with incompatible units or normalizations.

**Limitations and attention.** Resolve raw-output/exporter scaling, vacuum treatment and physical conventions before assigning conductivity units or calculating device performance.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0193, RS0177.

## R079 — Interpret error fields narrowly

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** A domain-specific comparison field could be mislabeled a general dataset error rate.

**Method.** Keep maxdiff_mesh and maxdiff_bz tied to their documented Wannier-versus-DFT comparison role.

**Dimensions and units.** Population: 431 populated record rows for the named comparison fields. Units: populated rows.

**Recorded result.** These fields are populated in 431 rows; the study does not report a global accuracy percentage from them.

**Controls and calibration.** Specific model-versus-model comparison availability; no general external calibration established.

**Lesson and development.** Name the reference, observable and population of every error metric.

**Limitations and attention.** Do not generalize a method-specific comparison into dataset accuracy, experimental correlation or overall proficiency.

**Date and role.** Value: 2026-09-18T02:43:17.444616+00:00. Role: recorded preparation timestamp of the historical follow-up; not first conception, publication or a new run. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0194.

## R080 — Deterministic replay checks consistency, not physical truth

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** An analysis should yield the same deterministic outputs from the same input.

**Method.** Two separate Python standard-library processes analyzed the same archive; deterministic output files were compared byte-for-byte, excluding variable metrics.

**Dimensions and units.** Population: Three named deterministic files from the initial two-process replay; follow-up replay statements are separate evidence. Units: files. byte comparison.

**Recorded result.** analysis.json, checks.json and record_index.json matched: 3 of 3. The follow-up also records exact full-field-profile and structure-evidence replay.

**Controls and calibration.** Deterministic reproducibility recorded. No accuracy-to-experiment, hardware calibration or quantum advantage established.

**Lesson and development.** Repeatable output supports computational consistency while leaving source anomalies and scientific calibration open.

**Limitations and attention.** The public companion withholds analysis code/full inputs and is not a self-contained reproduction package. Preserve false catalog/nat check flags alongside successful execution and replay.

**Date and role.** Value: 2026-09-18T01:13:42.423869+00:00. Role: historical deterministic-output comparison verification timestamp. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0169, RS0180.

## R081 — Keep performance measurements within their measurement scope

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** A small analysis timing could be exaggerated into system-wide performance.

**Method.** The saved receipts separately record elapsed time and tracemalloc allocations for read/decompress/parse/analyze/write, with download excluded.

**Dimensions and units.** Population: Two historical Python processes in the recorded Linux execution environment for one selected archive. Units: seconds. Python-tracked allocation bytes. network operations.

**Recorded result.** Analysis 1.6917715249946923 s and replay 2.091641733997676 s; tracked peak allocations 113,852,701 and 113,852,477 bytes. Zero network operations during analysis.

**Controls and calibration.** Instrumentation scope is documented; no system-wide or energy-efficiency calibration is established.

**Lesson and development.** Report timing conditions and memory instruments before comparing efficiency.

**Limitations and attention.** No laptop-wide memory, process RSS, USB speed, scaling benchmark or controlled energy comparison follows from these two measurements; timing variation is not a failed replay.

**Date and role.** Value: 2026-09-18T01:11:34.580384+00:00. Role: historical analysis execution timestamp as reported by the saved receipt. Precision: timestamp with numeric UTC offset. Use the role retained inside each date object.

**Evidence.** historical dataset-inspection evidence; current documentary synthesis. Bounded documentary review; no new numerical execution.

**Research source references.** RS0175.

## R082 — Preserve scientific corrections and derivative identities

**Research area and type.** JARVIS materials data; teaching point.

**Aim.** Link repairs or later interpretation can obscure what originally changed.

**Method.** The saved companion records original/derivative hashes and repairs missing relative links to a pinned repository revision; original findings remain in the historical record.

**Dimensions and units.** Population: Six files listed in MATERIALS_COMPANION_DERIVATIONS.json; not the entire research collection. Units: files. SHA-256 identities.

**Recorded result.** An earlier bounded review checked six companion-file identity entries: three link-repaired derivatives and three unchanged files matched that review's recorded hashes. This does not verify every file in the present edition.

**Controls and calibration.** No physical or quantum-hardware calibration established by these sources; dataset consistency diagnostics only.

**Lesson and development.** Separate documentary maintenance from scientific changes and keep the earlier observation plus dated interpretation.

**Limitations and attention.** The pinned external targets were not refreshed in this local review. Hash matches establish file identity, not scientific correctness, signature or endorsement.

**Date and role.** Value: 2026-10-16. Role: earlier bounded identity review and teaching compilation date; historical findings retain their own dates. Precision: day. Use the role retained inside each date object.

**Evidence.** earlier bounded documentary identity check and link-repair record. Bounded documentary review; no new numerical execution.

**Research source references.** RS0178, RS0201.

## R083 — USB-hosted research software and host computation

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Describe what the portable environment actually supplies and where the calculations run.

**Method.** Retained code describes Node.js host processes, typed-array numerical operations, worker processes, host CPU/memory reporting and portable storage.

**Dimensions and units.** Population: Selected source implementation, not a hardware benchmark population. Units: Embedded in the result; not inferred.

**Recorded result.** Substantive software computation and portable storage/custody paths are supported by retained implementation. A USB device-side QPU or independent processor is not established. .

**Controls and calibration.** Recorded checks: Source identity and implementation review. Not established: USB device-side computation or physical QPU execution. Attention: Keep execution location, storage location and claimed hardware type in separate fields.

**Lesson and development.** A portable application can be useful without moving the computation off the host. Describe the measured mechanism before naming the achievement.

**Limitations and attention.** Qualify the project processor name with software/emulator where used. Do not describe USB storage as a separately measured compute device.

**Date and role.** Value: 2026-10-16. Role: documentary review date. Precision: day. Value: No separate measured result is asserted for this field. Role: original inception date. Precision: not established by this selection. Use the role retained inside each date object.

**Evidence.** implementation description supported by earlier code review. reviewed documentary teaching row.

**Research source references.** RS0160, RS0161, RS0154.

## R084 — Dense state-vector capacity with explicit workload and memory

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Determine the executable state-vector sizes under the laptop load and reserve policy then in effect.

**Method.** Two Float64 arrays store the real and imaginary amplitudes. Retained tests use GHZ H/CX operations and their inverse plus a four-phase full-support input, with serial workers and admission checks.

**Dimensions and units.** Population: 25 trials across the saved size ladder; three samples at 21 qubits. Repeated checks are not independent research studies. Units: Embedded in the result; not inferred.

**Recorded result.** Recorded sizes 1 through 21 completed for the specified workloads. 25 completed passing trials. 9 checks per trial. 225 repeated check evaluations. 2097152 complex amplitudes at 21 qubits. 33554432 state-array bytes at 21 qubits. 766.6211 median full validation milliseconds from three 21-qubit samples.

**Controls and calibration.** Recorded checks: Nine checks per trial and forward/inverse workloads; retain the original reserve policy. Not established: Capacity for arbitrary algorithms or dense operators; physical quantum trials. Attention: Keep workload, state representation, trial count, validation cost and memory accounting together.

**Lesson and development.** Dense state storage grows with 2^n amplitudes; a stated qubit count needs a representation and a circuit. A capacity demonstration is bounded by what actually ran.

**Limitations and attention.** Preserve the 21-qubit result with its explicit workload and trial population. Do not label 225 check evaluations as 225 studies.

**Date and role.** Value: 2026-09-18. Role: historical scaling work date. Precision: day; exact trial timestamps not transcribed here. Use the role retained inside each date object.

**Evidence.** historical saved execution result. implementation and review-linked. reviewed documentary teaching row.

**Research source references.** RS0166, RS0155.

## R085 — Memory admission refusal versus numerical failure

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Protect the required free-memory reserve before attempting a larger dense state.

**Method.** Compare available memory with the state-plus-reserve requirement before starting the next trial.

**Dimensions and units.** Population: One saved admission boundary; no executed 22-qubit trial in this record. Units: Embedded in the result; not inferred.

**Recorded result.** The 22-qubit trial was not admitted; it did not produce a failed numerical result. 322658304 observed free bytes. 335544320 required free bytes. 268435456 unchanged memory-reserve bytes.

**Controls and calibration.** Recorded checks: A fixed reserve was enforced before allocation/trial. Not established: A permanent hardware maximum or correctness failure at 22 qubits. Attention: Track not-started separately from started, completed, accepted and target-met.

**Lesson and development.** A guard can correctly stop a run. Teaching the stop condition prevents a safety/resource decision from becoming a false scientific failure.

**Limitations and attention.** Use not admitted, not failed, for this trial. Do not replace observed-load limits with general hardware limits.

**Date and role.** Value: 2026-09-18. Role: historical scaling admission decision. Precision: day. Use the role retained inside each date object.

**Evidence.** historical admission decision. reviewed documentary teaching row.

**Research source references.** RS0167.

## R086 — Structured states and the meaning of a large qubit index

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Represent selected large-index product and GHZ states without allocating every dense amplitude.

**Method.** SOP stores a sum of product branches; MPS contracts bounded tensors and uses reorthogonalized QR. The bridge checks selected amplitudes and normalization.

**Dimensions and units.** Population: A selected implementation and three-amplitude bridge check, not exhaustive dense state verification. Units: Embedded in the result; not inferred.

**Recorded result.** Selected structured product/GHZ implementation supports a 60 indexed-qubit limit with explicit representation caps; historical benchmark linkage remains limited. 60 indexed-qubit limit. 64 SOP branch cap. 32 bridge MPS bond cap. 1e-13 local QR residual omission threshold. 3 selected basis-amplitude witnesses.

**Controls and calibration.** Recorded checks: SOP refuses branch overflow; MPS records local omitted residual diagnostics; bridge uses three amplitudes plus normalization. Not established: A certified global state-error bound or arbitrary dense 60-qubit capacity. Attention: Separate algebraic representation, floating-point error, local omission threshold and global state accuracy.

**Lesson and development.** Compression works by using structure. A local numerical threshold does not automatically provide a global error guarantee.

**Limitations and attention.** Retain dense and structured capacities as separate achievements. Do not infer original implementation date from the later copy folder. Attach exact historical benchmark evidence before publishing an additional performance assertion.

**Date and role.** Value: No separate measured result is asserted for this field. Role: original structured implementation date. Precision: not established by this selected later source snapshot. Value: 2026-10-16. Role: documentary review date. Precision: day. Use the role retained inside each date object.

**Evidence.** implementation supported. historical benchmark linkage limited. reviewed documentary teaching row.

**Research source references.** RS0168, RS0156.

## R087 — Conventional byte prediction and bounded register machine

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Explain additional prototype capabilities without overstating their scope.

**Method.** One-byte-context softmax/SGD prediction and a bounded arithmetic/memory/branch register-machine implementation in the host process.

**Dimensions and units.** Population: Implementation parameters, not a measured general intelligence or OS-isolation study. Units: Embedded in the result; not inferred.

**Recorded result.** The selected Q8 source contains these concrete conventional software components. 256 byte vocabulary. 65536 bigram weights. 16 maximum VM registers. 4096 maximum VM memory words. 100000 maximum VM steps.

**Controls and calibration.** Recorded checks: Bounded implementation described in previous code review. Not established: General language-model capability, a new OS or a native-process security sandbox. Attention: Use component-level acceptance criteria and avoid upgrading a model name into a capability claim.

**Lesson and development.** Small interpretable models are teaching tools. Their explicit limits make the implementation easier to test and explain.

**Limitations and attention.** Describe the byte predictor as a one-byte-context model. Keep VM limits separate from operating-system guarantees.

**Date and role.** Value: No separate measured result is asserted for this field. Role: original implementation date. Precision: not established in selected register. Value: 2026-10-16. Role: documentary review date. Precision: day. Use the role retained inside each date object.

**Evidence.** implementation description. reviewed documentary teaching row.

**Research source references.** RS0163.

## R088 — Historical Windows resource observations and correlation

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Understand the host conditions surrounding the work and keep observed changes distinct from causal conclusions.

**Method.** Three saved windows sample eleven counter identities thirty times each at a scheduled one-second interval. Background workloads changed. All sampling ended before the associated USB checks.

**Dimensions and units.** Population: 990 saved readings = 3 windows × 11 counters × 30 samples. These are repeated counter readings, not 990 independent experiments. Units: Embedded in the result; not inferred.

**Recorded result.** Later windows show lower sampled CPU pressure and higher available-memory counter means; other indicators do not improve monotonically. 40.954661803379665. 16.632889047421816. 12.057595117859382. mean percent processor time in before/after/post-install order. 301.96666666666664. 339.6. 421.46666666666664. mean values of the Windows available mbytes counter, same window order. 926.5994757837885. 0.5207366614199194. 370.687491257829. mean pages output per second. 0.0005620876636694995. 0.0006296199070738684. 0.0007796027563135101. unweighted mean sampled disk seconds/read.

**Controls and calibration.** Recorded checks: Source derivative retains values, status codes and exact timestamps; all selected values finite with status zero. Not established: Controlled Windows-wide acceleration, USB causal effect, electrical energy, battery, thermal or unrelated-program responsiveness gain. Attention: Keep the original counter name/unit and window timing. Disk-latency samples are unweighted and include idle intervals. A future causal claim would need a separately designed controlled comparison; none was performed here.

**Lesson and development.** A real observation is worth preserving even when it cannot establish causation. Report favorable and unfavorable indicators together and identify changing background conditions.

**Limitations and attention.** Do not claim these counters measured the later USB verification workload. Preserve counter-reported Mbytes terminology; the older README labels it MiB, while the technical review uses the exact counter unit. Do not promote lower observed pressure into general Windows or energy improvement.

**Date and role.** Value: 2026-09-29T03:24:21.3923759Z. End: 2026-09-29T03:24:51.0207323Z. Role: historical counter sampling: before. Precision: exact source timestamp strings. Value: 2026-09-29T03:28:03.4200452Z. End: 2026-09-29T03:28:32.8982117Z. Role: historical counter sampling: after. Precision: exact source timestamp strings. Value: 2026-09-29T04:27:01.0738435Z. End: 2026-09-29T04:27:30.4675116Z. Role: historical counter sampling: post-install-20260929. Precision: exact source timestamp strings. Use the role retained inside each date object.

**Evidence.** historical observation. association under changing background conditions. reviewed documentary teaching row.

**Research source references.** RS0161, RS0164, RS0152, RS0181.

## R089 — Reproducing arithmetic from retained observations

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Make the saved resource data independently checkable without treating a replay as a new experiment.

**Method.** A standard-library Python replay sums thirty saved values for each counter/window, divides by thirty and compares with its saved mean using absolute and relative tolerances of 1e-12.

**Dimensions and units.** Population: The same 990 readings as R088; do not add this row to the observation population. Units: Embedded in the result; not inferred.

**Recorded result.** The saved preparation receipt records all selected means reproduced and the source comparison passed. 990 saved readings compared. 33 saved means reproduced. 0 new observations in that replay.

**Controls and calibration.** Recorded checks: All values, statuses and exact timestamps compared to originals; independent temporary replay produced the same output bytes, as reported in the retained review. Not established: Independent repetition of the historical workload. Attention: State whether a result is a new measurement, recomputation, cached retrieval or code fixture.

**Lesson and development.** Reproducible arithmetic and experimental replication answer different questions. Both have value when labeled precisely.

**Limitations and attention.** Keep new_observations equal to zero for documentary replay. Reuse the saved validated replay state unless input bytes or method change; no need to rerun it to compile this matrix.

**Date and role.** Value: 2026-09-29. Role: UTC date of original observations. Precision: day; exact windows in R088. Value: 2026-10-16. Role: earlier documentary replay/review date. Precision: day. Use the role retained inside each date object.

**Evidence.** saved documentary replay receipt. derived arithmetic on historical data. reviewed documentary teaching row.

**Research source references.** RS0186, RS0185, RS0205.

## R090 — Unsigned manifest consistency and variable check durations

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Verify the declared installed package without confusing byte consistency with authenticated provenance or performance.

**Method.** Each saved operation checks the same declared forty-file package against an unsigned manifest after the counter sampling ends.

**Dimensions and units.** Population: Three operations over the same declared forty-file set; not 120 distinct files or the full USB. Units: Embedded in the result; not inferred.

**Recorded result.** All three saved operations reported the declared package check succeeded. 40 declared package files in each check. 3 saved check operations. 12.5676291. 1.620652. 9.3315077. elapsed verification seconds by recorded operation. No separate measured result is asserted for this field. signature field in each receipt.

**Controls and calibration.** Recorded checks: Fingerprint comparison within the declared manifest scope. Not established: Authenticated release, ownership, malicious replacement protection, or controlled speed improvement. Attention: Retain signature=null and the stated fingerprint scope. Different cache/background conditions make check durations unsuitable as a causal speedup comparison.

**Lesson and development.** A hash verifies agreement with specified bytes. It does not by itself authenticate who produced them or why a later check was faster.

**Limitations and attention.** Keep the package population explicit. Do not treat variable verification times as a fresh research calculation benchmark.

**Date and role.** Value: 2026-09-29T03:24:56.7680401Z. Role: historical package check: before. Precision: exact saved timestamp. Value: 2026-09-29T03:28:38.0299580Z. Role: historical package check: after. Precision: exact saved timestamp. Value: 2026-09-29T04:27:35.7322933Z. Role: historical package check: post-install-20260929. Precision: exact saved timestamp. Use the role retained inside each date object.

**Evidence.** historical package consistency receipt. reviewed documentary teaching row.

**Research source references.** RS0165.

## R091 — Partial installation, later readback and preserved mistakes

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Reconcile a genuine incomplete intermediate state with the later recorded completed installation.

**Method.** Order the saved copy, installation and readback receipts by their own timestamps and distinguish writes from later verification.

**Dimensions and units.** Population: Three declared packages; not the complete USB or a current file inventory. Units: Embedded in the result; not inferred.

**Recorded result.** The earlier repair-copy check recorded 43 of 47; the later readback reported all 78 selected payload rows matched across three packages. 43 earlier matching repair files out of 47. 47 later repair files. 16 performance-package files. 15 adaptive-package files. 78 later matched selected payload rows.

**Controls and calibration.** Recorded checks: Saved receipt reports present/matched rows; later local custody checks do not supply retroactive per-row historical digests. Not established: Current USB contents or a calculation from the newly installed performance package. Attention: The performance receipt explicitly defers calculation and installed-runtime testing.

**Lesson and development.** An earlier incomplete report may be correct at its time. Correct the current summary without deleting that intermediate evidence.

**Limitations and attention.** Preserve the 43/47 checkpoint and supersede only its use as current status. Do not interpret readback usbWritesPerformed=false as denying preceding installation writes. Do not upgrade installed bytes to an executed scientific benchmark.

**Date and role.** Value: 2026-09-29T04:02:43.211Z. Role: earlier partial repair-copy observation. Precision: exact saved timestamp. Value: 2026-09-29T04:23:04.767Z. Role: performance-package installation receipt. Precision: exact saved timestamp. Value: 2026-09-29T04:30:48.386Z. Role: later selected-package readback receipt. Precision: exact saved timestamp. Use the role retained inside each date object.

**Evidence.** historical partial observation. historical installation/readback receipt. reviewed documentary teaching row.

**Research source references.** RS0208, RS0196, RS0162.

## R092 — Bounded operation from the installed USB environment

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Establish what an actual recorded interaction with the installed environment did.

**Method.** The saved receipt names a USB executable and working directory, performs declared file checks, local library retrieval and means from existing readings.

**Dimensions and units.** Population: One saved installed-runtime interaction; its 14 checked package files differ from the 15 adaptive files in the installation receipt. Units: Embedded in the result; not inferred.

**Recorded result.** The bounded operation recorded verification, retrieval and arithmetic; it did not start a language model or collect new observations. 14 package files checked. 10 source files checked. 4 persistent library records loaded. 3 retrieval results. 660 previously saved readings. 22 derived means.

**Controls and calibration.** Recorded checks: Receipt binds executable/working-folder context and individual action flags. Not established: Current live service readiness or a new model/numerical experiment. Attention: Keep model launch, service/network activity, writes, retrieval and calculation as separate flags.

**Lesson and development.** A real runtime success can be narrow. Credit exactly what ran without requiring unrelated tasks to have succeeded, and without promoting it to complete readiness.

**Limitations and attention.** Do not label the 660 readings as new samples. Use start/end fields rather than a filename time. Do not merge differently scoped file counts.

**Date and role.** Value: 2026-09-29T04:33:44.399Z. End: 2026-09-29T04:33:45.301Z. Role: historical installed-runtime interaction. Precision: exact saved start/end fields. Use the role retained inside each date object.

**Evidence.** historical bounded execution receipt. derived arithmetic on previously saved observations. reviewed documentary teaching row.

**Research source references.** RS0207, RS0197.

## R093 — GAUCIA repair installation versus live service readiness

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Avoid erasing a successful installation because older not-installed prose remains, while retaining the separate live-readiness gap.

**Method.** Use the later owner-run receipt and matched package manifest as the installation evidence; keep earlier fixture tests and historical UI visibility separate.

**Dimensions and units.** Population: One owner-run installation and its manifest/readback evidence; entries are not all files. Units: Embedded in the result; not inferred.

**Recorded result.** R3 installed bytes are recorded; the installer did not launch or verify the live service. 8 installed repair target files. 45 listed package files verified. 944 preserved non-target entries, including directory and hold markers.

**Controls and calibration.** Recorded checks: Target bytes, manifest and preservation counts; local fixtures are a separate population. Not established: Current live model/service readiness or complete USB mirroring. Attention: Report installed, launched and ready as independent outcomes; preserve older states at their original timestamps.

**Lesson and development.** State must be chronological and stage-specific. A successful installation is meaningful even while a later usable-service check remains open.

**Limitations and attention.** Do not reinstall merely because stale prose says pending. Do not call 944 preserved entries 944 files.

**Date and role.** Value: 2026-10-16T01:00:15.847Z. End: 2026-10-16T01:00:47.21Z. Role: owner-run installation receipt. Precision: exact saved UTC fields; completed October 15 9:00:47.210 p.m. EDT. Use the role retained inside each date object.

**Evidence.** historical owner-run installation receipt. separate local fixture evidence. reviewed documentary teaching row.

**Research source references.** RS0206, RS0198.

## R094 — Reproducible teaching package and remaining source work

**Research area and type.** Q8 and USB; teaching point.

**Aim.** Give a reader enough information to inspect and reproduce the selected work without inventing new research or silently rewriting historical programs.

**Method.** Bind claims to source identities, distinguish raw receipts from derivatives, preserve negative results and document runtime/dependency/workload/acceptance requirements.

**Dimensions and units.** Population: Documentary coverage of the bounded Q8 supplement; source references and copied reports are not additional studies. Units: Embedded in the result; not inferred.

**Recorded result.** The selected review binds sixteen claim decisions to forty source identities and contains a self-contained replay of saved counter means. This is not the executable dependency tree for every experiment. 16 technical claim decisions in the retained review. 40 selected source identities in that review. 33 means reproducible by the selected arithmetic companion.

**Controls and calibration.** Recorded checks: Selected archive identities and saved replay checks were verified in the previous review. Not established: Complete per-experiment portable dependency environments, all-history semantic coverage or independent scientific replication. Attention: This edition supplies an identified adapter for selected saved-state and scoring checks. It does not reproduce every historical experiment; original sources and baselines remain intact.

**Lesson and development.** Teach the question, representation, method, checks, unfavorable results and limits together. Reuse a saved review state keyed to source hashes, and revisit only changed inputs or unresolved questions.

**Limitations and attention.** Portable assembly is supplied for the explicitly selected replay components; broader per-experiment integration remains separate. Keep unresolved original benchmark/dependency links explicit.

**Date and role.** Value: 2026-10-16. Role: saved documentary review and teaching compilation date. Precision: day. Use the role retained inside each date object.

**Evidence.** documentary reproduction scope. source-identity register. reviewed documentary teaching row.

**Research source references.** RS0202, RS0153, RS0151.
