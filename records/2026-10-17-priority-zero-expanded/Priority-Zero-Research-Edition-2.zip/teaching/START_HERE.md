# Priority Zero — research teaching edition

This collection explains the aims, methods, dimensions, results, corrections and limits of existing research.

- [Read the complete teaching account](RESEARCH_RECORDS.md).
- [Use the structured research records](RESEARCH_RECORDS.json).
- [Review contribution and source credit](CREDITS.md).

The edition contains **94 overlapping records**: **64 simulation and mathematics**, **18 JARVIS materials-data** and **12 Q8/USB**. The simulation group includes eight work summaries, 36 learning-history cases and 20 mathematical mechanism notes. These counts describe documentary records, not distinct discoveries or new experiments.

The Q8/USB account distinguishes host computation from portable storage, dense from structured state representations, admission stops from numerical failures, and saved installation evidence from live service readiness. The numerical records preserve unsuccessful attempts, stronger conventional controls and successful corrections with their original limitations. The materials review retains unresolved catalog, structural, descriptor and physical-interpretation questions.

This is a research review edition prepared on October 16, 2026. Publication remains pending the final selection decision. No scientific program was rerun or changed to prepare it. The records explain the available evidence; they are not a complete executable reproduction package for every study.

Research direction: Sherman Gaucia Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. AI-assisted documentary preparation: Codex and delegated reviewers.
