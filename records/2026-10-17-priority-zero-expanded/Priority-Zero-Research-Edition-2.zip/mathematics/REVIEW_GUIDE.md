# Where to find the proof-review records

The two current manuscripts in this folder retain the exact bytes assessed by their cross-reviewers. Their original review notes refer to companion filenames such as ERRATA, CLAIM_PROOF_COVERAGE and EXTERNAL_DEPENDENCIES. In this assembled edition those companions are organized by chapter:

- [Complex-analysis review and source preservation](../review/proof-complex/REVIEW_REPORT.md)
- [Advanced-mathematics review and source preservation](../review/proof-advanced/REVIEW_STATUS.md)
- [Bridge proof appendix](../review/proof-bridges/PROOF_APPENDIX.md)
- [Revision-wide scientific correction record](../SCIENTIFIC_REVIEW.md)

The `preservation` subfolders contain earlier versions with their original statements, dates and relative references. Their historical wording is evidence, not the current completion status. The unchanged license and scope are supplied here so the current manuscript's license links resolve.
