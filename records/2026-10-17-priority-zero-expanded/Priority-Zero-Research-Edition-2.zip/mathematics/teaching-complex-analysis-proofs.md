Revised research-review derivative, October 16, 2026. The retained teaching manuscript is dated September 20, 2026. Every section, displayed argument, worked example and exercise solution in the 733-line selected source was examined in the present mathematical review. The accompanying coverage matrix records the result for each logical unit. This edition supplies previously implicit prerequisite arguments and clarifies boundary hypotheses; it does not claim new theorems, formal proof-assistant verification or independent mathematical certification.

# Complex Analysis: Complete Proofs from Contour Integration to Polynomial Roots

Established mathematics proof continuation, 20 September 2026. Prepared by GAUCIA Actual for the Quantum.Earth.Laing educational collection. Mathematical exposition and examples in this document are assistant-authored reconstructions of established results; they are not attributed to the reader as discoveries.

This continuation supplies the arguments deferred in Volume 3, section 9: Cauchy's integral theorem for closed piecewise continuously differentiable curves in a simply connected domain, Cauchy's integral formula on a disk, the derivative formulas, and the passage from complex differentiability to convergent power series. It then proves removable singularity results, the identity theorem, Liouville's theorem, the fundamental theorem of algebra, and a precisely delimited residue theorem. Each conclusion is derived from stated hypotheses. Nothing here asserts that a finite selection of theorems exhausts complex analysis.

The starting point is complex arithmetic, real integration and elementary compactness in the plane. Appendix A explicitly lists the real-analysis prerequisites and supplies the calculus, exponential and power-series arguments otherwise referred to the unavailable Volume 3. In particular, we do **not** begin by assuming that a holomorphic function has continuous derivatives of all orders, or that it already equals its Taylor series. Those conclusions will be proved. This order matters: assuming either conclusion at the beginning would conceal part of the question the study is supposed to answer.

## 1. The objects being integrated

### 1.1 Domains, paths, and the meaning of a derivative

A **domain** is a nonempty connected open subset of the complex plane. All disk and circle radii in this chapter are strictly positive unless a zero-radius limiting case is explicitly stated. Write

$$D(a,r)=\{z\in\mathbb C:|z-a|<r\}.$$

A function $f:U\to\mathbb C$ is **holomorphic** on an open set $U$ if, at each $a\in U$, the limit

$$f'(a)=\lim_{h\to0}\frac{f(a+h)-f(a)}h$$

exists for arbitrary complex increments. The openness ensures that sufficiently small increments remain in the domain. Existence of this limit implies continuity at $a$: write the increment as $h$ times a difference quotient that stays bounded near zero. It also gives the local expansion

$$f(a+h)=f(a)+f'(a)h+h\eta(h),\qquad \eta(h)\to0.$$

This is a first-order approximation, not yet an infinite series. The remainder estimate is uniform over all directions because the definition quantifies over every sufficiently small complex $h$.

There is a useful warning about reducing this definition to separate coordinate tests. Define $f(0)=0$ and, for $z=x+iy\ne0$, set

$$f(x+iy)=\frac{xy}{x^2+y^2}(x+iy).$$

Because $2|xy|\leq x^2+y^2$, we have $|f(z)|\leq|z|/2$, so the function is continuous at zero. Its values on both coordinate axes are zero. Consequently the four partial derivatives of its real and imaginary components at zero are all zero, and the Cauchy–Riemann equations hold there. Nevertheless,

$$\frac{f(z)-f(0)}{z}=\frac{xy}{x^2+y^2}$$

equals zero along the real axis and $1/2$ along $y=x\ne0$. The complex derivative does not exist. The Cauchy–Riemann equations at one point, even together with continuity there, do not replace the full complex limit. A sufficient theorem using continuous partial derivatives on a neighborhood has additional hypotheses that this example does not supply. Appendix A.2 proves that theorem. Here, for the real component u(x,y)=x²y/(x²+y²), one has u_x(t,t)=1/2 for t≠0 but u_x(0,0)=0, so the relevant partial derivative is not continuous at zero.

Similarly, $f(z)=|z|^2$ is complex differentiable at zero, since $|z|^2/z=\overline z\to0$. At a nonzero point $a$, its increment quotient contains $a\overline h/h+\overline a+\overline h$, so real and imaginary increments give different limits. It is therefore not holomorphic on any neighborhood of zero. Having a derivative at one point cannot justify using Cauchy's formula on a disk around that point. These examples separate three claims: coordinate identities at a point, complex differentiability at a point, and holomorphy on an open set.

A path will normally be a continuous map $\gamma:[\alpha,\beta]\to U$ with a finite partition on whose subintervals it is continuously differentiable, with one-sided derivatives allowed at the partition points. We call this **piecewise $C^1$**. Its length is

$$L(\gamma)=\sum_j\int_{t_{j-1}}^{t_j}|\gamma'(t)|\,dt.$$

The path can stop, retrace an edge, or cross itself. We do not require its derivative to be nonzero. It is closed if its two endpoints agree. A contour integral is defined by

$$\int_\gamma f(z)\,dz
=\sum_j\int_{t_{j-1}}^{t_j}f(\gamma(t))\gamma'(t)\,dt,$$

where $f$ is continuous on the path. Complex integration here means integrating the real and imaginary parts. The finite partition makes the integrands ordinary continuous functions on individual pieces.

Reversing a parametrization changes the integral's sign, by real substitution. Joining paths adds their integrals. A constant path contributes zero. Reparametrizing by an increasing piecewise smooth change of parameter preserves the integral whenever real substitution applies. In this chapter these facts follow from the definition; they are not additional contour theorems.

### 1.2 The integral triangle inequality and the ML bound

For any integrable complex function $v$ on a real interval,

$$\left|\int v(t)\,dt\right|\leq\int|v(t)|\,dt.$$

To see this without treating a complex number as an ordered quantity, set $I=\int v$. If $I=0$, the assertion holds. Otherwise choose a complex number $\lambda$ of modulus one with $\lambda I=|I|$. Then

$$|I|=\operatorname{Re}(\lambda I)
=\int\operatorname{Re}(\lambda v(t))\,dt
\leq\int|v(t)|\,dt.$$

Apply this inequality to $v(t)=f(\gamma(t))\gamma'(t)$ and sum the pieces. If $|f|\leq M$ on the path, we obtain the **ML bound**

$$\boxed{\left|\int_\gamma f(z)\,dz\right|\leq M L(\gamma).}$$

The bound connects a local size estimate to a global integral. It also explains which convergence is enough for exchanging a limit and a contour integral. If the functions $f_n$ are continuous on the image of a fixed finite-length path and converge uniformly there to $f$, then the limit is continuous there and

$$\left|\int_\gamma f_n-\int_\gamma f\right|
\leq L(\gamma)\sup_{z\in\gamma}|f_n(z)-f(z)|\longrightarrow0.$$

Pointwise convergence alone does not give this estimate. Every later interchange of a contour integral and an infinite sum will include a uniform bound.

### Worked example 1 — a useful bound that does not calculate the integral

On the counterclockwise circle $|z|=3$, consider $f(z)=e^z/(z-1)^2$. The path has length $6\pi$. Since $|e^z|=e^{\operatorname{Re}z}\leq e^3$ and $|z-1|\geq||z|-1|=2$,

$$\left|\oint_{|z|=3}\frac{e^z}{(z-1)^2}\,dz\right|
\leq\frac{e^3}{4}\,6\pi=\frac{3\pi e^3}{2}.$$

The singularity at $1$ does not obstruct this estimate because it is not on the path. The estimate uses only the integrand's values along the path. Later the exact answer will be $2\pi i e$, whose modulus satisfies this upper bound. An upper bound and an exact value are different mathematical statements.

### 1.3 Primitives and the fundamental theorem for paths

A **primitive** of a continuous function $f$ on $U$ is a holomorphic function $F$ with $F'=f$. The first-order expansion for $F$, applied along a differentiable path, proves

$$\frac{d}{dt}F(\gamma(t))=F'(\gamma(t))\gamma'(t).$$

Because $f$ and the derivative of each path piece are continuous, the right side is continuous on that piece. Real FTC therefore gives

$$\boxed{\int_\gamma f(z)\,dz=F(\gamma(\beta))-F(\gamma(\alpha)).}$$

The endpoint terms telescope across the finitely many pieces. Thus a function with a primitive integrates to zero around every closed piecewise $C^1$ path in its domain. We have not claimed that every holomorphic function on every domain has a primitive. The counterexample $1/z$ on the punctured plane will show why that stronger statement is false.

## 2. Goursat's triangle theorem without continuity of the derivative

### 2.1 Statement and subdivision identity

**Triangle theorem.** Let $T$ be a filled triangle, and suppose $f$ is holomorphic on an open set containing $T$. Orient the three edges of its boundary consistently. Then

$$\int_{\partial T}f(z)\,dz=0.$$

For a degenerate triangle, the oriented collinear segments cancel directly. Assume the triangle is nondegenerate. Join its side midpoints to obtain four smaller triangles. Orient each boundary counterclockwise. Every new internal segment occurs twice: once in each direction. The contributions of those two traversals are negatives of one another by the reversal rule. Each segment of the original boundary occurs exactly once with the original orientation. Consequently

$$I(T):=\int_{\partial T}f=\sum_{j=1}^4 I(T_j).$$

The triangle inequality gives $|I(T)|\leq\sum_j|I(T_j)|$. At least one child therefore satisfies $|I(T_j)|\geq|I(T)|/4$. Choose such a child and repeat. This constructs closed nested triangles

$$T=T_0\supseteq T_1\supseteq T_2\supseteq\cdots$$

with

$$|I(T_n)|\geq4^{-n}|I(T)|,\qquad
\operatorname{diam}(T_n)=2^{-n}d,\qquad
L(\partial T_n)=2^{-n}P,$$

where $d$ and $P$ are the original diameter and perimeter. Midpoint subdivision halves every side, so these geometric scaling statements are exact.

### 2.2 Why the nested triangles select one point

Choose $z_n\in T_n$. If $m\geq n$, both points are in $T_n$, so $|z_m-z_n|\leq2^{-n}d$. Thus $(z_n)$ is Cauchy. Completeness of the plane, obtained from completeness of its real and imaginary coordinates, supplies a limit $z_*$. Each $T_n$ is closed and contains all later $z_m$, so it contains $z_*$. No second point can belong to every $T_n$, since the distance between two such points would be at most $2^{-n}d$ for every $n$.

Holomorphy at this one selected point gives

$$f(z)=f(z_*)+f'(z_*)(z-z_*)+r(z),$$

where, for every $\varepsilon>0$, sufficiently small $|z-z_*|$ ensures

$$|r(z)|\leq\varepsilon|z-z_*|.$$

Define $r(z_*)=0$. Constants and the linear function $z-z_*$ have polynomial primitives. Their integrals around every $\partial T_n$ are zero. For sufficiently large $n$, the ML estimate therefore yields

$$|I(T_n)|=\left|\int_{\partial T_n}r(z)\,dz\right|
\leq\varepsilon(2^{-n}d)(2^{-n}P)
=\varepsilon4^{-n}dP.$$

Combine this with the lower bound from the subdivision:

$$4^{-n}|I(T)|\leq\varepsilon4^{-n}dP.$$

Cancel the positive factor $4^{-n}$. Then $|I(T)|\leq\varepsilon dP$ for every positive $\varepsilon$, forcing $I(T)=0$.

This proves the theorem. We used continuity of $f$ to define integrals, complex differentiability at the limit point to obtain a remainder estimate, compactness and completeness to select that point, and explicit cancellation of internal edges. We did not use continuity of $f'$, second derivatives, Green's theorem, or Taylor's theorem.

### Worked example 2 — following the constants in the proof

Suppose a triangle has diameter $d=5$ and perimeter $P=12$. At a stage where the derivative remainder satisfies $|r(z)|\leq0.001|z-z_*|$, the selected triangle obeys

$$|I(T_n)|\leq0.06\,4^{-n}.$$

The selection inequality gives $|I(T)|\leq4^n|I(T_n)|\leq0.06$. This numerical bound alone does not prove zero. The derivative definition allows $0.001$ to be replaced by every smaller positive tolerance, with a correspondingly later stage. The final conclusion comes from that quantified freedom, not from treating a small value as exactly zero.

### 2.3 A continuous exceptional point

We need one extension before proving Cauchy's formula. Suppose $g$ is continuous on an open set $U$, and holomorphic on $U\setminus\{a\}$. Then the integral of $g$ around every filled triangle contained in $U$ is zero, even if the triangle contains $a$.

If the triangle misses $a$, use the triangle theorem. If it contains $a$, join $a$ to the triangle's vertices. After discarding degenerate pieces this divides the original triangle into at most three triangles with $a$ as a vertex. It suffices to handle one such triangle with vertices $a,b,c$.

For $0<\delta<1$, set $b_\delta=a+\delta(b-a)$ and $c_\delta=a+\delta(c-a)$. The quadrilateral with vertices $b_\delta,b,c,c_\delta$ excludes $a$. Split it by a diagonal into two triangles. Both have zero boundary integral by Goursat. Cancellation on the diagonal shows that the quadrilateral has zero boundary integral. Adding the small triangle $(a,b_\delta,c_\delta)$ to the quadrilateral recovers the large triangle; the shared segment cancels in opposite directions. Hence

$$\int_{\partial(a,b,c)}g
=\int_{\partial(a,b_\delta,c_\delta)}g.$$

Continuity bounds $|g|$ by some $M$ on the original compact triangle. The small triangle has perimeter $\delta P$, so the last integral has modulus at most $M\delta P$. Letting $\delta\to0$ proves the assertion, including the cases where $a$ lies on an edge or a vertex of the original triangle.

This argument has not yet proved that $g$ is holomorphic at $a$. It proves the vanishing triangle integrals that we presently need. Inferring differentiability of $g$ at this point without another argument would skip a step.

## 3. Local primitives, star-shaped sets, and global topology

### 3.1 Constructing a primitive from triangle integrals

An open set $U$ is **star-shaped about $b$** if $b\in U$ and every segment $[b,z]$ for $z\in U$ lies in $U$. Assume $f$ is continuous on $U$ and its integral around every triangle contained in $U$ vanishes. Define

$$F(z)=\int_{[b,z]}f(w)\,dw.$$

Fix $z\in U$. The compact segment $[b,z]$ has a sufficiently thin open neighborhood contained in $U$. Here is the needed compactness argument: otherwise points outside $U$ could approach this segment arbitrarily closely; a convergent subsequence of their nearby points on the segment would give a point of the segment outside the open set. Equivalently, a finite collection of small balls inside $U$ provides a positive uniform clearance.

For sufficiently small $h$, every point of the triangle with vertices $b,z,z+h$ is within distance $|h|$ of $[b,z]$. Indeed, it has the form

$$b+t(z-b)+ts h,\qquad0\leq s,t\leq1.$$

Thus this triangle lies in $U$. Its zero boundary integral gives

$$F(z+h)-F(z)=\int_{[z,z+h]}f(w)\,dw
=h\int_0^1f(z+th)\,dt.$$

Divide by $h\ne0$ and subtract $f(z)$. The modulus of the difference is at most $\sup_{0\leq t\leq1}|f(z+th)-f(z)|$, which tends to zero by continuity at $z$. Therefore $F'(z)=f(z)$.

Every disk is star-shaped about its center. Goursat now proves that every holomorphic function has a primitive on every sufficiently small disk in its domain. The same construction applies to the continuous exceptional-point function of section 2.3. These are local conclusions; a global primitive requires compatible behavior when paths go around the domain.

### 3.2 Continuous homotopies require no differentiability

Let $\gamma_0,\gamma_1:[0,1]\to U$ be closed piecewise $C^1$ paths. A homotopy through closed loops is a continuous map

$$H:[0,1]\times[0,1]\to U$$

such that $H(t,0)=\gamma_0(t)$, $H(t,1)=\gamma_1(t)$, and $H(0,s)=H(1,s)$ for every $s$. The intermediate loops need only be continuous. We will never attempt to integrate their derivatives, which might not exist.

**Homotopy invariance.** If $f$ is holomorphic on $U$ and these conditions hold, then

$$\int_{\gamma_0}f=\int_{\gamma_1}f.$$

The image $K=H([0,1]^2)$ is compact and lies in $U$. There exists $r>0$ such that $D(x,r)\subseteq U$ for every $x\in K$. For example, if $U\ne\mathbb C$, the distance from compact $K$ to the closed complement of $U$ is positive; choose a smaller $r$. If $U=\mathbb C$, any positive $r$ works. The positive-distance assertion follows by the same compactness argument used for the radial segment.

Uniform continuity of $H$ gives a sufficiently fine rectangular grid in the parameter square so that the image of each cell has diameter less than $r/2$. We may add partition lines through all breakpoints of the two boundary paths. Refining a grid preserves the diameter bound. Each cell's image therefore lies in a disk of radius $r$, centered at the image of its lower-left vertex, and that disk lies in $U$.

Replace each grid edge by the straight segment joining the images of its endpoints. For an edge belonging to a cell, its endpoints lie in the cell's disk, and convexity keeps the entire segment in that disk. The local primitive there shows that the integral around the resulting four-segment cell boundary is zero: the primitive's four endpoint differences telescope exactly.

Now sum over all cells with the same counterclockwise orientation in the parameter square. A horizontal interior grid edge appears as the top edge of the cell below and as the bottom edge of the cell above. These two occurrences have the same endpoint images and opposite directions. They are the same straight segment, even though the two cells may use different local primitives. Their actual contour integrals cancel. Every vertical interior edge cancels by the identical argument. This leaves precisely the polygonal images of the four outer edges of the parameter square.

On a bottom boundary interval, the original path piece and its straight chord lie in the same cell disk. The primitive formula makes their integrals equal because their endpoints agree. Summing gives the integral of $\gamma_0$. The top boundary is traversed in reverse, so it contributes $-\int_{\gamma_1}f$. The two side boundaries have identical vertex images because $H(0,s)=H(1,s)$. Their polygonal segments occur in opposite directions and cancel, including any constant segments. The sum of zero cell integrals is consequently

$$0=\int_{\gamma_0}f-\int_{\gamma_1}f.$$

This proves homotopy invariance for a merely continuous homotopy. There was no appeal to an area integral over a potentially rough surface, no assumption that self-intersecting curves split into finitely many simple loops, and no unproved differentiability of intermediate paths.

### 3.3 The simply connected theorem and path independence

For this proof, a domain is **simply connected** if every continuous closed loop in it admits a homotopy through closed loops to a constant loop. This standard formulation allows the loop's common endpoint to move during the contraction. The equality of the two side boundaries in the preceding argument is exactly what is needed.

If $f$ is holomorphic on such a domain and $\gamma$ is closed piecewise $C^1$, apply homotopy invariance to a contraction. The constant loop has integral zero. Thus

$$\boxed{\int_\gamma f(z)\,dz=0.}$$

If two piecewise $C^1$ paths have the same endpoints, traverse the first and then the reverse of the second. Their concatenation is closed, so the integrals agree. This is **path independence**.

For completeness, points of an open connected subset of the plane can be joined by polygonal paths. Fix a base point and let $A$ consist of points reachable by such paths. Small disks show that $A$ is open in the domain: append a short straight segment. They also show its complement is open: if a small disk about an unreachable point contained a reachable point, a final segment would reach its center. Connectedness and nonemptiness force $A$ to be the whole domain.

We can therefore define $F(z)$ as the integral from a fixed base point to $z$ along any polygonal path. Path independence makes the definition unambiguous. Append a sufficiently short segment from $z$ to $z+h$ and repeat section 3.1's difference-quotient calculation. It proves $F'=f$. Thus every holomorphic function on a simply connected domain has a global primitive.

### Worked example 3 — one hole, two different conclusions

On $\mathbb C\setminus\{0\}$, parameterize the counterclockwise unit circle by $z=e^{it}$, $0\leq t\leq2\pi$. Directly,

$$\oint\frac{dz}{z}=\int_0^{2\pi}i\,dt=2\pi i.$$

Hence $1/z$ has no primitive on that domain, and the unit loop cannot contract there. Otherwise either the primitive theorem or homotopy invariance would force this integral to vanish.

On the same domain, $1/z^2$ does have the primitive $-1/z$. Its integral around every closed piecewise $C^1$ path is zero. A hole therefore permits an obstruction; it does not make every holomorphic function's loop integral nonzero. The simple-connectivity hypothesis gives a guarantee for all holomorphic functions. A particular function can have a primitive on a domain with holes.

## 4. Cauchy's formula with its exceptional point handled

### 4.1 Computing the kernel on a circle

Let $\Gamma$ be the circle $|\zeta-c|=R$, traversed counterclockwise once. If $|a-c|<R$, then

$$\frac1{\zeta-a}
=\sum_{n=0}^{\infty}\frac{(a-c)^n}{(\zeta-c)^{n+1}}$$

uniformly on $\Gamma$. This is the geometric series with ratio $(a-c)/(\zeta-c)$, whose modulus is the fixed number $q=|a-c|/R<1$. Its tail after index $N$ is bounded by $q^{N+1}/[R(1-q)]$, so the ML estimate justifies term-by-term integration.

With $\zeta=c+Re^{it}$,

$$\int_\Gamma\frac{d\zeta}{(\zeta-c)^{n+1}}
=iR^{-n}\int_0^{2\pi}e^{-int}\,dt
=\begin{cases}2\pi i,&n=0,\\0,&n\geq1.\end{cases}$$

The zero values follow by evaluating the elementary exponential antiderivative. Consequently

$$\int_\Gamma\frac{d\zeta}{\zeta-a}=2\pi i.$$

If $|a-c|>R$, the integrand is holomorphic on a disk larger than the closed disk bounded by $\Gamma$, and its integral is zero by Cauchy's theorem. If equality holds, the integrand is undefined at a point of the path, so this ordinary contour integral formula does not apply.

### 4.2 The formula and its proof

**Cauchy's formula on a disk.** Suppose $f$ is holomorphic on an open set containing the closed disk $\overline{D(c,R)}$. For $a\in D(c,R)$ and the positively oriented boundary $\Gamma$,

$$\boxed{f(a)=\frac1{2\pi i}\int_\Gamma\frac{f(\zeta)}{\zeta-a}\,d\zeta.}$$

There is a slightly larger concentric disk on which $f$ is holomorphic, by compactness of the closed disk. On that larger disk define

$$g(\zeta)=
\begin{cases}
\dfrac{f(\zeta)-f(a)}{\zeta-a},&\zeta\ne a,\\[6pt]
f'(a),&\zeta=a.
\end{cases}$$

The derivative definition says exactly that $g$ is continuous at $a$. The quotient rule shows it is holomorphic away from $a$. Section 2.3 gives zero triangle integrals; section 3.1 then gives a primitive on the larger disk. Thus $\int_\Gamma g=0$. On the contour, where no denominator vanishes,

$$\frac{f(\zeta)}{\zeta-a}=g(\zeta)+\frac{f(a)}{\zeta-a}.$$

Integrating and applying the kernel calculation gives $\int_\Gamma f(\zeta)/(\zeta-a)\,d\zeta=2\pi i f(a)$, proving the formula.

We have not presumed that the extended quotient $g$ is holomorphic at $a$. Its continuity and zero triangle integrals were enough to establish its primitive. Later we will prove that the extension is holomorphic as well. This dependency avoids using the conclusion of analyticity inside its own proof.

### Worked example 4 — orientation, location, and a removable denominator

Let $\Gamma$ be $|z|=3$ counterclockwise. Since $f(z)=z^2+2$ is entire and $1$ lies inside,

$$\int_\Gamma\frac{z^2+2}{z-1}\,dz=2\pi i(1^2+2)=6\pi i.$$

Clockwise traversal gives $-6\pi i$. Traversing the same counterclockwise circle twice gives $12\pi i$, by additivity. On $|z|=1/2$ the integral is zero because the singularity at $1$ lies outside the disk.

By contrast,

$$\int_{|z|=3}\frac{z^2-1}{z-1}\,dz=0.$$

The numerator vanishes at $1$, and for $z\ne1$ the quotient equals $z+1$. That polynomial extends the function across the apparent singularity. Cauchy's formula agrees, since $f(1)=0$. A denominator written as zero at a point does not by itself prove the singularity is a pole.

## 5. From holomorphy to convergent power series

### 5.1 Deriving coefficients and controlling the remainder

Keep a closed disk $\overline{D(c,R)}$ inside the domain of holomorphy. For $|z-c|<R$, expand the kernel in Cauchy's formula:

$$\frac1{\zeta-z}=\sum_{n=0}^\infty
\frac{(z-c)^n}{(\zeta-c)^{n+1}}.$$

Let $M=\max_{\Gamma}|f|$. For any fixed $0<r<R$, the expansion is uniform for both $\zeta\in\Gamma$ and $|z-c|\leq r$. Integrating it gives

$$f(z)=\sum_{n=0}^\infty A_n(z-c)^n,\qquad
A_n=\frac1{2\pi i}\int_\Gamma\frac{f(\zeta)}{(\zeta-c)^{n+1}}\,d\zeta.$$

The ML bound gives

$$|A_n|\leq\frac{M}{R^n}.$$

The geometric remainder supplies the explicit estimate

$$\sup_{|z-c|\leq r}\left|f(z)-\sum_{n=0}^N A_n(z-c)^n\right|
\leq\frac{M(r/R)^{N+1}}{1-r/R}.$$

Therefore the equality with a power series is proved, and its convergence is uniform on every smaller closed disk. The chosen $R$ need not be the largest possible radius. The proof establishes convergence at least throughout every disk whose closure lies in the holomorphic domain.

### 5.2 Why differentiation of the series is legitimate

Set $p_N(z)=\sum_{n=0}^N A_n(z-c)^n$. The candidate first-derivative series is

$$G(z)=\sum_{n=1}^\infty nA_n(z-c)^{n-1}.$$

On $|z-c|\leq r<R$, its terms are bounded by $(M/R)n(r/R)^{n-1}$. This numerical series converges: for $q=r/R<1$, the ratio of successive positive terms is $q(1+1/n)$, which is eventually less than a fixed number strictly between $q$ and $1$. Thus the tail is bounded by a convergent geometric tail. The derivative polynomials $p_N'$ converge uniformly to a continuous function $G$ on that closed disk.

Choose $z$ in its interior and a sufficiently short segment to $z+h$ lying inside it. For each polynomial,

$$p_N(z+h)-p_N(z)=\int_{[z,z+h]}p_N'(w)\,dw.$$

Uniform convergence of $p_N$ and $p_N'$ lets us pass to the limit, using the ML estimate on the segment:

$$f(z+h)-f(z)=h\int_0^1G(z+th)\,dt.$$

Divide by $h$ and use continuity of $G$ to obtain $f'(z)=G(z)$. This proves the exchange of derivative and infinite sum rather than assuming it.

The same argument applies to every fixed order $k$. The numerical bounds contain the polynomial factor $n(n-1)\cdots(n-k+1)$ multiplied by a geometric factor. The ratio still tends to $r/R<1$, so each derivative series converges uniformly on smaller disks. Induction proves that all complex derivatives exist and

$$f^{(k)}(c)=k!A_k.$$

Consequently a holomorphic function is **analytic**, meaning locally represented by a convergent power series, and its coefficients are exactly its Taylor coefficients. We derived this from existence of the first complex derivative on an open set. The corresponding implication is false for general infinitely differentiable real functions. Appendix A.5 supplies the complete flat-function counterexample instead of relying on an unavailable earlier volume.

### 5.3 The derivative formula at any interior point

For the fixed circle $\Gamma$ and any interior $a$, let $d=\min_{\zeta\in\Gamma}|\zeta-a|>0$. For $|h|<d/2$,

$$\frac{1}{h}\left(\frac1{\zeta-a-h}-\frac1{\zeta-a}\right)
=\frac1{(\zeta-a-h)(\zeta-a)}.$$

This converges uniformly on $\Gamma$ to $1/(\zeta-a)^2$. Subtracting the limit shows its error is at most $2|h|/d^3$. Multiplication by the bounded function $f$ and the ML estimate permit differentiating Cauchy's formula once.

For a positive integer $p$, the identity

$$\frac{(A-h)^{-p}-A^{-p}}h
=\frac{\sum_{j=0}^{p-1}A^{p-1-j}(A-h)^j}{A^p(A-h)^p}$$

shows uniform convergence to $p/A^{p+1}$ when $A=\zeta-a$ stays on this compact contour away from zero. Every numerator is a finite polynomial, and both denominator factors have a fixed positive lower bound. Thus the same argument can be repeated. It proves, for every integer $n\geq0$,

$$\boxed{f^{(n)}(a)=\frac{n!}{2\pi i}\int_\Gamma
\frac{f(\zeta)}{(\zeta-a)^{n+1}}\,d\zeta.}$$

The circle need not be centered at $a$. For a circle of radius $R$ centered at $a$, the bound becomes the **Cauchy estimate**

$$|f^{(n)}(a)|\leq\frac{n!M_R}{R^n},\qquad
M_R=\max_{|z-a|=R}|f(z)|.$$

### Worked example 5 — a third-order denominator

On the counterclockwise circle $|z|=2$, evaluate

$$I=\int\frac{e^{2z}}{(z-1)^3}\,dz.$$

The numerator is entire, $1$ lies strictly inside, and the third power in the denominator corresponds to $n=2$, not $n=3$. Since $(e^{2z})''=4e^{2z}$,

$$I=\frac{2\pi i}{2!}\,4e^2=4\pi i e^2.$$

The factorial is required by the derivative formula. Omitting it would double the answer. If the circle were $|z|=1$, the denominator would vanish on the path and this evaluation would not apply.

### Worked example 6 — a certified approximation error

Suppose $f$ is holomorphic on a neighborhood of $|z|\leq2$ and $|f(z)|\leq5$ on $|z|=2$. On $|z|\leq1/2$, the Taylor polynomial of degree $N$ about zero satisfies

$$|f(z)-p_N(z)|\leq\frac{5(1/4)^{N+1}}{1-1/4}
=\frac{20}{3}\,4^{-(N+1)}.$$

For $N=6$, this is $20/(3\cdot16384)<0.000407$. We have controlled the entire smaller disk using boundary data on a larger disk. The estimate is valid without knowing the individual coefficients, although coefficient information might produce a sharper bound.

## 6. Removable points, Morera's theorem, and limits

### 6.1 The quotient in Cauchy's proof really does extend

Expand $f$ at $a$ using the now-proved Taylor theorem:

$$f(z)=f(a)+f'(a)(z-a)+\sum_{n=2}^\infty A_n(z-a)^n.$$

For $z\ne a$, divide the difference by $z-a$:

$$\frac{f(z)-f(a)}{z-a}=f'(a)+\sum_{n=2}^\infty A_n(z-a)^{n-1}.$$

The series has the same positive local convergence radius and defines a holomorphic function at $a$ as well, by the general power-series differentiation argument in Appendix A.3. Its value there is $f'(a)$. This proves the holomorphic extension of the quotient used earlier and identifies its derivative at $a$ as $f''(a)/2$.

### 6.2 Every bounded isolated singularity is removable

**Removable singularity theorem.** Suppose $f$ is holomorphic on $0<|z-a|<r$ and bounded on some smaller punctured disk. Then there exists a unique holomorphic function on $D(a,r)$ agreeing with $f$ away from $a$.

Shrink to a disk where $|f|\leq M$, and define

$$h(z)=\begin{cases}(z-a)^2f(z),&z\ne a,\\0,&z=a.\end{cases}$$

The bound proves continuity at $a$. Its difference quotient there satisfies

$$\left|\frac{h(z)-h(a)}{z-a}\right|=|(z-a)f(z)|\leq M|z-a|\to0.$$

Thus $h$ is holomorphic at $a$, with $h(a)=h'(a)=0$, and is holomorphic elsewhere by the product rule. Its Taylor series has no constant or linear term:

$$h(z)=\sum_{n=2}^\infty b_n(z-a)^n.$$

Dividing by $(z-a)^2$ on the punctured disk gives the convergent series $\sum_{n=2}^\infty b_n(z-a)^{n-2}$. Define its value at $a$ to be $b_2$. The series proves a holomorphic extension locally; joining it to the original function elsewhere in $D(a,r)$ gives the stated extension. Any two continuous extensions must have the same value, because their values at $a$ are limits of their common punctured values. That proves uniqueness.

The squared factor was chosen to make differentiability at $a$ follow from boundedness. Multiplying only by $z-a$ would make continuity immediate but would leave a difference quotient equal to $f(z)$, whose limit is precisely what was not yet known.

### 6.3 Morera's converse and uniform limits

**Morera's theorem, local triangle form.** If $f$ is continuous on an open set $U$ and has zero integral around every triangle contained in $U$, then $f$ is holomorphic on $U$.

On each small disk, section 3.1 constructs a holomorphic primitive $F$ with $F'=f$. Section 5 proves that a holomorphic function has holomorphic derivatives, so $F'=f$ is holomorphic there. Such disks cover $U$, proving the result. We could not validly use the last step before deriving analyticity.

As a consequence, a sequence of holomorphic functions converging uniformly on every compact subset of $U$ has a holomorphic limit. Uniform convergence on a small closed disk proves the limit is continuous there. On any filled triangle in $U$, uniform convergence on its compact boundary and the ML estimate give

$$\int_{\partial T}f=\lim_{n\to\infty}\int_{\partial T}f_n=0.$$

Morera now applies. Moreover, the derivative formulas on a fixed surrounding circle show uniform convergence of derivatives on every smaller disk: if all points in that disk have distance at least $d>0$ from the circle, the integral estimate bounds the $k$th derivative difference by $k!L(\Gamma)\sup_\Gamma|f_n-f|/(2\pi d^{k+1})$. For any compact subset of U, choose such a smaller disk around each point and take a finite subcover. The maximum of the finitely many bounds tends to zero, proving uniform convergence of each fixed-order derivative on that compact subset.

### Worked example 7 — removing a singularity and finding its value

For $z\ne0$, let $f(z)=(e^z-1-z)/z^2$. Since every derivative of $e^z$ equals $e^z$, its Taylor coefficients at zero are $1/n!$, by section 5. Therefore

$$f(z)=\frac12+\frac z6+\frac{z^2}{24}+\cdots.$$

The holomorphic extension has $f(0)=1/2$ and $f'(0)=1/6$. In particular the numerator's two vanishing initial coefficients are what cancel the apparent second-order singularity. By comparison $e^z/z^2$ has no bounded extension: along positive real $z\to0$, its modulus diverges.

## 7. Rigidity: isolated zeros, identity, and bounded entire functions

### 7.1 Isolated zeros and the identity theorem

Suppose $f$ is holomorphic near $a$ and $f(a)=0$. If some Taylor coefficient is nonzero, let $m\geq1$ be its first nonzero index. Factoring the convergent series gives

$$f(z)=(z-a)^m g(z),\qquad g(a)\ne0,$$

with $g$ holomorphic near $a$. Continuity ensures that $g$ stays nonzero on a smaller disk, so $a$ is the only zero there. The integer $m$ is the zero's multiplicity. If all coefficients vanish, the Taylor series proves that $f$ vanishes on a neighborhood of $a$.

**Identity theorem.** If two holomorphic functions on a domain agree on a set having an accumulation point in that domain, they agree everywhere on the domain.

Apply the previous observation to their difference $h$. Continuity first gives h(a)=0 at the interior accumulation point a. Distinct zeros approach a, so this zero cannot be isolated; all Taylor coefficients there vanish and $h$ vanishes on a neighborhood. Let $S$ be the set of points where $h$ vanishes on a neighborhood. It is nonempty and open. It is also closed relative to the domain: if $a_j\in S$ and $a_j\to a$ in the domain, every derivative $h^{(n)}$ vanishes at every $a_j$; continuity of these derivatives gives $h^{(n)}(a)=0$ for every $n$. The Taylor expansion at $a$ therefore vanishes nearby, putting $a$ in $S$. Connectedness forces $S$ to be the whole domain.

The accumulation point must belong to the domain. A function can have infinitely many zeros approaching a boundary point without vanishing identically. The theorem also does not say that two isolated matching values determine an arbitrary holomorphic function.

### 7.2 Liouville's theorem

A function holomorphic on all of $\mathbb C$ is called **entire**. Suppose an entire function satisfies $|f(z)|\leq M$ for every complex $z$, with one fixed finite constant $M$. For any center $a$ and any radius $R>0$, Cauchy's estimate gives

$$|f'(a)|\leq M/R.$$

Let $R\to\infty$. Then $f'(a)=0$. Since $a$ was arbitrary, the derivative vanishes everywhere. On the segment from any $a$ to any $b$, the real chain rule and FTC give $f(b)-f(a)=\int_0^1f'(a+t(b-a))(b-a)\,dt=0$. Thus $f$ is constant. This is **Liouville's theorem**.

Boundedness on each individual compact disk would be insufficient: every entire function has that property by continuity. The hypothesis is one common global bound. Nor is boundedness on the real axis enough: $e^{iz}$ has modulus one on the real axis but modulus $e^{-y}$ at $z=x+iy$, unbounded as $y\to-\infty$.

### Worked example 8 — a bounded reciprocal forces a root

Imagine that $p(z)=z^4+z+1$ had no complex root. Then $1/p$ would be entire. For $|z|\geq2$,

$$|p(z)|\geq|z|^4-|z|-1\geq|z|^4-\tfrac14|z|^4
=\tfrac34|z|^4.$$

The intermediate bound follows because $(|z|+1)/|z|^4$ decreases for positive $|z|$ and at $2$ equals $3/16<1/4$. Thus the reciprocal is bounded outside that disk. Inside, continuity and the assumed absence of zeros give a positive minimum of $|p|$, so the reciprocal is bounded there too. Liouville makes $1/p$ constant, which contradicts the polynomial's degree. We have proved existence of a complex root without calculating its coordinates. The following section proves the argument for every nonconstant polynomial.

### 7.3 Mean values and the maximum-modulus principle

Parameterize a circle centered at $a$ in Cauchy's formula. The factors $re^{it}$ cancel, giving

$$f(a)=\frac1{2\pi}\int_0^{2\pi}f(a+re^{it})\,dt$$

whenever the closed disk and a neighborhood lie in the holomorphic domain. This is a mean-value identity for the **complex values** of the function. It does not state that the average of their moduli equals the modulus at the center. The integral triangle inequality supplies only

$$|f(a)|\leq\frac1{2\pi}\int_0^{2\pi}|f(a+re^{it})|\,dt.$$

**Strong maximum-modulus principle.** If the modulus of a holomorphic function on a domain has a local maximum at an interior point, then the function is constant on the domain.

To prove it, suppose $|f(z)|\leq|f(a)|=M$ throughout a small disk about $a$. If $M=0$, the function vanishes throughout that disk, and the identity theorem makes it zero everywhere on the domain. Suppose $M>0$. Choose a constant $\lambda$ of modulus one with $\lambda f(a)=M$, and put $g=\lambda f$. Then $g(a)=M$ is a positive real number and $|g(z)|\leq M$ in the disk.

For any sufficiently small radius $r$, the mean-value identity and linearity of the real part give

$$M=\frac1{2\pi}\int_0^{2\pi}\operatorname{Re}g(a+re^{it})\,dt.$$

The continuous real function $M-\operatorname{Re}g(a+re^{it})$ is nonnegative, since $\operatorname{Re}g\leq|g|\leq M$, and its integral is zero. It must vanish at every parameter value: if it were positive at one value, continuity would make it bounded below by a positive number on a small interval and hence give a positive integral. Thus the real part of $g$ equals $M$ all around the circle. At a point with $\operatorname{Re}g=M$ and $|g|\leq M$, the relation $|g|^2=M^2+(\operatorname{Im}g)^2$ forces its imaginary part to be zero. Therefore $g=M$ everywhere on this circle.

The argument applies to every sufficiently small positive radius, so $g=M$ on an entire neighborhood of $a$. The identity theorem extends that equality to the connected domain, proving that $f$ is constant. Every equality step has been justified; no assumption that complex numbers have a compatible total order entered the argument.

There is a corresponding boundary statement. Suppose $D$ is a bounded domain, $f$ is holomorphic on $D$, and $f$ is continuous on its closure. The compact closure ensures that $|f|$ attains a maximum. If $f$ is nonconstant, that maximum cannot occur inside $D$ by the strong principle, so it occurs on the boundary. Thus

$$|f(z)|\leq\max_{w\in\partial D}|f(w)|\qquad(z\in\overline D).$$

For a constant function the inequality also holds. The boundary is nonempty: a segment from an interior point to a point outside a large disk containing D must first leave D at a boundary point. Boundary continuity is part of this formulation: without it, the displayed maximum might not even be defined. If two functions meeting these hypotheses agree on the boundary, apply the inequality to their difference. Its boundary maximum modulus is zero, so the two functions agree everywhere. This proves a uniqueness consequence from the same analytic argument.

For a concrete calculation, $f(z)=z^2-1$ satisfies $|f(z)|\leq|z|^2+1\leq2$ on the closed unit disk. At $z=i$ and $z=-i$, its value is $-2$, so the bound is attained. Because the polynomial is nonconstant, the maximum-modulus principle also establishes the strict inequality $|z^2-1|<2$ for every $|z|<1$. A triangle estimate supplied the upper bound; the boundary evaluations proved sharpness; the strong principle excluded an interior equality. These are three separate logical contributions to the result.

## 8. The fundamental theorem of algebra

**Theorem.** Every complex polynomial of positive degree has a complex root. Consequently a degree-$n$ complex polynomial factors into $n$ linear factors, counting multiplicity.

Let

$$p(z)=a_nz^n+a_{n-1}z^{n-1}+\cdots+a_0,\qquad n\geq1,\quad a_n\ne0.$$

Put $B=\sum_{k=0}^{n-1}|a_k|$. For $|z|\geq1$,

$$\left|\sum_{k=0}^{n-1}a_kz^k\right|\leq B|z|^{n-1}.$$

Choose $R\geq1$ so large that $R\geq2B/|a_n|$. Then for $|z|\geq R$,

$$|p(z)|\geq|a_n||z|^n-B|z|^{n-1}
\geq\frac{|a_n|}{2}|z|^n.$$

Assume for contradiction that $p$ has no root. The quotient rule makes $1/p$ entire. The displayed estimate bounds it outside $D(0,R)$. On the closed disk, the continuous positive function $|p|$ attains a positive minimum $m$. Positivity of the minimum follows because an attained value zero would itself be a root. Thus $|1/p|\leq1/m$ there, giving a global finite bound. Liouville's theorem makes $1/p$ constant, so $p$ is constant, a contradiction.

There is therefore a root $a$. The elementary identity

$$z^k-a^k=(z-a)\sum_{j=0}^{k-1}z^{k-1-j}a^j$$

gives $p(z)-p(a)=(z-a)q(z)$ after summing for $k=1,\ldots,n$. Its quotient has leading coefficient $a_n$ and degree $n-1$; since $p(a)=0$, this proves the factorization step directly. If that degree is positive, apply the root-existence result again. Induction gives

$$p(z)=a_n\prod_{j=1}^n(z-\alpha_j).$$

A repeated value among the $\alpha_j$ records multiplicity. No root can have a total multiplicity greater than $n$, since each removed factor lowers the degree by one. This completes both parts of the theorem.

The proof provides existence and factorization, not a formula by radicals for arbitrary degree. It does not give a numerical root-finding algorithm or a stability bound for measured coefficients. Those are separate questions in algebra and numerical analysis. The word “algebra” in the theorem's name does not prevent a proof from using complex analysis; the preceding argument exhibits exactly which analytic results support it.

## 9. Winding numbers and a finite-pole residue theorem

### 9.1 An integer obtained from a contour integral

For a closed piecewise $C^1$ path $\gamma:[0,1]\to\mathbb C\setminus\{a\}$ define

$$\operatorname{Ind}(\gamma,a)=\frac1{2\pi i}\int_\gamma\frac{dz}{z-a}.$$

We must prove that this quantity is an integer before treating it as a count. Let

$$B(t)=\int_0^t\frac{\gamma'(s)}{\gamma(s)-a}\,ds,$$

interpreted piecewise across the finite path partition. It is continuous, piecewise $C^1$, and $B(0)=0$. On each smooth piece, differentiation gives

$$\frac{d}{dt}\left(e^{-B(t)}(\gamma(t)-a)\right)=0.$$

FTC and continuity across endpoints make this product constant on the whole interval. Therefore

$$\gamma(t)-a=(\gamma(0)-a)e^{B(t)}.$$

Since the path is closed, $e^{B(1)}=1$. Writing $B(1)=x+iy$, the modulus implies $e^x=1$, hence $x=0$; the sine and cosine components imply $y=2\pi k$ for an integer $k$. Thus $B(1)=2\pi i k$ and the index is $k$.

Homotopy invariance applied to $1/(z-a)$ shows that the integer cannot change while the loop is continuously deformed without crossing $a$. A counterclockwise circle has index one at an interior point and zero at an exterior point, by the kernel calculation. Reversal negates the index, and repeated traversal adds indices.

### 9.2 Poles and residues from Taylor coefficients

An isolated singularity $a$ is a **pole of order $m\geq1$** if, near $a$,

$$f(z)=\frac{g(z)}{(z-a)^m},$$

where $g$ is holomorphic across $a$ and $g(a)\ne0$. Taylor expansion of $g$ gives

$$f(z)=\frac{b_0}{(z-a)^m}+\frac{b_1}{(z-a)^{m-1}}
+\cdots+\frac{b_{m-1}}{z-a}+h(z),$$

where $h$ extends holomorphically across $a$. The finite sum of negative powers is the **principal part**, and the coefficient of $(z-a)^{-1}$ is the **residue**:

$$\operatorname{Res}(f,a)=b_{m-1}=\frac{g^{(m-1)}(a)}{(m-1)!}.$$

This derives the pole formula from Taylor's theorem. The order and principal part are unique. If two representations have orders m>n, multiplying their equality by $(z-a)^m$ and taking the limit at a would make the nonzero leading numerator equal zero, a contradiction. For the principal part, subtract two proposed finite negative-power expansions with holomorphic remainders. Multiply by the highest remaining negative power's compensating positive power and let z tend to a. Its coefficient must vanish. Repeating removes every coefficient. Thus the residue is independent of the representation. No general Laurent-series theorem is needed for this finite-pole case.

### 9.3 Residue theorem in the exact scope proved here

Let $U$ be a simply connected domain. Suppose $f$ is holomorphic on $U$ except at finitely many points $a_1,\ldots,a_N$, each a pole, and let $\gamma$ be a closed piecewise $C^1$ path in $U$ avoiding those points. Then

$$\boxed{\int_\gamma f(z)\,dz
=2\pi i\sum_{j=1}^N\operatorname{Ind}(\gamma,a_j)
\operatorname{Res}(f,a_j).}$$

Subtract from $f$ the principal parts at all its poles. Near any one pole, the corresponding subtraction removes all its negative powers, and principal parts belonging to other poles are holomorphic there. The resulting function therefore extends holomorphically to all of $U$. Its integral around $\gamma$ is zero by the simply connected theorem.

For each remaining term $(z-a)^{-k}$ with $k\geq2$, the function

$$-\frac1{k-1}(z-a)^{-(k-1)}$$

is a single-valued primitive on $\mathbb C\setminus\{a\}$, so its closed-path integral is zero. A term $b/(z-a)$ contributes $2\pi i b\operatorname{Ind}(\gamma,a)$ by the definition of index. Adding the finitely many contributions proves the formula. The listed poles are distinct. If there are none, the sum is empty and equals zero, recovering the simply connected Cauchy theorem.

This proof accommodates self-intersections and multiple traversals through their indices. It does not claim the most general residue theorem on arbitrary domains or the version including essential singularities; those require additional hypotheses or Laurent-series arguments. Every application below lies in the stated finite-pole scope.

### Worked example 9 — two poles, then a reversed traversal

Let $f(z)=z/[(z-1)(z+2)]$. The simple pole at $1$ has residue $1/3$, since $(z-1)f(z)=z/(z+2)$. At $-2$, the residue is $2/3$, since $(z+2)f(z)=z/(z-1)$.

For the counterclockwise circle $|z|=3$, both indices are one. Hence

$$\int_{|z|=3}f(z)\,dz=2\pi i(1/3+2/3)=2\pi i.$$

For $|z|=3/2$, the indices are one at $1$ and zero at $-2$, so the answer is $2\pi i/3$. Traversing this smaller circle three times clockwise changes its index at $1$ to $-3$ and gives $-2\pi i$. None of these circles passes through a pole.

## 10. Exercises with full solutions

### Exercise 1 — a nonholomorphic integrand on a closed curve

For R>0, compute $\int_\Gamma\overline z\,dz$ on $|z|=R$ counterclockwise, and explain why the result does not contradict Cauchy's theorem.

**Solution.** Put $z=Re^{it}$ for $0\leq t\leq2\pi$. Then $\overline z=Re^{-it}$ and $dz=iRe^{it}\,dt$. Thus

$$\int_\Gamma\overline z\,dz=\int_0^{2\pi}iR^2\,dt=2\pi iR^2.$$

The function $z\mapsto\overline z$ is not holomorphic on a neighborhood of the disk. Its difference quotient $\overline h/h$ equals one along real increments and negative one along imaginary increments, so the complex derivative fails at every point. Smoothness as a function of two real coordinates does not satisfy the holomorphy hypothesis.

### Exercise 2 — path dependence calculated without a theorem

Integrate $\overline z$ from $0$ to $1+i$ first along the straight segment and then along the two segments $0\to1\to1+i$.

**Solution.** On the straight segment, $z=t(1+i)$ with $0\leq t\leq1$. The integrand times differential is $t(1-i)(1+i)\,dt=2t\,dt$, so the integral is $1$.

On $0\to1$, use $z=x$, giving $\int_0^1x\,dx=1/2$. On $1\to1+i$, use $z=1+it$; then $\overline z=1-it$ and $dz=i\,dt$, so the integral is $\int_0^1(t+i)\,dt=1/2+i$. The total along the bent path is $1+i$, different from $1$. The difference is the integral around the resulting oriented triangle. There is no primitive for $\overline z$ on the plane, consistently with the direct calculation.

### Exercise 3 — construct and inspect a global logarithm

Let $U$ be a simply connected domain that omits zero. Show that there is a holomorphic $L$ on $U$ with $e^{L(z)}=z$ and $L'(z)=1/z$.

**Solution.** Cauchy's theorem supplies a primitive $F$ of $1/z$. Fix $b\in U$ and choose a complex number $\ell$ with $e^\ell=b$, using a polar representation of this one nonzero number. Define $L(z)=F(z)-F(b)+\ell$. Then $L'=1/z$. Differentiate $q(z)=e^{-L(z)}z$:

$$q'(z)=e^{-L(z)}-ze^{-L(z)}L'(z)=0.$$

An open connected set is polygonally connected, and FTC on those paths makes $q$ constant. At $b$, its value is $e^{-\ell}b=1$, so $e^{L(z)}=z$. This constructs a branch of logarithm; it does not provide a branch on the whole punctured plane. Such a branch would differentiate to $1/z$ there and contradict its nonzero unit-circle integral. Different choices of $\ell$ differing by $2\pi i k$ give corresponding logarithm branches.

### Exercise 4 — choose the correct derivative order

Evaluate $\int_{|z|=2}(z^3+1)/(z-i)^2\,dz$ counterclockwise.

**Solution.** The numerator $f(z)=z^3+1$ is entire, $i$ is strictly inside, and the squared denominator uses the first derivative. Since $f'(z)=3z^2$, $f'(i)=-3$. Therefore

$$\int_{|z|=2}\frac{z^3+1}{(z-i)^2}\,dz=2\pi i(-3)=-6\pi i.$$

Substituting $f(i)$ instead would apply the first-order-denominator formula to the wrong integrand. The pole is not on the path because $|i|=1<2$.

### Exercise 5 — a growth condition forces a polynomial

Suppose an entire function satisfies $|f(z)|\leq C(1+|z|^m)$ for all $z$, where $C>0$ and $m$ is a nonnegative integer. Prove that $f$ is a polynomial of degree at most $m$.

**Solution.** On the circle $|z|=R$, Cauchy's coefficient estimate about zero gives, for each integer $n>m$,

$$\frac{|f^{(n)}(0)|}{n!}\leq\frac{C(1+R^m)}{R^n}
=C(R^{-n}+R^{m-n}).$$

Both powers tend to zero as $R\to\infty$, so every Taylor coefficient with index $n>m$ is zero. For an arbitrary point $z$, choose a radius $R>|z|$. The Taylor representation on that disk equals $f(z)$, but the only possibly nonzero coefficients have indices $0$ through $m$. Thus one polynomial represents $f$ everywhere. The conclusion includes constant functions and the zero polynomial; the zero polynomial does not need a separately assigned finite degree.

### Exercise 6 — determine a removable value from a derivative

Let $f$ be holomorphic near $a$. Show that

$$q(z)=\frac{f(z)-f(a)-f'(a)(z-a)}{(z-a)^2},\qquad z\ne a,$$

extends holomorphically across $a$, and find its value and first derivative there.

**Solution.** Taylor's theorem gives

$$f(z)=f(a)+f'(a)(z-a)+\frac{f''(a)}2(z-a)^2
+\frac{f'''(a)}6(z-a)^3+\cdots.$$

Subtract the first two terms and divide the convergent series by $(z-a)^2$ away from $a$. The resulting series has nonnegative powers and remains convergent on a neighborhood of $a$. It defines the required holomorphic extension, with

$$q(a)=f''(a)/2,\qquad q'(a)=f'''(a)/6.$$

Uniqueness follows from continuity. Merely substituting $z=a$ into the original displayed quotient would produce an undefined $0/0$ expression; the series establishes the limit and regularity.

### Exercise 7 — a boundary accumulation does not force identity

On $U=\mathbb C\setminus\{0\}$, consider $f(z)=\sin(1/z)$. Show that it has infinitely many zeros approaching zero but is not identically zero. Reconcile this with the identity theorem.

**Solution.** Define sine through the entire exponential formula $\sin w=(e^{iw}-e^{-iw})/(2i)$. Composition with $1/z$ is holomorphic on $U$. For every positive integer $n$, $z_n=1/(n\pi)$ lies in $U$ and gives $f(z_n)=\sin(n\pi)=0$. These points tend to zero. However, at $z=2/\pi$, the value is $\sin(\pi/2)=1$, so the function is not identically zero. The accumulation point zero is excluded from $U$. The identity theorem requires an accumulation point inside the holomorphic domain, so its hypothesis fails.

### Exercise 8 — an order-two pole and its residue

Evaluate the integral of $e^z/[z^2(z-2)]$ around $|z|=1$ counterclockwise.

**Solution.** The only enclosed pole is zero. Write the integrand near zero as $g(z)/z^2$, where $g(z)=e^z/(z-2)$ is holomorphic there. Its residue is $g'(0)$. The quotient derivative is

$$g'(z)=\frac{e^z(z-2)-e^z}{(z-2)^2}
=\frac{e^z(z-3)}{(z-2)^2},$$

so $g'(0)=-3/4$. The pole at $2$ has index zero for this circle. The residue theorem gives

$$\int_{|z|=1}\frac{e^z}{z^2(z-2)}\,dz
=2\pi i(-3/4)=-\frac{3\pi i}{2}.$$

Alternatively apply the first-derivative Cauchy formula directly to $g(z)/z^2$ on the disk of radius one. Both methods have the same analytic justification and give the same answer.

### Exercise 9 — compact convergence and derivatives

For $p_N(z)=\sum_{k=0}^N z^k$, establish convergence and derivative convergence on each disk $|z|\leq r$ with 0<r<1 and identify both limits. Also check the singleton case r=0.

**Solution.** The finite geometric identity gives

$$p_N(z)=\frac{1-z^{N+1}}{1-z}.$$

Thus $|p_N(z)-(1-z)^{-1}|\leq r^{N+1}/(1-r)$ on the smaller disk, proving uniform convergence. The derivative series is $\sum_{k=1}^\infty kz^{k-1}$. Its terms are uniformly bounded by $kr^{k-1}$, a convergent numerical series by the ratio argument in section 5.2. The segment-integral proof there permits differentiating the limit, so the derivative series equals $1/(1-z)^2$ and $p_N'$ converges uniformly on every smaller closed disk. For r=0, p_N(0)=1 for every N and p_N'(0)=1 for N≥1, so the same limits hold without a ratio estimate. The statements do not extend to a disk containing $z=1$, where the candidate limit has a pole and $p_N(1)=N+1$ diverges.

## 11. Source relationship and the remaining boundary of this proof set

The earlier volume linked Jeremy Orloff's MIT notes for the contour theorem and formula. Those documents were reopened for this continuation. [MIT 18.04, Topic 3](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/1968cab6de7c96ead1c83001459a007b_MIT18_04S18_topic3.pdf) presents the path integral, primitive theorem, and simply connected conclusion; its discussion identifies additional work needed to make the general nonsimple-curve argument precise. Sections 2 and 3 above supply that work through Goursat and a continuous homotopy grid. This is a reconstructed proof, not a transcription of those notes.

[MIT 18.04, Topic 4](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/b1a90df19f643b974555bbbb93138a48_MIT18_04S18_topic4.pdf) provides the reference statements of Cauchy's formula and its derivative versions. The arguments above track their domain and contour conditions, and make the exceptional-point and uniform-convergence steps explicit. These teaching references are primary course materials; they are not original nineteenth-century publications.

Historical names identify the established results. This continuation has not examined original Cauchy or Goursat manuscripts and therefore makes no new claim about publication priority or the exact wording of their original hypotheses. The origin studied here is the logical construction from the derivative and integral definitions, connected to the retained historical-source work in Volume 3. A textual history comparing original editions remains a distinct source study.

The general simply connected contour theorem, disk Cauchy formula, all derivative formulas, local analyticity, bounded removable singularities, identity theorem, Liouville's theorem, and fundamental theorem of algebra have been proved in the stated forms. The residue theorem has been proved for finitely many poles in a simply connected domain. General Laurent theory, essential-singularity residue formulas, arbitrary-domain homology formulations, the Riemann mapping theorem, and boundary-value theory are not silently included in that claim. The explicit boundary preserves the distinction between the mathematics established in these pages and the larger subject still available for study.


---

## New preparation note — 2026-10-15

The source manuscript is dated September 20, 2026 and was recovered from the existing teaching archive on October 14. Its exact bytes are retained privately with archive/member provenance. The earlier preparation copy preserved the entire body. The present October 16 corrected derivative makes the separately recorded changes in ERRATA.json and CHANGES.patch; preservation/teaching-complex-analysis-proofs.before.md retains the exact pre-review preparation copy. Original-source SHA-256: `098887a46f272691cbbcc12fcef3cbe3b2a028aa364751ac6f97b16c49eb0e16`; original byte length: 54,164.

The original study context identifies the exposition as assistant-written reconstructions of established results, prepared for the project owner. The retained complex-analysis chapter names GAUCIA Actual; this preparation was performed by Codex as supporting reviewer. Do not convert preparation for the owner into an ownership or novelty claim over established theorems. The chapter is one part of a larger finite teaching collection and can refer to material in other volumes; this selection does not claim those other volumes are included.

The historical bibliography is retained. The present review reopened the two cited MIT course notes and consulted the author-hosted Trinity College Dublin notes for targeted mathematical cross-checks. This is a full review of the arguments in this selected chapter under its stated prerequisites, not independent certification or an audit of unrelated manuscripts. No claim about historical publication priority or a new solution to an open problem is added. The original pre-review copy and every changed passage remain separately preserved.


## Appendix A. Explicit prerequisites and elementary proofs added October 16, 2026

This appendix closes dependencies previously assigned to an earlier volume. It does not change the historical dates of the original exposition. All results below are established mathematics. The derivative/series lemmas use real calculus and uniform convergence, not Cauchy's theorem, so using them earlier in the chapter does not create circular reasoning.

### A.1 What is assumed, and the complex calculus rules

The base prerequisites are the ordered complete real field, elementary plane geometry, real trigonometry, the real exponential and logarithm with their elementary derivative and inverse properties, real one-variable differentiation and the fundamental theorem of calculus for continuous integrands, finite-dimensional compactness (closed and bounded sets are compact; continuous functions attain bounds and are uniformly continuous on compact sets), ordinary limits and absolutely convergent series, and finite polynomial identities. We do not reconstruct the real numbers, prove the real FTC or formalize these results in a proof assistant. These are explicit foundational dependencies, not missing proofs of the chapter's complex-analysis theorems.

For complex differentiable f and g at a, write their increments as f'(a)h+o(|h|) and g'(a)h+o(|h|). Addition immediately gives the sum rule. Expanding the product and using continuity makes the extra product of increments o(|h|), giving (fg)'=f'g+fg'. If g(a)≠0, continuity keeps g nonzero nearby and

$$\frac{1/g(a+h)-1/g(a)}h=-\frac{(g(a+h)-g(a))/h}{g(a+h)g(a)}\longrightarrow-\frac{g'(a)}{g(a)^2}.$$

Combining the reciprocal and product rules gives the quotient rule. For composition f∘g, put k=g(a+h)-g(a)=g'(a)h+o(|h|). Then k=O(|h|), so f(g(a)+k)-f(g(a))=f'(g(a))k+o(|k|) implies the chain rule, including cases where k=0 or g'(a)=0. The same estimate for a real differentiable path gives the chain rule used in section 1.3. Induction gives the polynomial power rule; the reciprocal rule gives negative integer powers away from zero.

### A.2 The Cauchy–Riemann sufficient condition

Let u and v have continuous first partial derivatives on a real neighborhood of a=(x,y). For a sufficiently small increment (h,k), two coordinate segments stay in that neighborhood. Apply the one-variable real FTC on each segment:

$$u(x+h,y+k)-u(x,y)=\int_0^h u_x(x+s,y+k)ds+\int_0^k u_y(x,y+t)dt.$$

Subtract u_x(a)h+u_y(a)k. Continuity bounds the remaining magnitude by ε(|h|+|k|)≤√2 ε√(h²+k²) when the increment is small. The identical argument applies to v. If u_x(a)=v_y(a) and u_y(a)=−v_x(a), the combined linear term is

$$[u_x(a)+iv_x(a)](h+ik).$$

Dividing by h+ik proves the complex derivative at a is u_x(a)+iv_x(a). If the equations hold at every point of an open set with these continuous partials, the function is holomorphic there. Equations at just one point without real differentiability do not suffice; section 1.1 supplies a continuous counterexample.

### A.3 General power-series differentiation and shifted series

Suppose a power series Σ a_n(z−c)^n converges at w with R=|w−c|>0. Its terms there are bounded, so there is M such that |a_n|R^n≤M for every n. For each 0<r<R, the terms on |z−c|≤r are bounded by M(r/R)^n. For each fixed derivative order k, their k-th formal derivatives are bounded by M R^(−k)n(n−1)…(n−k+1)(r/R)^(n−k) for n≥k. The ratio tends to r/R<1, so both the original and derivative series converge uniformly on that disk. A uniform limit of continuous functions is continuous: at a point, bound the difference by two uniform approximation errors plus the continuity error of one fixed approximant.

For the partial polynomials p_N, real FTC on a segment says p_N(z+h)−p_N(z)=h∫₀¹p_N'(z+th)dt. Uniform convergence permits passage to the limit, since the integral of the error is bounded by its supremum. Dividing by h and using continuity of the derivative-series limit proves that it is the complex derivative. Induction proves every fixed higher-order assertion. At any interior point choose a positive r leaving room for the segment. This argument requires no contour theorem or presumed analyticity.

In particular, after finitely many initial coefficients vanish, dividing a convergent series by (z−c)^j simply shifts its remaining coefficients and leaves positive local convergence radius; the same bounds prove holomorphy of the shifted series. This supplies the quotient and factorization facts used in sections 6 and 7. No convergence on the boundary |z−c|=R is inferred.

### A.4 Complex exponential, kernel and logarithm prerequisites

Define E(z)=Σ z^n/n!. On |z|≤R the absolute terms have eventual ratio at most R/(n+1), so convergence is uniform on every fixed disk. A.3 gives E'=E and E(0)=1. Absolute convergence justifies grouping the double series for E(z)E(w): its degree-n coefficient is Σ z^k w^(n−k)/(k!(n−k)!)=(z+w)^n/n!, by the binomial identity. Thus E(z+w)=E(z)E(w). In particular E(z)E(−z)=1, so E never vanishes.

On the real line E agrees with the usual real exponential: the derivative of e^(−x)E(x) is zero and its value at zero is one. Put c(t)=Re E(it), s(t)=Im E(it). Differentiation gives c'=−s, s'=c, c(0)=1 and s(0)=0. They agree with the elementary real cosine and sine. One direct uniqueness check is to subtract the sine/cosine solutions: if differences u,v satisfy u'=−v, v'=u and vanish initially, then (u²+v²)'=0, forcing u=v=0. Hence E(x+iy)=e^x(cos y+i sin y).

The elementary real trigonometric facts cos²y+sin²y=1 and (cos y,sin y)=(1,0) exactly for y∈2πZ imply |E(x+iy)|=e^x and E(z)=1 exactly for z∈2πiZ. Those real trigonometric facts and the existence of a polar angle for a nonzero plane vector are explicitly part of the base prerequisites. For b≠0 choose its polar representation b=ρ(cos θ+i sin θ); then ℓ=log ρ+iθ satisfies E(ℓ)=b. This is a logarithm of one number, not a continuous logarithm on the punctured plane.

Define complex sine and cosine by sin z=(E(iz)−E(−iz))/(2i) and cos z=(E(iz)+E(−iz))/2. The calculus rules and E'=E prove that both are entire, with derivatives cos z and −sin z respectively. Euler's formula gives agreement with the real trigonometric functions. Also sin z=0 exactly when E(2iz)=1, equivalently z∈πZ; this supplies the sine facts used in Exercise 7.

These facts justify every exponential antiderivative, circle parametrization, sine identity and integer-winding step used above without presupposing the chapter's Cauchy or Taylor theorems.

### A.5 A smooth real function need not equal its Taylor series

Define φ(t)=e^(−1/t²) for t≠0 and φ(0)=0. For every nonnegative integer m, |t|^(−m)e^(−1/t²)→0: put s=1/t² and choose an integer j>m/2; the exponential series gives e^s≥s^j/j!, so s^(m/2)e^(−s)≤j!s^(m/2−j)→0.

Away from zero, repeated differentiation gives φ^(n)(t)=P_n(1/t)e^(−1/t²) for a polynomial P_n. The induction step follows by the ordinary chain/product rules. Each such expression tends to zero at zero by the bound just proved. To prove differentiability there as well, divide the n-th expression, extended by zero, by t: it is another polynomial in 1/t times e^(−1/t²), again tending to zero. Induction therefore proves φ is infinitely differentiable and φ^(n)(0)=0 for every n. Its Taylor series at zero is identically zero, but φ(t)>0 when t≠0. This establishes the contrast invoked in section 5.2.

### A.6 Review boundary and reference cross-checks

The matrix accompanying this revision distinguishes unchanged valid proofs, clarified hypotheses, supplied subsidiary arguments and intentionally assumed real-analysis foundations. No counterexample to a central theorem or incorrect numerical exercise answer was found in this chapter. This conclusion is an explicit mathematical review, not an infallibility guarantee or a new theorem.

The two existing MIT reference notes were reopened for their stated contour and derivative formulas. The university-hosted [Dmitri Zaitsev complex-analysis notes](https://www.maths.tcd.ie/~zaitsev/23204-2022/ca-notes.pdf), especially sections 12.2–12.3, 13.2 and 16.4, provide independent reference statements for the triangle, primitive, residue and power-series framework. These references support cross-checks; the arguments in this chapter are the actual proofs being audited, rather than substitutes for missing reasoning.
