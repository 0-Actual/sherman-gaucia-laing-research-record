# Mathematical bridges

The eight explanations retain the assumptions, known results, measured outcomes and limits of the reviewed work. No new numerical run was performed for this edition.

## MATH-01 — State amplitudes → factored representations → bounded simulation

**Dates:** Dense observations: September 18, 2026. Structured implementation date is not established by its later preserved-copy date.

**Classification:** established representation identity; implementation strategy; bounded empirical capacity

**Starting math:** A pure n-qubit state is a unit vector in C^(2^n): psi = sum_x a_x |x>, with sum_x |a_x|² = 1.; The same amplitudes can sometimes be factored: SOP psi = sum_(b=1)^B c_b tensor_(j=1)^n v_(b,j); MPS a_(x1...xn) = A1[x1] A2[x2] ... An[xn].

**Transformation:** Replace an explicit amplitude array with factors when the state/circuit permits small branch count B or bond dimension chi.; For two Float64 arrays, dense state storage is 16·2^n bytes. Factor storage can scale as O(Bn) or O(n·chi²), but B or chi can grow with entanglement and circuit structure. This is a representation change, not a proof that arbitrary states become cheap.

**Retained result:** Dense sizes 1–21 completed in 25 trials. At 21, 2,097,152 complex amplitudes occupy 33,554,432 state bytes; three validation times have median 766.6211 ms.; The structured source provides product/GHZ paths with SOP branch cap 64, bridge MPS bond cap 32 and local QR omission threshold 1e-13. This source selection establishes implementation, not every historical 60-qubit timing claim.

**Teaching example:** GHZ_n = (|0...0> + |1...1>)/sqrt(2) has a two-term SOP and a bond-dimension-two MPS for n>=2, although its dense vector has 2^n entries. This standard example explains the compact representation; it is not a newly executed trial.

**Negative or boundary:** Dense 22 was not admitted: free memory was below state-plus-reserve requirement. SOP overflow and MPS rank overflow refuse a state update. A local QR residual threshold is not a certified global-state error bound. Three amplitude witnesses plus norm are not exhaustive state verification.

**Novelty and proof status:** Tensor factorizations and GHZ structure are established mathematics. The local engineering choices and measured capacity are project evidence. No new representation theorem or physical-qubit result is claimed.

**Project research question:** For the actual supported gates, can a project-specific global error bound and cost model be derived from recorded local omissions and representation growth? This is an unproved project task, not a claim that the subject is new to mathematics.

## MATH-02 — Wannier material blocks → a Hermitian matrix → circuit energy

**Dates:** September 20, 2026 JARVIS pass 01; separately extended September 28.

**Classification:** established Fourier construction; finite-dimensional encoding; verified implementation

**Starting math:** The retained eight-orbital tight-binding input supplies H(R) over 1,041 lattice-vector blocks, with positive block degeneracies d_R.; Construct H(k) = sum_R [H(R)/d_R] exp(2πi R·k), followed by (H+H†)/2. In this source, entries are in eV, original orbital ordering is preserved and Fermi shift is zero.

**Transformation:** Identify the eight orbital basis vectors with the eight computational basis labels of three simulated qubits. This is a dimension-preserving encoding, not a claim about eight physical particles.; A normalized circuit state psi(theta) gives E(theta)=psi†H(k)psi. For Hermitian H, a normalized trial energy is an upper bound on its lowest eigenvalue.

**Retained result:** The saved pass-01 reconstruction differs from its 24-matrix fixture by at most 2.220446049250313e-16 eV.; Ninety circuit/energy cases on 30 matrices passed their fixed criteria; maximum full complex-amplitude difference was 3.7238012298709097e-16 and energy-expectation difference 1.0658141036401503e-14 eV.

**Teaching example:** The translation is “same matrix, new basis labels, a chosen family of trial vectors.” It does not make the material model a full many-electron calculation or imply that a circuit optimizer beats direct diagonalization.

**Negative or boundary:** The input is one material, aluminum JVASP-816. Extra k-points are more cases from that material. Model construction, variational search and conventional reference diagonalization must retain separate roles and timing.

**Novelty and proof status:** Fourier interpolation, Hermitian expectation values and the variational bound are established. The contribution here is source-bound integration and checked calculations, not a new materials theorem.

**Project research question:** Which classes of input matrices justify a circuit representation when accuracy, representation size and total computation are compared with strong classical solvers? New-material and larger-size evidence is not supplied by the current aluminum record.

## MATH-03 — Spectral gap → an energy/fidelity bound → better acceptance rules

**Dates:** September 20, 2026 passes 02–03.

**Classification:** established inequality; acceptance-contract correction; empirical solver improvement

**Starting math:** Let H have ground energy E0 and ground-space projector P0. Let Delta>0 be the gap from that entire ground space to the next distinct eigenvalue.; For normalized psi, F=⟨psi,P0 psi⟩. Spectral expansion gives E-E0 >= Delta·(1-F), hence 1-F <= (E-E0)/Delta.

**Transformation:** An energy criterion is not automatically a state criterion. At a tiny gap, the bound may be weak or vacuous even when energy error is small.; Evaluate energy, ground-space fidelity, norm, residual and circuit agreement separately. For degeneracy, compare with the whole ground subspace rather than one arbitrarily chosen eigenvector.

**Retained result:** At gap 1e-6 eV, energy error 5.61226507949274e-8 eV passed the energy target but fidelity 0.9438801949621364 missed 0.9999. At gap 1e-8 eV, fidelity was 0.7237052008836223 despite energy and gradient acceptance.; The 720-case study had baseline full acceptance 424, first repair 681 and bracketed revision 720. Removing the identified already-solved seed-collision control gives 423/719, 680/719 and 719/719; the original counts remain retained.

**Teaching example:** In H=diag(0,Delta), psi=sqrt(F)|0>+sqrt(1-F)|1> has energy Delta·(1-F). If Delta is very small, a state with substantial excited-state weight can still have a very small absolute energy error. This is a pure state and an exact teaching identity, not a new measurement.

**Negative or boundary:** Energy-target successes did not remove two fidelity misses, 39 first-repair acceptance misses, wrong zero-gradient starts or the reused seed. Floating-point gap estimates are not interval certificates; finite acceptance does not prove universal convergence.

**Novelty and proof status:** The spectral inequality is established and follows directly from the eigenbasis expansion. Separating metrics and repairing the target iteration are engineering lessons supported by retained results. No new inequality or quantum advantage is claimed.

**Project research question:** Can certified spectral bounds yield a conservative, computable fidelity certificate for the project’s chosen matrix class? The present diagnostics do not supply that certificate.

## MATH-04 — Overlap penalties → successive variational states → a spectrum

**Dates:** September 28, 2026 original and additional aluminum assessments.

**Classification:** established VQD method; implementation extension; bounded empirical accuracy

**Starting math:** After fitting states psi_0,...,psi_(j-1), use J_j(theta)=⟨psi(theta),H_normalized psi(theta)⟩+beta·sum_(k<j)|⟨psi_k,psi(theta)⟩|².; Equivalently, optimize H_j=H_normalized+beta·sum_(k<j)|psi_k><psi_k|. The implementation uses beta=4 after centering and positive row-sum scaling.

**Transformation:** The rank-one terms penalize returning to earlier fitted states, allowing sequential searches for different low-energy states.; The final reported energy is evaluated against the original H, not the penalized objective. Source passes the penalized matrix directly to refineBFGS; it does not call the classical-target fastRefine path.

**Retained result:** The original path has 24 ordered points × 8 energies = 192 scalar predictions, with MAE 3.4501989767139057e-6 eV and largest scalar error 2.424081433360925e-4 eV.; The separately frozen additional set has another 192 predictions at 24 same-material points, with MAE 1.2888900558943352e-6 eV. These are separate populations, not 384 independent materials.

**Teaching example:** With exact normalized, mutually orthogonal prior eigenstates covering the earlier energy levels, and a sufficiently large positive penalty, those eigenvalues shift upward while the orthogonal eigenstates are unchanged. Approximate fitted states and finite optimization complicate that clean argument; the implementation must therefore check overlaps and residuals.

**Negative or boundary:** The original run had 187/384 starts hit the iteration limit; the additional run had 239/384. The conventional control was faster and more accurate on the original small problem. Previously seen references prevent a blind-test claim. No official rank or matched public-Qiskit runtime comparison was established.

**Novelty and proof status:** The source explicitly credits Higgott, Wang and Brierley’s variational quantum deflation method. This is a local implementation and assessment, not a claim that VQD was invented here. A new contribution would require its own precisely stated and independently assessed result.

**Project research question:** How should penalty choice, ansatz restrictions and near-degeneracy be combined with rigorous or empirical stopping criteria? Current low mean error does not settle full eigenstate convergence.

## MATH-05 — The chain rule and reversible gates → adjoint gradients → less repeated work

**Dates:** September 20 adjoint work. Later benchmark receipts: September 29 UTC at 02:12:31.070 (negative first version), 02:20:03.206 (selected v4) and 02:45:43.686 (audit), all September 28 Eastern. These are receipt times, not interchangeable run start/end times.

**Classification:** established derivative method; implementation optimization; empirical performance improvement

**Starting math:** For real parameters theta, psi(theta)=U(theta)|0> and a parameter-independent Hermitian H, dE/dtheta_j=2 Re⟨dpsi/dtheta_j,H psi⟩.; A backward sweep moves states and the adjoint vector through inverse unitary gates, evaluating each parameter derivative without separately preparing a shifted state for every parameter. For the retained RY/RZ gates, the code also supplies the standard ±π/2 parameter-shift comparison.

**Transformation:** Reuse intermediate state vectors and reverse gate operations instead of repeated whole-circuit evaluations. A constant number of state vectors with respect to parameter traversal is still exponential storage in qubit count for a dense representation.; The later implementation calculates sin(theta_j/2) and cos(theta_j/2) once per new parameter vector, changes the sine sign for inverse rotation, and removes unused optimizer-history retention. It keeps the same circuit, BFGS update arithmetic, seeds and stopping budgets.

**Retained result:** The adjoint receipt has 64 angle sets, 512 state-comparison evaluations and 1,152 derivative-component checks; maximum parameter-shift discrepancy is 1.7763568394002505e-15.; Two four-process old/new/new/old batches of the 24-point/192-energy VQD workload reduced median calculation time by 17.142% and 13.344%, with exact fitted outputs within each batch. These are the combined implementation changes, not a measured isolation of each change’s individual contribution.

**Teaching example:** A repeated trigonometric value can be reused without changing its mathematical meaning. That does not imply every memory-saving rewrite is faster: the retained first allocation rewrite was 52.1% slower despite lower process memory.

**Negative or boundary:** Both accepted batches missed their 20% time target; two intermediate probes also remained slower. Timings exclude startup and concern a particular process workload, not Windows globally. Saved-answer cache reuse is another operation and must not be counted as fresh optimization speed.

**Novelty and proof status:** The adjoint source credits Jones and Gacon’s published method. Trigonometric reuse and unused-history removal are implementation optimizations. The exact local measured gains are empirical evidence; no new derivative identity or universal speedup is asserted.

**Project research question:** A future controlled decomposition could estimate which change helps under which workload and runtime. That is a project experiment to design, not evidence already present or a novelty claim.

## MATH-06 — Scale invariance and projective geometry → robust normalization and distance

**Dates:** September 4–5, 2026 report/package interval; the precision-results file has no execution timestamp.

**Classification:** established identities; numerical reformulation; verified boundary correction

**Starting math:** For any nonzero vector z and any positive scale s, z/||z|| = (z/s)/||z/s|| in exact arithmetic.; For normalized a,b, the ray distance sqrt(1-|a†b|²) equals the norm of b projected perpendicular to a. For nonzero a,b, r=b-a(a†b)/(a†a) and ||r||/||b|| expresses the same scale-invariant geometry.

**Transformation:** Choose s as the largest absolute real or imaginary component, scale those components separately, then normalize the bounded vector. Avoid forming an overflowing or underflowing original norm.; Compute the projection residual and its robust norm instead of subtracting a near-one fidelity from one. This changes finite-precision behavior while preserving the intended exact formula.

**Retained result:** The parent failed 13 of 22 new precision methods. The successor passed all 22 plus 108 inherited and 12 earlier boundary methods: 142 methods in those suites.; Saved examples correct rejection of [1e300,1e300] and [1e-300,1e-300], remove a roughly 2.10734e-8 spurious self-distance, and preserve structured basis perturbations of 1e-12 and 1e-300 that the parent rounded to zero.

**Teaching example:** Two algebraically equivalent expressions can have different intermediate magnitudes. The lesson is to preserve the invariant in a representable range, not to claim that ordinary floating-point arithmetic becomes arbitrary precision.

**Negative or boundary:** Tiny components relative to enormous ones can still disappear. General near-collinear vectors incur projection/representation error; special basis examples at 1e-300 do not prove universal sensitivity. A direct raw squared-distance result can still overflow and must be rejected.

**Novelty and proof status:** The scale and projection identities are established mathematics. The contribution is the explicit correction, counterexamples and preservation of earlier behavior. Novelty of a new numerical method has not been assessed.

**Project research question:** Can the implementation receive a useful forward/backward error analysis over its declared input domain, including subnormal components and nearly collinear states? The present tests are evidence, not a full error theorem.

## MATH-07 — An affine quantum channel → fixed-point algebra → stable convex weights

**Dates:** C002 standalone successor; result receipt timestamp is September 5, 2026, 00:56:01.683802 UTC (September 4 Eastern). This identifies the receipt, not the first historical occurrence of the equation.

**Classification:** established affine fixed-point derivation; numerical correction; bounded reference implementation

**Starting math:** D_p(rho)=(1-p)rho+pI/2 and C_eta(rho)=(1-eta)rho+eta tau, with p,eta in [0,1] and a fixed valid qubit density tau.; Applying C_eta after D_p gives F(rho)=a rho+bI/2+c tau, where a=(1-eta)(1-p), b=(1-eta)p, c=eta and a+b+c=1.

**Transformation:** For p or eta positive, a<1 and rho*=(bI/2+c tau)/(b+c). At p=eta=0 the channel is identity and every density is fixed.; Use s=max(p,eta), u=(p/s)(1-eta), v=eta/s, then rho*=(uI/2+v tau)/(u+v). Scale before multiplication and avoid subtracting a from one. Differences contract by a in exact arithmetic.

**Retained result:** Thirteen saved methods passed, including a 760-digit Decimal reference over ten difficult parameter pairs, 72 channel-invariance subcases and 100 seeded density subcases. The subcases are not added as independent test methods.; With both probabilities equal to the smallest positive binary64 subnormal and tau=|0><0|, the fixed-point diagonal rounds to (0.75,0.25) in binary64. In exact arithmetic, for their common positive value q, it is (3/4 + q/(8-4q), 1/4 - q/(8-4q)); the correction is nonzero.

**Teaching example:** Very small p or eta still gives a unique fixed point, but a≈1 means slow contraction. One floating-point update may round to the identity. Existence, convergence rate and numerical visibility are different questions.

**Negative or boundary:** The original threshold 1-a<=1e-10 incorrectly rejected some mathematically unique channels. The new file is a standalone successor, not recovery of the full 662-line historical module. Target replacement is a specified channel, not cost-free thermodynamic entropy reduction.

**Novelty and proof status:** The fixed-point derivation is elementary affine algebra under explicit density/channel assumptions. The numerical correction and boundary checks are supported; no new physical law or globally novel theorem is claimed.

**Project research question:** What finite-precision convergence/stopping guarantee can be proved for repeated channel application when parameters are tiny? The fixed-point formula alone does not provide a rapid iterative algorithm.

## MATH-08 — Boolean clause violations → diagonal energy → product-state expectation

**Dates:** Documentary Study 003 row: September 19, 2026, 06:03 UTC. Contract row: 04:53 UTC.

**Classification:** established representation identity; documentary historical bridge; original implementation/proof unavailable; novelty unassessed

**Starting math:** For Boolean assignment x, let v_C(x)=1 if clause C is unsatisfied and 0 otherwise. Then E(x)=sum_C v_C(x).; Define the diagonal operator H=sum_x E(x)|x><x|. Its zero-energy computational basis states are exactly the satisfying assignments. This statement is a representation equivalence, not a search algorithm.

**Transformation:** For a product state with independent bit probabilities p_j, ⟨H⟩=sum_C Pr(C unsatisfied). For a canonical clause with distinct, consistent literals, that probability is the product of the appropriate p_j or (1-p_j) factors.; Repeated copies of a literal refer to the same random variable and must not be multiplied as independent events. A clause containing x and not-x is a tautology with zero violation. The empty clause has violation one.

**Retained result:** The prior-work summary reports 384 formulas, 4,096 assignments and 4,608 expectation checks, followed by a repeated-literal correction. These are inherited reported populations, not newly inspected raw executions.; No actual original Study 003 code or complete proof ledger has been inspected in this bounded map. The equations here are a fresh editorial explanation of the standard identity, not reconstructed historical source.

**Teaching example:** For clause (x OR x), the unsatisfied probability is 1-p, not (1-p)^2. Boolean idempotence exposes why canonicalization matters. For (x OR NOT x), the probability is zero, not p(1-p). These examples explain the correction class without claiming to reproduce the missing source bug line.

**Negative or boundary:** The explicit diagonal has 2^n entries if materialized. A compact clause formula or a continuous expected-energy objective does not establish efficient global minimization, rounding to a satisfying assignment, an UNSAT certificate or a worst-case polynomial solver. Local minima and precision/readout costs must remain separate obligations.

**Novelty and proof status:** The Boolean/diagonal-energy expectation identity is standard. The reported study may contain project-specific work, but complete original artifacts and a proof/novelty assessment are unavailable here. The conditional resource bound remains unproved; no solution to P versus NP is claimed.

**Project research question:** Recover the original code, repeated-literal correction, full proof obligations and counterexamples before assessing any stronger algorithmic claim. A new theorem would require a precise statement, assumptions and proof with bit-cost and certificate analysis.
