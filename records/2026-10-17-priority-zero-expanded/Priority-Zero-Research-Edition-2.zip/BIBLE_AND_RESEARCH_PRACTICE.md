# Biblical study and accountable research practice

Quantum.Earth.Laing places Biblical study alongside truthfulness, stewardship, peace and human responsibility. The research practice is to name the source, declare the transformation, test the stated behavior and preserve errors with their corrections. A passing calculation does not establish a theological interpretation.

The Bible arithmetic companion replays declared text and profiles from six selected studies. It checks the retained calculations, not the original conversation or a claim of newly discovered mathematics.

The Hebrew H04.1 converter addresses an interruption window in which replacing a file could succeed before rollback bookkeeping recorded it. The earlier audit examined 306,785 selected records across 39 books: 305,507 direct verse-word records and 1,278 alternate-reading records. These are record counts, not distinct linguistic words. Forty XML files are supplied; the book count excludes the separate mapping file.

The JSON output does not retain all XML reading-container metadata. The XML remains necessary when those distinctions matter. A Jeremiah amendment changes four attributes on two words; its supporting inference is not upstream maintainer approval. Structural checks and converter tests do not certify every linguistic annotation.

H04 and H04.1 keep separate execution histories. Earlier H04 results are not automatically counted as H04.1 executions. Historical errors are retained as technical lessons, with exact earlier evidence maintained independently.
