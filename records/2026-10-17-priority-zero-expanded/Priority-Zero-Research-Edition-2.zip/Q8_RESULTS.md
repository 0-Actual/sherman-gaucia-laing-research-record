# Q8 and USB: research aim, method and results

The research asks how bounded numerical workloads can run efficiently in a portable software environment while preserving enough inputs and evidence to check the results. Computation uses the host computer's processor and memory. USB storage supplies program and data portability; a separate device-side processor is not demonstrated.

## Model and dimensions

The materials work uses eight-by-eight complex Wannier Hamiltonians for aluminum, represented by three simulated qubits with eighteen adjustable circuit angles. The stage-04 hybrid first calculates a conventional target and then fits a circuit using BFGS and adjoint derivatives. The later full-spectrum VQD assessment uses successive overlap penalties and is a distinct workload.

## Recorded results

| Study | Recorded result | Interpretation |
|---|---|---|
| September 18, 2026 dense H/CX scaling | Sizes 1–21 completed in 25 trials; size 22 was not admitted under the observed memory reserve | Bounded classical simulation; the unexecuted size is not a numerical failure or a proven hardware ceiling |
| Structured SOP/MPS implementation | Selected product/GHZ paths support up to 60 indexed qubits with branch/bond caps | Compact structure, not a dense arbitrary 60-qubit vector; original implementation date and all historical benchmark links remain unresolved |
| September 20, 2026 stage-04 hybrid | Approximately 65.85 times lower aggregate solver time in the specified 24-case, three-repeat comparison | Conventional direct solving remained cheaper; the energy-only baseline missed eighteen timed acceptance cases |
| Stage-04 complete requests | Approximately 4.69 times faster on a separate three-point comparison | Full-request timing differs from solver timing; the two ratios are not interchangeable |
| September 28/29, 2026 VQD revisions | Two saved batches reduced calculation time by 17.1% and 13.3%, retaining fitted outputs | Both missed the 20% target; an earlier allocation revision increased time by about 52% |
| September 29, 2026 host observations | Three windows, eleven counter identities, thirty samples each: 990 readings and 33 means | Recalculation of saved readings is reproducible. Changing background conditions prevent a causal whole-Windows speedup conclusion |

The counter samples precede the associated package-verification operations. They are not simultaneous measurements of computation during those checks. Source integrity checks, installation, numerical execution and scientific validation remain distinct outcomes.

## Limits and remaining work

These are classical software simulations and saved observations, not physical quantum-computer trials. No general quantum advantage, USB-caused acceleration, measured electrical-energy reduction or system-wide Windows improvement is established. Later timing reductions cannot be multiplied with earlier speedup ratios as one cumulative experiment. Further calibration requires a declared model, matched controls, independently specified reference answers and repeated runs under measured conditions.

This edition adds no scientific measurement. Its reproduction material distinguishes checks of saved data from a newly executed optimizer or performance benchmark.
