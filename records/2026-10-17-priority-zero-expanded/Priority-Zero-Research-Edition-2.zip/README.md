# Priority Zero — selected research edition

Revision 2 prepared October 16, 2026 for Sherman G. Laing / Quantum.Earth.Laing. Primary project agent: GAUCIA Actual. Supporting preparation and review: Codex. **Review edition; public release approval is pending.**

This edition presents the research through its objectives, dimensions, assumptions, methods, measurements, corrections and remaining questions. Source conversations and personal circumstances are not included. Earlier drafts remain evidence, while these research explanations have their own identified versions.

Start with the [reader's twenty questions](READER_QUESTIONS.md), [research and funding invitation](RESEARCH_INVITATION.md), [six-period research overview](periods/RESEARCH_PERIODS.md), [Q8 results](Q8_RESULTS.md), [early research origins](history/ORIGINS.md), [mathematical bridges](mathematics/BRIDGES.md), [technical mistakes and corrections](learning/CORRECTIONS.md), and [Biblical study and research practice](BIBLE_AND_RESEARCH_PRACTICE.md). The `teaching/` folder supplies 94 overlapping research records and readable lessons. The `process/` folder explains selected development chains and mathematical examples. The `reproduction/` folder supplies selected source, inputs and instructions for bounded checks.

The [complex-analysis manuscript](mathematics/teaching-complex-analysis-proofs.md) and [advanced-mathematics manuscript](mathematics/teaching-advanced-mathematics-frontiers.md) are retained educational reconstructions of established mathematics. All sections, mathematical arguments, examples and exercises in these two selected manuscripts have now received a complete AI-assisted review and cross-review. Supplied proofs, completed derivations, imported theorems and remaining research questions are identified separately. This is not formal proof-assistant verification or outside peer review. See [the correction and proof-review record](SCIENTIFIC_REVIEW.md).

## Evidence and scope

The [proof-review navigation guide](mathematics/REVIEW_GUIDE.md) locates each chapter's coverage, exact errata, imported foundations and preserved earlier versions.

The editorial selection includes twelve early research themes, twenty-four topics across six chronological periods, eight mathematical bridges and forty-five selected technical issue/version groups. These overlap the 94 teaching records and are not counts of separate discoveries or experiments. This selection is not the complete project chronology or every previously prepared manuscript. Wider chronological and manuscript integration remains review work.

Original research dates, later implementations and this edition's preparation date remain distinct. The first-week origin account is included with its uncertainty. Favorable and unfavorable results remain together. No new scientific benchmark, physical quantum-computer run or host-performance measurement was performed for this edition. Verification of package bytes or saved arithmetic does not certify the scientific claims.

Follow the reproduction folder's instructions and limitations. Only the inputs and component versions actually supplied are available for the offered checks. A saved result is not a new execution, a calculated average is not a new observation, and a classical simulation is not quantum hardware.

## Terms and review

The complete [Quantum.Earth.Laing license](LICENSE.md) and [edition-specific scope](LICENSE_SCOPE.md) govern the included project material. Noncommercial research permissions, attribution, peaceful-use terms and the requirement for prior written authorization for other covered uses remain intact. Applicable third-party terms remain attached. See [attribution](ATTRIBUTION.md).

Use `python -B verify_edition.py` to compare the files with the supplied manifest. Only a real top-level `.git` administration directory is outside the file census, permitting the same selection to be used as a local repository. A separately retained original manifest hash is needed to detect replacement of both the package and its manifest. This unsigned integrity check is not a signature or ownership determination.

The [review checklist](REVIEW_CHECKLIST.md) applies to this exact selection. Preparation does not publish it or grant permission beyond the license.
