# Mistakes, boundaries and corrections

The [revision 2 scientific addendum](../SCIENTIFIC_REVIEW.md) records the newly completed numerical corrections, proof review and preparation mistakes. The dated groups below retain their earlier evidence and scope.

Earlier errors and unfavorable results remain part of the research. A missed target, unexecuted stage, unverified claim and reproduced defect retain different labels. These are selected technical groups rather than an exhaustive incident history.

Historical bodies and receipts described as retained or preserved belong to a separate evidence record unless explicitly listed in this edition's manifest. A summary does not supply every original source.

## LESSON-01 — Squared norm called energy in an early dynamics function

Classification: unresolved_or_limited.

Date: Not established. Function inception not established; source captured and observed October 14, 2026.

**Attempt or claim:** The historical dynamics routine names sum(abs(state)**2) energy and selects returned states using energy_threshold.

**Evidence:** There is no Hamiltonian. A nonunitary scaling example gives norm squared four; rejected output states still feed the next gate. The saved bounded observations reproduce these semantics.

**Correction or later version:** Later source review states the actual norm-filter behavior; no silent rewrite of this historical body was made.

**Outcome:** The historical routine is retained in the separate evidence record. Its behavior is conventional array processing; it does not establish physical energy selection.

**Remaining unknowns:** The file inception date and intended original physical contract are not established by the capture date.

## LESSON-02 — Observer naming exceeds the implemented predicate filter

Classification: unresolved_or_limited.

Date: Not established. Undated historical body; October 14, 2026 source observation.

**Attempt or claim:** The produced observer_effect function retains entries satisfying a supplied predicate.

**Evidence:** It preserves order, duplicates and object references; no quantum probability, collapse, renormalization or copied state is implemented.

**Correction or later version:** The documentary review separates implementation from the physical implication of the name.

**Outcome:** The historical function is retained in the separate evidence record. This is a semantic limit, not a claim that list filtering malfunctioned.

**Remaining unknowns:** No missing measurement mechanism is invented.

## LESSON-03 — Greedy gate placement rejected valid plateau-crossing solutions

Classification: confirmed_defect.

Date: 2026-08-21. Generation A integration correction cycle; no exact first-failure timestamp.

**Attempt or claim:** The first placer required each individual chosen gate to improve target fidelity.

**Evidence:** |00> to |11> needs two X gates; either first gate alone leaves target fidelity zero, so the one-step rule rejected a valid sequence.

**Correction or later version:** Deterministic bounded beam look-ahead over unused validated unitary candidates replaced greedy acceptance; regression test_adaptive_gate_placement added.

**Outcome:** Correction receipt states corrected and retested. This is bounded search, not universal optimizer completeness.

**Remaining unknowns:** Exact first greedy body is not separately identified in this selected register; correction receipt and final implementation lineage remain.

## LESSON-04 — Input coercion and receipt canonicalization defects in the integration adapter

Classification: confirmed_defect.

Date: 2026-08-21. Correction cycle; exact occurrence times not in the receipts.

**Attempt or claim:** Some qubit/depth paths coerced booleans or fractions with int(), and array/complex receipt conversion could reintroduce raw floats. The manifest still called the corrected search greedy.

**Evidence:** The correction receipt identifies prepare_uniform_state, max_depth, measurement, gate expansion, controlled-phase type checks, recursive canonicalization and stale naming.

**Correction or later version:** Strict integer validation and recursive decimal-string canonicalization were applied; the manifest name became bounded_lookahead_adaptive_gate_placement.

**Outcome:** Final receipt reports 59 adapter/kernel plus 87 preserved B-D behavioral methods, 146 total within those two suites.

**Remaining unknowns:** These reconstructed B-D behavior checks do not recover the missing exact original B-D source.

## LESSON-05 — Mean-square amplitude rescaling was incorrectly associated with coherence

Classification: confirmed_defect.

Date: 2026-09-04. C001 recheck of an older already-corrected model; not the first discovery date.

**Attempt or claim:** Historical Algorithm 13 divided a vector by sqrt(mean(abs(psi)**2)) as a coherence-preservation operation.

**Evidence:** A unit-norm d-dimensional vector then has norm sqrt(d), giving raw probability sum 8 at three qubits. Global rescaling does not establish coherence preservation.

**Correction or later version:** The reference separates normalization, density-matrix coherence, phase, fidelity and open-system channels. The old operation is deliberately retained as a historical counterexample function.

**Outcome:** This was already known before C001; it is not counted as a newly discovered C001 defect.

**Remaining unknowns:** The exact original historical text-document bytes remain distinct from the clean-room reference.

## LESSON-06 — Algebraically equivalent Ramsey evaluation failed reciprocal scales

Classification: confirmed_defect.

Date: 2026-09-04. C001 checkpoint 20:19 Eastern; September 5 UTC.

**Attempt or claim:** The parent evaluated exp(-0.5*spread*spread*t*t).

**Evidence:** For spread=1e200,t=1e-200 it returned 0 instead of exp(-1/2); reversed scales returned 1; spread=1e200,t=0 produced NaN.

**Correction or later version:** C001 forms spread*t first, preserving the dimensionless product, then squares it.

**Outcome:** The corrected v2.1 parent is preserved. C001 reports 108 inherited and 12 boundary methods passing; seven of the 12 boundary methods exposed parent failures.

**Remaining unknowns:** The pre-C001 v2 body is described by the retained report but is not separately selected in this C002 register; no arbitrary-precision claim.

## LESSON-07 — Finite ratio inputs produced infinite outputs

Classification: confirmed_defect.

Date: 2026-09-04. C001 checkpoint date.

**Attempt or claim:** safe_modulation_ratio and coherence_preservation_ratio checked inputs and denominators but not representability of the quotient.

**Evidence:** 1e308/1e-14 returned positive infinity; the signed function could return negative infinity.

**Correction or later version:** C001 validates the quotient and raises LQCPValidationError rather than fabricating a saturated value.

**Outcome:** Bounded correction passes reported regression/boundary tests, preserving ordinary finite behavior.

**Remaining unknowns:** Tiny valid quotients may still underflow to zero; the correction does not guarantee arbitrary relative accuracy.

## LESSON-08 — Unknown circuit operation was skipped while the API reported PASS

Classification: confirmed_defect.

Date: 2026-09-04. C001 reproduction; isolated Windows candidate checked September 5 UTC.

**Attempt or claim:** executeCircuit validated the configuration but not a separately supplied circuit argument.

**Evidence:** A separate UNKNOWN then MEASURE_Z circuit returned PASS with 10/10 checks; the unknown operation generated zero checks.

**Correction or later version:** A shared per-circuit validator now applies at the actual execution boundary and rejects unknown instructions before execution.

**Outcome:** Sixteen focused methods passed; 13 frozen circuits retained exact bodies and 383 existing engine checks. Later same-device candidate test recorded separately.

**Remaining unknowns:** No evidence says malformed operations occurred in the historical production path, which selected validated configuration circuits; candidate deployment is not inferred.

## LESSON-09 — The corrected v2.1 reference still rejected valid extreme-scale states

Classification: confirmed_defect.

Date: 2026-09-04. C002 began 20:41 Eastern; September 5 UTC.

**Attempt or claim:** v2.1 normalized using a direct Euclidean norm after validation.

**Evidence:** Finite nonzero [1e300,1e300] and [1e-300,1e-300] overflowed/underflowed the direct norm although the normalized direction is ordinary.

**Correction or later version:** v2.2 scales by the largest absolute real/imaginary component, divides components separately, then normalizes the bounded vector.

**Outcome:** Parent fails 13 of 22 new precision methods; candidate passes all 22 plus 108 inherited and 12 earlier methods, 142 total. Full parent retained as E03.

**Remaining unknowns:** Extreme relative components can still round to zero; no recovery of information outside the chosen numeric format.

## LESSON-10 — Near-one fidelity subtraction lost tiny distances or invented self-distance

Classification: confirmed_defect.

Date: 2026-09-04. C002 cycle, September 5 UTC execution receipts.

**Attempt or claim:** v2.1 evaluated sqrt(max(0,1-fidelity)).

**Evidence:** It reported about 2.1073424255447017e-8 self-distance for [1+2j,3-4j], while structured perturbations 1e-12 and 1e-300 vanished to zero.

**Correction or later version:** v2.2 uses a projection residual and robust norm rather than subtracting nearly equal scalars.

**Outcome:** Saved focused examples yield zero self-distance and retain the structured perturbations.

**Remaining unknowns:** This does not establish sensitivity to arbitrary 1e-300 changes in general nearly collinear floating-point vectors.

## LESSON-11 — Three-qubit normalization accepted zero output after overflow

Classification: confirmed_defect.

Date: 2026-09-04. C002 source-text reconstruction/correction; historical body inception unresolved.

**Attempt or claim:** The reconstructed validator rejected norm<=tol but did not reject an infinite norm before division; lifted reduction also used a direct norm.

**Evidence:** Huge finite input divided by infinity became a zero vector, and lifted reduction could yield a zero-trace density. Invalid NaN tolerance could permit zero-vector division.

**Correction or later version:** Scaled normalization was applied to both paths with explicit tolerance validation and preserved core/lifted cutoff differences.

**Outcome:** 22 focused methods pass; 504 inherited numeric leaves differ by at most 2.53681827024348e-14 against 1e-12. Reconstructed parent retained as E04.

**Remaining unknowns:** Original exact 16,249-byte object remains unrecovered; results apply to 16,248-byte recovered text.

## LESSON-12 — Entropy uniqueness test confused numerical threshold with mathematical existence

Classification: confirmed_defect.

Date: 2026-09-04. C002 review and September 5 UTC successor receipt.

**Attempt or claim:** The historical excerpt rejected 1-(1-eta)*(1-p)<=1e-10 as no unique fixed point.

**Evidence:** For p=1e-20,eta=0 the exact fixed point is I/2; for p=0,eta=1e-20 it is tau. Only p=eta=0 is nonunique. Near-one subtraction and unscaled products were numerically fragile.

**Correction or later version:** A standalone reference uses scaled convex weights proportional to p*(1-eta) and eta and rejects only exact double zero.

**Outcome:** 13 methods passed with a 760-digit oracle over ten difficult pairs and separate invariance/generated-density subcases.

**Remaining unknowns:** The full original 662-line entropy module is not recovered here. Uniqueness is not a claim of fast convergence or thermodynamic benefit.

## LESSON-13 — Exact three-qubit source recovery was incomplete by one byte

Classification: unresolved_or_limited.

Date: 2026-09-05. C002 provenance receipt, not historical body date.

**Attempt or claim:** Raw-byte retrieval failed; authenticated source-text reading produced 16,248 bytes against metadata reporting 16,249.

**Evidence:** The receipt retains TEXT_RECONSTRUCTION_NOT_BYTE_VERIFIED and did not guess the missing byte.

**Correction or later version:** The parent is explicitly named a source-text reconstruction; candidate corrections and identity changes bind to that text only.

**Outcome:** Exact recovered-text exhibit preserved with the same limitation, not promoted into the missing original.

**Remaining unknowns:** Original byte discrepancy remains unresolved.

## LESSON-14 — WF019 direct calls falsely accepted five invalid-input cases

Classification: confirmed_defect.

Date: 2026-09-18. Paired replay window 22:46:43.581–22:46:44.781 UTC; defect originally known earlier.

**Attempt or claim:** The direct function returned passed:true for text time, fractional time, excessive time, Infinity and a state omitted from the allowed set.

**Evidence:** Five fixed paired examples went from five false successes to zero via the existing guard. They overlap the broader 16-case rejection suite.

**Correction or later version:** Guard admission validates the input contract; 36 valid samples retained the same outputs and 252 internal checks.

**Outcome:** Known regression correction confirmed on the guarded path, not 100% improvement in the entire project.

**Remaining unknowns:** Direct callers can still bypass the separate guard; deployment-wide enforcement is not established.

## LESSON-15 — Expanded verification was not numerical improvement or model training

Classification: unresolved_or_limited.

Date: 2026-09-18. Saved improvement-audit date.

**Attempt or claim:** A broad improvement account risked treating more checks as improved numerical accuracy or training of the underlying modules.

**Evidence:** The 24 matched energies are identical with the same error: 0% accuracy reduction in that subset. Seven source files remain byte-equal over 49 comparisons across eight scientific checkpoints.

**Correction or later version:** The audit separates expanded coverage from changed algorithms, accuracy and overall assistant reliability.

**Outcome:** It reports narrower admission gains while retaining zero matched accuracy gain and no measured project-wide error-rate improvement.

**Remaining unknowns:** No whole-project reliability denominator exists; this is correction of the inference, not evidence that every aspect improved by zero.

## LESSON-16 — Paired replay staging failed before any scored cases

Classification: confirmed_defect.

Date: 2026-09-18. Audit date; separate exact tool times not asserted here.

**Attempt or claim:** Nested shell expansion damaged a help filter; script policy blocked a launcher; the first VM harness omitted initializeImportMeta.

**Evidence:** The first two were setup failures before Node. The VM error occurred before cases because import.meta.url was undefined. The proposed PowerShell watchdog never ran.

**Correction or later version:** Direct Node invocation and an additive run_02 harness with module.identifier metadata corrected the path; policies and original numerical code stayed unchanged.

**Outcome:** Original harness, corrected harness and failure receipts all remain preserved; no nonexistent numerical result is counted.

**Remaining unknowns:** A pre-execution wrapper does not prove its unexecuted watchdog or resource behavior.

## LESSON-17 — Dense scaling attempt 01 was stopped before any circuit

Classification: not_executed.

Date: 2026-09-18. Attempt day; exact saved timing is in its result object.

**Attempt or claim:** The first dense scaling parent tried to admit a ladder under a 256 MiB reserve plus launch allowance.

**Evidence:** It observed 269,041,664 free bytes, below the parent threshold. No circuit ran.

**Correction or later version:** Later attempts revised orchestration and retained the reserve; the empty first numerical stage was not credited.

**Outcome:** Attempt 01 code and result are preserved.

**Remaining unknowns:** Not evidence of a numerical defect or hard machine-capacity limit.

## LESSON-18 — Dense-state memory admission counted runtime reserve twice

Classification: confirmed_defect.

Date: 2026-09-18. Attempts 02 and 03 in the same cycle.

**Attempt or claim:** The child admission rule reserved runtime memory after runtime/kernel memory was already reflected in measured free RAM.

**Evidence:** The later report identifies duplicate reserve accounting. Attempt 02 passed sizes 1–13, then the parent stopped before 14 at 334,376,960 free bytes versus 335,806,464 required.

**Correction or later version:** The accounting correction and lower-overhead scheduling enabled continuation under the retained memory-reserve policy.

**Outcome:** Attempt 03 continued 14–21. The parent stop and later success are retained as different orchestration states.

**Remaining unknowns:** Memory snapshots vary with other activity; this is not proof of an intrinsic increase in hardware capacity.

## LESSON-19 — The dense 22-qubit trial never ran

Classification: not_executed.

Date: 2026-09-18T23:40:17.343Z. Final admission measurement UTC.

**Attempt or claim:** After three successful 21-qubit trials, the driver evaluated admission for 22.

**Evidence:** Required free memory was 335,544,320 bytes including reserve; observed 322,658,304 was short by 12,886,016 bytes.

**Correction or later version:** The result correctly remains admission stopped, not numerical failure. Dense maximum demonstrated in this ladder remains 21.

**Outcome:** Twenty-five completed trials across sizes 1–21 and one stopped child are separate units; no 22-qubit execution is credited.

**Remaining unknowns:** A different load/policy could admit another size, but no such new run is asserted.

## LESSON-20 — JARVIS first variational pass missed one of six energy targets

Classification: failed_target.

Date: 2026-09-20. Day stated in original report; first run has separate timestamps.

**Attempt or claim:** Two seeded starts and at most 12 coordinate sweeps attempted six ground-energy cases using the unchanged 18-angle circuit.

**Evidence:** Original point 4 ended 0.0004007142024144983 eV above reference versus a <=0.0001 eV goal; five of six passed.

**Correction or later version:** Two explicitly adaptive budget increases followed, then coupled BFGS in pass 02.

**Outcome:** Original failed point and all other successes remain; no all-targets-passed claim for pass 01.

**Remaining unknowns:** The first pass alone did not isolate landscape, expressivity or numerical cause.

## LESSON-21 — The first adaptive follow-up still missed point 4

Classification: failed_target.

Date: 2026-09-20. Same-day bounded follow-up, exact time not repeated here.

**Attempt or claim:** Four starts and 64 sweeps revisited the already examined original point.

**Evidence:** Energy gap improved to 0.00014289359835650828 eV but exceeded unchanged 0.0001 eV target.

**Correction or later version:** A separately declared 256-sweep follow-up followed.

**Outcome:** Improvement is retained without reclassifying the miss as a pass or a fresh held-out test.

**Remaining unknowns:** This follow-up was run once; no independent deterministic replay is claimed.

## LESSON-22 — The second adaptive follow-up remained above goal

Classification: failed_target.

Date: 2026-09-20. Same-day second bounded follow-up.

**Attempt or claim:** Four starts and 256 sweeps revisited point 4.

**Evidence:** Final gap 0.00012074495903213744 eV remained above 0.0001 despite a 69.8676% reduction from the initial gap.

**Correction or later version:** Pass 02 applied coupled BFGS after coordinate warmup, preserving circuit and 18 parameters.

**Outcome:** All four saved warm-start refinements and a cold seeded point-4 check reached the target in the later pass. The 256-sweep miss remains unchanged.

**Remaining unknowns:** Adaptive follow-up was not blind or independently replayed; more sweeps alone did not establish convergence.

## LESSON-23 — Energy accuracy hid two synthetic fidelity misses

Classification: failed_target.

Date: 2026-09-20. Pass 02 report and stress receipts.

**Attempt or claim:** Pass 02 evaluated six representable known-spectrum synthetic states with energy and fidelity requirements.

**Evidence:** At gap 1e-6 eV, energy error 5.61226507949274e-8 passed but fidelity 0.9438801949621364 missed 0.9999. At gap 1e-8, energy error 2.762947736350209e-9 passed while fidelity 0.7237052008836223 missed; that case also met gradient tolerance.

**Correction or later version:** State/ground-subspace fidelity became a separate acceptance dimension, followed by the pass-03 target/fit study.

**Outcome:** Four of six fidelity cases passed; the two misses are substantive negative results, not discarded energy successes.

**Remaining unknowns:** Small residual/gradient/energy alone does not identify a unique ground state at a tiny gap.

## LESSON-24 — Passing energy did not mean every BFGS start converged

Classification: unresolved_or_limited.

Date: 2026-09-20. Pass 02 expanded-validation report.

**Attempt or claim:** The 42 ordered cases used two starts each and up to 400 BFGS iterations after warmup.

**Evidence:** Of 84 starts, 33 reached gradient tolerance and 51 exhausted iteration budget. Largest state residual was 0.0008444199310936169 eV despite all 42 energy targets passing.

**Correction or later version:** Report separates stopping reason, energy, state residual and fidelity.

**Outcome:** No claim of universal convergence or 84 successful convergence events is retained.

**Remaining unknowns:** Further convergence at larger budgets is not measured by this receipt.

## LESSON-25 — Pass-02 orchestration reference error occurred before candidate creation

Classification: confirmed_defect.

Date: 2026-09-20. Learning-record day, no exact failed call timestamp.

**Attempt or claim:** One implementation orchestration reference was wrong while preparing candidate.mjs.

**Evidence:** Learning record states the error occurred before the candidate file was written and before numerical execution.

**Correction or later version:** Reference corrected before numerical work.

**Outcome:** Narrative error receipt retained; no failed numerical result or erased test is inferred.

**Remaining unknowns:** Exact failed transient command/source bytes are not independently preserved in this selected record.

## LESSON-26 — Pass-03 baseline and first Rayleigh repair retained many acceptance misses

Classification: failed_target.

Date: 2026-09-20. Final report recorded 21:01:46.962 UTC; individual study times separate.

**Attempt or claim:** A matched 720-case study compared the previous optimizer, first Rayleigh repair and bracketed revision.

**Evidence:** Baseline passed energy 696/720 but full acceptance 424/720. First repair passed energy 720/720 but full acceptance 681/720: 39 failures remained. All 39 fitted their supplied target accurately; target iteration stalled at a distant lower-bound shift.

**Correction or later version:** The revision bracketed the low eigenvalue and used a nearby inverse-iteration shift before fitting.

**Outcome:** Bracketed revision accepted 720/720, gaining 296 over baseline and 39 over first repair with no lost prior pass. One seed-collision control must also be disclosed (T037).

**Remaining unknowns:** Finite, partly shared synthetic populations do not prove universal convergence; bracket is floating-point, not interval certified.

## LESSON-27 — Wrong zero-gradient flat starts were mistaken for useful stopping points

Classification: failed_target.

Date: 2026-09-20. Pass-03 supplemental study.

**Attempt or claim:** Unperturbed circuit fitting began at basis-state flat starts.

**Evidence:** Only 8/64 passed; 56 stopped at zero iterations in wrong states.

**Correction or later version:** Bounded perturbed starts in the conditioned fitter resolved all 64 tested cases.

**Outcome:** The original 56 misses and corrected finite population are retained.

**Remaining unknowns:** This does not establish escape from every stationary point or universal optimizer success.

## LESSON-28 — A reused seed made one supposed test already solved

Classification: confirmed_defect.

Date: 2026-09-20. Final initialization review within pass 03.

**Attempt or claim:** Matrix-family and optimizer seed reuse made one synthetic initial state nearly identical to the target.

**Evidence:** Initial fidelity was 0.9999999999999993 and parameter maximum difference 4.440892098500626e-16. It supplied an already-solved control, not independent difficulty.

**Correction or later version:** Original counts remain. Excluding the identified control gives baseline 423/719, first repair 680/719, revised 719/719 and cold 137/137. Separate seed streams and already-solved-start rejection were introduced.

**Outcome:** A separate confirmation began at fidelity 0.09613601511106884 and reached approximately one in 47 iterations. The improvement counts of 296 and 39 remain unchanged.

**Remaining unknowns:** The new confirmation does not retroactively make the original case independent.

## LESSON-29 — Centering cannot recover input information already rounded away

Classification: unresolved_or_limited.

Date: 2026-09-20. Pass-03 affine diagnostic.

**Attempt or claim:** Affine scale/offset transformations were tested before and after conditioning.

**Evidence:** Conditioned targets passed all 45 represented-matrix cases, but three inputs had already lost information. One intended-state fidelity remained about 0.26515785 even though represented-reference fidelity was approximately one.

**Correction or later version:** The report distinguishes the actually represented matrix from the intended unrounded one; centering/scaling is not described as restoring lost bits.

**Outcome:** All 45 represented-matrix results and the three input-representation limits remain.

**Remaining unknowns:** Recovering the intended input would require additional precision or original information, not another claim of pass.

## LESSON-30 — Hybrid target computation limits discovery and quantum-advantage claims

Classification: unresolved_or_limited.

Date: 2026-09-20. Passes03/04 source and reports.

**Attempt or claim:** The hybrid first calculates a target conventionally, then fits the Q8 circuit.

**Evidence:** Source groundTarget and target-projector fitting provide a classical answer construction inside the pipeline. No external answer file is not the same as no classical target.

**Correction or later version:** Reports explicitly disclose target computation; later VQD uses a different target-free optimization path and must retain separate identity.

**Outcome:** This is an actual algorithmic limitation, not evidence that an unassisted-discovery claim was ever independently verified.

**Remaining unknowns:** No physical QPU, quantum advantage or universal discovery follows from these software comparisons.

## LESSON-31 — Stage-04 energy-only baseline missed 18 runs and direct solving remained cheaper

Classification: failed_target.

Date: 2026-09-20. Recorded timing populations, final report day.

**Attempt or claim:** Five methods were timed on 24 unique cases, with three repetitions each: 72 runs per method.

**Evidence:** Energy-only accepted 54/72. Old and fast hybrid accepted 72/72, but direct mean solver time of 22.815 ms was cheaper than the fast hybrid mean of 111.487 ms; direct complete requests also beat circuit mode.

**Correction or later version:** Retain the 18 misses and direct control beside the 65.85-fold solver and 4.69-fold complete-request improvements.

**Outcome:** No blanket Q8 speedup over the strongest conventional solver is supported.

**Remaining unknowns:** The solver and complete-request populations/timing boundaries differ.

## LESSON-32 — Stage-04 profiling and audit failures remained part of the engineering record

Classification: confirmed_defect.

Date: 2026-09-20. Distinct receipts at 21:58:01.675, 22:01:20.531, 22:01:55.600 and 22:38:06.676 UTC.

**Attempt or claim:** Early profiling attempted fsync under the permission model; another attempt expected a missing CPU-profile file. Adjoint validation hit Resume required; first final audit had a worker failure.

**Evidence:** Exact failure receipts remain. The missing trace followed a successful numerical worker and is not a failed numerical answer.

**Correction or later version:** Durable writes moved to the supervisor, unsupported trace capture gave way to stage timing, resume/permission-boundary recording was corrected and later audit passed.

**Outcome:** No failed attempt is erased. Aggregate successful-job counts are not summed with these receipt identities as unique numerical studies.

**Remaining unknowns:** Final-audit generic error alone does not establish a numerical cause; source readback and later successful audit supply the limited closure.

## LESSON-33 — VQD staging adapter failed before numerical work

Classification: confirmed_defect.

Date: 2026-09-28. Eastern date in setup-attempts receipt.

**Attempt or claim:** The first adapter recursively linked cached VM modules.

**Evidence:** Node raised ERR_VM_MODULE_LINK_FAILURE before a numerical pilot or run output folder.

**Correction or later version:** Nine reviewed modules are instantiated first; Node links the fixed allowlisted root graph once.

**Outcome:** Pilot, classical control and full 192-value VQD run later completed. The original adapter version and corrected adapter are preserved.

**Remaining unknowns:** Module loading failure is not a failed scientific prediction.

## LESSON-34 — First VQD scorer needed explicit schema and count hardening

Classification: unresolved_or_limited.

Date: 2026-09-28. Later audit after initial scores; exact first edit time not supplied.

**Attempt or claim:** The first scoring route did not carry the later explicit material, units, mode and receipt-count checks.

**Evidence:** Setup-attempts receipt records the added validation; scoring arithmetic remained unchanged.

**Correction or later version:** The hardened scorer rejects 11 malformed cases and reproduces the saved score arithmetic.

**Outcome:** The first produced scores are retained, not replaced with revised predictions. This is validation hardening, not proof original numeric scores were wrong.

**Remaining unknowns:** Exact earliest scorer body is not separately identified in this selection.

## LESSON-35 — Low original-path VQD average error concealed unconverged states

Classification: unresolved_or_limited.

Date: 2026-09-28. Approximately 21:20 Eastern assessment.

**Attempt or claim:** One full run fitted 192 states from 384 starts on 24 ordered aluminum path points.

**Evidence:** MAE 3.4501989767139057e-6 eV passed the local goal, but maximum error 0.0002424081433360925 eV and largest residual 0.005244191334342701 eV remained. Of 384 starts, 197 reached gradient tolerance and 187 hit the iteration limit. Two points contributed 94.93% of total absolute error.

**Correction or later version:** Report retains residuals/stopping reasons and distinguishes local comparison from official rank or blind test.

**Outcome:** The conventional solver remained both faster (0.911 s versus 20.582 s) and more accurate. No matched timing comparison against the public Qiskit implementation ran.

**Remaining unknowns:** Wavefunction convergence, new materials, physical advantage and commercial value are not established.

## LESSON-36 — Additional aluminum cases retained substantial iteration-budget stops

Classification: unresolved_or_limited.

Date: 2026-09-28. Approximately 21:28 Eastern separate assessment.

**Attempt or claim:** The unchanged VQD method predicted 192 energies at 24 additional same-material points.

**Evidence:** MAE 1.2888900558943352e-6 eV and maximum error 4.240288216550425e-5 eV passed local goals, but largest residual 0.009607193267454683 eV remained. Of 384 starts, 145 met gradient tolerance and 239 hit the iteration budget.

**Correction or later version:** Separate scoring excludes these points from the official-path score; report distinguishes energy accuracy from fully converged eigenstates.

**Outcome:** Useful bounded additional evidence, not an all-convergence success or a new-material test.

**Remaining unknowns:** No generalization beyond aluminum or universal convergence is measured.

## LESSON-37 — First allocation rewrite saved memory but increased time 52.1%

Classification: failed_target.

Date: 2026-09-29T02:12:31.070Z. Exact benchmark receipt UTC; September28Eastern.

**Attempt or claim:** Typed-array compact BFGS attempted to reduce resource cost for the same 192-energy workload.

**Evidence:** The old/new/new/old batch had medians of 17,591.91365 ms for baseline and 26,757.5566 ms for candidate: 52.1014548636% slower. CPU time increased 43.0189%; maximum observed process RSS decreased 40.6022%. All 192 energies and parameters matched.

**Correction or later version:** The variant was retained but not selected; flat/row probes and later angle-cache implementation followed.

**Outcome:** This is a completed unfavorable performance comparison, not an incorrect numerical answer.

**Remaining unknowns:** Two runs per version on one laptop are bounded observations; no total-system memory or electrical-energy claim.

## LESSON-38 — Flat-array v2 probe remained slower

Classification: failed_target.

Date: 2026-09-29T02:14:07.020Z. Exact focused-probe receipt UTC.

**Attempt or claim:** A flat-array variant tested whether allocation organization improved the same optimizer work.

**Evidence:** Four focused rounds preserved iteration counts and identical output; the baseline/candidate speed ratio of 0.806597963663965 is below one.

**Correction or later version:** Variant retained; not chosen for installation. A row-based variant and cached-angle successor followed.

**Outcome:** The two baseline observations, 281.2636 and 229.6612 ms, and candidate observations, 332.5347 and 300.8971 ms, remain explicit.

**Remaining unknowns:** This focused probe is not the full24-point benchmark and is not an independent material study.

## LESSON-39 — Row-array v3 probe also remained slower

Classification: failed_target.

Date: 2026-09-29T02:15:42.196Z. Exact focused-probe receipt UTC.

**Attempt or claim:** A row-array variant attempted another BFGS allocation layout.

**Evidence:** Baseline observations were 284.7159 and 234.2065 ms versus candidate 389.8639 and 402.8986 ms; the reported ratio 0.6545748569085952 is below one. Outputs and iteration counts were identical.

**Correction or later version:** The variant was retained but not selected; cached trigonometry and compact history became v4.

**Outcome:** The unfavorable result remains with actual source and receipt.

**Remaining unknowns:** A focused kernel probe is not full-workload timing.

## LESSON-40 — Selected performance v4 improved time but missed the 20% target

Classification: failed_target.

Date: 2026-09-29. Exact UTC is in benchmark-results-v4.json; local September 28.

**Attempt or claim:** The selected angle-cache and compact-history implementation targeted at least 20% less calculation time.

**Evidence:** The four-process old/new/new/old batch decreased median time from 17.8700468 s to 14.8067205 s, a 17.14223994% reduction; target_passed is false. All 192 energies and parameters were identical.

**Correction or later version:** The selected code retained the measured gain honestly; a later batch checked it again.

**Outcome:** Useful improvement and a failed target are both true; neither erases the other.

**Remaining unknowns:** This is not a guaranteed fixed percentage; startup is excluded.

## LESSON-41 — Audit repeat also missed the 20% target

Classification: failed_target.

Date: 2026-09-29. UTC receipt; local September 28 late evening.

**Attempt or claim:** A second four-process batch repeated the accepted comparison.

**Evidence:** Median time decreased from 18.52155325 s to 16.04999345 s, a 13.34423613% reduction; target_passed is false with identical 192 energies and parameters.

**Correction or later version:** The report gives an observed 13.3–17.1% range across batches, not one guaranteed gain.

**Outcome:** The second miss is retained separately from the first; neither becomes numerous independent studies.

**Remaining unknowns:** Small live-laptop sample; no causal Windows-wide effect.

## LESSON-42 — Performance README installation-pending prose was superseded by a later limited receipt

Classification: retracted_claim.

Date: 2026-09-29T04:23:04.767Z. Installation receipt UTC; older guide remains historical.

**Attempt or claim:** The earlier README said installation had not been performed and described an installer that would verify a fresh calculation.

**Evidence:** The later receipt says INSTALLED_BYTE_VERIFIED_CALCULATION_DEFERRED, 16 payload files, calculation_started: false and installed_runtime_tested: false.

**Correction or later version:** Use the later installed-byte state while retaining the deferred calculation and runtime check; do not repeat older pending prose as current.

**Outcome:** The original guide and later receipt remain separate preserved artifacts.

**Remaining unknowns:** No current USB check or post-install scientific run is established.

## LESSON-43 — Structured 60-qubit labels require branch, bond and verification limits

Classification: unresolved_or_limited.

Date: Not established. Implementation date unresolved; retained later Q8 snapshot and current static review.

**Attempt or claim:** The SOP/MPS bridge represents selected product and GHZ states up to 60 indexed qubits.

**Evidence:** SOP caps branches at 64 and throws before overflow. The bridge MPS bond cap is 32, with a local QR omission threshold of 1e-13. Verification uses three selected amplitude witnesses plus norm, not all 2^60 amplitudes.

**Correction or later version:** The later review states compact representation limits and separates the dense 21-qubit trial results.

**Outcome:** These are implementation boundaries, not proof that 60 physical qubits or arbitrary dense 60-qubit states were executed.

**Remaining unknowns:** Full historical benchmark-to-version linkage remains limited; the local QR threshold is not a global error certificate.

## LESSON-44 — Windows observation changes cannot be promoted to causal USB speedup

Classification: unresolved_or_limited.

Date: 2026-09-29. Three original UTC observation windows; documentary review October 16.

**Attempt or claim:** Three windows recorded Windows resource counters and then checked the USB package.

**Evidence:** 990 readings (3 × 11 × 30) yield 33 means. In all three windows, the last counter precedes USB verification. Checks took 12.5676291, 1.620652 and 9.3315077 seconds against 40 declared files.

**Correction or later version:** The public review separates the overall observation window, counter sampling and package check; it explicitly discloses the unsigned manifest and sequential timing.

**Outcome:** Observed resource changes are preserved; no controlled Windows-wide causal estimate is inferred.

**Remaining unknowns:** Background activity, cache effects and storage-placement causality were not isolated. No new measurements.

## LESSON-45 — Saved-result retrieval is not a hundreds-fold fresh-computation gain

Classification: unresolved_or_limited.

Date: 2026-09-29. Later performance operation receipts/report cycle.

**Attempt or claim:** The launcher reused an unchanged verified result in 0.062 seconds after entry-point startup, versus 16.804 seconds for the preceding fresh calculation.

**Evidence:** This operation returned previous answers. Six invalid, stale, corrupt or incomplete cache cases were rejected, but the cache performs unsigned consistency checks.

**Correction or later version:** The review separates saved-result retrieval from fresh computation; cache consistency is a different property from authenticated provenance.

**Outcome:** Useful cache behavior is retained without inflating fresh-calculation speed.

**Remaining unknowns:** No adversarial authenticity guarantee or universal cache correctness follows from six negative cases.
