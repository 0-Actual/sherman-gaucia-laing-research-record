# Mathematical bridge corrections — October 16, 2026

The earlier 112-file edition is preserved unchanged. This is a separately identified teaching correction.

1. MATH-07 described the equal-subnormal fixed point as diagonal (0.75,0.25) without a rounding qualifier. For positive common probability q, exact algebra gives (3/4+q/(8-4q),1/4-q/(8-4q)). The revised text states that the displayed pair is rounded in binary64. This does not establish a failed historical calculation or change the channel model.
2. MATH-07 now states the composition order explicitly: first D_p, then C_eta. Reversing the order generally changes the fixed point. The displayed original coefficients already corresponded to this order.
3. Foundation F03 now explicitly requires normalized, mutually orthogonal exact prior eigenstates. This states the condition already used in the full VQD teaching argument, including degenerate spectra.
4. Foundation F06 now calls the density-matrix trace the ground-state population (squared fidelity with the pure ground state), avoiding an implication that a mixed state has a single state vector. The proof appendix also explicitly orders the eigenvalues used by the deflation argument.

All other displayed mathematical identities and worked examples were checked under their stated assumptions. The accompanying appendix makes the elementary derivations explicit. It does not certify empirical timings, source authenticity, universal floating-point accuracy or solutions to the listed open project questions.
