# Proof review of the mathematical bridges

Reviewed October 16, 2026. These are explicit teaching derivations of established identities, prepared with Codex assistance for Sherman G. Laing / Quantum.Earth.Laing. They do not claim new mathematical discoveries. The existing project license and independently applicable source rights remain in force.

The scope is the eight bridge explanations and five worked lessons. Historical measurements, code execution receipts and outstanding project research questions are not mathematical premises proved by this appendix. Finite-dimensional complex inner products use conjugate transpose. Norms are Euclidean unless otherwise stated.

## 1. Dense and factored states

A binary string of length n has 2^n possible values, so a full state vector has 2^n complex coefficients. Two eight-byte real components per coefficient require 16*2^n bytes for those arrays. At n=21 this is 33,554,432 bytes. This excludes all other storage.

An SOP with B terms stores B weights and 2nB local coefficients, giving O(Bn) storage for fixed local dimension. An open-boundary MPS stores sum_j 2*chi_(j-1)*chi_j coefficients, with boundary dimensions one; if every internal dimension is at most chi, this is at most 2n*chi^2. These are storage bounds for the representation supplied, not bounds on ranks needed by arbitrary states or circuits.

For GHZ, the two SOP terms are the all-zero and all-one product vectors, each with coefficient 1/sqrt(2). An explicit MPS for n>=2 has first matrices A1[0]=(1,0)/sqrt(2), A1[1]=(0,1)/sqrt(2); interior matrices A_j[0]=diag(1,0), A_j[1]=diag(0,1); and last columns A_n[0]=(1,0)^T, A_n[1]=(0,1)^T. A mixed string multiplies incompatible diagonal selectors and gives zero. The two constant strings give 1/sqrt(2). The two branches are orthogonal across every nontrivial bipartition, so their Schmidt rank is two. No exponential compression of all states follows.

Background: [Vidal's restricted-state simulation result](https://arxiv.org/html/quant-ph/0301063v2) and [Tensor Toolbox's weighted product sums](https://www.tensortoolbox.org/ktensor_doc.html). These support the representation context, not the project's measured results.

## 2. Hermitian expectation and the spectral gap

For any matrix M, H=(M+M*)/2 satisfies H*=H. Identify eight orbital basis vectors with the eight strings of three bits; this is a unitary relabeling, with no change to the spectrum.

By the finite-dimensional spectral theorem, choose orthonormal eigenvectors u_j with real eigenvalues E_j. Write psi=sum_j c_j u_j and sum_j |c_j|^2=1. Then psi*H psi=sum_j |c_j|^2 E_j, a real convex combination of the eigenvalues, hence at least E0=min_j E_j. This is the Rayleigh bound; a restricted ansatz need not reach E0.

Let P0 project onto the entire ground eigenspace, F=||P0 psi||^2, and suppose every remaining eigenvalue is at least E0+Delta with Delta>0. Separating the two parts gives E>=E0 F+(E0+Delta)(1-F), so 1-F<=(E-E0)/Delta. Also F>=0, giving F>=max(0,1-(E-E0)/Delta). If H has no excited space, F=1 and no positive-gap estimate is needed. A unique chosen eigenvector cannot replace P0 in a degenerate ground space.

For H=diag(0,Delta) and psi=(sqrt(F),sqrt(1-F)), direct multiplication gives E=Delta*(1-F), attaining the bound. The worked values (Delta,F)=(2,0.99) give E=0.02; (0.001,0.5) give E=0.0005. These are exact examples, not new measurements.

Background: [Hangleiter and colleagues, Lemma 2](https://arxiv.org/html/1602.00703v4). Their stated unique-ground-state setting is extended here explicitly by the elementary ground-subspace decomposition above.

## 3. Overlap penalties

For a normalized vector phi, psi*(phi phi*)psi=|phi*psi|^2. Thus adding overlap penalties is exactly adding rank-one matrices to H. Order the eigenvalues as E_0<=E_1<=...<=E_(d-1), with multiplicity, and let 0<=k<d. With a corresponding orthonormal eigenbasis u_i and exact previous eigenvectors u_0,...,u_(k-1), the modified operator sends u_i to (E_i+beta_i)u_i when i<k and to E_i u_i otherwise. If beta_i>E_k-E_i for each i<k, every shifted earlier value exceeds E_k, while the least unshifted value is E_k. The minimum over all normalized states is therefore E_k. Degenerate unshifted eigenvalues can give a multidimensional minimizing subspace; uniqueness is not implied.

If a prior vector is not an exact eigenvector, that diagonal argument fails. If optimization is local or the ansatz does not contain a minimizing state, the ideal minimum need not be attained. The criterion concerns the objective, not universal optimizer convergence. It agrees with [Higgott, Wang and Brierley's overlap weighting condition](https://arxiv.org/html/1805.08138v2).

## 4. Differentiation, inverse gates and parameter shift

For a real parameter t and fixed Hermitian H, differentiate E=psi*H psi: E'=psi'*H psi+psi*H psi'. The terms are complex conjugates, giving E'=2 Re(psi'*H psi). If H depends on t, add psi*H'psi. For a gate product U_L...U_1, the product rule sums one term per parameter-dependent occurrence. Moving a unitary factor across an inner product uses its conjugate transpose, equal to its inverse. This explains backward reuse; it does not prove a wall-clock gain on any particular machine.

For one occurrence of R(t)=exp(-itP/2), with Hermitian P and P^2=I, R(t)=I cos(t/2)-iP sin(t/2). Expanding an expectation with all other gates fixed yields A+B cos(t)+C sin(t), for real A,B,C. Its derivative equals [E(t+pi/2)-E(t-pi/2)]/2. This applies to the retained RY/RZ form. Shifting one shared parameter simultaneously in multiple gates does not generally satisfy this single-occurrence formula; apply the product rule occurrence by occurrence.

The computational method is established: [Jones and Gacon's adjoint-gradient paper](https://arxiv.org/abs/2009.02823). Historical speedups require separate timing evidence.

## 5. Scaling and projective distance

For nonzero x and nonzero complex scalar a, ||ax||=|a| ||x||. Therefore ax/||ax||=(a/|a|)x/||x||. The factor has modulus one and cancels in the outer product psi psi*. Positive real scaling preserves even the normalized representative. The examples (3,4) and (6,8) both give (3/5,4/5).

For nonzero vectors a,b, put c=(a*b)/(a*a) and r=b-ca. Then a*r=0, and orthogonality gives ||b||^2=||r||^2+|a*b|^2/||a||^2. Dividing by ||b||^2 and taking the nonnegative square root proves the residual formula. For normalized inputs this is sqrt(1-|a*b|^2). Cauchy-Schwarz ensures the radicand is nonnegative in exact arithmetic; rounded computations need their own guards.

Choosing m as the largest absolute real or imaginary component gives m>0 for finite nonzero x; each scaled component is bounded by one, and (x/m)/||x/m||=x/||x|| exactly. This avoids squaring the original huge components. It cannot restore components already rounded away or certify an arbitrary implementation. [LAPACK's scaled sum-of-squares documentation](https://netlib.org/lapack/explore-html/d8/d76/group__lassq_gae8f40b0a34771b4f2d9c863de3af7be5.html) gives established numerical background.

## 6. Affine channel and fixed point

Let rho,tau be qubit density matrices and p,eta in [0,1]. Applying D_p first and C_eta second gives F(rho)=(1-eta)(1-p)rho+(1-eta)p I/2+eta tau. Denote the coefficients a,b,c. They are nonnegative and sum to one, so the result is again a density matrix. This is a convex combination of the identity channel and fixed replacement channels; no thermodynamic resource claim follows.

If p=eta=0, F is identity. Otherwise a<1 and b+c=1-a>0. Solving (1-a)rho*=bI/2+c tau gives the stated unique density matrix. For any rho,sigma, F(rho)-F(sigma)=a(rho-sigma); any norm therefore scales by a. Induction gives F^t(rho)-rho*=a^t(rho-rho*), including immediate convergence when a=0. For 0<a<1 this proves exact-arithmetic convergence, not rapid convergence when a is near one.

Set s=max(p,eta)>0, u=(p/s)(1-eta), v=eta/s. Multiplying u and v by s returns b and c, so their normalized weighted sum is identical. This removes cancellation in 1-a algebraically. Finite precision may still make an individual update indistinguishable from identity.

For p=eta=q>0 and tau=diag(1,0), the two exact diagonal entries simplify to 3/4+q/(8-4q) and 1/4-q/(8-4q). With q the smallest positive binary64 subnormal, their binary64 rounding is (0.75,0.25); those numbers are not the exact real-valued fixed point. This is the precision wording corrected in the bridge record.

If a separate implementation supplies a proved per-step error bound delta in a norm, the triangle inequality would give e_(t+1)<=a e_t+delta and thus e_t<=a^t e_0+delta*(1-a^t)/(1-a). No such uniform implementation bound is established here. The conditional recurrence is not a certificate for the supplied program.

## 7. Boolean energy and expectations

For each Boolean assignment x, a positive literal x_j is false with indicator 1-x_j and a negative literal has false indicator x_j. Their product is one exactly when all literals in the clause are false. Summing clause indicators counts violated clauses. The diagonal operator with this count on each basis assignment has zero energy exactly at satisfying basis assignments; its zero eigenspace is their span.

For a product-state measurement distribution, distinct bit variables are independent, so a simplified clause's violation probability is the product of the appropriate one-bit probabilities. The expectation of the sum is the sum of those probabilities by linearity. Repeated occurrences of one bit are not independent: x^2=x and (1-x)^2=1-x on {0,1}. A clause containing x and not-x has factor x(1-x)=0. The empty product is one, matching violation of an empty clause. For x1 OR not-x2, only assignment 01 violates the clause in basis order 00,01,10,11, yielding diag(0,1,0,0).

These are representation identities. They provide no polynomial-time search, efficient global minimization or UNSAT certificate. [Farhi and colleagues' clause-Hamiltonian construction](https://arxiv.org/html/quant-ph/0001106v1) supplies the established context.

## 8. Additional foundation derivations

For an SOP, sesquilinearity expands its squared norm into sum_(r,s) conjugate(c_r)c_s times the inner product of the two product vectors. By the tensor-product inner-product definition, that inner product is product_j <v_rj,v_sj>. Cross terms remain unless their weighted sum vanishes. Squaring the weights alone is therefore insufficient for general overlapping product vectors.

On a computational basis bit b, Z has eigenvalue 1-2b. Thus (I+Z)/2 has eigenvalue 1-b and (I-Z)/2 has eigenvalue b. The foundation's product (I+Z1)(I-Z2)(I+Z3)/8 consequently has eigenvalue (1-b1)b2(1-b3), one exactly on 010 and zero on the other seven assignments. Expanding the product includes a Z1 Z2 Z3 term, so it is not a purely pairwise operator.

For the mixed-state gap inequality, A=H-E0 I-Delta(I-P0) is positive semidefinite by its eigenvalues. If rho is positive semidefinite with trace one, Tr(rho A)>=0: diagonalize A and use nonnegative diagonal expectations of rho. Expanding this trace gives Tr(P0 rho)>=1-(Tr(rho H)-E0)/Delta. With a unique pure ground state, that trace is the ground-state population, or squared fidelity convention; for a general mixed rho it need not be an overlap between two vectors. This proves the density-matrix version used in foundation F06.

## Review boundary

Every mathematical identity and small example in the selected eight bridges, five lessons and six foundation sections is covered above. The cited general theorems remain imported background, with their specific uses and assumptions checked; this does not re-prove each cited paper in full. Historical test counts and physical/material conclusions still depend on their evidence. All eight listed project research questions remain open unless separately resolved; elementary explanatory derivations here are not new original research. This is a complete human-readable audit of this declared mathematical scope, performed by AI assistance, not a proof-assistant check or outside peer review.
