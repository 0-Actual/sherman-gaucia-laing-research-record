# Complete complex-analysis proof coverage

Reviewed October 16, 2026. Source: c26704e7da955e9bf2272c2b17a353d020c78f4a3e58ee367df9afb19d6dd355. Corrected derivative: 94fd9d9a556af222eff4538be89b8482101d25061ce109d01fa9ea63045f2e48.

55 contiguous source review units cover all 733 physical lines, including metadata and blank separators. These are review units, not a theorem or discovery count. All nine worked examples and nine exercise solutions are included. Six appended units supply or delimit prerequisites. The original central results and exercise answers were sound within their stated scope; the derivative makes implicit arguments and boundary conditions explicit.

A complete chapter review is not a formal proof-assistant verification or external certification. Foundational real calculus, compactness and real trigonometry remain imported; the external-dependency record identifies them.

## CA-001 — Introduction and dependency order

**Coverage:** source lines 1–10. **Status:** reviewed under explicit prerequisites.

The announced local-to-global chain matches the proofs actually given. Earlier-volume dependencies are replaced by explicit Appendix A prerequisites.

**Assumptions:** Real integration and compactness; no general Laurent or homology theorem asserted.

**Boundaries:** The missing earlier volume is not silently treated as available.

**Changes:** CA-E01, CA-E02.

## CA-002 — Domains, derivative and continuity

**Coverage:** source lines 11–27. **Status:** reviewed under explicit prerequisites.

Dividing the increment by h gives a finite derivative limit, hence bounded quotient and continuity; the remainder is o(abs(h)).

**Assumptions:** Nonempty connected open domain; a is an interior point.

**Boundaries:** All radii positive, excluding degenerate circle parametrizations.

**Changes:** CA-E03.

## CA-003 — Pointwise Cauchy–Riemann equations

**Coverage:** source lines 28–38. **Status:** reviewed under explicit prerequisites.

Axes give the four origin partials and both equations. The difference quotient is zero on axes and 1/2 on y=x. Continuity follows from abs(xy)/(x²+y²)<=1/2. u_x(t,t)=1/2 versus u_x(0,0)=0 verifies the failed continuous-partial hypothesis.

**Assumptions:** Partial derivatives at a point are weaker than real differentiability.

**Boundaries:** A.2 now proves the separate C1 sufficient theorem.

**Changes:** CA-E04.

## CA-004 — Derivative of abs(z) squared

**Coverage:** source lines 39–40. **Status:** reviewed under explicit prerequisites.

At zero the quotient is conjugate(h), tending to zero. At a!=0 the quotient a*conjugate(h)/h+conjugate(a)+conjugate(h) differs by 2a along real and imaginary increments.

**Assumptions:** All complex directions must have one common limit.

**Boundaries:** Complex derivative exists only at zero; existence at a point is not holomorphy on a neighborhood.

## CA-005 — Piecewise smooth contour integration

**Coverage:** source lines 41–52. **Status:** reviewed under explicit prerequisites.

Finite partition, real-parameter integral and chain substitutions justify concatenation, reversal and orientation-preserving reparameterization.

**Assumptions:** Continuous integrand on the path and piecewise C1 finite path.

**Boundaries:** Breakpoints are finite and do not affect the integral; traversal multiplicity retained.

## CA-006 — Integral triangle inequality

**Coverage:** source lines 53–64. **Status:** reviewed under explicit prerequisites.

If I!=0 multiply by its conjugate phase, take real parts under the integral, and bound real part by modulus. I=0 is immediate.

**Assumptions:** Integrable complex function on a finite real interval.

**Boundaries:** No invalid ordering of complex numbers is used.

## CA-007 — ML bound and uniform passage

**Coverage:** source lines 65–75. **Status:** reviewed under explicit prerequisites.

Apply the triangle inequality to f(gamma)gamma-prime. Supremum of the difference times finite length tends to zero.

**Assumptions:** Continuous f_n on the fixed compact path image, uniform convergence, finite length.

**Boundaries:** Zero-length paths harmless; continuity ensures all integrals exist.

**Changes:** CA-E05.

## CA-008 — Worked example 1: circle estimate

**Coverage:** source lines 76–84. **Status:** reviewed under explicit prerequisites.

On abs(z)=3, abs(exp(z))<=e³ and abs(z-1)>=2. Length 6pi yields 3pi e³/2; later derivative formula gives exact 2pi i e.

**Assumptions:** Positive counterclockwise radius; pole lies strictly inside.

**Boundaries:** An upper bound is not the integral value.

## CA-009 — Primitive integral theorem

**Coverage:** source lines 85–96. **Status:** reviewed under explicit prerequisites.

Apply chain rule on each C1 piece and real FTC, then telescope endpoint terms.

**Assumptions:** Primitive derivative equals continuous integrand on an open neighborhood of the path.

**Boundaries:** Primitive derivative continuity follows here from the continuous integrand, without assuming all holomorphic derivatives continuous yet.

## CA-010 — Goursat subdivision selection

**Coverage:** source lines 97–120. **Status:** reviewed under explicit prerequisites.

Oriented four-triangle boundaries cancel. Triangle inequality gives a child with at least one quarter of the parent integral magnitude; diameter and perimeter halve.

**Assumptions:** Function holomorphic on an open neighborhood of the filled triangle.

**Boundaries:** Collinear degeneracy cancels directly; no derivative continuity is assumed.

## CA-011 — Goursat limiting estimate

**Coverage:** source lines 121–146. **Status:** reviewed under explicit prerequisites.

Nested compact triangles with vanishing diameter have one point. Subtract constant and linear derivative terms with zero boundary integral; remainder bound epsilon times distance gives epsilon*4^-n*d*P. Combine with the chosen-child lower bound and let epsilon tend to zero.

**Assumptions:** Complex differentiability at the nested point and compact containment.

**Boundaries:** The point may be on an edge; open-neighborhood differentiability still applies.

## CA-012 — Worked example 2: shrinking-triangle bound

**Coverage:** source lines 147–154. **Status:** reviewed under explicit prerequisites.

Diameter 5, perimeter 12 and epsilon .001 yield .06 after cancelling 4^-n. The arbitrary-epsilon quantifier, rather than this one numerical bound, proves zero.

**Assumptions:** The estimate is valid once the selected triangle lies in the differentiability neighborhood.

**Boundaries:** No finite tolerance is mistaken for exact equality.

## CA-013 — One exceptional point in Goursat

**Coverage:** source lines 155–169. **Status:** reviewed under explicit prerequisites.

Remove a small similar triangle around the exceptional point, triangulate the remaining part, cancel common edges and bound the small contour by boundedness times its shrinking perimeter.

**Assumptions:** Continuous function on the full triangle, holomorphic away from at most one point.

**Boundaries:** Point outside, on an edge or at a vertex is covered by subdivision/cancellation; differentiability at it is not presupposed.

## CA-014 — Star-shaped local primitive

**Coverage:** source lines 170–192. **Status:** reviewed under explicit prerequisites.

The triangle from base b to z and z+h lies in U using star-shapedness plus compact clearance. Triangle integral zero gives the increment integral on the short segment; continuity yields derivative g(z).

**Assumptions:** U open and star-shaped, continuous g with every triangle integral zero.

**Boundaries:** The local construction does not require a globally fixed disk or assume g holomorphic.

## CA-015 — Continuous closed-loop homotopy invariance

**Coverage:** source lines 193–218. **Status:** reviewed under explicit prerequisites.

Compact image gives a uniform small-ball radius. Uniform continuity gives a finite grid whose cells lie in such balls. Local primitives make cell chord boundaries zero, interior edges cancel, and original boundary arcs can be replaced by chords. Equal side paths cancel.

**Assumptions:** Continuous homotopy with each parameter loop closed; endpoints are piecewise C1 loops; holomorphic f on U.

**Boundaries:** Intermediate loops need not be smooth; self-intersections are allowed; endpoint side need not be constant.

## CA-016 — Simply connected Cauchy theorem

**Coverage:** source lines 219–228. **Status:** reviewed under explicit prerequisites.

Null-homotope each closed loop and apply invariance; a constant loop has zero integral. Concatenation with a reversed path proves path independence.

**Assumptions:** Simply connected domain in the declared loop-contraction sense.

**Boundaries:** No implicit Jordan-curve theorem or arbitrary interior-region assertion.

## CA-017 — Global primitive and polygonal connectivity

**Coverage:** source lines 229–232. **Status:** reviewed under explicit prerequisites.

Polygonally reachable points form a nonempty relatively open and relatively closed subset of the connected domain. Define primitive by path integral; a local short segment gives its derivative.

**Assumptions:** Open connected domain and vanishing all closed piecewise C1 integrals.

**Boundaries:** The polygonal connection proof supplies the paths instead of assuming connected means path connected in every space.

## CA-018 — Worked example 3: punctured plane

**Coverage:** source lines 233–242. **Status:** reviewed under explicit prerequisites.

Direct circle parametrization gives integral 2pi i for 1/z, precluding a primitive and contraction there. The derivative of -1/z is 1/z², so that different integrand has a primitive.

**Assumptions:** Circle winds once counterclockwise around zero.

**Boundaries:** A non-simply-connected domain may still support primitives for particular functions.

## CA-019 — Circle kernel integral

**Coverage:** source lines 243–265. **Status:** reviewed under explicit prerequisites.

Geometric expansion has ratio abs(a-c)/R<1 and uniform tail, permitting termwise integration. Centered monomial integrals select the constant Fourier mode. For an exterior point, the kernel is holomorphic on a slightly larger disk and Cauchy's theorem gives zero.

**Assumptions:** Positive R and a strictly off the circle.

**Boundaries:** Inside gives 2pi i, outside zero; on-circle kernel is not a defined ordinary contour integral.

## CA-020 — Cauchy formula on a disk

**Coverage:** source lines 266–287. **Status:** reviewed under explicit prerequisites.

Neighborhood of the closed disk contains a slightly larger disk. The divided difference is continuous at a and holomorphic elsewhere; exceptional-point triangles plus a primitive make its circle integral zero. Kernel integral gives the formula.

**Assumptions:** f holomorphic on an open neighborhood of the closed disk; a strictly inside.

**Boundaries:** Does not assume divided difference holomorphic at a before proving analyticity.

## CA-021 — Worked example 4: polynomial numerator

**Coverage:** source lines 288–301. **Status:** reviewed under explicit prerequisites.

Apply the disk formula to the given numerator to obtain 6pi i; reversal negates and repeated winding multiplies. Outside pole gives zero; cancellation quotient z+1 extends holomorphically.

**Assumptions:** Contour orientation, radius and location are kept distinct.

**Boundaries:** A removable denominator zero differs from a genuine pole.

## CA-022 — Taylor expansion and remainder

**Coverage:** source lines 302–326. **Status:** reviewed under explicit prerequisites.

Expand the Cauchy kernel as a uniformly convergent geometric series on the circle. Coefficients have integral expressions and bound M/R^n. Sum the geometric tail to M(r/R)^(N+1)/(1-r/R).

**Assumptions:** Fixed 0<=r<R with f holomorphic on a neighborhood of the closed radius-R disk.

**Boundaries:** Uniformity is only on smaller disks; no boundary convergence inference.

## CA-023 — Differentiating Taylor polynomials

**Coverage:** source lines 327–350. **Status:** reviewed under explicit prerequisites.

Derivative terms obey a convergent polynomial-times-geometric majorant. Uniform convergence and segment FTC pass derivatives to the limit; repeat for each fixed order. Evaluation at the center yields coefficient f^(k)/k!.

**Assumptions:** Positive smaller radius with room for the segment; fixed differentiation order.

**Boundaries:** A.5 supplies the real smooth nonanalytic contrast; no Cauchy theorem used in A.3 general-series lemma.

**Changes:** CA-E06.

## CA-024 — Higher Cauchy formula and estimates

**Coverage:** source lines 351–374. **Status:** reviewed under explicit prerequisites.

Kernel difference quotient converges uniformly when the point remains positive distance d from the circle; error bound 2abs(h)/d³ for first derivative. General power denominator algebra gives induction. ML yields n!M/R^n at the center.

**Assumptions:** Fixed derivative order; evaluation points in a compact subset strictly inside circle.

**Boundaries:** Factorial and denominator exponent checked; derivative continuity follows from uniform local formulas.

## CA-025 — Worked example 5: third-order denominator

**Coverage:** source lines 375–386. **Status:** reviewed under explicit prerequisites.

f(z)=exp(2z) has f''(1)=4e²; order-three formula gives 2pi i*f''/2=4pi i e².

**Assumptions:** Radius 2 encloses 1 strictly.

**Boundaries:** Radius 1 places the singularity on the contour and is excluded.

## CA-026 — Worked example 6: Taylor error

**Coverage:** source lines 387–395. **Status:** reviewed under explicit prerequisites.

M=5,R=2,r=.5,N=6 gives 20/(3*16384)=.0004069010416..., less than .000407.

**Assumptions:** Uniform bound on the radius-R circle.

**Boundaries:** The bound is not asserted to be the actual error.

## CA-027 — Holomorphic divided difference

**Coverage:** source lines 396–409. **Status:** reviewed under explicit prerequisites.

Taylor expansion shifted by one coefficient gives q(a)=f'(a), q'(a)=f''(a)/2; A.3 supplies holomorphy and valid termwise differentiation of shifted series.

**Assumptions:** Holomorphic f in a neighborhood of a.

**Boundaries:** No appeal to the quotient rule at the originally undefined point.

**Changes:** CA-E07.

## CA-028 — Removable singularity theorem

**Coverage:** source lines 410–429. **Status:** reviewed under explicit prerequisites.

Define h=(z-a)²f off a and zero at a. Boundedness gives continuity and h'(a)=0. Taylor starts at order two; divide the series, then agree with f off a. Continuity gives uniqueness.

**Assumptions:** f holomorphic on a punctured neighborhood and bounded there sufficiently near a.

**Boundaries:** Extension joins the unchanged function over the rest of its original domain; unbounded poles not included.

## CA-029 — Morera theorem

**Coverage:** source lines 430–435. **Status:** reviewed under explicit prerequisites.

Continuous triangle-zero function has a local primitive F by the triangle construction. F is holomorphic, so the already established derivative theorem makes F'=g holomorphic.

**Assumptions:** Continuity and zero integral on all filled triangles lying in U.

**Boundaries:** Dependency on analyticity is explicit, avoiding circular use during Goursat.

## CA-030 — Locally uniform limits and derivative convergence

**Coverage:** source lines 436–441. **Status:** reviewed under explicit prerequisites.

Limit is continuous on compact local disks. Triangle integrals pass to zero, invoking Morera. Fixed surrounding-circle derivative formula bounds differences; finite disk subcover proves convergence on an arbitrary compact subset.

**Assumptions:** Holomorphic f_n on common U, locally uniform convergence and fixed derivative order.

**Boundaries:** Positive contour clearance is explicit; no assertion of convergence uniform over all derivative orders.

**Changes:** CA-E08.

## CA-031 — Worked example 7: removable exponential quotient

**Coverage:** source lines 442–449. **Status:** reviewed under explicit prerequisites.

Taylor coefficients of exp(z)-1-z begin at z²/2 and z³/6, giving extension 1/2 and derivative 1/6.

**Assumptions:** At zero, a punctured neighborhood and Taylor convergence.

**Boundaries:** exp(z)/z² stays unbounded on a real approach and is not removable.

## CA-032 — Isolated zeros and multiplicity

**Coverage:** source lines 450–459. **Status:** reviewed under explicit prerequisites.

If some Taylor coefficient is nonzero, the least such index factors out a finite power times a continuous nonzero local factor; otherwise the function vanishes on a disk.

**Assumptions:** Holomorphic function near the zero.

**Boundaries:** Identically zero local functions have no finite zero multiplicity.

## CA-033 — Identity theorem

**Coverage:** source lines 460–465. **Status:** reviewed under explicit prerequisites.

Continuity makes the interior accumulation point a zero; distinct approaching zeros exclude isolation. The set where all derivatives vanish is relatively closed and locally open by Taylor, hence all the connected domain.

**Assumptions:** Interior accumulation of distinct zeros, connected open domain.

**Boundaries:** Boundary accumulation and disconnected components are expressly insufficient.

**Changes:** CA-E09.

## CA-034 — Liouville theorem

**Coverage:** source lines 466–475. **Status:** reviewed under explicit prerequisites.

Cauchy derivative bound M/R tends to zero as arbitrary R grows. Derivative zero implies constancy along segments/polygonal paths.

**Assumptions:** Entire function bounded by one global finite constant.

**Boundaries:** Bounds only on compact subsets or the real axis do not suffice.

## CA-035 — Worked example 8: quartic root argument

**Coverage:** source lines 476–484. **Status:** reviewed under explicit prerequisites.

For rho>=2, (rho+1)/rho^4 is decreasing and at 2 is 3/16, ensuring the displayed lower bound at least 3rho^4/4. If no roots, reciprocal bounded outside and on compact disk; Liouville contradicts nonconstant polynomial.

**Assumptions:** Polynomial denominator assumed zero-free for contradiction.

**Boundaries:** This is an existence proof, not numerical root computation.

## CA-036 — Mean value and strong maximum principle

**Coverage:** source lines 485–506. **Status:** reviewed under explicit prerequisites.

Cauchy formula yields complex mean value. At an interior modulus maximum M>0, rotate the value to M. The nonnegative continuous defect M-Re(g) has zero integral, hence vanishes; modulus bound then forces imaginary part zero. Every small radius gives local constancy; identity theorem gives global constancy.

**Assumptions:** Holomorphic on connected domain; genuine local modulus maximum.

**Boundaries:** M=0 gives local zero directly; no unjustified equality case of the triangle inequality.

## CA-037 — Boundary maximum and uniqueness

**Coverage:** source lines 507–512. **Status:** reviewed under explicit prerequisites.

Compact closure gives maximum. If a nonconstant function attained it inside, strong maximum principle would contradict nonconstancy. A bounded nonempty domain has nonempty boundary via segment exit. Apply to the difference for uniqueness.

**Assumptions:** Bounded domain, function holomorphic inside and continuous on closure.

**Boundaries:** No unbounded-domain or discontinuous-boundary extension asserted.

**Changes:** CA-E10.

## CA-038 — Sharp maximum example

**Coverage:** source lines 513–514. **Status:** reviewed under explicit prerequisites.

abs(z²-1)<=abs(z)²+1<=2 on closed unit disk, equality at z=+i or -i; strong principle gives strict interior inequality.

**Assumptions:** Closed unit disk and nonconstant holomorphic polynomial.

**Boundaries:** Equality points are on boundary.

## CA-039 — Fundamental theorem of algebra and factorization

**Coverage:** source lines 515–539. **Status:** reviewed under explicit prerequisites.

For large radius, the leading term dominates coefficient sum, giving abs(p)>=abs(a_n)rho^n/2. Zero-free reciprocal would be globally bounded and entire, contradiction by Liouville. The telescoping power identity supplies a degree n-1 quotient at a root; induction gives all n linear factors.

**Assumptions:** Positive-degree polynomial, leading coefficient nonzero.

**Boundaries:** Repeated roots count with multiplicity; constant polynomials are outside the statement.

**Changes:** CA-E11.

## CA-040 — Limits of the algebra theorem

**Coverage:** source lines 540–541. **Status:** reviewed under explicit prerequisites.

Existence and linear factorization are the proved results.

**Assumptions:** Complex field and finite-degree polynomial.

**Boundaries:** No formula by radicals, root-selection algorithm, stability or runtime claim.

## CA-041 — Winding index integrality

**Coverage:** source lines 542–565. **Status:** reviewed under explicit prerequisites.

Integrate gamma-prime/(gamma-a) cumulatively as B. On each smooth piece the derivative of exp(-B)(gamma-a) is zero; continuity joins pieces. Closed endpoints yield exp(B(1))=1, and the explicitly proved exponential kernel gives 2pi i times an integer.

**Assumptions:** Closed piecewise C1 path avoiding a.

**Boundaries:** Non-simple paths allowed; homotopy invariance follows from earlier contour result; exponential kernel depends on declared real trigonometry.

## CA-042 — Finite-pole principal part and residue

**Coverage:** source lines 566–582. **Status:** reviewed under explicit prerequisites.

Taylor-expand the numerator at a and divide by the finite pole power; shifted remainder is holomorphic. Coefficient of power -1 gives g^(m-1)(a)/(m-1)!. Multiplying a difference by its highest compensating power proves order and coefficient uniqueness.

**Assumptions:** Pole representation has finite positive order and numerator nonzero at a.

**Boundaries:** No full Laurent expansion or essential-singularity formula claimed.

**Changes:** CA-E12.

## CA-043 — Finite-pole residue theorem

**Coverage:** source lines 583–600. **Status:** reviewed under explicit prerequisites.

Subtract all finite principal parts to obtain a holomorphic function throughout simply connected U. Its integral vanishes; powers <=-2 have explicit single-valued primitives; simple powers give 2pi i times index.

**Assumptions:** Finite distinct poles, closed piecewise C1 path in U avoiding them, simply connected U.

**Boundaries:** No-pole case is an empty sum; arbitrary winding handled; essential singularities and general homology are excluded.

**Changes:** CA-E13.

## CA-044 — Worked example 9: two rational poles

**Coverage:** source lines 601–610. **Status:** reviewed under explicit prerequisites.

Partial fractions give residues 1/3 at 1 and 2/3 at -2. Radius 3 yields 2pi i; radius 1.5 yields 2pi i/3; three clockwise traversals of the smaller circle yield -2pi i.

**Assumptions:** All selected circles avoid both poles.

**Boundaries:** Orientation and traversal count checked separately from residue values.

## CA-045 — Exercise 1: conjugate integrand

**Coverage:** source lines 611–622. **Status:** reviewed under explicit prerequisites.

Parametrize z=R exp(it): conjugate(z)dz=iR²dt, so integral is 2pi i R². Difference quotients of conjugation along real and imaginary axes disagree.

**Assumptions:** R>0, positive orientation.

**Boundaries:** No contradiction with Cauchy because conjugation is nowhere holomorphic.

**Changes:** CA-E14.

## CA-046 — Exercise 2: path dependence

**Coverage:** source lines 623–630. **Status:** reviewed under explicit prerequisites.

Straight path t(1+i) gives integral 1. Real then vertical legs give 1/2 plus 1/2+i=1+i.

**Assumptions:** Piecewise linear paths from 0 to 1+i.

**Boundaries:** Continuous but nonholomorphic integrand; endpoint equality need not imply equal integral.

## CA-047 — Exercise 3: logarithm on a domain

**Coverage:** source lines 631–640. **Status:** reviewed under explicit prerequisites.

Primitive F of 1/z exists. Choose a logarithm of one nonzero base value and adjust constant. Derivative of exp(-L)z is zero and its base value is one, yielding exp(L)=z. Connectedness fixes the branch-difference integer.

**Assumptions:** Simply connected domain omitting zero; point logarithm supplied by A.4.

**Boundaries:** No global branch on punctured plane; branch differences are constant multiples of 2pi i.

**Changes:** CA-E15.

## CA-048 — Exercise 4: second-order Cauchy formula

**Coverage:** source lines 641–650. **Status:** reviewed under explicit prerequisites.

For f=z³+1, f'(i)=3i²=-3; integral equals 2pi i times -3=-6pi i.

**Assumptions:** Radius 2, pole i strictly inside.

**Boundaries:** Derivative order is one for denominator power two.

## CA-049 — Exercise 5: polynomial growth

**Coverage:** source lines 651–661. **Status:** reviewed under explicit prerequisites.

Cauchy estimates on radius R bound n-th Taylor coefficient by C(1+R^m)/R^n, tending to zero for n>m. Entire Taylor expansion therefore truncates.

**Assumptions:** m a nonnegative integer, one global growth constant.

**Boundaries:** m=0 recovers constant functions; zero polynomial has degree at most m by convention.

## CA-050 — Exercise 6: second divided difference

**Coverage:** source lines 662–680. **Status:** reviewed under explicit prerequisites.

Remove constant and linear Taylor terms and divide by (z-a)²; shifted series gives value f''(a)/2 and derivative f'''(a)/6.

**Assumptions:** f holomorphic near a.

**Boundaries:** Uniqueness follows from continuity of any extension; no quotient differentiation at a before extension.

## CA-051 — Exercise 7: boundary zeros

**Coverage:** source lines 681–686. **Status:** reviewed under explicit prerequisites.

sin(1/z) is holomorphic on punctured plane; zeros z=1/(npi) approach excluded zero. Value at 2/pi is one.

**Assumptions:** Zero is outside the domain.

**Boundaries:** Interior accumulation is essential to identity theorem; sine properties follow from exponential/trigonometric prerequisites.

## CA-052 — Exercise 8: double-pole residue

**Coverage:** source lines 687–702. **Status:** reviewed under explicit prerequisites.

g(z)=exp(z)/(z-2), so g'(0)=-1/2-1/4=-3/4. Radius 1 integral is -3pi i/2; pole 2 has index zero. Cauchy derivative formula independently agrees.

**Assumptions:** Contour excludes zero and two themselves; radius 1 encloses only zero.

**Boundaries:** The exterior pole is not added despite belonging to the rational-exponential expression.

## CA-053 — Exercise 9: geometric approximants

**Coverage:** source lines 703–712. **Status:** reviewed under explicit prerequisites.

Tail r^(N+1)/(1-r) tends uniformly to zero. Derivative majorant sum k*r^(k-1) converges and differentiated geometric sum is 1/(1-z)². At r=0 values are exactly 1 and eventual derivative 1.

**Assumptions:** 0<r<1 for ratio estimates; singleton r=0 checked separately.

**Boundaries:** At z=1 the approximants diverge; boundary behavior is not claimed.

**Changes:** CA-E16, CA-E17.

## CA-054 — Reference notes and declared theorem scope

**Coverage:** source lines 713–722. **Status:** reviewed under explicit prerequisites.

The two cited MIT official notes were reopened; author-hosted Trinity notes cross-check Goursat, primitives, residues and power-series differentiation.

**Assumptions:** Reference cross-checks are targeted statements, not a new audit of entire books.

**Boundaries:** General Laurent theory, homology, Riemann mapping and other later theorems remain outside scope.

## CA-055 — Historical preparation and current review status

**Coverage:** source lines 723–733. **Status:** reviewed under explicit prerequisites.

Earlier date and source-byte provenance remain historical metadata. Current copy is expressly a changed derivative; exact original is retained.

**Assumptions:** Hash confirms bytes, not original authorship or an independent time stamp.

**Boundaries:** Current full selected-chapter review is distinct from formal verification, external certification and other manuscripts.

**Changes:** CA-E18, CA-E20.

## CA-APP-01 — Explicit foundations and calculus

**Coverage:** derivative lines 744–753. **Status:** reviewed; foundations explicitly imported.

Sum, product, reciprocal and composition use o(abs(h)); composition handles zero increments and derivative-zero case. Real path chain rule follows by the same remainder bound. Negative powers require nonzero argument. Real FTC, compactness, real trigonometry and elementary series remain explicitly imported.

**Changes:** CA-E19.

## CA-APP-02 — Cauchy–Riemann sufficient theorem

**Coverage:** derivative lines 754–765. **Status:** reviewed; foundations explicitly imported.

Two coordinate-segment FTC integrals use only one-variable calculus, including negative h or k. Continuous partials give an epsilon times Euclidean norm remainder. CR equations combine the real-linear term into complex multiplication; no pointwise-only sufficiency is asserted.

**Changes:** CA-E19.

## CA-APP-03 — General power-series differentiation

**Coverage:** derivative lines 766–773. **Status:** reviewed; foundations explicitly imported.

Convergence at a positive radius bounds coefficient terms; geometric and polynomial-geometric majorants give uniform convergence on every smaller positive disk. Uniform limit continuity and segment FTC justify one derivative, then each fixed higher derivative. Shifting finitely many coefficients preserves the interior radius.

**Changes:** CA-E19.

## CA-APP-04 — Complex exponential and kernel

**Coverage:** derivative lines 774–785. **Status:** reviewed; foundations explicitly imported.

Factorial majorant gives all-disk convergence, A.3 gives derivative, and absolutely convergent Cauchy products prove addition. Real sine/cosine comparison uses an elementary ODE uniqueness via squared norm. Kernel 2pi i Z and a logarithm of one point follow using explicitly assumed real trigonometric periodicity and polar representation.

**Changes:** CA-E19.

## CA-APP-05 — Smooth flat-function counterexample

**Coverage:** derivative lines 786–791. **Status:** reviewed; foundations explicitly imported.

Positive exponential-series term bounds defeat every inverse power. Derivative polynomials and their difference quotients tend to zero, proving all derivatives exist at zero and vanish; positivity away from zero disproves equality with the zero Taylor series.

**Changes:** CA-E19.

## CA-APP-06 — Review and reference boundary

**Coverage:** derivative lines 792–796. **Status:** reviewed; foundations explicitly imported.

No new theorem or certification claim. Targeted primary university references support stated checks; real foundational assumptions and excluded later theory are not misrepresented as newly proved.

**Changes:** CA-E19.
