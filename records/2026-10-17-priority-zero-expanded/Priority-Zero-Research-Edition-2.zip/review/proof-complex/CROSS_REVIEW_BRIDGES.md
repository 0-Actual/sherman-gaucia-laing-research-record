# Cross-review of mathematical bridges

Result: **pass within the stated mathematical scope**. All eight bridge records, five worked lessons, six foundation sections and eight proof-appendix sections were read. Exact identities are listed below and in the JSON record.

- `proof-bridges/PROOF_APPENDIX.md` — SHA-256 `d59019e19ee341b7d2ad8db849163ef171ce30a5fe118ecca4c263b5aacc8f4e`; 81 physical lines.
- `proof-bridges/BRIDGES.md` — SHA-256 `6efee42982ea31829335a5cc80ef66899d3b4e4d3708a00f8b34eac71a972808`; 163 physical lines.
- `proof-bridges/FOUNDATIONS.md` — SHA-256 `733b5cd0116dc9487c11ddf24188ab14d850a07a839c7d313ad46fa0cbf2c28b`; 120 physical lines.
- `proof-bridges/WORKED_BRIDGES.md` — SHA-256 `2de7e3e20c74b8af472ade5f577b5201270aac66f95b136c02279a1dcdae4953`; 213 physical lines.

## XBR-01 — Dense, SOP and MPS representations

**Pass.** Dense coefficient and byte counts are correct. Open-boundary MPS storage is bounded by the declared bond cap. The explicit GHZ first-row/interior-selector/last-column contraction gives exactly two amplitudes 1/sqrt(2), including n=2 with no interior factors. Every nontrivial GHZ bipartition has Schmidt rank two. No arbitrary-state compression claim follows.

## XBR-02 — Hermitian energies and ground-space fidelity

**Pass.** Hermitian symmetrization, basis relabeling and Rayleigh convex combination are correct. Separating the entire ground eigenspace gives the stated gap inequality, including degeneracy. For mixed rho, the positive-semidefinite spectral difference has nonnegative trace against rho, proving the density version without requiring commutation. Ground-state population uses the squared-fidelity convention for a pure target.

## XBR-03 — VQD overlap penalties

**Pass with the stated energy ordering.** Exact normalized mutually orthogonal prior eigenvectors produce rank-one diagonal shifts. With eigenvalues ordered nondecreasingly, beta_i>E_k-E_i raises every previous eigenvalue above the least remaining one E_k. Degenerate target subspaces are allowed. The result does not apply unchanged to inaccurate prior vectors, a restricted ansatz or unsuccessful local optimization.

## XBR-04 — Gradient, inverse gates and parameter shift

**Pass.** The two differentiated expectation terms are conjugates for fixed Hermitian H; parameter-dependent H requires the additional term. P²=I gives the two-term rotation expansion; a single occurrence produces A+B cos(t)+C sin(t), whose symmetric pi/2 shift gives the derivative. Shared parameters require summing gate occurrences. Runtime gains are explicitly empirical rather than proved here.

## XBR-05 — Scaling and projective residual

**Pass.** Complex normalization changes only the global phase. Orthogonal projection yields the residual norm and ray-distance identity for nonzero vectors. Component scaling preserves normalized direction exactly and avoids the original huge squares; no blanket finite-precision guarantee follows. SOP norm expansion correctly retains cross terms.

## XBR-06 — Affine channel, fixed point and precision

**Pass.** The stated channel order gives coefficients a=(1-eta)(1-p), b=(1-eta)p, c=eta. They sum to one and are nonnegative. Outside the identity case, b+c>0 gives a unique fixed density; differences contract by a and iteration follows by induction. Scaled weights multiply back to b,c. For p=eta=q>0 and pure zero target, exact diagonal is (3/4+q/(8-4q),1/4-q/(8-4q)); binary64 (.75,.25) is a rounded result. The conditional per-step error bound is not claimed as an established implementation certificate.

## XBR-07 — Boolean clauses and diagonal operators

**Pass.** Products of false-literal indicators count violated clauses. Repeated literals use Boolean idempotence; complementary literals make a tautology; empty product gives the unsatisfied empty clause. Factorized expectations require distinct independent bits. The two-bit diagonal example and three-bit Pauli product each select the stated assignment. A three-body product is not silently reduced to a pairwise operator.

## XBR-08 — Scientific and foundational limits

**Pass within stated scope.** The eight bridge records, five worked lessons, six foundation sections and proof appendix were read. Elementary identities are separated from historical measurements, source availability, formal error certificates, optimization guarantees and open project research questions. The finite-dimensional spectral theorem and other cited background are imported; no claim to prove all cited literature or close all eight research questions is made.

## Precision clarifications

- XBR-F01: Resolved in bound text. Explicitly order eigenvalues E0<=...<=E(d-1) in appendix section 3 before asserting Ek is the least unshifted eigenvalue. The surrounding earlier-level terminology already indicates this intended ordering.
- XBR-F02: Resolved in bound text. In F06 call Tr(P0 rho) the ground-state population or squared fidelity with the pure target, rather than squared-overlap fidelity for a general mixed rho. Appendix section 8 already makes this convention explicit.

## External checks and limits

The exact-eigenstate penalty argument was compared with [Higgott, Wang and Brierley, Section III](https://arxiv.org/html/1805.08138v2). The spectral inequality was compared with [Hangleiter and colleagues, Lemma 2](https://arxiv.org/html/1602.00703v4). These targeted checks do not audit every claim in the cited papers.

- No historical benchmarks or experiments rerun.
- No independent verification of the project timing/data provenance in this mathematical cross-review.
- No proof-assistant verification or outside peer review.
- No general numerical error bound or algorithmic convergence guarantee established beyond the explicit conditional statements.
