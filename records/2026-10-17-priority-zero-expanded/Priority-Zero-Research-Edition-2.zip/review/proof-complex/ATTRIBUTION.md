# Attribution and modifications

Project direction and collection attribution: **Sherman G. Laing / Quantum.Earth.Laing**. Current primary project agent: **GAUCIA Actual**. Supporting selection, editorial preparation, software adaptation and review: **Codex**. Applicable earlier ChatGPT/AI assistance and third-party source notices remain attached. Current roles are not backdated to earlier work.

This October 16, 2026 edition contains new research summaries and selected technical sources. Summaries describe aims, model dimensions, methods, outcomes, limits and corrections. They are editorial derivatives, not verbatim historical dialogue. Dated mathematical teaching manuscripts reconstruct established results and retain their existing proof-audit limitations. Original numerical sources and data keep their component attribution; portable adapters and new explanatory files are identified as preparation work.

The package manifest identifies these derivative bytes. It does not authenticate historical authorship, independently certify dates, establish novelty, or imply endorsement by source maintainers. Detailed source-to-derivative records are maintained separately from this reading edition.

Retain the complete [license](LICENSE.md), [edition scope](LICENSE_SCOPE.md), attribution and applicable component notices with redistributed material. Credit alone does not authorize uses outside the license grant.


## Mathematical revision

The October 16, 2026 complex-analysis proof review, explicit prerequisite appendix, coverage matrix and errata were prepared by Codex as supporting reviewer. The historical chapter retains its GAUCIA Actual attribution and September 20, 2026 date. The added explanations concern established mathematics; no new ownership or novelty claim over theorems is made. The project license applies only within its stated rights and scope.
