# Changes and preservation

Twenty entries record hypothesis clarifications, supplied elementary arguments, and review-status updates. They are not twenty false theorems or failed exercise answers. Exact before/after passages are in ERRATA.json; CHANGES.patch provides the unified diff. The 733-line source remains byte-identical in preservation/.

## CA-E01 — review status update

Original lines: [1, 1]. Replace the former pending-review statement with the actual bounded mathematical-review scope.

## CA-E02 — missing dependency exposition supplied

Original lines: [9, 9]. The earlier volume is not in this selection; the needed elementary complex lemmas now have explicit proofs.

## CA-E03 — hypothesis clarification

Original lines: [15, 15]. Positive radius is required for ordinary circle parametrizations and denominators R.

## CA-E04 — subsidiary proof supplied

Original lines: [37, 37]. Make the previously referenced sufficient theorem and its failed hypothesis inspectable.

## CA-E05 — hypothesis clarification

Original lines: [70, 70]. Uniform convergence alone does not define the integrals unless the integrability/continuity of the approximants is stated.

## CA-E06 — missing subsidiary example supplied

Original lines: [350, 350]. Provide the claimed real-analysis counterexample and proof locally.

## CA-E07 — dependency clarification

Original lines: [409, 409]. Make clear that holomorphy of the shifted quotient series is a proved general power-series fact, not an assumption of Cauchy’s formula.

## CA-E08 — proof detail supplied

Original lines: [441, 441]. Explicitly pass from local disk estimates to arbitrary compact subsets and keep derivative order fixed.

## CA-E09 — proof detail supplied

Original lines: [463, 463]. State the continuity step and distinct-zero accumulation before using isolated-zero factorization.

## CA-E10 — proof detail supplied

Original lines: [512, 512]. Justify that the boundary maximum is over a nonempty compact set in the bounded-domain case.

## CA-E11 — algebraic dependency supplied

Original lines: [535, 535]. Supply the division step rather than leave an algebraic prerequisite implicit.

## CA-E12 — subsidiary uniqueness proof supplied

Original lines: [582, 582]. Justify that pole order and residue are well-defined under the stated finite-principal-part definition.

## CA-E13 — boundary case clarification

Original lines: [598, 598]. Avoid duplicate pole counting and include the zero-pole case explicitly.

## CA-E14 — exercise hypothesis clarification

Original lines: [616, 616]. State the radius condition of the circle exercise.

## CA-E15 — exercise hypothesis clarification

Original lines: [634, 634]. Explicitly retain nonempty open connected domain hypotheses in the logarithm exercise.

## CA-E16 — exercise boundary clarification

Original lines: [706, 706]. Separate positive-radius ratio estimates from the harmless zero-radius case.

## CA-E17 — exercise solution completion

Original lines: [712, 712]. Resolve the zero-radius boundary without an implicit 0^0 convention in the derivative bound.

## CA-E18 — review scope update

Original lines: [733, 733]. Replace obsolete pending language while keeping the distinction between full chapter review and external certification.

## CA-E20 — version role clarification

Original lines: [729, 729]. Distinguish the earlier unchanged preparation copy from this revised derivative; preserve both earlier wording and exact source bytes.

## CA-E19 — new prerequisite and subsidiary proof appendix

Original lines: new appendix after original text. Supply explicit elementary proofs and declare foundations instead of depending on an absent volume.

## Reviewer draft correction

The first reviewer appendix used a straight-segment real chain rule in the Cauchy–Riemann sufficient proof while listing only one-variable FTC as its immediate calculus premise. The final proof uses two coordinate-segment FTC integrals, avoiding that extra implicit prerequisite. The first derivative and its exact errata remain in preservation/initial-review-derivative.md and preservation/initial-review-errata.json. This was a tightening of the reviewer’s exposition, not a counterexample to the theorem.
