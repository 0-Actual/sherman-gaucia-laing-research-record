# Explicit dependencies and reference checks

Reviewed October 16, 2026. This record distinguishes imported foundations, arguments proved in the chapter, and targeted reference checks. It does not imply an audit of every page in a cited text.

## Foundational results assumed

The ordered complete real field and elementary plane geometry; ordinary real limits, differentiation and the fundamental theorem of calculus for continuous integrands; finite-dimensional compactness and its consequences (attained extrema and uniform continuity); elementary real exponential, logarithm and trigonometric functions including their derivatives, periodicity and polar representation; elementary convergent-series facts including the geometric/ratio comparison, absolute Cauchy products and binomial identity; elementary finite polynomial identities. Integration acts separately on real and imaginary components.

These remain prerequisite mathematics. The review does not derive them from axioms. Appendix A explicitly supplies the complex sum/product/quotient/chain rules, the continuous-partial Cauchy–Riemann implication, general complex power-series differentiation, the complex exponential and its kernel, and the smooth real flat-function counterexample. Those are proved using the listed real prerequisites without relying on the later Cauchy theorems.

## Checked dependency order

1. Complex derivative and real path integration give continuity, ML bounds and primitive integration.
2. Goursat subdivision proves triangle integration without assuming derivative continuity. The continuous exceptional-point variant allows a divided difference before it is known to be holomorphic at its center.
3. Triangle integration gives local primitives. A finite grid of local primitives proves continuous homotopy invariance; simple connectedness gives global path independence and primitives.
4. Direct geometric-series kernel integration plus the exceptional-point primitive gives the disk Cauchy formula.
5. The disk formula gives Taylor series and coefficient bounds. Uniform derivative-series convergence and real segment FTC give analyticity and higher derivatives, rather than assuming them in the earlier stages.
6. Taylor coefficients give removable singularities, isolated zeros and residue coefficients. Morera uses the now-proved holomorphy of derivatives; locally uniform convergence then follows without a circular invocation of Morera earlier.
7. Cauchy estimates give Liouville and polynomial-growth rigidity. Liouville gives root existence; a finite telescoping identity gives factorization.
8. The elementary exponential kernel makes the winding integral an integer. Subtracting finitely many principal parts and applying simply connected Cauchy yields the stated finite-pole residue theorem.

## Primary or official reference checks

- **REF-MIT-3:** Jeremy Orloff, MIT 18.04 Topic 3, [Line integrals and Cauchy’s theorem](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/1968cab6de7c96ead1c83001459a007b_MIT18_04S18_topic3.pdf). Checked the contour definition, primitive/endpoint theorem, path independence and simply connected Cauchy statement, including the note allowing nonsimple closed curves. This confirms corresponding statement scope; the manuscript provides its own Goursat and homotopy arguments.
- **REF-MIT-4:** Jeremy Orloff, MIT 18.04 Topic 4, [Cauchy’s integral formula](https://ocw.mit.edu/courses/18-04-complex-variables-with-applications-spring-2018/b1a90df19f643b974555bbbb93138a48_MIT18_04S18_topic4.pdf). Checked the integral and derivative formulas, their inside-contour assumption and factorial normalization. The selected chapter uses a disk version with an explicit neighborhood of the closed disk.
- **REF-TCD:** Dmitri Zaitsev, author-hosted [Complex Analysis lecture notes](https://www.maths.tcd.ie/~zaitsev/23204-2022/ca-notes.pdf), sections 12.2–12.3, 13.2 and 16.4. Checked the triangle-to-primitive construction and general power-series differentiation framework, and compared the stated residue scope. The manuscript deliberately proves only the finite-pole theorem on a simply connected domain, not the notes’ more general homological theorem.

The linked documents were opened during the October 16 review. The two MIT notes were already cited by the retained manuscript; the Trinity notes were added for this review. Targeted extracted PDF text was inspected; no successful independent visual audit of all PDF equations or complete-book proof audit is asserted. The mathematical review also directly checked the manuscript’s equations and arguments, rather than treating a citation as a substitute for proof.

## Outside the claim set

General Laurent expansions, essential-singularity residue theory, general homological Cauchy theorems, Riemann mapping and later complex-analysis topics are expressly outside this selected chapter. Their absence is not an omitted proof of a result claimed here. Historical origin, authorship, mathematical novelty and legal priority are also not certified by this proof review.
