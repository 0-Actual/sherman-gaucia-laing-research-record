# Cross-review of the advanced chapter

Result: **pass within the declared proof scope**. Exact artifact SHA-256: `9f6d349fced3ba5c4191d63820792d56809ecbe9aa83d44632d0af36b5a3dd47`.

Read the corrected chapter and the new/substantive proofs, including all 21 worked examples and 12 exercises. Targeted independent reasoning emphasizes the nine groups below. This is not a second full claim-by-claim matrix or a full audit of every cited external work.

The one requested clarification, A29, is resolved: the entropy inequality now explicitly includes zero-probability outputs through a support-restricted sum. It does not change the capacity conclusion.

## XADV-01 — Finite Kraft converse and entropy

**Pass after A29.** Sorted nonnegative lengths and disjoint descendant sets imply an available node at every step. A zero-length word excludes all others and the framing limit is stated. The support-restricted Gibbs sum is <=0 even when p has zero masses; rearrangement yields the prefix-code bound. The BSC upper bound therefore covers degenerate output probabilities.

## XADV-02 — Convexity, descent and KKT

**Pass.** Supporting-plane equivalence, descent estimate and telescoping rate have correct signs and quantifiers. KKT sufficiency uses convexity on a common open domain, nonnegative multipliers and complementary slackness. Slater necessity is imported with finite value and separate primal-attainment condition; it does not claim attainment from Slater alone.

## XADV-03 — Coding and complexity scope

**Pass.** Hamming distance and syndrome calculations agree. Channel coding remains imported for a finite memoryless model. Polynomial-time implication for an NP-complete decision problem requires all encoded inputs, deterministic correctness and worst-case polynomial time. Indexed literal verification is distinguished from machine-independent linear cost.

## XADV-04 — Measure, projection and heat series

**Pass.** Dyadic intervals prove no common integrable dominator for the spikes. Finite projection and coefficient calculations are consistent. For each fixed derivative order, square-summable Fourier coefficients and Gaussian decay bound derivatives uniformly away from t=0. Parseval and dominated convergence give L2 initial convergence; no unjustified pointwise recovery is asserted.

## XADV-05 — Geodesic variation and curvature

**Pass.** The two Euler–Lagrange terms, symmetrization and inverse-metric contraction produce the Christoffel equation. Affine parameter and constant speed are distinguished from arbitrary reparameterization. Local minimizing behavior, the variational fundamental lemma and the shape-operator identity are identified imports. Sphere normal differential and signs give curvature 1/R².

## XADV-06 — Luders instrument assumption

**Pass.** The posterior vector is correctly conditional on positive outcome probability and the ideal projective instrument. Projection probabilities alone do not uniquely choose the posterior state. An outcome-subspace unitary is a valid counterexample to uniqueness without changing those probabilities.

## XADV-07 — Marginals and no-signaling

**Pass.** Bell-state partial trace removes off-diagonal terms and gives I/2. Cyclicity and sum A†A=I preserve the other marginal for an unconditioned local trace-preserving map. Conditional outcome statistics and communication are kept separate.

## XADV-08 — Finite-channel exact no-cloning

**Pass.** Kraus completeness makes the displayed V an isometry. A pure output density implies every Kraus output lies on the same ray because sums of nonnegative orthogonal squared components vanish. Environment vectors are normalized; overlap preservation gives r=r² times an environment overlap magnitude <=r², impossible for 0<r<1. Exact, deterministic and state-independent scope is explicit; fixed auxiliary systems and discarded environments are covered by the imported channel representation.

## XADV-09 — Periodic fluid energy and exercises

**Pass in stated scope.** Periodic velocity and pressure, smoothness and incompressibility justify the integration-by-parts cancellations. The identity is not a global-regularity proof. All 21 examples and 12 exercise solutions were read; the finite computations, normalization, signs and boundary conditions are consistent. This reviewer did not rerun the other reviewer’s numerical check script.

## External and review boundaries

Targeted checks used [Watrous, Chapter 2, Corollary 2.27](https://cs.uwaterloo.ca/~watrous/TQI/TQI.2.pdf) for finite channels and [Boyd and Vandenberghe, Section 5.2.3](https://web.stanford.edu/~boyd/cvxbook/bv_cvxbook.pdf) for Slater scope. These sources support the imported premises, not a claim that the whole books were audited.

- No proof-assistant verification or independent external peer review.
- No re-run of experiments or claim of new mathematical results.
- Other reviewer’s full reference retrieval and current frontier classifications were not independently repeated in this cross-review.
- Imported foundational theorems are identified premises rather than locally proved results.
