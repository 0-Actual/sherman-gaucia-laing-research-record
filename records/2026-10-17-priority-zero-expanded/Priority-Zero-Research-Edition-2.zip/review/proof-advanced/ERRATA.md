# Advanced mathematics — before/after errata

All prior wording remains in the unchanged preservation copy. A correction is not automatically a failed theorem or failed experiment. The instrument assumption and complexity quantifier are substantive wording corrections; most entries supply derivations, explicit boundaries or current review status.

## A01 — review-status correction

Source lines: [1, 1]. Replace the preparation-stage pending statement only in this new derivative; retain the exact old edition.

Before:

Prepared research-review derivative, October 16, 2026. The retained teaching manuscript is dated September 20, 2026. Its mathematical content reconstructs established results; no original solution to an open problem or independent proof certification is claimed. A complete proof audit remains pending. References to earlier volumes denote prerequisites; those volumes are not supplied by this selection.

After:

Corrected mathematical teaching derivative — October 16, 2026. The complete 573-line selected manuscript, all 21 worked examples and all 12 exercises have been reviewed, including assumptions, proof steps and boundary cases. This is a bounded mathematical review, not formal proof-assistant verification, independent certification, or a proof of any open problem. Imported theorems remain explicitly identified. The unchanged prior manuscript and exact before/after errata are retained alongside this derivative. Earlier volumes remain outside this selection.

## A02 — domain clarification

Source lines: [13, 13]. The logarithm requires a nonempty alphabet; bit-string length is a nonnegative integer.

Before:

A finite set with $N$ members requires

After:

For integers $N\ge1$ and $b\ge0$, a finite set with $N$ members requires

## A03 — missing derivation and framing boundary

Source lines: [40, 40]. Supply the branch-count induction and the zero-length-stream boundary, rather than relying on a construction sketch.

Before:

This proves the necessary part of Kraft's inequality for finite binary prefix codes. Conversely, any finite list of nonnegative integer lengths satisfying this inequality can be realized by a prefix code. One construction orders lengths increasingly and assigns still unused binary-tree branches. At each level, the Kraft bound ensures enough branches remain. This construction also explains the exceptional length-zero code: it can occur only when it is the sole codeword.

After:

This proves necessity for finite binary prefix codes. For sufficiency, take a nonempty finite list of nonnegative integer lengths and order them $\ell_1\le\cdots\le\ell_m$. Suppose the first $j-1$ codewords have been chosen prefix free. At depth $\ell_j$ they block exactly $B=\sum_{i<j}2^{\ell_j-\ell_i}$ nodes, since their descendant sets are disjoint. Kraft's inequality for the first $j$ terms gives $B+1\le2^{\ell_j}$. At least one node remains free; choose it as word $j$. It has no earlier word as a prefix, and cannot be a prefix of a shorter earlier word. Induction constructs the whole code. If a length is zero, its contribution is one, so no other finite length can occur. The sole empty word needs a known block length or external framing to recover a variable number of repeated symbols; for the one-symbol alphabet or fixed-block problem here, that framing is known.

## A04 — missing elementary derivation

Source lines: [42, 42]. Make the inequality and normalization premises explicit.

Before:

We can derive an average-length lower bound rather than merely quote it.

After:

We can derive an average-length lower bound rather than merely quote it. The inequality $\ln t\le t-1$ for $t>0$ follows because $t-1-\ln t$ has derivative $1-1/t$ and its minimum zero at $t=1$. The alphabet is finite and nonempty, so the Kraft sum below is strictly positive.

## A29 — cross-review zero-probability proof clarification

Source lines: [42, 45]. Independent cross-review requested an explicit support-restricted Gibbs argument so the later comparison with a uniform output distribution also covers zero-probability output symbols. The earlier positive-probability statement was correct in its stated scope.

Before:

For positive $p_i$, the inequality $\ln t\le t-1$ gives

$$\sum_i p_i\ln\frac{q_i}{p_i}
\le \sum_i p_i\left(\frac{q_i}{p_i}-1\right)=0.$$

After:

More generally, let $p$ be any probability vector on the finite alphabet and let $q_i>0$ with $\sum_iq_i=1$; the displayed code-derived $q$ has these properties. Put $S=\{i:p_i>0\}$. The inequality $\ln t\le t-1$ gives

$$\sum_{i\in S}p_i\ln\frac{q_i}{p_i}
\le\sum_{i\in S}p_i\left(\frac{q_i}{p_i}-1\right)
=\sum_{i\in S}q_i-1\le0.$$

## A05 — missing derivation

Source lines: [59, 59]. State the product-probability argument used by the block-code bound.

Before:

For $n$ independent identically distributed finite-alphabet symbols, joint entropy is $nH(X)$.

After:

For $n\ge1$ independent identically distributed finite-alphabet symbols, joint entropy is $nH(X)$. Indeed, on positive-probability strings $p(x_1,\ldots,x_n)=\prod_jp(x_j)$, so $-\log_2p(x_1,\ldots,x_n)=\sum_j-\log_2p(x_j)$. Taking the finite expectation gives $\sum_jH(X_j)=nH(X)$. Zero-probability strings contribute zero.

## A06 — missing inference

Source lines: [85, 85]. Connect the weight calculation to the asserted distance.

Before:

No nonzero word of weight one lies in $C$,

After:

Because $C$ is linear, $c-c^\prime$ ranges over its nonzero words for distinct codewords, and $d(c,c^\prime)$ is the Hamming weight of $c-c^\prime$. Thus minimum distance equals minimum nonzero weight. No nonzero word of weight one lies in $C$,

## A07 — definition and scope clarification

Source lines: [109, 109]. Specify the rate, error distribution and zero-probability convention; retain the imported coding theorem.

Before:

For rates strictly below $C$, sufficiently long block codes exist whose average decoding-error probability tends to zero.

After:

Here $p(y)=\sum_xp(x)W(y\mid x)$, and summands with zero joint probability are defined to contribute zero. A code with $M_n$ equiprobable messages and $n$ channel uses has rate $n^{-1}\log_2M_n$ bits per use; average error is averaged over these messages and the channel. For every fixed $0\le R<C$, a sequence of codes with asymptotic rate at least $R$ and average decoding-error probability tending to zero exists.

## A08 — missing derivation

Source lines: [111, 111]. Supply the entropy identities needed for the capacity upper bound; no new channel theorem is claimed.

Before:

**Worked example 5 — binary symmetric channel.**

After:

The identity $I(X;Y)=H(Y)-H(Y\mid X)$ used below follows by expanding the displayed logarithm as $\log_2W(y\mid x)-\log_2p(y)$ and summing. Also $H(Y)\le\log_2m$ for an $m$-symbol output: apply the previously proved divergence inequality to $p_Y$ and the uniform distribution $q_y=1/m$ to obtain $D(p_Y\Vert q)=\log_2m-H(Y)\ge0$.

**Worked example 5 — binary symmetric channel.**

## A09 — missing sufficiency proof and theorem scope

Source lines: [175, 175]. Supply KKT sufficiency and separate Slater, dual attainment and primal attainment.

Before:

Necessity and equality of primal and dual optima require further conditions, for example an appropriate strict-feasibility condition; they are not automatic for arbitrary constrained problems.

After:

For the sufficiency claim, let $(x_*,\lambda_*,\nu_*)$ satisfy these conditions on a common open convex domain $D$ with every feasible point in $D$. The function $\mathcal L(\cdot,\lambda_*,\nu_*)$ is convex, and stationarity makes $x_*$ its global minimizer on $D$. For feasible $y$,

$$f(y)\ge\mathcal L(y,\lambda_*,\nu_*)\ge\mathcal L(x_*,\lambda_*,\nu_*)=f(x_*),$$

where the final equality uses feasibility and complementary slackness. This proves sufficiency. The infimum defining the dual is over the common domain $D$, or all of $\mathbb R^n$ when the functions are defined there.

For necessity, a useful imported theorem is Slater's theorem: in a convex problem, strict feasibility in the relative interior of the common domain, together with a finite optimal value, ensures zero duality gap and dual attainment. At an attained primal optimum in the differentiable open-domain setting, KKT multipliers then exist. This is a sufficient constraint qualification, not a necessary condition for every problem, and it does not itself guarantee primal attainment. The general relative-interior and affine-constraint refinements are in Boyd and Vandenberghe, Sections 5.2.3 and 5.5.3; they are not proved here.

## A10 — complexity quantifier correction

Source lines: [217, 217]. A fast instance or an unspecified notion of fast is not the required universal polynomial-time algorithm.

Before:

A fast solution of one NP-complete problem would imply P=NP.

After:

A deterministic algorithm that correctly decides every instance of one NP-complete decision problem in polynomial worst-case time, measured in the encoded input length, would imply P=NP.

## A11 — cost-model clarification

Source lines: [223, 223]. Make the random-access premise explicit rather than claiming linear time in every computational model.

Before:

Each clause can be checked by reading its literals, so verification takes time proportional to the formula's written length.

After:

With indexed access to the supplied assignment, verification requires one lookup per literal occurrence and therefore linear work in the number of written literals. With standard finite bit encodings, the indexing and parsing costs still give a polynomial-time verifier; a machine-independent exact linear-time bound is not asserted.

## A12 — missing counterexample proof

Source lines: [255, 255]. Prove the missing hypothesis directly rather than relying only on the failed conclusion of dominated convergence.

Before:

The sequence is not increasing and has no single integrable dominating function.

After:

The sequence is not increasing: for example, at $x=3/4$, $f_1(x)=1$ but $f_2(x)=0$. Nor can a single integrable $g\ge0$ dominate every $f_n$ almost everywhere. On each disjoint interval $(2^{-(k+1)},2^{-k})$, $f_{2^k}=2^k$ and hence $\int g\ge\sum_{k=0}^K2^k2^{-(k+1)}=(K+1)/2$ for every $K$. The countable union of the exceptional null sets is still null. Letting $K$ increase proves the required integral is infinite.

## A13 — external-dependency clarification

Source lines: [265, 265]. Identify a foundational imported theorem omitted from the original proof-status list.

Before:

Mere square-integrable pointwise functions without this identification would not yet give an inner product.

After:

Mere square-integrable pointwise functions without this identification would not yet give an inner product. Completeness of this quotient space is a further established theorem being used here; the finite projection proof below does not prove completeness of $L^2$.

## A14 — missing full-series derivation

Source lines: [302, 302]. Close the explicitly left-open convergence check in the finite teaching setting.

Before:

To justify a full infinite-series solution, one must check convergence and differentiation conditions; each individual mode already verifies the equation exactly.

After:

Each individual mode verifies the equation exactly. Here is a bounded full-series justification: if the initial periodic datum $f$ lies in $L^2$ and has coefficients $c_n$, define $u(t,x)=\sum_{n\in\mathbb Z}c_ne^{-\kappa n^2t}e^{inx}$. For any $\varepsilon>0$ and nonnegative integers $r,q$, Cauchy–Schwarz bounds the absolute sum of the $r$ spatial and $q$ time derivatives, uniformly for $t\ge\varepsilon$, by

$$\left(\sum_n|c_n|^2\right)^{1/2}
\left(\sum_n |n|^{2r}(\kappa n^2)^{2q}e^{-2\kappa n^2\varepsilon}\right)^{1/2}<\infty,$$

with the zero-frequency term interpreted by direct differentiation (for $r=q=0$ it contributes one to the second sum). Exponential decay makes every such weighted sum finite. Uniform convergence of the derivative series on positive-time strips justifies termwise differentiation, giving the heat equation for $t>0$. Parseval and dominated convergence for the summable series $4\sum|c_n|^2$ give $\|u(t,\cdot)-f\|_2^2=\sum|c_n|^2|e^{-\kappa n^2t}-1|^2\to0$ as $t\downarrow0$. This uses the imported Fourier-completeness theorem and standard termwise-differentiation theorem; it does not assert pointwise recovery of arbitrary $L^2$ initial data.

## A15 — missing variational derivation and theorem classification

Source lines: [345, 345]. Expand the advertised Euler–Lagrange derivation and identify the separate local-minimality dependency.

Before:

This follows by applying the Euler–Lagrange equations to the energy $\tfrac12\int g_{ij}\dot x^i\dot x^jdt$. Energy-stationary curves with this parameterization are geodesics. A geodesic is locally length minimizing on sufficiently short segments, but need not minimize length between distant endpoints.

After:

For completeness, write the energy integrand as $\mathscr E=\tfrac12\sum_{i,j}g_{ij}\dot x^i\dot x^j$. Smooth fixed-endpoint variations give the Euler–Lagrange equations. In coordinates,

$$\frac{d}{dt}\frac{\partial\mathscr E}{\partial\dot x^\ell}
=\sum_jg_{\ell j}\ddot x^j+\sum_{i,j}(\partial_i g_{\ell j})\dot x^i\dot x^j,
\qquad
\frac{\partial\mathscr E}{\partial x^\ell}
=\frac12\sum_{i,j}(\partial_\ell g_{ij})\dot x^i\dot x^j.$$

Subtract, symmetrize the $i,j$ product and multiply by $g^{k\ell}$. This gives exactly the displayed geodesic equation. The elementary first-variation argument uses integration by parts on variations vanishing at the endpoints and the fundamental lemma of the calculus of variations. Substitution in $d(\sum g_{ij}\dot x^i\dot x^j)/dt$ gives zero, so the speed is constant. These are energy-stationary curves with an affine parameter; arbitrary nonlinear reparameterizations need not satisfy this equation.

The further local length-minimizing property uses the normal-neighborhood/Gauss-lemma theorem, imported here. It holds on sufficiently short segments; it does not imply length minimization between distant endpoints.

## A16 — missing curvature calculation

Source lines: [349, 349]. Show how the spherical curvature value follows from the normal field while identifying the surface-curvature identity.

Before:

For a round sphere, $K=1/R^2$ and area $4\pi R^2$,

After:

For a round sphere, the unit normal is $N(r)=r/R$, so its differential on tangent vectors is $dN(v)=v/R$. With shape-operator convention $S=-dN$, both principal curvatures are $-1/R$, and their product is $K=1/R^2$ (the Gaussian-curvature/shape-operator identity is the standard surface formula being used). The area is $4\pi R^2$,

## A17 — substantive instrument-assumption correction

Source lines: [360, 360]. Avoid identifying a general projective outcome distribution with one uniquely determined posterior-state rule.

Before:

For an observed outcome of positive probability, the corresponding normalized post-measurement state is $P_j\psi/\sqrt{\langle\psi,P_j\psi\rangle}$.

After:

For an ideal Lüders projective measurement, an observed outcome of positive probability has normalized post-measurement state $P_j\psi/\sqrt{\langle\psi,P_j\psi\rangle}$. The projection probabilities alone do not uniquely specify a physical measurement instrument: a unitary within a degenerate outcome subspace may change the posterior state while leaving these probabilities unchanged. The displayed update therefore assumes the ideal Lüders instrument, rather than following from the probabilities alone.

## A18 — quantum model scope clarification

Source lines: [355, 355]. Finite-dimensional is the mathematical assumption; a physically finite system need not have finite-dimensional state space.

Before:

For a finite isolated quantum system, a pure state

After:

For an isolated quantum system modeled by a finite-dimensional Hilbert space, a pure state

## A19 — missing partial-trace and no-signaling derivation

Source lines: [391, 391]. Distinguish correlations, marginal statistics and communicated conditional outcomes.

Before:

The joint state is pure even though each reduced state is mixed.

After:

The joint state is pure even though each reduced state is mixed. Explicitly,

$$\rho_{AB}=\tfrac12\sum_{i,j=0}^1|i\rangle\langle j|\otimes|i\rangle\langle j|,
\qquad\operatorname{tr}_B\rho_{AB}=\tfrac12\sum_{i,j}|i\rangle\langle j|\,\delta_{ij}=I/2.$$

The broader no-signaling statement concerns an unconditioned local trace-preserving operation. If $A_a$ are its Kraus operators on the first system and $\sum_a A_a^\dagger A_a=I$, then for any observable $B$ on the second system,

$$\sum_a\operatorname{tr}\!\left[(A_a\otimes I)\rho_{AB}(A_a^\dagger\otimes I)(I\otimes B)\right]
=\operatorname{tr}[\rho_{AB}(I\otimes B)].$$

Cyclicity of the full trace and the Kraus normalization give the equality. Thus the second marginal is unchanged. Conditioning on a reported outcome can change conditional statistics, but conveying that outcome requires communication. The finite-dimensional Kraus representation of a general quantum channel is an imported theorem; the displayed trace calculation proves the consequence once that representation is given.

## A20 — scope clarification and channel extension

Source lines: [399, 399]. The earlier unitary proof is sound but narrower than the general physical-operation formulation; state the additional imported premise and derive the extension.

Before:

Orthogonal states can be copied by an appropriate operation, so the word “unknown” and the unrestricted choice of state are essential to the theorem.

After:

Orthogonal states can be copied by a fixed operation: the vectors $|j\rangle|b\rangle$ and $|j\rangle|j\rangle$ are two orthonormal lists, so a map taking one to the other extends to a unitary by completing orthonormal bases. The theorem concerns a single state-independent device, exact output, deterministic success and a set containing nonorthogonal pure states. It does not forbid preparing copies from a classical description, approximate copies, or successful outcomes of appropriately restricted probabilistic procedures.

The finite-channel extension also includes an auxiliary system or discarded environment. Import the Kraus representation $\Phi(\rho)=\sum_aK_a\rho K_a^\dagger$, $\sum_aK_a^\dagger K_a=I$, for a deterministic finite-dimensional quantum channel. Define $V\psi=\sum_a K_a\psi\otimes|a\rangle$; then $V^\dagger V=I$. If the two output systems are exactly in $|\psi\psi\rangle$, each vector $K_a\psi$ must be parallel to $|\psi\psi\rangle$: for every vector $w$ orthogonal to that ray, $\sum_a|\langle w,K_a\psi\rangle|^2=0$. Hence $V\psi=|\psi\psi\rangle\otimes|a_\psi\rangle$ with $\|a_\psi\|=1$. For two input states, inner-product preservation and Cauchy–Schwarz give

$$r=|\langle\psi,\phi\rangle|
=r^2|\langle a_\psi,a_\phi\rangle|\le r^2.$$

This is impossible when $0<r<1$. Thus adding a fixed auxiliary system or discarding an environment cannot produce a deterministic exact cloner for arbitrary pure states. The channel-representation theorem is imported; the implication from it is proved here. See [Watrous, The Theory of Quantum Information, Chapter 2](https://cs.uwaterloo.ca/~watrous/TQI/TQI.2.pdf) for representations and [IBM Quantum Learning, limitations](https://quantum.cloud.ibm.com/learning/en/courses/basics-of-quantum-information/quantum-circuits/limitations-on-quantum-information) for the elementary theorem.

## A21 — dated source verification

Source lines: [407, 407]. Separate the old claimed lookup from the actually observed current classifications.

Before:

The [Clay Mathematics Institute problem list](https://www.claymath.org/millennium-problems/), checked on 20 September 2026, classifies Poincaré as **Solved**, Navier–Stokes as **Active**, and Birch–Swinnerton-Dyer, Hodge, P versus NP, Riemann, and Yang–Mills/mass gap as **Unsolved**. The “Active” label is preserved here exactly; it is not silently converted into either “Solved” or “Unsolved.” This study does not certify any proposed new proof.

After:

The retained manuscript reports a September 20, 2026 check. In this review, the [Clay Mathematics Institute problem list](https://www.claymath.org/millennium-problems/) was retrieved on October 16, 2026 and displayed Poincaré under **Solved**, Navier–Stokes under **Active**, and Birch–Swinnerton-Dyer, Hodge, P versus NP, Riemann, and Yang–Mills/mass gap under **Unsolved**. These are the page's dated category labels; “Active” is not evidence that a new proof has been accepted. This retrieval does not independently authenticate the earlier check or certify any proposed proof.

## A22 — frontier quantifier clarification

Source lines: [416, 416]. State the universal group quantifier, domain and axiomatic requirement from the official formulation.

Before:

Can the required nontrivial four-dimensional quantum Yang–Mills theory be constructed with a positive mass gap for compact simple gauge groups?

After:

For every compact simple gauge group, does a nontrivial quantum Yang–Mills theory on $\mathbb R^4$ exist with the required axiomatic properties and a positive mass gap?

## A23 — frontier version clarification

Source lines: [414, 414]. Distinguish the rank statement from the separately described refined version instead of conflating their presentation.

Before:

Does the rank of an elliptic curve over the rationals equal the order of vanishing of its $L$-function at $s=1$, together with the refined leading-term statement?

After:

Does the rank of an elliptic curve over the rationals equal the order of vanishing of its $L$-function at $s=1$? A refined version also specifies the leading coefficient.

## A24 — exercise boundary clarification

Source lines: [514, 514]. State the radius and colatitude domain needed for the cap formula.

Before:

**Problem.** On a sphere of radius $R$, compute the area of the cap $0\le\theta\le\theta_0$.

After:

**Problem.** On a sphere of radius $R>0$, for $0\le\theta_0\le\pi$, compute the area of the cap $0\le\theta\le\theta_0$.

## A25 — attribution-evidence limit

Source lines: [558, 558]. Do not present an earlier provenance assertion as an independently verified originality result.

Before:

The exposition, numerical choices, derivations and practice solutions in this volume are newly written; no source's exercise solutions have been copied.

After:

The retained source describes its exposition and practice solutions as newly written. This review checks the mathematics and cited dependencies; it does not independently certify originality or conduct an exhaustive textual-similarity search. Established results remain attributed to their mathematical literature.

## A26 — proof-status correction

Source lines: [560, 560]. Complete the imported-theorem inventory instead of overstating proof self-containment.

Before:

The channel-coding theorem, incompleteness machinery, general convergence theorems, Fourier completeness, and Gauss–Bonnet are clearly identified as results used or outlined rather than falsely represented as fully proved in this volume.

After:

The channel-coding theorem, incompleteness machinery, general measure-convergence theorems, $L^2$ completeness, Fourier completeness and piecewise-smooth pointwise convergence, Slater necessity, normal-neighborhood local minimality, surface-curvature identity, Gauss–Bonnet and general quantum-channel representation remain imported results. The new derivations prove the stated consequences, not every prerequisite theorem. See EXTERNAL_DEPENDENCIES.md and CLAIM_PROOF_COVERAGE.md for the complete review boundary.

## A27 — version-role correction

Source lines: [569, 569]. The corrected body must not claim byte-identical preservation; its before-state remains separately intact.

Before:

This new copy preserves the entire body, including proof assumptions, examples, references and limits.

After:

The earlier preparation copy preserved the body. The present corrected derivative makes the separately enumerated changes in ERRATA.md; preservation/source-manuscript.md retains that exact earlier preparation copy, including its former limitations and assertions.

## A28 — review-date and scope correction

Source lines: [573, 573]. Retain the old state as history while accurately describing this new bounded audit.

Before:

The historical bibliography is retained with the text. Links, historical-priority assertions and dated open-problem classifications have not been newly recertified. Full scientific validation of every proof is not asserted.

After:

At the earlier preparation stage, the historical bibliography and open-problem categories had not been newly checked and a complete proof audit was not asserted. The October 16 mathematical review now covers every section, calculation, stated proof and exercise in this selected chapter. It verifies the listed external statements against the specified primary or institutional sources and records what remains imported. It does not independently certify broad historical-priority assertions or reconstruct the entire prerequisite literature.
