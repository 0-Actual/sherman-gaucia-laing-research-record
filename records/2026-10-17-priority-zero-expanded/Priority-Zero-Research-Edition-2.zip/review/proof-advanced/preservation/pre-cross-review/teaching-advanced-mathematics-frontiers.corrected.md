Corrected mathematical teaching derivative — October 16, 2026. The complete 573-line selected manuscript, all 21 worked examples and all 12 exercises have been reviewed, including assumptions, proof steps and boundary cases. This is a bounded mathematical review, not formal proof-assistant verification, independent certification, or a proof of any open problem. Imported theorems remain explicitly identified. The unchanged prior manuscript and exact before/after errata are retained alongside this derivative. Earlier volumes remain outside this selection.

# Volume 6 — Advanced Mathematics and Frontiers

Established mathematics study · prepared 20 September 2026

This volume continues the sequence through foundations, algebra and geometry, calculus and analysis, linear algebra and probability, and discrete mathematics, abstract algebra and topology. Its subject is established mathematics. Its examples are mathematical exercises, not demonstrations of a new physical device or project capability. The proofs below reconstruct the reasoning from stated definitions. Results requiring a longer theory are identified as theorems being used, or as proof outlines; a worked special case is never presented as their general proof.

## 1. Information begins with distinguishable possibilities

### 1.1 From counting to logarithms

For integers $N\ge1$ and $b\ge0$, a finite set with $N$ members requires $N$ distinguishable labels if every member must be recoverable. A fixed string of $b$ binary digits offers $2^b$ labels. An injective encoding into these strings therefore requires $N\le 2^b$, or $b\ge\lceil\log_2N\rceil$. This is a counting theorem. It does not depend on a particular programming language or storage medium.

When two choices are independent and have $M$ and $N$ equally likely outcomes, their joint choice has $MN$ outcomes. A measure of information that adds for these independent choices should turn multiplication into addition. The logarithm does exactly this: $\log_2(MN)=\log_2M+\log_2N$. The base sets the unit; base two gives bits, while the natural logarithm gives nats.

In the documented development of information theory, Shannon's 1948 paper explicitly builds on Nyquist and Hartley and separates the engineering problem of reproducing a selected message from the message's meaning. Studying that distinction is useful: a bit count is not a measurement of truth, wisdom, literary value, or spiritual significance. The original paper is available as [Shannon, A Mathematical Theory of Communication](https://people.math.harvard.edu/~ctm./REDACTED_LOCAL_ROOT/others/shannon/entropy/entropy.pdf).

For an event of probability $p>0$, define its information content by $I(p)=-\log_2p$. An event certain to happen contributes zero; an event of probability $1/8$ contributes three bits. If events are independent, their joint probability is $pq$, and their information contents add. For a finite random variable $X$ with probabilities $p_i$, the expected information is its entropy:

$$H(X)=-\sum_i p_i\log_2p_i,$$

with $0\log_2 0=0$, the continuous limiting convention. Entropy belongs to a probability model. A fixed file does not acquire a justified probability model merely because software reports an entropy estimate.

**Worked example 1 — unequal probabilities.** Let symbols $A,B,C,D$ have probabilities $1/2,1/4,1/8,1/8$. Their information contents are $1,2,3,3$. Therefore

$$H(X)=\tfrac12(1)+\tfrac14(2)+\tfrac18(3)+\tfrac18(3)=\tfrac74=1.75\text{ bits}.$$

Two fixed bits suffice for every symbol. The smaller entropy suggests that short labels for frequent symbols and longer labels for rare ones can improve the average. It does not mean that each symbol can physically occupy exactly $1.75$ binary positions.

### 1.2 Prefix codes and Kraft's inequality

A binary code is prefix free when no codeword is the initial segment of another. A decoder can then stop at the end of each codeword without needing an extra separator. For example, $0,10,110,111$ are prefix free; $0,01,11$ are not, because $0$ begins $01$.

Let the finite codeword lengths be $\ell_1,\ldots,\ell_m$ and let $L$ be their maximum. A codeword of length $\ell_i$ has $2^{L-\ell_i}$ binary extensions of length $L$. Prefix freeness makes these extension sets disjoint. There are only $2^L$ total strings of length $L$, so

$$\sum_i2^{L-\ell_i}\le2^L,
\qquad\sum_i2^{-\ell_i}\le1.$$

This proves necessity for finite binary prefix codes. For sufficiency, take a nonempty finite list of nonnegative integer lengths and order them $\ell_1\le\cdots\le\ell_m$. Suppose the first $j-1$ codewords have been chosen prefix free. At depth $\ell_j$ they block exactly $B=\sum_{i<j}2^{\ell_j-\ell_i}$ nodes, since their descendant sets are disjoint. Kraft's inequality for the first $j$ terms gives $B+1\le2^{\ell_j}$. At least one node remains free; choose it as word $j$. It has no earlier word as a prefix, and cannot be a prefix of a shorter earlier word. Induction constructs the whole code. If a length is zero, its contribution is one, so no other finite length can occur. The sole empty word needs a known block length or external framing to recover a variable number of repeated symbols; for the one-symbol alphabet or fixed-block problem here, that framing is known.

We can derive an average-length lower bound rather than merely quote it. The inequality $\ln t\le t-1$ for $t>0$ follows because $t-1-\ln t$ has derivative $1-1/t$ and its minimum zero at $t=1$. The alphabet is finite and nonempty, so the Kraft sum below is strictly positive. Set $K=\sum_i2^{-\ell_i}\le1$ and $q_i=2^{-\ell_i}/K$. For positive $p_i$, the inequality $\ln t\le t-1$ gives

$$\sum_i p_i\ln\frac{q_i}{p_i}
\le \sum_i p_i\left(\frac{q_i}{p_i}-1\right)=0.$$

Thus $D(p\Vert q)=\sum_i p_i\log_2(p_i/q_i)\ge0$. Substituting $q_i$ and rearranging yields

$$\bar\ell-H(X)=D(p\Vert q)-\log_2K\ge0.$$

Zero-probability symbols may be omitted from the source alphabet. This proof establishes the bound for the prefix codes under discussion. The extension to all uniquely decodable codes uses the separate Kraft–McMillan theorem.

Choose Shannon lengths $\ell_i=\lceil-\log_2p_i\rceil$. Since $2^{-\ell_i}\le p_i$, Kraft's condition holds, while $\ell_i<-\log_2p_i+1$. Hence a prefix code exists with

$$H(X)\le\bar\ell<H(X)+1.$$

**Worked example 2 — constructing the code.** Assign the four symbols above the strings $0,10,110,111$. Kraft's sum is $1/2+1/4+1/8+1/8=1$. Their expected length is $1.75$ bits, exactly the entropy. The message $ABDA$ becomes $0101110$. Read from the left: $0$ gives $A$, $10$ gives $B$, $111$ gives $D$, and $0$ gives $A$. No delimiter was needed.

For $n\ge1$ independent identically distributed finite-alphabet symbols, joint entropy is $nH(X)$. Indeed, on positive-probability strings $p(x_1,\ldots,x_n)=\prod_jp(x_j)$, so $-\log_2p(x_1,\ldots,x_n)=\sum_j-\log_2p(x_j)$. Taking the finite expectation gives $\sum_jH(X_j)=nH(X)$. Zero-probability strings contribute zero. Applying the same coding result to entire blocks gives expected length per symbol below $H(X)+1/n$. This is a precise asymptotic statement about expected lossless code length under the stated source model. It does not promise that every individual block is short.

**Worked example 3 — why uniform universal compression fails.** There are $2^{100}$ possible strings of length $100$, but only $2^{10}$ strings of length exactly $10$. No injective map can send every one of the former into the latter. Even allowing every output length from zero through $10$ gives only $1+2+\cdots+2^{10}=2047$ labels. A dictionary shared with the decoder is additional information; its size, availability and version are part of the description. Large compression is mathematically possible for suitable structured data, but never for every input under a universal lossless guarantee.

## 2. Recovering information after errors

### 2.1 Distance is the central invariant

For $x,y\in\{0,1\}^n$, the Hamming distance $d(x,y)$ counts the coordinates in which they differ. It is a metric: if a coordinate differs between $x$ and $z$, it must differ between $x,y$ or between $y,z$, giving the triangle inequality. A code $C$ is a subset of possible strings. Its minimum distance is the smallest distance between distinct codewords.

Suppose this distance is at least $2t+1$. If a received word $r$ were within $t$ errors of distinct codewords $c,c'$, the triangle inequality would give $d(c,c')\le2t$, a contradiction. Thus at most one codeword can explain any pattern of at most $t$ errors. This proves unique correction under the bounded-error assumption. A distance of at least $s+1$ similarly detects every nonzero error pattern affecting at most $s$ coordinates, because such an error cannot turn one codeword into another.

The algebraic perspective and the probabilistic perspective answer different questions. Hamming's 1950 error-correcting work studied explicit code constructions; Shannon's channel theory addressed reliable transmission under statistical noise laws. A researcher's own course notes connect these developments and define linear codes in [Guruswami, Introduction to Coding Theory, Notes 1](https://www.cs.cmu.edu/~venkatg/teaching/codingtheory/notes/notes1.pdf).

### 2.2 A complete Hamming $(7,4)$ calculation

Work over the field $\mathbb F_2$, so addition is exclusive OR and $1+1=0$. Choose the parity-check matrix

$$H=\begin{pmatrix}
1&0&1&0&1&0&1\\
0&1&1&0&0&1&1\\
0&0&0&1&1&1&1
\end{pmatrix}.$$

The columns are the seven nonzero three-bit vectors, ordered by the binary representations of $1$ through $7$, with the least significant bit first. Define $C=\{c:Hc=0\}$. Columns $1,2,4$ are the standard basis, so $H$ has rank $3$. Rank–nullity gives $\dim C=7-3=4$, hence $16$ codewords.

Because $C$ is linear, $c-c^\prime$ ranges over its nonzero words for distinct codewords, and $d(c,c^\prime)$ is the Hamming weight of $c-c^\prime$. Thus minimum distance equals minimum nonzero weight. No nonzero word of weight one lies in $C$, because every column of $H$ is nonzero. No word of weight two lies in $C$, because distinct columns cannot sum to zero. Columns $1,2,3$ do sum to zero, so a weight-three codeword exists. The minimum distance is exactly $3$.

**Worked example 4 — encoding and correcting.** Place information bits $1,0,1,1$ in positions $3,5,6,7$. Solve the three parity equations:

$$c_1+c_3+c_5+c_7=0,\quad
c_2+c_3+c_6+c_7=0,\quad
c_4+c_5+c_6+c_7=0.$$

They give $c_1=0,c_2=1,c_4=0$, so $c=(0,1,1,0,0,1,1)^T$. If position $6$ flips, the received word is $r=(0,1,1,0,0,0,1)^T$. Its syndrome is

$$Hr=(0,1,1)^T,$$

which is column $6$ of $H$. Flipping that position restores $c$. In general, if $r=c+e_j$, then $Hr=Hc+He_j=He_j$, exactly column $j$.

The seven possible single-bit errors and the no-error case account for eight received words around each codeword. Since $16\times8=128=2^7$, these disjoint radius-one balls cover all seven-bit words. This is why this code is called perfect for single-error correction. It does not make arbitrary numbers of errors correctable. With two flipped bits, the syndrome can imitate a third single error, and a decoder assuming only one error can miscorrect.

### 2.3 A precise noisy-channel statement

A finite discrete memoryless channel has transition probabilities $W(y\mid x)$; conditional on the inputs, separate channel uses follow the same law independently. Its capacity is

$$C=\max_{p(x)}I(X;Y),\qquad
I(X;Y)=\sum_{x,y}p(x)W(y\mid x)
\log_2\frac{W(y\mid x)}{p(y)}.$$

Here $p(y)=\sum_xp(x)W(y\mid x)$, and summands with zero joint probability are defined to contribute zero. A code with $M_n$ equiprobable messages and $n$ channel uses has rate $n^{-1}\log_2M_n$ bits per use; average error is averaged over these messages and the channel. For every fixed $0\le R<C$, a sequence of codes with asymptotic rate at least $R$ and average decoding-error probability tending to zero exists. At rates strictly above capacity, vanishing error is impossible under this model. Existence does not itself specify an efficient encoder, decoder, suitable block length, or implementation cost. Equality at capacity needs a separate limiting discussion. This is the finite-memoryless formulation of the channel-coding theorem; a proof requires typical-set or comparable probabilistic arguments beyond the elementary code proof just given.

The identity $I(X;Y)=H(Y)-H(Y\mid X)$ used below follows by expanding the displayed logarithm as $\log_2W(y\mid x)-\log_2p(y)$ and summing. Also $H(Y)\le\log_2m$ for an $m$-symbol output: apply the previously proved divergence inequality to $p_Y$ and the uniform distribution $q_y=1/m$ to obtain $D(p_Y\Vert q)=\log_2m-H(Y)\ge0$.

**Worked example 5 — binary symmetric channel.** Suppose each bit independently flips with probability $p$. With a uniform input, the output is uniform, so $H(Y)=1$. Given $X$, the uncertainty in $Y$ is the binary entropy $h_2(p)=-p\log_2p-(1-p)\log_2(1-p)$. Thus $I(X;Y)=1-h_2(p)$. For any input, $H(Y)\le1$, while $H(Y\mid X)=h_2(p)$ is unchanged, proving capacity is $1-h_2(p)$. At $p=1/2$ this is zero; at $p=0$ it is one. At $p=1$ the bit always flips, which the receiver can reverse, so capacity is again one.

## 3. Optimization: what guarantees improvement?

### 3.1 Convexity and global conclusions

A set $S\subseteq\mathbb R^n$ is convex if $(1-t)x+ty\in S$ for $x,y\in S$ and $0\le t\le1$. A function $f:S\to\mathbb R$ is convex if

$$f((1-t)x+ty)\le(1-t)f(x)+tf(y).$$

The right side is the height of a chord. Convexity says the graph does not rise above it along a segment. This is a property of the entire specified domain, not merely a visually bowl-shaped fragment of a plot.

For differentiable $f$ on an open convex domain, convexity is equivalent to the supporting-plane inequality

$$f(y)\ge f(x)+\nabla f(x)^T(y-x).$$

To obtain it from convexity, apply the defining inequality to $x+t(y-x)$, subtract $f(x)$, divide by $t>0$, and let $t\downarrow0$. Conversely, apply the supporting inequalities at $z=(1-t)x+ty$ toward both $x$ and $y$, multiply by $1-t$ and $t$, and add. The gradient terms cancel, yielding convexity.

Therefore $\nabla f(x_*)=0$ guarantees that $x_*$ is a global minimum for an unconstrained differentiable convex problem. It does not guarantee a unique minimizer. Strict convexity gives at most one minimizer; existence still needs a separate argument, such as continuity on a nonempty compact feasible set. The general organization of convex sets, duality and numerical methods is available from the authors at [Boyd and Vandenberghe, Convex Optimization](https://web.stanford.edu/~boyd/cvxbook/). The derivations here are carried out explicitly rather than importing a solver's result.

**Worked example 6 — a quadratic minimum.** Let

$$f(x,y)=(x-2)^2+3(y+1)^2.$$

The gradient is $(2(x-2),6(y+1))^T$, and the Hessian is $\operatorname{diag}(2,6)$. It is positive definite, since $v^T\nabla^2fv=2v_1^2+6v_2^2>0$ for $v\ne0$. The only stationary point is $(2,-1)$, and the displayed sum of squares proves directly that its value zero is the unique global minimum.

### 3.2 Deriving a step-size condition

Assume $f$ is differentiable on all of $\mathbb R^n$ and its gradient is $L$-Lipschitz for a chosen constant $L>0$:

$$\|\nabla f(y)-\nabla f(x)\|\le L\|y-x\|.$$

Integrate the derivative along the segment from $x$ to $x+d$:

$$f(x+d)-f(x)-\nabla f(x)^Td
=\int_0^1[\nabla f(x+td)-\nabla f(x)]^Td\,dt.$$

Cauchy–Schwarz and the Lipschitz bound make the integrand at most $Lt\|d\|^2$. Consequently

$$f(x+d)\le f(x)+\nabla f(x)^Td+\tfrac L2\|d\|^2.$$

For gradient descent $d=-\alpha\nabla f(x)$ this becomes

$$f(x-\alpha\nabla f(x))
\le f(x)-\alpha(1-L\alpha/2)\|\nabla f(x)\|^2.$$

Thus $0<\alpha<2/L$ guarantees strict decrease whenever the gradient is nonzero. Convexity was not needed for this descent inequality, but it is needed for several conclusions about global optimality. A decreasing sequence of objective values alone neither proves a global minimum nor guarantees that the iterates converge.

**Worked example 7 — convergence, oscillation and divergence.** For $f(x)=2x^2$, $L=4$ and the update is $x_{k+1}=(1-4\alpha)x_k$. With $\alpha=1/8$, $x_k=2^{-k}x_0$, so convergence follows from a geometric sequence. With $\alpha=1/2$, the multiplier is $-1$, and nonzero iterates oscillate forever at constant objective. With $\alpha=3/4$, the multiplier is $-2$, and their magnitude grows. An algorithm name alone did not guarantee improvement; its assumptions and parameters determined the behavior.

For a differentiable convex function with a minimizer $x_*$ and an $L$-Lipschitz gradient, the step $1/L$ also gives the familiar bound $f(x_k)-f(x_*)\le L\|x_0-x_*\|^2/(2k)$ for $k\ge1$. Here is its mechanism. Write $g=\nabla f(x)$, $x^+=x-g/L$. The squared-distance identity and convexity give

$$\|x-x_*\|^2-\|x^+-x_*\|^2
=\tfrac2L g^T(x-x_*)-\tfrac1{L^2}\|g\|^2
\ge\tfrac2L(f(x^+)-f(x_*)).$$

The last step combines $g^T(x-x_*)\ge f(x)-f(x_*)$ with the descent bound $f(x^+)\le f(x)-\|g\|^2/(2L)$. Sum over iterations; intermediate distances cancel. Since function values decrease, $k$ times the final gap is no larger than the sum of gaps, proving the bound. This is an iteration-count guarantee in exact arithmetic, not a measurement of time or energy.

### 3.3 Constraints, multipliers and duality

For minimizing $f(x)$ subject to $g_i(x)\le0$ and $Ax=b$, define

$$\mathcal L(x,\lambda,\nu)=f(x)+\sum_i\lambda_i g_i(x)+\nu^T(Ax-b),\quad\lambda_i\ge0.$$

At any feasible $x$, $\mathcal L(x,\lambda,\nu)\le f(x)$. Taking its infimum over all $x$ therefore gives a lower bound on every feasible objective value. This is weak duality and follows directly from the signs. The Karush–Kuhn–Tucker conditions include feasibility, nonnegative multipliers, stationarity and $\lambda_i g_i(x)=0$. If $f$ and every $g_i$ are differentiable convex functions and the equality constraints are affine, a point satisfying these conditions is globally optimal. For the sufficiency claim, let $(x_*,\lambda_*,\nu_*)$ satisfy these conditions on a common open convex domain $D$ with every feasible point in $D$. The function $\mathcal L(\cdot,\lambda_*,\nu_*)$ is convex, and stationarity makes $x_*$ its global minimizer on $D$. For feasible $y$,

$$f(y)\ge\mathcal L(y,\lambda_*,\nu_*)\ge\mathcal L(x_*,\lambda_*,\nu_*)=f(x_*),$$

where the final equality uses feasibility and complementary slackness. This proves sufficiency. The infimum defining the dual is over the common domain $D$, or all of $\mathbb R^n$ when the functions are defined there.

For necessity, a useful imported theorem is Slater's theorem: in a convex problem, strict feasibility in the relative interior of the common domain, together with a finite optimal value, ensures zero duality gap and dual attainment. At an attained primal optimum in the differentiable open-domain setting, KKT multipliers then exist. This is a sufficient constraint qualification, not a necessary condition for every problem, and it does not itself guarantee primal attainment. The general relative-interior and affine-constraint refinements are in Boyd and Vandenberghe, Sections 5.2.3 and 5.5.3; they are not proved here.

**Worked example 8 — an active constraint.** Minimize $(x-2)^2$ with $x\le1$. Here $g(x)=x-1$ and $\mathcal L=(x-2)^2+\lambda(x-1)$. At $x=1$, stationarity requires $-2+\lambda=0$, so $\lambda=2$. Feasibility and complementary slackness hold. Moreover $\mathcal L(x,2)=(x-1)^2+1$, whose infimum is $1$. The feasible point $x=1$ also has objective $1$. Matching lower and upper bounds proves optimality without relying on a graph.

## 4. Computation has mathematical limits

### 4.1 Defining a procedure before judging its power

A deterministic Turing machine has a finite set of states, a finite tape alphabet, a read/write head, and a transition rule specifying a new state, symbol and head movement from the current state and scanned symbol. The tape supplies arbitrarily extensible storage in the abstract model. A finite description of the machine can itself be encoded as a string. A universal machine interprets such descriptions and simulates their transitions.

This model distinguishes a finite rule from an arbitrary infinite oracle. A real number $r$ is computable, in a standard approximation formulation, if an algorithm returns a rational $q_n$ with $|r-q_n|\le2^{-n}$ for every input $n$. Writing a symbol for a real number does not provide such an algorithm. There are countably many finite programs, so at most countably many computable reals, whereas the reals are uncountable. The conclusion follows by cardinality; it does not identify which particular named numbers are computable.

Turing's original 1936 paper develops computing machines and universal simulation while investigating decision procedures. Its terminology about machines producing infinitely many digits differs from the modern halting formulation below. Reading the source prevents treating every modern presentation as his exact wording: [Turing, On Computable Numbers, with an Application to the Entscheidungsproblem](https://www.cs.virginia.edu/~robins/Turing_Paper_1936.pdf).

### 4.2 Full diagonal proof of undecidability of halting

Assume for contradiction there is a total algorithm $H(p,x)$ that returns $1$ exactly when the program encoded by $p$ eventually halts on input $x$, and returns $0$ otherwise. Total means it returns an answer for every valid program-input pair.

Construct another program $D$ with input $p$. It first evaluates $H(p,p)$. If that answer is $1$, it runs forever. If that answer is $0$, it halts immediately. The assumed algorithm $H$ is a finite procedure, so this construction is also a finite procedure and has some program encoding $d$.

Now examine $D(d)$. If $H(d,d)=1$, the definition of $D$ makes $D(d)$ run forever, contradicting the answer. If $H(d,d)=0$, the definition makes $D(d)$ halt, again contradicting the answer. The two possible outputs are both impossible. Therefore no such total, always-correct algorithm $H$ exists.

The contradiction concerns a universal decider, not every individual program. Many concrete programs have elementary termination proofs. A tool may correctly answer some cases and report “unknown” on others without contradicting this theorem. A time limit also does not decide nontermination: failing to finish within one million steps proves only that the program did not finish within those steps.

**Worked example 9 — a termination invariant.** Start with a nonnegative integer $n$ and repeatedly replace it by $n-1$ while it is positive. The value remains a nonnegative integer and strictly decreases at every step. After exactly the initial $n$ steps it is zero. The proof uses a well-founded order: there is no infinite strictly descending chain of nonnegative integers. Replacing the domain by all real numbers and subtracting a progressively smaller positive amount would destroy this particular argument; decreasing values can approach a positive limit without reaching zero.

### 4.3 Proof, truth and incompleteness

A formal theory consists of a language, axioms and rules for deriving sentences. It is consistent if it does not derive a contradiction. It is complete if for each sentence in its language it derives that sentence or its negation. An effectively axiomatized theory has axioms that can be enumerated by an algorithm; finite derivations can be supplied with sufficient bookkeeping to check their correctness mechanically.

One precise first-incompleteness statement is the Gödel–Rosser theorem: every consistent, computably axiomatized classical theory extending Robinson arithmetic $Q$ is incomplete. This formulation includes an expressiveness requirement. Propositional logic and other weaker decidable systems are not contradicted by it. The modern proof and the distinction between Gödel's original stronger consistency assumption and Rosser's refinement are developed in the authors' [Open Logic Project, Incompleteness](https://builds.openlogicproject.org/content/incompleteness/incompleteness.pdf).

**Proof outline, with the missing work identified.** Encode formulas and finite derivations by natural numbers. Represent enough of the arithmetic of those encodings inside the theory. A diagonal lemma then constructs a sentence referring, through its code, to its own provability. Gödel's sentence can be arranged to assert its own unprovability. Consistency prevents a proof of that sentence; the original argument uses a stronger assumption to prevent a proof of its negation. Rosser modifies the self-reference to compare proof and refutation codes and obtains both conclusions from consistency. The representation and diagonal lemmas, and the two Rosser cases, are substantial parts of the general proof; the English sentence alone is not a proof of the theorem.

The second incompleteness theorem has a similarly precise scope. For example, if Peano arithmetic is consistent, it cannot prove its own standard arithmetized consistency statement $\operatorname{Con}(\mathrm{PA})$, where that statement says there is no PA proof of $0=1$. The usual proof depends on the standard provability predicate satisfying appropriate derivability conditions. It is not a blanket claim that every consistent formal system is unable to reason about every form of consistency.

**Worked example 10 — a theory and its model.** From the axioms $P\to Q$ and $P$, modus ponens derives $Q$. The truth assignment $P=\mathrm{true},Q=\mathrm{true}$ satisfies both axioms and the conclusion. Now remove the axiom $P$. Both assignments $(P,Q)=(\mathrm{false},\mathrm{false})$ and $(\mathrm{false},\mathrm{true})$ satisfy $P\to Q$. Thus $Q$ is not forced by that remaining axiom. This small example distinguishes derivability from arbitrary assertion without suggesting it is itself an incompleteness-theorem example.

### 4.4 Feasible computation and P versus NP

A decision problem is a set of finite strings; membership asks for yes or no. The class P consists of problems decided by a deterministic algorithm in time polynomial in the encoded input length. NP consists of problems whose yes-instances admit polynomial-length certificates verifiable in polynomial time. Every P problem is in NP: a verifier can simply run the decision algorithm and ignore the certificate.

A problem is NP-hard if every problem in NP can be transformed to it by a polynomial-time many-one reduction, and NP-complete if it is both NP-hard and in NP. A reduction must preserve yes and no answers. A deterministic algorithm that correctly decides every instance of one NP-complete decision problem in polynomial worst-case time, measured in the encoded input length, would imply P=NP. Failure of familiar algorithms to find such a solution does not prove P differs from NP. The official research formulation is [Cook, The P versus NP Problem](https://www.claymath.org/wp-content/uploads/2022/06/pvsnp.pdf).

**Worked example 11 — certificate verification.** Consider

$$F=(x\lor y)\land(\neg x\lor z)\land(\neg y\lor\neg z).$$

The certificate $x=\mathrm{true},y=\mathrm{false},z=\mathrm{true}$ makes the clauses true, true, true respectively. With indexed access to the supplied assignment, verification requires one lookup per literal occurrence and therefore linear work in the number of written literals. With standard finite bit encodings, the indexing and parsing costs still give a polynomial-time verifier; a machine-independent exact linear-time bound is not asserted. Exhaustive search over $n$ variables considers $2^n$ assignments. This proves that one method is exponential; it does not prove every possible method must be.

Input length matters. An integer $N$ written in binary uses approximately $\log_2N$ bits. An algorithm performing $N$ steps is therefore exponential in that bit length, even though it is linear in the numerical value $N$. Complexity claims must identify the encoding and the cost model.

## 5. Measure: extending length and integration

### 5.1 What can be assigned a size?

A sigma-algebra $\mathcal F$ on a set $\Omega$ contains $\Omega$, is closed under complements, and is closed under countable unions. A measure $\mu:\mathcal F\to[0,\infty]$ has $\mu(\varnothing)=0$ and is countably additive on pairwise disjoint sets. Probability is the special case $\mu(\Omega)=1$.

The domain $\mathcal F$ matters. On the real line, Lebesgue measure extends interval length to a large sigma-algebra, but one cannot consistently assign every subset a translation-invariant, countably additive length agreeing with intervals under the usual set-theoretic assumptions. Accordingly, measurability is part of a theorem's hypotheses. Modern integration grows from this problem of extending elementary length while retaining useful limit operations. A complete university sequence developing outer measure, measurable sets and integration is [MIT 18.102, lecture notes](https://ocw.mit.edu/courses/18-102-introduction-to-functional-analysis-spring-2021/pages/lecture-notes-and-readings/).

**Worked example 12 — the rationals have measure zero.** Enumerate the rationals in $[0,1]$ as $q_1,q_2,\ldots$. For any $\varepsilon>0$, cover $q_n$ by an interval of length $\varepsilon/2^n$. The total length is $\varepsilon$. Therefore their outer measure is at most every positive $\varepsilon$, hence zero. They are dense in $[0,1]$, yet have measure zero. Density and measure answer different questions: every open interval contains rationals, but their countable set occupies zero Lebesgue length.

The indicator $1_{\mathbb Q\cap[0,1]}$ has integral zero in the Lebesgue sense. It is not Riemann integrable: every nontrivial subinterval contains both rational and irrational points, so every lower Riemann sum is zero and every upper sum is one. This gives a concrete reason to extend integration rather than regarding the newer definition as terminology alone.

### 5.2 Defining the integral from simple functions

For a nonnegative simple function $s=\sum_{i=1}^m a_i1_{A_i}$ with disjoint measurable $A_i$ and finite $a_i\ge0$, define

$$\int s\,d\mu=\sum_i a_i\mu(A_i).$$

In this definition, a zero coefficient contributes zero even when its region has infinite measure. For nonnegative measurable $f$, define $\int f\,d\mu$ as the supremum of these integrals over simple $s$ satisfying $0\le s\le f$. Signed $f$ is integrable when both positive and negative parts have finite integral; then subtract them. Requiring finiteness avoids the undefined expression $\infty-\infty$.

**Worked example 13 — computing from level regions.** On $[0,1]$, let $s=2$ on $[0,1/4)$, $s=5$ on $[1/4,3/4)$, and $s=1$ on $[3/4,1]$. The integral is

$$2(1/4)+5(1/2)+1(1/4)=13/4.$$

Changing the function at finitely many boundary points does not change its integral, because finitely many points have measure zero. The formula measures heights times the sizes of their regions; it does not require the regions to be intervals in the general definition.

The monotone convergence theorem says that if nonnegative measurable functions $f_n$ increase pointwise almost everywhere to a measurable function $f$, then their integrals increase to $\int f$. The dominated convergence theorem says that if measurable functions $f_n$ converge almost everywhere to a measurable function $f$ and $|f_n|\le g$ for one integrable function $g$, then $\int f_n\to\int f$. “Almost everywhere” means outside a measurable set of measure zero. These are theorems being used here, not consequences of pointwise convergence alone.

**Worked example 14 — a failed interchange of limit and integral.** On $[0,1]$, put $f_n(x)=n1_{(0,1/n)}(x)$. For every fixed $x$, $f_n(x)$ eventually vanishes, so its pointwise limit is zero. Yet $\int f_n=n(1/n)=1$ for every $n$. Thus $\lim\int f_n=1$ while $\int\lim f_n=0$. The sequence is not increasing: for example, at $x=3/4$, $f_1(x)=1$ but $f_2(x)=0$. Nor can a single integrable $g\ge0$ dominate every $f_n$ almost everywhere. On each disjoint interval $(2^{-(k+1)},2^{-k})$, $f_{2^k}=2^k$ and hence $\int g\ge\sum_{k=0}^K2^k2^{-(k+1)}=(K+1)/2$ for every $K$. The countable union of the exceptional null sets is still null. Letting $K$ increase proves the required integral is infinite. A graph of narrower, taller spikes explains the lost hypothesis but does not replace the integral calculation.

## 6. Hilbert spaces and Fourier analysis

### 6.1 Geometry of functions

A Hilbert space is a real or complex inner-product space complete in the norm induced by its inner product. Completeness says every Cauchy sequence has a limit in the same space. In $L^2([0,1])$, the elements are equivalence classes of measurable functions with $\int_0^1|f|^2<\infty$, identifying functions equal almost everywhere. For complex functions use

$$\langle f,g\rangle=\int_0^1\overline{f(x)}g(x)\,dx.$$

With this convention the inner product is conjugate-linear in the first argument and linear in the second. The identification is essential: a nonzero function at only one point has squared norm zero and must represent the zero element. Mere square-integrable pointwise functions without this identification would not yet give an inner product. Completeness of this quotient space is a further established theorem being used here; the finite projection proof below does not prove completeness of $L^2$.

If $e_1,\ldots,e_m$ are orthonormal, the projection of $f$ onto their span is $p=\sum_j e_j\langle e_j,f\rangle$. For each $i$, $\langle e_i,f-p\rangle=0$. For any vector $v$ in the span,

$$\|f-v\|^2=\|f-p\|^2+\|p-v\|^2,$$

because the two terms are orthogonal. Thus $p$ is the unique nearest vector in that finite-dimensional span. This is least squares expressed in the language of functions.

**Worked example 15 — best constant approximation.** Approximate $f(x)=x$ on $[0,1]$ by a constant. The function $e(x)=1$ has norm one, and $\langle e,f\rangle=\int_0^1x\,dx=1/2$. Thus the best constant is $1/2$. Directly,

$$\int_0^1(x-a)^2\,dx
=\tfrac13-a+a^2=(a-\tfrac12)^2+\tfrac1{12}.$$

The minimum squared error is $1/12$, achieved only at $a=1/2$. This independently confirms the projection argument.

### 6.2 Deriving Fourier coefficients

On $[-\pi,\pi]$, use the normalized inner product $(2\pi)^{-1}\int\overline f g$. The functions $e_n(x)=e^{inx}$, $n\in\mathbb Z$, are orthonormal. If $m\ne n$,

$$\langle e_m,e_n\rangle
=\frac1{2\pi}\int_{-\pi}^{\pi}e^{i(n-m)x}\,dx=0,$$

because the antiderivative has equal endpoint values; for $m=n$ the integrand is one. The coefficient of $e_n$ is therefore

$$c_n=\frac1{2\pi}\int_{-\pi}^{\pi}f(x)e^{-inx}\,dx.$$

Orthogonality proves that finite partial sums give best approximations within their chosen frequency span. The further assertion that these exponentials form a complete orthonormal system in $L^2$ is a theorem. It yields $L^2$ convergence and Parseval's identity, $\|f\|_2^2=\sum_n|c_n|^2$. It does not, by itself, assert pointwise convergence at every point. Different convergence questions require different hypotheses.

**Worked example 16 — a sawtooth and its energy.** For $f(x)=x$ on $(-\pi,\pi)$, oddness makes the constant and cosine coefficients zero. Integration by parts gives

$$b_n=\frac1\pi\int_{-\pi}^{\pi}x\sin(nx)\,dx
=\frac{2(-1)^{n+1}}n.$$

Indeed, the antiderivative is $-x\cos(nx)/n+\sin(nx)/n^2$, whose endpoint difference is $-2\pi(-1)^n/n$. The Fourier series is therefore $2\sum_{n\ge1}(-1)^{n+1}\sin(nx)/n$. For the periodic extension, the usual piecewise-smooth convergence theorem gives value $x$ at interior continuity points and zero at the endpoint jump, the average of the two one-sided limits.

The mean square of $f$ is $(2\pi)^{-1}\int_{-\pi}^{\pi}x^2\,dx=\pi^2/3$. Each sine has normalized squared norm $1/2$, so Parseval gives $\pi^2/3=2\sum_{n\ge1}1/n^2$. Hence $\sum_{n\ge1}1/n^2=\pi^2/6$. This derivation is conditional on the stated completeness/Parseval theorem, not a proof of that theorem from scratch.

Fourier analysis also turns differential equations into algebraic or ordinary differential equations. For $u_t=\kappa u_{xx}$ with $\kappa>0$, forward time $t\ge0$, and a $2\pi$-periodic spatial interval, the mode $a_n(t)e^{inx}$ gives $a_n'(t)=-\kappa n^2a_n(t)$, so $a_n(t)=a_n(0)e^{-\kappa n^2t}$. Higher frequencies decay faster. Each individual mode verifies the equation exactly. Here is a bounded full-series justification: if the initial periodic datum $f$ lies in $L^2$ and has coefficients $c_n$, define $u(t,x)=\sum_{n\in\mathbb Z}c_ne^{-\kappa n^2t}e^{inx}$. For any $\varepsilon>0$ and nonnegative integers $r,q$, Cauchy–Schwarz bounds the absolute sum of the $r$ spatial and $q$ time derivatives, uniformly for $t\ge\varepsilon$, by

$$\left(\sum_n|c_n|^2\right)^{1/2}
\left(\sum_n |n|^{2r}(\kappa n^2)^{2q}e^{-2\kappa n^2\varepsilon}\right)^{1/2}<\infty,$$

with the zero-frequency term interpreted by direct differentiation (for $r=q=0$ it contributes one to the second sum). Exponential decay makes every such weighted sum finite. Uniform convergence of the derivative series on positive-time strips justifies termwise differentiation, giving the heat equation for $t>0$. Parseval and dominated convergence for the summable series $4\sum|c_n|^2$ give $\|u(t,\cdot)-f\|_2^2=\sum|c_n|^2|e^{-\kappa n^2t}-1|^2\to0$ as $t\downarrow0$. This uses the imported Fourier-completeness theorem and standard termwise-differentiation theorem; it does not assert pointwise recovery of arbitrary $L^2$ initial data.

## 7. Differential geometry: measuring on a space

### 7.1 Coordinates are descriptions, not the underlying points

A topological $n$-manifold is a Hausdorff, second-countable space locally homeomorphic to open subsets of $\mathbb R^n$. A chart assigns coordinates in such a neighborhood. A smooth structure consists of compatible charts whose transition maps are smooth. Local Euclidean coordinates do not imply the entire space is globally equivalent to $\mathbb R^n$.

A tangent vector at a point can be represented by the derivative of a curve through that point, with equivalent curves having the same derivative in coordinates. Coordinate changes transform this derivative by the chain rule. A Riemannian metric assigns a positive-definite inner product to each tangent space, varying smoothly with the point. In coordinates it is a positive-definite matrix $g_{ij}(x)$, and a curve has length

$$L(\gamma)=\int_a^b
\sqrt{\sum_{i,j}g_{ij}(\gamma(t))\dot\gamma^i(t)\dot\gamma^j(t)}\,dt.$$

Riemann's foundational lecture asks which assumptions underlie geometry and examines local metric structure. The historical text and Clifford translation are preserved by Trinity College Dublin: [Riemann, On the Hypotheses which lie at the Bases of Geometry](https://www.maths.tcd.ie/pub/HistMath/People/Riemann/Geom/WKCGeom.html). The archive records posthumous publication in 1867. This source supports a documented stage in the development, not a claim that all geometry began with one person or one lecture.

### 7.2 Deriving the sphere's metric

Parameterize the sphere of radius $R>0$, away from coordinate singularities, by

$$r(\theta,\phi)=
(R\sin\theta\cos\phi,R\sin\theta\sin\phi,R\cos\theta).$$

Differentiate. The vector $r_\theta$ is $(R\cos\theta\cos\phi,R\cos\theta\sin\phi,-R\sin\theta)$, and $r_\phi$ is $(-R\sin\theta\sin\phi,R\sin\theta\cos\phi,0)$. Their squared lengths are $R^2$ and $R^2\sin^2\theta$, and their dot product is zero. Therefore

$$ds^2=R^2d\theta^2+R^2\sin^2\theta\,d\phi^2.$$

At a pole this chart degenerates because all longitudes meet there. The sphere itself is smooth; the coordinate choice fails. This distinction recurs throughout geometry and physics.

**Worked example 17 — two lengths on a sphere.** At fixed longitude, changing colatitude from $\pi/6$ to $\pi/2$ gives length $R\int_{\pi/6}^{\pi/2}d\theta=R\pi/3$. At fixed colatitude $\theta=\pi/6$, traversing all longitudes gives circumference $\int_0^{2\pi}R\sin(\pi/6)d\phi=\pi R$. This latitude circle is smaller than the equator, whose circumference is $2\pi R$. Both follow from the same local metric.

The area element is $\sqrt{\det g}\,d\theta\,d\phi=R^2\sin\theta\,d\theta\,d\phi$. Integrating gives total area $R^2(2)(2\pi)=4\pi R^2$. A coordinate formula has produced an invariant geometric quantity after the correct measure factor is included.

### 7.3 Geodesics and curvature

For a smooth Riemannian metric, an affinely parameterized geodesic satisfies

$$\ddot x^k+\sum_{i,j}\Gamma^k_{ij}\dot x^i\dot x^j=0,$$

where

$$\Gamma^k_{ij}=\tfrac12\sum_\ell g^{k\ell}
(\partial_i g_{j\ell}+\partial_j g_{i\ell}-\partial_\ell g_{ij}).$$

For completeness, write the energy integrand as $\mathscr E=\tfrac12\sum_{i,j}g_{ij}\dot x^i\dot x^j$. Smooth fixed-endpoint variations give the Euler–Lagrange equations. In coordinates,

$$\frac{d}{dt}\frac{\partial\mathscr E}{\partial\dot x^\ell}
=\sum_jg_{\ell j}\ddot x^j+\sum_{i,j}(\partial_i g_{\ell j})\dot x^i\dot x^j,
\qquad
\frac{\partial\mathscr E}{\partial x^\ell}
=\frac12\sum_{i,j}(\partial_\ell g_{ij})\dot x^i\dot x^j.$$

Subtract, symmetrize the $i,j$ product and multiply by $g^{k\ell}$. This gives exactly the displayed geodesic equation. The elementary first-variation argument uses integration by parts on variations vanishing at the endpoints and the fundamental lemma of the calculus of variations. Substitution in $d(\sum g_{ij}\dot x^i\dot x^j)/dt$ gives zero, so the speed is constant. These are energy-stationary curves with an affine parameter; arbitrary nonlinear reparameterizations need not satisfy this equation.

The further local length-minimizing property uses the normal-neighborhood/Gauss-lemma theorem, imported here. It holds on sufficiently short segments; it does not imply length minimization between distant endpoints. On the sphere, a great-circle arc longer than a semicircle is an immediate example of the distinction.

For the sphere metric, the nonzero coefficients in these coordinates are $\Gamma^\theta_{\phi\phi}=-\sin\theta\cos\theta$ and $\Gamma^\phi_{\theta\phi}=\Gamma^\phi_{\phi\theta}=\cot\theta$. At the equator $\theta=\pi/2$, the curve $\phi=at+b$ satisfies both geodesic equations. At a fixed non-equatorial latitude with nonzero angular speed, the $\theta$ equation fails, so that circle is not a geodesic.

Curvature describes how local geometry differs from flat geometry. For an oriented closed smooth surface with a Riemannian metric, the Gauss–Bonnet theorem states $\int_MK\,dA=2\pi\chi(M)$. This is a theorem being used, not proved here. For a round sphere, the unit normal is $N(r)=r/R$, so its differential on tangent vectors is $dN(v)=v/R$. With shape-operator convention $S=-dN$, both principal curvatures are $-1/R$, and their product is $K=1/R^2$ (the Gaussian-curvature/shape-operator identity is the standard surface formula being used). The area is $4\pi R^2$, giving integral $4\pi=2\pi(2)$, consistent with Euler characteristic two. Checking this case does not establish the theorem for arbitrary surfaces.

## 8. The mathematics of quantum information

### 8.1 State spaces and measurement rules

For an isolated quantum system modeled by a finite-dimensional Hilbert space, a pure state is represented by a unit vector in a complex Hilbert space, with vectors differing only by a global complex phase representing the same physical pure state. A qubit uses $\mathbb C^2$:

$$|\psi\rangle=\alpha|0\rangle+\beta|1\rangle,
\qquad |\alpha|^2+|\beta|^2=1.$$

The notation is linear algebra: $|0\rangle=(1,0)^T$ and $|1\rangle=(0,1)^T$. The Born rule assigns computational-basis measurement probabilities $|\alpha|^2$ and $|\beta|^2$. More generally, a projective measurement with orthogonal projections $P_j$ summing to the identity gives probability $\langle\psi,P_j\psi\rangle$. For an ideal Lüders projective measurement, an observed outcome of positive probability has normalized post-measurement state $P_j\psi/\sqrt{\langle\psi,P_j\psi\rangle}$. The projection probabilities alone do not uniquely specify a physical measurement instrument: a unitary within a degenerate outcome subspace may change the posterior state while leaving these probabilities unchanged. The displayed update therefore assumes the ideal Lüders instrument, rather than following from the probabilities alone.

These are modeling postulates connecting mathematics to physical predictions; they are not derivable merely by changing the notation for binary digits. A contemporary primary instructional source is [Watrous, IBM Quantum Learning: single systems](https://quantum.cloud.ibm.com/learning/en/courses/basics-of-quantum-information/single-systems/introduction). The calculations below study the model without claiming that a general-purpose laptop becomes quantum hardware.

**Worked example 18 — amplitudes and probabilities.** Let $|\psi\rangle=(\sqrt3/2)|0\rangle+(i/2)|1\rangle$. Its squared norm is $3/4+1/4=1$. Measurement yields $0$ with probability $3/4$ and $1$ with probability $1/4$. The expected value of the observable $Z=\operatorname{diag}(1,-1)$ is $3/4-1/4=1/2$. The imaginary phase in the second amplitude does not affect these particular probabilities, but it can affect probabilities after an operation that mixes the basis states.

### 8.2 Unitaries and interference

A matrix $U$ is unitary if $U^\dagger U=I$, where the dagger means conjugate transpose. Then $\|U\psi\|^2=\psi^\dagger U^\dagger U\psi=\|\psi\|^2$. Unitary transformations preserve inner products as well as lengths. Their inverse is $U^\dagger$.

Consider the Hadamard matrix

$$H=\frac1{\sqrt2}\begin{pmatrix}1&1\\1&-1\end{pmatrix}.$$

It is real symmetric and $H^2=I$, so it is unitary. Define $|+\rangle=(|0\rangle+|1\rangle)/\sqrt2$ and $|-\rangle=(|0\rangle-|1\rangle)/\sqrt2$.

**Worked example 19 — equal initial probabilities, different outcomes.** Both $|+\rangle$ and $|-\rangle$ have probabilities $1/2,1/2$ in the computational basis. Yet $H|+\rangle=|0\rangle$ while $H|-\rangle=|1\rangle$. Adding amplitudes before squaring permits constructive and destructive interference. By contrast, multiplying every amplitude by one common factor $e^{i\theta}$ changes no projective-measurement probability, since the phase cancels in the inner product.

### 8.3 Tensor products and entanglement

Two systems with spaces $\mathbb C^m$ and $\mathbb C^n$ have joint space $\mathbb C^m\otimes\mathbb C^n$, of dimension $mn$. For two qubits, a basis is $|00\rangle,|01\rangle,|10\rangle,|11\rangle$. A product state expands as

$$(a|0\rangle+b|1\rangle)\otimes(c|0\rangle+d|1\rangle)
=ac|00\rangle+ad|01\rangle+bc|10\rangle+bd|11\rangle.$$

A pure state that cannot be written as such a product is entangled. This is a precise algebraic property, not a synonym for complicated correlation.

**Worked example 20 — proving a Bell state is entangled.** Suppose $(|00\rangle+|11\rangle)/\sqrt2$ were a product. Comparing coefficients would give $ac=1/\sqrt2$, $ad=0$, $bc=0$, $bd=1/\sqrt2$. The first and last equations imply all four numbers $a,b,c,d$ are nonzero, contradicting the middle equations. Thus the state is not a product. Equivalently its coefficient matrix has rank two, whereas a product state's coefficient matrix is an outer product of rank one.

Measuring both qubits in this basis gives $00$ or $11$, each with probability $1/2$. Each individual result is uniformly random. Correlation does not allow an observer to choose the other observer's random outcome.

For mixed states, use a density matrix $\rho$, a positive semidefinite operator with trace one. An ensemble of pure states with probabilities $p_i$ gives $\rho=\sum_i p_i|\psi_i\rangle\langle\psi_i|$. Measurement probability is $\operatorname{tr}(P_j\rho)$. The Bell state's reduced density matrix for either qubit is $I/2$, found by taking the partial trace over the other basis. The joint state is pure even though each reduced state is mixed. Explicitly,

$$\rho_{AB}=\tfrac12\sum_{i,j=0}^1|i\rangle\langle j|\otimes|i\rangle\langle j|,
\qquad\operatorname{tr}_B\rho_{AB}=\tfrac12\sum_{i,j}|i\rangle\langle j|\,\delta_{ij}=I/2.$$

The broader no-signaling statement concerns an unconditioned local trace-preserving operation. If $A_a$ are its Kraus operators on the first system and $\sum_a A_a^\dagger A_a=I$, then for any observable $B$ on the second system,

$$\sum_a\operatorname{tr}\!\left[(A_a\otimes I)\rho_{AB}(A_a^\dagger\otimes I)(I\otimes B)\right]
=\operatorname{tr}[\rho_{AB}(I\otimes B)].$$

Cyclicity of the full trace and the Kraus normalization give the equality. Thus the second marginal is unchanged. Conditioning on a reported outcome can change conditional statistics, but conveying that outcome requires communication. The finite-dimensional Kraus representation of a general quantum channel is an imported theorem; the displayed trace calculation proves the consequence once that representation is given.

### 8.4 A limit proved from linearity

Assume a unitary operation could clone every unknown pure state with a fixed blank state $|b\rangle$:

$$U(|\psi\rangle|b\rangle)=|\psi\rangle|\psi\rangle.$$

Apply this to states $\psi,\phi$. Preservation of inner products would require $\langle\psi|\phi\rangle=(\langle\psi|\phi\rangle)^2$. This equation forces their overlap to be zero or one. Choosing, for example, $|0\rangle$ and $|+\rangle$, whose overlap is $1/\sqrt2$, gives a contradiction. Even if the output representatives are allowed state-dependent global phases, taking absolute values gives $r=r^2$ for $r=|\langle\psi|\phi\rangle|$, and the same counterexample applies. Therefore no such universal unitary cloner exists. Orthogonal states can be copied by a fixed operation: the vectors $|j\rangle|b\rangle$ and $|j\rangle|j\rangle$ are two orthonormal lists, so a map taking one to the other extends to a unitary by completing orthonormal bases. The theorem concerns a single state-independent device, exact output, deterministic success and a set containing nonorthogonal pure states. It does not forbid preparing copies from a classical description, approximate copies, or successful outcomes of appropriately restricted probabilistic procedures.

The finite-channel extension also includes an auxiliary system or discarded environment. Import the Kraus representation $\Phi(\rho)=\sum_aK_a\rho K_a^\dagger$, $\sum_aK_a^\dagger K_a=I$, for a deterministic finite-dimensional quantum channel. Define $V\psi=\sum_a K_a\psi\otimes|a\rangle$; then $V^\dagger V=I$. If the two output systems are exactly in $|\psi\psi\rangle$, each vector $K_a\psi$ must be parallel to $|\psi\psi\rangle$: for every vector $w$ orthogonal to that ray, $\sum_a|\langle w,K_a\psi\rangle|^2=0$. Hence $V\psi=|\psi\psi\rangle\otimes|a_\psi\rangle$ with $\|a_\psi\|=1$. For two input states, inner-product preservation and Cauchy–Schwarz give

$$r=|\langle\psi,\phi\rangle|
=r^2|\langle a_\psi,a_\phi\rangle|\le r^2.$$

This is impossible when $0<r<1$. Thus adding a fixed auxiliary system or discarding an environment cannot produce a deterministic exact cloner for arbitrary pure states. The channel-representation theorem is imported; the implication from it is proved here. See [Watrous, The Theory of Quantum Information, Chapter 2](https://cs.uwaterloo.ca/~watrous/TQI/TQI.2.pdf) for representations and [IBM Quantum Learning, limitations](https://quantum.cloud.ibm.com/learning/en/courses/basics-of-quantum-information/quantum-circuits/limitations-on-quantum-information) for the elementary theorem.

An $n$-qubit vector has $2^n$ complex amplitudes, but one measurement does not print all those amplitudes. State preparation, repeated measurement, noise and the desired output all matter. The mathematical existence of a large vector space is not a theorem that arbitrary classical data can be recovered from a tiny physical memory with no further resources.

## 9. Reaching a frontier without inventing a result

A mathematical frontier is not a single final chapter. It consists of many specialized questions whose statements require different prerequisites. A theorem can be settled while its applications remain active; a proposed proof can be under examination while a prize organization has not classified the problem as solved. The categories must be recorded with a date.

The retained manuscript reports a September 20, 2026 check. In this review, the [Clay Mathematics Institute problem list](https://www.claymath.org/millennium-problems/) was retrieved on October 16, 2026 and displayed Poincaré under **Solved**, Navier–Stokes under **Active**, and Birch–Swinnerton-Dyer, Hodge, P versus NP, Riemann, and Yang–Mills/mass gap under **Unsolved**. These are the page's dated category labels; “Active” is not evidence that a new proof has been accepted. This retrieval does not independently authenticate the earlier check or certify any proposed proof.

| Problem | Mathematical question, with essential scope | Verified Clay category |
|---|---|---|
| [Poincaré](https://www.claymath.org/millennium/poincare-conjecture/) | Is every closed, simply connected topological three-manifold homeomorphic to the three-sphere? | Solved |
| [P versus NP](https://www.claymath.org/millennium/p-vs-np/) | Does polynomial-time verification imply polynomial-time decision for all finite decision problems in NP? | Unsolved |
| [Riemann](https://www.claymath.org/millennium/riemann-hypothesis/) | Do all nontrivial zeros of the analytically continued zeta function have real part $1/2$? | Unsolved |
| [Birch–Swinnerton-Dyer](https://www.claymath.org/wp-content/uploads/2022/05/birchswin.pdf) | Does the rank of an elliptic curve over the rationals equal the order of vanishing of its $L$-function at $s=1$? A refined version also specifies the leading coefficient. | Unsolved |
| [Hodge](https://www.claymath.org/wp-content/uploads/2022/06/hodge.pdf) | On a smooth complex projective variety, are rational Hodge classes of type $(p,p)$ rational linear combinations of algebraic cycle classes? | Unsolved |
| [Yang–Mills and mass gap](https://www.claymath.org/wp-content/uploads/2022/06/yangmills.pdf) | For every compact simple gauge group, does a nontrivial quantum Yang–Mills theory on $\mathbb R^4$ exist with the required axiomatic properties and a positive mass gap? | Unsolved |
| [Navier–Stokes](https://www.claymath.org/millennium/navier-stokes-equation/) | Does the specified three-dimensional incompressible evolution retain the required global smoothness, or can an allowed breakdown be demonstrated? | Active |

Here a closed manifold means compact and without boundary. These short statements identify the questions; the official formulations contain the exact technical conditions. In particular, a phrase such as “all three-dimensional spaces” would be an incorrect Poincaré statement without the closed and simply connected assumptions. A numerical calculation of many zeta zeros does not establish a statement about all zeros.

### 9.1 A worked PDE estimate and the question it leaves

Consider a sufficiently smooth solution with both velocity $u$ and pressure $p$ periodic on the same spatial box, with $u$ divergence-free, satisfying the unforced incompressible Navier–Stokes equation

$$\partial_tu+(u\cdot\nabla)u=-\nabla p+\nu\Delta u,
\qquad\nabla\cdot u=0,\quad\nu>0.$$

**Worked example 21 — deriving the energy identity.** Multiply by $u$, integrate over a periodic box, and sum vector components. The time term is $\tfrac12(d/dt)\int|u|^2$. The nonlinear term is $\int u\cdot\nabla(|u|^2/2)$; writing this as a divergence minus $(\nabla\cdot u)|u|^2/2$ makes its integral zero. The pressure term similarly integrates to zero by incompressibility. Integration by parts gives $\int u\cdot\Delta u=-\int|\nabla u|^2$. Therefore

$$\frac d{dt}\frac12\int|u|^2
=-\nu\int|\nabla u|^2\le0.$$

This is a rigorous identity under the smoothness and boundary assumptions stated. It controls an integral norm, not automatically every derivative or pointwise maximum. Extending solutions while proving the necessary regularity is a separate issue. The official specification is [Fefferman, Existence and Smoothness of the Navier–Stokes Equation](https://www.claymath.org/wp-content/uploads/2022/06/navierstokes.pdf), while the current category appears on [Clay's Navier–Stokes page](https://www.claymath.org/millennium/navier-stokes-equation/).

### 9.2 What counts as advancing a mathematical claim

A proposed theorem needs a statement whose objects and quantifiers are fixed. “Every finite input” differs from “the tested inputs.” “For all real parameters” differs from “for positive integer parameters.” An existence theorem differs from a constructive algorithm, and a convergent algorithm differs from a finite-time error certificate.

For a new definition, check that it is well defined: choosing another representative of an equivalence class must not change the output. For a new theorem, list assumptions and derive the conclusion using accepted inference rules. For a counterexample, verify every assumption before showing the conclusion fails. For a computational experiment, preserve inputs, methods, precision and outputs. These are ordinary mathematical obligations; a striking pattern or a prestigious author does not remove them.

Original mathematics may eventually emerge from this work, but novelty requires comparison with existing literature, and correctness requires proof or a precisely limited empirical claim. This volume establishes a route into advanced subjects with explicit calculations. It neither exhausts the world's mathematical literature nor replaces the learner's own independent solutions.

## 10. Exercises with full solutions

### Exercise 1 — entropy and a prefix code

**Problem.** A source has probabilities $1/2,1/4,1/4$. Find its entropy, construct an optimal binary prefix code, and explain why two one-bit words plus another codeword cannot be prefix free.

**Solution.** Entropy is $(1/2)1+(1/4)2+(1/4)2=3/2$ bits. The code $0,10,11$ is prefix free and has expected length $3/2$, attaining the lower bound. Two distinct one-bit words would have to be $0$ and $1$. Every nonempty binary word begins with one of these, so no third word can be added. The Kraft calculation gives the same obstruction: $2^{-1}+2^{-1}=1$ already consumes the full available sum, leaving no positive contribution for a third finite length.

### Exercise 2 — a two-error syndrome

**Problem.** In the Hamming code of Section 2, suppose positions $2$ and $5$ flip. Find the syndrome. What would a decoder assuming exactly one error do, and why would that be wrong?

**Solution.** The error vector is $e_2+e_5$, so the syndrome is column $2$ plus column $5$:

$$(0,1,0)^T+(1,0,1)^T=(1,1,1)^T.$$

This is column $7$. The decoder flips position $7$, leaving total error $e_2+e_5+e_7$. Its syndrome is zero, because the three columns sum to zero, but the error vector is nonzero. The resulting word is a different valid codeword. This is miscorrection, not successful recovery. Minimum distance three guarantees single-error correction; it does not guarantee correct recovery under two errors.

### Exercise 3 — selecting a gradient step

**Problem.** Minimize $f(x)=\tfrac32(x-4)^2$. Starting at $x_0=0$, use step size $\alpha=1/6$. Give $x_k$, prove convergence, and find the smallest $k$ for which $|x_k-4|\le1/8$.

**Solution.** The derivative is $3(x-4)$, so

$$x_{k+1}-4=(1-3/6)(x_k-4)=\tfrac12(x_k-4).$$

Induction gives $x_k-4=-4\,2^{-k}$ and $x_k=4(1-2^{-k})$. The geometric factor tends to zero, proving convergence to four. The required inequality is $4\,2^{-k}\le1/8$, or $2^k\ge32$. The smallest integer is $k=5$. This exact solution supplies an error bound, which merely observing five decreasing objective values would not provide.

### Exercise 4 — a dual certificate

**Problem.** Minimize $x^2+y^2$ subject to $x+y=6$. Find the minimum by completing squares and by a Lagrange multiplier. Show that the multiplier yields a matching lower bound.

**Solution.** The identity

$$x^2+y^2=\tfrac12(x+y)^2+\tfrac12(x-y)^2$$

gives $x^2+y^2=18+(x-y)^2/2\ge18$, with equality at $x=y=3$. The Lagrangian is $x^2+y^2+\nu(x+y-6)$. Stationarity gives $2x+\nu=0$ and $2y+\nu=0$; feasibility gives $x=y=3$ and $\nu=-6$. For this multiplier,

$$\mathcal L=(x-3)^2+(y-3)^2+18,$$

so its unconstrained infimum is $18$. Weak duality makes this a lower bound, and the feasible point attains it. Both arguments establish the same global optimum.

### Exercise 5 — why a timeout is not a halting decision

**Problem.** A tester simulates a program for one million transitions and labels it “never halts” if the time expires. Give a counterexample to the tester's correctness. Explain why increasing the fixed limit does not repair the general claim.

**Solution.** Choose a program that runs a counter for more than one million transitions and then halts. The tester returns “never halts,” which is false. For every larger finite bound $B$, there is likewise a finite program that performs more than $B$ steps before halting. Thus no fixed timeout distinguishes all long finite computations from infinite ones. The tester can validly report “did not halt within the bound,” which is a different proposition. Even a more sophisticated purported total decider must confront the diagonal proof, not just this particular timeout counterexample.

### Exercise 6 — a legitimate limit interchange

**Problem.** For $f_n(x)=x^n$ on $[0,1]$, identify the almost-everywhere limit and justify exchanging limit and integral. Contrast this with the spike example.

**Solution.** If $0\le x<1$, the geometric sequence $x^n$ tends to zero; at $x=1$ it stays one. The limit is therefore zero almost everywhere, since the exceptional singleton has measure zero. Also $0\le f_n\le1$ and the constant function one is integrable on $[0,1]$. Dominated convergence applies, giving $\int f_n\to0$. Direct integration confirms $\int_0^1x^n\,dx=1/(n+1)\to0$. The spikes $n1_{(0,1/n)}$ lack an integrable common bound. Their heights grow enough to retain integral one even while each fixed point eventually leaves the support.

### Exercise 7 — projection onto two functions

**Problem.** Find the best $L^2([0,1])$ approximation to $x^2$ of the form $a+bx$, and compute its squared error.

**Solution.** Orthogonality of the residual to $1$ and $x$ gives

$$\tfrac13-a-\tfrac b2=0,
\qquad\tfrac14-\tfrac a2-\tfrac b3=0.$$

The first gives $a=1/3-b/2$. Substitute in the second: $1/4-1/6+b/4-b/3=0$, hence $b=1$ and $a=-1/6$. The residual is $r=x^2-x+1/6$. Its square is $x^4-2x^3+(4/3)x^2-(1/3)x+1/36$. Integration yields

$$\tfrac15-\tfrac12+\tfrac49-\tfrac16+\tfrac1{36}=\tfrac1{180}.$$

For any other linear approximation, its difference from the optimal one lies in the span of $1,x$ and is orthogonal to $r$. Pythagoras therefore adds a nonnegative squared norm to $1/180$, proving global optimality and uniqueness in this function space.

### Exercise 8 — spherical cap area

**Problem.** On a sphere of radius $R>0$, for $0\le\theta_0\le\pi$, compute the area of the cap $0\le\theta\le\theta_0$. Check the cases $\theta_0=0,\pi/2,\pi$.

**Solution.** Integrate the area element derived from the metric:

$$A=\int_0^{2\pi}\int_0^{\theta_0}R^2\sin\theta\,d\theta\,d\phi
=2\pi R^2(1-\cos\theta_0).$$

At zero the result is zero. At $\pi/2$ it is $2\pi R^2$, half the full area. At $\pi$ it is $4\pi R^2$, the full sphere. The coordinate singularity at the north pole does not contribute an area discrepancy; the integral is evaluated using a valid chart away from that measure-zero point and its limiting behavior.

### Exercise 9 — a phase-sensitive measurement

**Problem.** Apply the Hadamard matrix to $(|0\rangle+i|1\rangle)/\sqrt2$. Compute both measurement probabilities. Compare with input $|+\rangle$.

**Solution.** Matrix multiplication gives

$$H\frac{|0\rangle+i|1\rangle}{\sqrt2}
=\frac{1+i}{2}|0\rangle+\frac{1-i}{2}|1\rangle.$$

Each amplitude has squared magnitude $(1^2+1^2)/4=1/2$. Thus both outcomes remain equally likely. For $|+\rangle$, the amplitudes after $H$ are $(1+1)/2=1$ and $(1-1)/2=0$, giving outcome zero with certainty. Equal probabilities before an operation do not imply equal states; their relative phases can change subsequent predictions.

### Exercise 10 — product or entangled?

**Problem.** Decide whether

$$|\psi\rangle=\tfrac12(|00\rangle+|01\rangle+|10\rangle-|11\rangle)$$

is a product state. Verify normalization and compute its computational-basis probabilities.

**Solution.** Four coefficients have magnitude $1/2$, so their squared magnitudes sum to one. The coefficient matrix is $\tfrac12\begin{pmatrix}1&1\\1&-1\end{pmatrix}$, with determinant $-1/2\ne0$. It has rank two, whereas a product-state coefficient matrix has rank one. Hence this pure state is entangled. Every computational-basis outcome has probability $1/4$. These probabilities alone match those of the product state $|+\rangle\otimes|+\rangle$, but the minus sign creates a different quantum state. A single chosen measurement distribution cannot fully specify the state.

### Exercise 11 — a certificate is not a universal algorithm

**Problem.** A program solves one Boolean formula with one thousand variables and supplies a satisfying assignment. What mathematical claim has been established after the assignment is checked? What additional work would be needed to establish P=NP?

**Solution.** Verification establishes that this particular formula is satisfiable. The number of variables does not turn a single instance into a theorem about all instances. To establish P=NP by satisfiability, one would need an algorithm deciding satisfiability for every permitted input formula, a proof of correctness on both satisfiable and unsatisfiable inputs, and a polynomial worst-case running-time bound in the formula's encoded length. The known NP-completeness reduction would then transfer the bound to all NP decision problems. A fast run on one instance supplies none of those universal quantifiers by itself.

### Exercise 12 — an integral norm is not a pointwise bound

**Problem.** On $[0,1]$, define $g_n(x)=\sqrt n\,1_{(0,1/n)}(x)$. Compute its $L^2$ norm and its essential supremum. Explain why this is relevant to interpreting an energy estimate, while also stating what it does not prove about a PDE.

**Solution.** The squared $L^2$ norm is $\int n1_{(0,1/n)}=1$, so $\|g_n\|_2=1$ for every $n$. Its essential supremum is $\sqrt n$, because it has that value on a set of positive measure. Therefore uniformly bounded $L^2$ norms do not imply uniformly bounded pointwise magnitudes for an arbitrary family of functions. These discontinuous scalar examples are not Navier–Stokes solutions. They illustrate a logical gap in an attempted inference from an integral bound alone; they do not construct a fluid singularity or settle any existence question.

## Source and proof record

The historical sources consulted are Shannon's communication paper, Turing's computability paper, and the archived Riemann lecture. Contemporary primary instructional material comes from the named authors and teaching institutions linked at the relevant sections. The Open Logic Project distinguishes the original incompleteness argument from Rosser's refinement. Clay's own list supplies the dated frontier classifications. The retained source describes its exposition and practice solutions as newly written. This review checks the mathematics and cited dependencies; it does not independently certify originality or conduct an exhaustive textual-similarity search. Established results remain attributed to their mathematical literature.

Full proofs supplied here include the finite prefix-code Kraft bound, entropy lower bound for prefix codes, Hamming single-error correction, convex first-order characterization, smooth descent bound and its convex rate consequence, weak duality, halting undecidability, rational measure zero, finite orthogonal projection, and the unitary no-cloning contradiction. The channel-coding theorem, incompleteness machinery, general measure-convergence theorems, $L^2$ completeness, Fourier completeness and piecewise-smooth pointwise convergence, Slater necessity, normal-neighborhood local minimality, surface-curvature identity, Gauss–Bonnet and general quantum-channel representation remain imported results. The new derivations prove the stated consequences, not every prerequisite theorem. See EXTERNAL_DEPENDENCIES.md and CLAIM_PROOF_COVERAGE.md for the complete review boundary.

This distinction leaves the work inspectable: a reader can tell which conclusions were derived here, which depend on established theorems, and which current research statements remain unproved or under active review. The next mathematical work should preserve the same separation among definitions, hypotheses, proofs, examples and empirical measurements.


---

## New preparation note — 2026-10-15

The source manuscript is dated September 20, 2026 and was recovered from the existing teaching archive on October 14. Its exact bytes are retained privately with archive/member provenance. The earlier preparation copy preserved the body. The present corrected derivative makes the separately enumerated changes in ERRATA.md; preservation/source-manuscript.md retains that exact earlier preparation copy, including its former limitations and assertions. Original-source SHA-256: `cb12778c3e728933b6b0f3a8b4a913c15e18b56fbc4181e1c3378e24f220fb97`; original byte length: 59,125.

The original study context identifies the exposition as assistant-written reconstructions of established results, prepared for the project owner. The retained complex-analysis chapter names GAUCIA Actual; this preparation was performed by Codex as supporting reviewer. Do not convert preparation for the owner into an ownership or novelty claim over established theorems. The chapter is one part of a larger finite teaching collection and can refer to material in other volumes; this selection does not claim those other volumes are included.

At the earlier preparation stage, the historical bibliography and open-problem categories had not been newly checked and a complete proof audit was not asserted. The October 16 mathematical review now covers every section, calculation, stated proof and exercise in this selected chapter. It verifies the listed external statements against the specified primary or institutional sources and records what remains imported. It does not independently certify broad historical-priority assertions or reconstruct the entire prerequisite literature. No external Quasi-Riemann manuscript is included or reattributed, and this teaching manuscript must not substitute for missing original QEL research papers.


## License, attribution and review boundary — October 16, 2026

This corrected project-controlled expression remains subject to the unchanged [LICENSE.md](<../../../../LICENSE.md>) and [LICENSE_SCOPE.md](<../../../../LICENSE_SCOPE.md>). Section 8 preserves third-party rights, public-domain material, facts and mathematical principles; the project license does not claim ownership of established mathematics. The cited authors and institutions retain their own source rights. This review does not redistribute their books, papers, slides or exercise solutions. GAUCIA Actual remains the primary project agent; Codex prepared this supporting mathematical review for Sherman G. Laing / Quantum.Earth.Laing. Preparation and source integrity do not establish novelty, scientific certification or publication approval.
