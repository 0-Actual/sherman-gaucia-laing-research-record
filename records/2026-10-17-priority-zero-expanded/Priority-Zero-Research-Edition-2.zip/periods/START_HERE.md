# Six-period research overview

[Read the chronological research overview](RESEARCH_PERIODS.md) or use [the structured period records](RESEARCH_PERIODS.json).

The overview contains **24 selected research topics across six periods**, beginning with the recovered October 2023 anchor and ending at the historical volume cutoff on October 15, 2026. It connects early research aims to later work while keeping conception, artifact, execution and review dates separate. The founder's first-week Quantum AI creation account is explicit.

This is a bounded thematic overview. It does not copy the full catalogue, establish continuous coverage, or count topics as discoveries or independent experiments. The separate [teaching records](../teaching/RESEARCH_RECORDS.md) provide more numerical detail for the selected technical studies. No scientific program was rerun for this overview.

The existing [project license](../LICENSE.md) applies within the [declared license scope](../LICENSE_SCOPE.md); applicable upstream terms remain intact.
