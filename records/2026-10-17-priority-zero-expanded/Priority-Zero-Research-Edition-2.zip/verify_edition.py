"""Check exact research-package file bytes and membership without running components.

Only a real top-level .git directory is excluded as repository administration.
Other links, reparse points and nonregular entries are rejected. Regular empty
directories are outside the file-inventory claim. Concurrent writers are not locked.
"""
from pathlib import Path, PurePosixPath
import argparse
import hashlib
import json
import os
import re
import stat


class VerificationError(ValueError):
    pass


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise VerificationError('Duplicate JSON key')
        result[key] = value
    return result


def reject_constant(value):
    raise VerificationError('Nonfinite JSON number')


def ordinary_kind(path):
    metadata = path.lstat()
    if stat.S_ISLNK(metadata.st_mode) or getattr(metadata, 'st_file_attributes', 0) & 0x400:
        raise VerificationError('Link or reparse point: ' + path.name)
    if stat.S_ISREG(metadata.st_mode):
        return 'file'
    if stat.S_ISDIR(metadata.st_mode):
        return 'directory'
    raise VerificationError('Nonregular entry: ' + path.name)


def inventory(root):
    if ordinary_kind(root) != 'directory':
        raise VerificationError('Package root is not a directory')
    files = {}
    excluded_git = False
    pending = [root]
    while pending:
        directory = pending.pop()
        with os.scandir(directory) as entries:
            for entry in entries:
                path = Path(entry.path)
                kind = ordinary_kind(path)
                if directory == root and entry.name == '.git' and kind == 'directory':
                    excluded_git = True
                    continue
                if kind == 'directory':
                    pending.append(path)
                else:
                    files[path.relative_to(root).as_posix()] = path
    return files, excluded_git


def verify(root, expected_manifest_sha256=None):
    root = Path(root).absolute()
    files, excluded_git = inventory(root)
    if 'MANIFEST.json' not in files:
        raise VerificationError('Missing MANIFEST.json')
    manifest_bytes = files.pop('MANIFEST.json').read_bytes()
    manifest_digest = hashlib.sha256(manifest_bytes).hexdigest()
    if expected_manifest_sha256 is not None:
        if not re.fullmatch('[0-9a-f]{64}', expected_manifest_sha256):
            raise VerificationError('Expected manifest digest must be lowercase SHA-256')
        if manifest_digest != expected_manifest_sha256:
            raise VerificationError('Manifest differs from the supplied reference')
    data = json.loads(manifest_bytes.decode('utf-8'), object_pairs_hook=unique_object,
                      parse_constant=reject_constant)
    if not isinstance(data, dict) or not isinstance(data.get('files'), list):
        raise VerificationError('Manifest must contain a file list')
    expected = {}
    for row in data['files']:
        if not isinstance(row, dict):
            raise VerificationError('Invalid inventory row')
        relative = row.get('path')
        if not isinstance(relative, str) or not relative or '\\' in relative or ':' in relative or '\x00' in relative:
            raise VerificationError('Invalid inventory path')
        parsed = PurePosixPath(relative)
        if (not parsed.parts or parsed.is_absolute() or '..' in parsed.parts or parsed.as_posix() != relative
                or parsed.parts[0].casefold() == '.git' or relative == 'MANIFEST.json'
                or relative in expected):
            raise VerificationError('Invalid or duplicate inventory path')
        if type(row.get('bytes')) is not int or row['bytes'] < 0:
            raise VerificationError('Invalid byte count')
        if not isinstance(row.get('sha256'), str) or not re.fullmatch('[0-9a-f]{64}', row['sha256']):
            raise VerificationError('Invalid file digest')
        expected[relative] = row
    if set(files) != set(expected):
        raise VerificationError('Inventory membership differs')
    for relative, row in expected.items():
        path = files[relative]
        if ordinary_kind(path) != 'file':
            raise VerificationError('Nonregular component')
        content = path.read_bytes()
        if len(content) != row['bytes'] or hashlib.sha256(content).hexdigest() != row['sha256']:
            raise VerificationError('File mismatch: ' + relative)
    return {'status': 'PASS', 'checked_files': len(expected),
            'manifest_sha256': manifest_digest,
            'external_manifest_reference_checked': expected_manifest_sha256 is not None,
            'top_level_git_administration_excluded': excluded_git,
            'scope': 'unsigned package file-byte and membership consistency; regular empty directories are not inventoried'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', help='Optional digest from a separately trusted manifest copy')
    args = parser.parse_args()
    try:
        print(json.dumps(verify(Path(__file__).absolute().parent, args.manifest_sha256), ensure_ascii=True))
        return 0
    except (OSError, ValueError, TypeError, IndexError) as error:
        print(json.dumps({'status': 'FAIL', 'reason': str(error)}, ensure_ascii=True))
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
