# Reproduce the selected research calculations

This edition supplies research source, inputs and declared arithmetic. The preparation adapters are dated October 16, 2026; dates within saved measurements remain historical dates. The adapters do not establish a new scientific experiment.

Run from this directory using Python 3.10 or later:

```text
python -B run_checks.py
```

This executes four quantum identity fixture groups, recalculates 33 historical means from 990 counter readings, and checks six saved Bible arithmetic records. These commands print results and do not modify the packaged inputs. A nonzero exit status denotes a failed or incomplete invocation; retain the actual output when recording a run.

For the Q8 aluminum saved-state and score replay, use Node.js (the earlier preparation used version 24.20.0):

```text
node q8-numerical/check_saved_states.mjs
```

This reads 1,041 Wannier blocks, rebuilds the 24 represented matrices, recalculates 192 saved circuit states and energies, and recalculates four saved score comparisons. It does not fit an optimizer or measure the original timing results. No package installation or network access is required. Nine numerical modules and their relative imports are included. Some exported optimization routines remain available as historical source but are not exercised by this command.

The Q8 calculations simulate quantum states on a classical computer. The supplied material is aluminum JVASP-816. Original reference answers had been seen; the study was not blind testing, unseen-material evaluation or evidence of quantum advantage. A conventional solver was faster and more accurate in the retained full-study comparison. Host counter observations are observational and do not establish that USB storage caused a system-wide performance change.

The quantum fixtures teach established tensor products, normalized expectation values, phase-insensitive state distance and a spectral-gap bound. They are preparation examples, not historical performance results. Bible arithmetic verifies declared spellings, counts and sums; it does not establish theological conclusions from numerical patterns.

## Hebrew converter

The H04.1 converter is supplied unchanged with 39 book XML files, the verse map and its 12-method unit suite. The XML population includes alternate readings. Its flattened export omits reading-container metadata; it is not a uniquely selected reading or a count of distinct linguistic words. The retained Jeremiah metadata amendment is a reviewed local change, not upstream maintainer approval.

Use a disposable copy of `hebrew-h041` to keep the selected source immutable. From inside that copy:

```text
python -B verification/test_converter.py
python -B candidate/morphhbXML-to-JSON.py --includeIds
python -B candidate/morphhbXML-to-JSON.py --remapVerses --includeIds
```

The last two commands create `hebrew.json` and `remapped.json` in the copy. Repeated runs can replace those outputs; preserve any output you need before rerunning. This preparation includes the implementation and data, but does not claim a new whole-corpus export or exhaustive linguistic certification. The historical H04.1 checks remain historical evidence.

See `ATTRIBUTION_AND_NOTICES.md` and the component notices before reuse. File hashes identify this derivative selection and do not establish authorship, historical dates or scientific correctness.

## Corrected numerical boundaries and retained materials findings

See [correction instructions](corrections/README.md) for the separately authored numerical teaching module and focused regression tests. See [materials consistency replay](corrections/materials/README.md) for the supplied descriptive findings and the exact boundary of that replay. Neither command reruns the full historical scientific study.
