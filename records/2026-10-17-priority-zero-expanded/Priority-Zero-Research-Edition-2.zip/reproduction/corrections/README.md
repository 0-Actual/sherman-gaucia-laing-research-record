# Five numerical boundary corrections

Prepared October 16, 2026 for the Priority Zero research edition. These are newly corrected research derivatives. The original versions and their errors remain preserved separately. Their historical results have not been rewritten.

| Boundary | Preserved error | Corrected behavior |
|---|---|---|
| Tiny angular error | A small squared denominator was replaced by a zero ratio, even when zero gain left the error unchanged. | A stable sinc expression retains ratio one when no change occurs. A step at or below the declared deadband also has ratio one. |
| Signed temperature error | A one-sided comparison accepted a large negative miss. | The magnitude must be strictly below 0.001 by default; both signs and the exact threshold are checked. |
| Subspace projection | Disabling explicit normalization still passed through an unconditional normalizer. | The false option preserves projected support mass, including zero. The true option conditions on numerically resolved support. |
| Noise-scale labels | The first observation was always named scale one, although other orderings were admitted. | The first scale is named explicitly; scale-one bias uses its actual position or is absent when no scale-one observation exists. |
| Workflow membership | Two sets with six members were accepted without comparing their identities. | An explicit one-to-one naming dictionary is checked against both complete memberships. Duplicates and unrelated names fail. |

The standalone module expresses only these numerical/API ideas. It is not a reconstruction of the complete earlier research programs. The supplied examples use synthetic numbers and small matrices. In particular, the angular ratio is a scalar sample, not a theorem of continuous-envelope, full-state or physical stability. Its default deadband is 1e-10. Matrix input checks use stated floating-point tolerances; accepting a tiny negative eigenvalue as roundoff is not an exact positivity proof.

From this directory, with Python 3.11 or later and NumPy 2.3.5 available, run:

```text
python -B test_numerical_boundaries.py
```

The test suite has 16 methods. It performs no optimizer training, scientific timing benchmark, random sampling, network access or hardware operation. The file `requirements.txt` pins the tested NumPy version; it does not claim an offline wheel bundle is supplied. Python 3.12.14 was used for preparation verification.

Separate private checks compare the exact retained versions with their corrected versions in 12 focused methods. The scale API check substitutes a deterministic sample fixture and rejects access to an unused dependency. A full dependency import first stopped because SciPy was unavailable; that stopped attempt is retained. This is not a full original-suite execution or a dependency-closure pass. The saved nominal results are not reclassified as failures.

During independent review, the new projection adapter was also found to accept a finite matrix whose summed trace overflowed, incorrectly returning zero support. The earlier adapter and the observed zero result remain preserved. The corrected adapter rejects a nonfinite trace and uses safer symmetrization; its regression includes the actual large-input counterexample. This is a preparation error and correction, not a newly failed historical study.

The corrected full decoder likewise rejects an invalid input-normalization result before accepting a zero subspace projection. A valid density matrix with genuinely zero subspace support still returns zero when normalization is disabled. An overly strict exact-equality assertion in the large-value regression initially failed by approximately 1.1e-16; the test now uses an explicit 2e-16 absolute tolerance for that finite normalization. The stopped import, erroneous adapter versions and failed assertion remain part of the correction history.

The `materials` subdirectory supplies Python-standard-library checks of selected saved JARVIS-DFT 2D evidence and an independently authored descriptive replay of a pinned, reacquired public source. Its README separates the new source recount from the original program and explains the remaining historical source and analysis gaps.

No physical accuracy, new mathematical theorem, scientific certification or broader historical correctness follows from these boundary tests. A changed scale receipt now allows an absent scale-one value; callers of the corrected full version must handle that case. See `ATTRIBUTION.md`, `LICENSE.md` and `VALIDATION.json` for attribution, reuse scope and the exact recorded verification.
