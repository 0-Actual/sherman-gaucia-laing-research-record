"""Recalculate consistency of selected historical evidence, not the original dataset."""
from pathlib import Path
import json
import math


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_rows(rows):
    require(isinstance(rows,list), 'records must be a list')
    identifiers=[r['jid'] for r in rows]
    require(all(isinstance(x,str) and x.startswith('JVASP-') for x in identifiers), 'invalid material identifier')
    require(len(set(identifiers))==len(identifiers), 'duplicate material identifier')
    return {r['jid']:r for r in rows}


def positive_integer(value):
    return isinstance(value,int) and not isinstance(value,bool) and value>0


def verify(data):
    require(data['schema']=='retained-materials-observations/1','unknown schema')
    scope=data['historical_scope']
    require(positive_integer(scope['records']), 'invalid declared population')
    missing=data['missing_exfoliation']
    missing_rows=unique_rows(missing['records'])
    require(len(missing_rows)==missing['declared_missing_count'],'missing-value count mismatch')
    require(all(r['raw_exfoliation_energy']=='na' for r in missing_rows.values()), 'missing value was imputed or altered')
    require(missing['declared_total_records']==scope['records'],'population mismatch')
    require(positive_integer(missing['declared_numeric_count']),'invalid numeric count')
    require(len(missing_rows)+missing['declared_numeric_count']==scope['records'],'numeric and missing counts do not sum to declared population')
    differences=data['atom_count_differences']
    difference_rows=unique_rows(differences['records'])
    require(len(difference_rows)==differences['declared_count'],'count-difference population mismatch')
    for row in difference_rows.values():
        nat=row['nat_field'];actual=row['supplied_structure_atom_count']
        require(all(positive_integer(x) for x in (nat,actual,row['coordinate_count'])),'invalid atom count')
        require(actual==row['coordinate_count'] and actual!=nat,'not the recorded count difference')
        require(math.isclose(actual/nat,row['ratio_structure_atoms_to_nat'],rel_tol=0,abs_tol=1e-12),'atom-count ratio mismatch')
    follow=data['followup']
    follow_rows=unique_rows(follow['records'])
    require(set(follow_rows)==set(difference_rows),'follow-up IDs do not match the original differences')
    supporting=follow['supporting_repeated_cell_interpretation_jids'];unresolved=follow['unresolved_jids']
    require(len(set(supporting))==len(supporting) and len(set(unresolved))==len(unresolved),'duplicate follow-up classification')
    require(not set(supporting)&set(unresolved),'overlapping follow-up classification')
    require(set(supporting)|set(unresolved)==set(difference_rows),'follow-up classification is incomplete')
    supported_by_saved_counts=[]
    for jid,row in follow_rows.items():
        earlier=difference_rows[jid]
        require(row['nat']==earlier['nat_field'] and row['structure_count']==earlier['supplied_structure_atom_count'],'follow-up counts changed')
        require(math.isclose(row['ratio'],row['structure_count']/row['nat'],rel_tol=0,abs_tol=1e-12),'follow-up ratio mismatch')
        require(all(positive_integer(x) for x in row['species_counts'].values()),'invalid species count')
        require(sum(row['species_counts'].values())==row['structure_count'],'species totals mismatch')
        require(positive_integer(row['recorded_translation_count']),'invalid translation count')
        if math.isclose(row['ratio'],row['recorded_translation_count'],rel_tol=0,abs_tol=1e-12):
            supported_by_saved_counts.append(jid)
    require(set(supported_by_saved_counts)==set(supporting),'saved ratio/translation-count correspondence differs from reported classification')
    require(follow['cause_proven'] is False,'unresolved causal qualification was changed')
    flags=data['retained_check_flags']
    require(flags['catalog_count_matches_download'] is (data['declared_catalog_records']==scope['records']),'catalog flag does not match declared counts')
    require(flags['nat_metadata_matches_supplied_structure'] is (len(difference_rows)==0),'atom metadata flag disagrees with differences')
    return {
        'status':'PASS_SELECTED_EVIDENCE_CONSISTENCY',
        'missing_value_rows_checked':len(missing_rows),'count_difference_rows_checked':len(difference_rows),
        'followup_rows_checked':len(follow_rows),'supported_classification_rows':len(supporting),'unresolved_classification_rows':len(unresolved),
        'historical_population_declared_not_recounted':scope['records'],
        'retained_scientific_check_flags':flags,
        'raw_dataset_reanalyzed':False,'geometric_diagnostic_rerun':False,'physical_calibration_established':False,
    }


if __name__=='__main__':
    data=json.loads((Path(__file__).resolve().parent/'saved_findings.json').read_text(encoding='utf8'))
    print(json.dumps(verify(data),indent=2))
