import copy
import hashlib
import io
import json
from types import SimpleNamespace
import unittest
import zipfile

from replay_source import census,load_source


class MemoryArchive:
    """Exercise the reader's byte/ZIP checks without filesystem fixture writes."""
    def __init__(self,body):self.body=body
    def stat(self):return SimpleNamespace(st_size=len(self.body))
    def read_bytes(self):return self.body


class SourceReplayTests(unittest.TestCase):
    def test_synthetic_census_keeps_missingness_and_count_difference(self):
        rows=[{'jid':'JVASP-1','formula':'X','nat':1,'exfoliation_energy':'na','atoms':{'elements':['X','X'],'coords':[[0,0,0],[1,0,0]]}},
              {'jid':'JVASP-2','formula':'Y','nat':1,'exfoliation_energy':0.0,'atoms':{'elements':['Y'],'coords':[[0,0,0]]}}]
        result=census(rows)
        self.assertEqual(result['numeric_exfoliation_count'],1)
        self.assertEqual(len(result['missing_rows']),1)
        self.assertEqual(result['difference_rows'][0]['ratio_structure_atoms_to_nat'],2)
        self.assertEqual(result['species']['JVASP-1'],{'X':2})

    def test_duplicate_ids_and_unknown_missing_token_rejected(self):
        row={'jid':'JVASP-1','formula':'X','nat':1,'exfoliation_energy':'na','atoms':{'elements':['X'],'coords':[[0,0,0]]}}
        with self.assertRaises(ValueError):census([row,copy.deepcopy(row)])
        row['exfoliation_energy']='unknown'
        with self.assertRaises(ValueError):census([row])

    def test_pinned_archive_and_changed_hash(self):
        raw=b'[]';buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w') as archive:archive.writestr('fixture.json',raw)
        body=buffer.getvalue()
        identity={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'member':'fixture.json','member_bytes':len(raw),'member_sha256':hashlib.sha256(raw).hexdigest()}
        source=MemoryArchive(body)
        self.assertEqual(load_source(source,identity),[])
        identity['sha256']='0'*64
        with self.assertRaises(ValueError):load_source(source,identity)

    def test_unlisted_archive_member_is_rejected(self):
        raw=b'[]';buffer=io.BytesIO()
        with zipfile.ZipFile(buffer,'w') as archive:
            archive.writestr('fixture.json',raw);archive.writestr('extra.txt','unexpected')
        body=buffer.getvalue()
        identity={'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'member':'fixture.json','member_bytes':len(raw),'member_sha256':hashlib.sha256(raw).hexdigest()}
        with self.assertRaises(ValueError):load_source(MemoryArchive(body),identity)


if __name__=='__main__':unittest.main(verbosity=2)
