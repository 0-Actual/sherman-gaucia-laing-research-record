# Source attribution and modification notice

Underlying dataset attribution retained from the source companion: **Kamal Choudhary**, JARVIS-DFT 2D data, DOI [10.6084/m9.figshare.6815705.v8](https://doi.org/10.6084/m9.figshare.6815705.v8), file ID 38521268, archive `d2-12-12-2022.json.zip`. The retained source identifies the data license as [Creative Commons Attribution 4.0](https://creativecommons.org/licenses/by/4.0/).

`saved_findings.json` is an explicitly selected derivative of previously recorded diagnostics and missing-value lists. It is not an unchanged copy of the complete upstream dataset. Selection, computed diagnostics, classifications and the new checker are identified as such. Underlying data and independently applicable third-party terms remain separate from the project's license; no NIST or source-author endorsement is implied.

Research selection and account: **Sherman G. Laing / Quantum.Earth.Laing**. Primary project agent: **GAUCIA Actual**. Supporting numerical preparation and review: **Codex**, with AI assistance disclosed. New checker and tests: October 16, 2026. The earlier observation dates remain historical evidence; this date is not a claim of original discovery or first public disclosure.
