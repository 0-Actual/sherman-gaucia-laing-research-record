# Replay of selected materials evidence

This portable, Python-standard-library-only check makes the selected saved findings testable. It checks 355 missing exfoliation-value rows, recalculates 42 atom-count ratios, compares species totals, and checks the recorded follow-up division into 40 supported repeated-cell interpretations and two unresolved cases. It retains the false catalog-count and atom-metadata flags.

From this directory, run:

```text
python -B check_saved_findings.py
python -B test_materials_checks.py
```

The first command prints the consistency result. The second includes rejection tests for altered ratios, erased adverse flags, duplicate rows, zero-imputed missing values and changed follow-up membership. Neither command writes output files or downloads anything.

The 1,103-record population, 65 top-level fields and 1,861,469 scalar-leaf occurrences are historical declarations from the saved companion. They are not independently recounted by the two commands above. The comparison of recorded translation counts to count ratios does not rerun the periodic-geometry calculation or establish crystallographic equivalence. The two unresolved structures and the 1,109-versus-1,103 catalog difference remain unresolved.

## Recount the public source

The dated public archive was reacquired from its original cited file URL. Its archive size, JSON-member size and version match the earlier account. `SOURCE_IDENTITY.json` pins the newly acquired archive and member hashes. No historical hash was recovered, so this agreement does not establish exact historical byte identity.

Obtain [file 38521268](https://ndownloader.figshare.com/files/38521268), retain the filename `d2-12-12-2022.json.zip`, and run from this directory with the archive's actual path:

```text
python -B replay_source.py --source d2-12-12-2022.json.zip
python -B test_source_replay.py
```

The source reader rejects a size, hash or member mismatch. It independently recounts 1,103 records, a union of 65 top-level fields, 1,861,469 scalar leaves and 748 numeric exfoliation values. It compares all 355 missing-value rows and all 42 atom-count difference rows to the saved lists, including identifiers and formulas, and checks all 42 recorded follow-up species totals against the source. Those checks passed on the pinned reacquired input. The archive is not bundled in this selection; only `replay_source.py` requires that separately identified source. `test_source_replay.py` uses small synthetic, in-memory fixtures and needs no download. No network access occurs during either command.

`replay_source.py` is a new, independently authored descriptive implementation. Original `analyze.py`, follow-up analysis code and original full deterministic outputs were not recovered by the bounded inventory/companion-locator checks. The earlier documents say they were privately preserved but do not provide an attachment identifier. Recounting the full data population does not reproduce every historical analysis of the 65 fields. The periodic-geometry diagnostic, descriptor-generation provenance, detailed tensor/transport interpretation and full original output-by-output comparison remain outside this replay. This wider 2D materials census is separate from the aluminum saved-state replay.

This selection adds newly written consistency and descriptive-source checks dated October 16, 2026. The two test files contain eight methods in total. It does not claim a new materials simulation, hardware result, benchmark, physical calibration or full reproduction of the original study. See `NOTICE.md` for the retained third-party attribution and modification notice.
