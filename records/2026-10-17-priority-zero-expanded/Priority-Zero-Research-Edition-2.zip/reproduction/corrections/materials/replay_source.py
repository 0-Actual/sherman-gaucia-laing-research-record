"""Independently authored descriptive replay of a pinned public source archive.

This is a correction-era reimplementation, not the recovered original analyze.py.
Reads the supplied file, prints a report, and does not download or write data.
"""
import argparse
from collections import Counter
import hashlib
import io
import json
import math
from pathlib import Path
import zipfile

from check_saved_findings import positive_integer, require, unique_rows, verify

ROOT=Path(__file__).resolve().parent


def load_source(path, identity):
    require(path.stat().st_size==identity['bytes'],'source archive size mismatch')
    body=path.read_bytes()
    require(hashlib.sha256(body).hexdigest()==identity['sha256'],'source archive hash mismatch')
    with zipfile.ZipFile(io.BytesIO(body)) as archive:
        require(archive.namelist()==[identity['member']],'unexpected archive membership')
        info=archive.getinfo(identity['member'])
        require(info.file_size==identity['member_bytes'],'source member size mismatch')
        raw=archive.read(identity['member'])
    require(hashlib.sha256(raw).hexdigest()==identity['member_sha256'],'source member hash mismatch')
    records=json.loads(raw)
    require(isinstance(records,list),'source records must be a list')
    return records


def leaf_count(value):
    if isinstance(value,dict):return sum(leaf_count(v) for v in value.values())
    if isinstance(value,list):return sum(leaf_count(v) for v in value)
    return 1


def census(records):
    missing=[];differences=[];numeric=0;fields=set();species={}
    unique_rows(records)
    for row in records:
        fields.update(row)
        energy=row['exfoliation_energy']
        if energy=='na':
            missing.append({k:row[k] for k in ('jid','formula')} | {'raw_exfoliation_energy':'na'})
        else:
            require(isinstance(energy,(int,float)) and not isinstance(energy,bool) and math.isfinite(energy),'unexpected exfoliation value')
            numeric+=1
        atoms=row['atoms'];elements=atoms['elements'];coordinates=atoms['coords']
        require(isinstance(elements,list) and isinstance(coordinates,list),'invalid supplied structure arrays')
        require(all(isinstance(x,str) and x for x in elements),'invalid element labels')
        require(len(elements)==len(coordinates),'element and coordinate counts differ')
        nat=row['nat']
        require(positive_integer(nat) and positive_integer(len(elements)),'invalid atom count')
        species[row['jid']]=dict(Counter(elements))
        if nat!=len(elements):
            differences.append({
                'jid':row['jid'],'formula':row['formula'],'nat_field':nat,
                'coordinate_count':len(coordinates),'supplied_structure_atom_count':len(elements),
                'ratio_structure_atoms_to_nat':len(elements)/nat,
            })
    return {'records':len(records),'top_level_fields':len(fields),'scalar_leaf_occurrences':leaf_count(records),
            'numeric_exfoliation_count':numeric,'missing_rows':missing,'difference_rows':differences,'species':species}


def compare_to_saved(observed,saved):
    consistency=verify(saved)
    for key in ('records','top_level_fields','scalar_leaf_occurrences'):
        require(observed[key]==saved['historical_scope'][key],f'{key} differs from the saved declaration')
    require(observed['numeric_exfoliation_count']==saved['missing_exfoliation']['declared_numeric_count'],'numeric exfoliation count differs')
    require(unique_rows(observed['missing_rows'])==unique_rows(saved['missing_exfoliation']['records']),'missing-value records differ')
    require(unique_rows(observed['difference_rows'])==unique_rows(saved['atom_count_differences']['records']),'atom-count difference records differ')
    for row in saved['followup']['records']:
        require(observed['species'][row['jid']]==row['species_counts'],'recorded follow-up composition differs from source')
    return {
        'status':'PASS_PINNED_SOURCE_DESCRIPTIVE_REPLAY',
        'source_records_recounted':observed['records'],'top_level_field_union_count':observed['top_level_fields'],
        'scalar_leaf_occurrences_recounted':observed['scalar_leaf_occurrences'],
        'numeric_exfoliation_values_recounted':observed['numeric_exfoliation_count'],
        'missing_value_rows_exactly_matched':len(observed['missing_rows']),
        'atom_count_difference_rows_exactly_matched':len(observed['difference_rows']),
        'followup_species_counts_matched':len(saved['followup']['records']),
        'retained_scientific_check_flags':consistency['retained_scientific_check_flags'],
        'original_analysis_program_recovered':False,'historical_byte_identity_established':False,
        'full_65_field_scientific_analysis_reproduced':False,
        'geometric_diagnostic_rerun':False,'new_physical_or_simulation_experiment':False,
    }


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source',type=Path,required=True,help='Downloaded d2-12-12-2022.json.zip matching SOURCE_IDENTITY.json')
    args=parser.parse_args()
    identity=json.loads((ROOT/'SOURCE_IDENTITY.json').read_text(encoding='utf8'))
    saved=json.loads((ROOT/'saved_findings.json').read_text(encoding='utf8'))
    result=compare_to_saved(census(load_source(args.source,identity)),saved)
    result['reacquired_archive_sha256']=identity['sha256']
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
