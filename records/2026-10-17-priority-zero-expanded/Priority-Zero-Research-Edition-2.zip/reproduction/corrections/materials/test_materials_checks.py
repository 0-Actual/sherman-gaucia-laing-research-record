import copy
import json
from pathlib import Path
import unittest

from check_saved_findings import verify


class MaterialsConsistencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=json.loads((Path(__file__).resolve().parent/'saved_findings.json').read_text(encoding='utf8'))

    def test_saved_evidence_replays_with_false_flags_retained(self):
        result=verify(self.data)
        self.assertEqual(result['missing_value_rows_checked'],355)
        self.assertEqual(result['count_difference_rows_checked'],42)
        self.assertEqual(result['supported_classification_rows'],40)
        self.assertEqual(result['unresolved_classification_rows'],2)
        self.assertEqual(list(result['retained_scientific_check_flags'].values()),[False,False])

    def test_altered_ratio_and_erased_failure_rejected(self):
        bad=copy.deepcopy(self.data)
        bad['atom_count_differences']['records'][0]['ratio_structure_atoms_to_nat']=0
        with self.assertRaises(ValueError):verify(bad)
        bad=copy.deepcopy(self.data)
        bad['retained_check_flags']['catalog_count_matches_download']=True
        with self.assertRaises(ValueError):verify(bad)

    def test_duplicate_missing_value_and_imputation_rejected(self):
        bad=copy.deepcopy(self.data)
        bad['missing_exfoliation']['records'][1]=copy.deepcopy(bad['missing_exfoliation']['records'][0])
        with self.assertRaises(ValueError):verify(bad)
        bad=copy.deepcopy(self.data)
        bad['missing_exfoliation']['records'][0]['raw_exfoliation_energy']=0
        with self.assertRaises(ValueError):verify(bad)

    def test_changed_followup_membership_rejected(self):
        bad=copy.deepcopy(self.data)
        bad['followup']['supporting_repeated_cell_interpretation_jids'][0]=bad['followup']['unresolved_jids'][0]
        with self.assertRaises(ValueError):verify(bad)


if __name__=='__main__':
    unittest.main(verbosity=2)
