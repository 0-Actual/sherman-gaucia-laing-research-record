"""Focused synthetic regression tests. No benchmark, optimization, or hardware call."""
import math
import unittest

import numpy as np

from numerical_boundaries import (
    angle_error_ratio, projected_density, scale_bias,
    temperature_error_accepted, workflow_membership_matches,
)


class NumericalBoundaryTests(unittest.TestCase):
    def test_zero_gain_tiny_error_preserves_ratio_one(self):
        theta = 1e-8
        before = math.sin(theta / 2) ** 2
        old_ratio = 0.0 if before <= 1e-15 else 1.0
        self.assertEqual(old_ratio, 0.0)  # Historical shortcut, shown as a counterexample.
        self.assertEqual(angle_error_ratio(theta, 0, 1), 1.0)
        self.assertEqual(angle_error_ratio(5e-324, 0, 1), 1.0)

    def test_deadband_keeps_the_angle_unchanged(self):
        self.assertEqual(angle_error_ratio(1e-11, 0.5, 1), 1.0)
        self.assertEqual(angle_error_ratio(2e-10, 0.5, 1), 1.0)
        self.assertAlmostEqual(angle_error_ratio(1e-11, 0.5, 1, deadband=0), 0.25)

    def test_stable_formula_agrees_with_direct_ratio(self):
        for theta, gain, cap in [(0.4, 0.2, 0.8), (math.pi, 0.5, 0.3), (1e-7, 0.7, 1), (0.1, 1, 1)]:
            with self.subTest(theta=theta, gain=gain):
                step = min(theta * gain, cap, theta)
                expected = (math.sin((theta-step)/2)/math.sin(theta/2))**2
                self.assertAlmostEqual(angle_error_ratio(theta, gain, cap), expected, places=14)

    def test_angle_input_rejections(self):
        for arguments in [(0, 0.5, 1), (-0.1, 0.5, 1), (0.1, -1, 1), (0.1, 2, 1), (0.1, 0.5, 0), (float('nan'), 0.5, 1)]:
            with self.subTest(arguments=arguments), self.assertRaises(ValueError):
                angle_error_ratio(*arguments)

    def test_temperature_both_signs_and_strict_threshold(self):
        self.assertTrue(-1 < 0.001)  # The previous signed predicate accepted this miss.
        for value, expected in [(-1, False), (1, False), (-0.001, False), (0.001, False), (-0.0009, True), (0.0009, True), (0, True)]:
            with self.subTest(value=value):
                self.assertEqual(temperature_error_accepted(value), expected)

    def test_temperature_nonfinite_values_rejected(self):
        for value in [float('nan'), float('inf'), -float('inf')]:
            self.assertFalse(temperature_error_accepted(value))
        with self.assertRaises(ValueError):
            temperature_error_accepted(0, tolerance=0)

    def test_projection_preserves_partial_support(self):
        rho = np.diag([0.25, 0, 0.75]).astype(complex)
        basis = np.eye(3, dtype=complex)[:, :2]
        result = projected_density(rho, basis, normalize=False)
        np.testing.assert_allclose(result, np.diag([0.25, 0]), atol=1e-15)
        normalized = projected_density(rho, basis)
        self.assertAlmostEqual(float(np.trace(normalized).real), 1)
        self.assertAlmostEqual(float(np.trace(result).real), 0.25)
        np.testing.assert_array_equal(rho, np.diag([0.25, 0, 0.75]))

    def test_zero_support_returns_zero_only_without_normalization(self):
        rho = np.diag([0, 0, 1]).astype(complex)
        basis = np.eye(3, dtype=complex)[:, :2]
        np.testing.assert_array_equal(projected_density(rho, basis, normalize=False), np.zeros((2, 2)))
        with self.assertRaises(ValueError):
            projected_density(rho, basis)

    def test_projection_keeps_complex_coherence(self):
        state = np.array([1, 1j, 0], dtype=complex) / np.sqrt(2)
        rho = 0.3*np.outer(state, state.conj()) + np.diag([0, 0, 0.7])
        basis = np.eye(3, dtype=complex)[:, :2]
        result = projected_density(rho, basis, normalize=False)
        np.testing.assert_allclose(result, rho[:2, :2], atol=1e-15)
        self.assertGreaterEqual(float(np.linalg.eigvalsh(result).min()), -1e-15)

    def test_projection_rejects_invalid_input(self):
        basis = np.eye(3, dtype=complex)[:, :2]
        for rho in [np.diag([2, -1, 0]), np.zeros((3, 3)), np.full((3, 3), np.nan), np.array([[1, 1, 0], [0, 0, 0], [0, 0, 0]])]:
            with self.assertRaises(ValueError):
                projected_density(rho, basis)
        with self.assertRaises(ValueError):
            projected_density(np.eye(3), np.ones((3, 2)))

    def test_huge_finite_entries_cannot_silently_erase_support(self):
        with self.assertRaises(ValueError):
            projected_density(np.diag([6e307]*4), np.eye(4)[:, :2], normalize=False)
        # A representable trace remains usable without overflowing symmetrization.
        result = projected_density(np.diag([1e308, 0]), np.eye(2), normalize=False)
        np.testing.assert_allclose(result, np.diag([1, 0]), atol=2e-16, rtol=0)

    def test_scale_one_can_appear_later(self):
        result = scale_bias((3, 1, 5), (0.4, 0.7, 0.2), 0.8)
        self.assertEqual(result.first_sampled_scale, 3)
        self.assertAlmostEqual(result.raw_bias_at_first_scale, -0.4)
        self.assertAlmostEqual(result.raw_bias_at_scale_one, -0.1)

    def test_absent_scale_one_has_no_invented_value(self):
        result = scale_bias((2, 4, 6), (0.6, 0.3, 0.1), 0.8)
        self.assertIsNone(result.raw_bias_at_scale_one)
        self.assertAlmostEqual(result.raw_bias_at_first_scale, -0.2)
        result = scale_bias((1, 3, 5), (0.6, 0.3, 0.1), 0.8)
        self.assertEqual(result.raw_bias_at_first_scale, result.raw_bias_at_scale_one)

    def test_scale_mismatch_duplicates_and_nonfinite_rejected(self):
        for scales, values in [((1, 1), (0.2, 0.3)), ((1, 3), (0.2,)), ((0, 3), (0.2, 0.3)), ((True, 3), (0.2, 0.3)), ((1, 3), (0.2, math.nan))]:
            with self.subTest(scales=scales), self.assertRaises(ValueError):
                scale_bias(scales, values, 0.8)

    def test_equal_cardinality_does_not_imply_membership(self):
        names = [f'Display {i}' for i in range(6)]
        mapping = {name: f'RESULT_{i}' for i, name in enumerate(names)}
        observed = [f'UNRELATED_{i}' for i in range(6)]
        self.assertEqual(len(set(names)), len(set(observed)))
        self.assertFalse(workflow_membership_matches(names, observed, mapping))
        self.assertTrue(workflow_membership_matches(names, list(reversed(list(mapping.values()))), mapping))

    def test_duplicate_or_unknown_members_are_rejected(self):
        names = ['Alpha', 'Beta']
        mapping = {'Alpha': 'A', 'Beta': 'B'}
        for approved, observed, aliases in [(['Alpha', 'Alpha'], ['A', 'B'], mapping), (names, ['A', 'B', 'B'], mapping), (['Alpha', 'Unknown'], ['A', 'B'], mapping), (names, ['A', 'B'], {'Alpha': 'A', 'Beta': 'A'}), (names, ['A'], mapping)]:
            self.assertFalse(workflow_membership_matches(approved, observed, aliases))


if __name__ == '__main__':
    unittest.main(verbosity=2)
