# Attribution and included material

Research program and owner direction: **Sherman G. Laing / Quantum.Earth.Laing**. Primary project agent: **GAUCIA Actual**. Correction implementation, test preparation and supporting review: **Codex**, with AI assistance disclosed.

The numerical module, tests and explanations are correction-era derivatives prepared October 16, 2026. They teach established numerical and linear-algebra concepts and the five version-specific mistakes described in the README. No claim of ownership over mathematical principles is made.

The owner's Quantum.Earth.Laing Noncommercial Research and Evaluation License, Version 1.0, is supplied verbatim in `LICENSE.md`. Its terms apply to the project-controlled code, tests, documentation and data arrangement actually included in this correction selection, within the rights the owner controls. The historical phrase excluding absent development code does not exclude the code expressly supplied here. Third-party rights and independently applicable licenses remain governed by section 8.

NumPy is an external dependency and is not redistributed by this selection. No NumPy source or bundled binary is included. Its own applicable license remains separate.

The owner has not approved a public upload of this exact correction selection. File identities and test results are not a signature, independent timestamp or guarantee of attribution through arbitrary copying and rewriting.
