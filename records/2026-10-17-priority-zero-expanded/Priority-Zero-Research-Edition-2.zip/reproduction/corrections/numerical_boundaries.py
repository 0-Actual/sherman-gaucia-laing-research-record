"""Small research-only numerical corrections, separately authored in October 2026.

These functions expose mathematical/API boundaries for teaching and testing.
They are neither a historical full-program reconstruction nor physical experiments.
Project attribution and reuse terms are in ATTRIBUTION.md and LICENSE.md.
"""
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
import math
import numbers

import numpy as np


def _finite(value, name):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, numbers.Real):
        raise ValueError(f"{name} must be a finite real number")
    value = float(value)
    if not math.isfinite(value):
        raise ValueError(f"{name} must be a finite real number")
    return value


def angle_error_ratio(angle, gain, maximum_step, *, deadband=1e-10):
    """Return sin(residual/2)^2 / sin(angle/2)^2 without squaring a tiny divisor.

    Domain: 0 < angle <= pi, 0 <= gain <= 1, 0 < maximum_step <= pi.
    A requested step at or below deadband leaves the angle unchanged.
    This is one scalar sample, not proof of stability across a continuous envelope.
    """
    angle = _finite(angle, "angle")
    gain = _finite(gain, "gain")
    maximum_step = _finite(maximum_step, "maximum_step")
    deadband = _finite(deadband, "deadband")
    if not 0 < angle <= math.pi or not 0 <= gain <= 1:
        raise ValueError("angle or gain outside its domain")
    if not 0 < maximum_step <= math.pi or not 0 <= deadband <= math.pi:
        raise ValueError("maximum_step or deadband outside its domain")
    applied = min(gain * angle, maximum_step, angle)
    if applied <= deadband:
        return 1.0
    residual = angle - applied
    fraction = residual / angle
    before_sinc = float(np.sinc(angle / (2.0 * math.pi)))
    after_sinc = float(np.sinc(residual / (2.0 * math.pi)))
    return (fraction * after_sinc / before_sinc) ** 2


def temperature_error_accepted(error, tolerance=0.001):
    """An error is accepted only when its magnitude is strictly below tolerance.

    Nonfinite error values are rejected. The tolerance must be finite and positive.
    This predicate is one acceptance condition, not evidence of a completed run.
    """
    tolerance = _finite(tolerance, "tolerance")
    if tolerance <= 0:
        raise ValueError("tolerance must be positive")
    if isinstance(error, (bool, np.bool_)) or not isinstance(error, numbers.Real):
        raise ValueError("error must be a real number")
    return math.isfinite(float(error)) and abs(float(error)) < tolerance


def projected_density(rho, isometry, *, normalize=True):
    """Project a normalized density matrix into an orthonormal column subspace.

    normalize=False returns E* rho E with its original support mass, including
    the zero matrix. normalize=True conditions on support and requires mass > 1e-10.
    Input trace is normalized, matching the retained decoder's input convention.
    Unlike the historical input validator, non-Hermitian inputs are rejected.
    Hermiticity uses absolute tolerance 1e-10. Eigenvalues down to -1e-8 are
    accepted as numerical tolerance, not a guarantee of exact positive semidefiniteness.
    A nonfinite total trace is rejected even when individual entries are finite.
    """
    if not isinstance(normalize, (bool, np.bool_)):
        raise ValueError("normalize must be Boolean")
    matrix = np.asarray(rho, dtype=np.complex128)
    basis = np.asarray(isometry, dtype=np.complex128)
    if matrix.ndim != 2 or matrix.shape[0] == 0 or matrix.shape[0] != matrix.shape[1]:
        raise ValueError("rho must be a nonempty square matrix")
    if basis.ndim != 2 or basis.shape[0] != matrix.shape[0] or basis.shape[1] == 0:
        raise ValueError("isometry dimensions do not match rho")
    if not np.isfinite(matrix).all() or not np.isfinite(basis).all():
        raise ValueError("inputs must be finite")
    if not np.allclose(matrix, matrix.conj().T, atol=1e-10, rtol=0):
        raise ValueError("rho must be Hermitian")
    if not np.allclose(basis.conj().T @ basis, np.eye(basis.shape[1]), atol=1e-10, rtol=0):
        raise ValueError("isometry columns must be orthonormal")
    matrix = matrix / 2.0 + matrix.conj().T / 2.0
    with np.errstate(over='ignore', invalid='ignore'):
        mass = float(np.trace(matrix).real)
    if not math.isfinite(mass) or mass <= 1e-10:
        raise ValueError("rho must have finite positive trace")
    matrix = matrix / mass
    if float(np.linalg.eigvalsh(matrix).min()) < -1e-8:
        raise ValueError("rho must be positive semidefinite")
    result = basis.conj().T @ matrix @ basis
    result = (result + result.conj().T) / 2.0
    support = float(np.trace(result).real)
    if normalize:
        if support <= 1e-10:
            raise ValueError("projection has no numerically resolved support")
        result = result / support
    return result


@dataclass(frozen=True)
class ScaleBias:
    first_sampled_scale: int
    raw_bias_at_first_scale: float
    raw_bias_at_scale_one: float | None


def scale_bias(scales, estimates, ideal):
    """Label recorded estimates; do not sample or extrapolate any new observations."""
    if not isinstance(scales, Sequence) or isinstance(scales, (str, bytes)):
        raise ValueError("scales must be a sequence")
    if len(scales) < 2 or len(scales) > 12 or len(scales) != len(estimates):
        raise ValueError("two to twelve scales must correspond to the estimates")
    if any(isinstance(x, (bool, np.bool_)) or not isinstance(x, numbers.Integral) or not 1 <= x <= 10000 for x in scales):
        raise ValueError("scales must be positive integers no greater than 10000")
    if len(set(scales)) != len(scales):
        raise ValueError("scales must be distinct")
    values = [_finite(x, "estimate") for x in estimates]
    ideal = _finite(ideal, "ideal")
    labels = list(scales)
    return ScaleBias(int(labels[0]), values[0] - ideal,
                     values[labels.index(1)] - ideal if 1 in labels else None)


def workflow_membership_matches(approved_names, observed_ids, name_to_id):
    """Check exact membership through a declared one-to-one naming dictionary.

    Dictionary keys must exactly match the approval names. Unknown names,
    duplicate approvals/observations, or reused identifiers are rejected.
    Order does not matter; cardinality alone is insufficient.
    """
    if not isinstance(name_to_id, Mapping):
        raise ValueError("name_to_id must be a mapping")
    approved = list(approved_names)
    observed = list(observed_ids)
    if not approved or any(not isinstance(x, str) or not x for x in [*approved, *observed, *name_to_id.keys(), *name_to_id.values()]):
        return False
    if len(set(approved)) != len(approved) or len(set(observed)) != len(observed):
        return False
    if set(approved) != set(name_to_id):
        return False
    expected = [name_to_id[x] for x in approved]
    return len(set(expected)) == len(expected) and set(observed) == set(expected)
