// October 16, 2026 research-edition adapter. Codex, supporting reviewer.
// Recalculate saved numerical evidence without fitting parameters or measuring speed.
import fs from 'node:fs';
import assert from 'node:assert/strict';
import {parseWannier, constructH, ansatz, dense, independentEnergy} from './numerics/baseline.mjs';

const read = name => JSON.parse(fs.readFileSync(new URL(name, import.meta.url), 'utf8'));
const saved = read('./saved-states.json');
const inputs = read('./inputs/hamiltonians_24x8x8.json');
const blocks = parseWannier(fs.readFileSync(new URL('./inputs/wannier90_hr.dat', import.meta.url), 'utf8'));
assert.equal(saved.rows.length, 24);
assert.equal(inputs.rows.length, 24);
let matrixError = 0, energyError = 0, amplitudeError = 0, normError = 0, states = 0;
for (const [index, row] of saved.rows.entries()) {
  assert.equal(row.index, index);
  assert.equal(row.bands.length, 8);
  const fixture = inputs.rows[index];
  assert.deepEqual(row.kpoint, fixture.kpoint_fractional_reciprocal);
  const matrix = fixture.matrix_ev;
  const reconstructed = constructH(blocks, row.kpoint).h;
  for (let i = 0; i < 8; i++) for (let j = 0; j < 8; j++) for (let k = 0; k < 2; k++)
    matrixError = Math.max(matrixError, Math.abs(reconstructed[i][j][k] - matrix[i][j][k]));
  for (const band of row.bands) {
    const state = dense(3, ansatz(band.parameters));
    const energy = independentEnergy(matrix, state);
    energyError = Math.max(energyError, Math.abs(energy - band.energy_ev));
    let norm = 0, residualSquared = 0;
    for (let i = 0; i < 8; i++) {
      norm += state[i][0] ** 2 + state[i][1] ** 2;
      amplitudeError = Math.max(amplitudeError, Math.hypot(state[i][0] - band.amplitudes[i][0], state[i][1] - band.amplitudes[i][1]));
      let re = -energy * state[i][0], im = -energy * state[i][1];
      for (let j = 0; j < 8; j++) {
        re += matrix[i][j][0] * state[j][0] - matrix[i][j][1] * state[j][1];
        im += matrix[i][j][0] * state[j][1] + matrix[i][j][1] * state[j][0];
      }
      residualSquared += re * re + im * im;
    }
    assert.ok(Math.abs(Math.sqrt(residualSquared) - band.residual_ev) < 1e-9);
    normError = Math.max(normError, Math.abs(norm - 1));
    states++;
  }
  assert.deepEqual(row.eigenvalues_ev, row.bands.map(b => b.energy_ev).sort((a, b) => a - b));
}
assert.ok(matrixError <= 1e-10);
assert.ok(energyError <= 1e-9);
assert.ok(amplitudeError <= 2e-10);
assert.ok(normError <= 1e-9);
const comparisons = [];
for (const label of ['vqd-pilot-v1', 'classical-control-v1', 'vqd-full-v1', 'vqd-additional-v1']) {
  const score = read('./scores/' + label + '.json');
  const expectedCount = score.scalar_values ?? score.scalar_predictions;
  assert.ok(Number.isInteger(expectedCount) && expectedCount > 0);
  assert.equal(score.values.length, expectedCount);
  assert.ok(score.values.length > 0);
  const errors = score.values.map(v => {
    assert.ok(Number.isFinite(v.prediction_ev) && Number.isFinite(v.reference_ev));
    const error = Math.abs(v.prediction_ev - v.reference_ev);
    assert.ok(Math.abs(error - v.absolute_error_ev) <= 1e-12);
    return error;
  });
  const mean = errors.reduce((a, b) => a + b, 0) / errors.length;
  assert.ok(Math.abs(mean - score.mean_absolute_error_ev) <= 1e-12);
  assert.ok(Math.abs(Math.max(...errors) - score.maximum_absolute_error_ev) <= 1e-12);
  comparisons.push({label, scalar_values: errors.length, mean_absolute_error_ev: mean});
}
console.log(JSON.stringify({status: 'PASS', points: 24, saved_states: states, wannier_blocks: blocks.length,
  maximum_matrix_difference_ev: matrixError, maximum_energy_difference_ev: energyError,
  maximum_amplitude_difference: amplitudeError, maximum_norm_error: normError,
  saved_score_recalculations: comparisons, optimizer_rerun: false, timing_benchmark: false, physical_QPU: false}, null, 2));
