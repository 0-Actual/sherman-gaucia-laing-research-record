"""Run the three small Python replay lanes. Prints results; does not save a pass receipt."""
from pathlib import Path
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
scripts = ('quantum-teaching/check_fixtures.py', 'q8-observations/reproduce_means.py', 'bible-arithmetic/check_arithmetic.py')
environment = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', PYTHONIOENCODING='utf-8')
for relative in scripts:
    print(relative, flush=True)
    result = subprocess.run([sys.executable, '-B', str(ROOT / relative)], cwd=ROOT, env=environment, check=False)
    if result.returncode:
        raise SystemExit(result.returncode)
print('Three Python replay lanes completed. No scientific optimizer or timing benchmark was run.')
