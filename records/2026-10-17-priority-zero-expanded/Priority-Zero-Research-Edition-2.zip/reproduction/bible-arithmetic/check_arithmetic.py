"""October 16, 2026 research-edition adapter: replay declared letter arithmetic.

Only scientific fields from the saved studies are used. These numerical checks
do not assess linguistic interpretation or establish theological conclusions.
"""
from pathlib import Path
import json
import math
import unicodedata

HERE = Path(__file__).resolve().parent
HEBREW = dict(zip('אבגדהוזחטיכלמנסעפצקרשת', [1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100,200,300,400]))
HEBREW.update(dict(zip('ךםןףץ', [20,40,50,80,90])))
GREEK = dict(zip('αβγδεϛζηθικλμνξοπϟρστυφχψωϡ', [1,2,3,4,5,6,7,8,9,10,20,30,40,50,60,70,80,90,100,200,300,400,500,600,700,800,900]))
GREEK['ς'] = 200
CLAUSES = {'Genesis 1:2': [4,4,6], 'Genesis 1:3': [2,2,2], 'Genesis 1:4': [6,6], 'Genesis 1:5': [7,6]}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def letters(text, table):
    return [c for c in unicodedata.normalize('NFD', text).lower() if c in table]

def main():
    reports = []
    files = sorted((HERE / 'data').glob('*.json'))
    require(len(files) == 6, 'Expected six retained calculation records')
    for path in files:
        record = json.loads(path.read_text(encoding='utf8'))
        words = record['words']; word_values = []
        for word in words:
            spelling = letters(word['hebrew'], HEBREW)
            expected_trace = [{'letter': c, 'value': HEBREW[c]} for c in spelling]
            require(expected_trace == word['letter_values'], 'Hebrew trace mismatch')
            total = sum(HEBREW[c] for c in spelling)
            require(total == word['value'], 'Hebrew word total mismatch')
            word_values.append(total)
        consonants = letters(record['hebrew_pointed'], HEBREW)
        require(consonants == letters(record['hebrew_consonantal'], HEBREW), 'Consonant projection mismatch')
        require(consonants == [c for w in words for c in letters(w['hebrew'], HEBREW)], 'Word spelling mismatch')
        require(len(consonants) == record['consonantal_letter_count'], 'Letter count mismatch')
        require(len(words) == record.get('lexical_word_count', record.get('word_count')), 'Word count mismatch')
        require(sum(word_values) == record['total'], 'Verse total mismatch')
        if 'arithmetic_factorization' in record:
            require(math.prod(record['arithmetic_factorization']) == record['total'], 'Factorization mismatch')
        if 'clause_subtotals' in record:
            sizes = CLAUSES[record['passage']]; offset = 0; subtotals = []
            for size in sizes:
                subtotals.append(sum(word_values[offset:offset+size])); offset += size
            require(offset == len(words) and subtotals == record['clause_subtotals'], 'Clause subtotal mismatch')
        greek = record['selected_greek_witness']; spelling = letters(greek['word'], GREEK)
        require(sum(GREEK[c] for c in spelling) == greek['total'], 'Greek total mismatch')
        require([GREEK[c] for c in spelling] == [t['value'] for t in greek['trace']], 'Greek value trace mismatch')
        if 'dictionary_form' in greek:
            require(sum(GREEK[c] for c in letters(greek['dictionary_form'], GREEK)) == greek['dictionary_form_total'], 'Greek dictionary total mismatch')
        reports.append({'record': path.name, 'passage': record['passage'], 'words': len(words), 'hebrew_total': record['total'], 'greek_total': greek['total']})
    print(json.dumps({'status': 'PASS', 'calculation_records': len(reports), 'results': reports}, indent=2, ensure_ascii=True))

if __name__ == '__main__':
    main()
