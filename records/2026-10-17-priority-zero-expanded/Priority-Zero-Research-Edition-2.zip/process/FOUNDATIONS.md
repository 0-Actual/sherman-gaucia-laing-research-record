# Foundations for the mathematical bridges

Prepared 2026-10-16. This is a targeted orientation using four original research
papers and two official software documents. It is not an exhaustive prior-art or
novelty search, a validation of project results, or a certification. No local
experiment was run. Algebra marked **teaching derivation** is supplied here to
connect the standard foundations; it is not a new empirical result.

## F01 — Sum of products is a structured tensor representation

The official [Tensor Toolbox Kruskal-tensor documentation](https://www.tensortoolbox.org/ktensor_doc.html)
describes weighted sums of rank-one outer products and operations performed
without materializing the full tensor (opening definition; “Specifying weights”;
“Adding and subtracting ktensors”).

**Teaching derivation:** for
\(\lvert\psi\rangle=\sum_{r=1}^{R}c_r\bigotimes_{j=1}^{n}\lvert v_{rj}\rangle\),
storage of the explicit factors is proportional to \(nR\) for qubits. Its squared norm is
\(\sum_{r,s}c_r^*c_s\prod_j\langle v_{rj}|v_{sj}\rangle\), not generally
\(\sum_r|c_r|^2\). A two-term GHZ representation illustrates a large register
with small structure; it says nothing by itself about arbitrary states.

Limit: term counts can grow, and cancellation makes numerical conditioning
relevant. Compact storage does not establish general efficient simulation.

## F02 — MPS cost depends on the retained ranks

[Vidal, *Efficient classical simulation of slightly entangled quantum computations*](https://arxiv.org/html/quant-ph/0301063v2)
(2003), equations 2–5, local-update lemmas and Theorem 1, relates a chain tensor
description to Schmidt ranks. A polynomial bound maintained throughout the
considered computation gives polynomial simulation resources in that model.

**Teaching derivation:** MPS amplitudes can be written
\(\psi_{b_1\ldots b_n}=A^{[1]}_{b_1}\cdots A^{[n]}_{b_n}\); bounded bond
dimension \(\chi\) gives \(O(n\chi^2)\) stored coefficients for fixed local
dimension. SOP term count and MPS bond dimension are different quantities.

Limit: a 60-qubit structured example is not a dense 60-qubit simulation result.
Ranks can grow; truncation introduces approximation requiring its own error
accounting. Vidal's sufficient condition is not a universal classification of
classically easy states.

## F03 — VQD adds a penalty for returning to earlier states

[Higgott, Wang and Brierley, *Variational Quantum Computation of Excited States*](https://arxiv.org/html/1805.08138v2)
(published 2019), equation 2 and Section III, uses
\[
F_k(\psi)=\langle\psi|H|\psi\rangle+
\sum_{i<k}\beta_i|\langle\phi_i|\psi\rangle|^2.
\]
For exact normalized, mutually orthogonal earlier eigenstates, \(\beta_i>E_k-E_i\) raises their effective
energies above the target. The formulation iterates through previously found
states.

Limit: the spectral argument assumes exact prior eigenstates; finding the
global optimum within a sufficiently expressive ansatz is separate from writing
the objective. Approximate states, optimizer failure, noisy overlaps and penalty
selection affect practice. Recomputing this objective on a classical simulator
does not establish quantum-hardware execution or a new deflation method.

## F04 — A clause becomes an energy penalty

[Farhi, Goldstone, Gutmann and Sipser, *Quantum Computation by Adiabatic Evolution*](https://arxiv.org/html/quant-ph/0001106v1)
(2000), Sections 2.2–2.3, equations 2.11–2.16, assigns each violated clause energy
one, sums those energies, and embeds them diagonally in the computational basis.

**Teaching derivation:** with Boolean \(b_i=(1-z_i)/2\), the clause
\(b_1\lor\neg b_2\lor b_3\) is violated by
\((1-b_1)b_2(1-b_3)\). Its operator penalty is
\((I+Z_1)(I-Z_2)(I+Z_3)/8\). Its only nonzero eigenvalue on the clause's
eight assignments is the violated assignment's unit penalty.

Limit: this contains a three-body interaction. A general clause mapping is not
automatically a pairwise Ising model. Constructing an energy function does not
solve its minimization efficiently; the paper does not establish a general
polynomial SAT algorithm.

## F05 — Scaling protects norm evaluation from unnecessary overflow

Official [LAPACK 3.12.1 DLASSQ documentation and source](https://netlib.org/lapack/explore-html/d8/d76/group__lassq_gae8f40b0a34771b4f2d9c863de3af7be5.html)
specifies a scaled sum-of-squares representation. Its implementation separates
large, small and intermediate contributions to reduce overflow/underflow risk.

**Teaching derivation:** for a finite, nonzero real vector, let
\(m=\max_i|x_i|\), \(y=x/m\), and \(s=\sqrt{\sum_i y_i^2}\). Then
\(u=y/s\) is the normalized vector in exact arithmetic. Forming \(ms\) is
unnecessary when only the direction is needed.

Limit: this teaching formula is not an implementation of DLASSQ or a blanket
accuracy guarantee. Tiny contributions can still underflow; summation error,
zero vectors, nonfinite inputs and complex magnitudes need deliberate handling.
Scaling is established numerical practice, not a novel normalization principle.

## F06 — Energy can bound ground-space weight when a gap is known

[Hangleiter, Kliesch, Schwarz and Eisert, *Direct certification of a class of quantum simulations*](https://arxiv.org/html/1602.00703v4)
(2017), Lemma 2 and equations 12–13, bounds overlap using energy and a positive
spectral gap for its stated ground-state setting.

**Teaching derivation:** if \(P_0\) projects onto the ground space,
\(H-E_0I\geq\Delta(I-P_0)\), hence for a density matrix \(\rho\) with trace one,
\[
\operatorname{Tr}(P_0\rho)\geq
1-\frac{\operatorname{Tr}(\rho H)-E_0}{\Delta}.
\]
For a unique ground state this is its ground-state population (squared fidelity with the pure ground state); with degeneracy
it bounds total ground-space weight.

Limit: require a justified ground energy, positive gap lower bound and energy
error accounting. An uncertified estimated gap or approximate variational
ground-energy upper bound cannot simply replace these inputs. The inequality
alone does not certify this project's devices or results.

## Use in the project narrative

Present each bridge as: standard foundation, explicit project implementation,
dated evidence, comparison with an appropriate baseline, and remaining limits.
Similar mathematics does not by itself prove copying, originality, priority,
ownership, certification or an experimental advantage. The accompanying
`FOUNDATION_SOURCES.json` records the exact reference versions and supported claims.
