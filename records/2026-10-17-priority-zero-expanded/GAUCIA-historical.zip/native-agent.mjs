// GAUCIA native desktop integration. Local USB files and fixed quantum functions.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {randomUUID} from 'node:crypto';
import {Worker} from 'node:worker_threads';
import {Records,Library,writeNew,loadJSON,stamp,review,naturalTool,safeName} from './core.mjs';
import {hashBytes} from './engine/sgl-prime.mjs';
import {Backend} from './backend.mjs';
// Owner-directed security-only hold: stop before ordinary runtime work.
let qelSecurityOnlyHold = true;
try { fs.lstatSync('./REDACTED_LOCAL_ROOT/QEL_Q7/SECURITY_ONLY_HOLD.json'); } catch (e) { if (e.code === 'ENOENT') qelSecurityOnlyHold = false; }
if (qelSecurityOnlyHold) { console.error('QEL_SECURITY_ONLY_HOLD: ordinary project work is paused.'); process.exit(73); }
const root=import.meta.dirname;
const config=loadJSON(path.join(root,'config.json'));
const ipc=path.join(root,'data','native');
for(const d of ['inbox','handled','replies'])fs.mkdirSync(path.join(ipc,d),{recursive:true});
const lock=path.join(ipc,'service.lock.json');
if(fs.existsSync(lock))throw Error('An existing native session record is present. No duplicate session started.');
writeNew(lock,{pid:process.pid,at:stamp()});
const records=new Records(root,hashBytes), recovered=records.recoverJobs();
const library=new Library(root,config.corpus);
const backend=new Backend(root,config,(k,d)=>records.event(k,d));
const policy=fs.readFileSync(path.join(root,'governance','system-prompt.txt'),'utf8');
