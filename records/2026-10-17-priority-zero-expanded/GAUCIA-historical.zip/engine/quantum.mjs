// QEL integration by GAUCIA for Sherman G. Laing, 2026-09-19.
// Uses an unchanged copy of the existing QEL SOP kernel. No network or filesystem.
import {SOP} from './vendor/qel60_sop.mjs';
export function circuit(spec){
 if(!spec||typeof spec!=='object')throw Error('Circuit object required');
 const {n,gates,probes=[]}=spec;
 if(!Number.isInteger(n)||n<1||n>60)throw Error('n must be 1..60');
 if(!Array.isArray(gates)||gates.length>256)throw Error('At most 256 gates');
 if(!Array.isArray(probes)||probes.length>64)throw Error('At most 64 probes');
 const state=new SOP(n,64);
 for(const g of gates){if(!g||!['H','S','SDG','X','RY','RZ','CNOT','CZ'].includes(g.kind))throw Error('Unsupported gate');state.gate(g);}
 const norm=state.norm();if(!norm.every(Number.isFinite)||Math.abs(norm[0]-1)>1e-9||Math.abs(norm[1])>1e-9)throw Error('Norm validation failed');
 const outcomes=probes.map(bits=>{if(typeof bits!=='string'||bits.length!==n||!/^[01]+$/.test(bits))throw Error('Invalid probe');const a=state.amplitude([...bits].map(Number));return {bits,amplitude:a,probability:a[0]**2+a[1]**2};});
 return {backend:'existing QEL SOP / classical quantum simulation',n,gates:gates.length,norm,storage:state.storage(),outcomes,physical_QPU:false,arbitrary_dense_60_qubits:false};
}
export function ghz(n=2){return circuit({n,gates:[{kind:'H',q:0},...Array.from({length:n-1},(_,i)=>({kind:'CNOT',c:0,t:i+1}))],probes:['0'.repeat(n),'1'.repeat(n),...(n>1?['0'.repeat(n-1)+'1']:[])]});}
export function predict(x,theta){
 if(!Array.isArray(x)||x.length!==2||!x.every(v=>Number.isFinite(v)&&v>=0&&v<=1))throw Error('Two features in [0,1] required');
 if(!Array.isArray(theta)||theta.length!==3||!theta.every(Number.isFinite))throw Error('Three finite parameters required');
 const gates=[{kind:'RY',q:0,angle:Math.PI*x[0]+theta[0]},{kind:'RY',q:1,angle:Math.PI*x[1]+theta[1]},{kind:'CNOT',c:0,t:1},{kind:'RY',q:1,angle:theta[2]}];
 const r=circuit({n:2,gates,probes:['01','11']});return r.outcomes.reduce((s,a)=>s+a.probability,0);
}
export const demoData=[{x:[0,0],y:0},{x:[0,1],y:1},{x:[1,0],y:1},{x:[1,1],y:0}];
export function train(rows=demoData,{epochs=150,rate=0.5}={}){
 if(!Array.isArray(rows)||rows.length<1||rows.length>128)throw Error('1..128 labelled rows required');
 if(!Number.isInteger(epochs)||epochs<1||epochs>300||!Number.isFinite(rate)||rate<=0||rate>1)throw Error('Training budget invalid');
 for(const r of rows){if(!r||![0,1].includes(r.y))throw Error('Labels must be 0 or 1');predict(r.x,[0,0,0]);}
 let theta=[0.6,-0.7,0.4];const history=[];
 const loss=t=>rows.reduce((s,r)=>s+(predict(r.x,t)-r.y)**2,0)/rows.length;
 const initial_loss=loss(theta);
 for(let e=0;e<epochs;e++){
  const gradient=[0,0,0];
  for(const r of rows){const error=predict(r.x,theta)-r.y;
   for(let j=0;j<3;j++){const plus=theta.slice(),minus=theta.slice();plus[j]+=Math.PI/2;minus[j]-=Math.PI/2;gradient[j]+=error*(predict(r.x,plus)-predict(r.x,minus))/rows.length;}
  }
  theta=theta.map((v,j)=>v-rate*gradient[j]);
  const value=loss(theta);if(!Number.isFinite(value))throw Error('Nonfinite training loss');
  history.push({epoch:e+1,loss:value});
 }
 const predictions=rows.map(r=>({x:r.x,y:r.y,probability:predict(r.x,theta)}));
 return {kind:'QEL 2-qubit variational classifier',owner:'Sherman G. Laing',implementation:'GAUCIA AI-assisted integration',parameters:theta,epochs,initial_loss,final_loss:loss(theta),training_accuracy:predictions.filter(p=>Number(p.probability>=0.5)===p.y).length/rows.length,predictions,history,gradient:'parameter-shift / classical optimizer',training_data_scope:rows===demoData?'four-row XOR demonstration, not private-corpus training':'caller-supplied two-feature labelled data',generalization_tested:false,physical_QPU:false,signature:'UNSIGNED'};
}
