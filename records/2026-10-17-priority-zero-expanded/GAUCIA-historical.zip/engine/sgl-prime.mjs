/**
 * SGL Prime profile 3: a versioned, domain-separated BLAKE2b-512 fingerprint.
 * This is a project framing profile over an existing cryptographic primitive.
 * It is not a signature, proof of authorship, or authenticated release.
 * Importing this module does not access files, write data, or use the network.
 */
import { createHash, timingSafeEqual } from 'node:crypto';
import {
  constants, closeSync, fstatSync, lstatSync, openSync, readSync,
} from 'node:fs';

export const PROFILE = 'QEL-SGLP3-BLAKE2B512-v1';
export const ALGORITHM = 'blake2b512';
export const DOMAIN = 'QEL\0SGL-PRIME\0HASH\0BLAKE2B-512\0v1\0';

// Keep the mutable Buffer private; the exported domain is an immutable string.
const DOMAIN_BYTES = Buffer.from(DOMAIN, 'ascii');
const ID_PREFIX = 'sglp3:b2b512:v1:';
const PURPOSE_PATTERN = /^[a-z][a-z0-9._-]{0,63}$/;
const ID_PATTERN = /^sglp3:b2b512:v1:([a-z][a-z0-9._-]{0,63}):([0-9a-f]{128})$/;
const MAX_U64 = (1n << 64n) - 1n;
const MAX_FILE_SIZE = BigInt(Number.MAX_SAFE_INTEGER);
const MAX_CHUNK_SIZE = 4 * 1024 * 1024;

function validatePurpose(purpose) {
  if (typeof purpose !== 'string' || !PURPOSE_PATTERN.test(purpose)) {
    throw new TypeError('purpose must be 1–64 ASCII characters matching [a-z][a-z0-9._-]*');
  }
  // JavaScript $ also matches immediately before a final newline. Explicitly
  // reject every non-ASCII purpose character, including that trailing newline.
  for (let i = 0; i < purpose.length; i += 1) {
    const code = purpose.charCodeAt(i);
    if (code < 0x21 || code > 0x7e) {
      throw new TypeError('purpose must contain only the specified ASCII characters');
    }
  }
  return purpose;
}

function asBytes(input) {
  if (!(input instanceof Uint8Array)) {
    throw new TypeError('input must be a Buffer or Uint8Array');
  }
  return Buffer.from(input.buffer, input.byteOffset, input.byteLength);
}

function framedHash(purpose, payloadLength) {
  validatePurpose(purpose);
  if (typeof payloadLength !== 'bigint' || payloadLength < 0n || payloadLength > MAX_U64) {
    throw new RangeError('payload length must fit an unsigned 64-bit integer');
  }
  const purposeBytes = Buffer.from(purpose, 'ascii');
  const purposeLengthBytes = Buffer.alloc(2);
  purposeLengthBytes.writeUInt16BE(purposeBytes.length);
  const payloadLengthBytes = Buffer.alloc(8);
  payloadLengthBytes.writeBigUInt64BE(payloadLength);
  return createHash(ALGORITHM)
    .update(DOMAIN_BYTES)
    .update(purposeLengthBytes)
    .update(purposeBytes)
    .update(payloadLengthBytes);
}

function completeIdentity(hash, purpose) {
  return `${ID_PREFIX}${purpose}:${hash.digest('hex')}`;
}

/** Return the canonical identity string for exactly the supplied byte view. */
export function hashBytes(input, purpose) {
  const bytes = asBytes(input);
  const hash = framedHash(purpose, BigInt(bytes.byteLength));
  hash.update(bytes);
  return completeIdentity(hash, purpose);
}

/**
 * Parse a canonical identity. Malformed, unsupported, uppercase, padded, or
 * otherwise noncanonical identities throw SyntaxError. No data is hashed.
 */
export function parseIdentity(identity) {
  if (typeof identity !== 'string') {
    throw new SyntaxError('expected a canonical SGLP3 identity string');
  }
  const match = ID_PATTERN.exec(identity);
  // The full-string comparison closes JavaScript's final-newline $ exception.
  if (!match || match[0] !== identity) {
    throw new SyntaxError('expected a canonical SGLP3 identity string');
  }
  return Object.freeze({
    profile: PROFILE,
    algorithm: ALGORITHM,
    purpose: match[1],
    hex: match[2],
    identity,
  });
}

function expectedForPurpose(expected, purpose) {
  validatePurpose(purpose);
  try {
    const parsed = parseIdentity(expected);
    return parsed.purpose === purpose ? parsed : null;
  } catch (error) {
    if (error instanceof SyntaxError) return null;
    throw error;
  }
}

function constantTimeDigestMatch(actualIdentity, expectedParsed) {
  const actual = Buffer.from(parseIdentity(actualIdentity).hex, 'hex');
  const expected = Buffer.from(expectedParsed.hex, 'hex');
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

/**
 * Return false for a malformed expected ID or a purpose/digest mismatch.
 * Invalid input bytes or purpose are programmer errors and throw.
 */
export function verifyBytes(input, purpose, expected) {
  // Validate the input even if an expected identity is malformed.
  asBytes(input);
  const parsed = expectedForPurpose(expected, purpose);
  if (parsed === null) return false;
  return constantTimeDigestMatch(hashBytes(input, purpose), parsed);
}

function assertRegularFile(stat) {
  if (!stat.isFile() || stat.isSymbolicLink()) {
    throw new Error('SGLP3 file hashing requires a regular file and rejects symbolic links');
  }
  if (stat.size < 0n || stat.size > MAX_FILE_SIZE) {
    throw new RangeError('file size exceeds the supported safe integer range');
  }
}

function nanosecondTime(stat, field) {
  const value = stat[`${field}Ns`];
  if (typeof value !== 'bigint') {
    throw new Error('SGLP3 file hashing requires nanosecond BigInt stat timestamps');
  }
  return value;
}

function assertUnchanged(initial, current) {
  assertRegularFile(current);
  const identityFields = ['dev', 'ino', 'mode', 'nlink', 'uid', 'gid', 'size'];
  const changed = identityFields.some((key) => initial[key] !== current[key])
    || nanosecondTime(initial, 'mtime') !== nanosecondTime(current, 'mtime')
    || nanosecondTime(initial, 'ctime') !== nanosecondTime(current, 'ctime');
  if (changed) {
    throw new Error('file identity or metadata changed during SGLP3 hashing');
  }
}

/**
 * Stream a regular file through one open descriptor using bounded memory.
 * Detect observed replacement, truncation, growth, or metadata change and fail
 * closed. Pathname checks reject symbolic links; O_NOFOLLOW strengthens the
 * final-component check where available. Parent-directory symlinks are not
 * prohibited. This is change detection, not an adversarial atomic snapshot.
 */
export function hashFile(path, purpose, { chunkSize = 1024 * 1024 } = {}) {
  validatePurpose(purpose);
  if (!Number.isInteger(chunkSize) || chunkSize < 1 || chunkSize > MAX_CHUNK_SIZE) {
    throw new RangeError('chunkSize must be an integer from 1 through 4194304');
  }
  const pathBefore = lstatSync(path, { bigint: true });
  assertRegularFile(pathBefore);
  const descriptor = openSync(path, constants.O_RDONLY | (constants.O_NOFOLLOW ?? 0));
  try {
    const opened = fstatSync(descriptor, { bigint: true });
    assertUnchanged(pathBefore, opened);
    const hash = framedHash(purpose, opened.size);
    const expectedLength = Number(opened.size);
    const buffer = Buffer.allocUnsafe(Math.min(chunkSize, Math.max(expectedLength, 1)));
    let received = 0;
    while (received < expectedLength) {
      const requested = Math.min(buffer.length, expectedLength - received);
      const count = readSync(descriptor, buffer, 0, requested, null);
      if (count === 0) {
        throw new Error('file was truncated during SGLP3 hashing');
      }
      hash.update(buffer.subarray(0, count));
      received += count;
    }
    if (readSync(descriptor, buffer, 0, 1, null) !== 0) {
      throw new Error('file grew during SGLP3 hashing');
    }
    const openedAfter = fstatSync(descriptor, { bigint: true });
    assertUnchanged(opened, openedAfter);
    const pathAfter = lstatSync(path, { bigint: true });
    assertUnchanged(opened, pathAfter);
    return completeIdentity(hash, purpose);
  } finally {
    closeSync(descriptor);
  }
}

/**
 * Return false for a malformed expected ID or a purpose/digest mismatch.
 * Invalid purpose, I/O failures, unsafe file type, or observed changes throw.
 * A malformed expected ID is rejected before opening the file.
 */
export function verifyFile(path, purpose, expected) {
  const parsed = expectedForPurpose(expected, purpose);
  if (parsed === null) return false;
  return constantTimeDigestMatch(hashFile(path, purpose), parsed);
}
