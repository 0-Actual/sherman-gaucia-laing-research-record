import {parentPort,workerData} from 'node:worker_threads';
import {circuit,ghz,train,predict} from './engine/quantum.mjs';
try {
  const {kind}=workerData;let result;
  if(kind==='ghz')result=ghz(workerData.n);
  else if(kind==='circuit')result=circuit(workerData.spec);
  else if(kind==='train')result=train(workerData.rows,workerData.options||{});
  else if(kind==='predict')result={features:workerData.features,probability:predict(workerData.features,workerData.parameters)};
  else throw Error('Unsupported bounded quantum operation');
  parentPort.postMessage({ok:true,result});
}catch(e){parentPort.postMessage({ok:false,error:e.message});}
