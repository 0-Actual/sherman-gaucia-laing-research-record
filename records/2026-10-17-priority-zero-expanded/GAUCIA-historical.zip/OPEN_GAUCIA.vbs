' QEL desktop launcher. Opens only the local GAUCIA communication application.
Option Explicit
Dim fso, shell, root, node, entry
Set fso = CreateObject("Scripting.FileSystemObject")
Set shell = CreateObject("WScript.Shell")
root = fso.GetParentFolderName(WScript.ScriptFullName)
node = fso.GetAbsolutePathName(fso.BuildPath(root, "..\Independent_Model_20260919\runtime\node.exe"))
entry = fso.BuildPath(root, "tools\start-panel.mjs")
If Not fso.FileExists(node) Or Not fso.FileExists(entry) Then
  MsgBox "The GAUCIA USB runtime is not available. No files were changed.", 48, "GAUCIA"
  WScript.Quit 2
End If
shell.Run Chr(34) & node & Chr(34) & " " & Chr(34) & entry & Chr(34) & " --open", 0, False
