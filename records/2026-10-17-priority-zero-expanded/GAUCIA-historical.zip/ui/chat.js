'use strict';
const $=id=>document.getElementById(id);
let session='',current=null,lastRender='',polling=false,status=null;
function pendingSends(){return Object.keys(localStorage).filter(k=>k.startsWith('qel-pending-send-')).map(k=>JSON.parse(localStorage.getItem(k))).sort((a,b)=>a.savedAt-b.savedAt);}
const el=(tag,text,cls)=>{const n=document.createElement(tag);if(text!==undefined)n.textContent=text;if(cls)n.className=cls;return n;};
function notice(text,error=false){$('notice').textContent=text;$('notice').classList.toggle('error',error);}
async function connect(){const r=await fetch('/session',{cache:'no-store'});if(!r.ok)throw Error('Local session unavailable');session=(await r.json()).session;}
async function api(route,data,retry=true){const r=await fetch('/api/'+route,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json','X-QEL-Session':session},body:data===undefined?undefined:JSON.stringify(data),cache:'no-store'});if(r.status===403&&retry){await connect();return api(route,data,false);}const b=await r.json();if(!r.ok){const error=Error(b.error||'Local request failed');error.notAdmitted=b.notAdmitted===true;error.response=b;throw error;}return b;}
function render(c){
  current=c;localStorage.setItem('qel-local-current',c.id);$('welcome').hidden=c.messages.length>0;
  const key=JSON.stringify(c.messages);if(key===lastRender)return;lastRender=key;
  const panel=$('messages'),nearEnd=panel.scrollHeight-panel.scrollTop-panel.clientHeight<100;
  const opened=new Set([...panel.querySelectorAll('details[open]')].map(d=>d.dataset.id));panel.replaceChildren();
  for(const m of c.messages){
    const box=el('article',undefined,'message '+m.role+(m.error?' error':''));
    box.append(el('div',m.role==='user'?'Sherman G. Laing':'GAUCIA Actual','role'));
    box.append(el('div',m.content||(m.status==='running'?'Working locally…':''),'body'));
    if(m.error)box.append(el('div',m.error,'meta'));
    if(m.engine)box.append(el('div',m.engine+(m.status==='running'?' · running':''),'meta'));
    if(m.context?.shortened)box.append(el('div','A shorter context was used to fit local memory. The complete conversation remains saved.','meta'));
    if(m.result){const d=el('details');d.dataset.id=m.id+'-result';d.open=opened.has(d.dataset.id);d.append(el('summary','Computed result and parameters'),el('pre',JSON.stringify(m.result,null,2)));box.append(d);}
    if(m.sources?.length){const d=el('details');d.dataset.id=m.id+'-sources';d.open=opened.has(d.dataset.id);d.append(el('summary',`${m.sources.length} USB source passages`));for(const s of m.sources){const b=el('div',undefined,'source');b.append(el('strong',`[${s.id}] ${s.title}`),el('span',s.excerpt),el('div',s.origin,'meta'));d.append(b);}box.append(d);}
    panel.append(box);
  }
  $('saveState').textContent=c.updatedAt?'Saved to USB · '+new Date(c.updatedAt).toLocaleTimeString():'USB preservation enabled';
  if(nearEnd||c.messages.length<3)panel.scrollTop=panel.scrollHeight;
}
async function history(){const rows=await api('conversations');$('history').replaceChildren();for(const r of rows){const b=el('button',r.title||'Conversation');b.classList.toggle('active',current?.id===r.id);b.title=r.title;b.addEventListener('click',async()=>{try{lastRender='';render(await api('conversation?id='+encodeURIComponent(r.id)));await history();}catch(e){notice(e.message,true);}});$('history').append(b);}}
async function newChat(){lastRender='';render(await api('new',{}));await history();$('input').focus();}
async function poll(){
  if(polling)return;polling=true;
  try{const before=status?.active;status=await api('status');
    const bs=status.backend.state;$('modelState').textContent=bs==='ready'?'Language model ready':bs==='loading'?'Loading local model…':bs==='error'?'Language model needs attention':'Language model resting';
    $('modelButton').textContent=bs==='ready'?'Rest language model':'Load language model';$('modelButton').disabled=bs==='loading'||!!status.active;
    $('sendButton').disabled=!!status.active;$('stopButton').hidden=!status.active;
    $('footer').textContent=`Quantum.Earth.Laing · ${status.library.records} indexed passages · ${status.freeMiB} MiB currently available`;
    if(current)render(await api('conversation?id='+encodeURIComponent(current.id)));
    if(before&&!status.active){await history();const ended=await api('conversation?id='+encodeURIComponent(before.conversation));const last=ended.messages.find(m=>m.requestId===before.id&&m.role==='assistant');notice(last?.status==='complete'?'Response completed and saved on USB.':'Operation ended with status: '+(last?.status||'unknown'),last?.status!=='complete');}
    if(status.audit?.storageFailure)notice('Audit storage error: '+status.audit.storageFailure,true);else if(status.audit?.overdue>0)notice(status.audit.overdue+' local request(s) overdue. Saved input is retained.',true);
  }catch(e){notice('Local connection: '+e.message,true);}finally{polling=false;}
}
$('chatForm').addEventListener('submit',async e=>{
  e.preventDefault();if(status?.active)return;
  const kind=$('mode').value,text=$('input').value||(kind==='ghz'?'Run the GHZ state':kind==='train'?'Run the quantum classifier training':'');if(!text.trim())return;
  let pendingKey;
  try{if(!current)await newChat();$('sendButton').disabled=true;const request={id:current.id,text,kind};if(kind==='ghz')request.n=Number($('qubits').value);const held=pendingSends().find(p=>p.id===request.id);if(held){if(held.id!==request.id||held.text!==text||held.kind!==kind||held.n!==request.n)throw Error('An unconfirmed send is preserved. Retry that same message before changing it.');request.requestId=held.requestId;}else request.requestId=crypto.randomUUID();request.savedAt=held?.savedAt||Date.now();pendingKey='qel-pending-send-'+request.requestId;localStorage.setItem(pendingKey,JSON.stringify(request));const receipt=await api('message',request);if(!receipt.receipt)throw Error('No local audit receipt returned. Input is retained.');localStorage.removeItem(pendingKey);$('input').value='';notice(receipt.duplicate?'Recovered saved request. Recorded state: '+receipt.state:'Input committed to USB. Local processing admitted.');await poll();await history();}catch(error){if(error.notAdmitted&&pendingKey){const retained=localStorage.getItem(pendingKey);localStorage.setItem(pendingKey.replace('qel-pending-send-','qel-rejected-send-'),JSON.stringify({request:JSON.parse(retained),rejection:error.response,at:new Date().toISOString()}));localStorage.removeItem(pendingKey);}notice(error.message+(error.notAdmitted?' Input retained as an editable draft.':''),true);$('sendButton').disabled=false;}
});
$('input').addEventListener('keydown',e=>{if(e.key==='Enter'&&!e.shiftKey){e.preventDefault();$('chatForm').requestSubmit();}});
$('newChat').addEventListener('click',()=>newChat().catch(e=>notice(e.message,true)));
$('stopButton').addEventListener('click',()=>api('stop',{}).then(()=>notice('Stopping this response; saved work is retained.')).catch(e=>notice(e.message,true)));
$('modelButton').addEventListener('click',()=>api(status?.backend.state==='ready'?'model/stop':'model/start',{}).then(poll).catch(e=>notice(e.message,true)));
$('mode').addEventListener('change',()=>{$('qubitsLabel').hidden=$('mode').value!=='ghz';});
$('exportButton').addEventListener('click',async()=>{try{if(!current)return;const r=await api('export',{id:current.id});notice('Readable conversation saved and read back: '+r.file);}catch(e){notice(e.message,true);}});
for(const b of document.querySelectorAll('[data-prompt]'))b.addEventListener('click',()=>{$('mode').value='chat';$('input').value=b.dataset.prompt;$('chatForm').requestSubmit();});
$('aboutButton').addEventListener('click',()=>{$('details').textContent=status?`Owner: ${status.owner}\nWorkspace: ${status.workspace}\nLanguage model: ${status.backend.model}\nLanguage context: ${status.backend.context} tokens\nResearch: ${status.library.records} passages from ${status.library.sourceFiles} files\nLibrary read errors: ${status.library.errors.length}\nUI connection: ${status.origin}\nConversation storage: USB, new revisions with byte readback\nCorpus use: local retrieval, not weight training\nState: ${status.release}`:'Connecting…';$('about').showModal();});
$('closeAbout').addEventListener('click',()=>$('about').close());
(async()=>{try{await connect();const saved=localStorage.getItem('qel-local-current');if(saved){try{render(await api('conversation?id='+encodeURIComponent(saved)));}catch{await newChat();}}else await newChat();await history();await poll();const held=pendingSends()[0];if(held){lastRender='';render(await api('conversation?id='+encodeURIComponent(held.id)));$('input').value=held.text;$('mode').value=held.kind;if(held.n!==undefined)$('qubits').value=held.n;$('qubitsLabel').hidden=held.kind!=='ghz';notice('A send was not acknowledged. Its exact input is restored; resending uses the same request ID.',true);}else notice('GAUCIA is connected to your local USB workspace.');setInterval(poll,1000);$('input').focus();}catch(e){notice('Workspace could not open: '+e.message,true);}})();
