// Quantum.Earth.Laing — Sherman G. Laing. GAUCIA AI-assisted native interface.
// This window uses only the existing loopback communication API. No shell input.
using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Script.Serialization;
using System.Windows.Forms;
public sealed class GauciaWindow : Form {
 readonly string root=AppDomain.CurrentDomain.BaseDirectory;
 readonly HttpClient http=new HttpClient(new HttpClientHandler { UseProxy=false,AllowAutoRedirect=false });
 readonly JavaScriptSerializer json=new JavaScriptSerializer { MaxJsonLength=8388608 };
 readonly Color bg=Color.FromArgb(17,25,28), panel=Color.FromArgb(28,42,46), ink=Color.FromArgb(237,243,241), gold=Color.FromArgb(209,179,118);
 readonly RichTextBox transcript=new RichTextBox(); readonly TextBox input=new TextBox(); readonly ListBox history=new ListBox();
 readonly Label notice=new Label(),health=new Label(),saved=new Label(); readonly ComboBox mode=new ComboBox(); readonly NumericUpDown qubits=new NumericUpDown();
 readonly Button send=new Button(),stop=new Button(),model=new Button(); readonly System.Windows.Forms.Timer timer=new System.Windows.Forms.Timer();
 readonly Font small=new Font("Segoe UI",9),smallBold=new Font("Segoe UI",9,FontStyle.Bold),large=new Font("Segoe UI",19);
 string session="", currentId="",rendered=""; bool polling=false,historyLoading=false,busy=false,verify=false;
 Dictionary<string,object> lastStatus; readonly Font regular=new Font("Segoe UI",11),bold=new Font("Segoe UI",11,FontStyle.Bold);
 static Dictionary<string,object> D(object value){return (Dictionary<string,object>)value;}
 static string S(Dictionary<string,object> d,string key){return d.ContainsKey(key)&&d[key]!=null?Convert.ToString(d[key]):"";}
 static object[] A(object value){return ((IEnumerable)value).Cast<object>().ToArray();}
 sealed class ChatRow {public string Id,Title;public override string ToString(){return Title;}}
 public GauciaWindow(bool verification){verify=verification;Text="GAUCIA | Quantum.Earth.Laing";Size=new Size(1180,800);MinimumSize=new Size(850,610);StartPosition=FormStartPosition.CenterScreen;BackColor=bg;ForeColor=ink;Font=regular;Build();http.Timeout=TimeSpan.FromSeconds(15);Shown+=async delegate {await Initialize();if(verify)await VerifyWindow();};timer.Interval=1000;timer.Tick+=async delegate {await Poll();};FormClosed+=delegate {timer.Stop();http.Dispose();};}
 Button B(string text,int width=150){var b=new Button {Text=text,Width=width,Height=34,FlatStyle=FlatStyle.Flat,BackColor=panel,ForeColor=ink,Margin=new Padding(4)};b.FlatAppearance.BorderColor=Color.FromArgb(65,85,88);return b;}
 void Style(Button b,string text,int width){b.Text=text;b.Width=width;b.Height=34;b.FlatStyle=FlatStyle.Flat;b.BackColor=panel;b.ForeColor=ink;b.Margin=new Padding(4);b.FlatAppearance.BorderColor=Color.FromArgb(65,85,88);}
 void Build(){
  var shell=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=2,RowCount=1,Margin=new Padding(0)};shell.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,235));shell.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100));Controls.Add(shell);
  var side=new Panel {Dock=DockStyle.Fill,Padding=new Padding(16),BackColor=Color.FromArgb(13,21,24)};shell.Controls.Add(side,0,0);
  var brand=new Label {Text="QEL\nQuantum.Earth.Laing",Dock=DockStyle.Top,Height=90,Font=new Font("Segoe UI",18,FontStyle.Bold),ForeColor=gold};
  var owner=new Label {Text="Sherman G. Laing\nLocal execution · USB records",Dock=DockStyle.Bottom,Height=58,Font=new Font("Segoe UI",9),ForeColor=Color.LightGray};
  var newButton=B("+ New conversation",190);newButton.Dock=DockStyle.Top;newButton.Click+=async delegate {await NewChat();};
  history.Dock=DockStyle.Fill;history.BackColor=side.BackColor;history.ForeColor=ink;history.BorderStyle=BorderStyle.None;history.Font=new Font("Segoe UI",9);history.ItemHeight=27;history.IntegralHeight=false;
  history.SelectedIndexChanged+=async delegate {if(historyLoading||history.SelectedItem==null)return;try{currentId=((ChatRow)history.SelectedItem).Id;rendered="";Render(D(await Api("conversation?id="+currentId)));}catch(Exception e){Notice(e.Message,true);}};
  side.Controls.Add(history);side.Controls.Add(owner);side.Controls.Add(newButton);side.Controls.Add(brand);
  var main=new TableLayoutPanel {Dock=DockStyle.Fill,ColumnCount=1,RowCount=6,Padding=new Padding(20,8,20,8)};foreach(float h in new float[]{86,36,0,45,120,27})main.RowStyles.Add(new RowStyle(h==0?SizeType.Percent:SizeType.Absolute,h==0?100:h));shell.Controls.Add(main,1,0);
  var heading=new Panel {Dock=DockStyle.Fill};heading.Controls.Add(new Label {Text="GAUCIA Actual",Font=new Font("Segoe UI",27,FontStyle.Regular),Dock=DockStyle.Top,Height=51,ForeColor=ink});health.Dock=DockStyle.Bottom;health.Height=29;health.ForeColor=gold;health.Font=new Font("Segoe UI",10);heading.Controls.Add(health);main.Controls.Add(heading,0,0);
  notice.Dock=DockStyle.Fill;notice.Font=new Font("Segoe UI",9);notice.Text="Opening your local workspace…";main.Controls.Add(notice,0,1);
  transcript.Dock=DockStyle.Fill;transcript.BackColor=bg;transcript.ForeColor=ink;transcript.BorderStyle=BorderStyle.None;transcript.ReadOnly=true;transcript.DetectUrls=false;transcript.Font=regular;main.Controls.Add(transcript,0,2);
  var tools=new FlowLayoutPanel {Dock=DockStyle.Fill,WrapContents=false};mode.DropDownStyle=ComboBoxStyle.DropDownList;mode.Items.AddRange(new object[]{"Talk with GAUCIA","Search USB research","Quantum GHZ state","Train quantum classifier"});mode.SelectedIndex=0;mode.Width=190;mode.BackColor=panel;mode.ForeColor=ink;mode.Margin=new Padding(4,7,4,4);tools.Controls.Add(mode);
  qubits.Minimum=2;qubits.Maximum=60;qubits.Value=3;qubits.Width=48;qubits.BackColor=panel;qubits.ForeColor=ink;qubits.Margin=new Padding(4,7,4,4);tools.Controls.Add(qubits);qubits.AccessibleName="GHZ qubits";qubits.Visible=false;mode.SelectedIndexChanged+=delegate {qubits.Visible=mode.SelectedIndex==2;};
  Style(model,"Load language",135);model.Click+=async delegate {try{bool ready=lastStatus!=null&&S(D(lastStatus["backend"]),"state")=="ready";await Api(ready?"model/stop":"model/start",new Dictionary<string,object>());await Poll();}catch(Exception e){Notice(e.Message,true);}};tools.Controls.Add(model);
  var export=B("Save readable copy",145);export.Click+=async delegate {await Export();};tools.Controls.Add(export);var details=B("Details",80);details.Click+=delegate {ShowDetails();};tools.Controls.Add(details);main.Controls.Add(tools,0,3);
  var composer=new Panel {Dock=DockStyle.Fill,Padding=new Padding(10),BackColor=panel};input.Multiline=true;input.AcceptsReturn=true;input.MaxLength=8000;input.Dock=DockStyle.Fill;input.BackColor=panel;input.ForeColor=ink;input.BorderStyle=BorderStyle.None;input.Font=regular;input.KeyDown+=async delegate(object sender,KeyEventArgs e){if(e.KeyCode==Keys.Enter&&!e.Shift){e.SuppressKeyPress=true;await Send();}};
  var bar=new FlowLayoutPanel {Dock=DockStyle.Bottom,Height=40,FlowDirection=FlowDirection.RightToLeft};Style(send,"Send",95);send.BackColor=gold;send.ForeColor=bg;send.Click+=async delegate {await Send();};Style(stop,"Stop",75);stop.Visible=false;stop.Click+=async delegate {try{await Api("stop",new Dictionary<string,object>());Notice("Stopping the response; saved work is retained.");}catch(Exception e){Notice(e.Message,true);}};bar.Controls.Add(send);bar.Controls.Add(stop);composer.Controls.Add(input);composer.Controls.Add(bar);main.Controls.Add(composer,0,4);
  saved.Dock=DockStyle.Fill;saved.Font=new Font("Segoe UI",8);saved.Text="USB preservation enabled · Enter sends · Shift+Enter adds a line";main.Controls.Add(saved,0,5);
 }
 void Notice(string text,bool error=false){notice.Text=text;notice.ForeColor=error?Color.Salmon:Color.LightGray;}
 async Task<object> Api(string route,object data=null){
  if(route.Contains("://")||route.StartsWith("/"))throw new Exception("Local route required");
  var request=new HttpRequestMessage(data==null?HttpMethod.Get:HttpMethod.Post,"http://127.0.0.1:17807/api/"+route);request.Headers.Add("X-QEL-Session",session);
  if(data!=null)request.Content=new StringContent(json.Serialize(data),Encoding.UTF8,"application/json");
  using(var response=await http.SendAsync(request)){var value=json.DeserializeObject(await response.Content.ReadAsStringAsync());if(!response.IsSuccessStatusCode)throw new Exception(S(D(value),"error"));return value;}
 }
 async Task<bool> Healthy(){try{var r=D(json.DeserializeObject(await http.GetStringAsync("http://127.0.0.1:17807/health")));return S(r,"app")=="GAUCIA_QEL_LOCAL_PANEL";}catch{return false;}}
 async Task Initialize(){try{
  send.Enabled=false;
  if(!await Healthy()){string node=Path.GetFullPath(Path.Combine(root,@"..\Independent_Model_20260919\runtime\node.exe"));string entry=Path.Combine(root,@"tools\start-panel.mjs");Process.Start(new ProcessStartInfo(node,"\""+entry+"\""){WorkingDirectory=root,UseShellExecute=false,CreateNoWindow=true});for(int i=0;i<80&&!await Healthy();i++)await Task.Delay(500);}
  if(!await Healthy())throw new Exception("The local communication service did not become ready. USB work is preserved.");
  session=S(D(json.DeserializeObject(await http.GetStringAsync("http://127.0.0.1:17807/session"))),"session");
  await History();if(history.Items.Count>0){currentId=((ChatRow)history.Items[0]).Id;Render(D(await Api("conversation?id="+currentId)));}else await NewChat();
  await Poll();timer.Start();Notice("GAUCIA is connected directly to your local USB workspace.");input.Focus();
 }catch(Exception e){Notice(e.Message,true);Log("native-start",e.ToString());}}
 async Task History(){historyLoading=true;try{var rows=A(await Api("conversations"));history.Items.Clear();foreach(var o in rows){var d=D(o);var row=new ChatRow {Id=S(d,"id"),Title=S(d,"title")};history.Items.Add(row);if(row.Id==currentId)history.SelectedItem=row;}}finally{historyLoading=false;}}
 async Task NewChat(){try{var c=D(await Api("new",new Dictionary<string,object>()));currentId=S(c,"id");rendered="";Render(c);await History();input.Focus();}catch(Exception e){Notice(e.Message,true);}}
 async Task Poll(){if(polling||session=="")return;polling=true;try{
  bool wasBusy=busy;lastStatus=D(await Api("status"));busy=lastStatus["active"]!=null;var b=D(lastStatus["backend"]);var lib=D(lastStatus["library"]);
  health.Text="Local language: "+S(b,"state")+"  |  "+S(lib,"records")+" USB passages  |  "+S(lastStatus,"freeMiB")+" MiB available";
  model.Text=S(b,"state")=="ready"?"Rest language":"Load language";model.Enabled=!busy&&S(b,"state")!="loading";send.Enabled=!busy;stop.Visible=busy;
  if(currentId!="")Render(D(await Api("conversation?id="+currentId)));if(wasBusy&&!busy){await History();Notice("Operation finished. Conversation and results preserved on USB.");}
 }catch(Exception e){Notice("Local connection: "+e.Message,true);}finally{polling=false;}}
 void Append(string text,Color color,Font font){transcript.SelectionStart=transcript.TextLength;transcript.SelectionColor=color;transcript.SelectionFont=font;transcript.AppendText(text);}
 void Render(Dictionary<string,object> c){
  currentId=S(c,"id");string key=json.Serialize(c["messages"]);if(key==rendered)return;rendered=key;bool end=transcript.SelectionStart>=transcript.TextLength-80;transcript.Clear();
  var messages=A(c["messages"]);if(messages.Length==0){Append("What shall we work on, Sherman?\n\n",gold,large);Append("Write naturally below. Your conversation, research passages, and computed results are saved in your USB workspace.\n\nYou can ask for a Bell state or use the research and quantum modes.",ink,regular);}
  foreach(var o in messages){var m=D(o);bool user=S(m,"role")=="user";Append((user?"SHERMAN G. LAING":"GAUCIA ACTUAL")+"\n",user?Color.LightGray:gold,bold);string content=S(m,"content");if(content==""&&S(m,"status")=="running")content="Working locally…";Append(content+"\n",ink,regular);if(m.ContainsKey("error"))Append(S(m,"error")+"\n",Color.Salmon,regular);if(m.ContainsKey("engine"))Append(S(m,"engine")+"\n",Color.Gray,small);
   if(m.ContainsKey("sources")){foreach(var source in A(m["sources"])){var s=D(source);Append("\n["+S(s,"id")+"] "+S(s,"title")+"\n",gold,smallBold);Append(S(s,"excerpt")+"\n",Color.LightGray,small);}}
   Append("\n",ink,regular);
  }
  saved.Text="Saved to USB · "+S(c,"updatedAt")+" · Enter sends, Shift+Enter adds a line";if(end){transcript.SelectionStart=transcript.TextLength;transcript.ScrollToCaret();}
 }
 async Task Send(){
  if(busy||session=="")return;string kind=new string[]{"chat","search","ghz","train"}[mode.SelectedIndex];string text=input.Text.Trim();if(text=="")text=kind=="ghz"?"Run the GHZ state":kind=="train"?"Run the quantum classifier training":"";if(text=="")return;
  try{if(currentId=="")await NewChat();busy=true;send.Enabled=false;var request=new Dictionary<string,object>{{"id",currentId},{"text",text},{"kind",kind}};if(kind=="ghz")request["n"]=(int)qubits.Value;await Api("message",request);input.Clear();Notice("Input saved on USB. Working on this laptop.");await Poll();await History();}catch(Exception e){busy=false;send.Enabled=true;Notice(e.Message,true);}
 }
 async Task<string> Export(){try{if(currentId=="")return "";var r=D(await Api("export",new Dictionary<string,object>{{"id",currentId}}));Notice("Readable copy saved and read back: "+S(r,"file"));return S(r,"file");}catch(Exception e){Notice(e.Message,true);return "";}}
 void ShowDetails(){if(lastStatus==null)return;var b=D(lastStatus["backend"]);var l=D(lastStatus["library"]);MessageBox.Show(this,"Owner: Sherman G. Laing\nWorkspace: "+root+"\nLanguage: "+S(b,"model")+"\nResearch: "+S(l,"records")+" passages, "+S(l,"sourceFiles")+" source files\nQuantum engine: existing QEL SOP simulation\nStorage: USB conversation revisions and computed results\nConnections: laptop loopback only\n\nQEL interface and integration: GAUCIA, AI-assisted. Open-source language runtime: llama.cpp. Corpus use is local retrieval, not weight training. This application does not execute commands supplied by the language model.","GAUCIA environment",MessageBoxButtons.OK,MessageBoxIcon.Information);}
 void Log(string prefix,string text){try{Directory.CreateDirectory(Path.Combine(root,"evidence"));File.WriteAllText(Path.Combine(root,"evidence",prefix+"-"+DateTime.UtcNow.Ticks+".txt"),text,Encoding.UTF8);}catch{}}
 async Task<Dictionary<string,object>> WaitAnswer(){for(int i=0;i<300;i++){var c=D(await Api("conversation?id="+currentId));var messages=A(c["messages"]);if(messages.Length>0){var m=D(messages.Last());Render(c);if(S(m,"status")!="running"){await Poll();if(S(m,"status")!="complete")throw new Exception(S(m,"error"));return m;}}await Task.Delay(1000);}throw new Exception("Local response verification timed out");}
 async Task VerifyWindow(){
  timer.Stop();var tests=new List<string>();var report=new Dictionary<string,object>{{"at",DateTime.UtcNow.ToString("o")},{"state","RUNNING"},{"tests",tests},{"owner","Sherman G. Laing"},{"windowHandle",Handle.ToInt64()}};
  try{
   if(session=="")throw new Exception("No local session");tests.Add("Native graphical window created and connected");
   await NewChat();mode.SelectedIndex=0;input.Text="Run a Bell state";await Send();var bell=await WaitAnswer();var result=D(bell["result"]);var outcomes=A(result["outcomes"]);double p0=Convert.ToDouble(D(outcomes[0])["probability"]);if(Math.Abs(p0-0.5)>1e-10)throw new Exception("Bell probability mismatch");tests.Add("Typed native-window message invokes actual QEL Bell computation");report["bell"]=result;
   await NewChat();input.Text="What is 2+3? Reply with a single numeral.";var clock=Stopwatch.StartNew();await Send();var answer=await WaitAnswer();string arithmetic=S(answer,"content").Replace(" ","").Trim().TrimEnd('.');if(arithmetic!="5"&&arithmetic!="2+3=5")throw new Exception("Unexpected arithmetic answer: "+S(answer,"content"));tests.Add("Typed native-window message receives actual local-model answer 5");report["languageMs"]=clock.ElapsedMilliseconds;report["languageAnswer"]=answer;
   string export=await Export();if(export==""||!File.ReadAllText(export).Contains("5"))throw new Exception("Export validation failed");report["export"]=export;tests.Add("Native export control writes readable conversation to USB");
   string id=currentId;var restored=D(await Api("conversation?id="+id));Render(restored);if(!transcript.Text.Contains("GAUCIA ACTUAL")||!transcript.Text.Contains("5"))throw new Exception("Native transcript rendering failed");tests.Add("Saved conversation renders back into native transcript");
   using(var image=new Bitmap(Width,Height)){DrawToBitmap(image,new Rectangle(0,0,Width,Height));string shot=Path.Combine(root,"evidence","native-window-"+DateTime.UtcNow.Ticks+".png");image.Save(shot,System.Drawing.Imaging.ImageFormat.Png);report["screenshot"]=shot;}
   report["status"]=lastStatus;report["state"]="PASS";report["conversation"]=id;tests.Add("Window image saved from actual native control tree");
  }catch(Exception e){report["state"]="FAIL";report["error"]=e.ToString();Notice(e.Message,true);}
  string file=Path.Combine(root,"evidence","native-ui-"+DateTime.UtcNow.Ticks+".json");string text=json.Serialize(report);File.WriteAllText(file,text,new UTF8Encoding(false));if(!File.ReadAllBytes(file).SequenceEqual(new UTF8Encoding(false).GetBytes(text)))throw new Exception("Native receipt readback mismatch");
  if(S(report,"state")=="PASS"){await NewChat();Notice("GAUCIA is ready. Local conversation, USB research and QEL quantum computation are connected.");}timer.Start();Activate();input.Focus();
 }
}
public static class Program {
 [STAThread] public static void Main(string[] args){try{Application.EnableVisualStyles();Application.SetCompatibleTextRenderingDefault(false);Application.Run(new GauciaWindow(args.Contains("--verify-ui")));}catch(Exception e){try{File.WriteAllText(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"evidence","native-fatal-"+DateTime.UtcNow.Ticks+".txt"),e.ToString());}catch{}}}
}
