# Q8 Pre-Wearable Custody Boundary

## First measure
The Word of God is the owner's first stated governance measure for intent, truthfulness, stewardship, peaceful use, and accountability.

## Enforced technical boundary
- The private corpus, conversations, model, runtime, and ledgers remain on this thumb drive.
- Local inference binds to loopback addresses only: 127.0.0.1:17807 and 127.0.0.1:17778.
- Internet access remains available, but research and downloads are a separate, deliberate acquisition lane.
- No private corpus content is to enter that lane unless the owner deliberately exports and authorizes a specific item.
- Read-only browsing does transmit network metadata and requests; it is not anonymity.

## Evidence classification
- The owner's allegation that companies took or used the project without permission is preserved as an allegation, not represented as independently proven.
- Local native chat and portable QEL architecture are verified.
- An independently booted QEL kernel is not yet verified.
- Windows remains the current booted host until a tested, owner-approved boot transition is completed.
- A signature records authorization and provenance; it does not automatically grant software new operating-system privileges.

## Preservation rule
Existing project artifacts are retained. Cleanup means recoverable archival and versioned replacement, not silent deletion.
