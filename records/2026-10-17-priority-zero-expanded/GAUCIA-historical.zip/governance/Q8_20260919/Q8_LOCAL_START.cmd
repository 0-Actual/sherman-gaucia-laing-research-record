@echo off
set "Q8_ROOT=%LOCALAPPDATA%\Temp\QEL_Q8_Connection"
powershell.exe -NoLogo -NoExit -ExecutionPolicy Bypass -File "%Q8_ROOT%\Q8.PowerShell.ps1"

[executed on device: DESKTOP-EI6MFFI (94e10637-ae66-4f89-b08f-5c16bd362ae6)]