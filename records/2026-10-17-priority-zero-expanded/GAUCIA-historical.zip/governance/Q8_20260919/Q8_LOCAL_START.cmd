@echo off
set "Q8_ROOT=%LOCALAPPDATA%\Temp\QEL_Q8_Connection"
powershell.exe -NoLogo -NoExit -ExecutionPolicy Bypass -File "%Q8_ROOT%\Q8.PowerShell.ps1"

