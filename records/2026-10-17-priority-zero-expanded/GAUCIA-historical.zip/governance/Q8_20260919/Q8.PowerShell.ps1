$ErrorActionPreference = 'Stop'
$Q8Root = Join-Path $env:LOCALAPPDATA 'Temp\QEL_Q8_Connection'
$Q8Workspace = 'http://127.0.0.1:8795'
$Q8Model = 'http://127.0.0.1:8794'
$env:Q8_ROOT = $Q8Root
$env:Q8_MODE = 'LOCAL_PRIVATE'
$env:Q8_EXTERNAL_TRANSMISSION = 'DENY'

try { $Host.UI.RawUI.WindowTitle = 'Q8 Sovereign PowerShell - Local Private Runtime' } catch {}
Set-Location $Q8Root

function global:prompt {
    "Q8 [LOCAL|PRIVATE] PS $($executionContext.SessionState.Path.CurrentLocation)> "
}

function Q8-Status {
    Write-Host 'Q8 Sovereign Workspace' -ForegroundColor Yellow
    try { Invoke-RestMethod "$Q8Workspace/status" | Format-List } catch { Write-Host "Workspace HOLD: $($_.Exception.Message)" -ForegroundColor Red }
    try { Invoke-RestMethod "$Q8Model/health" | Format-List } catch { Write-Host "Model HOLD: $($_.Exception.Message)" -ForegroundColor Red }
}

function Q8-Open {
    Start-Process $Q8Workspace
}

function Q8-Files {
    Get-ChildItem $Q8Root | Select-Object Mode,Length,LastWriteTime,Name | Format-Table -AutoSize
}

function Q8-Ledger {
    $ledger = Join-Path $Q8Root 'Q8_SOVEREIGN_WORKSPACE_LEDGER.ndjson'
    if (Test-Path $ledger) { Get-Content $ledger -Tail 20 } else { Write-Host 'Ledger not found.' -ForegroundColor Red }
}

Clear-Host
Write-Host 'Q8 SOVEREIGN POWERSHELL' -ForegroundColor Yellow
Write-Host 'Mode: LOCAL / PRIVATE / OWNER-CONTROLLED'
Write-Host 'Corpus and transcripts: local laptop storage'
Write-Host 'Model: Qwen2.5 0.5B Q4_K_M through llama.cpp'
Write-Host 'Commands: Q8-Status | Q8-Open | Q8-Files | Q8-Ledger'
Write-Host ''
Q8-Status

