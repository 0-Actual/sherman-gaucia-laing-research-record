' Add a desktop entry without replacing an existing shortcut.
Option Explicit
Dim fs, sh, root, desk, target, shortcutPath, link, check
Set fs = CreateObject("Scripting.FileSystemObject")
Set sh = CreateObject("WScript.Shell")
root = fs.GetParentFolderName(fs.GetParentFolderName(WScript.ScriptFullName))
desk = sh.SpecialFolders("Desktop")
target = fs.BuildPath(root, "OPEN_GAUCIA.vbs")
If Not fs.FileExists(target) Then WScript.Quit 2
shortcutPath = fs.BuildPath(desk, "GAUCIA Local Workspace.lnk")
If fs.FileExists(shortcutPath) Then
  WScript.Echo "EXISTING_SHORTCUT_PRESERVED " & shortcutPath
  WScript.Quit 3
End If
Set link = sh.CreateShortcut(shortcutPath)
link.TargetPath = sh.ExpandEnvironmentStrings("%SystemRoot%\System32\wscript.exe")
link.Arguments = "//nologo " & Chr(34) & target & Chr(34)
link.WorkingDirectory = root
link.Description = "GAUCIA - local conversation, USB research and QEL quantum computation"
link.WindowStyle = 1
link.Save
Set check = sh.CreateShortcut(shortcutPath)
WScript.Echo "SHORTCUT_CREATED " & shortcutPath
WScript.Echo "TARGET_READBACK " & check.TargetPath
WScript.Echo "ARGUMENTS_READBACK " & check.Arguments
WScript.Echo "WORKDIR_READBACK " & check.WorkingDirectory
