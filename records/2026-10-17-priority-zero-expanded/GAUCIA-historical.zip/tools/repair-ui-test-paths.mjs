import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const source=path.join(import.meta.dirname,'verify-visible-interface.mjs');
const before=fs.readFileSync(source,'utf8');
const old="const candidates=[path.join(process.env['ProgramFiles(x86)'],'Microsoft','Edge','Application','msedge.exe'),path.join(process.env.ProgramFiles,'Microsoft','Edge','Application','msedge.exe')];";
const replacement="const candidates=[path.join(process.env['ProgramFiles(x86)']||'./REDACTED_LOCAL_ROOT/Program Files (x86)','Microsoft','Edge','Application','msedge.exe'),path.join(process.env.ProgramFiles||'./REDACTED_LOCAL_ROOT/Program Files','Microsoft','Edge','Application','msedge.exe')];";
assert(before.includes(old));const out=path.join(import.meta.dirname,'verify-visible-interface-r2.mjs');fs.writeFileSync(out,before.replace(old,replacement),{flag:'wx'});console.log(out);
