// Close only the verification window created by this build, using normal WM_CLOSE.
using System;using System.Text;using System.Runtime.InteropServices;
class CloseOwnTestWindow {
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetWindowText(IntPtr window,StringBuilder text,int count);
 [DllImport("user32.dll",SetLastError=true)]static extern bool PostMessage(IntPtr window,uint message,IntPtr wparam,IntPtr lparam);
 static int Main(){var window=new IntPtr(2753854);var text=new StringBuilder(256);GetWindowText(window,text,256);if(text.ToString()!="GAUCIA | Quantum.Earth.Laing"){Console.WriteLine("Verification window not matched; no action.");return 1;}bool ok=PostMessage(window,0x0010,IntPtr.Zero,IntPtr.Zero);Console.WriteLine("OWN_TEST_WINDOW_CLOSE_REQUEST="+ok);return ok?0:2;}
}
