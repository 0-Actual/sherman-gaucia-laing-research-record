// Read-only diagnostic of this process's desktop and local HTTP access.
using System;using System.Net.Http;using System.Diagnostics;using System.Threading.Tasks;
class NativeProbe {
 static void Main(){Console.WriteLine("USER_INTERACTIVE="+Environment.UserInteractive);try{Console.WriteLine("SESSION="+Process.GetCurrentProcess().SessionId);}catch(Exception e){Console.WriteLine("SESSION_READ="+e.Message);}try{Console.WriteLine("DESKTOP="+Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory));}catch(Exception e){Console.WriteLine("DESKTOP_READ="+e.Message);}Run().GetAwaiter().GetResult();}
 static async Task Run(){try{using(var client=new HttpClient(new HttpClientHandler{UseProxy=false,AllowAutoRedirect=false})){client.Timeout=TimeSpan.FromSeconds(6);var r=await client.GetAsync("http://127.0.0.1:17807/health");Console.WriteLine("HTTP="+(int)r.StatusCode);Console.WriteLine(await r.Content.ReadAsStringAsync());}}catch(Exception e){Console.WriteLine("HTTP_FAILURE="+e.ToString());}}
}
