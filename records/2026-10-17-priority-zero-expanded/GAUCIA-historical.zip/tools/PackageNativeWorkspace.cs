// Private point-in-time source/application/evidence bundle. No hashes or signatures.
using System;using System.IO;using System.IO.Compression;using System.Linq;using System.Text;using System.Collections.Generic;using System.Web.Script.Serialization;
class PackageNativeWorkspace {
 static string root;static List<string> files=new List<string>();
 static void Add(string relative){string full=Path.Combine(root,relative);if(File.Exists(full))files.Add(full);}
 static void Tree(string relative,Func<string,bool> include){string dir=Path.Combine(root,relative);if(Directory.Exists(dir))foreach(string file in Directory.GetFiles(dir,"*",SearchOption.AllDirectories))if(include(file))files.Add(file);}
 static int Main(){
  root=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,".."));string id=DateTime.UtcNow.ToString("yyyyMMddTHHmmssZ"),snapshot=Path.Combine(root,"release-snapshots",id);Directory.CreateDirectory(snapshot);var json=new JavaScriptSerializer {MaxJsonLength=33554432};
  string archive=Path.Combine(root,"GAUCIA_Local_Environment_"+id+".zip");var items=new List<Dictionary<string,object>>();
  try{
   foreach(string file in new[]{"GAUCIA-Local.exe","communication.mjs","backend.mjs","core.mjs","config.json","quantum-worker.mjs","CURRENT_ENVIRONMENT.md","CURRENT_STATUS.json","BUILD_STATUS.json"})Add(file);
   Tree("engine",p=>p.EndsWith(".mjs",StringComparison.OrdinalIgnoreCase));Tree("governance",p=>p.EndsWith(".txt",StringComparison.OrdinalIgnoreCase));
   Tree("ui",p=>new[]{".cs",".html",".css",".js"}.Contains(Path.GetExtension(p).ToLowerInvariant()));
   Tree("tools",p=>new[]{".cs",".mjs",".vbs"}.Contains(Path.GetExtension(p).ToLowerInvariant()));
   Tree("evidence",p=>new[]{".json",".png",".txt"}.Contains(Path.GetExtension(p).ToLowerInvariant()));
   foreach(string dir in new[]{"conversations","jobs","models","notes","exports"})Tree(Path.Combine("data",dir),p=>new[]{".json",".md",".txt"}.Contains(Path.GetExtension(p).ToLowerInvariant()));
   foreach(string source in files.Distinct().OrderBy(p=>p,StringComparer.Ordinal)){string relative=source.Substring(root.Length).TrimStart(Path.DirectorySeparatorChar);byte[] bytes=File.ReadAllBytes(source);if(bytes.Length>33554432)throw new Exception("Unexpected oversized source: "+relative);string target=Path.Combine(snapshot,relative);Directory.CreateDirectory(Path.GetDirectoryName(target));using(var f=new FileStream(target,FileMode.CreateNew,FileAccess.Write)){f.Write(bytes,0,bytes.Length);f.Flush(true);}if(!File.ReadAllBytes(target).SequenceEqual(bytes))throw new Exception("Snapshot byte mismatch: "+relative);items.Add(new Dictionary<string,object>{{"name",relative.Replace('\\','/')},{"bytes",bytes.Length}});}
   var manifest=new Dictionary<string,object>{{"at",DateTime.UtcNow.ToString("o")},{"owner","Sherman G. Laing"},{"state","PRIVATE/HOLD/UNSIGNED"},{"files",items},{"snapshotReadback","each saved file directly compared with its source bytes"},{"excluded","existing 640MB language weights and runtimes remain in Independent_Model_20260919; browser test caches, encoded abandoned transfer, mutable logs and ledgers excluded"},{"signature",null}};
   File.WriteAllText(Path.Combine(snapshot,"FILE_INVENTORY.json"),json.Serialize(manifest),new UTF8Encoding(false));
   using(var output=new FileStream(archive,FileMode.CreateNew,FileAccess.ReadWrite))using(var zip=new ZipArchive(output,ZipArchiveMode.Create))foreach(string file in Directory.GetFiles(snapshot,"*",SearchOption.AllDirectories)){string relative=file.Substring(snapshot.Length).TrimStart(Path.DirectorySeparatorChar).Replace('\\','/');zip.CreateEntryFromFile(file,relative,CompressionLevel.Optimal);}
   long total=0;int count=0;using(var input=ZipFile.OpenRead(archive)){foreach(var entry in input.Entries){byte[] actual;using(var stream=entry.Open())using(var memory=new MemoryStream()){stream.CopyTo(memory);actual=memory.ToArray();}string source=Path.Combine(snapshot,entry.FullName.Replace('/',Path.DirectorySeparatorChar));if(!File.ReadAllBytes(source).SequenceEqual(actual))throw new Exception("ZIP byte mismatch: "+entry.FullName);total+=entry.Length;count++;}}
   var receipt=new Dictionary<string,object>{{"at",DateTime.UtcNow.ToString("o")},{"state","PASS"},{"archive",archive},{"snapshot",snapshot},{"entries",count},{"compressedBytes",new FileInfo(archive).Length},{"uncompressedBytes",total},{"everyEntryComparedDirectly",true},{"ownerSignature",null}};
   string receiptPath=Path.Combine(root,"evidence","native-package-"+id+".json");string text=json.Serialize(receipt);File.WriteAllText(receiptPath,text,new UTF8Encoding(false));if(File.ReadAllText(receiptPath)!=text)throw new Exception("Receipt readback failed");Console.WriteLine(text);Console.WriteLine(receiptPath);return 0;
  }catch(Exception e){string report=Path.Combine(root,"evidence","native-package-failure-"+id+".txt");File.WriteAllText(report,e.ToString());Console.WriteLine(e.ToString());return 1;}
 }
}
