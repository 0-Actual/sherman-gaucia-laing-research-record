// Desktop entry point for the owner-operated QEL communication panel.
import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';
// Owner-directed security-only hold: stop before ordinary runtime work.
let qelSecurityOnlyHold = true;
try { fs.lstatSync('./REDACTED_LOCAL_ROOT/QEL_Q7/SECURITY_ONLY_HOLD.json'); } catch (e) { if (e.code === 'ENOENT') qelSecurityOnlyHold = false; }
if (qelSecurityOnlyHold) { console.error('QEL_SECURITY_ONLY_HOLD: ordinary project work is paused.'); process.exit(73); }
const root=path.resolve(import.meta.dirname,'..'),url='http://127.0.0.1:17807';
async function healthy(){try{const r=await fetch(url+'/health',{redirect:'error',signal:AbortSignal.timeout(1500)});return r.ok&&(await r.json()).app==='GAUCIA_QEL_LOCAL_PANEL';}catch{return false;}}
if(!await healthy()){
  const log=fs.openSync(path.join(root,'logs','communication-'+Date.now()+'.log'),'a');
  const child=spawn(process.execPath,[path.join(root,'communication.mjs')],{cwd:root,detached:true,windowsHide:true,stdio:['ignore',log,log]});
  child.unref();fs.closeSync(log);
  let ready=false;for(let i=0;i<40;i++){await new Promise(r=>setTimeout(r,500));if(await healthy()){ready=true;break;}}
  if(!ready)throw Error('Local panel did not become ready; inspect the USB communication log.');
}
console.log('GAUCIA_LOCAL_PANEL_READY '+url);
if(process.argv.includes('--open')){
  const choices=[path.join(process.env['ProgramFiles(x86)']||'./REDACTED_LOCAL_ROOT/Program Files (x86)','Microsoft','Edge','Application','msedge.exe'),path.join(process.env.ProgramFiles||'./REDACTED_LOCAL_ROOT/Program Files','Microsoft','Edge','Application','msedge.exe')];
  const edge=choices.find(f=>fs.existsSync(f));
  if(!edge)throw Error('The existing Edge rendering engine was not found. No browser was installed.');
  const window=spawn(edge,['--app='+url,'--no-first-run','--no-default-browser-check','--disable-background-networking'],{detached:true,windowsHide:false,stdio:'ignore'});
  window.unref();console.log('QEL_WINDOW_LAUNCH_REQUESTED');
}
