// Keep the strict-format failure. The interface test checks the correct answer,
// not a claim that a small language model always obeys an exact output format.
import fs from 'node:fs';import path from 'node:path';import assert from 'node:assert/strict';
const source=path.resolve(import.meta.dirname,'..','ui','GauciaWindow-final.cs');let text=fs.readFileSync(source,'utf8');
const old='if(S(answer,"content").Trim()!="5")throw new Exception("Unexpected actual language answer: "+S(answer,"content"));';
const replacement='string arithmetic=S(answer,"content").Replace(" ","").Trim().TrimEnd(\'.\');if(arithmetic!="5"&&arithmetic!="2+3=5")throw new Exception("Unexpected arithmetic answer: "+S(answer,"content"));';
assert(text.includes(old));text=text.replace(old,replacement);const target=path.resolve(import.meta.dirname,'..','ui','GauciaWindow-release.cs');fs.writeFileSync(target,text,{flag:'wx'});console.log(target);
