// Use software rendering for this old laptop; preserve browser sandboxing.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const source=fs.readFileSync(path.join(import.meta.dirname,'verify-visible-interface-r2.mjs'),'utf8');
const old="['--headless=new','--remote-debugging-address=127.0.0.1'";
const replacement="['--headless=new','--disable-gpu','--disable-gpu-shader-disk-cache','--remote-debugging-address=127.0.0.1'";
assert(source.includes(old));const out=path.join(import.meta.dirname,'verify-visible-interface-r3.mjs');fs.writeFileSync(out,source.replace(old,replacement),{flag:'wx'});console.log(out);
