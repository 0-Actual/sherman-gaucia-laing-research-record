import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const root=path.resolve(import.meta.dirname,'..');
const p=JSON.parse(fs.readFileSync(path.join(root,'data/probe.json'),'utf8'));
const start=Date.now();
try {
 const response=await fetch('http://127.0.0.1:'+p.port+'/v1/chat/completions',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+p.key},body:JSON.stringify({messages:[{role:'system',content:'You are GAUCIA, a local assistant in Quantum.Earth.Laing.'},{role:'user',content:'Reply with exactly these words: LOCAL QEL READY'}],max_tokens:24,temperature:0.7,stream:false,chat_template_kwargs:{enable_thinking:false}}),signal:AbortSignal.timeout(180000)});
 const data=await response.json();
 const result={at:new Date().toISOString(),httpStatus:response.status,elapsedMs:Date.now()-start,freeMiB:Math.round(os.freemem()/1048576),response:data};
 fs.writeFileSync(path.join(root,'evidence/first-local-inference.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(result));
}catch(e){console.error(e.stack);process.exitCode=1;}
