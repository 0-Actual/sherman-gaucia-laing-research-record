// Uses the Windows Shell link interface; does not change scripting or security policy.
using System;using System.IO;using System.Text;using System.Runtime.InteropServices;using System.Runtime.InteropServices.ComTypes;using System.Web.Script.Serialization;using System.Collections.Generic;
[ComImport,Guid("00021401-0000-0000-C000-000000000046")]class ShellLink {}
[ComImport,Guid("000214F9-0000-0000-C000-000000000046"),InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]interface IShellLinkW {
 void GetPath([Out,MarshalAs(UnmanagedType.LPWStr)]StringBuilder path,int capacity,IntPtr findData,uint flags);
 void GetIDList(out IntPtr pidl);void SetIDList(IntPtr pidl);
 void GetDescription([Out,MarshalAs(UnmanagedType.LPWStr)]StringBuilder text,int capacity);
 void SetDescription([MarshalAs(UnmanagedType.LPWStr)]string text);
 void GetWorkingDirectory([Out,MarshalAs(UnmanagedType.LPWStr)]StringBuilder path,int capacity);
 void SetWorkingDirectory([MarshalAs(UnmanagedType.LPWStr)]string path);
 void GetArguments([Out,MarshalAs(UnmanagedType.LPWStr)]StringBuilder args,int capacity);
 void SetArguments([MarshalAs(UnmanagedType.LPWStr)]string args);
 void GetHotkey(out short key);void SetHotkey(short key);void GetShowCmd(out int command);void SetShowCmd(int command);
 void GetIconLocation([Out,MarshalAs(UnmanagedType.LPWStr)]StringBuilder icon,int capacity,out int index);
 void SetIconLocation([MarshalAs(UnmanagedType.LPWStr)]string icon,int index);
 void SetRelativePath([MarshalAs(UnmanagedType.LPWStr)]string path,uint reserved);
 void Resolve(IntPtr window,uint flags);void SetPath([MarshalAs(UnmanagedType.LPWStr)]string path);
}
class DesktopEntry {
 [STAThread]static int Main(){
  string root=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,".."));var receipt=new Dictionary<string,object>{{"at",DateTime.UtcNow.ToString("o")},{"state","RUNNING"}};
  try{string target=Path.Combine(root,"GAUCIA.exe"),desktop=Environment.GetFolderPath(Environment.SpecialFolder.DesktopDirectory),file=Path.Combine(desktop,"GAUCIA Local Workspace.lnk");if(!File.Exists(target))throw new Exception("Native GAUCIA executable missing");if(File.Exists(file))throw new Exception("Existing desktop entry preserved; no overwrite performed");
   object obj=new ShellLink();var link=(IShellLinkW)obj;link.SetPath(target);link.SetWorkingDirectory(root);link.SetArguments("");link.SetDescription("GAUCIA — Quantum.Earth.Laing local conversation and quantum computation");link.SetShowCmd(1);link.SetIconLocation(target,0);((IPersistFile)obj).Save(file,true);Marshal.ReleaseComObject(obj);
   object check=new ShellLink();((IPersistFile)check).Load(file,0);var text=new StringBuilder(2048);((IShellLinkW)check).GetPath(text,text.Capacity,IntPtr.Zero,0);if(!String.Equals(text.ToString(),target,StringComparison.OrdinalIgnoreCase))throw new Exception("Shortcut target readback mismatch");Marshal.ReleaseComObject(check);
   receipt["state"]="PASS";receipt["shortcut"]=file;receipt["target"]=target;receipt["targetReadback"]=text.ToString();receipt["bytes"]=new FileInfo(file).Length;
  }catch(Exception e){receipt["state"]="FAIL";receipt["error"]=e.ToString();}
  string output=Path.Combine(root,"evidence","desktop-entry-"+DateTime.UtcNow.Ticks+".json");var json=new JavaScriptSerializer().Serialize(receipt);File.WriteAllText(output,json,new UTF8Encoding(false));Console.WriteLine(json);Console.WriteLine(output);return (string)receipt["state"]=="PASS"?0:1;
 }
}
