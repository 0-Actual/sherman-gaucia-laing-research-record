// Close only this build's verification window, then open the verified app normally.
// No screenshot capture, desktop writes, permission changes, or hosted services.
using System;using System.IO;using System.Text;using System.Linq;using System.Diagnostics;using System.Runtime.InteropServices;using System.Threading;using System.Collections.Generic;using System.Web.Script.Serialization;
class OpenVerifiedNativeWindow {
 [DllImport("user32.dll",CharSet=CharSet.Unicode)]static extern int GetWindowText(IntPtr window,StringBuilder text,int count);
 [DllImport("user32.dll")]static extern bool PostMessage(IntPtr window,uint message,IntPtr w,IntPtr l);
 [DllImport("user32.dll")]static extern bool IsWindowVisible(IntPtr window);
 static int Main(){
  string root=Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory,".."));var r=new Dictionary<string,object>{{"at",DateTime.UtcNow.ToString("o")},{"state","RUNNING"},{"owner","Sherman G. Laing"}};
  try{
   var prior=new IntPtr(197734);var title=new StringBuilder(256);GetWindowText(prior,title,256);if(title.ToString()=="GAUCIA | Quantum.Earth.Laing"){r["verificationWindowCloseRequested"]=PostMessage(prior,0x0010,IntPtr.Zero,IntPtr.Zero);Thread.Sleep(700);}
   string exe=Path.Combine(root,"GAUCIA-Local.exe");var app=Process.Start(new ProcessStartInfo(exe){WorkingDirectory=root,UseShellExecute=false});
   try{app.WaitForInputIdle(20000);}catch(InvalidOperationException){}
   for(int i=0;i<40;i++){app.Refresh();if(app.HasExited)throw new Exception("Native application exited before its window was ready");if(app.MainWindowHandle!=IntPtr.Zero)break;Thread.Sleep(500);}
   r["pid"]=app.Id;r["windowHandle"]=app.MainWindowHandle.ToInt64();r["title"]=app.MainWindowTitle;r["visible"]=IsWindowVisible(app.MainWindowHandle);r["executable"]=exe;r["userInteractive"]=Environment.UserInteractive;r["sessionId"]=Process.GetCurrentProcess().SessionId;
   if(app.MainWindowHandle==IntPtr.Zero||!(bool)r["visible"]||app.MainWindowTitle!="GAUCIA | Quantum.Earth.Laing")throw new Exception("Visible native window verification failed");
   r["state"]="PASS";r["leftOpen"]=true;r["scope"]="Native window visibility and identity; functional interaction is recorded in separate receipts";
  }catch(Exception e){r["state"]="FAIL";r["error"]=e.ToString();}
  string output=Path.Combine(root,"evidence","native-open-"+DateTime.UtcNow.Ticks+".json");string text=new JavaScriptSerializer().Serialize(r);byte[] bytes=new UTF8Encoding(false).GetBytes(text);File.WriteAllBytes(output,bytes);if(!File.ReadAllBytes(output).SequenceEqual(bytes))throw new Exception("Receipt readback mismatch");Console.WriteLine(text);Console.WriteLine(output);return (string)r["state"]=="PASS"?0:1;
 }
}
