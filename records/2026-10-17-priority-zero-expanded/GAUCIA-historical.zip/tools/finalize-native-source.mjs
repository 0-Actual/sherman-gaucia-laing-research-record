// Preserve the first source and emit a resource-bounded final source.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
const source=path.resolve(import.meta.dirname,'..','ui','GauciaWindow.cs');let text=fs.readFileSync(source,'utf8');
const anchor='string session="", currentId="",rendered="";';assert(text.includes(anchor));
text=text.replace(anchor,'readonly Font small=new Font("Segoe UI",9),smallBold=new Font("Segoe UI",9,FontStyle.Bold),large=new Font("Segoe UI",19);\n '+anchor);
const cut=text.indexOf(' void Render(');text=text.slice(0,cut)+text.slice(cut).replaceAll('new Font("Segoe UI",9,FontStyle.Bold)','smallBold').replaceAll('new Font("Segoe UI",9)','small').replaceAll('new Font("Segoe UI",19)','large');
text=text.replace('tools.Controls.Add(qubits);','tools.Controls.Add(qubits);qubits.AccessibleName="GHZ qubits";qubits.Visible=false;mode.SelectedIndexChanged+=delegate {qubits.Visible=mode.SelectedIndex==2;};');
const target=path.resolve(import.meta.dirname,'..','ui','GauciaWindow-final.cs');fs.writeFileSync(target,text,{flag:'wx'});console.log(target);
