import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
const root=path.resolve(import.meta.dirname,'..');
const dep=path.resolve(root,'../Independent_Model_20260919');
const q=path.resolve(root,'../QEL_Local_Quantum_AI_20260919_1434');
const pairs=[['engine/quantum.mjs',path.join(q,'quantum.mjs')],['engine/vendor/qel60_sop.mjs',path.join(q,'vendor/qel60_sop.mjs')],['engine/sgl-prime.mjs',path.join(dep,'integrity/sgl-prime.mjs')],['governance/inherited-system-prompt.txt',path.join(dep,'governance/system-prompt.txt')]];
const rows=[];
try {
 for(const [relative,source] of pairs){
  const destination=path.join(root,relative), bytes=fs.readFileSync(source);
  if(fs.existsSync(destination)&&!bytes.equals(fs.readFileSync(destination)))fs.renameSync(destination,destination+'.incomplete-'+Date.now());
  if(!fs.existsSync(destination)){const fd=fs.openSync(destination,'wx');try{fs.writeFileSync(fd,bytes);fs.fsyncSync(fd);}finally{fs.closeSync(fd);}}
  if(!bytes.equals(fs.readFileSync(destination)))throw Error('Byte mismatch: '+relative);
  rows.push({source,destination,bytes:bytes.length,byte_equal:true});
  console.log('Verified '+relative);
 }
 const result={at:new Date().toISOString(),owner:'Sherman G. Laing',copies:rows,free_ram:os.freemem(),originals_unchanged:true,signature:null,release:'PRIVATE/HOLD'};
 fs.writeFileSync(path.join(root,'evidence/preparation.json'),JSON.stringify(result,null,2)+'\n',{flag:'wx'});
 console.log(JSON.stringify(result));
} catch(e){console.error(e.stack);process.exitCode=1;}
