// Actual loopback integration tests; no mocked language or quantum output.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {Records,writeNew} from '../core.mjs';
const root=path.resolve(import.meta.dirname,'..'),base='http://127.0.0.1:17807';
const receipt={at:new Date().toISOString(),owner:'Sherman G. Laing',tests:[],actualOutputs:{},state:'RUNNING',signature:null};
let key='';
async function api(route,data){const r=await fetch(base+'/api/'+route,{method:data===undefined?'GET':'POST',headers:{'Content-Type':'application/json','X-QEL-Session':key},body:data===undefined?undefined:JSON.stringify(data),signal:AbortSignal.timeout(10000)});const b=await r.json();if(!r.ok)throw Error(route+': '+JSON.stringify(b));return b;}
function passed(name,details={}){receipt.tests.push({name,passed:true,...details});console.log('PASS '+name);}
async function run(c,text,kind='chat',extra={}){
 const acknowledgement=await api('message',{id:c.id,text,kind,...extra});const begin=Date.now();
 for(;;){const now=await api('conversation?id='+c.id),answer=now.messages.at(-1);if(answer.status!=='running'){if(answer.status!=='complete')throw Error(answer.error||answer.status);return {conversation:now,answer,elapsedMs:Date.now()-begin,job:acknowledgement.job};}if(Date.now()-begin>360000)throw Error('Timed out waiting for local job');await new Promise(r=>setTimeout(r,1000));}
}
try{
 const session=await fetch(base+'/session');key=(await session.json()).session;assert(key);passed('local session established');
 const page=await fetch(base+'/');assert.equal(page.status,200);assert((await page.text()).includes('Message GAUCIA'));assert(page.headers.get('content-security-policy').includes("connect-src 'self'"));passed('custom chat page and restrictive content policy');
 assert.equal((await fetch(base+'/api/status')).status,403);passed('API refuses missing local-session token');
 assert.equal((await fetch(base+'/api/status',{headers:{Origin:'https://example.invalid','X-QEL-Session':key}})).status,403);passed('API refuses external origin');
 const status=await api('status');receipt.initialStatus=status;assert(status.library.records>0);passed('USB research loaded',{records:status.library.records,sourceFiles:status.library.sourceFiles});
 const c=await api('new',{});receipt.testConversation=c.id;
 const bad=await fetch(base+'/api/message',{method:'POST',headers:{'Content-Type':'application/json','X-QEL-Session':key},body:JSON.stringify({id:c.id,text:'invalid-mode verification',kind:'execute'})});assert.equal(bad.status,400);assert.equal((await api('conversation?id='+c.id)).messages.length,0);passed('unknown operation rejected without adding a message');
 const search=await run(c,'Search my archive for Genesis','search');assert(search.answer.sources.length>0);receipt.actualOutputs.search=search;passed('archive search through chat interface',{sources:search.answer.sources.length});
 const bell=await run(c,'Run a Bell state');assert.equal(bell.answer.result.n,2);assert(Math.abs(bell.answer.result.outcomes[0].probability-.5)<1e-10);assert(Math.abs(bell.answer.result.outcomes[1].probability-.5)<1e-10);receipt.actualOutputs.bell=bell;passed('natural-language request invokes actual QEL Bell calculation');
 const train=await run(c,'Run the quantum classifier training','train');assert(train.answer.result.final_loss<train.answer.result.initial_loss);assert.equal(train.answer.result.training_accuracy,1);receipt.actualOutputs.training=train;passed('quantum classifier training and USB parameter save',{epochs:train.answer.result.epochs});
 const dialog=await api('new',{});receipt.languageConversation=dialog.id;console.log('START actual USB language inference');
 const answer=await run(dialog,'Reply with exactly these words: GAUCIA LOCAL CHAT READY.');assert(answer.answer.content.trim().length>0);assert(answer.answer.engine.includes('Qwen3'));receipt.actualOutputs.language=answer;passed('actual local language response via integrated API',{elapsedMs:answer.elapsedMs,response:answer.answer.content});
 const disk=new Records(root,()=>null);assert.deepEqual(disk.get('conversations',dialog.id).messages,answer.conversation.messages);assert.deepEqual(disk.get('conversations',c.id).messages,train.conversation.messages);passed('fresh file reader restores exact saved conversation messages');
 const exported=await api('export',{id:dialog.id});assert(exported.readbackVerified);assert(fs.readFileSync(exported.file,'utf8').includes(answer.answer.content));receipt.export=exported;passed('readable export contains exact generated reply and passes byte readback');
 const models=disk.list('models');assert(models.some(m=>m.result?.parameters?.length===3));passed('trained quantum parameters reload from USB');
 receipt.finalStatus=await api('status');receipt.state='PASS';receipt.completedAt=new Date().toISOString();
}catch(e){receipt.state='FAIL';receipt.error=e.message;receipt.stack=e.stack;process.exitCode=1;console.error(e.stack);}
const file=path.join(root,'evidence','communication-'+Date.now()+'.json');writeNew(file,receipt);console.log(JSON.stringify({receipt:file,state:receipt.state,passed:receipt.tests.length,error:receipt.error||null}));
