// Test only our local chat page in a separate temporary browser profile.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {writeNew} from '../core.mjs';
const root=path.resolve(import.meta.dirname,'..'),base='http://127.0.0.1:17807',debug='http://127.0.0.1:17809';
const candidates=[path.join(process.env['ProgramFiles(x86)']||'./REDACTED_LOCAL_ROOT/Program Files (x86)','Microsoft','Edge','Application','msedge.exe'),path.join(process.env.ProgramFiles||'./REDACTED_LOCAL_ROOT/Program Files','Microsoft','Edge','Application','msedge.exe')];
const edge=candidates.find(p=>fs.existsSync(p));if(!edge)throw Error('Existing browser engine missing');
const started=Date.now(),receipt={at:new Date().toISOString(),tests:[],pageRequests:[],pageExceptions:[],state:'RUNNING'};
const log=fs.openSync(path.join(root,'logs','ui-verification-'+started+'.log'),'a');
const browser=spawn(edge,['--headless=new','--remote-debugging-address=127.0.0.1','--remote-debugging-port=17809','--user-data-dir='+path.join(root,'data','ui-test-profile-'+started),'--no-first-run','--no-default-browser-check','--disable-background-networking','--disable-sync','--disable-extensions','--window-size=1280,850',base],{windowsHide:true,stdio:['ignore',log,log]});fs.closeSync(log);
const delay=ms=>new Promise(r=>setTimeout(r,ms));let ws,serial=0,pending=new Map();
async function call(method,params={}){return new Promise((resolve,reject)=>{const id=++serial,timer=setTimeout(()=>{pending.delete(id);reject(Error('Browser test timeout: '+method));},30000);pending.set(id,{resolve,reject,timer});ws.send(JSON.stringify({id,method,params}));});}
async function value(expression){const r=await call('Runtime.evaluate',{expression,returnByValue:true,awaitPromise:true});if(r.exceptionDetails)throw Error(r.exceptionDetails.text);return r.result.value;}
async function wait(expression,seconds=90){for(let i=0;i<seconds;i++){if(await value(expression))return;await delay(1000);}throw Error('Page condition timed out: '+expression);}
function pass(name){receipt.tests.push({name,passed:true});console.log('PASS '+name);}
try{
 let target;for(let i=0;i<45;i++){try{const list=await(await fetch(debug+'/json/list')).json();target=list.find(t=>t.type==='page'&&t.url.startsWith(base));if(target)break;}catch{}await delay(1000);}if(!target)throw Error('Local test browser did not start');
 ws=new WebSocket(target.webSocketDebuggerUrl);await new Promise((resolve,reject)=>{ws.addEventListener('open',resolve,{once:true});ws.addEventListener('error',reject,{once:true});});
 ws.addEventListener('message',event=>{const d=JSON.parse(event.data);if(d.id&&pending.has(d.id)){const p=pending.get(d.id);pending.delete(d.id);clearTimeout(p.timer);d.error?p.reject(Error(d.error.message)):p.resolve(d.result);}else if(d.method==='Runtime.exceptionThrown')receipt.pageExceptions.push(d.params.exceptionDetails);else if(d.method==='Network.requestWillBeSent')receipt.pageRequests.push(d.params.request.url);});
 await call('Runtime.enable');await call('Network.enable');await call('Page.enable');await call('Emulation.setDeviceMetricsOverride',{width:1280,height:850,deviceScaleFactor:1,mobile:false});
 await wait("document.title.includes('GAUCIA') && document.getElementById('notice').textContent.includes('connected')");pass('custom GAUCIA page opens and connects');
 assert.equal(await value("document.querySelector('h1').textContent.trim()"),'GAUCIA Actual');pass('owner workspace branding rendered');
 await value("document.getElementById('input').value='Run a Bell state'; document.getElementById('chatForm').requestSubmit();");
 await wait("document.getElementById('messages').textContent.includes('P(00)') && !document.getElementById('sendButton').disabled");pass('typed chat request executes actual quantum operation from the page');
 receipt.bellPageText=await value("document.getElementById('messages').innerText");
 await value("document.getElementById('newChat').click()");await wait("document.getElementById('messages').children.length===0");
 const languageBegin=Date.now();await value("document.getElementById('input').value='What is 2+3? Reply with a single numeral.'; document.getElementById('chatForm').requestSubmit();");
 await wait("document.querySelector('.message.assistant .body') && document.querySelector('.message.assistant .body').textContent.trim()==='5' && !document.getElementById('sendButton').disabled",240);
 receipt.languagePageText=await value("document.getElementById('messages').innerText");receipt.languageMs=Date.now()-languageBegin;pass('typed message receives actual local model answer in the graphical page');
 const cid=await value("localStorage.getItem('qel-local-current')");await call('Page.reload');
 await wait("document.querySelector('.message.assistant .body') && document.querySelector('.message.assistant .body').textContent.trim()==='5'");
 assert.equal(await value("localStorage.getItem('qel-local-current')"),cid);pass('page reload recovers conversation and exact reply');
 await value("document.getElementById('exportButton').click()");await wait("document.getElementById('notice').textContent.includes('saved and read back')");pass('graphical export button saves a readable USB copy');
 await value("document.getElementById('aboutButton').click()");assert((await value("document.getElementById('details').textContent")).includes('395 passages'));pass('environment details expose actual loaded research count');await value("document.getElementById('closeAbout').click()");
 const image=await call('Page.captureScreenshot',{format:'png',captureBeyondViewport:false});const imagePath=path.join(root,'evidence','local-chat-window-'+started+'.png');writeNew(imagePath,Buffer.from(image.data,'base64'));receipt.screenshot=imagePath;
 const external=receipt.pageRequests.filter(u=>!u.startsWith(base)&&!u.startsWith('data:'));assert.equal(external.length,0);pass('observed page requests remained on loopback');assert.equal(receipt.pageExceptions.length,0);pass('no browser JavaScript exceptions during interaction');
 receipt.state='PASS';receipt.completedAt=new Date().toISOString();
}catch(e){receipt.state='FAIL';receipt.error=e.message;receipt.stack=e.stack;process.exitCode=1;console.error(e.stack);
 if(ws?.readyState===1){try{receipt.failurePage=await value('document.body.innerText');const image=await call('Page.captureScreenshot',{format:'png'});const p=path.join(root,'evidence','ui-failure-'+started+'.png');writeNew(p,Buffer.from(image.data,'base64'));receipt.screenshot=p;}catch{}}
}finally{
 if(ws?.readyState===1){try{await call('Browser.close');}catch{}ws.close();}
 else if(browser.exitCode===null)browser.kill();
}
const target=path.join(root,'evidence','visible-interface-'+started+'.json');writeNew(target,receipt);console.log(JSON.stringify({receipt:target,state:receipt.state,tests:receipt.tests.length,screenshot:receipt.screenshot,error:receipt.error||null}));
