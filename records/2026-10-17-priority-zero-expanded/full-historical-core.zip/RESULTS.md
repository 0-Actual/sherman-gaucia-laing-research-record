# Historical function observations — completed

The one authorized run passed all **eight fixed observations**, using nine calls to three preserved functions and NumPy 2.3.5. The supervisor recorded **3.8834 seconds** before result saving, including source checks and child startup/import. All 15 preserved source files (8,767 bytes) remained unchanged. The saved result was independently read; the observations were not rerun.

The measured behavior matches the source review:

- A state with squared norm one is retained at threshold one and excluded at 1.000000001.
- A first step with expected squared norm 0.25 is excluded at threshold 0.5, yet still feeds the next gate. The returned final state is `[0,1]`. Filtering the output list does not stop state propagation.
- A scaling operation returns `[2,0]` with squared norm four, confirming that normalization is not enforced. A separate complex unitary example retains norm 0.9999999999999998 within the specified 10⁻¹² tolerance.
- Applying a 2×2 matrix to a four-entry vector raises the expected NumPy shape error in the available numeric function. This does not establish how the absent `QuantumAI` implementation would interpret an operator.
- With no gates, the initial state is omitted and the returned list is empty.
- The predicate filter preserves selected object references and duplicates. With explicitly fixed random draws 0.25, 0.5 and 0.75 at threshold 0.5, only the first decision receives the fixed 0.08 perturbation, producing `[1.08,2,3]`.

“Pass” means these disclosed observations agree with the implemented semantics, including its limitations. It does not validate physical energy, ethical decision-making, quantum measurement, an integrated architecture or the missing dependencies. No pipeline, original test suite, key generation, network operation or missing-component substitute was executed.

`SOURCE_REVIEW.md` and `OBSERVATION_PREPARATION.json` remain unchanged historical records of the review and plan saved before execution. This result updates the work state to **executed and reviewed**. `OBSERVATION_VERIFICATION.json` checks all 19 prepared member identities and records the actual result and this interpretation using SGL Prime profile 3. These are byte-consistency records, not independent ownership or authorship authentication.
