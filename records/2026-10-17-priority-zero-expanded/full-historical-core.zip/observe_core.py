"""Observe three preserved historical functions on eight fixed small cases.

Prepared for source review; run once only after the coordinator grants a slot.
No missing project component is imported or replaced. The child has an
eight-second timeout; parent source readback and result saving are separate.
"""
from __future__ import annotations

import argparse
import ast
from datetime import datetime, timezone
import json
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
SOURCE = HERE / "source"
TIMEOUT_SECONDS = 8


def load_definition(relative_path, function_name, namespace):
    path = SOURCE / relative_path
    data = path.read_bytes()
    if len(data) > 4096:
        raise ValueError("Unexpectedly large historical function source")
    parsed = ast.parse(data.decode("utf-8"), filename=str(path))
    matches = [node for node in parsed.body
               if isinstance(node, ast.FunctionDef) and node.name == function_name]
    if len(matches) != 1:
        raise ValueError("Expected one reviewed function definition")
    # Execute the actual retained definition, without executing file imports,
    # package initializers, other functions, or any project pipeline.
    selected = ast.Module(body=matches, type_ignores=[])
    exec(compile(selected, str(path), "exec"), namespace)
    return namespace[function_name]


class FixedRandom:
    """Disclosed branch inputs, not sampled randomness or a project module."""
    def __init__(self):
        self.draws = iter((0.25, 0.5, 0.75))
        self.random_calls = 0
        self.uniform_bounds = []

    def random(self):
        self.random_calls += 1
        return next(self.draws)

    def uniform(self, low, high):
        self.uniform_bounds.append([low, high])
        if [low, high] != [-0.1, 0.1] or len(self.uniform_bounds) != 1:
            raise AssertionError("Unexpected uniform draw")
        return 0.08


def child_observations():
    result = {"status": "IN_PROGRESS", "observations": [],
              "scope": "Eight fixed observations of three available functions; no pipeline or missing module execution"}
    try:
        import numpy as np
    except ImportError as exc:
        result.update(status="DEPENDENCY_UNAVAILABLE", error=str(exc))
        return result
    result["numpy_version"] = np.__version__
    dynamics = load_definition("quantum-core/src/sherman_g_laing_dynamics.py",
                               "sherman_g_laing_dynamics", {"np": np})
    observer = load_definition("quantum-core/src/observer_effect.py", "observer_effect", {})
    fixed_random = FixedRandom()
    guidance = load_definition("quantum-core/src/divine_guidance.py",
                              "divine_guidance", {"random": fixed_random})

    def vector(value):
        return [[float(x.real), float(x.imag)] for x in np.asarray(value).ravel()]

    def record(name, passed, **detail):
        result["observations"].append({"name": name, "pass": bool(passed), **detail})

    initial = np.array([1, 0], dtype=complex)
    identity = np.eye(2, dtype=complex)
    swap = np.array([[0, 1], [1, 0]], dtype=complex)

    at_boundary = dynamics(initial, [swap], energy_threshold=1.0)
    above_boundary = dynamics(initial, [swap], energy_threshold=1.000000001)
    record("inclusive_norm_threshold",
           len(at_boundary) == 1 and len(above_boundary) == 0
           and np.array_equal(at_boundary[0], [0, 1]),
           threshold_one_count=len(at_boundary), threshold_above_one_count=len(above_boundary),
           boundary_state=vector(at_boundary[0]) if at_boundary else None)

    propagated = dynamics(initial, [0.5 * identity, 2 * swap], energy_threshold=0.5)
    record("filtered_step_still_propagates",
           len(propagated) == 1 and np.array_equal(propagated[0], [0, 1]),
           first_step_squared_norm_expected=0.25, returned_count=len(propagated),
           returned_states=[vector(v) for v in propagated])

    amplified = dynamics(initial, [2 * identity], energy_threshold=0.5)
    record("nonunitary_scale_is_not_normalized",
           len(amplified) == 1 and np.array_equal(amplified[0], [2, 0]),
           returned_states=[vector(v) for v in amplified],
           squared_norm=float(np.sum(np.abs(amplified[0]) ** 2)) if amplified else None)

    balanced = np.array([1, 1], dtype=complex) / np.sqrt(2)
    phased = dynamics(balanced, [np.diag([1j, 1])], energy_threshold=0.5)
    expected_phase = np.array([1j, 1], dtype=complex) / np.sqrt(2)
    phase_norm = float(np.sum(np.abs(phased[0]) ** 2)) if phased else None
    record("complex_unitary_example",
           len(phased) == 1 and np.allclose(phased[0], expected_phase, rtol=0, atol=1e-12)
           and abs(phase_norm - 1) <= 1e-12,
           returned_states=[vector(v) for v in phased], squared_norm=phase_norm,
           absolute_tolerance=1e-12)

    mismatch = None
    try:
        dynamics(np.array([1, 0, 0, 0], dtype=complex), [swap])
    except ValueError as exc:
        mismatch = str(exc)
    record("available_numeric_function_rejects_2_by_2_on_length_4", mismatch is not None,
           observed_error=mismatch,
           scope="NumPy dot in the available function only; unknown QuantumAI contract is not tested")

    no_gates = dynamics(initial, [])
    record("initial_state_is_not_returned_without_gates", no_gates == [], result_count=len(no_gates))

    selected = {"particle": 1, "tag": "selected"}
    excluded = {"particle": 0, "tag": "excluded"}
    records = [selected, excluded, selected]
    filtered = observer(records, lambda entry: entry["particle"] == 1)
    record("predicate_filter_preserves_order_duplicates_and_references",
           len(filtered) == 2 and filtered[0] is selected and filtered[1] is selected
           and len(records) == 3,
           selected_tags=[entry["tag"] for entry in filtered],
           both_entries_are_original_object=len(filtered) == 2 and all(entry is selected for entry in filtered))

    decisions = [1, 2, 3]
    guided = guidance(decisions, holy_spirit=0.5)
    record("explicit_random_branch_observation",
           guided == [1.08, 2, 3] and decisions == [1, 2, 3]
           and fixed_random.random_calls == 3 and fixed_random.uniform_bounds == [[-0.1, 0.1]],
           fixed_random_draws=[0.25, 0.5, 0.75], fixed_uniform_value=0.08,
           threshold=0.5, result=guided, original_input=decisions,
           random_call_count=fixed_random.random_calls, uniform_bounds=fixed_random.uniform_bounds)

    result["preserved_function_calls"] = 9
    result["failed_observations"] = [row["name"] for row in result["observations"] if not row["pass"]]
    result["status"] = "PASS" if len(result["observations"]) == 8 and not result["failed_observations"] else "FAIL"
    return result


def source_snapshot():
    capture = json.loads((HERE / "SOURCE_CAPTURE.json").read_text(encoding="utf-8"))
    if len(capture["sources"]) != 15:
        raise ValueError("Expected the reviewed 15-file source capture")
    saved = {}
    for entry in capture["sources"]:
        path = HERE / entry["localPath"]
        if path.is_symlink():
            raise ValueError("Unexpected source symlink")
        path.resolve().relative_to(SOURCE.resolve())
        data = path.read_bytes()
        if len(data) != entry["bytes"] or len(data) > 4096 or path in saved:
            raise ValueError("Source size or duplicate path differs from capture")
        saved[path] = data
    if sum(map(len, saved.values())) != 8767:
        raise ValueError("Unexpected source byte population")
    return saved


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--worker", action="store_true", help=argparse.SUPPRESS)
    args = parser.parse_args()
    if args.worker:
        try:
            result = child_observations()
        except Exception as exc:
            result = {"status": "ERROR", "error_type": type(exc).__name__, "error": str(exc)}
        print(json.dumps(result, allow_nan=False))
        return 0 if result["status"] == "PASS" else 1
    if args.out is None or args.out.exists():
        parser.error("Supply a new --out path; existing results are never overwritten")
    started = datetime.now(timezone.utc).isoformat()
    tick = time.perf_counter()
    sources = source_snapshot()
    record = {"schema": "qel-historical-core-observations/1", "startedAtUTC": started,
              "childTimeoutSeconds": TIMEOUT_SECONDS, "sourceFiles": 15, "sourceBytes": 8767}
    try:
        child = subprocess.run([sys.executable, "-B", str(Path(__file__).resolve()), "--worker"],
                               capture_output=True, text=True, timeout=TIMEOUT_SECONDS)
        record["observed"] = json.loads(child.stdout)
        record["childExitCode"] = child.returncode
        record["status"] = record["observed"]["status"]
        if child.returncode != 0 and record["status"] == "PASS":
            record["status"] = "ERROR"
        if child.stderr:
            record["childStderr"] = child.stderr[:4000]
    except subprocess.TimeoutExpired:
        record["status"] = "TIMEOUT"
        record["observationComplete"] = False
    except Exception as exc:
        record.update(status="ERROR", error_type=type(exc).__name__, error=str(exc))
    record["preservedSourcesUnchanged"] = all(path.read_bytes() == body for path, body in sources.items())
    if not record["preservedSourcesUnchanged"]:
        record["status"] = "FAIL_SOURCE_CHANGE"
    record["elapsedBeforeResultSaveSeconds"] = time.perf_counter() - tick
    record["completedAtUTC"] = datetime.now(timezone.utc).isoformat()
    record["executionBoundary"] = "Only three reviewed retained function definitions; explicit mock randomness; no QuantumAI, pipeline, multi-agent, encryption, network, or original test-suite execution"
    serialized = json.dumps(record, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    with args.out.open("x", encoding="utf-8", newline="\n") as output:
        output.write(serialized)
    if args.out.read_text(encoding="utf-8") != serialized:
        raise RuntimeError("Saved result readback differs")
    print(json.dumps({"status": record["status"], "elapsedBeforeResultSaveSeconds": record["elapsedBeforeResultSaveSeconds"],
                      "preservedSourcesUnchanged": record["preservedSourcesUnchanged"]}))
    return 0 if record["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
