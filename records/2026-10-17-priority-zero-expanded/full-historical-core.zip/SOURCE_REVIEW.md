# Historical core — source review and bounded observation plan

All 15 retained source files (8,767 bytes), `SOURCE_CAPTURE.json` and `DEPENDENCY_ROUTES.json` were read on October 14, 2026. The review covers the saved latest snapshots of `XvXvi4/quantum-core` at `9765fb94ed08ec7f3ab18153e3cecd9e1c104c98` and `XvXvi4/quantum-earth-systems-architecture` at `34f4686c8d6c4c4aaa7f0c033d8701a8d626997d`. Their inherited Git identifiers remain provenance metadata. No old package, tests, pipeline or observation script has been executed for this review.

## Implemented behavior

| Retained source | Exact implemented behavior and limits |
|---|---|
| `quantum-core/src/sherman_g_laing_dynamics.py:3` | Repeatedly applies `np.dot(gate,current_state)`, computes the sum of squared absolute entries, and returns each resulting state whose value is at least `energy_threshold`. Line 11 updates the current state regardless of whether line 10 retained it. The initial state is never included automatically. |
| `quantum-core/src/divine_guidance.py:3` | For each numeric decision, one random draw below the supplied parameter selects addition of a uniform perturbation between −0.1 and 0.1. Equality at the branch threshold takes the unchanged branch. There is no ethical criterion, objective function, probability validation or output-range clipping in this function. The repository's religious naming is retained as attribution, not treated as a measured property. |
| `quantum-core/src/observer_effect.py:1` | A list comprehension selects entries for which the caller's predicate is true. Order, duplicates and object references are retained. No measurement probabilities, state collapse, renormalization or copy operation is implemented. |
| `quantum-earth-systems-architecture/src/node_controller.py:3` | Instantiates `PipelineManager`; `start` prints a message and invokes its pipeline once. No event loop, network synchronization or autonomous-node behavior appears in this body. |
| `quantum-earth-systems-architecture/src/pipeline_manager.py:5` | Constructs three imported components. Its run method applies a literal 2×2 operator to the quantum component, calls measurement and prints the result. It does not use the constructed multi-agent object or keys after initialization, and contains no API/IoT ingestion or encryption of data. |

For a vector, the dynamics quantity called `energy` is its squared Euclidean norm. There is no Hamiltonian or state-dependent physical energy definition. A normalized vector evolved by unitary matrices keeps norm one, so a threshold at or below one retains every step; a threshold above one retains none, apart from numerical tolerance effects. The code neither checks unitarity nor enforces normalization. A scaling matrix can yield norm greater than one and be retained. Matrix-valued input is not rejected explicitly; the sum then measures squared absolute entries of that array, not necessarily the intended vector-state quantity. Shape errors are delegated to NumPy.

## Dependencies, dimensions and original tests

The core README lists `src/quantum_ai.py`, but that body is absent from the captured source tree. Its test file imports `src.quantum_ai.QuantumAI` before defining any test. The architecture additionally imports `intelligence_core.multiagent.MultiAgentSystem` and `encryption_core.encryption_protocols.generate_rsa_keys`; none of their implementations is among these captures. The stored searches return references to those names, not implementations. This establishes a dependency gap in the inspected material, not absence from every possible source or installed environment.

There is also a packaging mismatch to resolve: the core tests use `src.*`, while the architecture expects `quantum_core.*`; the captures contain no distribution configuration binding them. The only retained requirements file lists NumPy without a version pin. Architecture initialization requests `QuantumAI(state_dim=4)` and then passes a 2×2 matrix (`pipeline_manager.py:7,14`). Under an ordinary four-entry state-vector contract that matrix cannot act directly. Because `QuantumAI` is missing, its actual dimensional convention, possible embedding and validation behavior remain unknown. This is a conditional integration concern, not an executed pipeline failure.

The four core tests check an initialization value for the missing class, one retained-state count for an X gate, output length for random perturbations and one filtered-list length. They do not establish normalization, threshold semantics, branch behavior, quantum measurement or physical interpretation. The architecture's three tests check non-null fields and whether a run raises an exception; they do not check its numerical output, communication or encryption. The missing imports prevent treating these retained tests as a self-contained runnable integration suite. No substitute components will be supplied to manufacture a passing result.

## Proposed observations — prepared, not executed

`observe_core.py` extracts only the three reviewed function definitions from their saved syntax trees. It supplies bundled NumPy to the dynamics definition and an explicit deterministic random object to the perturbation definition. This mock controls the two named random methods; it is not a replacement for a missing project module. Bundled NumPy's package file was observed locally; import and version will be recorded only when execution is authorized.

The eight observations use nine preserved-function calls: inclusive norm threshold; propagation after a filtered step; acceptance of a nonunitary scale; preservation of a complex unitary example's norm; a local shape mismatch; the empty-gate result; predicate selection with retained references; and explicit random-branch selection at/below/above the cutoff. They target distinct semantics instead of repeating inputs to inflate counts. The dimension observation concerns only the available numeric function and does not execute or reconstruct `QuantumAI`.

The supervisor allows at most eight seconds for its child process, retains a timeout/error result if necessary, records elapsed time and checks that all 15 preserved source files remain byte-identical. The small parent readback/save overhead is outside that child timeout; this is not a benchmark. It creates a new result exclusively. No installation, network access, key generation, missing dependency imports or upstream test-suite execution is planned. Source review and a coordinator execution slot are required before the one run.

## Attribution and remaining scope

Both latest licenses name Sherman G. Laing and carry a 2024 copyright notice. The retained initial quantum-core commit, dated December 19, 2024 at 17:52:16 UTC, contains only a README and an MIT license with the name spelling `Sherman G laing`. The later proprietary license and older initial notice are distinct source records; this review draws no legal conclusion and does not infer that the later function bodies were in the initial commit. The historical bodies, new observation harness and this interpretation remain separate.

These snapshots add concrete recoverable source to the record. They do not recover the 2026 SAT implementation, five-problem manuscripts, v2.4 integration archive or latest Run14 application, and do not establish outside use, ownership authentication or compensation.
