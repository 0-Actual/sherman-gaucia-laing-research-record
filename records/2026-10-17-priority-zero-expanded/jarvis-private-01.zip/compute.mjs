// Private JARVIS numerical work for Sherman G. Laing. GAUCIA, AI-assisted implementation.
// Independent classical controls plus actual calls to the unchanged Q8 circuit engine.
import { circuit } from './vendor/quantum.mjs';
export const add=(a,b)=>[a[0]+b[0],a[1]+b[1]];
export const mul=(a,b)=>[a[0]*b[0]-a[1]*b[1],a[0]*b[1]+a[1]*b[0]];
export const conj=a=>[a[0],-a[1]];
const mag=a=>Math.hypot(a[0],a[1]);
const check=(v,m)=>{if(!v)throw Error(m);};
const zeros=n=>Array.from({length:n},()=>[0,0]);
export function validateH(h,tol=1e-12){
 check(Array.isArray(h)&&h.length===8&&h.every(r=>Array.isArray(r)&&r.length===8),'Hamiltonian must be 8x8');
 let defect=0;
 for(let i=0;i<8;i++)for(let j=0;j<8;j++){
  const z=h[i][j];check(Array.isArray(z)&&z.length===2&&z.every(Number.isFinite),'Nonfinite complex Hamiltonian');
  defect=Math.max(defect,mag(add(z,[-h[j][i][0],h[j][i][1]])));
 }check(defect<=tol,'Hamiltonian is not Hermitian');return defect;
}
export function parseWannier(text){
 const lines=text.trimEnd().split(/\r?\n/);check(+lines[1]===8&&+lines[2]===1041,'Wrong Wannier dimensions');
 const n=8,nr=1041,count=Math.ceil(nr/15),degens=lines.slice(3,3+count).join(' ').trim().split(/\s+/).map(Number);
 check(degens.length===nr&&degens.every(d=>Number.isInteger(d)&&d>0),'Invalid degeneracies');
 const entries=lines.slice(3+count);check(entries.length===nr*n*n,'Wrong entry count');
 const blocks=[],seenR=new Set();
 for(let b=0;b<nr;b++){
  let R=null;const h=Array.from({length:n},()=>zeros(n)),seen=new Set();
  for(let i=0;i<n*n;i++){
   const f=entries[b*n*n+i].trim().split(/\s+/).map(Number);check(f.length===7&&f.every(Number.isFinite),'Invalid Wannier row');
   const r=f.slice(0,3);check(r.every(Number.isInteger),'Invalid lattice vector');
   if(R===null)R=r;check(r.every((v,k)=>v===R[k]),'Mixed lattice blocks');
   const a=f[3]-1,c=f[4]-1;check(Number.isInteger(a)&&Number.isInteger(c)&&a>=0&&a<n&&c>=0&&c<n,'Invalid orbital index');
   const key=a*n+c;check(!seen.has(key),'Duplicate orbital pair');seen.add(key);
   h[a][c]=[f[5]/degens[b],f[6]/degens[b]];
  }
  const key=R.join(',');check(!seenR.has(key),'Duplicate lattice block');seenR.add(key);blocks.push({R,h});
 }return blocks;
}
export function constructH(blocks,k){
 check(Array.isArray(k)&&k.length===3&&k.every(Number.isFinite),'Invalid reciprocal point');
 const h=Array.from({length:8},()=>zeros(8));
 for(const {R,h:hr} of blocks){
  const a=2*Math.PI*R.reduce((s,r,j)=>s+r*k[j],0),phase=[Math.cos(a),Math.sin(a)];
  for(let i=0;i<8;i++)for(let j=0;j<8;j++)h[i][j]=add(h[i][j],mul(phase,hr[i][j]));
 }
 let rawDefect=0;for(let i=0;i<8;i++)for(let j=0;j<8;j++)rawDefect=Math.max(rawDefect,mag(add(h[i][j],[-h[j][i][0],h[j][i][1]])));
 const projected=h.map((r,i)=>r.map((z,j)=>[(z[0]+h[j][i][0])/2,(z[1]-h[j][i][1])/2]));
 validateH(projected);return {h:projected,rawDefect};
}
export function jacobi(h){
 const n=h.length,N=2*n;
 const A=Array.from({length:N},(_,i)=>Array.from({length:N},(_,j)=>{
  const z=h[i%n][j%n];return i<n?(j<n?z[0]:-z[1]):(j<n?z[1]:z[0]);
 }));
 check(A.every((r,i)=>r.every((v,j)=>Number.isFinite(v)&&Math.abs(v-A[j][i])<=1e-12)),'Non-Hermitian eigensolver input');
 const original=A.map(r=>r.slice()),V=Array.from({length:N},(_,i)=>Array.from({length:N},(_,j)=>+(i===j)));
 let rotations=0,maxOff=0;
 for(;rotations<20000;rotations++){
  let p=0,q=1;maxOff=0;
  for(let i=0;i<N;i++)for(let j=i+1;j<N;j++)if(Math.abs(A[i][j])>maxOff){maxOff=Math.abs(A[i][j]);p=i;q=j;}
  if(maxOff<=1e-13)break;
  const ap=A[p][p],aq=A[q][q],off=A[p][q],tau=(aq-ap)/(2*off);
  const t=(tau<0?-1:1)/(Math.abs(tau)+Math.hypot(1,tau)),c=1/Math.hypot(1,t),s=t*c;
  for(let k=0;k<N;k++)if(k!==p&&k!==q){
   const kp=A[k][p],kq=A[k][q];A[k][p]=A[p][k]=c*kp-s*kq;A[k][q]=A[q][k]=s*kp+c*kq;
  }
  A[p][p]=ap-t*off;A[q][q]=aq+t*off;A[p][q]=A[q][p]=0;
  for(let k=0;k<N;k++){const vp=V[k][p],vq=V[k][q];V[k][p]=c*vp-s*vq;V[k][q]=s*vp+c*vq;}
 }
 check(rotations<20000,'Jacobi convergence failure');
 const order=Array.from({length:N},(_,i)=>i).sort((i,j)=>A[i][i]-A[j][j]);
 const eigenvalues=[],realEigenvalues=order.map(i=>A[i][i]);let pairSpread=0,residual=0,orthogonality=0;
 for(let i=0;i<N;i+=2){pairSpread=Math.max(pairSpread,Math.abs(realEigenvalues[i]-realEigenvalues[i+1]));eigenvalues.push((realEigenvalues[i]+realEigenvalues[i+1])/2);}
 for(let j=0;j<N;j++){
  let r2=0;
  for(let i=0;i<N;i++){let z=-A[j][j]*V[i][j];for(let k=0;k<N;k++)z+=original[i][k]*V[k][j];r2+=z*z;}
  residual=Math.max(residual,Math.sqrt(r2));
  for(let l=0;l<N;l++){let dot=0;for(let k=0;k<N;k++)dot+=V[k][j]*V[k][l];orthogonality=Math.max(orthogonality,Math.abs(dot-+(j===l)));}
 }
 let trace=0;for(let i=0;i<n;i++)trace+=h[i][i][0];
 return {eigenvalues,residual,orthogonality,pairSpread,traceError:Math.abs(trace-eigenvalues.reduce((a,b)=>a+b,0)),rotations,maxOff};
}
export function dense(n,gates,initialIndex=0){
 let state=Array.from({length:2**n},(_,i)=>[+(i===initialIndex),0]);
 for(const g of gates){
  if(g.kind==='CNOT'){
   const cm=1<<(n-1-g.c),tm=1<<(n-1-g.t),next=zeros(state.length);
   for(let i=0;i<state.length;i++)next[i&cm?i^tm:i]=state[i].slice();state=next;continue;
  }
  let m;const c=Math.cos((g.angle||0)/2),s=Math.sin((g.angle||0)/2),a=Math.SQRT1_2;
  if(g.kind==='RY')m=[[[c,0],[-s,0]],[[s,0],[c,0]]];
  else if(g.kind==='RZ')m=[[[c,-s],[0,0]],[[0,0],[c,s]]];
  else if(g.kind==='H')m=[[[a,0],[a,0]],[[a,0],[-a,0]]];
  else throw Error('Unsupported independent dense gate');
  const mask=1<<(n-1-g.q),next=state.map(z=>z.slice());
  for(let i=0;i<state.length;i++)if(!(i&mask)){
   const j=i|mask;next[i]=add(mul(m[0][0],state[i]),mul(m[0][1],state[j]));next[j]=add(mul(m[1][0],state[i]),mul(m[1][1],state[j]));
  }state=next;
 }return state;
}
export function ansatz(theta){
 check(theta.length===18&&theta.every(Number.isFinite),'18 angles required');
 const gates=[];let p=0;
 for(let layer=0;layer<3;layer++){
  for(let q=0;q<3;q++){gates.push({kind:'RY',q,angle:theta[p++]});gates.push({kind:'RZ',q,angle:theta[p++]});}
  if(layer===0)gates.push({kind:'CNOT',c:0,t:1},{kind:'CNOT',c:1,t:2});
  if(layer===1)gates.push({kind:'CNOT',c:0,t:2},{kind:'CNOT',c:2,t:1});
 }return gates;
}
const probes=Array.from({length:8},(_,i)=>i.toString(2).padStart(3,'0'));
export function actualState(gates){
 const result=circuit({n:3,gates,probes});return {state:result.outcomes.map(o=>o.amplitude),storage:result.storage};
}
export function energy(h,state){
 let er=0,ei=0;
 for(let i=0;i<8;i++){
  let hr=0,hi=0;for(let j=0;j<8;j++){hr+=h[i][j][0]*state[j][0]-h[i][j][1]*state[j][1];hi+=h[i][j][0]*state[j][1]+h[i][j][1]*state[j][0];}
  er+=state[i][0]*hr+state[i][1]*hi;ei+=state[i][0]*hi-state[i][1]*hr;
 }check(Number.isFinite(er)&&Math.abs(ei)<1e-9,'Invalid expectation');return er;
}
export function independentEnergy(h,state){
 let total=[0,0];for(let i=0;i<8;i++)for(let j=0;j<8;j++)total=add(total,mul(mul(conj(state[i]),h[i][j]),state[j]));return total[0];
}
export function rng(seed){let x=seed>>>0;return ()=>{x^=x<<13;x^=x>>>17;x^=x<<5;return (x>>>0)/4294967296;};}
export function circuitChecks(h,seed){
 validateH(h);const rand=rng(seed),out=[];
 for(let c=0;c<3;c++){
  const angles=Array.from({length:18},()=>2*Math.PI*rand()-Math.PI);
  const gates=c===0?[{kind:'H',q:0},{kind:'H',q:1},{kind:'H',q:2}]:ansatz(angles);
  const actual=actualState(gates),expected=dense(3,gates),amplitudeError=Math.max(...actual.state.map((z,j)=>mag(add(z,[-expected[j][0],-expected[j][1]]))));
  const E=energy(h,actual.state),reference=independentEnergy(h,expected),norm=actual.state.reduce((s,z)=>s+z[0]*z[0]+z[1]*z[1],0);
  out.push({case:c,gates,amplitudes:actual.state,energy_ev:E,dense_energy_ev:reference,energy_error_ev:Math.abs(E-reference),max_amplitude_error:amplitudeError,norm,storage:actual.storage});
 }return out;
}
export function optimize(h,config,seed){
 validateH(h);const random=rng(seed),starts=[];let chosen=null,totalEvaluations=0;
 for(let start=0;start<config.starts;start++){
  let theta=Array.from({length:18},()=>2*Math.PI*random()-Math.PI),evaluations=0;
  const objective=t=>{evaluations++;return energy(h,actualState(ansatz(t)).state);};
  const initial=objective(theta),history=[];let best=initial;
  for(let sweep=0;sweep<config.max_sweeps;sweep++){
   const before=best;
   for(let j=0;j<18;j++){
    const origin=theta[j],center=objective(theta);
    theta[j]=origin+Math.PI/2;const plus=objective(theta);
    theta[j]=origin-Math.PI/2;const minus=objective(theta);
    const offset=(plus+minus)/2,a=center-offset,b=(plus-minus)/2;
    theta[j]=origin+Math.atan2(b,a)+Math.PI;
    const candidate=objective(theta);
    if(candidate>center+1e-11)theta[j]=origin;
   }
   best=objective(theta);history.push({sweep:sweep+1,energy_ev:best,improvement_ev:before-best});
   if(before-best<config.early_stop_improvement_ev)break;
  }
  const state=actualState(ansatz(theta)),reference=dense(3,ansatz(theta));
  const record={start,initial_energy_ev:initial,final_energy_ev:best,improvement_ev:initial-best,parameters:theta,amplitudes:state.state,history,evaluations,storage:state.storage,max_amplitude_error:Math.max(...state.state.map((z,i)=>mag(add(z,[-reference[i][0],-reference[i][1]])))),dense_energy_error_ev:Math.abs(best-independentEnergy(h,reference))};
  starts.push(record);totalEvaluations+=evaluations;if(chosen===null||best<chosen.final_energy_ev)chosen=record;
 }
 return {starts,best_start:chosen.start,final_energy_ev:chosen.final_energy_ev,total_evaluations:totalEvaluations};
}
export function controls(){
 const results=[];
 const h2=[[[2,0],[0,1]],[[0,-1],[2,0]]],r=jacobi(h2);
 results.push({id:'complex_2x2',expected:[1,3],actual:r.eigenvalues,error:Math.max(Math.abs(r.eigenvalues[0]-1),Math.abs(r.eigenvalues[1]-3)),residual:r.residual});
 const theta=Array.from({length:18},(_,i)=>0.17*(i+1)),gates=ansatz(theta),columns=Array.from({length:8},(_,j)=>dense(3,gates,j)),spectrum=[-3,-3,-1,0,0.25,2,7,9];
 const H=Array.from({length:8},(_,i)=>Array.from({length:8},(_,j)=>{let z=[0,0];for(let k=0;k<8;k++){const u=mul(columns[k][i],conj(columns[k][j]));z=add(z,[u[0]*spectrum[k],u[1]*spectrum[k]]);}return z;}));
 const s=jacobi(H);results.push({id:'known_complex_rotated_spectrum',expected:spectrum,actual:s.eigenvalues,error:Math.max(...spectrum.map((x,i)=>Math.abs(x-s.eigenvalues[i]))),residual:s.residual});
 const variants=[[],H.map(r=>r.map(z=>z.slice())),H.map(r=>r.map(z=>z.slice()))];
 variants[1][0][0][0]=NaN;variants[2][0][1][0]+=1;
 for(let i=0;i<variants.length;i++){let rejected=false;try{validateH(variants[i]);}catch{rejected=true;}results.push({id:['shape_rejection','nonfinite_rejection','nonhermitian_rejection'][i],rejected});}
 const phaseA=dense(1,[{kind:'H',q:0},{kind:'RZ',q:0,angle:Math.PI/2}]);
 const phaseB=dense(1,[{kind:'H',q:0},{kind:'RZ',q:0,angle:-Math.PI/2}]);
 results.push({id:'phase_sensitive_comparison',amplitude_difference:Math.max(...phaseA.map((z,i)=>mag(add(z,[-phaseB[i][0],-phaseB[i][1]])))),same_probabilities:phaseA.every((z,i)=>Math.abs(mag(z)**2-mag(phaseB[i])**2)<1e-12)});
 return results;
}
