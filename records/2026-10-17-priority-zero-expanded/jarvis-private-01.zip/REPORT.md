# Private JARVIS / Q8 laptop benchmark

Owner and project principal: **Sherman G. Laing — Quantum.Earth.Laing**  
Work performed by: **GAUCIA, AI-assisted implementation and review**  
State: **PRIVATE / COMPLETED WITH STATED LIMITS / UNSIGNED / NO PUBLICATION**  
Recorded execution date: 20 September 2026. Exact UTC times are in each execution record.

## Result

The current Q8 circuit engine was exercised on the actual laptop against JARVIS aluminum Hamiltonians. All 90 complex-state and energy cases passed their predeclared numerical tolerances. A separately identified classical reference reproduced all 192 published aluminum band values within the existing private tolerance. Two subsequent complete executions reproduced all 17 deterministic result files exactly.

The initial variational optimization met its ground-energy goal in five of six cases. The remaining original benchmark point improved after two bounded follow-ups, but still missed the unchanged goal. This is a completed experiment with one unresolved optimization target; it is not an all-targets-passed result.

The archived Python ground-energy implementation was recovered and inspected, but a usable Python runtime was not found in the searched laptop/USB locations. That older route was not executed. No Python implementation was silently replaced and presented as the original.

## What actually ran

| Component | Actual role |
|---|---|
| Preserved current Q8 quantum.mjs and qel60_sop.mjs | Prepared the three-qubit circuit states through the existing circuit() / SOP implementation. Both source files were copied unchanged. |
| New compute.mjs | Parsed the original Wannier input, constructed Hamiltonians, evaluated energies, and optimized circuit parameters using Q8-produced states. |
| Independent dense gate application | Compared all eight complex amplitudes and independently evaluated the same expectation values. It does not call the SOP implementation. |
| Independent realified Jacobi eigensolver | Produced full-spectrum classical control values and ground-energy references. This is new control code, not the archived QEL Python solver. |
| Archived Python source | Preserved for provenance and future deployment; not executed in this cycle. |
| runner.mjs and launch.mjs | Applied bounded execution, restricted filesystem access, stage logging, paired saves, and resource measurements. |

The full-spectrum control and the Q8 circuit implementation have different roles. The control calculates eigenvalues. Q8 supplies the simulated circuit amplitudes used in the energy and variational calculations. Numerical agreement is evidence for these stated calculations.

## Inputs and definitions

The source material is aluminum, JVASP-816. The preserved original archive contains an eight-orbital Wannier Hamiltonian with 1,041 lattice-vector blocks and 66,624 complex entries.

Each block is divided by its positive degeneracy. The matrix at reciprocal point k is the sum of those blocks multiplied by exp(+2 pi i R dot k), followed by (H + H-dagger)/2. Entries are in electronvolts. The original orbital order, the 24-point path order, its duplicate endpoints, and zero Fermi shift are retained.

The 8-dimensional orbital problem is represented by three simulated qubits, with q0 the most significant bit. This encoding does not turn eight orbitals into eight physical qubits.

Six additional reciprocal points were fixed in CONTRACT.json before execution. They come from the same aluminum input. They provide new numerical cases for this cycle, not unseen materials, an official held-out competition split, or evidence that a trained model generalizes to other materials.

Predictions were saved before the answer files were parsed in each execution. The historical reference values had been reviewed in earlier work, so the experiment is not claimed to be blind.

## Measured numerical results

| Measurement | Result | Fixed acceptance condition |
|---|---:|---:|
| Original path | 24 matrices / 192 eigenvalues | Preserve every ordered value |
| Additional same-material points | 6 matrices / 48 control eigenvalues | Separate from official scoring |
| Analytical and rejection controls | 6 passed | All controls satisfy their stated conditions |
| Original-input reconstruction, maximum entry difference | 2.220446049250313e-16 eV | <= 1e-10 eV |
| Classical control versus official rounded targets, MAE | 2.3408413332703937e-9 eV | <= 1e-4 eV |
| Classical control versus official targets, maximum error | 4.949916032614965e-9 eV | Reported separately from MAE |
| Classical control versus preserved NumPy values, maximum error | 1.7763568394002505e-14 eV | <= 1e-9 eV |
| Maximum eigenpair residual across 30 matrices | 1.1039639991169238e-13 eV | <= 1e-9 eV |
| Q8 circuit/energy cases | 90 / 90 passed | Three state preparations per matrix |
| Maximum complete complex-amplitude difference | 3.7238012298709097e-16 | <= 2e-10 |
| Maximum energy-expectation difference | 1.0658141036401503e-14 eV | <= 1e-9 eV |

The small discrepancy against official targets is consistent with their rounded values; the separately preserved NumPy comparison is much closer. These tolerances are private engineering criteria, not certification by NIST.

Checks include complex phase, normalization, Hermiticity, finite values, eigensolver residuals, orthogonality, duplicate realification eigenvalue pairing, and trace consistency. Negative controls reject malformed, nonfinite, and non-Hermitian input. The phase control distinguishes states that have equal probabilities but different complex amplitudes.

## Variational optimization and the unresolved case

The ansatz contains 18 RY/RZ parameters in three local rotation layers, with two CNOT gates after each of the first two layers. The original Q8 branch cap is retained.

Each energy evaluation uses the actual Q8 circuit output. For a single angle, the energy has sinusoidal form c + a cos(theta) + b sin(theta). Three evaluations determine the sinusoid and the coordinate minimizer; the candidate is then checked before admission. The optimizer receives the Hamiltonian, not the ground-energy target.

The initial contract used two seeded starts and at most 12 sweeps. Every case reduced energy, respected the variational lower bound within tolerance, and agreed with independent dense evaluation.

| Hamiltonian index | Scope | Initial-cycle ground-energy gap (eV) | Goal <= 0.0001 eV |
|---|---|---:|---|
| 1 | Original path | 0.0000023940295506008624 | Pass |
| 4 | Original path | 0.0004007142024144983 | Miss |
| 8 | Original path | 0.00000026920386142492703 | Pass |
| 24 | New same-material point | 0.00000008563554576568322 | Pass |
| 26 | New same-material point | 0.00000001210944544638437 | Pass |
| 28 | New same-material point | 0.0000002277081067730835 | Pass |

For original point 4, a separately declared follow-up with four starts and 64 sweeps reduced the gap to 0.00014289359835650828 eV. A second bounded follow-up with four starts and 256 sweeps reduced it to 0.00012074495903213744 eV.

The final gap is 69.8676% below the initial gap, an improvement factor of approximately 3.3187. It remains above 0.0001 eV. The target was not relaxed. Initial and intermediate results remain intact.

Both follow-ups were adaptive work on an already examined original point; they are not new held-out tests. The remaining cause—optimization landscape, ansatz expressivity, or another numerical limitation—has not been isolated. More iteration alone has not established that this ansatz reaches the target. The next focused investigation should examine that distinction.

This trained circuit parameters for individual Hamiltonians. It did not train or update the GAUCIA language-model weights.

## Actual laptop resources and repeatability

The computer was REDACTED_DEVICE, Windows x64, Intel Celeron N4120 at its reported 1.10 GHz model frequency, using Node.js v24.20.0. No performance was inferred from the hosted Python runs preserved in the earlier record.

| Complete cycle | Recorded runner elapsed time | Sampled maximum resident memory |
|---|---:|---:|
| run_01 | 7.2546455 seconds | 96.94921875 MiB |
| run_02 | 7.0661605 seconds | 96.54296875 MiB |

These times include this runner's numerical work and evidence operations, exclude process startup, and are not comparable directly with the earlier Python reference's smaller workload. Memory includes Node overhead; the sampled maximum is not continuous monitoring. Full CPU and resource counters are preserved in execution.json.

The first replay matched all 17 deterministic JSON files byte-for-byte. A further run from freshly copied working folders, invoked by replay-new.mjs, also matched all 17 files. Timing, PID, and event records are retained separately and intentionally differ.

The two adaptive follow-ups were each executed once. No separate deterministic replay claim is made for those follow-up results.

## Privacy, integrity, and deployment limits

All new work is in the dedicated laptop and USB folders. No public repository action, submission, upload to another model provider, language-service restart, or change to existing Q8 source was performed. Existing jobs were not stopped.

The numerical child used the Node permission model, bounded heap settings, and below-normal scheduling priority. Its VM module imports were restricted to the inspected local computation and existing Q8 source. Process, require, fetch, and WebSocket bindings were absent from that computation context; string and WebAssembly code generation were disabled. No network operation was included in the reviewed computation.

These controls do not establish whole-operating-system network isolation or a security boundary against arbitrary hostile code. No firewall, administrator permission, or existing security policy was changed.

SGL Prime profile 3 content fingerprints identify the saved bytes. They are fingerprints, not owner signatures. Artifacts remain unsigned. Exclusive creation and retained attempts protect this workflow against accidental overwrite; no hardware write-once or forensic-vault guarantee is claimed.

The Python search covered the earlier executable lookup and the selected Codex, local application, USB, storage, and cache locations. Some unrelated protected Windows paths returned access denied. No permissions were bypassed. The result is "runtime not located in the searched locations," not proof that Python exists nowhere on the computer.

## Files and continuation

READ_FIRST.txt gives the shortest entry point. FINAL_STATUS.json records the final scoped result. START.json is the historical beginning of this cycle and is not the final status.

REPLAY_PRIVATE.cmd starts a fresh mirrored replay using the installed local Node runtime. It creates timestamped folders under replays and preserves existing results. Both saved locations must be available. It replays the initial benchmark, including the honestly retained 5/6 optimization outcome.

CONTRACT.json and the two FOLLOWUP contract files contain the fixed criteria and separately declared budget changes. run_01, run_02, followup_01, stage2_01, and replays retain raw predictions, metrics, execution details, and logs. SOURCE_COPIES.json maps preserved originals to working copies. MANIFEST.sgl.json and FINAL_VERIFY.json cover the saved snapshot.

Original JARVIS source and license notices are retained under provenance. The upstream context is the [JVASP-816 aluminum benchmark](https://pages.nist.gov/jarvis_leaderboard/QC/EigenSolver/dft_3d_electron_bands_JVASP_816_Al_WTBH/) and the [original Figshare dataset](https://doi.org/10.6084/m9.figshare.12473168.v1). This cycle used the previously saved inputs without downloading replacements.

No physical quantum hardware, quantum advantage, new material discovery, universal simulator validation, or public release is established by this cycle.
