// Private laptop runner. Sherman G. Laing / GAUCIA. No network imports or downloads.
import fs from 'node:fs';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {performance} from 'node:perf_hooks';
import {hashBytes,PROFILE} from './vendor/sgl-prime.mjs';
const root=path.dirname(fileURLToPath(import.meta.url));
const label=process.argv[2],mirror=process.argv[3];
if(!/^run_0[12]$/.test(label)||!mirror)throw Error('Expected run_01 or run_02 and an explicit mirror directory');
const dirs=[path.join(root,label),path.join(mirror,label)];
for(const d of dirs)fs.mkdirSync(d,{recursive:false});
const events=[],start=performance.now(),cpuStart=process.cpuUsage();
let sampledRss=process.memoryUsage().rss;
function save(name,obj){const bytes=Buffer.from(typeof obj==='string'?obj:JSON.stringify(obj,null,2)+'\n');for(const d of dirs){const p=path.join(d,name);fs.writeFileSync(p,bytes,{flag:'wx'});if(!bytes.equals(fs.readFileSync(p)))throw Error('Readback mismatch: '+p);}return bytes;}
function log(stage,detail={}){const e={at_utc:new Date().toISOString(),stage,...detail};events.push(e);for(const d of dirs)fs.appendFileSync(path.join(d,'events.ndjson'),JSON.stringify(e)+'\n');console.log(JSON.stringify(e));sampledRss=Math.max(sampledRss,process.memoryUsage().rss);}
function assert(x,message){if(!x)throw Error(message);}
try{
 const cfg=JSON.parse(fs.readFileSync(path.join(root,'CONTRACT.json'),'utf8'));save('contract.json',cfg);
 const sourceNames=['compute.mjs','runner.mjs','CONTRACT.json','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs','vendor/sgl-prime.mjs','inputs/wannier90_hr.dat','inputs/hamiltonians_24x8x8.json'];
 const identities=sourceNames.map(p=>({file:p,bytes:fs.statSync(path.join(root,p)).size,identity:hashBytes(fs.readFileSync(path.join(root,p)),'jarvis-source')}));
 save('source_identities.json',{profile:PROFILE,signature:'UNSIGNED',files:identities});
 log('start',{platform:process.platform,node:process.version,owner:cfg.owner,route:cfg.active_qel_route,private:true});
 const context=vm.createContext({}, {codeGeneration:{strings:false,wasm:false}});
 const cache=new Map(),allowed=new Set(['compute.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']);
 async function load(rel){
  if(!allowed.has(rel))throw Error('Module outside fixed allowlist: '+rel);
  if(cache.has(rel))return cache.get(rel);
  const module=new vm.SourceTextModule(fs.readFileSync(path.join(root,rel),'utf8'),{context,identifier:rel});
  cache.set(rel,module);
  await module.link((specifier,parent)=>{if(!specifier.startsWith('./'))throw Error('Only fixed local imports allowed');return load(path.posix.normalize(path.posix.join(path.posix.dirname(parent.identifier),specifier)));});
  return module;
 }
 const module=await load('compute.mjs');await module.evaluate({timeout:5000});const math=module.namespace;
 const unavailable=vm.runInContext("({process:typeof process,require:typeof require,fetch:typeof fetch,WebSocket:typeof WebSocket})",context);
 assert(Object.values(unavailable).every(v=>v==='undefined'),'Unexpected host or network binding');
 save('containment.json',{compute_bindings:unavailable,code_generation_disabled:true,local_module_allowlist:[...allowed],node_permission_model:!!process.permission,os_network_isolation:false,scope:'Reviewed numerical VM modules; not a hostile-code security certification'});
 const controls=math.controls();save('controls.json',controls);
 assert(controls.every(c=>c.rejected===true||(Number.isFinite(c.error)&&c.error<=1e-10)||(c.id==='phase_sensitive_comparison'&&c.amplitude_difference>0.1&&c.same_probabilities)),'Analytical control failed');
 log('analytical_controls_passed',{count:controls.length});
 const fixture=JSON.parse(fs.readFileSync(path.join(root,'inputs/hamiltonians_24x8x8.json'),'utf8'));
 assert(fixture.material_id==='JVASP-816'&&fixture.unit==='eV'&&fixture.rows.length===24,'Wrong material fixture');
 const parseStart=performance.now(),blocks=math.parseWannier(fs.readFileSync(path.join(root,'inputs/wannier90_hr.dat'),'utf8'));
 log('wannier_parsed',{blocks:blocks.length,milliseconds:performance.now()-parseStart});
 const all=[],spectra=[];
 for(let i=0;i<30;i++){
  const fresh=i>=24,k=fresh?cfg.new_kpoints[i-24]:fixture.rows[i].kpoint_fractional_reciprocal;
  const {h,rawDefect}=math.constructH(blocks,k);let reconstruction=0;
  if(!fresh){math.validateH(fixture.rows[i].matrix_ev);for(let a=0;a<8;a++)for(let b=0;b<8;b++){const z=h[a][b],v=fixture.rows[i].matrix_ev[a][b];reconstruction=Math.max(reconstruction,Math.hypot(z[0]-v[0],z[1]-v[1]));}}
  const solve=math.jacobi(h),record={index:i,group:fresh?'new_same_material_point':'original_path',kpoint:k,eigenvalues_ev:solve.eigenvalues,reference_route:'independent JavaScript Jacobi control',fixture_reconstruction_ev:fresh?null:reconstruction,raw_hermiticity_ev:rawDefect,eigenpair_residual_ev:solve.residual,orthogonality:solve.orthogonality,duplicated_pair_spread_ev:solve.pairSpread,trace_error_ev:solve.traceError,rotations:solve.rotations};
  assert(reconstruction<=cfg.tolerances.fixture_reconstruction_ev,'Raw reconstruction mismatch');
  assert(solve.residual<=cfg.tolerances.eigenpair_residual_ev&&solve.orthogonality<=cfg.tolerances.orthogonality&&solve.pairSpread<=1e-9,'Eigenpair diagnostics failed');
  all.push({h,k});spectra.push(record);
 }
 save('spectra_predictions.json',{material:'JVASP-816',units:'eV',rows:spectra});
 save('new_hamiltonians.json',{points:all.slice(24).map((r,i)=>({index:i,kpoint:r.k,matrix_ev:r.h}))});
 log('spectra_predictions_saved',{original_values:192,new_values:48,answer_files_opened:false});
 const cases=[];
 for(let i=0;i<all.length;i++){
  const rows=math.circuitChecks(all[i].h,(cfg.optimization.seed+i)>>>0);
  for(const r of rows){assert(r.max_amplitude_error<=cfg.tolerances.complex_amplitude&&r.energy_error_ev<=cfg.tolerances.energy_expectation_ev&&Math.abs(r.norm-1)<=2e-10,'Q8 complex-state or energy mismatch');cases.push({hamiltonian_index:i,...r});}
 }
 save('q8_circuit_energy.json',{route:cfg.active_qel_route,cases});log('q8_circuit_energy_passed',{cases:cases.length});
 const selected=[...cfg.optimization.selected_baseline_indices,...cfg.optimization.selected_new_indices.map(i=>24+i)],training=[];
 for(let j=0;j<selected.length;j++){
  const i=selected[j],t=performance.now(),r=math.optimize(all[i].h,cfg.optimization,(cfg.optimization.seed+1000+i)>>>0);
  const prediction={hamiltonian_index:i,kpoint:all[i].k,group:i<24?'original_path':'new_same_material_point',...r};
  save('optimization_'+j+'.json',prediction);training.push(prediction);
  log('optimization_saved',{case:j+1,total:selected.length,hamiltonian_index:i,evaluations:r.total_evaluations,milliseconds:performance.now()-t,answer_files_opened:false});
 }
 save('optimization_predictions.json',{method:cfg.optimization.method,language_model_trained:false,rows:training});
 log('all_predictions_frozen',{answer_files_opened:false});
 const official=JSON.parse(fs.readFileSync(path.join(root,'references/official_reference.json'),'utf8'));
 assert(official.train&&Object.keys(official.train).length===0&&Object.keys(official.test).join(',')==='JVASP-816','Unexpected official split');
 const target=official.test['JVASP-816'].split(';').map(Number);
 const numpy=JSON.parse(fs.readFileSync(path.join(root,'references/classical_reference_predictions.json'),'utf8')).eigenvalues.flat();
 const predicted=spectra.slice(0,24).flatMap(r=>r.eigenvalues_ev);assert(target.length===192&&target.every(Number.isFinite)&&numpy.length===192,'Invalid reference dimensions');
 const comparisons=predicted.map((v,i)=>({index:i,kpoint:Math.floor(i/8),band:i%8,prediction_ev:v,official_ev:target[i],numpy_ev:numpy[i],official_absolute_error_ev:Math.abs(v-target[i]),numpy_absolute_error_ev:Math.abs(v-numpy[i])}));
 const mae=comparisons.reduce((s,r)=>s+r.official_absolute_error_ev,0)/192,numpyMax=Math.max(...comparisons.map(r=>r.numpy_absolute_error_ev));
 save('comparisons.json',comparisons);
 assert(mae<=cfg.tolerances.official_mae_ev&&numpyMax<=cfg.tolerances.numpy_reference_max_ev,'Classical reference mismatch');
 const optimization=training.map(r=>{
  const ground=spectra[r.hamiltonian_index].eigenvalues_ev[0],gap=r.final_energy_ev-ground;
  const correct=r.starts.every(s=>s.final_energy_ev<=s.initial_energy_ev+1e-9&&s.history.every(h=>h.improvement_ev>=-1e-9)&&s.max_amplitude_error<=2e-10&&s.dense_energy_error_ev<=1e-9)&&gap>=-cfg.tolerances.variational_bound_ev;
  assert(correct,'Variational correctness condition failed');
  return {hamiltonian_index:r.hamiltonian_index,group:r.group,initial_best_energy_ev:Math.min(...r.starts.map(s=>s.initial_energy_ev)),final_energy_ev:r.final_energy_ev,ground_reference_ev:ground,gap_ev:gap,ground_gap_goal_ev:cfg.tolerances.optimization_ground_gap_goal_ev,ground_gap_goal_pass:gap<=cfg.tolerances.optimization_ground_gap_goal_ev,correctness_pass:correct,total_evaluations:r.total_evaluations};
 });
 save('optimization_scores.json',optimization);
 const summary={owner:cfg.owner,agent:cfg.agent,cycle_status:'COMPLETED_SCOPED_NODE_CYCLE',numerical_correctness:'PASS',original_python_route:cfg.original_python_route,material:'JVASP-816',baseline_hamiltonians:24,new_hamiltonians:6,analytical_controls:controls.length,q8_complex_state_energy_cases:cases.length,official_mae_ev:mae,official_max_absolute_error_ev:Math.max(...comparisons.map(r=>r.official_absolute_error_ev)),numpy_max_absolute_error_ev:numpyMax,max_fixture_reconstruction_ev:Math.max(...spectra.map(r=>r.fixture_reconstruction_ev||0)),max_eigenpair_residual_ev:Math.max(...spectra.map(r=>r.eigenpair_residual_ev)),max_q8_amplitude_error:Math.max(...cases.map(c=>c.max_amplitude_error)),max_q8_energy_error_ev:Math.max(...cases.map(c=>c.energy_error_ev)),optimization_cases:optimization.length,optimization_goal_passes:optimization.filter(r=>r.ground_gap_goal_pass).length,optimization_correctness_passes:optimization.filter(r=>r.correctness_pass).length,language_model_trained:false,physical_qpu_used:false,quantum_advantage_established:false,public_submission:false,signature:'UNSIGNED'};
 save('summary.json',summary);
 for(const item of identities)assert(hashBytes(fs.readFileSync(path.join(root,item.file)),'jarvis-source')===item.identity,'Source changed during computation: '+item.file);
 log('completed',{numerical_correctness:'PASS',optimization_goal_passes:summary.optimization_goal_passes});
 const memory=process.memoryUsage();save('execution.json',{started_utc:events[0].at_utc,finished_utc:new Date().toISOString(),elapsed_ms:performance.now()-start,cpu_microseconds:process.cpuUsage(cpuStart),sampled_maximum_rss_bytes:Math.max(sampledRss,memory.rss),process_maximum_rss_reported:process.resourceUsage().maxRSS,resource_usage:process.resourceUsage(),memory_final:memory,platform:process.platform,node:process.version,processor_arch:process.arch,scope:'Actual laptop Node process; elapsed excludes process startup. RSS includes Node overhead. Sampled maximum is not continuous sampling.',mirror_bytes_verified:true,source_bytes_unchanged:true});
}catch(error){
 const failure={at_utc:new Date().toISOString(),error:String(error),stack:error.stack,events};try{save('failure.json',failure);}catch{}
 console.error(error);process.exitCode=1;
}
