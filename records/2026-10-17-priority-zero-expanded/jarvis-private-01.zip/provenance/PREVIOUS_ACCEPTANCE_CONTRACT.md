# GAUCIA — Acceptance contract for the existing QEL kernel

Owner: Sherman Gaucia Laing. Scope: private integration study of the already prepared JARVIS aluminum reference problem.

## Gate 1: Recover the existing implementation

Recover `code/qel_qpu_emulator_kernel_v1.py`, its preserved successor if one is authoritative, and required project dependencies from an identified owner source. Preserve those files unchanged. Record their archive or file paths and direct byte comparisons where available. Do not silently recreate a missing module from a report, and do not invent an SGL signature.

Read the actual source before executing it. Identify imports, import-time behavior, network use, process creation, filesystem writes, credential access, resource limits, and its authentic callable interface. Keep the original project code private. If dependencies are absent or the source is unavailable, record the blocked gate; do not substitute another program and label it as the recovered kernel.

## Gate 2: Fix the scientific input contract

The input is the ordered array of 24 complex 8×8 Hermitian matrices in `fixture/hamiltonians_24x8x8.json` or its numerically identical NPY counterpart. Matrix entries are in electronvolts (eV). K-points are fractional reciprocal coordinates. Orbital order is the original Wannier orbital order. The construction is the positive-phase Fourier sum of degeneracy-normalized Wannier blocks, followed by `(H + H†)/2`.

Keep the 24-point path order, including repeated endpoints. No Fermi-level subtraction, basis permutation, rescaling, or unit conversion may be silently introduced. Reject nonfinite inputs, wrong dimensions, or a Hermiticity max-entry residual above `1e-12 eV` before computation.

These are Hamiltonians, not unitary gates. Passing `H` directly to an interface that expects a unitary is invalid. If the recovered method uses time evolution, declare energy/time units and the complete `exp(-i H t / hbar)` convention. If it encodes a Hamiltonian into Pauli operators, record basis and bit order and verify reconstruction. Do not assume these routes exist before source inspection.

## Gate 3: Declare what is actually being measured

Use the real supported QEL route. Record owner, GAUCIA's role, implementation file and version/provenance, exact function entry point, dependency route, configuration, seed if stochastic, start/end timestamps, CPU/runtime environment, measured resource use, and whether execution completed.

If QEL calls a numerical library internally, name that dependency. If NumPy or another external routine supplies the eigenvalues while QEL only checks the inputs or propagates states, state that narrower role. Merely running a wrapper or issuing an instruction as GAUCIA is not evidence that a named simulator component performed an eigensolver calculation.

The expected result for the existing benchmark is eight ascending eigenvalues per k-point, 24 rows, and 192 finite scalar outputs in k-point-major order. A ground-state-only algorithm does not satisfy this full-spectrum contract. If full-spectrum execution is unsupported, report the supported subtask separately rather than fabricate the remaining outputs.

## Gate 4: Freeze outputs before scoring

Write and preserve the output predictions before opening `reference_outputs/` in that execution. Reference values have already been inspected in prior preparation, so this is not a blind test. No expected answer may enter the Hamiltonian fixture or serve as a generated prediction.

For the full-spectrum route, compute the mean absolute error across the 192 ordered values against the official reference. Retain the existing private tolerance: **MAE ≤ 0.0001 eV**. This is an engineering condition from our prior experiment, not a NIST certification threshold. Also report maximum absolute error and all 192 comparison rows; MAE alone can hide one bad band.

If eigenvectors are returned, additionally report orthonormality and `H V - V E` residuals. Assess these against precision declared for the recovered method. These diagnostics are not prerequisites for a method that only promises eigenvalue estimates; do not fabricate eigenvectors.

## Gate 5: Replay and evidence review

Perform a bounded second run with the same declared inputs. For a deterministic route compare complete prediction bytes. For a stochastic route preserve the seed, repeat-count budget, individual results, and variability; do not demand byte equality if the method does not promise it. Retain failed attempts and explain any correction before rerunning.

The gate is incomplete unless the evidence identifies the actual QEL component exercised. Numerical agreement produced solely by the previous classical reference program is useful as a control, but is not QEL kernel integration evidence.

All outputs remain private for review. Any later public statement must distinguish input preparation, classical control reproduction, actual QEL kernel execution, scientific interpretation, unresolved limitations, and publication authorization. No blanket certificate, physical QPU claim, advantage claim, or project-wide validation follows from this test.
