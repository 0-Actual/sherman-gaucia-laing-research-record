# Third-party source-data notice

The source archive `JVASP-816.zip` was published by **Kamal Choudhary** as part of *JARVIS-DFT Wannier 3D materials (JVASP-5 to JVASP-28500)*, Figshare article12473168, DOI [10.6084/m9.figshare.12473168.v1](https://doi.org/10.6084/m9.figshare.12473168.v1). Its associated API metadata specifies **Creative Commons Attribution 4.0 International (CC BY 4.0)**.

License and warranty terms: [CC BY4.0 legal code](https://creativecommons.org/licenses/by/4.0/legalcode.en). The source archive is preserved unchanged. Newly calculated eigenvalues and comparisons are derived study outputs. The archive is not relicensed under QEL's noncommercial terms.

Related publication: Kevin F. Garrity and Kamal Choudhary, *Database of Wannier tight-binding Hamiltonians using high-throughput density functional theory*, Scientific Data8,106(2021), DOI [10.1038/s41597-021-00885-z](https://doi.org/10.1038/s41597-021-00885-z).

The initial direct attempt to save the plain-text legal code returned HTTP403. That failure remains in `acquisition_log.json`. The official legal-code page was subsequently read successfully with the web lookup. This notice preserves the license URI and attribution; it is not a claim that a raw legal-code file was downloaded.

JARVIS software/recipe copies and benchmark sources retain their separately preserved NIST notices in `JARVIS_LICENSE.rst` and `LEADERBOARD_LICENSE.rst`. No endorsement by NIST, the data authors, or Creative Commons is claimed.
