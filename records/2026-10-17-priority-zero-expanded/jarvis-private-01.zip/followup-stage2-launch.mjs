// Scoped private numerical runner; changes no existing service or OS setting.
import fs from 'node:fs'; import path from 'node:path'; import os from 'node:os';
import {spawn} from 'node:child_process'; import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const mirror=root.startsWith('D:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_01':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_01';
const label=process.argv[2];if(!/^stage2_0[12]$/.test(label))throw Error('Expected stage2_01 or stage2_02');
for(const r of [root,mirror])if(fs.existsSync(path.join(r,label)))throw Error('Run already exists; refusing overwrite');
const logs=[root,mirror].map(r=>path.join(r,label+'_launcher.ndjson'));
function note(v){const s=JSON.stringify({at_utc:new Date().toISOString(),...v})+'\n';for(const f of logs)fs.appendFileSync(f,s);process.stdout.write(s);}
const args=['--max-old-space-size=128','--permission','--allow-fs-read='+root,'--allow-fs-read='+mirror,'--allow-fs-write='+root,'--allow-fs-write='+mirror,'--experimental-vm-modules',path.join(root,'followup-stage2.mjs'),label,mirror];
const env={SystemRoot:process.env.SystemRoot,WINDIR:process.env.WINDIR,PATH:path.dirname(process.execPath)};
note({stage:'launch',node:process.execPath,args,free_memory_bytes:os.freemem(),host:os.hostname(),platform:os.platform(),cpu_model:os.cpus()[0]?.model});
const child=spawn(process.execPath,args,{cwd:root,env,windowsHide:true,stdio:['ignore','pipe','pipe']});
const timer=setTimeout(()=>{note({stage:'timeout',pid:child.pid,budget_ms:240000});child.kill();},240000);
try{os.setPriority(child.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);note({stage:'priority',pid:child.pid,priority:os.getPriority(child.pid)});}catch(e){note({stage:'priority_unavailable',error:String(e)});}
for(const [stream,name] of [[child.stdout,'stdout'],[child.stderr,'stderr']])stream.on('data',bytes=>{for(const r of [root,mirror])fs.appendFileSync(path.join(r,label+'_'+name+'.log'),bytes);process[name==='stdout'?'stdout':'stderr'].write(bytes);});
child.on('error',e=>{clearTimeout(timer);note({stage:'launch_error',error:String(e)});process.exitCode=1;});
child.on('close',(code,signal)=>{clearTimeout(timer);note({stage:'exit',code,signal,free_memory_bytes:os.freemem()});process.exitCode=code===0?0:1;});
