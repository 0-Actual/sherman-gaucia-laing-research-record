@echo off
setlocal
title Private JARVIS replay
"./REDACTED_LOCAL_ROOT/Program Files\nodejs\node.exe" "%~dp0replay-new.mjs"
pause
