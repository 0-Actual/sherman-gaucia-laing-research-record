// Final scoped evidence verification. No publication or source mutation.
import fs from 'node:fs';import path from 'node:path';import {fileURLToPath} from 'node:url';
import {hashBytes,PROFILE} from './vendor/sgl-prime.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const usb='./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_01',laptop='./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_01';
const roots=[laptop,usb],read=rel=>JSON.parse(fs.readFileSync(path.join(here,rel),'utf8'));
function save(rel,value){const b=Buffer.from(JSON.stringify(value,null,2)+'\n');for(const r of roots){const p=path.join(r,rel);fs.writeFileSync(p,b,{flag:'wx'});if(!b.equals(fs.readFileSync(p)))throw Error('Save verification failed');}return b;}
function walk(root,rel=''){return fs.readdirSync(path.join(root,rel),{withFileTypes:true}).flatMap(e=>{if(e.isSymbolicLink())throw Error('Unexpected symlink');return e.isDirectory()?walk(root,path.join(rel,e.name)):[path.join(rel,e.name)];}).sort();}
const sourceChecks=read('SOURCE_COPIES.json').map(row=>({source:row.source,preserved:row.destination,equal:fs.readFileSync(row.source).equals(fs.readFileSync(path.join(here,row.destination)))}));
if(sourceChecks.some(r=>!r.equal))throw Error('Original source changed');
const baseline=read('run_01/summary.json'),replay=read('REPLAY_VERIFICATION.json'),follow1=read('followup_01/result.json'),follow2=read('stage2_01/result.json');
const fresh=fs.readdirSync(path.join(here,'replays')).map(id=>read('replays/'+id+'/REPLAY_RECEIPT.json'));
if(!replay.exact||!fresh.length||fresh.some(r=>!r.exact))throw Error('Replay gate failed');
save('FINAL_STATUS.json',{recorded_utc:new Date().toISOString(),owner:'Sherman G. Laing',agent:'GAUCIA',scope:'Private laptop JARVIS/Q8 numerical benchmark cycle',cycle_complete:true,all_optimization_targets_met:false,numerical_correctness_pass:baseline.numerical_correctness==='PASS',baseline,initial_replay_exact:true,fresh_folder_replay_exact:true,final_remaining_gap_ev:follow2.followup_gap_ev,unchanged_gap_goal_ev:follow2.goal_ev,gap_reduction_from_initial_fraction:1-follow2.followup_gap_ev/follow1.initial_cycle_gap_ev,followups_replayed:false,source_checks:sourceChecks,original_python_deployment_complete:false,publication:'NONE',release:'HOLD',signature:'UNSIGNED',source_implementation_unchanged:true,laptop_path:laptop,usb_path:usb});
const a=walk(laptop),b=walk(usb);if(JSON.stringify(a)!==JSON.stringify(b))throw Error('File membership differs');
let total=0;const entries=a.map(rel=>{const left=fs.readFileSync(path.join(laptop,rel)),right=fs.readFileSync(path.join(usb,rel));if(!left.equals(right))throw Error('Mirror byte mismatch: '+rel);total+=left.length;return {path:rel.replaceAll('\\','/'),bytes:left.length,identity:hashBytes(left,'jarvis-artifact')};});
const manifest=save('MANIFEST.sgl.json',{schema:'qel.jarvis.manifest/v1',owner:'Sherman G. Laing',recorded_utc:new Date().toISOString(),profile:PROFILE,signature:'UNSIGNED',scope:'Named snapshot entries; manifest and final receipt are separately verified. Later replay folders are additional work.',files:entries});
const result={recorded_utc:new Date().toISOString(),source_originals_unchanged:sourceChecks.length,covered_files:entries.length,total_covered_bytes_per_copy:total,all_covered_files_byte_identical:true,manifest_identity:hashBytes(manifest,'jarvis-manifest'),manifest_byte_identical:true,initial_replay_exact:replay.exact,fresh_folder_replay_exact:true,numerical_gate:true,all_optimization_targets_gate:false,remaining_gap_ev:follow2.followup_gap_ev,target_gap_ev:follow2.goal_ev,signature:'UNSIGNED',release:'HOLD',paths:roots};
save('FINAL_VERIFY.json',result);console.log(JSON.stringify(result));
