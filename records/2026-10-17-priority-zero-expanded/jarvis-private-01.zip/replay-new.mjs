// New-folder replay preserves all existing evidence. Sherman G. Laing / GAUCIA.
import fs from 'node:fs';import path from 'node:path';import os from 'node:os';
import {spawn} from 'node:child_process';import {fileURLToPath} from 'node:url';
const source=path.dirname(fileURLToPath(import.meta.url));
const other=source.startsWith('D:')?'./REDACTED_LOCAL_ROOT/Documents/Codex/Q8_Testing_Space/JARVIS_Private_20260920_01':'./REDACTED_LOCAL_ROOT/QEL_Q7/Q8_Testing_Space/JARVIS_Private_20260920_01';
if(!fs.existsSync(other))throw Error('Both saved locations must be available for this mirrored replay');
const id=new Date().toISOString().replace(/[:.]/g,'-')+'-'+process.pid;
const roots=[source,other].map(r=>path.join(r,'replays',id));
const files=['compute.mjs','runner.mjs','CONTRACT.json','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs','vendor/sgl-prime.mjs','inputs/wannier90_hr.dat','inputs/hamiltonians_24x8x8.json','references/official_reference.json','references/classical_reference_predictions.json'];
for(const r of roots){fs.mkdirSync(r,{recursive:true});for(const f of files){const bytes=fs.readFileSync(path.join(source,f)),p=path.join(r,f);fs.mkdirSync(path.dirname(p),{recursive:true});fs.writeFileSync(p,bytes,{flag:'wx'});if(!bytes.equals(fs.readFileSync(p)))throw Error('Input copy mismatch');}}
const args=['--max-old-space-size=128','--permission',...roots.map(r=>'--allow-fs-read='+r),...roots.map(r=>'--allow-fs-write='+r),'--experimental-vm-modules',path.join(roots[0],'runner.mjs'),'run_01',roots[1]];
const child=spawn(process.execPath,args,{cwd:roots[0],env:{SystemRoot:process.env.SystemRoot,WINDIR:process.env.WINDIR,PATH:path.dirname(process.execPath)},windowsHide:true,stdio:['ignore','pipe','pipe']});
try{os.setPriority(child.pid,os.constants.priority.PRIORITY_BELOW_NORMAL);}catch{}
const timer=setTimeout(()=>child.kill(),240000);
for(const [s,name] of [[child.stdout,'stdout'],[child.stderr,'stderr']])s.on('data',b=>{for(const r of roots)fs.appendFileSync(path.join(r,name+'.log'),b);process[name==='stdout'?'stdout':'stderr'].write(b);});
child.on('error',e=>{clearTimeout(timer);console.error(e);process.exitCode=1;});
child.on('close',(code,signal)=>{
 clearTimeout(timer);let matches=[];
 if(code===0)matches=fs.readdirSync(path.join(source,'run_01')).filter(f=>f.endsWith('.json')&&f!=='execution.json').map(f=>({file:f,equal:fs.readFileSync(path.join(source,'run_01',f)).equals(fs.readFileSync(path.join(roots[0],'run_01',f)))}));
 const result={recorded_utc:new Date().toISOString(),code,signal,replay_roots:roots,comparison_source:path.join(source,'run_01'),files:matches,exact:code===0&&matches.length===17&&matches.every(m=>m.equal)};
 for(const r of roots)fs.writeFileSync(path.join(r,'REPLAY_RECEIPT.json'),JSON.stringify(result,null,2),{flag:'wx'});
 console.log(JSON.stringify(result));process.exitCode=result.exact?0:1;
});
