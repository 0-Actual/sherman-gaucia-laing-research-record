#!/usr/bin/env python3
"""
Project Quantum.Earth.Laing / Q6.1
Owner / Originator: Sherman G. Laing

QEL Quantum Energy Optimization Reference v1
--------------------------------------------
A deterministic, fail-closed classical quantum-information simulation reference
for Generation A Algorithm #7, "Laing Quantum Energy Optimization."

The implementation defines energy as the expectation value of a Hermitian
Hamiltonian, uses normalized parameterized states, performs an explicit bounded
search, and compares the variational result with exact diagonalization.

It does not claim quantum-hardware execution, physical energy generation,
thermodynamic advantage, or quantum advantage.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable

import numpy as np
from numpy.typing import ArrayLike, NDArray

from qel_quantum_common_kernel_v1 import (
    QuantumKernelError,
    expectation,
    normalize_state,
    require_hermitian,
    validate_state,
)

ComplexArray = NDArray[np.complex128]
TOL = 1e-10

I2 = np.eye(2, dtype=np.complex128)
X = np.array([[0, 1], [1, 0]], dtype=np.complex128)
Z = np.array([[1, 0], [0, -1]], dtype=np.complex128)


class EnergyOptimizationError(ValueError):
    """Fail-closed model, parameter, or objective error."""


def _finite_float(value: float, name: str) -> float:
    out = float(value)
    if not np.isfinite(out):
        raise EnergyOptimizationError(f"{name} must be finite")
    return out


def ry(theta: float) -> ComplexArray:
    """Single-qubit Y rotation."""
    t = _finite_float(theta, "theta") / 2.0
    return np.array(
        [[np.cos(t), -np.sin(t)], [np.sin(t), np.cos(t)]],
        dtype=np.complex128,
    )


def cnot() -> ComplexArray:
    return np.array(
        [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
        dtype=np.complex128,
    )


def product_ansatz(theta_a: float, theta_b: float) -> ComplexArray:
    """Prepare RY(theta_a)|0> tensor RY(theta_b)|0>."""
    zero = np.array([1, 0], dtype=np.complex128)
    state = np.kron(ry(theta_a) @ zero, ry(theta_b) @ zero)
    return validate_state(state)


def bell_family_ansatz(theta: float) -> ComplexArray:
    """Prepare cos(theta/2)|00> + sin(theta/2)|11>."""
    zero_zero = np.array([1, 0, 0, 0], dtype=np.complex128)
    rotation = np.kron(ry(theta), I2)
    return validate_state(cnot() @ (rotation @ zero_zero))


def energy(state: ArrayLike, hamiltonian: ArrayLike) -> float:
    """Return the real expectation value <psi|H|psi>."""
    psi = validate_state(state)
    h = require_hermitian(hamiltonian)
    if h.shape[0] != psi.size:
        raise EnergyOptimizationError("Hamiltonian dimension does not match state")
    try:
        return float(expectation(psi, h))
    except QuantumKernelError as exc:
        raise EnergyOptimizationError(str(exc)) from exc


@dataclass(frozen=True)
class EnergyOptimizationResult:
    best_parameter: float
    best_energy: float
    exact_ground_energy: float
    energy_gap: float
    evaluations: int
    best_state: ComplexArray
    ground_state_fidelity: float


def exact_ground_solution(hamiltonian: ArrayLike) -> tuple[float, ComplexArray]:
    h = require_hermitian(hamiltonian)
    values, vectors = np.linalg.eigh(h)
    index = int(np.argmin(values.real))
    ground_energy = float(values[index].real)
    ground_state = normalize_state(vectors[:, index])
    return ground_energy, ground_state


def _fidelity(a: ComplexArray, b: ComplexArray) -> float:
    a = validate_state(a)
    b = validate_state(b)
    if a.size != b.size:
        raise EnergyOptimizationError("fidelity states have different dimensions")
    return float(np.clip(abs(np.vdot(a, b)) ** 2, 0.0, 1.0))


def optimize_parameter_grid(
    hamiltonian: ArrayLike,
    parameter_grid: Iterable[float],
    state_factory: Callable[[float], ArrayLike],
) -> EnergyOptimizationResult:
    """Deterministically minimize energy over an explicit bounded grid."""
    h = require_hermitian(hamiltonian)
    grid = [float(value) for value in parameter_grid]
    if not grid:
        raise EnergyOptimizationError("parameter grid must not be empty")
    if any(not np.isfinite(value) for value in grid):
        raise EnergyOptimizationError("parameter grid contains a non-finite value")

    best_parameter: float | None = None
    best_energy: float | None = None
    best_state: ComplexArray | None = None

    for parameter in grid:
        state = validate_state(state_factory(parameter))
        if state.size != h.shape[0]:
            raise EnergyOptimizationError("state factory dimension does not match Hamiltonian")
        current = energy(state, h)
        if best_energy is None or current < best_energy - TOL:
            best_parameter = parameter
            best_energy = current
            best_state = state.copy()

    assert best_parameter is not None and best_energy is not None and best_state is not None
    ground_energy, ground_state = exact_ground_solution(h)
    gap = max(0.0, float(best_energy - ground_energy))
    if gap <= 1e-14:
        gap = 0.0
    return EnergyOptimizationResult(
        best_parameter=best_parameter,
        best_energy=float(best_energy),
        exact_ground_energy=ground_energy,
        energy_gap=gap,
        evaluations=len(grid),
        best_state=best_state,
        ground_state_fidelity=_fidelity(best_state, ground_state),
    )


def optimize_bell_hamiltonian(points: int = 201) -> EnergyOptimizationResult:
    """Minimize H = -(X⊗X + Z⊗Z) over a Bell-family ansatz."""
    if not isinstance(points, int) or isinstance(points, bool) or points < 3:
        raise EnergyOptimizationError("points must be an integer of at least three")
    hamiltonian = -(np.kron(X, X) + np.kron(Z, Z))
    grid = np.linspace(0.0, np.pi, points)
    return optimize_parameter_grid(hamiltonian, grid, bell_family_ansatz)


def optimize_product_zz(points: int = 101) -> tuple[float, float, float]:
    """Minimize Z⊗I + I⊗Z with a deterministic two-parameter product grid."""
    if not isinstance(points, int) or isinstance(points, bool) or points < 3:
        raise EnergyOptimizationError("points must be an integer of at least three")
    h = np.kron(Z, I2) + np.kron(I2, Z)
    grid = np.linspace(0.0, np.pi, points)
    best = (float("inf"), 0.0, 0.0)
    for a in grid:
        for b in grid:
            value = energy(product_ansatz(float(a), float(b)), h)
            if value < best[0] - TOL:
                best = (value, float(a), float(b))
    return best


def benchmark() -> dict[str, object]:
    bell = optimize_bell_hamiltonian(201)
    product_energy, theta_a, theta_b = optimize_product_zz(51)
    return {
        "schema": "qel.quantum-energy-optimization-benchmark/v1",
        "bell_hamiltonian": {
            "best_parameter": bell.best_parameter,
            "best_energy": bell.best_energy,
            "exact_ground_energy": bell.exact_ground_energy,
            "energy_gap": bell.energy_gap,
            "ground_state_fidelity": bell.ground_state_fidelity,
            "evaluations": bell.evaluations,
        },
        "product_zz": {
            "best_energy": product_energy,
            "theta_a": theta_a,
            "theta_b": theta_b,
            "exact_ground_energy": -2.0,
        },
        "claim_boundary": {
            "simulation": True,
            "physical_qpu_execution": False,
            "quantum_advantage": False,
            "thermodynamic_energy_generation": False,
        },
    }


if __name__ == "__main__":
    import json

    print(json.dumps(benchmark(), indent=2, sort_keys=True))
