#!/usr/bin/env python3
"""
Project Quantum.Earth.Laing / Q6.1
Author / Owner-Principal: Sherman G. Laing
Primary Agent Role: GAUCIA
Support Review Roles: Leviathan, Nadine
Attribution: no use without visible credit to the author.

QEL Quantum Common Kernel v1
----------------------------
A fail-closed, deterministic classical quantum-information simulation kernel
created during MC-003D. It supersedes no historical source bytes. It provides
shared primitives for corrected successors to Quantum Emulation Algorithms
#1–21.

This module does not claim quantum-hardware execution, physical quantum
advantage, cryptographic security, laboratory validation, or operator-signed
release.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Iterable, Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray
from scipy.linalg import expm

TOL = 1e-10
ComplexArray = NDArray[np.complex128]


class QuantumKernelError(ValueError):
    """Fail-closed input, model, or operator error."""


def _complex_vector(value: ArrayLike) -> ComplexArray:
    arr = np.asarray(value, dtype=np.complex128)
    if arr.ndim != 1 or arr.size < 2:
        raise QuantumKernelError("state must be a one-dimensional vector of dimension at least two")
    if not np.all(np.isfinite(arr.real)) or not np.all(np.isfinite(arr.imag)):
        raise QuantumKernelError("state contains non-finite values")
    return arr


def _complex_matrix(value: ArrayLike) -> ComplexArray:
    arr = np.asarray(value, dtype=np.complex128)
    if arr.ndim != 2 or arr.shape[0] != arr.shape[1] or arr.shape[0] < 2:
        raise QuantumKernelError("operator must be a square matrix of dimension at least two")
    if not np.all(np.isfinite(arr.real)) or not np.all(np.isfinite(arr.imag)):
        raise QuantumKernelError("operator contains non-finite values")
    return arr


def is_power_of_two(value: int) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0 and (value & (value - 1)) == 0


def qubit_count_from_dimension(dimension: int) -> int:
    if not is_power_of_two(dimension) or dimension < 2:
        raise QuantumKernelError("state dimension must be a power of two greater than or equal to two")
    return dimension.bit_length() - 1


def normalize_state(value: ArrayLike, *, atol: float = TOL) -> ComplexArray:
    arr = _complex_vector(value).copy()
    qubit_count_from_dimension(arr.size)
    norm = float(np.linalg.norm(arr))
    if not np.isfinite(norm) or norm <= atol:
        raise QuantumKernelError("state norm is zero or non-finite")
    arr /= norm
    return arr


def validate_state(value: ArrayLike, *, atol: float = TOL) -> ComplexArray:
    arr = _complex_vector(value).copy()
    qubit_count_from_dimension(arr.size)
    norm = float(np.linalg.norm(arr))
    if not np.isclose(norm, 1.0, atol=atol, rtol=0.0):
        raise QuantumKernelError(f"state is not normalized: norm={norm!r}")
    return arr


def random_pure_state(num_qubits: int, *, seed: int) -> ComplexArray:
    if not isinstance(num_qubits, int) or isinstance(num_qubits, bool) or num_qubits < 1:
        raise QuantumKernelError("num_qubits must be a positive integer")
    if not isinstance(seed, int) or isinstance(seed, bool):
        raise QuantumKernelError("seed must be an integer")
    rng = np.random.default_rng(seed)
    dimension = 2**num_qubits
    # Independent zero-mean normal real and imaginary components yield a
    # rotationally invariant complex Gaussian before normalization.
    raw = rng.normal(size=dimension) + 1j * rng.normal(size=dimension)
    return normalize_state(raw)


def is_hermitian(value: ArrayLike, *, atol: float = TOL) -> bool:
    matrix = _complex_matrix(value)
    return bool(np.allclose(matrix, matrix.conj().T, atol=atol, rtol=0.0))


def require_hermitian(value: ArrayLike, *, atol: float = TOL) -> ComplexArray:
    matrix = _complex_matrix(value).copy()
    if not is_hermitian(matrix, atol=atol):
        raise QuantumKernelError("Hamiltonian or observable must be Hermitian")
    return matrix


def is_unitary(value: ArrayLike, *, atol: float = TOL) -> bool:
    matrix = _complex_matrix(value)
    ident = np.eye(matrix.shape[0], dtype=np.complex128)
    return bool(
        np.allclose(matrix.conj().T @ matrix, ident, atol=atol, rtol=0.0)
        and np.allclose(matrix @ matrix.conj().T, ident, atol=atol, rtol=0.0)
    )


def require_unitary(value: ArrayLike, *, atol: float = TOL) -> ComplexArray:
    matrix = _complex_matrix(value).copy()
    if not is_unitary(matrix, atol=atol):
        raise QuantumKernelError("state-vector operator must be unitary")
    return matrix


def apply_unitary(state: ArrayLike, operation: ArrayLike, *, atol: float = TOL) -> ComplexArray:
    psi = validate_state(state, atol=atol)
    unitary = require_unitary(operation, atol=atol)
    if unitary.shape[0] != psi.size:
        raise QuantumKernelError("operator dimension does not match state dimension")
    result = unitary @ psi
    return validate_state(result, atol=max(atol, 1e-9))


def hamiltonian_unitary(hamiltonian: ArrayLike, time: float, *, hbar: float = 1.0) -> ComplexArray:
    h = require_hermitian(hamiltonian)
    if not np.isfinite(time):
        raise QuantumKernelError("time must be finite")
    if not np.isfinite(hbar) or hbar <= 0:
        raise QuantumKernelError("hbar must be finite and positive")
    return require_unitary(expm(-1j * h * float(time) / float(hbar)), atol=1e-9)


def evolve_state(state: ArrayLike, hamiltonian: ArrayLike, time: float, *, hbar: float = 1.0) -> ComplexArray:
    psi = validate_state(state)
    unitary = hamiltonian_unitary(hamiltonian, time, hbar=hbar)
    return apply_unitary(psi, unitary, atol=1e-9)


def probabilities(state: ArrayLike, *, atol: float = TOL) -> NDArray[np.float64]:
    psi = validate_state(state, atol=atol)
    probs = np.abs(psi) ** 2
    total = float(np.sum(probs))
    if not np.isclose(total, 1.0, atol=max(atol, 1e-12), rtol=0.0):
        raise QuantumKernelError("measurement probabilities do not sum to one")
    probs = probs / total
    return np.asarray(probs, dtype=np.float64)


@dataclass(frozen=True)
class MeasurementResult:
    outcome: int
    probability: float
    collapsed_state: ComplexArray


def measure_computational(state: ArrayLike, *, seed: int) -> MeasurementResult:
    if not isinstance(seed, int) or isinstance(seed, bool):
        raise QuantumKernelError("measurement seed must be an integer")
    psi = validate_state(state)
    probs = probabilities(psi)
    rng = np.random.default_rng(seed)
    outcome = int(rng.choice(psi.size, p=probs))
    collapsed = np.zeros(psi.size, dtype=np.complex128)
    collapsed[outcome] = 1.0
    return MeasurementResult(outcome, float(probs[outcome]), collapsed)


def density_matrix(state: ArrayLike) -> ComplexArray:
    psi = validate_state(state)
    return np.outer(psi, psi.conj())


def validate_density_matrix(value: ArrayLike, *, atol: float = TOL) -> ComplexArray:
    rho = _complex_matrix(value).copy()
    qubit_count_from_dimension(rho.shape[0])
    if not np.allclose(rho, rho.conj().T, atol=atol, rtol=0.0):
        raise QuantumKernelError("density matrix must be Hermitian")
    trace = np.trace(rho)
    if not np.isclose(trace.real, 1.0, atol=atol, rtol=0.0) or not np.isclose(trace.imag, 0.0, atol=atol, rtol=0.0):
        raise QuantumKernelError("density matrix must have unit trace")
    eigvals = np.linalg.eigvalsh((rho + rho.conj().T) / 2)
    if float(np.min(eigvals)) < -atol:
        raise QuantumKernelError("density matrix must be positive semidefinite")
    return rho


def partial_trace_bipartite(value: ArrayLike, dims: tuple[int, int], *, keep: int) -> ComplexArray:
    rho = validate_density_matrix(value, atol=1e-9)
    if (
        not isinstance(dims, tuple)
        or len(dims) != 2
        or any(not isinstance(d, int) or isinstance(d, bool) or d < 1 for d in dims)
        or dims[0] * dims[1] != rho.shape[0]
    ):
        raise QuantumKernelError("dims must be a two-part factorization of the density-matrix dimension")
    reshaped = rho.reshape(dims[0], dims[1], dims[0], dims[1])
    if keep == 0:
        reduced = np.trace(reshaped, axis1=1, axis2=3)
    elif keep == 1:
        reduced = np.trace(reshaped, axis1=0, axis2=2)
    else:
        raise QuantumKernelError("keep must be zero or one")
    # Reduced systems need not have power-of-two dimension in the general helper,
    # so validate directly rather than calling validate_density_matrix.
    if not np.allclose(reduced, reduced.conj().T, atol=1e-9, rtol=0.0):
        raise QuantumKernelError("reduced density matrix is not Hermitian")
    if not np.isclose(np.trace(reduced), 1.0, atol=1e-9, rtol=0.0):
        raise QuantumKernelError("reduced density matrix is not normalized")
    return np.asarray(reduced, dtype=np.complex128)


def von_neumann_entropy(value: ArrayLike, *, base: float = 2.0, atol: float = TOL) -> float:
    rho = np.asarray(value, dtype=np.complex128)
    if rho.ndim != 2 or rho.shape[0] != rho.shape[1]:
        raise QuantumKernelError("entropy input must be a square density matrix")
    if not np.allclose(rho, rho.conj().T, atol=atol, rtol=0.0):
        raise QuantumKernelError("entropy input must be Hermitian")
    if not np.isclose(np.trace(rho), 1.0, atol=atol, rtol=0.0):
        raise QuantumKernelError("entropy input must have unit trace")
    if not np.isfinite(base) or base <= 0 or np.isclose(base, 1.0):
        raise QuantumKernelError("entropy logarithm base must be positive and not equal to one")
    eigvals = np.linalg.eigvalsh((rho + rho.conj().T) / 2)
    if float(np.min(eigvals)) < -atol:
        raise QuantumKernelError("entropy input must be positive semidefinite")
    eigvals = np.clip(eigvals.real, 0.0, 1.0)
    nonzero = eigvals[eigvals > atol]
    if nonzero.size == 0:
        return 0.0
    return float(-np.sum(nonzero * np.log(nonzero) / np.log(base)))


def pure_entanglement_entropy(state: ArrayLike, dims: tuple[int, int], *, keep: int = 0) -> float:
    return von_neumann_entropy(partial_trace_bipartite(density_matrix(state), dims, keep=keep))


def pure_state_fidelity(a: ArrayLike, b: ArrayLike) -> float:
    psi = validate_state(a)
    phi = validate_state(b)
    if psi.size != phi.size:
        raise QuantumKernelError("states must have equal dimensions")
    value = float(abs(np.vdot(psi, phi)) ** 2)
    return float(np.clip(value, 0.0, 1.0))


def phase_invariant_distance(a: ArrayLike, b: ArrayLike, *, atol: float = 1e-14) -> float:
    residual = max(0.0, 1.0 - pure_state_fidelity(a, b))
    # Fidelity of mathematically identical rays can land a few ulps below one.
    # Collapse only that bounded numerical residue; do not hide material error.
    if residual <= atol:
        return 0.0
    return float(np.sqrt(residual))


def l1_coherence(value: ArrayLike) -> float:
    rho = validate_density_matrix(value, atol=1e-9)
    return float(np.sum(np.abs(rho - np.diag(np.diag(rho)))))


def relative_entropy_coherence(value: ArrayLike) -> float:
    rho = validate_density_matrix(value, atol=1e-9)
    diagonal = np.diag(np.diag(rho))
    return float(von_neumann_entropy(diagonal) - von_neumann_entropy(rho))


def expectation(state: ArrayLike, observable: ArrayLike) -> float:
    psi = validate_state(state)
    obs = require_hermitian(observable)
    if obs.shape[0] != psi.size:
        raise QuantumKernelError("observable dimension does not match state")
    value = np.vdot(psi, obs @ psi)
    if not np.isclose(value.imag, 0.0, atol=1e-9, rtol=0.0):
        raise QuantumKernelError("Hermitian expectation unexpectedly has a material imaginary component")
    return float(value.real)


def commutator(a: ArrayLike, b: ArrayLike) -> ComplexArray:
    left = _complex_matrix(a)
    right = _complex_matrix(b)
    if left.shape != right.shape:
        raise QuantumKernelError("commutator matrices must have equal dimensions")
    return left @ right - right @ left


def validate_kraus(kraus_ops: Sequence[ArrayLike], *, atol: float = TOL) -> list[ComplexArray]:
    if not isinstance(kraus_ops, Sequence) or len(kraus_ops) == 0:
        raise QuantumKernelError("at least one Kraus operator is required")
    ops = [_complex_matrix(op).copy() for op in kraus_ops]
    shape = ops[0].shape
    if any(op.shape != shape for op in ops):
        raise QuantumKernelError("all Kraus operators must have equal dimensions")
    closure = sum((op.conj().T @ op for op in ops), np.zeros(shape, dtype=np.complex128))
    if not np.allclose(closure, np.eye(shape[0]), atol=atol, rtol=0.0):
        raise QuantumKernelError("Kraus operators are not trace preserving")
    return ops


def apply_kraus(value: ArrayLike, kraus_ops: Sequence[ArrayLike]) -> ComplexArray:
    rho = validate_density_matrix(value, atol=1e-9)
    ops = validate_kraus(kraus_ops, atol=1e-9)
    if ops[0].shape != rho.shape:
        raise QuantumKernelError("Kraus-operator dimension does not match density matrix")
    result = sum((op @ rho @ op.conj().T for op in ops), np.zeros_like(rho))
    return validate_density_matrix(result, atol=1e-8)


def phase_damping_kraus(retention: float) -> list[ComplexArray]:
    if not np.isfinite(retention) or retention < 0 or retention > 1:
        raise QuantumKernelError("phase-damping retention must be between zero and one")
    i2 = np.eye(2, dtype=np.complex128)
    z = np.array([[1, 0], [0, -1]], dtype=np.complex128)
    return [np.sqrt((1 + retention) / 2) * i2, np.sqrt((1 - retention) / 2) * z]


def bit_flip_kraus(probability: float) -> list[ComplexArray]:
    if not np.isfinite(probability) or probability < 0 or probability > 1:
        raise QuantumKernelError("bit-flip probability must be between zero and one")
    i2 = np.eye(2, dtype=np.complex128)
    x = np.array([[0, 1], [1, 0]], dtype=np.complex128)
    return [np.sqrt(1 - probability) * i2, np.sqrt(probability) * x]


def dephase_computational(value: ArrayLike) -> ComplexArray:
    rho = validate_density_matrix(value, atol=1e-9)
    return np.diag(np.diag(rho)).astype(np.complex128)


def concurrence_two_qubit_pure(state: ArrayLike) -> float:
    psi = validate_state(state)
    if psi.size != 4:
        raise QuantumKernelError("two-qubit concurrence requires a four-dimensional state")
    a, b, c, d = psi
    return float(np.clip(2 * abs(a * d - b * c), 0.0, 1.0))


def partial_transpose_two_qubit(value: ArrayLike, *, subsystem: int = 1) -> ComplexArray:
    rho = validate_density_matrix(value, atol=1e-9)
    if rho.shape != (4, 4):
        raise QuantumKernelError("two-qubit partial transpose requires a 4x4 density matrix")
    tensor = rho.reshape(2, 2, 2, 2)
    if subsystem == 0:
        result = tensor.transpose(2, 1, 0, 3)
    elif subsystem == 1:
        result = tensor.transpose(0, 3, 2, 1)
    else:
        raise QuantumKernelError("subsystem must be zero or one")
    return result.reshape(4, 4)


def negativity_two_qubit(value: ArrayLike) -> float:
    pt = partial_transpose_two_qubit(value)
    eigvals = np.linalg.eigvalsh((pt + pt.conj().T) / 2)
    return float(np.sum(np.abs(eigvals[eigvals < 0])))


def optimize_parameter_grid(
    initial_state: ArrayLike,
    operation_factory: Callable[[float], ArrayLike],
    parameter_grid: Iterable[float],
    objective: Callable[[ComplexArray], float],
) -> dict[str, object]:
    psi = validate_state(initial_state)
    grid = [float(x) for x in parameter_grid]
    if len(grid) == 0 or any(not np.isfinite(x) for x in grid):
        raise QuantumKernelError("parameter grid must contain finite values")
    best_parameter: float | None = None
    best_value = -np.inf
    best_state: ComplexArray | None = None
    evaluations: list[dict[str, float]] = []
    for parameter in grid:
        state = apply_unitary(psi, operation_factory(parameter), atol=1e-9)
        value = float(objective(state))
        if not np.isfinite(value):
            raise QuantumKernelError("objective produced a non-finite value")
        evaluations.append({"parameter": parameter, "objective": value})
        if value > best_value:
            best_parameter = parameter
            best_value = value
            best_state = state
    assert best_parameter is not None and best_state is not None
    return {
        "best_parameter": best_parameter,
        "best_objective": float(best_value),
        "best_state": best_state,
        "evaluations": evaluations,
    }


# Fixed, explicit common operators.
I2 = np.eye(2, dtype=np.complex128)
X = np.array([[0, 1], [1, 0]], dtype=np.complex128)
Y = np.array([[0, -1j], [1j, 0]], dtype=np.complex128)
Z = np.array([[1, 0], [0, -1]], dtype=np.complex128)
H = np.array([[1, 1], [1, -1]], dtype=np.complex128) / np.sqrt(2)
CNOT = np.array(
    [[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 0, 1], [0, 0, 1, 0]],
    dtype=np.complex128,
)
