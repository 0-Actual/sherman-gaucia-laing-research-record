#!/usr/bin/env python3
"""QEL Emulated QPU Kernel v1.

Project Quantum.Earth.Laing / Q6.1
Owner-principal: Sherman G. Laing

This module promotes the corrected Generation A simulation suite into a
fail-closed emulator kernel and provides validated primitives needed to migrate
integrated QEL_Emulator Generations B, C, and D.

It is a software/emulation QPU layer. It does not claim physical QPU execution,
quantum advantage, automatic external action, owner acceptance, or an
operator-signed release.
"""
from __future__ import annotations

import dataclasses
import json
import math
import sys
import unicodedata
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from numpy.typing import ArrayLike, NDArray

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
RC1 = ROOT / "vendor" / "rc1"
if str(RC1) not in sys.path:
    sys.path.insert(0, str(RC1))

from qel_quantum_suite_v1 import (  # type: ignore
    CAPABILITIES,
    SUITE_ID,
    capability_catalog,
    run_capability,
)
from sgl_prime.core import canonical_json_bytes, fingerprint, secondary_sha256_witness  # type: ignore

ComplexArray = NDArray[np.complex128]
RealArray = NDArray[np.float64]
ATOL = 1e-10
SCHEMA = "qel.emulated-qpu-kernel/v1"
KERNEL_ID = "QEL-EMULATED-QPU-KERNEL-V1"
PROJECT = "Project Quantum.Earth.Laing / Q6.1"
OWNER = "Sherman G. Laing"


class QPUKernelError(ValueError):
    """Fail-closed emulator-kernel error."""


def _finite_complex_vector(value: ArrayLike, *, name: str = "state") -> ComplexArray:
    arr = np.asarray(value, dtype=np.complex128)
    if arr.ndim != 1 or arr.size == 0:
        raise QPUKernelError(f"{name} must be a non-empty one-dimensional vector")
    if not np.all(np.isfinite(arr.real)) or not np.all(np.isfinite(arr.imag)):
        raise QPUKernelError(f"{name} contains non-finite values")
    return arr.copy()


def _finite_square_matrix(value: ArrayLike, *, name: str = "matrix") -> ComplexArray:
    arr = np.asarray(value, dtype=np.complex128)
    if arr.ndim != 2 or arr.shape[0] == 0 or arr.shape[0] != arr.shape[1]:
        raise QPUKernelError(f"{name} must be a non-empty square matrix")
    if not np.all(np.isfinite(arr.real)) or not np.all(np.isfinite(arr.imag)):
        raise QPUKernelError(f"{name} contains non-finite values")
    return arr.copy()


def _finite_density(value: ArrayLike, *, name: str = "density") -> ComplexArray:
    rho = _finite_square_matrix(value, name=name)
    if not np.allclose(rho, rho.conj().T, atol=ATOL, rtol=ATOL):
        raise QPUKernelError(f"{name} must be Hermitian")
    trace = complex(np.trace(rho))
    if abs(trace.imag) > ATOL or not math.isclose(trace.real, 1.0, abs_tol=ATOL, rel_tol=ATOL):
        raise QPUKernelError(f"{name} must have trace one")
    eig = np.linalg.eigvalsh(rho)
    if float(np.min(eig)) < -ATOL:
        raise QPUKernelError(f"{name} must be positive semidefinite")
    return rho


def normalize_state(value: ArrayLike) -> ComplexArray:
    state = _finite_complex_vector(value)
    n = float(np.linalg.norm(state))
    if not math.isfinite(n) or n <= 0.0:
        raise QPUKernelError("state must have nonzero finite norm")
    return state / n


def probability_sum(value: ArrayLike) -> float:
    state = _finite_complex_vector(value)
    return float(np.sum(np.abs(state) ** 2))


def pure_fidelity(a: ArrayLike, b: ArrayLike) -> float:
    x = normalize_state(a)
    y = normalize_state(b)
    if x.shape != y.shape:
        raise QPUKernelError("state dimensions differ")
    return float(np.clip(abs(np.vdot(x, y)) ** 2, 0.0, 1.0))


def is_unitary(value: ArrayLike, *, tol: float = ATOL) -> bool:
    matrix = _finite_square_matrix(value)
    ident = np.eye(matrix.shape[0], dtype=np.complex128)
    return bool(np.allclose(matrix.conj().T @ matrix, ident, atol=tol, rtol=tol))


def is_hermitian(value: ArrayLike, *, tol: float = ATOL) -> bool:
    matrix = _finite_square_matrix(value)
    return bool(np.allclose(matrix, matrix.conj().T, atol=tol, rtol=tol))


def _validate_num_qubits(num_qubits: int) -> int:
    if isinstance(num_qubits, bool) or not isinstance(num_qubits, int) or num_qubits < 1:
        raise QPUKernelError("num_qubits must be a positive integer")
    return num_qubits


def _qubit_count_from_dimension(dimension: int) -> int:
    if isinstance(dimension, bool) or not isinstance(dimension, int) or dimension < 2:
        raise QPUKernelError("dimension must be an integer power of two >= 2")
    qubits = int(round(math.log2(dimension)))
    if 1 << qubits != dimension:
        raise QPUKernelError("dimension must be a power of two")
    return qubits


def prepare_basis_state(num_qubits: int, index: int) -> ComplexArray:
    num_qubits = _validate_num_qubits(num_qubits)
    dimension = 1 << num_qubits
    if isinstance(index, bool) or not isinstance(index, int) or not 0 <= index < dimension:
        raise QPUKernelError("basis index outside state dimension")
    state = np.zeros(dimension, dtype=np.complex128)
    state[index] = 1.0
    return state


def prepare_uniform_state(num_qubits: int) -> ComplexArray:
    num_qubits = _validate_num_qubits(num_qubits)
    dimension = 1 << num_qubits
    return np.ones(dimension, dtype=np.complex128) / math.sqrt(dimension)


def prepare_ghz_state(num_qubits: int) -> ComplexArray:
    state = prepare_basis_state(num_qubits, 0)
    state[-1] = 1.0
    return state / math.sqrt(2.0)


def expand_single_qubit_gate(gate: ArrayLike, target_qubit: int, num_qubits: int) -> ComplexArray:
    num_qubits = _validate_num_qubits(num_qubits)
    g = _finite_square_matrix(gate, name="gate")
    if g.shape != (2, 2) or not is_unitary(g):
        raise QPUKernelError("gate must be a finite 2x2 unitary")
    if isinstance(target_qubit, bool) or not isinstance(target_qubit, int) or not 0 <= target_qubit < num_qubits:
        raise QPUKernelError("invalid target qubit")
    out = np.array([[1.0 + 0.0j]], dtype=np.complex128)
    for q in range(num_qubits):
        out = np.kron(out, g if q == target_qubit else np.eye(2, dtype=np.complex128))
    return out


def apply_unitary(state: ArrayLike, unitary: ArrayLike) -> ComplexArray:
    psi = normalize_state(state)
    u = _finite_square_matrix(unitary, name="unitary")
    if u.shape[0] != psi.size:
        raise QPUKernelError("unitary/state dimension mismatch")
    if not is_unitary(u):
        raise QPUKernelError("operation must be unitary")
    out = u @ psi
    if not math.isclose(probability_sum(out), 1.0, abs_tol=ATOL, rel_tol=ATOL):
        raise QPUKernelError("unitary operation did not preserve probability")
    return out


def apply_unitary_sequence(state: ArrayLike, unitaries: Sequence[ArrayLike]) -> ComplexArray:
    if not unitaries:
        raise QPUKernelError("unitary sequence must not be empty")
    out = normalize_state(state)
    for unitary in unitaries:
        out = apply_unitary(out, unitary)
    return out


def reverse_unitary_sequence(state_after: ArrayLike, unitaries: Sequence[ArrayLike]) -> ComplexArray:
    if not unitaries:
        raise QPUKernelError("unitary sequence must not be empty")
    out = normalize_state(state_after)
    for unitary in reversed(unitaries):
        u = _finite_square_matrix(unitary, name="unitary")
        if not is_unitary(u):
            raise QPUKernelError("every reverse operation requires a unitary")
        out = apply_unitary(out, u.conj().T)
    return out


@dataclass(frozen=True)
class GateCandidate:
    name: str
    gate: ComplexArray
    target_qubit: int


@dataclass(frozen=True)
class AdaptivePlacementReceipt:
    initial_fidelity: float
    final_fidelity: float
    applied: tuple[dict[str, Any], ...]
    evaluated_candidates: int
    final_state: ComplexArray


def adaptive_gate_placement(
    state: ArrayLike,
    target_state: ArrayLike,
    num_qubits: int,
    candidates: Sequence[GateCandidate],
    *,
    minimum_gain: float = 1e-12,
    max_depth: int | None = None,
    beam_width: int = 64,
) -> AdaptivePlacementReceipt:
    """Bounded look-ahead gate placement with explicit fidelity objective.

    Each candidate can be used at most once. The search preserves a bounded
    beam of the most promising partial sequences, so it can discover multi-step
    improvements even when no single gate improves the target fidelity.
    """
    current = normalize_state(state)
    target = normalize_state(target_state)
    if current.size != (1 << num_qubits) or target.shape != current.shape:
        raise QPUKernelError("state/target dimensions do not match num_qubits")
    if not candidates:
        raise QPUKernelError("at least one gate candidate is required")
    if isinstance(beam_width, bool) or not isinstance(beam_width, int) or beam_width < 1:
        raise QPUKernelError("beam_width must be a positive integer")
    if max_depth is None:
        depth_limit = len(candidates)
    else:
        if isinstance(max_depth, bool) or not isinstance(max_depth, int):
            raise QPUKernelError("max_depth must be an integer")
        depth_limit = max_depth
    if depth_limit < 1 or depth_limit > len(candidates):
        raise QPUKernelError("max_depth must be in [1, len(candidates)]")

    expanded: list[tuple[str, int, ComplexArray]] = []
    for candidate in candidates:
        full = expand_single_qubit_gate(candidate.gate, candidate.target_qubit, num_qubits)
        expanded.append((candidate.name, candidate.target_qubit, full))

    initial = pure_fidelity(current, target)
    # frontier item: (score, index_path, state, step_receipts)
    frontier: list[tuple[float, tuple[int, ...], ComplexArray, tuple[dict[str, Any], ...]]] = [
        (initial, tuple(), current, tuple())
    ]
    best = frontier[0]
    evaluated = 0

    for _depth in range(1, depth_limit + 1):
        next_frontier: list[tuple[float, tuple[int, ...], ComplexArray, tuple[dict[str, Any], ...]]] = []
        for score_before, path, state_before, receipts in frontier:
            used = set(path)
            for idx, (name, target_qubit, full) in enumerate(expanded):
                if idx in used:
                    continue
                proposal = apply_unitary(state_before, full)
                score_after = pure_fidelity(proposal, target)
                evaluated += 1
                step = {
                    "name": name,
                    "target_qubit": target_qubit,
                    "fidelity_before": score_before,
                    "fidelity_after": score_after,
                    "unitary_defect": float(
                        np.linalg.norm(full.conj().T @ full - np.eye(full.shape[0]))
                    ),
                }
                item = (score_after, path + (idx,), proposal, receipts + (step,))
                next_frontier.append(item)
                if score_after > best[0] + minimum_gain or (
                    math.isclose(score_after, best[0], abs_tol=minimum_gain, rel_tol=0.0)
                    and item[1] < best[1]
                ):
                    best = item
        if not next_frontier:
            break
        next_frontier.sort(key=lambda item: (-item[0], item[1]))
        frontier = next_frontier[:beam_width]

    if best[0] <= initial + minimum_gain:
        return AdaptivePlacementReceipt(initial, initial, tuple(), evaluated, current)
    return AdaptivePlacementReceipt(initial, best[0], best[3], evaluated, best[2])

def phase_gradient(state: ArrayLike, gradient_factor: float) -> tuple[ComplexArray, ComplexArray]:
    psi = normalize_state(state)
    factor = float(gradient_factor)
    if not math.isfinite(factor):
        raise QPUKernelError("gradient factor must be finite")
    phases = np.exp(1j * factor * np.arange(psi.size, dtype=np.float64))
    unitary = np.diag(phases.astype(np.complex128))
    return apply_unitary(psi, unitary), unitary


def verify_in_bases(state: ArrayLike, bases: Mapping[str, ArrayLike]) -> dict[str, Any]:
    psi = normalize_state(state)
    if not bases:
        raise QPUKernelError("at least one basis is required")
    results: dict[str, Any] = {}
    for name, raw_basis in bases.items():
        basis = _finite_square_matrix(raw_basis, name=f"basis {name}")
        if basis.shape[0] != psi.size or not is_unitary(basis):
            raise QPUKernelError(f"basis {name!r} must be a matching unitary/orthonormal basis")
        coordinates = basis.conj().T @ psi
        probabilities = np.abs(coordinates) ** 2
        results[str(name)] = {
            "probabilities": probabilities.astype(float).tolist(),
            "probability_sum": float(np.sum(probabilities)),
            "maximum_probability": float(np.max(probabilities)),
            "argmax": int(np.argmax(probabilities)),
        }
    return results


def dephasing_channel(density: ArrayLike, retention: float) -> ComplexArray:
    rho = _finite_density(density)
    eta = float(retention)
    if not math.isfinite(eta) or not 0.0 <= eta <= 1.0:
        raise QPUKernelError("retention must be finite and in [0,1]")
    diagonal = np.diag(np.diag(rho))
    out = eta * rho + (1.0 - eta) * diagonal
    return _finite_density(out)


def amplitude_damping_channel(density: ArrayLike, gamma: float) -> ComplexArray:
    rho = _finite_density(density)
    if rho.shape != (2, 2):
        raise QPUKernelError("amplitude damping v1 supports one qubit")
    g = float(gamma)
    if not math.isfinite(g) or not 0.0 <= g <= 1.0:
        raise QPUKernelError("gamma must be finite and in [0,1]")
    k0 = np.array([[1.0, 0.0], [0.0, math.sqrt(1.0 - g)]], dtype=np.complex128)
    k1 = np.array([[0.0, math.sqrt(g)], [0.0, 0.0]], dtype=np.complex128)
    out = k0 @ rho @ k0.conj().T + k1 @ rho @ k1.conj().T
    return _finite_density(out)


def measure_qubit(
    state: ArrayLike,
    num_qubits: int,
    qubit_index: int,
    *,
    seed: int | None = None,
    draw: float | None = None,
) -> dict[str, Any]:
    psi = normalize_state(state)
    num_qubits = _validate_num_qubits(num_qubits)
    if psi.size != (1 << num_qubits):
        raise QPUKernelError("state dimension mismatch")
    if isinstance(qubit_index, bool) or not isinstance(qubit_index, int) or not 0 <= qubit_index < num_qubits:
        raise QPUKernelError("invalid qubit index")
    shift = num_qubits - 1 - qubit_index
    masks = np.array([((idx >> shift) & 1) for idx in range(psi.size)], dtype=np.int8)
    p1 = float(np.sum(np.abs(psi[masks == 1]) ** 2))
    p0 = 1.0 - p1
    if draw is None:
        draw = float(np.random.default_rng(seed).random())
    draw_value = float(draw)
    if not 0.0 <= draw_value < 1.0:
        raise QPUKernelError("draw must be in [0,1)")
    outcome = 0 if draw_value < p0 else 1
    selected = masks == outcome
    probability = p0 if outcome == 0 else p1
    if probability <= ATOL:
        raise QPUKernelError("selected zero-probability outcome")
    post = np.where(selected, psi, 0.0) / math.sqrt(probability)
    return {
        "outcome": outcome,
        "probabilities": [p0, p1],
        "draw": draw_value,
        "post_state": post,
        "post_probability_sum": probability_sum(post),
        "selective_measurement": True,
    }


def controlled_phase_kickback(
    state: ArrayLike,
    num_qubits: int,
    control_qubit: int,
    target_qubit: int,
    phase: float,
) -> tuple[ComplexArray, ComplexArray]:
    psi = normalize_state(state)
    num_qubits = _validate_num_qubits(num_qubits)
    if psi.size != (1 << num_qubits):
        raise QPUKernelError("state dimension mismatch")
    if isinstance(control_qubit, bool) or not isinstance(control_qubit, int):
        raise QPUKernelError("control qubit must be an integer")
    if isinstance(target_qubit, bool) or not isinstance(target_qubit, int):
        raise QPUKernelError("target qubit must be an integer")
    if control_qubit == target_qubit:
        raise QPUKernelError("control and target must differ")
    if not 0 <= control_qubit < num_qubits or not 0 <= target_qubit < num_qubits:
        raise QPUKernelError("invalid control or target qubit")
    phi = float(phase)
    if not math.isfinite(phi):
        raise QPUKernelError("phase must be finite")
    diag = np.ones(psi.size, dtype=np.complex128)
    c_shift = num_qubits - 1 - control_qubit
    t_shift = num_qubits - 1 - target_qubit
    for idx in range(psi.size):
        if ((idx >> c_shift) & 1) and ((idx >> t_shift) & 1):
            diag[idx] = np.exp(1j * phi)
    unitary = np.diag(diag)
    return apply_unitary(psi, unitary), unitary


def resource_estimate(*, num_qubits: int, gate_count: int, depth: int | None = None, measurement_count: int = 0) -> dict[str, Any]:
    if any(isinstance(v, bool) or not isinstance(v, int) or v < 0 for v in (num_qubits, gate_count, measurement_count)):
        raise QPUKernelError("resource counts must be nonnegative integers")
    if num_qubits < 1:
        raise QPUKernelError("num_qubits must be positive")
    if depth is None:
        depth = gate_count
    if isinstance(depth, bool) or not isinstance(depth, int) or depth < 0:
        raise QPUKernelError("depth must be a nonnegative integer")
    dimension = 1 << num_qubits
    statevector_bytes = dimension * np.dtype(np.complex128).itemsize
    density_bytes = dimension * dimension * np.dtype(np.complex128).itemsize
    return {
        "num_qubits": num_qubits,
        "state_dimension": dimension,
        "gate_count": gate_count,
        "depth": depth,
        "measurement_count": measurement_count,
        "statevector_bytes": statevector_bytes,
        "density_matrix_bytes": density_bytes,
        "physical_energy_cost": "NOT_MODELED",
        "hardware_runtime": "NOT_MODELED",
    }


def run_generation_a_capability(identifier: str | int) -> dict[str, Any]:
    return run_capability(identifier)


def suite_catalog() -> list[dict[str, Any]]:
    return capability_catalog()


def _json_safe(value: Any) -> Any:
    if dataclasses.is_dataclass(value):
        return _json_safe(dataclasses.asdict(value))
    if isinstance(value, np.ndarray):
        if np.iscomplexobj(value):
            return _json_safe({"real": value.real.tolist(), "imag": value.imag.tolist(), "shape": list(value.shape)})
        return _json_safe(value.tolist())
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if isinstance(value, complex):
        return {"real": _json_safe(float(value.real)), "imag": _json_safe(float(value.imag))}
    if isinstance(value, Mapping):
        return {str(k): _json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_safe(v) for v in value]
    if isinstance(value, float):
        if not math.isfinite(value):
            raise QPUKernelError("non-finite value cannot enter a receipt")
        return repr(0.0 if value == 0.0 else value)
    if isinstance(value, (str, int, bool)) or value is None:
        return value
    raise QPUKernelError(f"unsupported receipt type: {type(value).__name__}")


def integrity_receipt(payload: Any, purpose: str) -> dict[str, Any]:
    normalized_purpose = unicodedata.normalize("NFC", str(purpose)).strip()
    if not normalized_purpose:
        raise QPUKernelError("purpose is required")
    body = {
        "schema": SCHEMA,
        "kernel_id": KERNEL_ID,
        "generation_a_suite_id": SUITE_ID,
        "project": PROJECT,
        "owner_principal": OWNER,
        "payload": _json_safe(payload),
        "automatic_execution": False,
        "physical_qpu_execution_claimed": False,
    }
    body_bytes = canonical_json_bytes(body)
    return {
        **body,
        "primary_identity": fingerprint(body_bytes, normalized_purpose),
        "secondary_witness": secondary_sha256_witness(body_bytes),
        "secondary_witness_authorization_allowed": False,
    }


def kernel_manifest() -> dict[str, Any]:
    manifest = {
        "schema": SCHEMA,
        "kernel_id": KERNEL_ID,
        "project": PROJECT,
        "owner_principal": OWNER,
        "generation_a_suite_id": SUITE_ID,
        "generation_a_capabilities": len(CAPABILITIES),
        "validated_primitives": [
            "basis_state_preparation",
            "uniform_state_preparation",
            "ghz_state_preparation",
            "unitary_application",
            "unitary_sequence_and_reverse",
            "bounded_lookahead_adaptive_gate_placement",
            "basis_index_phase_gradient",
            "multi_basis_probability_verification",
            "dephasing_channel",
            "amplitude_damping_channel",
            "general_selective_qubit_measurement",
            "controlled_relative_phase_kickback",
            "resource_estimation",
            "sgl_prime_integrity_receipts",
        ],
        "claim_boundary": {
            "accepted": "QEL_EMULATED_QPU_SOFTWARE_KERNEL",
            "not_claimed": [
                "physical hardware QPU execution",
                "quantum advantage",
                "owner-accepted sovereign release",
                "automatic external action",
                "exact B-C-D historical source-byte closure",
            ],
        },
        "automatic_execution": False,
    }
    return integrity_receipt(manifest, "qel-emulated-qpu-kernel-manifest-v1")


if __name__ == "__main__":
    print(json.dumps(kernel_manifest(), indent=2, sort_keys=True))
