// Adaptive follow-up only: original aluminum point 4. Initial benchmark is preserved.
import fs from 'node:fs';import path from 'node:path';import vm from 'node:vm';import {fileURLToPath} from 'node:url';import {performance} from 'node:perf_hooks';
const root=path.dirname(fileURLToPath(import.meta.url)),mirror=process.argv[3],label=process.argv[2];
if(!/^stage2_0[12]$/.test(label)||!mirror)throw Error('Expected unique followup label and mirror');
for(const r of [root,mirror])fs.mkdirSync(path.join(r,label));
function save(name,obj){const b=Buffer.from(JSON.stringify(obj,null,2)+'\n');for(const r of [root,mirror]){const p=path.join(r,label,name);fs.writeFileSync(p,b,{flag:'wx'});if(!b.equals(fs.readFileSync(p)))throw Error('Readback failed');}}
const start=performance.now(),cpu=process.cpuUsage(),at=new Date().toISOString();
try{
 const cfg=JSON.parse(fs.readFileSync(path.join(root,'FOLLOWUP_STAGE2_CONTRACT.json'),'utf8'));save('contract.json',cfg);
 const context=vm.createContext({},{codeGeneration:{strings:false,wasm:false}}),cache=new Map(),allow=new Set(['compute.mjs','vendor/quantum.mjs','vendor/vendor/qel60_sop.mjs']);
 async function load(rel){if(!allow.has(rel))throw Error('Import outside allowlist');if(cache.has(rel))return cache.get(rel);const m=new vm.SourceTextModule(fs.readFileSync(path.join(root,rel),'utf8'),{context,identifier:rel});cache.set(rel,m);await m.link((s,p)=>{if(!s.startsWith('./'))throw Error('External import');return load(path.posix.normalize(path.posix.join(path.posix.dirname(p.identifier),s)));});return m;}
 const m=await load('compute.mjs');await m.evaluate({timeout:5000});const math=m.namespace;
 const fixture=JSON.parse(fs.readFileSync(path.join(root,'inputs/hamiltonians_24x8x8.json'),'utf8')),H=fixture.rows[4].matrix_ev;
 const prediction=math.optimize(H,cfg.budget_change,cfg.seed);save('prediction.json',prediction);
 const reference=math.jacobi(H),gap=prediction.final_energy_ev-reference.eigenvalues[0];
 const correct=prediction.starts.every(s=>s.final_energy_ev<=s.initial_energy_ev+1e-9&&s.history.every(h=>h.improvement_ev>=-1e-9)&&s.max_amplitude_error<=2e-10&&s.dense_energy_error_ev<=1e-9)&&gap>=-1e-8;
 const result={owner:cfg.owner,hamiltonian_index:4,kind:'adaptive follow-up of original point',initial_cycle_gap_ev:cfg.observed_gap_ev,followup_gap_ev:gap,ground_reference_ev:reference.eigenvalues[0],final_energy_ev:prediction.final_energy_ev,goal_ev:cfg.target_gap_ev,goal_pass:gap<=cfg.target_gap_ev,correctness_pass:correct,improvement_factor:cfg.observed_gap_ev/gap,total_evaluations:prediction.total_evaluations,signature:'UNSIGNED'};save('result.json',result);
 if(!correct)throw Error('Follow-up numerical correctness failed');
 save('execution.json',{started_utc:at,finished_utc:new Date().toISOString(),elapsed_ms:performance.now()-start,cpu_microseconds:process.cpuUsage(cpu),memory:process.memoryUsage(),resource_usage:process.resourceUsage(),node:process.version,platform:process.platform});
 console.log(JSON.stringify(result));
}catch(e){save('failure.json',{error:String(e),stack:e.stack});console.error(e);process.exitCode=1;}
