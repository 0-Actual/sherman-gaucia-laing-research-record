import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import assert from 'node:assert/strict';
const base=String.raw`./REDACTED_LOCAL_ROOT/QEL_Q7\Owner_Backups\20260918\QEL_Live_Qubit_Scaling_20260918_`;
const read=p=>JSON.parse(fs.readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const findings=[],rows=[],executions=[],sourceChecks=[];
for(const attempt of ['02','03']){
 const root=base+attempt,report=read(path.join(root,'LIVE_SCALING_RESULTS.json'));
 for(const r of report.trial_records){
  const suffix=String(r.n).padStart(2,'0')+'_'+r.trial+'.json',raw=read(path.join(root,'result_'+suffix)),ex=read(path.join(root,'execution_'+suffix));
  try{assert.deepStrictEqual(r,raw);assert.deepStrictEqual(raw,JSON.parse(ex.stdout.trim()));}catch(e){findings.push({attempt,n:r.n,trial:r.trial,issue:'Structural record comparison differs',detail:e.message});}
  if(ex.exit_code!==0||ex.stderr||ex.timed_out===true||ex.error)findings.push({attempt,n:r.n,trial:r.trial,issue:'Execution failure metadata',ex});
  rows.push({...raw,attempt});executions.push(ex);
 }
 const prov=read(path.join(root,'SOURCE_PROVENANCE.json')),saved=fs.readFileSync(path.join(root,'original_emulator_source.mjs')),current=fs.readFileSync(prov.source);
 const lines=current.toString('utf8').split(/\r?\n/),defs=prov.extracted_function_names.map(n=>lines.filter(l=>l.startsWith('function '+n+'(')));
 sourceChecks.push({attempt,source:prov.source,original_bytes:saved.length,current_bytes:current.length,original_equals_current:saved.equals(current),definitions_exact:defs.every((x,i)=>x.length===1&&x[0]===prov.definitions[i]),kernel_exact:fs.readFileSync(path.join(root,'kernel_functions.js'),'utf8')===prov.definitions.join('\n')+'\n'});
}
const passed=rows.filter(r=>r.status==='PASS'),sizes=[...new Set(passed.map(r=>r.n))].sort((a,b)=>a-b),checkNames=['finite','expected_ghz','two_ghz_branches','ghz_normalization','basis_return','dense_finite','dense_normalization','dense_return','dense_full_support'];
const stats=a=>{const v=[...a].sort((x,y)=>x-y);return {count:v.length,min:v[0],median:v[Math.floor(v.length/2)],max:v.at(-1)};};
const summary={reviewed_utc:new Date().toISOString(),review_host:os.hostname(),method:'Read-only aggregate review of fresh attempts 02 and 03; no additional benchmarks; exact bytes compared without hashes',findings,source_checks:sourceChecks,child_records:rows.length,completed_pass_trials:passed.length,completed_sizes:sizes,largest_completed_qubits:Math.max(...sizes),check_results:checkNames.map(name=>({name,passed:passed.filter(r=>r.checks[name]===true).length,total:passed.length})),all_nine_checks_pass:passed.every(r=>checkNames.every(n=>r.checks[n]===true)),max_errors:Object.fromEntries(Object.keys(passed[0].errors).map(k=>[k,Math.max(...passed.map(r=>r.errors[k]))])),peak_rss_sampled_bytes:Math.max(...passed.map(r=>r.peak_rss_sampled_bytes)),peak_resource_max_rss_kib:Math.max(...passed.map(r=>r.resource_max_rss_kib_reported)),minimum_sampled_free_bytes:Math.min(...passed.flatMap(r=>['before','after_allocation','after_forward','after_ghz','after'].map(k=>r[k].free_physical_bytes))),stop_records:rows.filter(r=>r.status!=='PASS'),timings_by_size:Object.fromEntries([20,21].map(n=>{const a=passed.filter(r=>r.n===n);return [n,{state_bytes:a[0].state_bytes,dimension:a[0].dimension,timings_ms:Object.fromEntries(Object.keys(a[0].timings_ms).map(k=>[k,stats(a.map(r=>r.timings_ms[k]))])),peak_rss_sampled_bytes:Math.max(...a.map(r=>r.peak_rss_sampled_bytes)),peak_resource_max_rss_kib:Math.max(...a.map(r=>r.resource_max_rss_kib_reported))}]})),limitations:['The nine checks are repeated assertions per trial, not 225 distinct scientific tests.','The largest passing size is workload- and available-memory-specific.','Twenty-two qubits was not admitted and is not a numerical failure.','The full-support complex input has a structured four-phase pattern, not arbitrary random amplitudes.','Attempt 03 report device field is null; review host and attempt 02 confirm the laptop.','No owner signature or new integrity hash was generated.']};
summary.review_pass=findings.length===0&&summary.all_nine_checks_pass&&sourceChecks.every(r=>r.original_equals_current&&r.definitions_exact&&r.kernel_exact)&&summary.minimum_sampled_free_bytes>=256*1048576;
fs.writeFileSync(path.join(base+'03','INDEPENDENT_REVIEW.json'),JSON.stringify(summary,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify(summary,null,2));process.exitCode=summary.review_pass?0:1;
