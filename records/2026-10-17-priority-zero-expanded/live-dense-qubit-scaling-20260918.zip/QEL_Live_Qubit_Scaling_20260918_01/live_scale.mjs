import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
const scriptPath=fileURLToPath(import.meta.url),root=path.dirname(scriptPath);
const sourcePath=String.raw`./REDACTED_LOCAL_ROOT/QEL_Q7\Forensics\Q7_PRESENT_DAY_MEASUREMENT_20260910_C053\q7-emulation-envelope-c055.mjs`;
const MiB=1048576, reserve=256*MiB, allowance=64*MiB, tolerance=1e-12;
const snap=()=>({utc:new Date().toISOString(),free_physical_bytes:os.freemem(),rss_bytes:process.memoryUsage().rss,array_buffer_bytes:process.memoryUsage().arrayBuffers,resource_max_rss_kib:process.resourceUsage().maxRSS});
const write=(name,value)=>fs.writeFileSync(path.join(root,name),JSON.stringify(value,null,2)+'\n',{flag:'wx'});
if(process.argv[2]==='trial'){
  const n=Number(process.argv[3]),trial=Number(process.argv[4]);
  if(!Number.isInteger(n)||n<1||n>30)throw Error('Qubit count outside reviewed bitshift range');
  const dimension=2**n,bytes=dimension*16,start=snap(),required=bytes+reserve+allowance;
  if(start.free_physical_bytes<required){console.log(JSON.stringify({status:'RESOURCE_NOT_ADMITTED',n,trial,dimension,state_bytes:bytes,required_free_bytes:required,before:start}));process.exit(0);}
  const kernel=fs.readFileSync(path.join(root,'kernel_functions.js'),'utf8');
  const {state,ghz,inverse,norm}=new vm.Script(kernel+'\n;({state,ghz,inverse,norm})').runInNewContext({Float64Array,Math},{timeout:1000,contextCodeGeneration:{strings:false,wasm:false}});
  const t0=performance.now();let s;
  try{s=state(n);}catch(e){console.log(JSON.stringify({status:'ALLOCATION_FAILED',n,trial,error:e.message,before:start}));process.exit(1);}
  if(s.re.length!==dimension||s.im.length!==dimension||s.re.byteLength+s.im.byteLength!==bytes)throw Error('Actual state size mismatch');
  const allocated=snap(),t1=performance.now();ghz(s,n);const t2=performance.now();
  const afterForward=snap();let finite=true,maxGhzError=0,populated=0,ghzNorm=0;
  for(let i=0;i<dimension;i++){const a=s.re[i],b=s.im[i],expected=i===0||i===dimension-1?Math.SQRT1_2:0;finite=finite&&Number.isFinite(a)&&Number.isFinite(b);maxGhzError=Math.max(maxGhzError,Math.abs(a-expected),Math.abs(b));const p=a*a+b*b;ghzNorm+=p;if(p>tolerance)populated++;}
  const t3=performance.now();inverse(s,n);const t4=performance.now();let maxBasisReturn=0;
  for(let i=0;i<dimension;i++)maxBasisReturn=Math.max(maxBasisReturn,Math.abs(s.re[i]-(i===0?1:0)),Math.abs(s.im[i]));
  const t5=performance.now(),afterGhz=snap();
  if(Math.min(afterForward.free_physical_bytes,afterGhz.free_physical_bytes)<reserve){console.log(JSON.stringify({status:'RESOURCE_RESERVE_STOP',n,trial,state_bytes:bytes,before:start,after_forward:afterForward,after_ghz:afterGhz}));process.exit(0);}
  const amplitude=1/Math.sqrt(dimension);
  for(let i=0;i<dimension;i++){const phase=i&3;s.re[i]=phase===0?amplitude:phase===2?-amplitude:0;s.im[i]=phase===1?amplitude:phase===3?-amplitude:0;}
  const t6=performance.now();ghz(s,n);const t7=performance.now();const denseNorm=norm(s);const t8=performance.now();inverse(s,n);const t9=performance.now();
  let maxDenseReturn=0,denseFinite=true,restoredNonzero=0;
  for(let i=0;i<dimension;i++){const phase=i&3,er=phase===0?amplitude:phase===2?-amplitude:0,ei=phase===1?amplitude:phase===3?-amplitude:0;maxDenseReturn=Math.max(maxDenseReturn,Math.abs(s.re[i]-er),Math.abs(s.im[i]-ei));denseFinite=denseFinite&&Number.isFinite(s.re[i])&&Number.isFinite(s.im[i]);if(s.re[i]!==0||s.im[i]!==0)restoredNonzero++;}
  const end=snap(),t10=performance.now();
  const checks={finite,expected_ghz:maxGhzError<=tolerance,two_ghz_branches:populated===2,ghz_normalization:Math.abs(ghzNorm-1)<=tolerance,basis_return:maxBasisReturn<=tolerance,dense_finite:denseFinite,dense_normalization:Math.abs(denseNorm-1)<=tolerance,dense_return:maxDenseReturn<=tolerance,dense_full_support:restoredNonzero===dimension};
  const numericalPass=Object.values(checks).every(Boolean),resourcePass=end.free_physical_bytes>=reserve;
  console.log(JSON.stringify({status:!numericalPass?'NUMERICAL_FAIL':!resourcePass?'RESOURCE_RESERVE_STOP':'PASS',n,trial,dimension,state_bytes:bytes,tolerance,checks,errors:{ghz_amplitude:maxGhzError,ghz_norm:Math.abs(ghzNorm-1),basis_return:maxBasisReturn,dense_norm:Math.abs(denseNorm-1),dense_return:maxDenseReturn},timings_ms:{allocation:t1-t0,ghz_forward:t2-t1,ghz_inspection:t3-t2,ghz_inverse:t4-t3,basis_inspection:t5-t4,dense_initialization:t6-t5,dense_forward:t7-t6,dense_norm_scan:t8-t7,dense_inverse:t9-t8,dense_inspection:t10-t9,total:t10-t0},before:start,after_allocation:allocated,after_forward:afterForward,after_ghz:afterGhz,after:end,peak_rss_sampled_bytes:Math.max(start.rss_bytes,allocated.rss_bytes,afterForward.rss_bytes,afterGhz.rss_bytes,end.rss_bytes),resource_max_rss_kib_reported:end.resource_max_rss_kib,network_calls:0}));
  process.exit(numericalPass?0:1);
}
const begin=snap(),source=fs.readFileSync(sourcePath);
fs.writeFileSync(path.join(root,'original_emulator_source.mjs'),source,{flag:'wx'});
const names=['state','h','cx','norm','ghz','inverse'];
const definitions=names.map(name=>{const found=source.toString('utf8').split(/\r?\n/).filter(line=>line.startsWith('function '+name+'('));if(found.length!==1)throw Error('Ambiguous source function '+name);return found[0];});
fs.writeFileSync(path.join(root,'kernel_functions.js'),definitions.join('\n')+'\n',{flag:'wx'});
write('SOURCE_PROVENANCE.json',{source:sourcePath,bytes:source.length,extracted_function_names:names,definitions,method:'exact original function lines; production top-level runner not executed'});
const trials=[],admissions=[];let stop=null;
outer:for(let n=1;n<=30;n++){
  const count=n>=20?3:1;
  for(let trial=1;trial<=count;trial++){
    const stateBytes=16*2**n,available=os.freemem(),required=stateBytes+reserve+allowance;
    admissions.push({n,trial,observed_utc:new Date().toISOString(),available_bytes:available,required_bytes:required,state_bytes:stateBytes});
    if(available<required){stop={status:'RESOURCE_NOT_ADMITTED',stage:'parent',n,trial,available_bytes:available,required_bytes:required,state_bytes:stateBytes};break outer;}
    const flags=['--max-old-space-size=64','--permission','--allow-fs-read='+root,scriptPath,'trial',String(n),String(trial)];
    const launchStart=new Date().toISOString(),launchClock=performance.now();
    const child=spawnSync(process.execPath,flags,{encoding:'utf8',timeout:30000,maxBuffer:1048576,windowsHide:true});
    const envelope={n,trial,started_utc:launchStart,ended_utc:new Date().toISOString(),wall_ms:performance.now()-launchClock,exit_code:child.status,signal:child.signal,error:child.error?.message??null,stdout:child.stdout,stderr:child.stderr};
    write('execution_'+String(n).padStart(2,'0')+'_'+trial+'.json',envelope);
    let result;try{result=JSON.parse(child.stdout.trim());}catch(e){stop={status:'EXECUTION_FAILED',n,trial,error:child.error?.message??e.message};break outer;}
    trials.push(result);write('result_'+String(n).padStart(2,'0')+'_'+trial+'.json',result);
    console.log(JSON.stringify({n,trial,status:result.status,state_mib:stateBytes/MiB,elapsed_ms:result.timings_ms?.total,free_mib:result.after?.free_physical_bytes/MiB}));
    if(result.status!=='PASS'||child.status!==0){stop={...result,exit_code:child.status};break outer;}
  }
}
const passed=trials.filter(t=>t.status==='PASS'),sizes=[...new Set(passed.map(t=>t.n))],sourceUnchanged=source.equals(fs.readFileSync(sourcePath));
const report={agent:'GAUCIA',owner:'Sherman G. Laing',started:begin,completed:snap(),device:os.hostname(),node_version:process.version,platform:process.platform,total_physical_memory_bytes:os.totalmem(),workload:'original H/CX GHZ forward/inverse and full-support four-phase complex state forward/inverse',reserve_bytes:reserve,allowance_bytes:allowance,tolerance,attempted_trials:trials.length,passed_trials:passed.length,passed_sizes:sizes,largest_completed_qubits:sizes.length?Math.max(...sizes):null,stop,source_unchanged:sourceUnchanged,trial_records:trials,admissions,scope:'fresh classical statevector workload; no dense operators, general maximum, physical QPU, or speedup claim',new_hashes_generated:false,owner_signature:null};
write('LIVE_SCALING_RESULTS.json',report);
console.log(JSON.stringify({complete:true,largest_completed_qubits:report.largest_completed_qubits,passed_trials:passed.length,passed_sizes:sizes,stop,source_unchanged:sourceUnchanged}));
if(!sourceUnchanged||passed.length===0)process.exitCode=1;

