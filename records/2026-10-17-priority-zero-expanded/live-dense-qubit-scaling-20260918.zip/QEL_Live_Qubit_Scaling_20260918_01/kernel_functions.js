function state(n){const re=new Float64Array(1<<n),im=new Float64Array(1<<n);re[0]=1;return {re,im};}
function h(s,n,q){const bit=1<<(n-1-q),k=Math.SQRT1_2,re=s.re,im=s.im;for(let base=0;base<re.length;base+=2*bit){const end=base+bit;for(let i=base;i<end;i++){const j=i+bit,ar=re[i],ai=im[i],br=re[j],bi=im[j];re[i]=(ar+br)*k;im[i]=(ai+bi)*k;re[j]=(ar-br)*k;im[j]=(ai-bi)*k;}}}
function cx(s,n,c,t){const cb=1<<(n-1-c),tb=1<<(n-1-t),hi=Math.max(cb,tb),lo=Math.min(cb,tb),re=s.re,im=s.im;for(let base=0;base<re.length;base+=2*hi)for(let middle=0;middle<hi;middle+=2*lo){const start=base+middle+cb,end=start+lo;for(let i=start;i<end;i++){const j=i+tb,ar=re[i],ai=im[i];re[i]=re[j];im[i]=im[j];re[j]=ar;im[j]=ai;}}}
function norm(s){let v=0;for(let i=0;i<s.re.length;i++)v+=s.re[i]*s.re[i]+s.im[i]*s.im[i];return v;}
function ghz(s,n){h(s,n,0);for(let q=1;q<n;q++)cx(s,n,0,q);}
function inverse(s,n){for(let q=n-1;q>=1;q--)cx(s,n,0,q);h(s,n,0);}
