import fs from 'node:fs';
import os from 'node:os';
import {performance} from 'node:perf_hooks';
const OUT='./REDACTED_LOCAL_ROOT/QEL_Q7\\Forensics\\Q7_PRESENT_DAY_MEASUREMENT_20260910_C053\\Q7_EMULATION_ENVELOPE_C055.json';
const TOL=1e-12;
function state(n){const re=new Float64Array(1<<n),im=new Float64Array(1<<n);re[0]=1;return {re,im};}
function h(s,n,q){const bit=1<<(n-1-q),k=Math.SQRT1_2,re=s.re,im=s.im;for(let base=0;base<re.length;base+=2*bit){const end=base+bit;for(let i=base;i<end;i++){const j=i+bit,ar=re[i],ai=im[i],br=re[j],bi=im[j];re[i]=(ar+br)*k;im[i]=(ai+bi)*k;re[j]=(ar-br)*k;im[j]=(ai-bi)*k;}}}
function cx(s,n,c,t){const cb=1<<(n-1-c),tb=1<<(n-1-t),hi=Math.max(cb,tb),lo=Math.min(cb,tb),re=s.re,im=s.im;for(let base=0;base<re.length;base+=2*hi)for(let middle=0;middle<hi;middle+=2*lo){const start=base+middle+cb,end=start+lo;for(let i=start;i<end;i++){const j=i+tb,ar=re[i],ai=im[i];re[i]=re[j];im[i]=im[j];re[j]=ar;im[j]=ai;}}}
function norm(s){let v=0;for(let i=0;i<s.re.length;i++)v+=s.re[i]*s.re[i]+s.im[i]*s.im[i];return v;}
function ghz(s,n){h(s,n,0);for(let q=1;q<n;q++)cx(s,n,0,q);}
function inverse(s,n){for(let q=n-1;q>=1;q--)cx(s,n,0,q);h(s,n,0);}
const results=[];
for(let n=1;n<=20;n++){
  const t0=performance.now(),s=state(n);ghz(s,n);const t1=performance.now();
  const last=s.re.length-1,normError=Math.abs(norm(s)-1),p0=s.re[0]**2+s.im[0]**2,p1=s.re[last]**2+s.im[last]**2;
  let populated=0;for(let i=0;i<s.re.length;i++)if(s.re[i]*s.re[i]+s.im[i]*s.im[i]>TOL)populated++;
  const t2=performance.now();inverse(s,n);const t3=performance.now();
  let maxRoundtrip=0;for(let i=0;i<s.re.length;i++){const er=Math.abs(s.re[i]-(i===0?1:0)),ei=Math.abs(s.im[i]);if(er>maxRoundtrip)maxRoundtrip=er;if(ei>maxRoundtrip)maxRoundtrip=ei;}
  results.push({qubits:n,dimension:1<<n,state_bytes:(1<<n)*16,ghz_ms:t1-t0,inspect_ms:t2-t1,inverse_ms:t3-t2,norm_error:normError,p0,p1,populated_branches:populated,roundtrip_max_abs_error:maxRoundtrip,pass:normError<=TOL&&Math.abs(p0-.5)<=TOL&&Math.abs(p1-.5)<=TOL&&populated===2&&maxRoundtrip<=TOL});
}
const failed=results.filter(r=>!r.pass);
let dFreeGiB=null;try{const x=fs.statfsSync('./REDACTED_LOCAL_ROOT/',{bigint:true});dFreeGiB=Number(x.bavail*x.bsize)/1073741824;}catch{}
const report={schema:'qel.q7.emulation-envelope/v1',captured_at:new Date().toISOString(),host:os.hostname(),mode:'LOCAL_CLASSICAL_STATEVECTOR_TYPED_ARRAY_NO_NETWORK_NO_CRYPTO',qubit_range:[1,20],maximum_dimension:1<<20,maximum_state_bytes:(1<<20)*16,total_system_memory_gib:os.totalmem()/1073741824,free_system_memory_gib_at_close:os.freemem()/1073741824,d_free_gib:dFreeGiB,tolerance:TOL,cases:results.length,passed:results.length-failed.length,failed:failed.length,failure_rate_percent:100*failed.length/results.length,results,physical_qpu:'NOT_RUN',quantum_advantage:'NOT_ESTABLISHED'};
fs.writeFileSync(OUT,JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify({output:OUT,cases:results.length,passed:report.passed,failed:report.failed,failure_rate_percent:report.failure_rate_percent,maximum_qubits:20,maximum_dimension:report.maximum_dimension,max_state_mib:report.maximum_state_bytes/1048576,total_memory_gib:report.total_system_memory_gib,free_memory_gib:report.free_system_memory_gib_at_close,d_free_gib:dFreeGiB,last_case:results.at(-1)},null,2));

process.exitCode=failed.length ? 1 : 0;
