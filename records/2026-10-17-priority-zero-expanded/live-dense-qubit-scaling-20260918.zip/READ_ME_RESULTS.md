# Fresh live qubit scaling — 18 September 2026

Agent: GAUCIA  
Owner: Sherman G. Laing  
Device: Node Zero / REDACTED_DEVICE  
Final live admission measurement: 2026-09-18 23:40:17.343 UTC

## Measured answer

**21 simulated qubits passed three of three trials under the laptop's current load.** That is 2,097,152 complex amplitudes in two Float64 arrays, totaling 32 MiB of state storage. Sizes 1 through 21 completed across the fresh ladder, with 25 passing trials in total.

The next size, 22 qubits, was **not admitted for execution**. It required 64 MiB for the state plus the unchanged 256 MiB free-memory reserve: 320 MiB total. The live worker measured 322,658,304 bytes (307.7109375 MiB) free, a shortfall of 12,886,016 bytes (12.2890625 MiB). This was an admission-policy boundary, not a numerical failure or a demonstrated hard hardware maximum.

## Upper end of the measured ladder

| Qubits | Complex amplitudes | State storage | Completed trials | Validation time |
|---|---:|---:|---:|---:|
| 19 | 524,288 | 8 MiB | 1/1 passed | 225.1469 ms |
| 20 | 1,048,576 | 16 MiB | 3/3 passed | 391.4782 ms median; 382.0149–393.8759 ms |
| 21 | 2,097,152 | 32 MiB | 3/3 passed | 766.6211 ms median; 706.4625–772.9428 ms |
| 22 | 4,194,304 | 64 MiB required | 0; admission stopped | Not executed |

Time covers state allocation, both forward/inverse workloads, full-array numerical scans, initialization, and included resource snapshots. It excludes process launch and initial kernel loading. It is not the time for an arbitrary 21-qubit algorithm. All timings are observed samples from the laptop under its existing load.

At 21 qubits, all nine numerical checks passed in each trial. The largest reported amplitude-return or normalization error was 2.220446049250313e-16 against a predeclared 1e-12 tolerance. The complex full-support state's return error was 1.0842021724855044e-19 in all three trials.

## What was actually exercised

The driver copied six exact function definitions from the existing emulator: state, h, cx, norm, ghz, and inverse. It did not execute the production file's top-level runner. All scientific computation ran on the laptop.

Each trial allocated the entire dense state vector, verified both array lengths and their combined byte size, and performed:

1. A GHZ circuit from the zero basis state. Every amplitude was scanned against its analytic expected value, with finite values, exactly two populated branches, and unit normalization checked.
2. The inverse circuit, checking return to the zero basis state.
3. A state with every basis amplitude populated, cycling through positive real, positive imaginary, negative real, and negative imaginary phases at equal magnitude.
4. The same forward circuit, a normalization scan, and its inverse, checking finite values, full support, and return to the expected complex input.

The full-support input is deterministic and structured. These results establish capacity for the tested H/CX state-vector workloads. They do not establish an all-algorithm capacity, a dense-matrix capacity, physical quantum hardware, or quantum speedup.

## Resource policy and preserved attempts

The target reserve remained **256 MiB** throughout. One trial ran at a time. Workers had a 30-second timeout and a 64 MiB JavaScript heap ceiling; typed-array state memory was separately controlled by the admission check. Free-memory observations are snapshots, not continuous monitoring.

- Attempt 01: no circuit executed. The parent observed 269,041,664 bytes free, below its reserve plus launch allowance. Its raw result is preserved.
- Attempt 02: sizes 1–13 passed. Child admission was corrected to avoid reserving runtime memory twice: it checked actual free RAM after loading its runtime and kernel. The parent then stopped before size 14 because 334,376,960 bytes free was below its 335,806,464-byte threshold.
- Attempt 03: continued from 14 using a PowerShell supervisor and isolated workers, removing the resident Node controller. Worker admission still required state bytes plus the same 256 MiB reserve. Sizes 14–21 passed; size 22 stopped at admission.

There were 25 completed passing trials across attempts 02 and 03, each with nine checks, for 225 successful check evaluations. These are repeated checks, not 225 distinct algorithms. Original production-source bytes were unchanged at the end of every attempt.

At 21 qubits, the greatest sampled worker RSS was 78,684,160 bytes. Node's process resource API separately reported a maximum RSS of 77,516 KiB. These are whole-process measurements, distinct from the 32 MiB state arrays. The sampled maximum may miss an intermediate peak.

The machine reported 4,045,615,104 bytes total physical RAM. Other activity caused free memory to vary during the experiment, so 21 is the largest demonstrated size in this run, not a permanent machine specification.

## Evidence index

Each attempt folder preserves its experiment contract, driver, original source copy, extracted kernel, provenance, and final JSON result. Attempts 02 and 03 also contain individual worker results and execution envelopes, including stdout, stderr, timestamps, and status. Attempt 03 includes the exact supervisor command and an independent review.

All evidence is private to the owner's workspace and evidence copies. No new SHA fingerprints or owner signatures were generated. The scripts contain no network API calls; this is not a claim of operating-system network isolation.


Independent review confirmed all 26 recorded child results matched both their aggregate records and execution stdout: 25 PASS and one admission stop. All child executions exited zero without stderr or timeout. The minimum observed free memory across completed trials was 279,822,336 bytes, above the 256 MiB floor. Attempt 03 has a null device field in its raw aggregate; the remote execution records and the independent review identify REDACTED_DEVICE. This omission is preserved and disclosed.
