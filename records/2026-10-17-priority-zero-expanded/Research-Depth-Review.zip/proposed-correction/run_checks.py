"""New portable October 16, 2026 packaging adapter. Only saved data and fixtures.

Writes to a newly created output directory, never edits packaged inputs, never
launches a model, browser, service, USB tool or network client.
"""
from pathlib import Path
import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from verify_manifest import verify

ROOT = Path(__file__).resolve().parent

def read(p): return json.loads(p.read_text(encoding='utf-8'))

def validate_output_destination(output, source_root=ROOT):
    """Keep generated results outside the complete enclosing review candidate."""
    source_root = source_root.resolve()
    protected_root = source_root
    for parent in source_root.parents:
        if (parent/'DISCLOSURE_REGISTER.json').is_file() and (parent/'MANIFEST.json').is_file():
            protected_root = parent
            break
    resolved = Path(output).resolve()
    if resolved == protected_root or protected_root in resolved.parents:
        raise ValueError('Output must be outside the complete public candidate')
    return resolved

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output',type=Path,required=True,help='New nonexistent directory outside this candidate')
    args=parser.parse_args(); output=validate_output_destination(args.output)
    source_count=verify()
    output.mkdir(parents=True,exist_ok=False)
    temp=output/'temporary';temp.mkdir()
    env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONUTF8='1',TMP=str(temp),TEMP=str(temp),TMPDIR=str(temp))
    report={'schema':'qel-public-reproduction-check/1','state':'INCOMPLETE','started_utc':datetime.now(timezone.utc).isoformat(),
            'python_version':platform.python_version(),'platform_family':platform.system(),'source_files_verified':source_count,
            'new_system_observations':0,'historical_scientific_benchmarks_rerun':False,'full_hebrew_corpus_export':False,
            'steps':[]}
    def save(): (output/'verification.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    def run(name,argv,cwd):
        result=subprocess.run([sys.executable,'-B',*map(str,argv)],cwd=cwd,env=env,capture_output=True,text=True,encoding='utf-8',timeout=180)
        (output/(name+'.stdout.txt')).write_text(result.stdout,encoding='utf-8')
        (output/(name+'.stderr.txt')).write_text(result.stderr,encoding='utf-8')
        report['steps'].append({'name':name,'exit_code':result.returncode});save()
        if result.returncode: raise RuntimeError(name+' failed; inspect saved logs')
        return result
    save()
    try:
        generated=output/'documentary-generated'
        run('documentary',[ROOT/'documentary/rebuild.py','--output',generated],output)
        expected=read(ROOT/'documentary/expected-output-manifest.json')['files']
        if {p.relative_to(generated).as_posix() for p in generated.rglob('*') if p.is_file()}!={r['path'] for r in expected}:
            raise ValueError('Documentary output list mismatch')
        for row in expected:
            b=(generated/row['path']).read_bytes()
            if len(b)!=row['bytes'] or hashlib.sha256(b).hexdigest()!=row['sha256']:raise ValueError('Documentary mismatch: '+row['path'])
        report['documentary_files_matching_frozen_outputs']=len(expected)
        q8=output/'counter-means.json'
        run('q8-observations',[ROOT/'q8-observations/reproduce_means.py',q8],output)
        if q8.read_bytes()!=(ROOT/'q8-observations/reproduction-result.json').read_bytes():raise ValueError('Counter replay bytes differ')
        report['counter_readings']=990;report['counter_means']=33
        bible=output/'bible-replay';shutil.copytree(ROOT/'bible-replay',bible)
        result=run('bible-replay',[bible/'verify.py'],bible)
        verified=read(bible/'replay-output/verification.json'); replayed=read(bible/'replay-output/results.json')
        comparisons=sum(len(x['checks']) for x in [replayed['baseline'],*replayed['studies']])
        if verified['state']!='PASS' or replayed['status']!='PASS' or comparisons!=113:raise ValueError('Unexpected Bible replay result')
        recovered=verified['results']['recovered_word_core']
        if recovered['executed']!=40 or recovered['passed']!=40:raise ValueError('Recovered suite population differs')
        if 'Ran 36 tests' not in result.stderr:raise ValueError('Adapter test population differs')
        report['bible']={'source_comparisons':comparisons,'adapter_test_methods':36,'recovered_test_methods':40,'excluded_archival_methods':3}
        hebrew=output/'hebrew-h041';shutil.copytree(ROOT/'hebrew-h041',hebrew)
        result=run('hebrew-h041',[hebrew/'verification/test_converter.py'],hebrew)
        if 'Ran 12 tests' not in result.stderr or '\nOK\n' not in result.stderr:raise ValueError('Unexpected H04.1 fixture suite result')
        report['hebrew_h041_test_methods']=12
        result=run('quantum-teaching',[ROOT/'quantum-teaching/check_fixtures.py'],output)
        teaching=json.loads(result.stdout)
        if teaching['status']!='PASS' or teaching['fixture_groups']!=4:raise ValueError('Unexpected teaching fixture result')
        report['new_quantum_teaching_fixture_groups']=4
        if verify()!=source_count:raise ValueError('Source file population changed')
        report.update(state='PASS',completed_utc=datetime.now(timezone.utc).isoformat(),packaged_sources_unchanged=True)
        save();print(json.dumps(report,indent=2));return 0
    except Exception as error:
        report.update(state='FAIL',error_type=type(error).__name__,error=str(error));save();raise

if __name__=='__main__':raise SystemExit(main())
