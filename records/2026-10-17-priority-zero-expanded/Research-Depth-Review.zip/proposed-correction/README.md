# Proposed reproduction-runner correction

This successor protects the whole enclosing review candidate from generated output, rather than only its reproduction subdirectory. The original remains unchanged.

The patch and complete successor file are supplied for a new manifest-bound edition. The verification records seven isolated destination cases; it does not claim a full reproduction rerun. Install the successor at the original runner location only as part of an explicitly versioned new edition with the required companion files. This folder alone is not a complete runnable reproduction package.

Status: prepared and narrowly tested; not installed, published or treated as a historical experiment.
