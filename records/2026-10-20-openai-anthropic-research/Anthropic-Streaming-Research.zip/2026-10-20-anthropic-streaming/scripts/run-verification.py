# Public portability derivative: executable paths only; not executed during edition preparation.
"""Run bounded local SDK checks and preserve logs; no API credentials are used."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
TS = ROOT / 'typescript'
NODE = Path(os.environ.get('NODE_BINARY', 'node'))
GIT = Path(os.environ.get('GIT_BINARY', 'git'))
FILES = ['src/lib/MessageStream.ts', 'src/lib/BetaMessageStream.ts']
TESTS = ['tests/api-resources/MessageStream.test.ts', 'tests/api-resources/BetaMessageStream.test.ts', 'tests/streaming.test.ts', 'tests/middleware-streaming.test.ts', 'tests/lib/streaming-completion-research.test.ts']

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def env():
    result = {k: v for k, v in os.environ.items() if not k.startswith(('ANTHROPIC_', 'OTEL_', 'OPENAI_')) and k not in ('NODE_OPTIONS', 'NOCK_RECORD', 'TEST_API_BASE_URL', 'PYTHONPATH')}
    temp = ROOT / 'temp'
    temp.mkdir(exist_ok=True)
    result.update(TEMP=str(temp), TMP=str(temp), NO_COLOR='1', CI='true')
    return result

def run(label, command, cwd, environment):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (ROOT / (label + '.log')).open('w', encoding='utf-8') as log:
        completed = subprocess.run(command, cwd=cwd, env=environment, stdout=log, stderr=subprocess.STDOUT, text=True)
    receipt = {'label': label, 'command': [str(c) for c in command], 'cwd': str(cwd), 'started_utc': start, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'exit_code': completed.returncode, 'log_sha256': digest(ROOT / (label + '.log'))}
    (ROOT / (label + '-receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n', encoding='utf-8')
    print(json.dumps(receipt), flush=True)
    return completed.returncode

def replace_once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new, 1)

def patch_guard():
    for name in FILES:
        path = TS / name
        body = path.read_text(encoding='utf-8')
        snapshot = '  #currentMessageSnapshot: ' + ('BetaMessage' if 'Beta' in name else 'Message') + ' | undefined;'
        body = replace_once(body, snapshot, snapshot + '\n  #receivedMessageStop = false;')
        body = replace_once(body, '  #beginRequest() {\n    if (this.ended) return;\n    this.#currentMessageSnapshot = undefined;', '  #beginRequest() {\n    if (this.ended) return;\n    this.#currentMessageSnapshot = undefined;\n    this.#receivedMessageStop = false;')
        body = replace_once(body, "      case 'message_stop': {", "      case 'message_stop': {\n        this.#receivedMessageStop = true;")
        marker = '    this.#currentMessageSnapshot = undefined;\n    return maybeParse'
        guard = '    if (!this.#receivedMessageStop) {\n      throw new AnthropicError(\n        `stream ended before a "message_stop" event was received, so the message is incomplete`,\n      );\n    }\n'
        body = replace_once(body, marker, guard + marker)
        path.write_bytes(body.replace('\n', '\r\n').encode())

def patch_iterator():
    for name in FILES:
        path = TS / name
        body = path.read_text(encoding='utf-8')
        body = replace_once(body, '    let done = false;', '    let done = false;\n    let error: AnthropicError | undefined;')
        for event in ('abort', 'error'):
            old = "    this.on('" + event + "', (err) => {\n      done = true;"
            body = replace_once(body, old, old + '\n      error = err;')
        body = replace_once(body, '        if (!pushQueue.length) {\n          if (done)', '        if (!pushQueue.length) {\n          if (error) throw error;\n          if (done)')
        path.write_bytes(body.replace('\n', '\r\n').encode())

def ts_check(label):
    cmd = [str(NODE), 'node_modules/vitest/vitest.mjs', 'run', *TESTS, '--maxWorkers=1', '--no-file-parallelism', '--reporter=json', '--outputFile=' + str(ROOT / (label + '.json'))]
    hashes = {p: digest(TS / p) for p in FILES + TESTS}
    (ROOT / (label + '-sources.json')).write_text(json.dumps(hashes, indent=2) + '\n', encoding='utf-8')
    status = run(label, cmd, TS, env())
    result_path = ROOT / (label + '.json')
    if result_path.exists():
        result = json.loads(result_path.read_text(encoding='utf-8'))
        print(json.dumps({'label': label, 'total': result.get('numTotalTests'), 'passed': result.get('numPassedTests'), 'failed': result.get('numFailedTests'), 'success': result.get('success')}), flush=True)
    return status

mode = sys.argv[1]
if mode == 'ts-baseline':
    for name in FILES:
        path = TS / name
        backup = ROOT / ('original-' + path.name)
        assert not backup.exists(), backup
        backup.write_bytes(path.read_bytes())
    sys.exit(ts_check('ts-baseline'))
elif mode == 'ts-guard':
    patch_guard()
    sys.exit(ts_check('ts-guard'))
elif mode == 'ts-combined':
    patch_iterator()
    sys.exit(ts_check('ts-combined'))
elif mode == 'python':
    environment = env()
    environment['PYTHONPATH'] = os.pathsep.join([str(ROOT / 'python/src'), str(ROOT / 'py-runtime')])
    code = run('python-characterization', [sys.executable, '-s', '-B', str(ROOT / 'python-characterization.py')], ROOT, environment)
    sys.exit(code)
elif mode == 'checks':
    paths = FILES + ['tests/lib/streaming-completion-research.test.ts']
    checks = [
        ('ts-format', [str(NODE), 'node_modules/prettier/bin/prettier.cjs', '--check', *paths]),
        ('ts-eslint', [str(NODE), 'node_modules/eslint/bin/eslint.js', *paths]),
        ('ts-types', [str(NODE), 'node_modules/typescript/bin/tsc', '-p', str(ROOT / 'tsconfig.focused.json')]),
        ('ts-diff-check', [str(GIT), 'diff', '--check']),
    ]
    statuses = [run(label, command, TS, env()) for label, command in checks]
    sys.exit(0 if all(status == 0 for status in statuses) else 1)
elif mode == 'final':
    paths = FILES + ['tests/lib/streaming-completion-research.test.ts']
    checks = [
        ('ts-format-apply', [str(NODE), 'node_modules/prettier/bin/prettier.cjs', '--write', *paths]),
        ('ts-format-final', [str(NODE), 'node_modules/prettier/bin/prettier.cjs', '--check', *paths]),
        ('ts-eslint-final', [str(NODE), 'node_modules/eslint/bin/eslint.js', *paths]),
        ('ts-types-final', [str(NODE), 'node_modules/typescript/bin/tsc', '-p', str(ROOT / 'tsconfig.focused.json')]),
        ('ts-diff-final', [str(GIT), 'diff', '--check']),
    ]
    for label, command in checks:
        if run(label, command, TS, env()) != 0:
            raise SystemExit(1)
    sys.exit(ts_check('ts-final'))
else:
    raise SystemExit('unknown mode')
