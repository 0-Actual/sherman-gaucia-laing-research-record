"""Characterize pinned Python helper behavior with 32 local HTTP mock cases.

Run with PYTHONPATH set to the sibling python/src directory. This is an ad hoc
baseline characterization, not the SDK test suite or a proposed completion
contract. It writes JSON to stdout and exits nonzero on a characterization mismatch.
No test execution is performed merely by authoring this file.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import platform
import subprocess
import sys
from collections.abc import AsyncIterator, Iterator
from pathlib import Path
from typing import Any

sys.dont_write_bytecode = True

import anyio
import httpx2

import anthropic
from anthropic import APIStatusError, Anthropic, AsyncAnthropic


PIN = "2d555d1416344a44af9322c88cb04b75df9c878d"
REPO = Path(__file__).resolve().parent / "python"
BASE_URL = "https://anthropic-characterization.invalid"
API_KEY = "synthetic-characterization-key-not-a-real-credential"
MODEL = "claude-sonnet-5-5"
SCENARIOS = (
    "start_eof",
    "partial_text_eof",
    "complete_terminal",
    "undelimited_stop_fixture",
    "server_error_then_final",
    "read_error_then_final",
    "close_unread",
    "close_after_start",
)
SOURCE_FILES = (
    "src/anthropic/lib/streaming/_messages.py",
    "src/anthropic/lib/streaming/_beta_messages.py",
    "src/anthropic/_streaming.py",
    "src/anthropic/_utils/_streams.py",
    "tests/lib/streaming/fixtures/basic_response.txt",
)
MESSAGE_START = {
    "type": "message_start",
    "message": {
        "id": "msg_characterization",
        "type": "message",
        "role": "assistant",
        "model": MODEL,
        "content": [],
        "stop_reason": None,
        "stop_sequence": None,
        "usage": {"input_tokens": 1, "output_tokens": 0},
    },
}
TEXT_START = {
    "type": "content_block_start",
    "index": 0,
    "content_block": {"type": "text", "text": ""},
}
TEXT_DELTA = {
    "type": "content_block_delta",
    "index": 0,
    "delta": {"type": "text_delta", "text": "partial"},
}
SERVER_ERROR = {
    "type": "error",
    "error": {"type": "overloaded_error", "message": "Synthetic stream error"},
}


def encode_event(event: dict[str, Any]) -> bytes:
    data = json.dumps(event, separators=(",", ":"))
    return f"event: {event['type']}\ndata: {data}\n\n".encode("utf-8")


def wire_chunks(scenario: str) -> list[bytes]:
    if scenario in ("complete_terminal", "undelimited_stop_fixture"):
        fixture = REPO / "tests/lib/streaming/fixtures/basic_response.txt"
        chunks = [line.encode("utf-8") + b"\n" for line in fixture.read_text(encoding="utf-8").splitlines()]
        if scenario == "complete_terminal":
            chunks.append(b"\n")
        return chunks
    chunks = [encode_event(MESSAGE_START)]
    if scenario != "start_eof":
        chunks.extend([encode_event(TEXT_START), encode_event(TEXT_DELTA)])
    if scenario == "server_error_then_final":
        chunks.append(encode_event(SERVER_ERROR))
    return chunks


class SyncBody(httpx2.SyncByteStream):
    def __init__(self, chunks: list[bytes], fail_read: bool) -> None:
        self.chunks = chunks
        self.fail_read = fail_read
        self.yielded = 0
        self.close_calls = 0
        self.request: httpx2.Request | None = None

    def __iter__(self) -> Iterator[bytes]:
        for chunk in self.chunks:
            self.yielded += 1
            yield chunk
        if self.fail_read:
            raise httpx2.ReadError("Synthetic read interruption", request=self.request)

    def close(self) -> None:
        self.close_calls += 1


class AsyncBody(httpx2.AsyncByteStream):
    def __init__(self, chunks: list[bytes], fail_read: bool) -> None:
        self.chunks = chunks
        self.fail_read = fail_read
        self.yielded = 0
        self.close_calls = 0
        self.request: httpx2.Request | None = None

    async def __aiter__(self) -> AsyncIterator[bytes]:
        for chunk in self.chunks:
            self.yielded += 1
            yield chunk
        if self.fail_read:
            raise httpx2.ReadError("Synthetic read interruption", request=self.request)

    async def aclose(self) -> None:
        self.close_calls += 1


def check(result: dict[str, Any], name: str, condition: bool) -> None:
    result["checks"].append({"name": name, "passed": bool(condition)})
    if not condition:
        raise AssertionError(name)


def describe_error(error: Exception) -> dict[str, Any]:
    return {
        "class": f"{type(error).__module__}.{type(error).__name__}",
        "message": str(error),
        "api_error_type": getattr(error, "type", None),
    }


def summarize_message(message: Any) -> dict[str, Any]:
    return {
        "id": message.id,
        "stop_reason": message.stop_reason,
        "text": "".join(block.text for block in message.content if block.type == "text"),
        "content_types": [block.type for block in message.content],
        "output_tokens": message.usage.output_tokens,
    }


def new_result(mode: str, beta: bool, scenario: str, chunks: list[bytes]) -> dict[str, Any]:
    return {
        "mode": mode,
        "surface": "beta.messages" if beta else "messages",
        "scenario": scenario,
        "wire_sha256": hashlib.sha256(b"".join(chunks)).hexdigest(),
        "wire_chunks": len(chunks),
        "requests": [],
        "observations": {},
        "checks": [],
        "matched_current_characterization": False,
    }


def handler_for(body: SyncBody | AsyncBody, result: dict[str, Any], beta: bool) -> Any:
    def handler(request: httpx2.Request) -> httpx2.Response:
        body.request = request
        payload = json.loads(request.content)
        result["requests"].append({
            "method": request.method,
            "url": str(request.url),
            "stream": payload.get("stream"),
            "model": payload.get("model"),
            "helper_method": request.headers.get("x-stainless-helper-method"),
            "stream_helper": request.headers.get("x-stainless-stream-helper"),
        })
        check(result, "mock host and method", request.url.host == "anthropic-characterization.invalid" and request.method == "POST")
        check(result, "messages endpoint", request.url.path == "/v1/messages")
        check(result, "beta query", request.url.params.get("beta") == ("true" if beta else None))
        check(result, "stream request body", payload.get("stream") is True and payload.get("model") == MODEL)
        check(result, "synthetic API credential", request.headers.get("x-api-key") == API_KEY)
        check(result, "stream helper headers", request.headers.get("x-stainless-helper-method") == "stream" and request.headers.get("x-stainless-stream-helper") == ("beta.messages" if beta else "messages"))
        return httpx2.Response(200, headers={"content-type": "text/event-stream"}, stream=body, request=request)
    return handler


def verify_first_error(result: dict[str, Any], scenario: str, error: Exception) -> None:
    result["observations"]["first_final_error"] = describe_error(error)
    if scenario == "server_error_then_final":
        check(result, "SSE error preserved", isinstance(error, APIStatusError) and error.type == "overloaded_error")
    else:
        check(result, "transport read error preserved", isinstance(error, httpx2.ReadError))


def verify_final(result: dict[str, Any], scenario: str, first: Any, second: Any) -> None:
    one, two = summarize_message(first), summarize_message(second)
    result["observations"]["final_message"] = one
    result["observations"]["repeated_final_message"] = two
    check(result, "repeated final snapshot agrees", one == two)
    if scenario in ("complete_terminal", "undelimited_stop_fixture"):
        check(result, "fixture snapshot", one["text"] == "Hello there!" and one["stop_reason"] == "end_turn")
    else:
        expected_text = "" if scenario == "start_eof" else "partial"
        check(result, "partial snapshot remains available", one["id"] == "msg_characterization" and one["text"] == expected_text and one["stop_reason"] is None)


def verify_events(result: dict[str, Any], scenario: str, event_types: list[str]) -> None:
    result["observations"]["event_types"] = event_types
    expected = ["message_start", "content_block_start", "content_block_delta", "text", "content_block_delta", "text", "content_block_delta", "text", "content_block_stop", "message_delta"]
    if scenario == "complete_terminal":
        expected.append("message_stop")
    check(result, "dispatched events include only delimited stop", event_types == expected)


def record_cleanup(result: dict[str, Any], body: SyncBody | AsyncBody, response: httpx2.Response | None) -> None:
    result["observations"]["body_chunks_yielded"] = body.yielded
    result["observations"]["body_close_calls"] = body.close_calls
    result["observations"]["response_closed_after_context"] = response.is_closed if response is not None else None


def run_sync(beta: bool, scenario: str) -> dict[str, Any]:
    chunks = wire_chunks(scenario)
    result = new_result("sync", beta, scenario, chunks)
    body = SyncBody(chunks, scenario == "read_error_then_final")
    response = None
    try:
        http_client = httpx2.Client(transport=httpx2.MockTransport(handler_for(body, result, beta)), trust_env=False)
        with Anthropic(api_key=API_KEY, base_url=BASE_URL, http_client=http_client, max_retries=0, open_telemetry=False) as client:
            resource = client.beta.messages if beta else client.messages
            with resource.stream(model=MODEL, max_tokens=32, messages=[{"role": "user", "content": "synthetic"}]) as stream:
                response = stream.response
                check(result, "response initially open", not response.is_closed)
                if scenario in ("close_unread", "close_after_start"):
                    if scenario == "close_after_start":
                        check(result, "first event is start", next(stream).type == "message_start")
                        result["observations"]["snapshot_before_close"] = summarize_message(stream.current_message_snapshot)
                    stream.close()
                    check(result, "explicit close does not drain", body.yielded == (1 if scenario == "close_after_start" else 0))
                else:
                    if scenario in ("server_error_then_final", "read_error_then_final"):
                        try:
                            stream.get_final_message()
                        except Exception as error:
                            verify_first_error(result, scenario, error)
                        else:
                            check(result, "first finalization raises", False)
                    else:
                        if scenario in ("complete_terminal", "undelimited_stop_fixture"):
                            verify_events(result, scenario, [event.type for event in stream])
                        result["observations"]["until_done_return"] = stream.until_done()
                        check(result, "drain returns None", result["observations"]["until_done_return"] is None)
                    verify_final(result, scenario, stream.get_final_message(), stream.get_final_message())
                check(result, "response closed before context exit", response.is_closed and body.close_calls >= 1)
        check(result, "exactly one mocked request", len(result["requests"]) == 1)
        result["matched_current_characterization"] = True
    except Exception as error:
        result["unexpected_error"] = describe_error(error)
    finally:
        record_cleanup(result, body, response)
    return result


async def run_async(beta: bool, scenario: str) -> dict[str, Any]:
    chunks = wire_chunks(scenario)
    result = new_result("async", beta, scenario, chunks)
    body = AsyncBody(chunks, scenario == "read_error_then_final")
    response = None
    try:
        http_client = httpx2.AsyncClient(transport=httpx2.MockTransport(handler_for(body, result, beta)), trust_env=False)
        async with AsyncAnthropic(api_key=API_KEY, base_url=BASE_URL, http_client=http_client, max_retries=0, open_telemetry=False) as client:
            resource = client.beta.messages if beta else client.messages
            async with resource.stream(model=MODEL, max_tokens=32, messages=[{"role": "user", "content": "synthetic"}]) as stream:
                response = stream.response
                check(result, "response initially open", not response.is_closed)
                if scenario in ("close_unread", "close_after_start"):
                    if scenario == "close_after_start":
                        check(result, "first event is start", (await anext(stream)).type == "message_start")
                        result["observations"]["snapshot_before_close"] = summarize_message(stream.current_message_snapshot)
                    await stream.close()
                    check(result, "explicit close does not drain", body.yielded == (1 if scenario == "close_after_start" else 0))
                else:
                    if scenario in ("server_error_then_final", "read_error_then_final"):
                        try:
                            await stream.get_final_message()
                        except Exception as error:
                            verify_first_error(result, scenario, error)
                        else:
                            check(result, "first finalization raises", False)
                    else:
                        if scenario in ("complete_terminal", "undelimited_stop_fixture"):
                            verify_events(result, scenario, [event.type async for event in stream])
                        result["observations"]["until_done_return"] = await stream.until_done()
                        check(result, "drain returns None", result["observations"]["until_done_return"] is None)
                    verify_final(result, scenario, await stream.get_final_message(), await stream.get_final_message())
                check(result, "response closed before context exit", response.is_closed and body.close_calls >= 1)
        check(result, "exactly one mocked request", len(result["requests"]) == 1)
        result["matched_current_characterization"] = True
    except Exception as error:
        result["unexpected_error"] = describe_error(error)
    finally:
        record_cleanup(result, body, response)
    return result


def source_hashes() -> dict[str, str]:
    return {path: hashlib.sha256((REPO / path).read_bytes()).hexdigest() for path in SOURCE_FILES}


def dependency_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


async def async_cases() -> list[dict[str, Any]]:
    results = []
    for beta in (False, True):
        for scenario in SCENARIOS:
            results.append(await run_async(beta, scenario))
    return results


def main() -> int:
    report: dict[str, Any] = {
        "purpose": "Characterize existing behavior, including incomplete EOF acceptance; not a fixed-contract test or SDK-suite pass",
        "expected_revision": PIN,
        "script_path": str(Path(__file__).resolve()),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "python_executable": sys.executable,
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "source_repository": str(REPO.resolve()),
        "anthropic_import_path": str(Path(anthropic.__file__).resolve()),
        "anthropic_version": anthropic.__version__,
        "httpx2_import_path": str(Path(httpx2.__file__).resolve()),
        "dependencies": {name: dependency_version(name) for name in ("httpx2", "anyio", "pydantic", "jiter", "opentelemetry-api")},
        "transport": "httpx2.MockTransport only; trust_env=False; explicit .invalid base URL",
        "credentials": "fixed synthetic constructor API key; never printed",
        "tracing": "disabled explicitly",
        "network_requests": "none by construction: every SDK request uses the in-memory mock transport",
        "test_runner": "standalone characterization; no pytest",
        "async_backend": "anyio default asyncio backend only; cancellation is not tested",
        "results": [],
    }
    try:
        imported = Path(anthropic.__file__).resolve()
        expected = (REPO / "src/anthropic/__init__.py").resolve()
        if imported != expected:
            raise RuntimeError("Set PYTHONPATH to the pinned sibling python/src directory before running")
        head = subprocess.run(["git", "-C", str(REPO), "rev-parse", "HEAD"], check=True, capture_output=True, text=True).stdout.strip()
        report["observed_revision"] = head
        if head != PIN:
            raise RuntimeError("The local source checkout is not at the requested pin")
        report["source_hashes_before"] = source_hashes()
        for beta in (False, True):
            for scenario in SCENARIOS:
                report["results"].append(run_sync(beta, scenario))
        report["results"].extend(anyio.run(async_cases))
        report["source_hashes_after"] = source_hashes()
        report["source_unchanged"] = report["source_hashes_before"] == report["source_hashes_after"]
        report["case_count"] = len(report["results"])
        report["matching_cases"] = sum(case["matched_current_characterization"] for case in report["results"])
        report["all_current_characterizations_match"] = report["case_count"] == 32 and report["matching_cases"] == 32 and report["source_unchanged"]
        exit_code = 0 if report["all_current_characterizations_match"] else 1
    except Exception as error:
        report["setup_or_harness_error"] = describe_error(error)
        exit_code = 1
    report["exit_code"] = exit_code
    print(json.dumps(report, indent=2, ensure_ascii=True))
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
