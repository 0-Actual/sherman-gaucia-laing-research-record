import { AnthropicError, APIConnectionError, APIUserAbortError } from '@anthropic-ai/sdk';
import { MessageStream } from '@anthropic-ai/sdk/lib/MessageStream';
import { BetaMessageStream } from '@anthropic-ai/sdk/lib/BetaMessageStream';
import type { MessageStreamEvent } from '@anthropic-ai/sdk/resources/messages';
import type { BetaRawMessageStreamEvent } from '@anthropic-ai/sdk/resources/beta/messages';
import { loadFixture, parseSSEFixture } from './sse-helpers';

interface CompletionStream
  extends
    Pick<MessageStream, 'done' | 'finalText' | 'abort' | 'ended' | 'errored' | 'aborted'>,
    AsyncIterable<MessageStreamEvent | BetaRawMessageStreamEvent> {
  readonly receivedMessages: readonly unknown[];
  finalMessage(): ReturnType<MessageStream['finalMessage']> | ReturnType<BetaMessageStream['finalMessage']>;
  on(event: 'error', listener: (error: AnthropicError) => void): unknown;
  on(event: 'abort', listener: (error: APIUserAbortError) => void): unknown;
  on(event: 'message' | 'finalMessage' | 'end', listener: () => void): unknown;
  emitted(event: 'streamEvent'): Promise<unknown>;
}

function controlledNDJSON() {
  let controller!: ReadableStreamDefaultController<Uint8Array>;
  const encoder = new TextEncoder();
  const readable = new ReadableStream<Uint8Array>({
    start(value) {
      controller = value;
    },
  });

  return {
    readable,
    write(event: unknown) {
      controller.enqueue(encoder.encode(JSON.stringify(event) + '\n'));
    },
    close() {
      controller.close();
    },
    error(error: unknown) {
      controller.error(error);
    },
  };
}

const consumerStates = ['paused', 'queued', 'waiting'] as const;

const helpers = [
  {
    name: 'MessageStream',
    create: (readable: ReadableStream): CompletionStream => MessageStream.fromReadableStream(readable),
  },
  {
    name: 'BetaMessageStream',
    create: (readable: ReadableStream): CompletionStream => BetaMessageStream.fromReadableStream(readable),
  },
];

describe.each(helpers)('$name completion and iterator failures', ({ create }) => {
  async function startStream(state: (typeof consumerStates)[number]) {
    const events = (await parseSSEFixture(loadFixture('basic_response.txt'))) as MessageStreamEvent[];
    const source = controlledNDJSON();
    const stream = create(source.readable);
    const iterator = stream[Symbol.asyncIterator]();
    const completion = stream.done().catch((error: unknown) => error);
    const lifecycle: string[] = [];
    const failures: AnthropicError[] = [];

    stream.on('error', (error: AnthropicError) => {
      failures.push(error);
      lifecycle.push('error');
    });
    stream.on('abort', (error: APIUserAbortError) => {
      failures.push(error);
      lifecycle.push('abort');
    });
    stream.on('message', () => lifecycle.push('message'));
    stream.on('finalMessage', () => lifecycle.push('finalMessage'));
    stream.on('end', () => lifecycle.push('end'));

    const first = iterator.next();
    source.write(events[0]);
    expect(await first).toEqual({ value: events[0], done: false });

    const queued = state === 'queued' ? events.slice(1, 3) : [];
    for (const event of queued) {
      const received = stream.emitted('streamEvent');
      source.write(event);
      await received;
    }

    const pending = state === 'waiting' ? iterator.next().catch((error: unknown) => error) : undefined;

    return { source, stream, iterator, completion, lifecycle, failures, queued, pending };
  }

  test.each(consumerStates)('%s consumer observes EOF without message_stop', async (state) => {
    const context = await startStream(state);
    const { source, stream, iterator, completion, lifecycle, failures, queued, pending } = context;

    source.close();
    const failure = await completion;
    expect(failure).toBeInstanceOf(AnthropicError);
    expect(failure).not.toBeInstanceOf(APIUserAbortError);
    expect(failure).toHaveProperty('message', expect.stringContaining('message_stop'));
    expect(failures).toEqual([failure]);
    expect(lifecycle).toEqual(['error', 'end']);
    expect(stream.ended).toBe(true);
    expect(stream.errored).toBe(true);
    expect(stream.aborted).toBe(false);
    expect(stream.receivedMessages).toEqual([]);
    await expect(stream.finalMessage()).rejects.toBe(failure);
    await expect(stream.finalText()).rejects.toBe(failure);

    for (const event of queued) {
      const item = await iterator.next();
      expect(item).toMatchObject({ value: { type: event.type }, done: false });
      if (event.type === 'content_block_delta') expect(item.value).toEqual(event);
    }
    if (pending) {
      expect(await pending).toBe(failure);
    } else {
      await expect(iterator.next()).rejects.toBe(failure);
    }
  });

  describe.each([
    {
      name: 'typed transport error',
      makeError: () => new APIConnectionError({ message: 'test stream interrupted' }),
      event: 'error',
      aborted: false,
    },
    {
      name: 'typed abort',
      makeError: () => new APIUserAbortError({ message: 'test stream aborted' }),
      event: 'abort',
      aborted: true,
    },
  ])('$name', ({ makeError, event, aborted }) => {
    test.each(consumerStates)('%s consumer receives the original error object', async (state) => {
      const { source, stream, iterator, completion, lifecycle, failures, queued, pending } =
        await startStream(state);
      const failure = makeError();

      source.error(failure);
      expect(await completion).toBe(failure);
      expect(failures).toEqual([failure]);
      expect(lifecycle).toEqual([event, 'end']);
      expect(stream.ended).toBe(true);
      expect(stream.errored).toBe(true);
      expect(stream.aborted).toBe(aborted);
      expect(stream.receivedMessages).toEqual([]);
      await expect(stream.finalMessage()).rejects.toBe(failure);

      for (const buffered of queued) {
        const item = await iterator.next();
        expect(item).toMatchObject({ value: { type: buffered.type }, done: false });
        if (buffered.type === 'content_block_delta') expect(item.value).toEqual(buffered);
      }
      if (pending) {
        expect(await pending).toBe(failure);
      } else {
        await expect(iterator.next()).rejects.toBe(failure);
      }
    });
  });

  test('explicit abort before EOF retains the abort error between reads', async () => {
    const { source, stream, iterator, completion, lifecycle, failures } = await startStream('paused');

    stream.abort();
    // The caller owns this readable; closing it lets the adapter observe the abort.
    source.close();
    const failure = await completion;

    expect(failure).toBeInstanceOf(APIUserAbortError);
    expect(failures).toEqual([failure]);
    expect(lifecycle).toEqual(['abort', 'end']);
    expect(stream.aborted).toBe(true);
    await expect(stream.finalMessage()).rejects.toBe(failure);
    await expect(iterator.next()).rejects.toBe(failure);
  });

  test.each(['end_turn', 'max_tokens'] as const)(
    'a complete %s message drains queued events and completes normally',
    async (stopReason) => {
      const fixture = (await parseSSEFixture(loadFixture('basic_response.txt'))) as MessageStreamEvent[];
      const events = fixture.map((event) => {
        if (
          typeof event === 'object' &&
          event !== null &&
          'type' in event &&
          event.type === 'message_delta' &&
          'delta' in event &&
          typeof event.delta === 'object' &&
          event.delta !== null
        ) {
          return { ...event, delta: { ...event.delta, stop_reason: stopReason } };
        }
        return event;
      });
      const source = controlledNDJSON();
      const stream = create(source.readable);
      const iterator = stream[Symbol.asyncIterator]();
      const completion = stream.done().catch((error: unknown) => error);
      const lifecycle: string[] = [];
      stream.on('error', () => lifecycle.push('error'));
      stream.on('abort', () => lifecycle.push('abort'));
      stream.on('message', () => lifecycle.push('message'));
      stream.on('finalMessage', () => lifecycle.push('finalMessage'));
      stream.on('end', () => lifecycle.push('end'));

      for (const event of events) {
        source.write(event);
      }
      source.close();

      expect(await completion).toBeUndefined();
      expect(lifecycle).toEqual(['message', 'finalMessage', 'end']);
      expect(stream.ended).toBe(true);
      expect(stream.errored).toBe(false);
      expect(stream.aborted).toBe(false);
      expect(stream.receivedMessages).toHaveLength(1);
      await expect(stream.finalMessage()).resolves.toMatchObject({ stop_reason: stopReason });
      await expect(stream.finalText()).resolves.toBe('Hello there!');

      for (const event of events) {
        expect(await iterator.next()).toMatchObject({ value: { type: event.type }, done: false });
      }
      expect(await iterator.next()).toEqual({ value: undefined, done: true });
    },
  );
});
