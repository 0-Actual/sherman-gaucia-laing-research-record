# Reproducing the bounded experiment

This edition preserves the recorded experiment. Reproduction requires dependency setup; no API key or live model request is needed. Use a **fresh execution directory separate from this evidence edition**, so recorded evidence cannot be overwritten. Run one stage at a time.

1. Clone `https://github.com/anthropics/anthropic-sdk-typescript.git` into `typescript` and check out `accbdd899218b49fcb3b5124319e99b64d51de90`. Clone `https://github.com/anthropics/anthropic-sdk-python.git` into `python` and check out `2d555d1416344a44af9322c88cb04b75df9c878d`. These must be actual Git checkouts; the Python script verifies its imported source path and Git revision.
2. Copy the four files from this edition's `scripts/` into that execution directory. Copy `source/typescript/tests/lib/streaming-completion-research.test.ts` into the pinned TypeScript checkout at `tests/lib/streaming-completion-research.test.ts`. Do not overlay the final helper snapshots before running the baseline.
3. Install dependencies using the pinned repository instructions. The recorded TypeScript execution used Node 24.20.0 and a script-disabled npm installation after the pinned pnpm installer failed on a Windows symlink. `evidence/typescript-npm-package-lock.json` records resolved dependencies; it is an inventory, not a claim that npm exactly reproduces upstream's frozen pnpm environment. `evidence/typescript-dependency-versions.json` records selected compiler/test versions.
4. The portable runner resolves `node` and `git` from PATH, or `NODE_BINARY` and `GIT_BINARY` when set. Its two executable-path constants are the only functional portability edits from the recorded runner. This derivative has not been executed. Read it before use. It filters credential/tracing variables and records commands, source hashes, stdout/stderr and exit codes in the execution directory.

```text
python run-verification.py ts-baseline
python run-verification.py ts-guard
python run-verification.py ts-combined
python run-verification.py final
```

Expected counts are 107 passed/16 failed, 109 passed/14 failed, 123 passed/0 failed and 123 passed/0 failed respectively. The first two processes deliberately exit 1. Patch stages are one-shot context-checked insertions and baseline refuses to overwrite source backups. The `final` stage formats the changed files, runs focused checks, then reruns the selected tests. Use another fresh directory for another experiment. The original PR patches have older surrounding context, so they are included for attribution; the runner ports only their added guard/retention lines. `source/typescript/combined-source.patch` is the final combined diff against the tested pin.

The supplied final test has a corrected structural interface and type import. The original baseline/guard records used the earlier runtime-equivalent version and therefore list a different test-file hash. A reproduction with the supplied final test verifies the same runtime assertions but cannot recreate the original earlier source hash. The final TypeScript check is source plus this test/imports, not the full release stack.

5. For Python, use Python 3.12.14 and install the runtime dependency families into sibling `py-runtime`, applying `python-constraints.txt`: `httpx2`, `anyio`, `docstring-parser`, `sniffio`, `typing-extensions`, `pydantic`, `jiter`, and `opentelemetry-api`. Alternatively use an isolated compatible environment and adjust the runner's import path deliberately. The constraints include more packages from the pinned lock than this small script requires; the saved receipt records the actual loaded versions.

```text
python run-verification.py python
```

This mode uses the current Python executable, sets `PYTHONPATH` to the pinned source and `py-runtime`, and runs `python-characterization.py` with bytecode disabled. `git` must be on PATH for the characterization's source-pin check. It records 32 scenarios and exits zero when all match the described existing behavior and the five monitored files remain unchanged. A match is not an endorsement of the behavior and not a Python SDK-suite pass. The script uses `httpx2.MockTransport`, an explicit `.invalid` host, synthetic credentials and disabled tracing. Async cancellation is outside its scope.

6. Compare JSON results, receipts, source hashes and logs. `MANIFEST.json` identifies edition bytes; `PROVENANCE.json` maps copied and sanitized artifacts to original source hashes. Receipt log hashes were preserved from the source record and may differ from public sanitized log hashes. Source line endings affect SHA-256; baseline snapshots retain the recorded Windows bytes and the final sources retain their formatted bytes.

Neither edition preparation nor reading these instructions executes checks. The original results do not certify a newer commit, a live-provider workflow, a release or every SDK platform. The Python repository requires its scripts for formal tests/lint/format; this reproduction is a standalone characterization. Preserve contributor credit and MIT notices when sharing derivatives.
