# Credits and source rights

- **qiyuhuating**: [TypeScript issue #1264](https://github.com/anthropics/anthropic-sdk-typescript/issues/1264), incomplete completion report.
- **ax3cubed**: [PR #1265](https://github.com/anthropics/anthropic-sdk-typescript/pull/1265), completion guard; reviewed head `4354ccd218975d482c89d637a5d13bcebacf4864`.
- **sylvesterkaczmarek**: [issue #1247](https://github.com/anthropics/anthropic-sdk-typescript/issues/1247) and [PR #1248](https://github.com/anthropics/anthropic-sdk-typescript/pull/1248), retained iterator error; reviewed head `dd68af161096bd7688a5b4709f8a950bdb8f708f`.
- **Anthropic, PBC and SDK contributors**: upstream SDK source, tests, fixtures and documentation. The original MIT notices are preserved in `LICENSES/anthropic-sdk-typescript-LICENSE.txt` and `LICENSES/anthropic-sdk-python-LICENSE.txt`.
- **feiiiiii5**: adjacent [Python PR #1959](https://github.com/anthropics/anthropic-sdk-python/pull/1959), unnamed-error handling. That proposal addresses a different trigger and is not included as a newly discovered result here.

This edition's added work is the integration test, local comparison, Python characterization and evidence presentation. Existing fixes retain their original authorship. The research used AI-assisted implementation/review; the root agent executed checks sequentially, while Nadine and Leviathan reviewed separate source/test/contract boundaries and another review checked prior reports. These are local agent reviews, not Anthropic review or external peer review.

Upstream material remains subject to its included license notices. Attribution and package hashes do not establish authorship of upstream work, maintainers' acceptance or release readiness.

The new contribution test, characterization, execution runner and focused configuration are licensed under the [scoped MIT contribution-code license](LICENSE-MIT-CONTRIBUTIONS.txt), copyright 2026 Sherman G. Laing. That license identifies its exact code scope. It does not relicense unrelated original research, mathematics/history records or third-party material. Original upstream source, tests, fixtures and patch proposals retain their separate included MIT notices.
