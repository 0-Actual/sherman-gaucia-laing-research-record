# Public-edition derivation

Original research evidence is preserved privately. This directory contains selected exact copies and clearly recorded derivatives, not a byte-identical copy of the private evidence archive.

`PROVENANCE.json` gives each copied artifact's source-relative name, original byte count/SHA-256, edition byte count/SHA-256 and transformation. Source names are relative to the research workspace; personal absolute paths are omitted. `MANIFEST.json` independently covers every edition file except itself.

For logs and receipts containing local paths, exact known research-workspace, task-workspace, user-home, Node-install and sandbox-temporary prefixes are replaced with descriptive angle-bracket tokens. Slash and JSON-escaped forms are handled. Result values, case names, assertions, timestamps, exception types, recorded process exits and original hash fields remain intact. JSON derivatives remain valid JSON. Text logs retain their failure details. ANSI terminal color codes, if present, are removed for readable public records.

Hash fields inside a sanitized receipt continue to identify the **original private log or script**, as they did when recorded. They must not be read as hashes of sanitized public bytes. Use the edition hash in PROVENANCE or MANIFEST for a public file. Empty logs and path-free source manifests remain byte-identical when no transformation is needed.

The execution runner is a portability derivative: personal Node/Git executable locations are replaced by PATH lookup with optional `NODE_BINARY`/`GIT_BINARY` environment values. A header marks that change. It has not been executed as part of edition preparation. The Python characterization, final 24-case TypeScript test, combined source patch, upstream patches, selected source snapshots, constraints and license notices are exact copies unless PROVENANCE explicitly states otherwise.

This edition omits dependency binaries, temporary directories, private workspace/account details and unrelated research. It does not include real credentials, private model conversations or live-provider response content. The fixed credential-like value in the Python script is deliberately synthetic and used only with its in-memory mock transport.

Preparation checks only file identities, JSON readability, population counts, edition completeness and the stated path/credential screening patterns. It does not rerun the tests or prove that a pattern scan can detect every possible sensitive datum. The selected scripts, report and evidence fields were also reviewed for relevance.
