"""Run one focused check against pinned source, preserving its full log."""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parent
runtime = Path(r"<RELATED_WORKSPACE>\work\openai-env\Lib\site-packages")
site = root / "env/Lib/site-packages"
(site / "existing_sdk_dependencies.pth").write_text(
    f"import site; site.addsitedir({str(runtime)!r})\n", encoding="utf-8"
)
evidence = root / "evidence"
evidence.mkdir(exist_ok=True)
name, *args = sys.argv[1:]
assert name.replace("-", "").replace("_", "").isalnum()
environment = os.environ.copy()
environment.update(
    PYTHONPATH=str(root / "source/src"),
    TEMP=str(root / "tmp"), TMP=str(root / "tmp"),
    OPENAI_API_KEY="synthetic-offline-test-key",
    OPENAI_AGENTS_DISABLE_TRACING="1",
    PYTHONIOENCODING="utf-8",
)
command = [str(root / "env/Scripts/python.exe"), "-m", "pytest", *args]
started = datetime.now(timezone.utc).isoformat()
with (evidence / f"{name}.txt").open("w", encoding="utf-8") as log:
    completed = subprocess.run(command, cwd=root / "source", env=environment,
                               stdout=log, stderr=subprocess.STDOUT, timeout=480)
receipt = {"command": command, "started_utc": started,
           "finished_utc": datetime.now(timezone.utc).isoformat(),
           "returncode": completed.returncode}
(evidence / f"{name}.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
print(json.dumps(receipt, indent=2))
print((evidence / f"{name}.txt").read_text(encoding="utf-8")[-6500:])
raise SystemExit(completed.returncode)
