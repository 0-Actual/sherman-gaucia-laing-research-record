# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Offline baseline, correction, and negative-control verification.

Run with Python 3.12 and openai-agents==0.24.0. No model API or real shell calls.
The candidate replaces one class in this process, never installed SDK files.
"""
from pathlib import Path
import contextlib
import hashlib
import importlib.metadata
import json
import platform
import sys
import types
import unittest
from datetime import datetime, timezone
from unittest.mock import patch

from agents import result as result_module, set_tracing_disabled
from agents.run_internal import tool_actions

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "shell"))
sys.path.insert(0, str(ROOT / "stream"))
import test_integrity
import test_owned_stream

set_tracing_disabled(True)
source = Path(tool_actions.__file__).read_bytes()
expected = "d7c5000ce55675eb016c0cf53fd89c3cc0d40d66cc7f86459c14a60d40238d70"
assert hashlib.sha256(source).hexdigest() == expected, "Unexpected SDK source; review before testing."
old = b"            if shell_output_payload:"
new = b"            if shell_output_payload is not None:"
assert source.count(old) == 1
candidate = types.ModuleType("agents.run_internal._qel_submission_candidate")
candidate.__package__ = "agents.run_internal"
candidate.__file__ = str(ROOT / "shell/fix.diff")
exec(compile(source.replace(old, new), str(ROOT / "shell/fix.diff"), "exec"), candidate.__dict__)
receipt = {
    "started_utc": datetime.now(timezone.utc).isoformat(),
    "python": platform.python_version(), "platform": sys.platform,
    "sdk_version": importlib.metadata.version("openai-agents"),
    "tool_actions_sha256": expected,
    "result_sha256": hashlib.sha256(Path(result_module.__file__).read_bytes()).hexdigest(),
    "runs": {},
    "live_model_calls": False, "real_shell_calls": False,
}


def run(name, suite):
    with (ROOT / (name + ".txt")).open("w", encoding="utf-8") as log:
        result = unittest.TextTestRunner(stream=log, verbosity=2).run(suite)
    row = {
        "tests": result.testsRun,
        "failures": [x.id() for x, _ in result.failures],
        "errors": [x.id() for x, _ in result.errors],
        "skipped": [x.id() for x, _ in result.skipped],
    }
    receipt["runs"][name] = row
    print(name, json.dumps(row), flush=True)
    return row


baseline = run("shell-baseline", unittest.defaultTestLoader.loadTestsFromModule(test_integrity))
with patch.object(tool_actions, "ShellAction", candidate.ShellAction):
    corrected = run("shell-corrected", unittest.defaultTestLoader.loadTestsFromModule(test_integrity))


@contextlib.asynccontextmanager
async def omit_ownership(result):
    # Deliberately wrong negative control: abandoning a consumer is not cancellation.
    yield result.stream_events()


with patch.object(test_owned_stream, "owned_stream", omit_ownership):
    negative = run("stream-negative-control", unittest.TestSuite([
        test_owned_stream.StreamIntegration("test_break_after_event_stops_and_settles_tool")
    ]))
positive = run("stream-corrected", unittest.defaultTestLoader.loadTestsFromModule(test_owned_stream))
assert Path(tool_actions.__file__).read_bytes() == source
receipt["installed_source_unchanged"] = True
receipt["finished_utc"] = datetime.now(timezone.utc).isoformat()
expected_failed = {f"test_integrity.ShellIntegrity.test_{mode}_{case}"
                   for mode in ("run", "stream")
                   for case in ("empty", "empty_with_metadata")}
receipt["acceptance_passed"] = (
    set(baseline["failures"]) == expected_failed
    and not baseline["errors"] and not baseline["skipped"]
    and corrected["tests"] == 32 and not any(corrected[k] for k in ("failures", "errors", "skipped"))
    and len(negative["failures"]) == 1 and not negative["errors"]
    and positive["tests"] == 10 and not any(positive[k] for k in ("failures", "errors", "skipped"))
)
(ROOT / "VALIDATION-20261020.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
raise SystemExit(0 if receipt["acceptance_passed"] else 1)
