### Executable regression coverage for the empty-structured-result fix

Building on BlueX888's report, jbeckwith-oai's response, and zhgao's existing
proposal, here is a tested one-line correction plus a self-contained regression
suite. The additional contribution is coverage of both runner modes, preservation
of metadata and display behavior, and the actual next model input. This is
corroboration and regression coverage, not a claim of original discovery.

On October 20 I checked `src/agents/run_internal/tool_actions.py` at main
`64cd5dfc5a1579870dcbed0ea42b27aa84033fee`: it is byte-identical to the
`openai-agents==0.24.0` file tested below. The presence/truthiness distinction is
still relevant. Synthetic tests on Windows, Python 3.12.14:

- Baseline: 32 tests, 28 pass and four fail. The failing cases are empty structured
  results, with/without metadata, in ordinary and streamed runs.
- With the single predicate correction: all 32 pass, no errors or skips.
- The eight approval/state controls already pass on the baseline; no approval
  bypass is claimed. The other 24 cases test shell-result behavior.

The correction keeps the human-readable display placeholder while preserving
`output=[]` in the retained item, its input conversion, and the next scripted
model request. It does not invent a successful exit code for an absent entry.
Explicit quiet success, unknown exit code, failure, timeout, multiple entries,
plain strings (including the literal placeholder), rejection, output limits,
executor exceptions, and provider metadata are checked.

No shell command, live model, credential, billing experiment, or production incident
is involved. These are bounded synthetic checks, not full SDK or security validation.
The installed SDK was not modified during evaluation.

### Patch

```diff
--- a/src/agents/run_internal/tool_actions.py
+++ b/src/agents/run_internal/tool_actions.py
@@ -624,7 +624,7 @@
                 log_tool_action_error("Shell executor failed", exc)
 
             raw_entries: list[dict[str, Any]] | None = None
-            if shell_output_payload:
+            if shell_output_payload is not None:
                 raw_entries = shell_output_payload
             elif output_text:
                 raw_entries = [
```

### Regression file

Save the following as `test_integrity.py`. With `openai-agents==0.24.0` installed,
run `python -m unittest -v test_integrity`. The unpatched package should fail the
four cases above. Apply the one-line correction in a separate SDK development
checkout to test the corrected path; do not patch an installed production package.
Our evaluation loaded that corrected class only inside the test process.

<details><summary>Complete runnable regression suite</summary>

```python
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Synthetic runner regressions. No shell commands or model API requests are made."""
from __future__ import annotations

import copy
import json
import unittest

from agents import Agent, RunConfig, Runner, RunState, function_tool
from agents.exceptions import ModelBehaviorError
from agents.items import ToolCallOutputItem
from agents.testing import ModelStep, ScriptedModel, assistant_message, function_call
from agents.tool import ShellCallOutcome, ShellCommandOutput, ShellResult, ShellTool
from openai.types.responses import (
    Response, ResponseCompletedEvent, ResponseFunctionShellToolCall,
    ResponseOutputItemDoneEvent,
)


async def run_agent(agent, data, mode):
    config = RunConfig(tracing_disabled=True)
    if mode == "stream":
        result = Runner.run_streamed(agent, data, max_turns=6, run_config=config)
        async for _ in result.stream_events():
            pass
        return result
    return await Runner.run(agent, data, max_turns=6, run_config=config)


class ApprovalControls(unittest.IsolatedAsyncioTestCase):
    async def scenario(self, mode, case):
        executed = []

        @function_tool(needs_approval=True)
        async def record(value: int) -> str:
            """Record a synthetic value in memory."""
            executed.append(value)
            return "recorded"

        @function_tool
        async def permitted_sibling(value: int) -> str:
            """Record a permitted synthetic sibling action in memory."""
            executed.append(value)
            return "recorded"

        steps = [[function_call("record", {"value": 1}, call_id="approved-id")]]
        if case == "changed_id_with_sibling":
            steps.append([
                function_call("record", {"value": 2}, call_id="approved-id"),
                function_call("permitted_sibling", {"value": 3}, call_id="sibling-id"),
            ])
        steps.append([assistant_message("finished")])
        model = ScriptedModel(steps)
        agent = Agent(name="approval-controls", model=model, tools=[record, permitted_sibling])
        paused = await run_agent(agent, "synthetic input", mode)
        self.assertEqual(executed, [])
        self.assertEqual(len(paused.interruptions), 1)
        self.assertEqual(len(model.calls), 1)
        if case == "pause_without_permission":
            return
        state = paused.to_state()
        if case == "reject":
            state.reject(paused.interruptions[0])
        else:
            state.approve(paused.interruptions[0])
        # Real JSON round-trip at the supported trusted-storage boundary.
        # This does not claim that from_json authenticates untrusted state.
        state = await RunState.from_json(agent, json.loads(json.dumps(state.to_json())))
        if case == "changed_id_with_sibling":
            with self.assertRaises(ModelBehaviorError):
                await run_agent(agent, state, mode)
            self.assertEqual(executed, [1])
        else:
            completed = await run_agent(agent, state, mode)
            self.assertEqual(completed.final_output, "finished")
            self.assertEqual(executed, [] if case == "reject" else [1])
            self.assertEqual(completed.interruptions, [])
            model.assert_complete()


def shell_call(*, cap=None):
    action = {"type": "shell_command", "commands": ["synthetic-no-execution"]}
    if cap is not None:
        action["max_output_length"] = cap
    return ResponseFunctionShellToolCall(
        id="shell-id", call_id="shell-call", type="shell_call", action=action,
        status="completed",
    )


class ShellIntegrity(unittest.IsolatedAsyncioTestCase):
    async def scenario(self, mode, case):
        executed = []
        cap = None
        if case == "empty":
            value = ShellResult(output=[])
            expected = []
        elif case == "empty_with_metadata":
            cap = 9
            value = ShellResult(output=[], max_output_length=4, provider_data={"label": "synthetic"})
            expected = []
        elif case == "quiet_success":
            value = ShellResult(output=[ShellCommandOutput(outcome=ShellCallOutcome(type="exit", exit_code=0))])
            expected = [{"stdout": "", "stderr": "", "outcome": {"type": "exit", "exit_code": 0}}]
        elif case == "unknown_exit":
            value = ShellResult(output=[ShellCommandOutput()])
            expected = [{"stdout": "", "stderr": "", "outcome": {"type": "exit", "exit_code": None}}]
        elif case == "failure":
            value = ShellResult(output=[ShellCommandOutput(stdout="partial", stderr="failed", outcome=ShellCallOutcome(type="exit", exit_code=7))])
            expected = [{"stdout": "partial", "stderr": "failed", "outcome": {"type": "exit", "exit_code": 7}}]
        elif case == "timeout":
            value = ShellResult(output=[ShellCommandOutput(stderr="timeout", outcome=ShellCallOutcome(type="timeout"))])
            expected = [{"stdout": "", "stderr": "timeout", "outcome": {"type": "timeout"}}]
        elif case == "multiple":
            value = ShellResult(output=[ShellCommandOutput(stdout="one"), ShellCommandOutput(stdout="two")])
            expected = [{"stdout": x, "stderr": "", "outcome": {"type": "exit", "exit_code": None}} for x in ("one", "two")]
        elif case == "plain_empty":
            value = ""
            expected = []
        elif case == "zero_limit":
            cap = 0
            value = ShellResult(output=[])
            expected = []
        elif case == "executor_exception":
            value = RuntimeError("synthetic executor failure")
            expected = [{"stdout": "synthetic executor failure", "stderr": "", "outcome": {"type": "exit", "exit_code": 1}}]
        elif case == "literal_placeholder":
            value = "(no output)"
            expected = [{"stdout": "(no output)", "stderr": "", "outcome": {"type": "exit", "exit_code": 0}}]
        elif case == "rejected":
            value = ShellResult(output=[])
            expected = None
        else:
            raise AssertionError(case)

        original = copy.deepcopy(value)

        async def synthetic_executor(request):
            executed.append(request.data.call_id)
            if isinstance(value, Exception):
                raise value
            return value

        call = shell_call(cap=cap)
        first_step = [call]
        if mode == "stream":
            # Shell calls require explicit normalized events in ScriptedModel.
            response = Response(
                id="synthetic-response", created_at=0, model="synthetic",
                object="response", output=[call], tool_choice="auto", tools=[],
                parallel_tool_calls=True,
            )
            first_step = ModelStep.stream([
                ResponseOutputItemDoneEvent(type="response.output_item.done", sequence_number=0, output_index=0, item=call),
                ResponseCompletedEvent(type="response.completed", sequence_number=1, response=response),
            ], output=[call])
        model = ScriptedModel([first_step, [assistant_message("finished")]])
        agent = Agent(name="shell-integrity", model=model, tools=[
            ShellTool(executor=synthetic_executor, needs_approval=(case == "rejected"))
        ])
        result = await run_agent(agent, "synthetic input", mode)
        if case == "rejected":
            self.assertEqual(executed, [])
            self.assertEqual(len(result.interruptions), 1)
            state = result.to_state()
            state.reject(result.interruptions[0])
            result = await run_agent(agent, state, mode)
            self.assertEqual(executed, [])
            self.assertEqual(result.final_output, "finished")
            return

        self.assertEqual(executed, ["shell-call"])
        if not isinstance(value, Exception):
            self.assertEqual(value, original)
        outputs = [x for x in result.new_items if isinstance(x, ToolCallOutputItem)]
        self.assertEqual(len(outputs), 1)
        item = outputs[0]
        self.assertEqual(item.raw_item["output"], expected)
        self.assertEqual(item.to_input_item()["output"], expected)
        replayed = [x for x in model.last_call.input if x.get("type") == "shell_call_output"]
        self.assertEqual(len(replayed), 1)
        self.assertEqual(replayed[0]["output"], expected)
        if expected == []:
            self.assertNotIn("shell_output", item.raw_item)
        if case == "empty_with_metadata":
            self.assertEqual(item.raw_item["provider_data"], {"label": "synthetic"})
            self.assertEqual(item.raw_item["max_output_length"], 4)
        if case == "zero_limit":
            self.assertEqual(item.raw_item["max_output_length"], 0)
        if case == "executor_exception":
            self.assertEqual(item.raw_item["status"], "failed")
        if case in ("empty", "empty_with_metadata"):
            self.assertEqual(item.output, "(no output)" if case == "empty" else "(no ")
        self.assertEqual(result.final_output, "finished")
        model.assert_complete()


def install_cases(cls, cases):
    for mode in ("run", "stream"):
        for case in cases:
            async def test(self, selected_mode=mode, selected_case=case):
                await self.scenario(selected_mode, selected_case)
            setattr(cls, f"test_{mode}_{case}", test)


install_cases(ApprovalControls, ("pause_without_permission", "reject", "approved_json_resume", "changed_id_with_sibling"))
install_cases(ShellIntegrity, ("empty", "empty_with_metadata", "quiet_success", "unknown_exit", "failure", "timeout", "multiple", "plain_empty", "literal_placeholder", "rejected", "zero_limit", "executor_exception"))

if __name__ == "__main__":
    unittest.main(verbosity=2)
```

</details>

### Contribution license and attribution

Prepared with Codex assistance at Sherman G. Laing's direction. The code supplied
in this comment is offered under the repository's MIT terms, including permission
for commercial use, modification, and redistribution. This grant covers these
contribution copies; it does not relicense unrelated work or change attribution
for the original issue and earlier proposals.

<details><summary>MIT license for the contributed code</summary>

```text
MIT License

Copyright (c) 2026 Sherman G. Laing
Copyright (c) 2025 OpenAI (upstream-derived patch)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

</details>
