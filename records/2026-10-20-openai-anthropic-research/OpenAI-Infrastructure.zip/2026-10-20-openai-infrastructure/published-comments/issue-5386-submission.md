### Tested opt-in stream ownership, including cancellation during cleanup

This contributes runnable code and regression tests for callers who explicitly
want the run to stop when their consumer exits. It follows the existing report
and the useful #4130 discussion above. In particular, it does **not** globally
change the SDK's intentional abandoned-consumer behavior or claim that every
detached consumer is a defect.

The helper uses public `cancel()` and `stream_events()` APIs. It requests
cancellation on early exit, waits for cleanup, retains the original consumer
exception, and survives repeated cancellation while waiting for cleanup.
Normal exhaustion leaves the result intact. It is an additive application-side
option, not a proposed replacement of the SDK's default stream contract.

Fresh verification on October 20, Windows/Python 3.12.14,
`openai-agents==0.24.0`:

- Eight real SDK integration cases and two cleanup-protocol cases pass.
- Replacing the helper with a deliberately broken context that only yields
  `result.stream_events()` causes the early-break cleanup test to fail.
  Restoring the helper passes that test and the complete ten-case suite.
- The installed `src/agents/result.py` is byte-identical to current main
  `64cd5dfc5a1579870dcbed0ea42b27aa84033fee`.

Coverage includes normal completion, break, exit before the first event, consumer
failure, cancellation in the body and during the next-event wait, repeated
cancellation during delayed tool cleanup, retention of the original error during
late cancellation, and cleanup-error propagation without copying private error
text into secondary exception notes. The tests use `ScriptedModel` and synthetic
in-memory tools with tracing disabled; no live model, network provider, billing
measurement, or real shell command was used.

Scope: one owning consumer. Tools/providers must cooperate with cancellation.
This does not undo completed effects, impose a timeout, or validate every provider
or sandbox lifecycle. The tests inspect SDK task state to verify settlement;
the helper itself uses the public cancellation/drain APIs.

Save the two files below together, install `openai-agents==0.24.0`, and run
`python -m unittest -v test_owned_stream`.

```python
async with owned_stream(result) as events:
    async for event in events:
        await forward(event)
```

<details><summary>owned_stream.py — complete implementation</summary>

```python
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Explicit ownership of an Agents SDK stream through public cancellation APIs.

Original project addition. This contribution copy is licensed under MIT.
This module has no OpenAI import and copies no SDK implementation.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Protocol, TypeVar


Event = TypeVar("Event", covariant=True)


class StreamResult(Protocol[Event]):
    is_complete: bool

    def stream_events(self) -> AsyncIterator[Event]: ...

    def cancel(self) -> None: ...


async def _settle(task: asyncio.Task[None]) -> tuple[BaseException | None, BaseException | None]:
    """Retain cleanup ownership even when its waiting caller is cancelled again."""
    interruption: BaseException | None = None
    while not task.done():
        try:
            await asyncio.shield(task)
        except asyncio.CancelledError as error:
            if task.cancelled():
                break
            interruption = error
        except BaseException:
            break
    try:
        task.result()
    except BaseException as error:
        return error, interruption
    return None, interruption


@asynccontextmanager
async def owned_stream(result: StreamResult[Event]) -> AsyncIterator[AsyncIterator[Event]]:
    """Own one stream, cancel on early exit, and await its cleanup boundary.

    Use exactly one consumer inside this context. Normal exhaustion does not
    request cancellation. A break, body failure, or caller cancellation does.
    Tools and providers must cooperate with cancellation; this is not a sandbox,
    a timeout, or a rollback mechanism for effects that have already happened.
    """
    source = result.stream_events()
    exhausted = False
    source_failed = False
    primary_error: BaseException | None = None

    async def events() -> AsyncIterator[Event]:
        nonlocal exhausted, source_failed
        while True:
            try:
                event = await anext(source)
            except StopAsyncIteration:
                exhausted = True
                return
            except BaseException:
                source_failed = True
                raise
            yield event

    iterator = events()
    try:
        yield iterator
    except BaseException as error:
        primary_error = error
        raise
    finally:
        async def cleanup() -> None:
            if not exhausted and not result.is_complete:
                result.cancel()
            await iterator.aclose()
            if not exhausted:
                # A cancelled source iterator can already be closed before its
                # background producer settles. Re-enter the public drain path.
                remaining = result.stream_events() if source_failed else source
                async for _ in remaining:
                    pass

        cleanup_task = asyncio.create_task(cleanup())
        cleanup_error, interruption = await _settle(cleanup_task)
        outcome_error = primary_error if primary_error is not None else interruption
        if outcome_error is None:
            outcome_error = cleanup_error
        if outcome_error is not None:
            for secondary in (cleanup_error, interruption):
                if secondary is not None and secondary is not outcome_error:
                    outcome_error.add_note(
                        "Stream cleanup also encountered " + type(secondary).__name__
                        + "; exception text is omitted to avoid copying payload data."
                    )
            if primary_error is None:
                raise outcome_error
```

</details>

<details><summary>test_owned_stream.py — complete runnable tests</summary>

```python
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Offline integration checks against the released Agents SDK; no API calls."""

from __future__ import annotations

import asyncio
import unittest

from agents import Agent, RunConfig, Runner
from agents.decorators import tool
from agents.testing import ScriptedModel, assistant_message, function_call

from owned_stream import owned_stream


class StreamIntegration(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.results = []
        self.tasks = []
        self.releases = []

    async def asyncTearDown(self):
        for release in self.releases:
            release.set()
        for result in self.results:
            if not result.is_complete:
                result.cancel()
            try:
                async with asyncio.timeout(3):
                    async for _ in result.stream_events():
                        pass
            except Exception:
                pass
        for task in self.tasks:
            if not task.done():
                task.cancel()
        await asyncio.gather(*self.tasks, return_exceptions=True)

    def run_result(self, model, tools=()):
        result = Runner.run_streamed(
            Agent(name="offline-ownership-test", model=model, tools=list(tools)),
            "synthetic input",
            run_config=RunConfig(tracing_disabled=True),
        )
        self.results.append(result)
        return result

    async def blocked_tool(self, delayed_cleanup=False):
        started = asyncio.Event()
        release = asyncio.Event()
        cleanup_started = asyncio.Event()
        cleanup_release = asyncio.Event()
        settled = asyncio.Event()
        self.releases.extend([release, cleanup_release])

        @tool
        async def controlled_work() -> str:
            """Run a synthetic cancellable operation."""
            started.set()
            try:
                await release.wait()
                return "synthetic success"
            finally:
                cleanup_started.set()
                if delayed_cleanup:
                    await cleanup_release.wait()
                settled.set()

        model = ScriptedModel([
            [function_call("controlled_work", {}, call_id="synthetic-call")],
            [assistant_message("done")],
        ])
        result = self.run_result(model, [controlled_work])
        await asyncio.wait_for(started.wait(), 3)
        return result, cleanup_started, cleanup_release, settled

    def assert_settled(self, result, settled):
        self.assertTrue(result.is_complete)
        self.assertTrue(settled.is_set())
        self.assertTrue(result.run_loop_task.done())

    async def test_normal_completion_preserves_output(self):
        result = self.run_result(ScriptedModel([[assistant_message("done")]]))
        async with owned_stream(result) as events:
            observed = [event async for event in events]
        self.assertTrue(observed)
        self.assertEqual(result.final_output, "done")
        self.assertTrue(result.run_loop_task.done())

    async def test_break_after_event_stops_and_settles_tool(self):
        result, _, _, settled = await self.blocked_tool()
        async with owned_stream(result) as events:
            async for _ in events:
                break
        self.assert_settled(result, settled)

    async def test_exit_before_first_event_settles_tool(self):
        result, _, _, settled = await self.blocked_tool()
        async with owned_stream(result):
            pass
        self.assert_settled(result, settled)

    async def test_body_failure_is_preserved_after_cleanup(self):
        result, _, _, settled = await self.blocked_tool()
        expected = ConnectionError("synthetic downstream failure")
        with self.assertRaises(ConnectionError) as caught:
            async with owned_stream(result) as events:
                async for _ in events:
                    raise expected
        self.assertIs(caught.exception, expected)
        self.assert_settled(result, settled)

    async def test_cancel_in_body_settles_tool_before_propagating(self):
        result, _, _, settled = await self.blocked_tool()
        handling = asyncio.Event()
        hold = asyncio.Event()

        async def consume():
            async with owned_stream(result) as events:
                async for _ in events:
                    handling.set()
                    await hold.wait()

        consumer = asyncio.create_task(consume())
        self.tasks.append(consumer)
        await asyncio.wait_for(handling.wait(), 3)
        consumer.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await consumer
        self.assert_settled(result, settled)

    async def test_cancel_during_next_event_wait_settles_tool(self):
        result, _, _, settled = await self.blocked_tool()
        waiting = asyncio.Event()

        async def consume():
            async with owned_stream(result) as events:
                async for _ in events:
                    waiting.set()

        consumer = asyncio.create_task(consume())
        self.tasks.append(consumer)
        await asyncio.wait_for(waiting.wait(), 3)
        # Let finite queued events drain so cancellation reaches the source wait.
        async with asyncio.timeout(3):
            while not result._waiting_on_event_queue:
                await asyncio.sleep(0)
        consumer.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await consumer
        self.assert_settled(result, settled)

    async def test_repeated_cancellation_does_not_abandon_cleanup(self):
        result, cleanup_started, cleanup_release, settled = await self.blocked_tool(True)

        async def consume():
            async with owned_stream(result) as events:
                async for _ in events:
                    break

        consumer = asyncio.create_task(consume())
        self.tasks.append(consumer)
        await asyncio.wait_for(cleanup_started.wait(), 3)
        consumer.cancel()
        await asyncio.sleep(0)
        consumer.cancel()
        await asyncio.sleep(0)
        self.assertFalse(consumer.done())
        self.assertFalse(settled.is_set())
        cleanup_release.set()
        with self.assertRaises(asyncio.CancelledError):
            await consumer
        self.assert_settled(result, settled)

    async def test_error_with_late_cancellation_retains_original_error(self):
        result, cleanup_started, cleanup_release, settled = await self.blocked_tool(True)
        expected = ConnectionError("synthetic downstream failure")

        async def consume():
            async with owned_stream(result) as events:
                async for _ in events:
                    raise expected

        consumer = asyncio.create_task(consume())
        self.tasks.append(consumer)
        await asyncio.wait_for(cleanup_started.wait(), 3)
        consumer.cancel()
        await asyncio.sleep(0)
        cleanup_release.set()
        with self.assertRaises(ConnectionError) as caught:
            await consumer
        self.assertIs(caught.exception, expected)
        self.assert_settled(result, settled)


class CleanupFailureContract(unittest.IsolatedAsyncioTestCase):
    async def test_cleanup_failure_preserves_original_without_payload_note(self):
        class FailedResult:
            is_complete = False

            def cancel(self):
                self.is_complete = True

            async def stream_events(self):
                yield "synthetic event"
                raise RuntimeError("synthetic private cleanup payload")

        expected = ValueError("synthetic body failure")
        with self.assertRaises(ValueError) as caught:
            async with owned_stream(FailedResult()) as events:
                async for _ in events:
                    raise expected
        self.assertIs(caught.exception, expected)
        self.assertIn("RuntimeError", " ".join(expected.__notes__))
        self.assertNotIn("private cleanup payload", " ".join(expected.__notes__))

    async def test_cleanup_failure_without_body_error_is_visible(self):
        class FailedResult:
            is_complete = False

            def cancel(self):
                self.is_complete = True

            async def stream_events(self):
                yield "synthetic event"
                raise RuntimeError("synthetic cleanup failure")

        with self.assertRaisesRegex(RuntimeError, "synthetic cleanup failure"):
            async with owned_stream(FailedResult()) as events:
                async for _ in events:
                    break


if __name__ == "__main__":
    unittest.main(verbosity=2)
```

</details>

### Contribution license and attribution

Prepared with Codex assistance at Sherman G. Laing's direction. The code supplied
in this comment is offered under the repository's MIT terms, including permission
for commercial use, modification, and redistribution. This grant covers these
contribution copies; it does not relicense unrelated work or change attribution
for the original issue and earlier proposals.

<details><summary>MIT license for the contributed code</summary>

```text
MIT License

Copyright (c) 2026 Sherman G. Laing
Copyright (c) 2025 OpenAI (upstream-derived patch)

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

</details>
