# Leviathan independent semantic review records

These are the two review reports delivered in this chat on October 20, 2026, reproduced here for the local evidence handoff. They are semantic review records, not strict Git-protocol receipts. Both passes were read-only and ran no tests.

## Revision 1 report

No actionable patch-scoped runtime defect found in this read-only pass. I recommend retaining the narrow implementation, with the verification limits below.

Reviewed pinned upstream `64cd5dfc5a1579870dcbed0ea42b27aa84033fee`, the complete three-file diff, and surrounding converter, provider, Runner, shell execution, approval, and replay paths. SHA-256 values matched the manifest and remained unchanged at review end:

| Content | SHA-256 |
|---|---|
| `review/complete.diff` | `0c81cf050ae51792f8c197e27abad0ef8e09320f414609006034e268002c9e97` |
| `src/agents/models/chatcmpl_converter.py` | `173b6e5af1972e5767470a40e713917386f4f1cbcc96f4eefa21091b79f5459d` |
| `src/agents/run_internal/tool_actions.py` | `6b431942d1a68d74e8699c5215e5a78c477acf6678b8bb69c524906331f5303b` |
| `tests/models/test_history_replay_regression.py` | `69ecc2119356e1921f8ebcd14e3b885ef205d023b6f151a523771702e00a1bae` |

Semantic conclusions:

- **History, converter lines 770–791:** Successive output messages join the assistant message owning pending calls. String and list content remain intact; successive refusals concatenate. Matching tool outputs flush the assistant at line 868, separating later turns. Calls retain their IDs, and the changed operations construct replacement content rather than modifying input items.
- **Reasoning:** Existing reasoning application consumes pending state, while the merge preserves previously attached fields and content. I found no supported-path reasoning regression introduced by the patch. Arbitrary malformed histories and unsupported cross-provider combinations were not promoted into requirements.
- **Shell, line 627:** The change has a concrete effect. `render_shell_outputs([])` returns `"(no output)"` (`tool_execution.py:975–978`); the old fallback fabricated a successful output entry from that display string. The patch retains model-facing `output: []`. Approval resolution precedes this branch, executor exceptions retain the existing fallback, and cancellation/cleanup ownership is unchanged.
- **Runner integration:** Ordinary and streamed adapter paths share `_fetch_response()` and its converter call. The new transport-capture test reaches public `Runner.run` and `Runner.run_streamed`, exhausts streamed events, and checks the actual request messages.

Evidence and remaining gaps:

- Read the recorded **11 baseline failures** and **169 focused passes** and their command receipts; I ran no tests.
- Inspected immutable `shell/test_integrity.py` (`b8f1bb60ec9e129b30d6c096c7805d8607b494af74a495bfa163248cfca98716`). Its 32 cases include empty output, metadata, ordinary/streamed replay, failures, rejection, and input preservation. Its published receipt records four baseline failures and 32 corrected passes on SDK **0.24.0**, not this pinned snapshot. Reusing those tests against the current snapshot would close that evidence gap.
- The new history tests do not combine multiple output messages with reasoning metadata. A focused regression for that explicit contract would strengthen verification; this is a coverage recommendation, not a confirmed defect.
- The source archive hash matches its receipt: `0a0cd5dd31e1e10e9bb08fab5da8ca9300d8d0608eb6debabfc57049fa137957`. This review does **not** certify the strict Git-based review gate, release compatibility, or the full final verification stack.

## Revision 2 report

Revision 2: no actionable findings.

The added test at `tests/models/test_history_replay_regression.py:132–174` covers both native and legacy thinking blocks through multiple same-turn messages. It checks exact text/block content, signature preservation, call IDs, later-turn separation, and input immutability. Those assertions agree with the unchanged converter boundaries.

Verified SHA-256:

| Content | SHA-256 |
|---|---|
| Complete diff | `5a15636c76b5a104ad166bb6aa96c0d31f11f2dbccd1914e4d6dc52e2ebf1526` |
| Manifest | `7de7eb6bc2e1a0004b2466adf1f84e4bd09ec61cf0251cac57a07e94952af684` |
| History test | `eaa6cf4d01823a9fe1ae9834adf2a751303500541f3e8d848ce3154b162623e7` |
| Converter—unchanged | `173b6e5af1972e5767470a40e713917386f4f1cbcc96f4eefa21091b79f5459d` |
| Shell action—unchanged | `6b431942d1a68d74e8699c5215e5a78c477acf6678b8bb69c524906331f5303b` |

I inspected the receipts and logs recording **13 history tests passing** and **32 existing shell tests passing against the current snapshot**. These address the specific coverage gaps identified in my first review.

Recommendation: accept this revision’s bounded semantic review. I ran no tests and changed nothing. This does not establish live-provider behavior, exhaustive reasoning-provider coverage, full final-stack verification, or the strict Git-based repository gate; the source remains an archive.
