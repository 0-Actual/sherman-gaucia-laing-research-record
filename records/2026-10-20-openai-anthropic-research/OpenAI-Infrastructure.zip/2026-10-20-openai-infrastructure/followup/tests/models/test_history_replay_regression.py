# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Preserve complete same-turn messages when replaying tool calls."""

from __future__ import annotations

import copy
from types import SimpleNamespace
from typing import Any, cast

import httpx2
import pytest
from openai.types.chat.chat_completion import ChatCompletion, Choice
from openai.types.chat.chat_completion_chunk import ChatCompletionChunk
from openai.types.chat.chat_completion_message import ChatCompletionMessage

from agents import Agent, OpenAIChatCompletionsModel, RunConfig, Runner
from agents.items import TResponseInputItem
from agents.models.chatcmpl_converter import Converter


def output_message(identifier: str, text: str | None = None, refusal: str | None = None):
    content = []
    if text is not None:
        content.append({"type": "output_text", "text": text, "annotations": []})
    if refusal is not None:
        content.append({"type": "refusal", "refusal": refusal})
    return {
        "id": identifier,
        "type": "message",
        "role": "assistant",
        "status": "completed",
        "content": content,
    }


def tool_call(identifier: str = "call-a"):
    return {
        "id": f"item-{identifier}",
        "type": "function_call",
        "call_id": identifier,
        "name": "lookup",
        "arguments": "{}",
    }


def tool_output(identifier: str = "call-a"):
    return {"type": "function_call_output", "call_id": identifier, "output": "synthetic"}


@pytest.mark.parametrize(
    ("parts", "expected_text", "expected_refusal"),
    [
        ([("first", None), ("second", None)], "first\nsecond", None),
        ([("first", None), ("second", None), ("third", None)], "first\nsecond\nthird", None),
        ([(None, "declined"), ("explanation", None)], "explanation", "declined"),
        ([("explanation", None), (None, "declined")], "explanation", "declined"),
        (
            [(None, "first refusal"), (None, "second refusal")],
            None,
            "first refusal\nsecond refusal",
        ),
        ([("", None), ("second", None)], "\nsecond", None),
        ([("α\nβ", None), ("🙂", None)], "α\nβ\n🙂", None),
    ],
    ids=[
        "two-texts",
        "three-texts",
        "refusal-text",
        "text-refusal",
        "two-refusals",
        "empty-text",
        "unicode-newlines",
    ],
)
def test_same_turn_content_is_preserved(parts, expected_text, expected_refusal):
    items = [tool_call()]
    items.extend(
        output_message(f"message-{i}", text, refusal) for i, (text, refusal) in enumerate(parts)
    )
    items.append(tool_output())
    original = copy.deepcopy(items)
    messages = Converter.items_to_messages(cast(list[TResponseInputItem], items))
    assert [message["role"] for message in messages] == ["assistant", "tool"]
    assert messages[0].get("content") == expected_text
    assert messages[0].get("refusal") == expected_refusal
    assert messages[0]["tool_calls"][0]["id"] == "call-a"
    assert messages[1]["tool_call_id"] == "call-a"
    assert items == original


def test_completed_turn_and_plain_assistant_turns_remain_separate():
    items = [
        tool_call(),
        output_message("a", "one"),
        output_message("b", "two"),
        tool_output(),
        output_message("c", "later"),
        output_message("d", "separate"),
    ]
    messages = Converter.items_to_messages(cast(list[TResponseInputItem], items))
    assert [message["role"] for message in messages] == [
        "assistant",
        "tool",
        "assistant",
        "assistant",
    ]
    assert [message.get("content") for message in messages] == [
        "one\ntwo",
        "synthetic",
        "later",
        "separate",
    ]


def test_parallel_calls_keep_results_contiguous_and_keep_their_ids():
    items = [
        tool_call("call-a"),
        output_message("a", "one"),
        tool_call("call-b"),
        output_message("b", "two"),
        tool_output("call-b"),
        tool_output("call-a"),
    ]
    messages = Converter.items_to_messages(cast(list[TResponseInputItem], items))
    assert [message["role"] for message in messages] == ["assistant", "tool", "tool"]
    assert [call["id"] for call in messages[0]["tool_calls"]] == ["call-a", "call-b"]
    assert [message["tool_call_id"] for message in messages[1:]] == ["call-b", "call-a"]
    assert messages[0]["content"] == "one\ntwo"


@pytest.mark.parametrize("native", [False, True], ids=["legacy-blocks", "native-blocks"])
def test_same_turn_merge_preserves_reasoning_blocks_and_signature(native: bool):
    model = "anthropic/claude-4-opus"
    blocks = [{"type": "thinking", "thinking": "synthetic reasoning", "signature": "signature"}]
    provider_data: dict[str, Any] = {"model": model}
    if native:
        provider_data["thinking_blocks"] = blocks
    items = [
        {
            "id": "reasoning",
            "type": "reasoning",
            "summary": [],
            "content": [{"type": "reasoning_text", "text": "synthetic reasoning"}],
            "encrypted_content": "signature",
            "provider_data": provider_data,
        },
        tool_call(),
        output_message("a", "one"),
        output_message("b", "two"),
        tool_output(),
        output_message("later", "separate"),
    ]
    original = copy.deepcopy(items)
    messages = Converter.items_to_messages(
        cast(list[TResponseInputItem], items),
        model=model,
        preserve_thinking_blocks=True,
    )
    assert [message["role"] for message in messages] == ["assistant", "tool", "assistant"]
    if native:
        assert messages[0]["thinking_blocks"] == blocks
        assert messages[0]["content"] == "one\ntwo"
    else:
        assert messages[0]["content"] == [
            *blocks,
            {"type": "text", "text": "one"},
            {"type": "text", "text": "two"},
        ]
    assert messages[0]["tool_calls"][0]["id"] == "call-a"
    assert messages[1]["tool_call_id"] == "call-a"
    assert messages[2]["content"] == "separate"
    assert "thinking_blocks" not in messages[2]
    assert items == original


@pytest.mark.allow_call_model_methods
@pytest.mark.parametrize("stream", [False, True], ids=["ordinary", "streamed"])
async def test_runner_sends_valid_replay_to_the_chat_adapter(stream: bool):
    """A fake transport captures the real adapter request without network I/O."""
    captured: list[dict[str, Any]] = []

    async def chunks():
        yield ChatCompletionChunk(
            id="synthetic",
            created=0,
            model="synthetic",
            object="chat.completion.chunk",
            choices=[
                {
                    "index": 0,
                    "delta": {"role": "assistant", "content": "done"},
                    "finish_reason": None,
                }
            ],
        )
        yield ChatCompletionChunk(
            id="synthetic",
            created=0,
            model="synthetic",
            object="chat.completion.chunk",
            choices=[{"index": 0, "delta": {}, "finish_reason": "stop"}],
        )

    async def create(**kwargs):
        captured.append(kwargs)
        if kwargs.get("stream"):
            return chunks()
        return ChatCompletion(
            id="synthetic",
            created=0,
            model="synthetic",
            object="chat.completion",
            choices=[
                Choice(
                    index=0,
                    finish_reason="stop",
                    message=ChatCompletionMessage(role="assistant", content="done"),
                )
            ],
        )

    client = SimpleNamespace(
        chat=SimpleNamespace(completions=SimpleNamespace(create=create)),
        base_url=httpx2.URL("https://synthetic.example.test/v1/"),
    )
    model = OpenAIChatCompletionsModel(model="synthetic", openai_client=client)
    agent = Agent(name="replay-boundary", model=model)
    items = [
        tool_call(),
        output_message("a", "first"),
        output_message("b", "second"),
        tool_output(),
    ]
    config = RunConfig(tracing_disabled=True)
    if stream:
        result = Runner.run_streamed(agent, items, run_config=config)
        async for _ in result.stream_events():
            pass
    else:
        result = await Runner.run(agent, items, run_config=config)
    assert result.final_output == "done"
    assert len(captured) == 1
    assert [message["role"] for message in captured[0]["messages"]] == ["assistant", "tool"]
    assert captured[0]["messages"][0]["content"] == "first\nsecond"
