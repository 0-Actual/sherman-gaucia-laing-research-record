# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Count canonicalizations in the history loop; no timing or speedup claim."""

from __future__ import annotations

import asyncio
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import sys
from unittest.mock import patch

from agents import Agent, RunConfig, Runner, function_tool
from agents.run_internal import tool_planning
from agents.testing import ScriptedModel, assistant_message, function_call


@function_tool
async def synthetic_lookup(value: int) -> str:
    """Return a deterministic synthetic result."""
    return f"result-{value}"


async def measure(turns: int, streamed: bool) -> dict:
    calls = Counter()
    original = tool_planning.tool_invocation_identity

    def counted(raw_item, *args, **kwargs):
        identity = original(raw_item, *args, **kwargs)
        if (
            identity is not None
            and sys._getframe(1).f_code.co_name
            == "_dedupe_processed_response_invocations"
        ):
            calls[identity[1]] += 1
        return identity

    steps = [
        [function_call("synthetic_lookup", {"value": i}, call_id=f"call-{i}")]
        for i in range(turns)
    ]
    steps.append([assistant_message("done")])
    agent = Agent(
        name="synthetic-count", model=ScriptedModel(steps), tools=[synthetic_lookup]
    )
    kwargs = {"max_turns": turns + 1, "run_config": RunConfig(tracing_disabled=True)}
    with patch.object(tool_planning, "tool_invocation_identity", counted):
        if streamed:
            result = Runner.run_streamed(agent, "synthetic input", **kwargs)
            async for _ in result.stream_events():
                pass
        else:
            result = await Runner.run(agent, "synthetic input", **kwargs)
    assert result.final_output == "done"
    assert len(result.new_items) == turns * 2 + 1
    history = result.to_input_list()
    outputs = [item for item in history if item.get("type") == "function_call_output"]
    assert [item["call_id"] for item in outputs] == [f"call-{i}" for i in range(turns)]
    assert [item["output"] for item in outputs] == [f"result-{i}" for i in range(turns)]
    return {
        "turns": turns,
        "mode": "streamed" if streamed else "ordinary",
        "historical_canonicalizations": sum(calls.values()),
        "per_call_counts": dict(calls),
        "history_sha256": hashlib.sha256(
            json.dumps(history, sort_keys=True, separators=(",", ":")).encode()
        ).hexdigest(),
        "output_count": len(outputs),
        "final_output": result.final_output,
    }


async def main():
    rows = []
    for turns in (10, 20, 40):
        for streamed in (False, True):
            rows.append(await measure(turns, streamed))
    print(
        json.dumps(
            {"observed_utc": datetime.now(timezone.utc).isoformat(), "rows": rows},
            indent=2,
        )
    )


if __name__ == "__main__":
    asyncio.run(main())
