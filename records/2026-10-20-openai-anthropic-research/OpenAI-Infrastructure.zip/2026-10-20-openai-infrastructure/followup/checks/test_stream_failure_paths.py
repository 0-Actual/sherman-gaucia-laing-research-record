# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Sherman G. Laing
"""Additional offline failure checks for the unchanged published helper."""

from __future__ import annotations

import asyncio
import sys
import unittest
from pathlib import Path

from agents import (
    Agent,
    GuardrailFunctionOutput,
    InputGuardrailTripwireTriggered,
    MaxTurnsExceeded,
    RunConfig,
    Runner,
    UserError,
    function_tool,
    input_guardrail,
)
from agents.testing import ModelStep, ScriptedModel, assistant_message, function_call

published = (
    Path(__file__).resolve().parents[3]
    / "outputs/OpenAI-Contributions-2026-10-20/stream"
)
sys.path.insert(0, str(published))
from owned_stream import owned_stream  # noqa: E402


class StreamFailurePaths(unittest.IsolatedAsyncioTestCase):
    def result(self, model, *, tools=(), guardrails=(), max_turns=10):
        return Runner.run_streamed(
            Agent(
                name="synthetic-failure-check",
                model=model,
                tools=list(tools),
                input_guardrails=list(guardrails),
            ),
            "synthetic input",
            max_turns=max_turns,
            run_config=RunConfig(tracing_disabled=True),
        )

    async def consume(self, result):
        async with asyncio.timeout(3):
            async with owned_stream(result) as events:
                async for _ in events:
                    pass

    def assert_run_settled(self, result):
        self.assertTrue(result.is_complete)
        self.assertIsNotNone(result.run_loop_task)
        self.assertTrue(result.run_loop_task.done())

    async def test_model_error_identity_survives_cleanup(self):
        expected = ConnectionError("synthetic model failure")
        result = self.result(ScriptedModel([ModelStep.raise_error(expected)]))
        with self.assertRaises(ConnectionError) as caught:
            await self.consume(result)
        self.assertIs(caught.exception, expected)
        self.assert_run_settled(result)

    async def test_tool_error_cause_and_finalizer_survive_cleanup(self):
        settled = asyncio.Event()
        expected = LookupError("synthetic tool failure")

        @function_tool(failure_error_function=None)
        async def failing_tool() -> str:
            """Raise a controlled test failure."""
            try:
                raise expected
            finally:
                settled.set()

        for owned in (False, True):
            with self.subTest(owned=owned):
                settled.clear()
                result = self.result(
                    ScriptedModel(
                        [[function_call("failing_tool", {}, call_id="failure-call")]]
                    ),
                    tools=[failing_tool],
                )
                # The SDK wraps tool failures in UserError before exposing them
                # to the consumer. Verify the same boundary with and without ownership.
                with self.assertRaises(UserError) as caught:
                    if owned:
                        await self.consume(result)
                    else:
                        async with asyncio.timeout(3):
                            async for _ in result.stream_events():
                                pass
                self.assertIs(caught.exception.__cause__, expected)
                self.assertTrue(settled.is_set())
                self.assert_run_settled(result)

    async def test_turn_limit_survives_cleanup(self):
        @function_tool
        async def small_tool() -> str:
            """Return one synthetic value."""
            return "synthetic"

        result = self.result(
            ScriptedModel([[function_call("small_tool", {}, call_id="limit-call")]]),
            tools=[small_tool],
            max_turns=1,
        )
        with self.assertRaises(MaxTurnsExceeded):
            await self.consume(result)
        self.assert_run_settled(result)

    async def test_input_guardrail_prevents_model_execution(self):
        @input_guardrail(run_in_parallel=False)
        async def reject_input(context, agent, input):
            return GuardrailFunctionOutput(
                output_info="synthetic", tripwire_triggered=True
            )

        model = ScriptedModel([[assistant_message("must not run")]])
        result = self.result(model, guardrails=[reject_input])
        with self.assertRaises(InputGuardrailTripwireTriggered):
            await self.consume(result)
        self.assertEqual(len(model.calls), 0)
        self.assert_run_settled(result)
