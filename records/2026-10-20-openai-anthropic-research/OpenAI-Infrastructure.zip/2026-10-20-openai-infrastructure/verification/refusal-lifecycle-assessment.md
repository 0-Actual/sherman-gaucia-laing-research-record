# Fresh refusal and lifecycle contract assessment

Agent: `AI-review-agent-refusal`. Received October 20, 2026. The text below is the agent's actual assessment, preserved without converting it into strict protocol credit.

Recommendation: **keep the combined candidate held for the converter’s unresolved contract; the shell correction can proceed separately once its regression is included in the repository candidate.** This is a bounded, read-only contract assessment, not final-review credit. I made no edits, ran no tests, and published nothing.

Verified scope: detached `64cd5dfc5a1579870dcbed0ea42b27aa84033fee`, exactly two modified runtime files and one untracked test. Final SHA-256 readback matched:

| File | SHA-256 |
|---|---|
| `src/agents/models/chatcmpl_converter.py` | `173b6e5af1972e5767470a40e713917386f4f1cbcc96f4eefa21091b79f5459d` |
| `src/agents/run_internal/tool_actions.py` | `6b431942d1a68d74e8699c5215e5a78c477acf6678b8bb69c524906331f5303b` |
| `tests/models/test_history_replay_regression.py` | `eaa6cf4d01823a9fe1ae9834adf2a751303500541f3e8d848ce3154b162623e7` |

All references below are relative to the supplied repository.

**Patch-scoped runtime defects:** none demonstrated on an established supported producer path.

**Converter contract uncertainty:** `chatcmpl_converter.py:743–749` still keeps only the last refusal part within one output message; new lines `783–789` concatenate surviving refusals across separate output messages. Thus `[refusal A, refusal B]` inside one message produces `B`, whereas two messages produce `A\nB`. This difference is real, but the within-message reduction predates this patch and is present in the supplied v0.24.0 source. Neither symmetry nor the new fixture establishes which behavior is intended. I would not turn this into a runtime defect or expand the implementation without resolving that contract.

The originating-workflow gap remains material. The ordinary Chat Completions producer creates one message (`chatcmpl_converter.py:207–237`); the streamed producer assembles one message with at most one accumulated text and refusal part (`chatcmpl_stream_handler.py:1315–1337`). Model mixing is documented conditionally on shared features (`docs/models/index.md:398–406`), which does not prove the precise multi-message sequence occurs. The supplied discussion’s maintainer question and contributor admission, JSON lines `21` and `27`, directly confirm the unresolved origin. No live rejection was established.

The converter regression meaningfully checks the supplied construction: text/refusal combinations, call IDs, input immutability, subsequent-turn separation, parallel calls, and native/legacy thinking blocks. Its ordinary/streamed Runner cases (`177–245`) exercise the real adapter request path, shared at `openai_chatcompletions.py:605–627`. They still begin with manually constructed input and mock the transport. Their expected refusal concatenation is an assertion of the proposed contract, not independent evidence for it.

**Shell assessment:** the one-line change is supported and appropriately narrow. `ShellResult.output` is a list (`tool.py:1438–1443`), and empty lists render as `"(no output)"` (`tool_execution.py:975–978`). The released truthiness check converts that display text into a fabricated successful command entry; the candidate preserves `output=[]`. It retains display text, metadata, limits, and call identity.

Approval interruption/rejection returns before executor invocation (`tool_actions.py:498–546`); invocation remains at `570–579`; ordinary executor failures still use the unchanged failure fallback (`604–637`). Both shell dispatch branches call the same executor (`tool_planning.py:1034–1042,1096–1103`), and replay preserves the output list while removing SDK metadata (`items.py:470–479`). I found no approval bypass, extra execution, or ordinary/streamed divergence introduced here.

The external published shell regression file has useful Runner coverage for empty output, metadata, failures, rejection, and both modes (`test_integrity.py:92–208`), but it is outside this three-file candidate. Its source is review evidence; I did not execute it or infer current passing status.

The smallest resolution is to establish an originating supported converter workflow and explicitly choose repeated-refusal semantics, then align representative regressions with that decision. Shell regression integration and applicable verification can proceed independently.
