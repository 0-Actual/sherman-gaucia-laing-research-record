# Fresh originating-workflow contract assessment

Agent: `AI-review-agent-origin`. Received October 20, 2026. The text below is the actual assessment, preserved without converting it into strict protocol credit.

**Recommendation: hold the converter candidate pending originating evidence or an explicit supported-input contract.** Keep it as a bounded local proposal; do not describe it as a verified production failure or complete fix for #5342. I found no independently established producer of the exact `[function_call, message, message, matching_output]` shape.

This is a read-only contract assessment, **not strict final-review credit**. No edits, tests, synthetic producers, memory inspection, or publishing were performed.

Verified detached HEAD: `64cd5dfc5a1579870dcbed0ea42b27aa84033fee`. The complete working diff contains the two runtime changes and the new 245-line regression file. Hashes were verified again after inspection:

| File | SHA-256 |
|---|---|
| `chatcmpl_converter.py` | `173b6e5af1972e5767470a40e713917386f4f1cbcc96f4eefa21091b79f5459d` |
| `tool_actions.py` | `6b431942d1a68d74e8699c5215e5a78c477acf6678b8bb69c524906331f5303b` |
| `test_history_replay_regression.py` | `eaa6cf4d01823a9fe1ae9834adf2a751303500541f3e8d848ce3154b162623e7` |

The evidence separates into three levels:

- **Representable and forwarded:** `TResponseInputItem` aliases the upstream Responses input type; `ModelResponse.output` is a list; `to_input_items()` preserves its sequence. The runner processes each output message. This establishes structural representability and forwarding, not the validity of every possible item order. See [items.py, lines 79–83 and 705–738](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/items.py:705) and [turn_resolution.py, lines 3201 and 3496–3497](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/run_internal/turn_resolution.py:3496).
- **Established adjacent behavior:** The non-streaming Chat Completions converter creates at most one message, combining text and refusal before appending calls. The stream terminal also creates one combined message, with calls ordered around it. See [converter, lines 207–240](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/models/chatcmpl_converter.py:207) and [stream handler, lines 1305–1350](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/models/chatcmpl_stream_handler.py:1305). LiteLLM and Any-LLM’s Chat Completions paths use those same conversion components.
- **Possible external origin, unverified:** Responses adapters forward `response.output` directly. Model-mixing documentation permits mixing when features exist on both shapes. Neither establishes that a provider emits two messages after a pending function call. See [Responses adapter, lines 671–675](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/models/openai_responses.py:671) and [model-mixing guidance, line 406](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/docs/models/index.md:406). Any-LLM also has a Responses pass-through path; it is inaccurate to characterize **all** Any-LLM output as using the Chat Completions converter.

Existing tests establish `[function_call, one_message]` replay, including a public Runner/session test, and separately establish multiple messages in a response **without** tool calls. They do not independently establish the candidate combination. See [existing converter tests, lines 382–492](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/tests/models/test_openai_chatcompletions_converter.py:382), [session replay test, lines 2267–2392](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/tests/models/test_openai_chatcompletions_stream.py:2267), and [multiple-message test, lines 180–205](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/tests/test_run_step_execution.py:180).

The new ordinary/streamed Runner test directly supplies the disputed history at lines 229–234 and returns a successful fake transport response at lines 205–225. It meaningfully exercises request construction, but proves neither origin nor provider acceptance/rejection. Its “valid replay” name exceeds what this test alone establishes. See [new regression test](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/tests/models/test_history_replay_regression.py:177).

**Actionable scope issue:** the new string-content and repeated-refusal merge behavior remains justified by the proposed requirement and synthetic sequence, without independent support evidence. Under AGENTS.md lines 68, 107, and 123, do not add further compatibility cases or manufacture an adapter to close that gap. The smallest next evidence is a sanitized originating response/history with provider, SDK version, transformation/model switch, item ordering, and call IDs—or a maintainer’s explicit decision to support application-constructed histories of this category. A paid provider call is unnecessary.

I found **no concrete new runtime defect on an established supported path** in this bounded inspection. Absence of originating evidence is not proof that the sequence is impossible.

The shell change has a separate, clearer basis: the public executor returns `ShellResult.output`; empty structured output is intentionally rendered as `"(no output)"`. Previously that display string could become a fabricated structured entry. The `is not None` change preserves the supplied empty list. See [shell execution, lines 581–644](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/run_internal/tool_actions.py:581) and [empty-output rendering, lines 975–978](<WORKSPACE>/work/openai-infrastructure/git-verification/repo/src/agents/run_internal/tool_execution.py:975). It should be assessed independently from the unresolved converter origin.

The supplied release-source snapshots contain the old converter guards and shell truthiness check. I **do not certify a Git comparison against v0.24.0**; its tag object was not verified here.
