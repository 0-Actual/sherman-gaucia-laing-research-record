"""Recheck the focused suite with a workspace-owned temporary directory.

Preserves the previous cleanup failure. Does not disable plugins or alter SDK
files, assertions, permissions, or the sandbox.
"""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "repo"
RUN = ROOT / "workspace-temp-retry"
RUN.mkdir(exist_ok=False)
TEMP = RUN / "tmp"
TEMP.mkdir()
assert TEMP.resolve().is_relative_to(ROOT.resolve())
PYTHON = ROOT.parent / "env/Scripts/python.exe"
EXPECTED = json.loads((ROOT.parent / "review/manifest.json").read_text(encoding="utf-8"))
ENV = dict(os.environ)
ENV.pop("OPENAI_API_KEY", None)
ENV.update(
    PYTHONPATH=str(REPO / "src"),
    PYTHONUTF8="1",
    PYTHONDONTWRITEBYTECODE="1",
    TMP=str(TEMP),
    TEMP=str(TEMP),
    TMPDIR=str(TEMP),
)


def hashes():
    return {p: hashlib.sha256((REPO / p).read_bytes()).hexdigest() for p in EXPECTED}


record = {
    "started_at_utc": datetime.now(timezone.utc).isoformat(),
    "reason": "Previous focused assertions passed but inline-snapshot cleanup exited 1.",
    "temporary_directory": str(TEMP),
    "normal_workspace_sandbox": True,
    "plugins_disabled": False,
    "source_hashes_before": hashes(),
    "steps": [],
}
assert record["source_hashes_before"] == EXPECTED


def run(name, args):
    result = subprocess.run(args, cwd=REPO, env=ENV, capture_output=True, timeout=600)
    (RUN / f"{name}.stdout").write_bytes(result.stdout)
    (RUN / f"{name}.stderr").write_bytes(result.stderr)
    record["steps"].append({"name": name, "args": args, "exit_code": result.returncode})
    (RUN / "receipt.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
    print(name, "exit", result.returncode, flush=True)
    print(result.stdout.decode("utf-8", errors="replace")[-1800:], flush=True)
    return result.returncode


probe = (
    "import pathlib,tempfile,sys; "
    "base=pathlib.Path(sys.argv[1]).resolve(); "
    "assert pathlib.Path(tempfile.gettempdir()).resolve()==base; "
    "p=tempfile.TemporaryDirectory(prefix='owned-probe-'); "
    "target=pathlib.Path(p.name).resolve(); "
    "assert target.is_relative_to(base) and target!=base; "
    "p.cleanup(); assert not target.exists(); "
    "print('Workspace temporary-directory create/remove passed')"
)
rc = run("temp-probe", [str(PYTHON), "-c", probe, str(TEMP)])
if rc == 0:
    rc = run(
        "focused-history",
        [str(PYTHON), "-m", "pytest", "-q", "tests/models/test_history_replay_regression.py"],
    )
record["source_hashes_after"] = hashes()
record["source_unchanged"] = record["source_hashes_after"] == record["source_hashes_before"]
record["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
record["exit_code"] = rc
record["contract_hold_unchanged"] = True
record["full_sdk_verification"] = False
(RUN / "receipt.json").write_text(json.dumps(record, indent=2), encoding="utf-8")
assert record["source_unchanged"], "Candidate bytes changed during focused verification"
raise SystemExit(rc)
