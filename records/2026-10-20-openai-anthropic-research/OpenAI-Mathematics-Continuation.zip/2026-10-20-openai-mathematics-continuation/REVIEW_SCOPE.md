# Scope, findings and unresolved dependencies

Source pin: [openai/math@1581d4cbdd69a0faf34b2089614fe2a814316a6a](https://github.com/openai/math/tree/1581d4cbdd69a0faf34b2089614fe2a814316a6a). This records review already performed; it does not assert that the pinned snapshot is current upstream main.

## Analytical and finite work through October 19

Family 271 review followed the spin-slot and exchange-cycle representation through simultaneous pins, exposure disintegration, fresh conditional laws, sparse geometry, routed flows, leakage estimates, signed-source cancellation and pressure/ordered-limit arguments. The second phase analytically read the eight numbered spherical-law sections, seven finite-range Bloch-law sections and the ordering manuscript's remaining equilibrium-state section. These are selected argument and section reads. Imported results, full dependency closure and end-to-end certification remain open.

The three included programs are original finite audit implementations. They do not execute the upstream Lean code or simulate the infinite model. Their recorded data are synthetic finite configurations, exact rational values, result counts and program-identification metadata. Negative controls exercise omitted factors, invalid dependence assumptions or incorrect projection order. A deliberately invalid input is not a counterexample to a manuscript whose hypotheses exclude it.

The earlier source/interface pass compared 31 model declarations and the target theorem header, and statically scanned 128 internal formal modules. [SOURCE_SCOPE.json](SOURCE_SCOPE.json) preserves the 159 retained source identities and each file's recorded October 19 reading mode. A file marked `identity_and_static_scan_only` must not be counted as semantically proof-reviewed. Reference checks likewise do not become whole-section reading.

## October 20 equilibrium-state passage

| Obligation | Bounded source-level finding | Remaining premise |
|---|---|---|
| Normalize averages | Nonnegative real weights sum to one; required uniform volumes are nonempty. Translations preserve the state operations used by the averaging construction. | Imported homomorphism, operator and state foundations are not all independently established. |
| Preserve the analytic bound | Finite convex averages preserve the common strip bound through the triangle inequality and norm-preserving translations. | The underlying finite Gibbs strip implementation remains a dependency. |
| Choose volume and field | After fixing an admissible temperature, each positive field receives a sufficiently large cube; the volume threshold may depend on the field. | No single field-uniform volume threshold or convergence rate is inferred. |
| Retain one limiting state | Volume and field sequences are composed with the same strictly increasing subsequence; weak convergence is for every observable. | Compactness, extraction and exact formal elaboration remain dependencies. |
| Remove the field | The local-support estimate avoids a requirement that field strength times volume tend to zero. | Deeper local-generator and dynamics estimates remain open to further review. |
| Preserve order | The total magnetization bound is divided by a positive cube cardinality before continuity passes it to the limiting state. | Physical order/surface/tilt premises are not fully certified. |
| Pass equilibrium boundaries | Both boundary correlation limits are locally uniform in time; multiplication order is retained. | Imported analytic theorem implementations remain unaudited in full. |
| Control an unbounded strip | Gaussian weighting controls tails; undoing the weight yields local uniform convergence. | Kernel/comparator acceptance remains unexecuted. |

At the pinned source, `Main.lean` lines 60–69 and the challenge lines 206–212 display the target theorem: natural dimension at least three, integer spin label at least one, dynamics convergence and an ordered equilibrium state above a positive inverse-temperature threshold. With `S = ℓ/2`, the displayed bound `ℓ/8` is `S/4`. This target does not state arbitrary finite-range asymptotics, the spherical law, Bloch's coefficient or the first lattice correction. The challenge placeholder is not evidence of a hole in the implementation.

The October 20 identity receipt covers 25 distinct source/configuration files, including 24 Lean sources. Its reading scopes come from overlapping review passes; the file population is not a number of fully verified proofs. [SOURCE_SCOPE.json](SOURCE_SCOPE.json) retains separate one-based reading ranges for those passes without exposing workstation paths or private coordination records. A whole-file read does not certify every imported lemma.

## Broader completed review register

The reconciled October 19 register, retained by this continuation, records 23 families with selected proof review (26 manuscripts), three statement-only families/manuscripts, 216 families with formal-scope-only review and 130 catalogue-only families. The family categories sum to 372. The manuscript denominator is 719 retained PDF paths. No single percentage represents completion of the full mathematical task.

Recent continuation work deepened eleven already-counted families: 025, 049, 076, 131, 173, 179, 218, 229, 276, 354 and 374. Its final five focused entries are:

| Family | Scoped analytical work recorded | Main unresolved part |
|---|---|---|
| 025 — Egyptian fractions | Shifted divisor-moment proof and deterministic high-level residue bounds | Random-product/common-realization premise and an unavailable referenced source |
| 131 — Graph-switch mixing | All-size slice absorption and positivity of the full disjoint contribution | Three-row variance premise; global mixing remains conditional |
| 276 — Quantum channels | Entropy-to-thermal-to-finite-partner Holevo/minimum-output-entropy chain | Imported operational coding result and complete/formal verification |
| 354 — Cubic torus | Local shape gain, nesting gain and derivative margins | Slice geometry, global reduction and equality classification |
| 374 — Transport stability | Cell, mass, moving-site and finite-potential arguments | Imported analytic inputs and complete/formal verification |

This edition reports those aggregate and scoped results; it does not distribute every broader review program or every private working record. No companion manuscript receives automatic proof-review credit from another paper's result.

## Formal execution boundary

Verified Lean builds, comparator executions, kernel axiom checks and whole-family certifications remain zero. The permitted-axiom list `propext`, `Quot.sound`, `Classical.choice` is policy configuration, not evidence of the implementation's checked dependencies.

The inspected pin requires Lean 4.34.1 and Mathlib `d13f23b723b8a846827a245b89c10fc7d3f11612`. The inspected local prerequisites were incomplete, including 23 compatibility patch bodies absent from the checked source/cache. Loading the stock configuration has dependency setup hooks. Exact compatible checker/exporter versions and a suitable sandbox environment remain prerequisites for a later formal run. The [standalone comparator's integration into Lean 4.35](https://github.com/leanprover/comparator#deprecation) does not establish compatibility with this 4.34.1 pin. [Landrun documents Linux with Landlock](https://github.com/Zouuup/landrun#requirements).

No toolchain migration, dependency installation or formal build was performed for this edition. These environment findings explain why execution remains open; they do not establish a mathematical defect.
