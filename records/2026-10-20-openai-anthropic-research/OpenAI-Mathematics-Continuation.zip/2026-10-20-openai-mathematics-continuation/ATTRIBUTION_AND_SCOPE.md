# Attribution and reuse scope

Research direction and original review material: Sherman Gaucia Laing / Quantum.Earth.Laing. Codex supplied analytical-review, implementation, checking and documentation assistance. Multiple Codex review passes do not establish independent human peer review.

OpenAI and the authors credited by its public manuscripts retain attribution for the underlying mathematics and formal sources. Literature cited by those sources retains its attribution. This edition makes no claim of discovery, priority, institutional derivation, endorsement or ownership of mathematical facts, methods or coefficients.

The three finite audit programs are independently prepared review implementations, using synthetic data. They and their recorded result bytes are retained unchanged from the completed October 19 checks. The public summary and selected source/coverage maps are explicitly prepared derivatives of the larger review records. They are not a complete mirror of the working archive.

Original audit code, commentary, result selection and documentation retain the owner's existing [noncommercial research and evaluation license](LICENSE-QEL.md), within that license's stated scope. No new commercial or operational license is granted here. This is source-available review material with restrictions, not an unrestricted or OSI-approved open-source license.

The referenced OpenAI/math sources retain their independently applicable Apache-2.0 rights and notices. [UPSTREAM_LICENSE.txt](UPSTREAM_LICENSE.txt) preserves the upstream license text for reference. No upstream proof implementation or manuscript body is redistributed in this edition: [SOURCE_SCOPE.json](SOURCE_SCOPE.json) supplies paths, links, hashes and review classifications. The owner's license does not replace or narrow third-party rights. A reader obtaining upstream material must preserve its applicable notices and terms.

Hashes and Git blob identifiers establish byte identities, not owner signatures, trusted timestamps, proof correctness or authorship priority. This edition does not claim that OpenAI accepted a contribution or that any outside body certified the review. The documentation candidate on the owner's fork is a separate contribution-status record and is not evidence of proof acceptance.
