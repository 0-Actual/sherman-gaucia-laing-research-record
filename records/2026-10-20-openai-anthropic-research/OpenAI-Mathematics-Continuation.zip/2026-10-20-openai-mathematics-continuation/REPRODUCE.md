# Reproduce the finite checks

These are finite audit programs, not Lean proof checks. They require Python 3 and its standard library, with no package installation, network access, credentials or external data. The retained multipin and spherical result records identify Python 3.12.14; no fresh cross-version execution is claimed by this publication.

## Run in a fresh directory

Copy all three files from [code](code/) into one new empty directory. Keep `verify_multipin.py` beside `verify_exposure.py`, because exposure imports two helpers from it. From that directory run, without Python optimization flags:

```text
python verify_multipin.py
python verify_exposure.py
python verify_spherical_finite.py
```

The programs use assertions as checks, so do not use `-O`, `-OO` or `PYTHONOPTIMIZE`. They create the following result files next to the programs and refuse to overwrite an existing result:

```text
MULTIPIN_EXACT_RESULTS.private.json
EXPOSURE_EXACT_RESULTS.private.json
SPHERICAL_FINITE_RESULTS.private.json
```

The `.private.json` suffix is the original historical output naming convention. The programs contain synthetic examples and do not read personal data. Their exact bytes are retained here so the recorded `program_sha256` remains verifiable. The public historical copies live separately in [recorded-results](recorded-results/) under names without that suffix. For a later rerun, use another fresh directory rather than overwrite an earlier receipt. Python may also create its normal local `__pycache__` directory.

## Compare substantive results

The historical outputs are from October 19, 2026. A fresh run will change timestamp fields and may change the reported Python version. Compare every mathematical result, case list, negative control and count after excluding only these top-level runtime metadata fields:

- Multipin: `started_utc`, `finished_utc`, `python`.
- Exposure: `started_utc`, `finished_utc`.
- Spherical: `created_utc`, `python`.

Do not exclude `program_sha256`: it must match for unchanged code bytes. File line-ending conversion changes the hash even when the apparent text is unchanged; preserve bytes when copying. This edition's [manifest](MANIFEST.json) lists exact SHA-256 values and byte lengths. A differing run should be investigated rather than normalized into a pass.

Expected substantive populations:

| Program | Expected results |
|---|---|
| Multipin | 4,282 deterministic splicing configurations; 1,702 weighted-law pin configurations; 4,054 conditional-presence pair checks; exact 11-variable polynomial identity; missing-term and invalid-correlated-law negative controls detected |
| Exposure | 11 cases; 125 positive branches; six zero branches; omitted outer conditioning factor detected in qualifying cases |
| Spherical | 18 model/parameter cases; 564 exposure branches; 1,815 conditional matrix entries; 54 susceptibility-vector checks; three projection-axis controls; nine exact exponent checks |

The exposure cases and spherical branches are nested populations, not independent theorem counts. An individual omitted-factor control may correctly report false in a degenerate case; the programs require detecting it in the appropriate population, not in every case.

No finite check was rerun while assembling this edition. Publication preparation checked copied bytes, recorded program-hash agreement, JSON readability and manifest integrity. It did not re-establish the mathematical results, execute upstream source, run Lean or certify the infinite-volume theorem.
