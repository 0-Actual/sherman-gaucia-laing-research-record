"""Independent exact checks for the finite simultaneous-pin argument.

Original audit implementation. It does not run upstream code, simulate the
infinite spin model, or replace the analytic stability/limit argument.
"""
from fractions import Fraction as F
from itertools import permutations, combinations
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, platform

ROOT = Path(__file__).resolve().parent

def subsets(items):
    items = tuple(items)
    for k in range(len(items)+1):
        yield from (frozenset(s) for s in combinations(items,k))

def cycles(p):
    unseen = set(range(len(p)))
    out = []
    while unseen:
        i = min(unseen); c = set()
        while i not in c:
            c.add(i); unseen.remove(i); i = p[i]
        out.append(frozenset(c))
    return tuple(out)

def next_pin(p, pins):
    result = {}
    for i in pins:
        j = p[i]
        for _ in range(len(p)):
            if j in pins: break
            j = p[j]
        else: raise AssertionError('A finite permutation cycle must return')
        result[i] = j
    assert set(result.values()) == set(pins)
    return result

def bernoulli_law(n, factors):
    law = {tuple(range(n)):F(1)}
    for a,b,probability in factors:
        new = defaultdict(F)
        for p,weight in law.items():
            new[p] += weight*(1-probability)
            # Compose the transposition on the output side.
            q = tuple(b if j==a else a if j==b else j for j in p)
            new[q] += weight*probability
        law = {p:w for p,w in new.items() if w}
    assert sum(law.values()) == 1
    return law

def inspect_law(law, E, T):
    P = E|T; m = len(T)
    ZE = ZP = eventE = eventP = F(0)
    incoming = {j:F(0) for j in T}
    next_images = []
    for p,mass in law.items():
        cs = cycles(p)
        wE = 2**sum(c.isdisjoint(E) for c in cs)
        wP = 2**sum(c.isdisjoint(P) for c in cs)
        ZE += mass*wE; ZP += mass*wP
        sigma = next_pin(p,P)
        images = frozenset(sigma[i] for i in T)
        H = all(c.isdisjoint(E) for c in cs if not c.isdisjoint(T))
        assert H == (images == T) == T.issubset(images)
        if H: eventE += mass*wE; eventP += mass*wP
        for j in T: incoming[j] += mass*wP*(j in images)
        next_images.append((mass*wP,images))
    marginals = {j:x/ZP for j,x in incoming.items()}
    r = sum(marginals.values())/m
    product = F(1)
    for x in marginals.values(): product *= x
    # Quantities returned even for the deliberately invalid law.
    result = {'Pr_E_H':eventE/ZE,'Pr_P_H':eventP/ZP,'product':product,
              'r_power':r**m,'bound':(2*r)**m,'r':r,'ZP':ZP,'ZE':ZE}
    assert ZP <= ZE <= 2**m*ZP
    # Independent verification of the conditioning chain used in the proof.
    conditional_pairs = 0
    for B in subsets(T):
        total = sum(w for w,A in next_images if B <= A)
        if not total: continue
        for j,k in combinations(sorted(T-B),2):
            pj = sum(w for w,A in next_images if B|{j} <= A)/total
            pk = sum(w for w,A in next_images if B|{k} <= A)/total
            pjk = sum(w for w,A in next_images if B|{j,k} <= A)/total
            if pjk > pj*pk:
                result['conditional_pair_violation'] = True
            conditional_pairs += 1
    result['conditional_pairs_checked'] = conditional_pairs
    return result

def monomial_product(poly, a, b):
    new = defaultdict(int)
    for key,c in poly.items():
        assert not key & a and not key & b
        new[key|a] += c; new[key|b] += c
    return dict(new)

def splicing_check(n,p,P):
    poly = {0:1}
    for i in range(n): poly = monomial_product(poly,1<<i,1<<(n+p[i]))
    for q in set(range(n))-P:
        x,y = 1<<q,1<<(n+q)
        new = defaultdict(int)
        for key,c in poly.items():
            if bool(key & x) != bool(key & y): new[key & ~(x|y)] += c
        poly = dict(new)
    free_cycles = sum(c.isdisjoint(P) for c in cycles(p))
    expected = {0:2**free_cycles}
    for i,j in next_pin(p,P).items():
        expected = monomial_product(expected,1<<i,1<<(n+j))
    assert poly == expected

# Sparse polynomial arithmetic proves the complex partial-symmetrization
# identity identically, without floating point values or external packages.
NVARS = 11
ZERO = {}
ONE = {(0,)*NVARS:1}
def add(a,b):
    d = defaultdict(int,a)
    for key,c in b.items(): d[key] += c
    return {key:c for key,c in d.items() if c}
def neg(a): return {key:-c for key,c in a.items()}
def sub(a,b): return add(a,neg(b))
def mul(a,b):
    d = defaultdict(int)
    for ea,ca in a.items():
        for eb,cb in b.items(): d[tuple(x+y for x,y in zip(ea,eb))] += ca*cb
    return {key:c for key,c in d.items() if c}
def variable(k):
    e = [0]*NVARS; e[k] = 1
    return {tuple(e):1}
def ca(a,b): return add(a[0],b[0]),add(a[1],b[1])
def cm(a,b): return sub(mul(a[0],b[0]),mul(a[1],b[1])),add(mul(a[0],b[1]),mul(a[1],b[0]))
def conj(a): return a[0],neg(a[1])
def scale(a,s): return mul(a[0],s),mul(a[1],s)
def norm2(a): return add(mul(a[0],a[0]),mul(a[1],a[1]))

def partial_symmetrization_identity():
    a,b,c,e,z = [(variable(2*k),variable(2*k+1)) for k in range(5)]
    u = variable(10); v = sub(ONE,u)
    bu,cu = ca(scale(b,v),scale(c,u)),ca(scale(c,v),scale(b,u))
    def N(bb,cc): return cm(ca(a,cm(bb,z)),conj(ca(cc,cm(e,z))))[1]
    lhs = N(bu,cu)
    rhs = add(add(mul(v,N(b,c)),mul(u,N(c,b))),
              mul(mul(mul(u,v),norm2((sub(b[0],c[0]),sub(b[1],c[1])))),z[1]))
    assert sub(lhs,rhs) == {}
    # Omitting the correction term must fail the identity.
    wrong = add(mul(v,N(b,c)),mul(u,N(c,b)))
    assert sub(lhs,wrong)
    return {'identity':'exact polynomial equality','real_indeterminates':NVARS,
            'lhs_nonzero_monomials':len(lhs),
            'negative_control_omitted_term':'detected'}

def run():
    started = datetime.now(timezone.utc).isoformat()
    symbolic = partial_symmetrization_identity()
    splice_counts = {}
    for n in range(1,6):
        count = 0
        for p in permutations(range(n)):
            for P in subsets(range(n)):
                splicing_check(n,p,P); count += 1
        splice_counts[str(n)] = count
    populations = []; conditional_total = 0
    for n in range(2,7):
        factors = [(i,i+1,F((i%3)+1,5)) for i in range(n-1)]
        factors += [(n-1,0,F(2,3)),(0,1,F(1,2)),(n//2,n-1,F(3,7))]
        # Omit a possible same-site factor (only n=2).
        factors = [(a,b,p) for a,b,p in factors if a!=b]
        laws = [('noncommuting_bernoulli_product',bernoulli_law(n,factors)),
                ('deterministic_endpoint_factors',bernoulli_law(n,[(a,b,F(i%2)) for i,(a,b,_) in enumerate(factors)]))]
        if n <= 5:
            ps = list(permutations(range(n)))
            laws.append(('uniform_seam_permutation',{p:F(1,len(ps)) for p in ps}))
        for label,law in laws:
            count = conditional_pairs = 0
            for E in subsets(range(n)):
                for T in subsets(set(range(n))-E):
                    if not T: continue
                    # A declared bounded selection at n=6; exhaustive E/T up to n=5.
                    if n==6 and (len(T)>3 or len(E)>2): continue
                    q = inspect_law(law,E,T)
                    assert not q.get('conditional_pair_violation',False),(n,label,E,T,q)
                    assert q['Pr_P_H'] <= q['product'] <= q['r_power']
                    assert q['Pr_E_H'] <= q['bound']
                    count += 1; conditional_pairs += q['conditional_pairs_checked']
            populations.append({'n':n,'law':label,'permutations_in_support':len(law),
                                'disjoint_E_T_configurations':count,
                                'conditional_presence_pairs':conditional_pairs,
                                'status':'pass'})
            conditional_total += conditional_pairs
    bad = {(0,1,2,3):F(1,10),(2,3,0,1):F(9,10)}
    q = inspect_law(bad,frozenset({2,3}),frozenset({0,1}))
    assert q['Pr_E_H'] == F(4,13) and q['bound'] == F(1,25)
    assert q['Pr_P_H'] > q['product'] and q['conditional_pair_violation']
    negative = {k:str(v) for k,v in q.items()}
    negative['interpretation'] = 'Perfectly correlated swaps violate the independent-transposition/stability hypothesis. This is a negative control, not a manuscript counterexample.'
    result = {'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
              'python':platform.python_version(),
              'program_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'arithmetic':'Exact integer polynomials and fractions; no numerical tolerances.',
              'symbolic_partial_symmetrization':symbolic,
              'deterministic_splicing_configurations_by_n':splice_counts,
              'deterministic_splicing_configurations_total':sum(splice_counts.values()),
              'law_populations':populations,
              'law_pin_configurations_total':sum(p['disjoint_E_T_configurations'] for p in populations),
              'conditional_presence_pair_checks_total':conditional_total,
              'arbitrary_correlated_law_negative_control':negative,
              'scope':'Finite exact checks and one symbolic identity; not a Lean proof, continuous-time disintegration, or validation of the full thermodynamic theorem.'}
    out = ROOT/'MULTIPIN_EXACT_RESULTS.private.json'
    assert not out.exists(), 'Preserve prior run receipts; choose a new filename for any rerun.'
    out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__': run()
