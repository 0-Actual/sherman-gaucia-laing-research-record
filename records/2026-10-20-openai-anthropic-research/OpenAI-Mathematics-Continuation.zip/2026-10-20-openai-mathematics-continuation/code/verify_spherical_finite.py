"""Independent rational checks of selected finite spherical-law identities.

This is original audit code. It neither implements the infinite-volume proof
nor establishes the theorem. Python standard library only; no external inputs.
"""
from collections import defaultdict
from datetime import datetime, timezone
from fractions import Fraction as F
from itertools import combinations, permutations
from pathlib import Path
import hashlib, json, platform

HERE = Path(__file__).resolve().parent

def subsets(items):
    items = tuple(items)
    for k in range(len(items)+1):
        yield from (frozenset(s) for s in combinations(items, k))

def cycles(p):
    unseen = set(range(len(p))); result = []
    while unseen:
        i = min(unseen); cycle = set()
        while i not in cycle:
            cycle.add(i); unseen.remove(i); i = p[i]
        result.append(frozenset(cycle))
    return result

def next_pin(p, pins):
    answer = {}
    for i in pins:
        j = p[i]
        while j not in pins:
            j = p[j]
        answer[i] = j
    return answer

def swap(n, a, b, q):
    p = list(range(n)); p[a], p[b] = p[b], p[a]
    return [(tuple(range(n)), 1-q), (tuple(p), q)]

def seam(n, sites):
    ps = list(permutations(sites)); result = []
    for perm in ps:
        p = list(range(n))
        for i,j in zip(sites, perm): p[i] = j
        result.append((tuple(p), F(1,len(ps))))
    return result

def histories(n, factors):
    law = {(tuple(range(n)),):F(1)}
    for factor in factors:
        out = defaultdict(F)
        for h, mass in law.items():
            for p, weight in factor:
                if weight: out[h+(tuple(p[i] for i in h[-1]),)] += mass*weight
        law = dict(out)
    assert sum(law.values()) == 1
    return law

def exposure(h, A):
    return tuple(tuple(p[i] for i in sorted(A)) for p in h)

def fresh_law(n, factors, exposed):
    restricted = []
    for t, factor in enumerate(factors):
        allowed = [(p,w) for p,w in factor if w and tuple(p[i] for i in exposed[t]) == exposed[t+1]]
        mass = sum(w for _,w in allowed)
        assert mass > 0
        restricted.append([(p,w/mass) for p,w in allowed])
    return histories(n, restricted)

def eye(n): return [[F(i==j) for j in range(n)] for i in range(n)]
def zero(n): return [[F(0) for _ in range(n)] for _ in range(n)]
def add(a,b): return [[x+y for x,y in zip(ar,br)] for ar,br in zip(a,b)]
def scale(c,a): return [[c*x for x in row] for row in a]
def mm(a,b):
    n = len(a)
    return [[sum((a[i][k]*b[k][j] for k in range(n)),F(0)) for j in range(n)] for i in range(n)]
def inverse(a):
    n = len(a); m = [row.copy()+er for row,er in zip(a,eye(n))]
    for k in range(n):
        p = next(i for i in range(k,n) if m[i][k])
        m[k],m[p] = m[p],m[k]
        v = m[k][k]; m[k] = [x/v for x in m[k]]
        for i in range(n):
            if i != k:
                v = m[i][k]; m[i] = [x-v*y for x,y in zip(m[i],m[k])]
    result = [row[n:] for row in m]
    assert mm(a,result) == eye(n)
    return result

def direct_trace(n, law, w):
    """Enumerate the spin basis, field weights and two-flip matrix elements."""
    Z = F(0); pair = zero(n)
    for h,mass in law.items():
        p = h[-1]
        for down in subsets(range(n)):
            if frozenset(p[i] for i in down) == down:
                weight = mass*w**len(down); Z += weight
                for i in range(n): pair[i][i] += weight/4
            for i,j in combinations(range(n),2):
                flipped = down ^ {i,j}
                if frozenset(p[k] for k in flipped) == down:
                    power = (len(down)+len(flipped))//2
                    assert 2*power == len(down)+len(flipped)
                    value = mass*w**power/4
                    pair[i][j] += value; pair[j][i] += value
    return Z, [[x/Z for x in row] for row in pair]

def soft_case(name,n,factors,q):
    w = 1-q; law = histories(n,factors)
    branches = defaultdict(list); Z = F(0)
    for h,mass in law.items():
        cs = cycles(h[-1])
        for pins in subsets(range(n)):
            missing = [c for c in cs if c.isdisjoint(pins)]
            A = frozenset().union(*missing)
            weight = mass*q**len(pins)*w**(n-len(pins))*2**len(missing)
            branches[(A,exposure(h,A))].append((h,pins,weight))
            Z += weight
    expected_inverse = zero(n); trace = F(0)
    checks = 0; wrong_witness = False; empty = 0; disconnected = 0
    for (A,exposed), rows in branches.items():
        H = sorted(set(range(n))-A); index = {i:k for k,i in enumerate(H)}
        branch = sum(m for _,_,m in rows)
        if not H:
            empty += 1
            continue
        fresh = fresh_law(n,factors,exposed)
        K = zero(len(H))
        for h,mass in fresh.items():
            for i in H:
                assert h[-1][i] in index
                K[index[i]][index[h[-1][i]]] += mass
        assert all(sum(row)==1 for row in K)
        assert all(sum(K[i][j] for i in range(len(H)))==1 for j in range(len(H)))
        D = add(eye(len(H)),scale(-w,K)); inv = inverse(D)
        assert all(x >= 0 for row in inv for x in row)
        assert all(q*sum(row)==1 for row in inv)
        for i in H:
            actual = sum(m for _,P,m in rows if i in P)/branch
            assert actual == q*inv[index[i]][index[i]]
            checks += 1
            for j in H:
                expected_inverse[i][j] += branch/Z*inv[index[i]][index[j]]
                if i == j: continue
                actual = sum(m for h,P,m in rows if i in P and j in P and next_pin(h[-1],P)[i]==j)/branch
                expected = q*q/w*inv[index[i]][index[j]]
                assert actual == expected
                if actual != q*q*inv[index[i]][index[j]]: wrong_witness = True
                checks += 1
        trace += branch/Z*sum(inv[i][i] for i in range(len(H)))
        reachable = {0}; old = set()
        while old != reachable:
            old = reachable.copy()
            reachable |= {j for i in old for j in range(len(H)) if K[i][j] or K[j][i]}
        disconnected += len(reachable) < len(H)
    assert trace <= n
    trace_Z, pair = direct_trace(n,law,w)
    assert trace_Z == Z
    for i in range(n):
        assert pair[i][i] == F(1,4)
        for j in range(n):
            if i != j:
                assert pair[i][j] == (expected_inverse[i][j]+expected_inverse[j][i])/4
    vectors = [[F(1)]*n, [F((-1)**i) for i in range(n)], [F(2*i-(n-1),max(n,1)) for i in range(n)]]
    for f in vectors:
        observed = sum(f[i]*f[j]*pair[i][j] for i in range(n) for j in range(n))
        predicted = sum(x*x for x in f)/4 + sum(f[i]*f[j]*expected_inverse[i][j]/2 for i in range(n) for j in range(n) if i!=j)
        assert observed == predicted
    return {'case':name,'slots':n,'q':str(q),'base_histories':len(law),
            'exposure_branches':len(branches),'empty_hole_branches':empty,
            'disconnected_hole_branches':disconnected,'conditional_entries_checked':checks,
            'susceptibility_vectors_checked':len(vectors),'mean_inverse_trace':str(trace),
            'omitted_1_over_w_detected':wrong_witness,'status':'PASS'}

def tensor(a,b):
    return [[x*y for x in ar for y in br] for ar in a for br in b]

def operator_at(n,i,a):
    out = [[F(1)]]
    for j in range(n): out = tensor(out,a if i==j else eye(2))
    return out

def projection_checks():
    I = eye(4); swap2 = zero(4)
    for col in range(4): swap2[((col&1)<<1)|(col>>1)][col] = F(1)
    P = scale(F(1,2),add(I,swap2))
    assert mm(P,P) == P
    X = [[F(0),F(1,2)],[F(1,2),F(0)]]
    J = [[F(0),F(1,2)],[-F(1,2),F(0)]] # i*s_y, real anti-symmetric
    Z = [[F(1,2),F(0)],[F(0),-F(1,2)]]
    out = []
    for name,a in [('X',X),('iY',J),('Z',Z)]:
        G = add(operator_at(2,0,a),scale(-1,operator_at(2,1,a)))
        B = mm(mm(P,G),P)
        first = mm(mm(P,mm(G,G)),P); mistaken = mm(B,B)
        assert B == zero(4) and first != mistaken
        # A second replica checks the exact outer-compression expansion.
        Pr = tensor(P,P); Gr = add(tensor(G,I),tensor(I,G))
        left = mm(mm(Pr,mm(Gr,Gr)),Pr)
        right = add(add(tensor(first,P),tensor(P,first)),scale(2,tensor(B,B)))
        assert left == right
        out.append({'axis':name,'square_before_projection_nonzero':True,
                    'project_before_square_zero':True,'two_replica_identity':'PASS'})
    return out

def exponent_checks():
    a = F(1,100); k = F(199,100)
    checks = {
        'torus_cutoff':(a+F(7,2)-2*k,F(-47,100)),
        'sparse_irregularity':(3-6*F(9,10),F(-12,5)),
        'sparse_diffusion':(a-F(3,2),F(-149,100)),
        'sparse_energy':(a-1,F(-99,100)),
        'cell_energy':(2+9*F(1,200)+F(1,8)-F(5,2),F(-33,100)),
        'short_flag':(3*F(1,200)-F(1,8),F(-11,100)),
        'small_components':(3*F(1,200)-F(5,2),F(-497,200)),
        'hole_cancellation':(-(3-F(5,2))/2,F(-1,4)),
        'union_entropy_vs_tail':(-3*F(9,10)+F(5,2),F(-1,5)),
    }
    for actual,expected in checks.values(): assert actual == expected
    assert max(checks[n][0] for n in ('sparse_irregularity','sparse_diffusion','sparse_energy')) < F(-9,10)
    assert max(checks[n][0] for n in ('cell_energy','short_flag','small_components')) < F(-1,20)
    return {n:str(a) for n,(a,_) in checks.items()}

def main():
    target = HERE/'SPHERICAL_FINITE_RESULTS.private.json'
    assert not target.exists(), 'Preserve existing results; use a new directory for reruns.'
    models = [('identity',1,[]),('swap',2,[swap(2,0,1,F(2,5))]),
      ('noncommuting',3,[swap(3,0,1,F(1,3)),swap(3,1,2,F(3,5)),swap(3,0,1,F(2,7))]),
      ('two_components',4,[swap(4,0,1,F(2,5)),swap(4,2,3,F(3,7))]),
      ('seam_and_exchange',4,[seam(4,(0,1,2)),swap(4,2,3,F(2,3))]),
      ('five_slots',5,[swap(5,i,i+1,F(i+1,i+3)) for i in range(4)])]
    cases = [soft_case(name,n,factors,q) for name,n,factors in models for q in (F(1,7),F(1,2),F(6,7))]
    assert any(c['omitted_1_over_w_detected'] for c in cases)
    assert sum(c['empty_hole_branches'] for c in cases)>0
    assert sum(c['disconnected_hole_branches'] for c in cases)>0
    result = {'created_utc':datetime.now(timezone.utc).isoformat(),'python':platform.python_version(),
      'program_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
      'arithmetic':'fractions.Fraction, exact rational; no floating-point tolerance',
      'scope':'Finite exchange histories, soft-pin laws, spin-basis trace oracle, projection order, exponent arithmetic. Not the thermodynamic theorem or full-manuscript certification.',
      'cases':cases,'projection_checks':projection_checks(),'exponent_checks':exponent_checks(),
      'totals':{'model_and_q_cases':len(cases),
       'exposure_branches':sum(c['exposure_branches'] for c in cases),
       'conditional_entries_checked':sum(c['conditional_entries_checked'] for c in cases),
       'susceptibility_vectors_checked':sum(c['susceptibility_vectors_checked'] for c in cases)},
      'status':'PASS'}
    target.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    assert json.loads(target.read_text(encoding='utf-8')) == result
    print(json.dumps({'status':result['status'],'totals':result['totals']},indent=2))

if __name__ == '__main__': main()
