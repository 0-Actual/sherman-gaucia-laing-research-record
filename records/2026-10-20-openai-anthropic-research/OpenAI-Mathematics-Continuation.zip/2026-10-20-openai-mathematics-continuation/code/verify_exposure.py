"""Exact finite history tests of exposed-path disintegration and its marginal.

These are new finite, layered tests, not a repeat of the earlier next-pin matrix
tests and not a substitute for the continuous-time conditional-law proof.
"""
from fractions import Fraction as F
from itertools import permutations, product
from collections import defaultdict
from pathlib import Path
from datetime import datetime, timezone
import hashlib, json
from verify_multipin import cycles, subsets

ROOT = Path(__file__).resolve().parent

def swap(n,a,b,p):
    ident = tuple(range(n)); q=list(ident); q[a],q[b]=q[b],q[a]
    return [(ident,1-p),(tuple(q),p)]

def seam(n,sites):
    ps=list(permutations(sites)); out=[]
    for perm in ps:
        q=list(range(n))
        for i,j in zip(sites,perm): q[i]=j
        out.append((tuple(q),F(1,len(ps))))
    return out

def histories(n,factors):
    law={ (tuple(range(n)),):F(1) }
    for factor in factors:
        new=defaultdict(F)
        for history,w in law.items():
            for op,p in factor:
                if p:
                    h=history+(tuple(op[j] for j in history[-1]),)
                    new[h]+=w*p
        law=dict(new)
    assert sum(law.values())==1
    return law

def missing_labels(history,pins):
    missing=set()
    for c in cycles(history[-1]):
        hits=any(history[t][label]==site for site,t in pins for label in c)
        if not hits: missing.update(c)
    return frozenset(missing)

def expose(history,A):
    return tuple(tuple(state[label] for label in sorted(A)) for state in history)

def conditional_factor_law(n,factors,A,exposure):
    restricted=[]
    for t,factor in enumerate(factors):
        permitted=[(op,p) for op,p in factor
                   if tuple(op[j] for j in exposure[t])==exposure[t+1] and p]
        normalizer=sum(p for _,p in permitted)
        assert normalizer>0
        restricted.append([(op,p/normalizer) for op,p in permitted])
    return histories(n,restricted)

def run_case(n,factors,pins):
    law=histories(n,factors)
    tilted=defaultdict(F); Z=F(0)
    for h,p in law.items():
        A=missing_labels(h,pins)
        c=sum(bool(c & A) for c in cycles(h[-1]))
        tilted[h]=p*2**c; Z+=tilted[h]
    actual=defaultdict(lambda:defaultdict(F))
    for h,p in tilted.items():
        A=missing_labels(h,pins)
        actual[(A,expose(h,A))][h]+=p/Z
    reconstructed=defaultdict(F)
    branch_count=positive_count=zero_count=0
    omitted_g_detected=False
    for A in subsets(range(n)):
        marginals=defaultdict(F)
        for h,p in law.items(): marginals[expose(h,A)]+=p
        for exposure,mu in marginals.items():
            if set(exposure[-1])!=set(A): continue
            if any(site in exposure[t] for site,t in pins): continue
            # These are precisely the F_A branches; A may be empty.
            branch_count+=1
            mapping=dict(zip(sorted(A),exposure[-1])); unseen=set(A); cA=0
            while unseen:
                i=min(unseen); cA+=1
                while i in unseen:
                    unseen.remove(i); i=mapping[i]
            Q=conditional_factor_law(n,factors,A,exposure)
            # Check the unconditioned conditional-law construction against
            # the full history law, before imposing the all-hit event.
            direct={h:p/mu for h,p in law.items() if expose(h,A)==exposure}
            assert Q==direct
            G={h:p for h,p in Q.items() if missing_labels(h,pins)==A}
            g=sum(G.values())
            if not g:
                zero_count+=1
                assert (A,exposure) not in actual
                continue
            positive_count+=1
            outer=mu*2**cA*g/Z
            observed=actual[(A,exposure)]
            assert sum(observed.values())==outer
            assert {h:p/outer for h,p in observed.items()}=={h:p/g for h,p in G.items()}
            for h,p in G.items(): reconstructed[h]+=mu*2**cA*p/Z
            if g!=1:
                assert mu*2**cA/Z != outer
                omitted_g_detected=True
    assert reconstructed=={h:p/Z for h,p in tilted.items()}
    return {'slots':n,'factors':len(factors),'pins':[list(p) for p in sorted(pins)],
            'full_histories':len(law),'F_A_exposure_branches':branch_count,
            'positive_g_branches':positive_count,'zero_g_branches':zero_count,
            'omitting_outer_g_detected':omitted_g_detected,'status':'pass'}

started=datetime.now(timezone.utc).isoformat()
cases=[]
for n in (3,4):
    factors=[swap(n,0,1,F(2,5)),swap(n,1,2,F(3,7)),
             seam(n,tuple(range(min(n,3)))),swap(n,n-1,0,F(1,3))]
    for pins in ({(0,0)},{(0,0),(1,2)},{(0,0),(n-1,4)},
                 {(0,0),(1,0),(2,0)},{(0,0),(0,1),(0,2),(0,3),(0,4)}):
        cases.append(run_case(n,factors,frozenset(pins)))
cases.append(run_case(4,[swap(4,0,1,F(2,5)),swap(4,2,3,F(1,2))],frozenset({(0,0)})))
assert any(c['zero_g_branches'] for c in cases)
assert any(c['omitting_outer_g_detected'] for c in cases)
result={'started_utc':started,'finished_utc':datetime.now(timezone.utc).isoformat(),
        'program_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'arithmetic':'exact fractions','cases':cases,
        'positive_g_exposure_branches_total':sum(c['positive_g_branches'] for c in cases),
        'zero_g_exposure_branches_total':sum(c['zero_g_branches'] for c in cases),
        'scope':'Finite independent exchange/seam history laws only. Continuous-time and dense-boundary passages are separately reviewed analytically.'}
out=ROOT/'EXPOSURE_EXACT_RESULTS.private.json'
assert not out.exists()
out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps(result,indent=2))
